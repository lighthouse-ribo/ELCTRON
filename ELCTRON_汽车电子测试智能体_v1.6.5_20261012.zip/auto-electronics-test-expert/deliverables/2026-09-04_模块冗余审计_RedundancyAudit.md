# 模块冗余审计报告（2026-09-04）

## 0. 审计方式与范围

- **方法**：受信任 git 明文通道（`git grep` / `git show`）做全量引用图 + 顶层符号扫描，逐项行级人工核验。jcodemunch MCP 本会话未挂载（两轮检索无果），本次为等效替代方案，关键结论均经行级验证。
- **范围**：128 个受控文件（skills/ 71 个 py + 19 个 md、references/ 17 个、deliverables/ 9 个、agents/avatars/根文档）。
- **重要修正**：初次扫描曾把 `uds_test_generator.py` 126~4270 行判为「死代码」，行级核验后确认该区间是 `SCRIPT_HEADER = '''` 字符串模板（生成脚本的运行时文本，内含转义 `\"\"\"`），**不是死代码**。本报告为最终结论。

## 1. 结论总览

| 档位 | 数量 | 处置 |
|---|---|---|
| A. 删除后零功能影响 | 3 项 | 可删，删前逐项确认 |
| B. 重复造轮子（活代码） | 6 项 | 建议合并/加漂移校验 |
| C. 看似重复，实为刻意设计 | 3 项 | **不要合并** |
| D. 结构性重复，保留但需知晓 | 3 项 | 保持同步维护 |

## 2. A 档：删除后零功能影响

### A1. `skills/uds-diagnostic-test/scripts/param_resolver.py` + `test_param_resolver.py`（约 18 KB）
- **证据**：全包零引用。py 侧唯一引用是它自带的测试；`SKILL.md`、`README.md`、agents 文档均未提及；`uds_runner.py` 只 shell 调 `uds_survey_parser.py`（486 行）和 `sddb_extract.py`（595 行），从不调它。
- **判定**：其功能（调查表参数提取 + 就绪检查）已被 `sddb_extract`（service_prereq 矩阵，经 `uds_runner sddb-extract` 子命令进入正式链）+ `uds_survey_parser` 取代。
- **前提**：你确认没有手动 `python param_resolver.py --survey ...` 的使用习惯，即可删（连同其测试）。

### A2. `report_to_html.py` 第一个 `build_html`（709~961 行，约 253 行）
- **证据**：962 行定义了同名 `build_html`（docstring 标注「v2 报告阅读面」），Python 后定义覆盖前定义；两个 def 之间无模块级调用点。
- **回归**：删除后跑 `test_report_to_html.py`，并生成一次报告页比对。

### A3. `deliverables/` 全部 9 份历史报告（约 116 KB）
- **证据**：无任何运行时引用（唯一引用者是 `.gitignore` 白名单规则）。issue register、CODE_REVIEW、META_REVIEW、2026-09-03 加固两篇均为过程档案。
- **判定**：删除对专家运行零影响（git 历史可找回）。但它们是整改追溯链，**建议外移归档而非直接删**；是否处置由你决定。

## 3. B 档：重复造轮子（活代码，按收益排序）

> **执行状态（2026-09-04）：B2/B3 已完成合并并落地主分支（见第 9/11 节，commit c9c2138）；B4 经逐行比对确认为「语义不同的刻意并行」，降级至第 4 节；B5 已比对，合并挂起待表头文案决策（第 11 节）；B1 单独立项；B6 待运行时确认。**

### B1. `uds_test_generator.py` 内嵌运行时模板（最大项，4248 行 / 占全文件 66%）
- **事实**：23~4270 行是 `SCRIPT_HEADER` 字符串模板，内嵌整套生成脚本运行时（VectorSeedKeyDll、SeedKeyGen2、AES-CMAC/CTR、IsoTpTransport、UdsClient、TestResult、TestRunner、入口 main）。
- **重复本质**：同一条 $27 Gen2 算法存在两份实现，模块版 `seedkey_gen2.py`（gen_case_scripts 正式链引用）+ 模板版（uds_test.py 冒烟链内嵌）；ISO-TP/UDS 客户端同理与 `lin_tp.py`/`f1l1_uds.py` 构成文本分叉。**改模块不改模板 = 确定性漂移**。
- **建议**：①短期给关键函数加「模板版 vs 模块版」漂移校验脚本；②中期按 CODE_REVIEW 💭-03 拆文件；③定位上维持 SKILL.md 现有口径（uds_test.py 仅冒烟兜底，非正式全量路径）。

### B2~B5. 跨文件重复函数
| 函数 | 位置 | 处置结果 |
|---|---|---|
| `compute_pid` | `ldf_parser.py` / `lin_tp.py` | ✅ 已合并：两处数学等价，唯一实现保留在 `lin_tp.py`（纯函数参考实现，且被 `compute_checksum` 依赖），`ldf_parser.py` 改为 `from lin_tp import compute_pid` |
| `_set_timer_resolution` | `f1l1_uds.py` / `timing_trace.py` | ✅ 已合并：两处逐字节等价，抽到新共享模块 `win_timer.py`，两个文件改为导入（别名保持调用点不变） |
| `parse_int` ×3 | `project_config.py` / `ldf_parser.py` / `swdl_flow.py` | ⛔ 不合并：三者错误语义不同（ldf 软失败返 None / swdl 严格抛错带字段名 / project_config 静默回退默认值），移至第 4 节 |
| HEADERS/样式常量两份 | `build_testcase_template.py` / `build_testcase_xlsx.py` | **已合并（2026-09-04）**：抽 `testcase_headers.py` 共享常量，xlsx 版文案为权威，详见第 11 节 |

### B6. `report_to_html.py` v2 的 PAGE_JS 注入疑似冗余
- 1163 行注入 `PAGE_JS` 后，1600 行 `_replace_once` 又把整个 `<script>` 替换为 `PAGE_JS_FRAMEWORK`。需运行时确认后一并清理。

## 4. C 档：看似重复，实为刻意设计（勿合并）

1. **审查链同名函数**（`hex_tokens`、`_is_negative`、`_service`、`_session_declared`、`normalize_session` 跨文件出现）：差分审查原则要求审查器**不 import 生成器推导函数**，防共模失效。CODE_REVIEW 明确告诫「不要为合并而合并」。
2. **三个 argparse main 相似**（`ldf_parser` / `uds_survey_parser` / `dbc_parser`，相似度 0.80~0.82）：解析规则不同，保留并行实现。
3. **`系统合格性测试用例模板.xlsx` + `build_testcase_template.py`**：成品模板与重建器互补，非重复。
4. **`parse_int` ×3 并行保留**（2026-09-04 逐行比对降级）：`ldf_parser.parse_int` 软失败返 None（LDF 行解析容错）、`swdl_flow.parse_int` 严格抛错并带字段名（配置校验要求响亮失败）、`project_config.parse_int` 静默回退默认值（JSON 配置解析）。行为不等价，合并会改变错误处理语义。

## 5. D 档：结构性重复（保留但需知晓）

1. **`diagnosing-bugs` / `tdd` / `embedded-ponytail` 双份存在**：包内副本（plugin.json 注册，README 路由表引用）+ 用户级 `~/.workbuddy/skills/` 副本并存。包内删除会改变专家路由，**不属于零影响删除**；两份副本修改时需人工同步。
2. **`references/ISO-11898/ISO11898-1_学习清单.md`**：未进 `reference-routing.json` 路由资产，但被 `ISO-11898/README.md` 与 `references/README.md` 索引引用，属学习材料，保留。
3. **`skills/project_config.py` 位于 skills 根目录**：跨两个技能共享的配置契约（9 个文件 import），位置合理，勿动。

## 6. 建议执行顺序（每步独立提交 + 回归）

1. 删 `param_resolver.py` + `test_param_resolver.py` → 跑全套 unittest 确认 0 fail
2. 删 `report_to_html.py` 709~961 行 v1 `build_html` → `test_report_to_html.py` + 生成一次报告页比对
3. （可选）`deliverables/` 外移归档
4. 合并 B2~B4 跨文件重复函数（参照 CODE_REVIEW 🟡-03 流程：行为等价才抽，逐项独立提交）
5. `uds_test_generator.py` 漂移校验/拆分（工程量大，单独立项）

**A 档已于 2026-09-04 执行删除并全量回归通过**，详见第 8 节执行记录；B/C/D 档未动。

## 7. 方法附录（复现命令）

```bash
# 每个脚本的引用映射（py 导入 + 文档提及）
for n in $(git ls-files '*.py' | xargs -n1 basename | sed 's/\.py$//' | sort -u); do
  echo "== $n"; git grep -l -w "$n" -- '*.py' '*.md' | grep -v "/$n\.py$"
done
# 顶层符号扫描（注意：会命中字符串模板内的文本，需行级核验三引号边界）
git grep -n -E "^(def|class) [A-Za-z_]" -- '*.py'
# 模板字符串边界核验
git grep -n -E "^[A-Za-z_]+ *= *('''|\"\"\")" -- '*.py'
```

## 8. 执行记录（2026-09-04 A 档删除）

| 项 | 动作 | 结果 |
|---|---|---|
| A1 | 删 `param_resolver.py` + `test_param_resolver.py` | 完成，git status 记 `D`，`git show HEAD:<path>` 可找回 |
| A2 | 删 `report_to_html.py` 709~961 行 v1 `build_html`（Edit 通道，文件保持明文） | 完成：`def build_html` 剩 1 处，1716→1463 行（−253），`py_compile` 通过 |
| A3 | 删 `deliverables/` 9 份历史报告（保留本审计报告） | 完成，git 历史可找回 |

**回归验证**：
- `uds-diagnostic-test` 全套件 `run_tests.py`：**24/24 测试文件 PASS**（EXIT=0；DLP 环境实际耗时 5m12s，后台执行）
- `srs-uds-testcase-designer`：`test_case_lint` + `test_uds_full_matrix_generator` 共 **25 例 OK**
- 删除与修改均保持**未提交**状态，建议核对 `git status` 后一次提交

## 9. 执行记录（2026-09-04 B2/B3 合并）

**改动清单**：

| 文件 | 动作 |
|---|---|
| `win_timer.py` | 新建共享模块：`set_timer_resolution()`（Windows timeBeginPeriod，失败静默），附合并来源说明 |
| `f1l1_uds.py` | 删除本地 `_set_timer_resolution` 定义；模块级调用随包内导入区移至 sys.path 守护之后（保持文件自身 `# noqa: E402` 约定）；`from win_timer import set_timer_resolution as _set_timer_resolution`，调用点不变 |
| `timing_trace.py` | 删除本地定义，顶部改为 `from win_timer import set_timer_resolution as _set_timer_resolution`，`:125` 调用点不变 |
| `ldf_parser.py` | 删除本地 `compute_pid` 定义，顶部 `from lin_tp import compute_pid`（唯一实现保留在 `lin_tp.py`，它被 `compute_checksum` 依赖） |

**行为等价证据**：
- `compute_pid` 两处同式（fid&0x3F，P0=ID0^ID1^ID2^ID4，P1=¬(ID1^ID3^ID4^ID5)）；合并后自检 0x3C→0x3C、0x30→0xF0，符合 LIN 规范
- `_set_timer_resolution` 两处逐字节等价（try windll.winmm.timeBeginPeriod / except pass）

**回归**：
- py_compile 4 文件通过；`import win_timer, f1l1_uds, ldf_parser, timing_trace` 导入冒烟通过
- 定向回归 `test_lin_tp + test_ldf_parser + test_timing_trace + test_link_check + test_partition_model`：43 例 OK
- 全量套件 `run_tests.py`：**24/24 测试文件 PASS**（EXIT=0，4m49s）

**附带发现（记录待办）**：`f1l1_uds.py` 模块级本地定义 `SF_MAX/FF_DATA/CF_DATA` 后又被 `from lin_tp import SF_MAX, ...` 覆盖（值相同），本地三行实为死赋值，后续清理时可删。

## 11. 执行记录（2026-09-04 B 档落地主分支：B2/B3/B6/B1 + B5 比对结论）

**B2/B3 主分支落地（commit `c9c2138`，4 文件 +27/−27）**：
- 移植来源：会话工作树已验证版本（备份 `~/.workbuddy/backups/auto-electronics-test-expert-20260904/`）；与基线 `48a8e6b` 的语义 diff（`--strip-trailing-cr`）**恰好仅为 B2/B3 三个改动块**，证明 Codex 1–8 未触碰这三个文件
- 移植方式：`f1l1_uds.py` / `timing_trace.py` 为明文文件，Edit 直改；`ldf_parser.py` 为密文文件，以基线明文整文件重建（先 `rm` 再 WorkBuddy Write，规避密文属性继承导致的编码劣化）
- 等价性：重建后与已回归备份版本**字节级一致**（MD5 `a14f8602`，CR 归一）；PID 自检 0x30→0xF0、0x3C→0x3C 合规
- 回归：py_compile 4 文件 + 导入冒烟 + 定向 43 例 OK（test_lin_tp / test_ldf_parser / test_timing_trace / test_link_check / test_partition_model）；全量 `run_tests.py` **24/24 PASS（EXIT=0，7m22s）**

**B5 比对结论（合并挂起，待决策）**：
- `build_testcase_template.py` 与 `build_testcase_xlsx.py` 的 HEADERS **同为 19 列且逐列语义一致**，仅两处外观差异：第 6 列 `测试点\nTest point`（模板）vs `测试点`（xlsx）；第 16 列 `缺陷编号 Defect ID`（模板，含空格）vs `缺陷编号Defect ID`（xlsx，无空格）
- 直接抽共享常量会改变其中一份交付 xlsx 的表头外观——**需先统一表头文案（用户定夺哪份为权威）再合并**；样式常量两边结构不同（模板为模块级 Font/Fill 对象、xlsx 在 build() 函数内构造），合并收益有限
- 状态：比对完成；剩余动作 = 统一第 6/16 列文案 → 抽 `testcase_headers.py` 共享常量 → 跑 designer 侧测试

**B5 共享常量抽取（2026-09-04 用户决策「xlsx 版为准」后执行）**：
- 新建 `skills/srs-uds-testcase-designer/scripts/testcase_headers.py`（19 列权威表头 + `len(HEADERS)==19` 断言）；两份 builder 各删除本地 HEADERS 块、改为 `from testcase_headers import HEADERS`；模板侧第 6 列随之 `测试点\nTest point` → `测试点`、第 16 列 `缺陷编号 Defect ID` → `缺陷编号Defect ID`
- 编辑通道勘误与选型：两份 builder 实为**明文**（此前「密文」判断有误——Read 工具误报 binary；python / git / cat 三通道均可完整读出 UTF-8）。Edit 工具因文件 CRLF 与匹配串 LF 不一致而未命中；改用 **sed -i 外科手术替换**（先探针验证 sed 写通道产物 python 仍可完整读、无密文劣化，顺带 LF 归一），`git diff` 确认改动恰好为「−HEADERS 块 +1 导入行」、中文无乱码
- 验证：py_compile 3 文件 OK；功能冒烟（模板 13 sheet 生成 + 用例 xlsx 生成 + 落盘自校验）回读 UDS 页 **G7=`测试点`、Q7=`缺陷编号Defect ID`、19 列齐全，双 PASS**；designer 侧受控测试（test_case_lint 23 例 + test_uds_full_matrix_generator 4 例）全 OK；全量 `run_tests.py` **24/24 PASS（EXIT=0，5m37s）**

**编码坑（复用价值高）**：对**已存在的密文文件**直接 WorkBuddy Write 会产出坏编码文件（python 报 `SyntaxError: (unicode error) 'utf-8' codec can't decode`）；必须先 `rm` 删除密文文件再 Write 重建（全新创建才是干净明文）。终端 diff 的中文乱码方向不可信（GBK 渲染会把真假颠倒），判断文件编码一律用 python 字节级 MD5 对比。

**B6 死代码清理（commit `208b710`）**：
- 结论：`report_to_html.py` 的 `PAGE_JS` 为**运行时不可达死代码**——v1 `build_html` 将其注入 `<script>%s</script>`，但 v2 统一走 `_render_framework_html`，其内部 `_replace_once(document, r"<script>.*?</script>", ..., flags=re.S)`（原 1347 行）把模板里的 script 占位整体替换为 `PAGE_JS_FRAMEWORK`，PAGE_JS 永远被覆盖
- 执行：删 PAGE_JS 两段定义（原 506~661 行），模板占位 `<script>%s</script>` 改为 `<script></script>`，format-args 元组移除 `PAGE_JS`；文件 1463 → 1304 行（本步 −159）
- 等价性证明：改动前后各生成一次 HTML，**字节级一致**（改动前 1463 行版本为对照基线）

**B1 短期措施：模板漂移校验脚本（`skills/uds-diagnostic-test/scripts/check_template_drift.py`，新增）**：
- 用途：`uds_test_generator.py` 内嵌 4248 行 `SCRIPT_HEADER` 模板与 `seedkey_gen2.py` / `lin_tp.py` 等模块文件存在同源复制关系，此脚本自动比对两者顶层 def/class 是否漂移，作为模板拆分（长期方案）前的护栏
- 实现：**列零行扫描**提取顶层 def/class（AST 解析不可行——模板含 `{test_methods}` 占位符后接类体缩进文本，`ast.parse` 报 `unexpected indent`），规范化 = dedent + rstrip + 去空行，模板模式额外恢复 `.format` 转义（`{{` → `{`）
- 三次踩坑修正：① AST → 列零扫描；② `_SEG_BREAK` 正则在列零赋值/装饰器/导入处切段（修 `_aes_cmac` 误报：模块级 `SEEDKEY_DLL_PATH` 赋值被并入函数体）；③ `template_mode=True` 恢复转义（修 `_to_key_bytes` 误报：模板 `{{len(s)}}` vs 模块 `{len(s)}`）
- 校验结果：`seedkey_gen2.py` 5 个同名顶层符号（SeedKeyGen2 / _aes_cmac / _aes_ctr / _to_key_bytes / main）**全部 SYNC，EXIT=0**；`lin_tp.py` 无同名顶层符号（模板用 IsoTpTransport/UdsClient 等类名，模块用 pack_*/compute_* 等函数名），按名比对天然无漂移，已在报告中如实标注

**全量回归收口（f1l1_uds 死赋值清理 `7165777` + B6 `208b710` 之后）**：`run_tests.py` **24/24 测试文件 PASS（EXIT=0，6m01s）**，B 档四项改动（B2/B3/B6/f1l1 清理）全部得到全量套件背书。

**B1 Phase 1：模板拆分（uds_test_generator.py 6431 → 2183 行）**：
- 动作：原 23~4270 行的内嵌 `SCRIPT_HEADER` 三引号模板（4248 源码行 / 字符串值 189,735 字符）**逐字节原样搬移**至新独立模块 `skills/uds-diagnostic-test/scripts/script_header_template.py`，生成器改为 `from script_header_template import SCRIPT_HEADER`（导入行落在原赋值位置，import 顺序零变化）；`__version__` 1.7.0 → 1.7.1
- 等价性证据：字符串值 MD5 拆分前后一致（**909fef0a0621c01937d15854044dd821**），三方核对（ast 解析旧文件基线 = 新模块导入 = 生成器命名空间导入）+ `SCRIPT_HEADER.format(...)` 入参未动，生成产物字节级等价；py_compile 3 文件 OK
- 联动修改：`check_template_drift.py` 默认 `--generator` 改指新模块（CLI 兼容不变）；`test_gen_case_scripts.py` 两处"读生成器源码断言模板内容"的测试（test_legacy_generator_did_probes_do_not_use_bbs_f190 / test_uds_runtime_result_object_normalizes_legacy_statuses）增加拼接读取模板源文本，语义与拆分前一致
- 拆分后护栏复跑：`check_template_drift.py`（无参数走新默认）**全部同步 EXIT=0**；`test_gen_case_scripts.py` 67/67 OK；全量 `run_tests.py` **24/24 PASS（EXIT=0，5m20s）**
- 编辑通道：目标文件为 CRLF，Edit 匹配不可用；全程 sed 行段操作（`sed -n '23,4270p'` 抽取 → `$r` 追加组装新模块 → `23,4270c\` 替换为导入行）+ git diff 逐行核对。**新踩坑**：MSYS 层会把命令参数中的 `\n` 改写为字面 `/n`（sed 替换与 python -c 双引号串均中招），多行插入须用 python `chr(10)` 构造换行经 stdin/stdout 管道完成
- Phase 2（单独立项）：模板内容从 seedkey_gen2/lin_tp 等模块源自动装配，消除同源复制本体

**并行外部改动记录（不纳入本审计提交）**：B5 执行期间仓库出现外部进程（疑为并行 Codex 会话）的改动——未跟踪新文件 5 个（`skills/input_manifest.example.json`、designer 的 `input_pack_validator.py` / `srs_focus_extractor.py` 及两份 test_*）+ 已跟踪修改 3 个（`references/input-file-spec.md`、`skills/srs-doc-extract/SKILL.md`、`skills/srs-uds-testcase-designer/SKILL.md`）。经用户决策**保持未提交状态**，留给外部会话自行收口；本审计所有提交均逐文件精准 add，未混入上述文件。

## 10. 执行记录（2026-09-04 A 档落地主分支 main）

- **背景**：Codex 已合并 1–8 项功能（项目配置、lint、门禁、会话流、矩阵生成、脚本链路、文档、回归验证）至主目录；同日 14:32 原 `.git` 元数据被外部进程清空（refs/、logs/、worktrees/ 丢失，历史对象仅剩 9 个散目录，旧提交 7ccc9f9/a69a929 等不可达）。补建 refs 后以工作区 128 个受控文件重建基线提交 `48a8e6b`，恢复 git 版本管理。
- **审查（删前复核，新基线上三项结论全部成立）**：
  - A1：`param_resolver` 全包仅 3 处提及（自身 ×2 + CODE_REVIEW_REPORT 历史报告本身），Codex 改动的 project_config/run_tests/SKILL.md 等未引入新引用，孤儿结论不变；
  - A2：`def build_html` 仍在 709（v1）/ 962（v2）两处，边界与旧基线一致，Codex 未触碰该文件；
  - A3：9 份历史报告仅被 deliverables 内部互引，无活代码/文档引用。
- **执行**：A1 删 2 个孤儿脚本；A2 Edit 删 v1 死代码块（WorkBuddy 明文通道）；A3 删 9 份历史报告并将本审计报告移入 `deliverables/`。独立提交，可单独 revert。
- **B 档说明**：B2/B3 合并仅在会话工作树完成并经 24/24 回归（成果备份于 `C:/Users/80026384/.workbuddy/backups/auto-electronics-test-expert-20260904/`），按「B 档暂定」指示**未落主分支**；MAIN 上 `compute_pid`/`_set_timer_resolution`/`parse_int` 等重复现状维持审计报告第 3/4 节所载。
- **回归（主分支 main，最终）**：py_compile 通过；定向 93 例 OK（test_report_to_html / test_project_config / test_uds_runner / test_gen_case_scripts）；全量套件 `run_tests.py` **24/24 测试文件 PASS（EXIT=0，5m00s）**。首跑 23/24 的唯一失败为 MAIN 自带 `.venv` 缺 `openpyxl`（requirements.txt 已列明，属 Codex 环境缺口、与 A 档删改无关），补装 openpyxl 3.1.5 后复跑全绿。

## 12. 交付收口（2026-09-04 下午）——B 档关闭，C 阶段暂缓

**交付判定**：B 档六项全部落地主分支 main，HEAD = `1a8da30`。提交链：A 档 `3f48fa9` → B2/B3 `c9c2138` → f1l1 死赋值清理 `7165777` → B6 `208b710` → B1 漂移护栏 `51e35a6` → B5 `50cd8d5` → B1 Phase1 `0985684` → B1 Phase2a `1a8da30`。工作区字节级锚点复验：`SCRIPT_HEADER` MD5 **93d3fb43525f048c2e7c64d663e73eca**（len 189656），与 Phase2a 锁定值一致；全量回归 24/24 已三轮背书（6m01s / 5m37s / 5m20s），`test_gen_case_scripts.py` 67/67。

**C 阶段（B1 Phase 2b 运行时装配）按「先给一个能交付的版本」决策暂缓**：转换器 v2 已写好、未执行、仓库零污染（只读校验过 B 态锚点）。设计要点：`SCRIPT_HEADER = _PART1 + _seedkey_block() + _PART2`——4 个同源符号（_to_key_bytes / SeedKeyGen2 / _aes_ctr / _aes_cmac）运行时从 `seedkey_gen2.py` 提取原始块（花括号双写适配 `.format` 模板），按模板胶水常量拼接，漂移在结构上不可能；`check_template_drift.py` 的 `compare` 改为 importlib 取模板值（附 AST 字面量回退）。转换器备份：`~/.workbuddy/b1_phase2_assemble.py`。

**恢复执行清单（预计约 3 分钟，不含全量回归）**：① `python b1_phase2_assemble.py verify`（B 态锚点 + 逐符号原始块等价自检）→ ② template / drift 两模式产物回写 `script_header_template.py` + `check_template_drift.py` → ③ 装配后 `SCRIPT_HEADER` MD5 必须仍等于 93d3fb43…（逐字节等价门槛）→ ④ py_compile + `check_template_drift.py --ignore main` 全 SYNC + `test_gen_case_scripts.py` 67/67 → ⑤ 全量 `run_tests.py` 24/24 → ⑥ 手术式提交（仅 script_header_template.py + check_template_drift.py + 本报告）。

**会话环境事件（已修复）**：本会话新建 worktree `main-b42e6c55` 的 `.git` 指针已写但主仓库 `worktrees/main-b42e6c55` 注册目录缺失，git 全量报 `not a git repository: (NULL)`；`git worktree add --force` 对非空目录两次 force 均拒绝。修复 = 手工补注册目录三件套（HEAD = 1a8da30 detached / gitdir / commondir）+ `reset --hard`。另：PortableGit bash 无 `rg`，代码检索用 `git grep` 或 python 替代。

**遗留**：无结构性遗留。并行外部改动（3 修改 + 5 未跟踪）保持未提交（见第 11 节末），留外部会话收口。
