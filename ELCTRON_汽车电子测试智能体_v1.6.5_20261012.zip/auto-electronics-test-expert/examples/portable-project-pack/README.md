# Portable Project Pack v0.1

复制此目录作为新项目包的起点。将真实项目文件放入对应目录，再更新 `input_manifest.json` 中的路径和 SHA-256；`project_context.json` 只保存规范化事实和缺口。

```text
portable-project-pack/
├── input_manifest.json
├── project_context.json
├── diagnostic/
│   ├── APP/SDDB_diagnostic.xlsx
│   ├── PBL/SDDB_diagnostic.xlsx
│   └── SBL/SDDB_diagnostic.xlsx
└── shared/
    ├── communication/       # DID 检查表、LIN Matrix、后续 LDF/DBC
    ├── requirements/        # SWRS、SRS
    ├── security/             # 安全文档；敏感材料只登记来源
    └── swdl/                # 刷写流程图
```

机器相关的 Python、DLL、通道和密钥存储引用放在包外的 execution profile，不复制进这个目录。缺少的资料不创建假文件，在 `project_context.json.gaps` 中登记。

执行前可在本机校验 profile 与本包上下文的绑定：

```powershell
python ..\..\skills\srs-uds-testcase-designer\scripts\execution_profile.py `
  --profile ..\execution-profile.local.json `
  --project-context .\project_context.json
```
