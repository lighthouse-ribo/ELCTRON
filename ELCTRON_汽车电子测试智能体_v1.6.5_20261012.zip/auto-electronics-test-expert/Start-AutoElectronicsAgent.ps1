﻿[CmdletBinding()]
param(
    [string]$WebRoot = $env:AETEX_WEB_ROOT,
    [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

trap {
    $message = "ELCTRON 未能启动。`n`n$($_.Exception.Message)`n`n请查看启动日志或确认 aetex-web 服务环境可用。"
    if ($NoBrowser) {
        [Console]::Error.WriteLine($message)
        exit 1
    }
    try {
        Add-Type -AssemblyName PresentationFramework
        [System.Windows.MessageBox]::Show($message, "ELCTRON 启动失败", "OK", "Error") | Out-Null
    } catch {
        Write-Error $message
    }
    exit 1
}

function Test-ELCTRONServer {
    try {
        foreach ($endpoint in @('http://127.0.0.1:5173/', 'http://127.0.0.1:5173/api/models')) {
            $request = [System.Net.HttpWebRequest]::Create($endpoint)
            $request.Timeout = 1500
            $request.ReadWriteTimeout = 1500
            $request.Proxy = $null
            $response = $request.GetResponse()
            try {
                if ($endpoint.EndsWith('/api/models')) {
                    if ($response.ContentType -notmatch 'application/json') { return $false }
                } else {
                    $reader = [IO.StreamReader]::new($response.GetResponseStream())
                    try { $html = $reader.ReadToEnd() } finally { $reader.Dispose() }
                    if ($html -notmatch '<title>\s*ELCTRON\s*</title>') { return $false }
                }
            } finally { $response.Close() }
        }
        return $true
    } catch {
        return $false
    }
}

function Wait-ELCTRONServer {
    param([int]$TimeoutSeconds = 20)

    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    while ([DateTime]::UtcNow -lt $deadline) {
        if (Test-ELCTRONServer) {
            return $true
        }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

function Start-ELCTRONFromWorkBuddyHost {
    param([string]$ProjectRoot)

    $prompt = "Start the local aetex-web development server from the supplied working directory. Use the project's dev command, do not modify files, keep the server running, and report localhost:5173 only after its health check succeeds."
    $query = "action=start&prompt=$([Uri]::EscapeDataString($prompt))&cwd=$([Uri]::EscapeDataString($ProjectRoot))"
    Start-Process "workbuddy://task?$query"
}

function Resolve-NpmCommand {
    $onPath = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if ($onPath) {
        return $onPath.Source
    }

    $versionsRoot = Join-Path $env:USERPROFILE ".workbuddy\binaries\node\versions"
    if (-not (Test-Path -LiteralPath $versionsRoot)) {
        return $null
    }

    $versions = Get-ChildItem -LiteralPath $versionsRoot -Directory |
        Where-Object { $_.Name -match '^\d+\.\d+\.\d+(?:-\d+)?$' } |
        Sort-Object @{ Expression = { [version]($_.Name -replace '-\d+$', '') }; Descending = $true },
                    @{ Expression = { $_.Name }; Descending = $true }
    foreach ($version in $versions) {
        $npm = Join-Path $version.FullName "npm.cmd"
        if ((Test-Path -LiteralPath $npm) -and
            (Test-Path -LiteralPath (Join-Path $version.FullName "node.exe"))) {
            return $npm
        }
    }
    return $null
}

$packageRoot = $PSScriptRoot
if (-not $WebRoot) {
    $WebRoot = "C:\Users\80026384\WorkBuddy\2026-09-15-13-29-06\aetex-web"
}
$WebRoot = [IO.Path]::GetFullPath($WebRoot)
$python = "C:\Users\80026384\.workbuddy\binaries\python\envs\default\Scripts\python.exe"

if (Test-ELCTRONServer) {
    Write-Host "ELCTRON 服务已在运行，正在打开页面：http://localhost:5173"
    if (-not $NoBrowser) {
        Start-Process "http://localhost:5173"
    }
    return
}

# DLP can make a desktop PowerShell process see the protected Web project as
# missing. Delegate cold start to WorkBuddy's trusted host in that case.
if (-not (Test-Path -LiteralPath (Join-Path $WebRoot "package.json"))) {
    Write-Host "正在请求 WorkBuddy 受信任宿主启动 ELCTRON 服务…"
    Start-ELCTRONFromWorkBuddyHost -ProjectRoot $WebRoot
    if (Wait-ELCTRONServer -TimeoutSeconds 90) {
        Write-Host "ELCTRON 服务已由 WorkBuddy 启动。"
        if (-not $NoBrowser) {
            Start-Process "http://localhost:5173"
        }
        return
    }
    throw "WorkBuddy 已收到启动请求，但 ELCTRON 服务未在 90 秒内就绪。请在 WorkBuddy 任务窗口查看启动结果。"
}

if (-not (Test-Path -LiteralPath (Join-Path $packageRoot "runtime\orchestrator\runtime_cli.py"))) {
    throw "专家包不完整：$packageRoot"
}
if (-not (Test-Path -LiteralPath (Join-Path $WebRoot "package.json"))) {
    throw "未找到 aetex-web。请设置 AETEX_WEB_ROOT，当前值：$WebRoot"
}
if (-not (Test-Path -LiteralPath $python)) {
    throw "未找到受控 Python：$python"
}
$npm = Resolve-NpmCommand
if (-not $npm) {
    throw "未找到 npm.cmd。请安装 Node.js LTS，或检查 WorkBuddy 托管的 Node.js 安装。"
}
if (-not (Test-Path -LiteralPath (Join-Path $WebRoot "node_modules"))) {
    throw "Web 依赖未安装。请先在 $WebRoot 执行 npm ci。"
}

$logDir = Join-Path $WebRoot ".aetex-logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logPath = Join-Path $logDir "dev-server.log"
$webQuoted = $WebRoot.Replace("'", "''")
$pkgQuoted = $packageRoot.Replace("'", "''")
$pyQuoted = $python.Replace("'", "''")
$logQuoted = $logPath.Replace("'", "''")
$npmQuoted = $npm.Replace("'", "''")
$nodeDirQuoted = (Split-Path -Parent $npm).Replace("'", "''")
$command = "Set-Location -LiteralPath '$webQuoted'; `$env:AETEX_PKG='$pkgQuoted'; `$env:AETEX_PYTHON='$pyQuoted'; `$env:PATH='$nodeDirQuoted;' + `$env:PATH; & '$npmQuoted' run dev *>> '$logQuoted'"

$process = Start-Process -FilePath "powershell.exe" -ArgumentList @(
    "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", $command
) -WindowStyle Hidden -PassThru

if (-not (Wait-ELCTRONServer)) {
    throw "Web 服务在 20 秒内未就绪。请查看日志：$logPath"
}

Write-Host "ELCTRON 已启动（进程 $($process.Id)）。"
Write-Host "专家包：$packageRoot"
Write-Host "Web 工程：$WebRoot"
Write-Host "日志：$logPath"
Write-Host "打开地址：http://localhost:5173"
if (-not $NoBrowser) {
    Start-Process "http://localhost:5173"
}
