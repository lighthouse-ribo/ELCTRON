# Auto Electronics Test Expert

面向车身域 ECU 的软件测试与诊断专家模块，覆盖 BCM、LIN 从节点及 CAN/CAN FD 节点。

## 能力

- SRS/SWRS、诊断调查表、CDD/DBC/LDF 的输入体检与需求追溯。
- UDS 用例设计：对象驱动全量矩阵或需求驱动矩阵；支持正例、负例、边界、时序、安全和恢复覆盖。
- 报文步骤审计、用例规则 lint、用例与脚本一一映射。
- LIN 网络测试独立技能：基于 LDF/LIN Matrix 验证帧、信号、调度、网络管理、节点一致性和错误注入；与 UDS 诊断及 SWDL 刷写分流，不混用 UDS 用例和 NRC 断言。
- CAN/CAN FD/LIN 通信测试、UDS-over-LIN、Bootloader 刷写测试和高实时采集-后处理。
- **SWDL 分层测试架构**：先做资料与能力门控，再按系统合格性测试表逻辑填充刷写用例、脚本、执行适配和统一证据报告；缺少 0x27 真实密钥时不阻断总体设计，但阻断依赖安全访问的实机执行，不虚构 PASS。
- **网络安全测试框架**：9 个工作域 + 18 个安全场景 + 需求→参考模式→派生用例的映射生成 + 选择性覆盖收敛 + PASS/FAIL/BLOCKED/PLANNED/NT/NA 门禁 + 敏感信息扫描 + HTML/ZIP 交付；LIN 仅作为承载通道，不与 `LIN-*` 帧/信号/调度用例混用。
- Vector 硬件预检、链路通探测、脚本生成/执行、HTML 报告和错误处理日志。
- NRC、无响应、丢帧和时序抖动的证据驱动定位。

## 路由

| 需求 | 使用技能 |
|---|---|
| 读取加密 SRS/PDF | `srs-doc-extract` |
| 由 SRS 或诊断资料设计用例 | `srs-uds-testcase-designer` |
| 生成或执行 UDS/CAN 诊断脚本 | `uds-diagnostic-test` |
| 设计或执行 LIN 网络帧/信号/调度测试 | `lin-network-test`（LDF → lin_db → 用例矩阵） |
| 分析缺陷或不稳定现象 | `diagnosing-bugs` |
| 修改包内工具脚本 | `tdd`，并先按 `embedded-ponytail` 检查复用方案 |

收到调查表后不会默认直接占用硬件。标准执行顺序是：解析 → 展示缺失项和默认值 → 用户确认 → 生成/审计 → 执行门禁 → 预检 → 链路探测 → 执行 → 报告。只有同时确认没有 CANoe/VickCAN 等占用进程且没有 CANviex/F1L1 设备时才允许直接输出设计产物；只要检测到任一项，必须硬件执行，不再提供 generate-only 参数。

## 重要口径

- 项目/主机厂资料优先于 ISO 示例和包内默认值；缺失参数标「待确认」，不编造报文或结果。
- 调查表未列服务不等于 ECU 不支持；只有资料明确说明或用户要求兼容性探测时才得出该结论。
- `PASS / FAIL / NA / BLOCKED / SKIP` 分开统计；密钥占位、缺参数、无硬件等前置问题标 `BLOCKED` 或 `NA`，不伪装成 `FAIL`。
- 不破解加密、不导出或硬编码密钥、不绕过 DLP；敏感材料在日志中使用 `<REDACTED>`。

## 常用示例

- “基于这份 SWRS 设计 0x22 用例”
- “解析这份 CDD 并列出生成用例前缺少的权限和时序信息”
- “根据诊断调查表生成脚本，但先不要执行”
- “ECU 无响应，请按证据链定位，不要直接猜根因”

详细命令、参数、模板和参考资料位于各技能目录；报告页面规范见 [DESIGN.md](DESIGN.md)。

## 目录

- `agents/auto-electronics-test-expert.md`：专家入口与路由门禁
- `skills/`：按任务拆分的技能、脚本和离线参考资料
- `.codebuddy-plugin/plugin.json`：当前 WorkBuddy/CodeBuddy 插件清单
