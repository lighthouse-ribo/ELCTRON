# 专家模块参考路由总入口

本目录把参考资产按三条规范分支组织：

- ISO-14229/：UDS 应用层，负责服务、NRC、会话、安全和服务器时序。
- ISO-11898/：CAN/CAN-FD 链路与物理层，负责帧、仲裁、错误、位时序、电气和低功耗。
- ISO-17987/：LIN，负责帧、PID、校验和、物理层、调度、节点配置、诊断传输和一致性。

机器可读路由表见 references/reference-routing.json。本页是给专家模块使用的人工速查入口。

## 挂载规则

每个任务按下面顺序选资料，避免把三套规范整包加载造成速查内容与任务错配：

~~~text
任务意图 → 主规范分支 → 总线承载分支（必要时） → 项目输入 → 工具专项资料
~~~

1. 先按任务意图选择唯一主分支。
2. 任务同时涉及 UDS 应用层和总线承载时，只追加一个辅分支：CAN/CAN-FD 追加 ISO 11898，LIN 追加 ISO 17987。
3. 纯协议问答只读主分支首选速查；不要默认加载另外两套规范。
4. 项目资料（SWRS/SRS、CDD/DBC/LDF、诊断调查表、主机厂规范）始终覆盖通用速查。
5. 速查没有明确覆盖的阈值、服务或配置标为“待确认”，不使用示例值补齐。

## 可执行路由器

需要把任务描述转换成可读取的最小资产清单时，运行：

~~~powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\reference_router.py" "UDS-over-LIN 使用 F1L1 诊断 NAD 0x3C/0x3D"
~~~

可用 --bus CAN、--bus CAN-FD 或 --bus LIN 覆盖自动识别。输出字段包括
primary_branch、secondary_branches、mounted_assets 和 optional_assets；
其中 mounted_assets 是本轮应该直接 Read 的最小集合，optional_assets 只在问题继续深入时加载。

## 任务路由表

| 任务主诉 | 主分支 | 首选资产 | 按承载追加 |
|---|---|---|---|
| UDS 服务设计、服务矩阵、请求/响应/NRC、会话、安全、P2/P2*/S3 | ISO-14229 | skills/srs-uds-testcase-designer/references/ISO14229-UDS-重点速查.md | CAN→ISO-11898；LIN→ISO-17987 |
| UDS 脚本生成、报文审计、DID/RID、刷写服务 | ISO-14229 | skills/srs-uds-testcase-designer/references/uds-services-cheatsheet.md | 按 CAN/LIN 追加对应分支；多帧再加 skills/uds-diagnostic-test/references/iso-tp-cheatsheet.md |
| ECU 无响应、意外 NRC、0x78、P2 超时、会话/安全排障 | ISO-14229 | `skills/uds-diagnostic-test/references/nrc-troubleshooting.md` | CAN→`references/ISO-11898/ISO11898-测试判定速查.md`；LIN→`references/ISO-17987/ISO17987-7_传输层与诊断速查.md` |
| CAN/CAN-FD 无通信、Error Frame、Bus Off、仲裁、位时序、终端、电平 | ISO-11898 | `references/ISO-11898/ISO11898-测试判定速查.md` | 只有进入 UDS 服务层时再加 ISO-14229 |
| LIN 帧、PID、校验和、调度表、休眠唤醒、从机无响应 | ISO-17987 | `references/ISO-17987/ISO17987-3_协议与帧速查.md` | 物理问题加 `references/ISO-17987/ISO17987-4_电气物理层速查.md`；配置问题加 `references/ISO-17987/ISO17987-6_节点配置与识别速查.md`；工具问题加 F1L1/VickCAN 资料 |
| UDS-over-LIN、F1L1、NAD、0x3C/0x3D、LIN 多帧 | ISO-17987 | `references/ISO-17987/ISO17987-7_传输层与诊断速查.md` | ISO-14229 作为 UDS 应用层伴随分支 |
| Bootloader / SWDL / 0x34/0x36/0x37 | ISO-14229 | skills/srs-uds-testcase-designer/references/ISO14229-UDS-重点速查.md | CAN→ISO-11898；LIN→ISO-17987；按需加 ISO-TP |

## 三个分支的边界

| 分支 | 能回答 | 不能单独回答 |
|---|---|---|
| ISO-14229 | 这个 SID/NRC/会话/安全/时序应该怎样 | CAN 电气、LIN PID、具体项目 DID 值 |
| ISO-11898 | CAN 帧为什么错误、总线为什么不通、物理层怎样测 | UDS 服务是否允许、NRC 语义、LIN 调度 |
| ISO-17987 | LIN 帧/节点/调度/诊断传输怎样工作 | UDS 服务业务语义、CAN 仲裁和 CAN 电气 |

## 冲突与证据

1. 项目/主机厂资料优先于规范速查。
2. 规范速查优先于工具手册和模型推断。
3. 任何“无响应”必须区分：帧未发出、帧未被接收、协议未重组、应用未响应。
4. 报告分别记录应用层、传输层、链路层、物理层证据，不把“上位机超时”当作根因。

## 原文边界

本包只分发面向测试任务的速查，不分发 ISO 原文 PDF。需要条款级证据时，按
read-encrypted-docs 流程处理用户提供的原文；不能引用本目录中不存在的原文路径。
