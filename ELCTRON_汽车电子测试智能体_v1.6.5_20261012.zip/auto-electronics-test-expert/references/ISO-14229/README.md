# ISO 14229 参考分支（UDS 应用层）

本分支只负责 UDS 应用层语义：服务与子功能、正/负响应、NRC、会话、安全访问和服务器时序。
CAN 的帧/电气问题转到 `references/ISO-11898/`；LIN 的帧、NAD、调度和诊断传输转到
`references/ISO-17987/`。这样处理“UDS 无响应”时，能把应用层超时与总线层不通分开。

## 任务到资产

| 任务 | 首选速查 | 需要时追加 |
|---|---|---|
| 服务矩阵、UDS 用例设计 | `skills/srs-uds-testcase-designer/references/ISO14229-UDS-重点速查.md` | `uds-services-cheatsheet.md` |
| 请求/响应/NRC/正响应 SID 审计 | `skills/srs-uds-testcase-designer/references/uds-services-cheatsheet.md` | `ISO14229-UDS-重点速查.md` |
| NRC、会话、安全排障 | `skills/uds-diagnostic-test/references/nrc-troubleshooting.md` | `ISO14229-UDS-重点速查.md` |
| 刷写 / Bootloader | `ISO14229-UDS-重点速查.md` | `uds-services-cheatsheet.md` + 对应总线分支 |
| 纯协议问答 | `ISO14229-UDS-重点速查.md` | 不自动加载 CAN/LIN 资料 |

## 读取纪律

- 先加载本分支，再根据输入中的 CAN/CAN-FD/LIN 证据决定是否追加一个总线分支。
- 具体 DID、会话权限、NRC 约束、P2/P2*/S3 和安全等级以项目资料为准；本分支只做通用基线。
- `ISO14229-UDS-重点速查.md` 负责“标准语义框架”，`uds-services-cheatsheet.md` 负责“写报文时的短表”，不要把两者当成互相独立的真值源。
- 只出现 LIN TP/CAN ISO-TP 的帧级问题时，不用整本 UDS 服务表；加载对应传输层资产即可。

## 跨层边界

```text
UDS 服务/NRC/会话/安全/时序
        │
        ├── CAN/CAN-FD 承载 → ISO-11898 + ISO-TP 资产
        └── LIN 承载        → ISO-17987 + LIN TP 资产
```

当“ECU 无响应”出现时，先按任务主诉确定是否是应用层问题；若没有响应证据，必须追加对应总线分支，不能只依据 14229 推断 ECU 拒绝。
