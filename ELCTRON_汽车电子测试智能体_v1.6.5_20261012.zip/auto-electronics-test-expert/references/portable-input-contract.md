# 可移植输入契约 v0.1

初版只固定最容易丢失、且跨项目必须保持一致的字段，完整 schema 留到解析器接入后再扩展。

## 三层

- `portable-core`：`schemas/portable-contract-v0.1.json`，只定义字段边界，不放项目值。
- `project-pack`：manifest、原始资料和 `project_context.json`，使用相对路径和 SHA-256。
- `execution-profile`：当前机器的 Python、DLL、硬件通道和受控密钥引用，不属于项目事实。

## 硬规则

1. `APP`、`PBL`、`SBL` 必须独立；跨分区资料使用 `shared`。
2. 原始文档保持文件化，context 只放规范化事实、证据定位、哈希和任务所需短片段。
3. 每条事实必须有 `status`：`confirmed`、`derived`、`pending`、`conflict` 或 `blocked`。
4. 缺失 functional NAD、刷写流程、安全材料等信息时保留缺口，不能用历史默认值补齐。
5. 密钥文件可以登记来源，但密钥值不得进入 context、日志或报告；执行时只使用 `provider/reference`。
6. 换项目只替换 project pack；换机器只替换 execution profile。

当前示例保留了已确认的 `0x51`、`19.2 kbps`、`5 ms`、`0.5 ms`，并将 functional NAD、0x27 执行材料和刷写流程标记为缺口。

## 文件到事实映射

`project_fact_mapper.py` 只建立来源索引，不解析文档。每个文件按 `role + partition` 映射到预期事实域，再通过 `fact.source.file_id` 连接已经确认的事实；没有事实的文件标记为 `unmapped`，敏感文件只标记 `metadata_only`。映射结果不复制 `fact.value`，也不把未解析的文件当成已知事实。

第六步开始接入现有解析器，但只通过适配层输出摘要事实：

- `diag_survey` 调用现有 `uds_survey_parser.parse_survey_table()`，只保留 DID、IOControl、Routine、DTC 数量及解析质量计数。
- `ldf` 调用现有 `ldf_parser.parse_ldf()`，只保留速率、主节点、从节点数量、信号/帧/调度数量及告警数量。
- `lin_matrix` 等尚未适配的角色明确标记为 `pending`，不把原文件或原始解析对象提升为事实。
- 每条事实携带 `id`、`partition`、`status`、`source.file_id` 和 `source.locator`；解析失败标记为 `blocked`。

适配结果使用 `project-fact-adapter/v0.1`，仍不改变现有 runner 的默认运行行为。

第七步使用 `project_context_builder.py` 生成唯一 `project_context.json`：

- manifest 的项目、分区和文件哈希作为上下文边界；
- 已有 `confirmed` 事实优先，已有 `derived` 事实可由本次解析刷新；
- 解析摘要、pending/blocked 状态和缺口统一进入同一 facts/gaps 结构；
- 同一分区的多个输入文件使用 `file_id` 参与事实 ID，避免跨项目或多文件覆盖；
- 适配器原始返回对象不进入上下文，确认事实冲突只保留来源证据。

第九步将缺口接入能力门控，门控结果写入本次输出目录并随 flow context 留证：

- `generation`：`pending` 允许生成但标记 `DEGRADED`；`blocked/conflict` 阻断生成。
- `hardware_execution`：`pending/blocked/conflict` 均阻断硬件执行；硬件预检前再次判断。
- 已通过现有执行器校验的 `project_config` 只确认其配置域，不清除原始 pending 记录。
- 门控只输出缺口 ID、状态、来源和决策，不复制事实值、原始文档或密钥。

第十步将本机执行配置与项目事实正式分离：

- `execution_profile.local.json` 只登记本机 Python、工作目录、传输适配器/DLL、硬件通道和受控密钥引用；不登记项目参数或密钥值。
- 用 `uds_runner.py execution-profile-check --profile <profile.json>` 校验版本、上下文 SHA-256、必需字段和密钥引用；`--require-files` 才检查本机 Python/DLL 是否存在。
- `uds_runner.py project/pipeline --execution-profile <profile.json>` 只生成脱敏绑定摘要并写入输出目录；runner 仍以 project-pack/context 的事实生成脚本，不把 profile 字段回写到 `project_context.json`。
- 绑定 project-pack 时，以所选包内的 `project_context.json` 重新核对 profile 声明的 SHA-256；换项目必须重新绑定对应上下文，换机器只需替换本机 profile。
- 没有提供 profile 时保留生成兼容路径，但硬件执行仍受 `execution_profile` 缺口门控；不能把缺失的机器配置伪装成项目事实。

## 第十一步：绑定生成产物

- `gen_case_scripts.py --project-context <project_context.json>` 将 `project_context` 的 schema、项目 ID（如有）和 SHA-256 摘要写入 `case_scripts/manifest.json`；不复制 facts、原始文件或密钥。
- `uds_runner.py project/pipeline` 将同一摘要写入 `effective_config_*.json`，并在生成后校验；有用例时 `run_all.py` 在清理旧结果和连接硬件前再次校验。
- 绑定路径始终相对生成产物目录，换项目必须重新生成绑定；复制完整输出目录时可保持绑定关系，换机器不需要改项目事实。
- context 文件缺失、被修改、绑定指向其他 context 或 schema 不一致时，产物校验失败并阻断执行；未带 context 的旧版直接 `gen-scripts` 保留兼容模式并明确提示未绑定。
