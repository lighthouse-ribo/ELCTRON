# 专家模块参考路由（兼容入口）

规范参考资产已经按三条分支重组，权威路由入口改为：

- 人工速查：`references/REFERENCE_ROUTING.md`
- 机器可读路由：`references/reference-routing.json`
- ISO 14229：`references/ISO-14229/README.md`
- ISO 11898：`references/ISO-11898/README.md`
- ISO 17987：`references/ISO-17987/README.md`

旧版任务表中的路径仍然有效，作为 canonical asset 保留；新任务请按 `REFERENCE_ROUTING.md` 只挂载一个主分支，并按 CAN/CAN-FD 或 LIN 需要追加一个承载分支。