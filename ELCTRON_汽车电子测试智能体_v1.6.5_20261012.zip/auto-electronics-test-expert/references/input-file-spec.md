# UDS 测试输入文件规范（Input File Spec）

> 跨项目通用规范，基于 BBS_P519_V436 实测验证（2026-08-19 固化）。
> 作用：约定「一次 UDS 测试任务需要什么输入文件、各文件的优先级与用途、缺失时的处置」，避免信息不足硬生成。
> 配套：`srs-uds-testcase-designer` 的「输入依赖矩阵」与 `uds-diagnostic-test` 的「强制确认（阻断点）」。

## 1. 输入文件优先级总表

按对用例设计与执行的影响排序（★ = 影响度）：

| 优先级 | 输入文件 | 提供什么 | 缺失处置 | 实测评级 |
|---|---|---|---|---|
| **P0 核心** | 诊断调查表（SDDB/ODX `*_diagnostic.xlsx`，**APP 主测，PBL/SBL 按需**） | DID/服务/例程/时序/会话/安全约束 | 无法设计参数化用例，先请用户提供 | ★★★★★ |
| **P0 核心** | DID 检查表（真实抓帧 + DID×APP/PBL/SBL 支持矩阵） | 每 DID 实测响应帧、分层受限（NRC31/NRC22）、公钥/常量写入状态场景 | 用调查表兜底，但分层受限与条件场景无法判定 | ★★★★★（常被低估） |
| **P1 高价值** | LDF 描述文件（LIN 节点） | 帧 ID/PID、信号位、调度表、**configured_NAD / functional_id**、主从节点 | 帧级步骤写「按 LIN Matrix」，**功能寻址 NAD 无法确认** | ★★★★ |
| **P1 高价值** | SWRS 软件需求规范（带 REQ 编号） | 真实需求 ID（REQ-xxxx）、功能/诊断章节 | 需求 ID 自动生成（`REQ-<章节>.<序号>`），追溯降级 | ★★★★（常被低估） |
| P2 有用 | LIN Matrix / 通信矩阵 | NAD、波特率、调度表、信号名 | 用 LDF 替代或按项目常识标注 | ★★★☆ |
| P2 有用 | SRS 系统需求（System Requirement） | 功能概述、诊断帧样例、章节 | 可继续，但细节以调查表/SWRS 为准 | ★★★ |
| P2 部分 | 0x27 密钥文档（算法/密钥） | Gen2 算法结构、密钥字段名 | **无真实密钥值 → 0x27 全部 BLOCKED**，不伪造 PASS | ★★☆ |
| P3 按需 | 刷写流程图（SoftwareDownload FlowChart） | 0x34/0x36/0x37 块大小/地址格式/时序/异常分支 | **刷写用例全部 BLOCKED/受限** | ★★★（刷写必需） |
| P3 可选 | CDD / DBC | DID 信号级定义 / CAN 报文编解码 | 回退调查表 / 「按 LIN Matrix」 | ★★（非 LIN 必需） |
| 工具类 | xcdevlay（F1L1 DLL）+ 开发文档 | 无 Vector 时的 LIN 执行引擎 | 无 Vector 且无 xcdevlay → generate-only | ★★★★（执行必需） |

**规则**：文件够用（P0+P1 齐备）才进入用例设计；缺 P0 停止；缺 P1 记录缺口继续；缺刷写/密钥类对应模块标 BLOCKED，不补造。

## 2. 测试需求文档（用户主诉）要素

测试需求决定**服务范围**，调查表提供**参数证据**；两者结合才能裁剪用例。收到需求时向用户确认以下要素：

| 要素 | 示例 |
|---|---|
| 被测软件/版本/分区 | BBS_P519 V436（APP） |
| 服务范围清单 | 0x10/0x11/0x22/0x2E/0x31/0x3E |
| 排除项 | 0x27 除外（标 BLOCKED） |
| 扩展范围 | 是否含 LIN 通信/网络安全/刷写 |
| 重点场景 | 0x10 会话切换矩阵、0x2E 未解锁拒绝 |
| 优先级取舍 | L1+L2 |
| 环境要求 | 台架 / 实车 / 通道 |
| 交付物 | 用例+脚本+HTML+错误日志 |

路由规则：有明确服务清单 → 按清单裁剪（只测清单内服务，缺失的做兼容性确认而非"不支持"结论）；无清单 → 按调查表全量兜底。

## 3. 实测经验（2026-08-19 BBS_P519_V436 固化）

1. **SWRS 优先于 System Requirement**：SWRS 带 REQ 编号（New/Updated/Deleted 清单），是需求追溯的权威源；System Requirement 是概览。体检应先扫 SWRS。
2. **DID 检查表价值被低估**：它含每 DID 真实抓帧（如 D03A「公钥未写入」→ `51 03 7F 22 22 FF FF FF`）与分层矩阵（D03A 在 PBL/SBL 返回 NRC31）。条件受限类 FAIL 判定全靠它，务必纳入输入并要求提供。
3. **功能寻址 NAD 从 LDF 取**：LDF 节点属性 `functional_id`（BBS=0x7E）是功能寻址 NAD 的权威来源，不要用 ISO 默认 0x7F 想当然；f1l1_uds 的 `NAD_FUNC=0x7E` 与 LDF 一致。
4. **0x27 密钥文档 ≠ 密钥值**：算法结构文档只能支撑 BLOCKED 依据；真实密钥值需主机厂/供应商提供（VolvoKey.json 或 SeedKey DLL）。
5. **刷写流程图与 LDF 是两回事**：LDF 管 LIN 通信定义，流程图管刷写步序/块大小/时序；缺后者刷写用例只能 BLOCKED。
6. **调查表解析器兼容性**：SDDB 表头行（`Identifier / DID Name / Total No. of bytes / Access Read/Write`）可能不被 `uds_survey_parser.py` 识别（find_header_row 需 `did+number/hex` 或 `did+name+r/w`）；遇解析异常改用 `sddb_extract.py` 适配（见 uds-diagnostic-test 交付物，其表头按空白归一化，兼容性更宽）。

## 4. 输入检查门禁（与技能流程衔接）

1. **Step 0 输入体检**（`srs_input_analyzer.py`，第一步必做）：输出章节/DID/诊断帧/外部引用 + 配套文件核对表 + 缺口清单 + 结论（true/partial/false）。
   - `false` → 停止，请用户补调查表/规范，不硬生成
   - `partial` → 缺口清单给用户，能补的补，不能补的标「待补」继续
2. **强制确认（阻断点）**（`uds-diagnostic-test` 2.5 节，生成脚本前）：can_config 缺 tx_id/rx_id/bitrate → 必须询问；`defaults_used` 非空 → 必须展示确认；`missing_attributes` 非空 → 必须告知。
3. **执行门禁**：硬件预检（进程占用/通道）→ 链路通探测 → 执行；无 Vector 走 F1L1（见 SKILL.md 路径选择）；两者皆无 → generate-only。

## 5. 输入文件包（Input Pack）规范 —— 可移植性

> 目标：把一次 UDS 测试任务所需的全部输入打包成**一个可搬运目录**，拷贝到其他机器/其他专家会话即可恢复全部输入上下文，避免"文件散落、换环境就丢"。

### 5.1 包结构

```
<项目>_输入文件包/
├── input_manifest.json      # 清单（模板：skills/input_manifest.example.json）
├── project_config.json      # 项目配置（项目身份 identity + 会话/NAD/安全等级/NRC/lint/生成维度）
├── survey/                  # P0：诊断调查表 + DID 检查表
├── lin/  |  can/            # LDF / LIN Matrix / DBC
├── srs/   swrs/             # SRS / SWRS（docx/pdf）
├── sec/                     # 安全需求清单 / 0x27 密钥文档
└── swdl/                    # 刷写流程图
```

### 5.2 project_config.json 的两层语义（2026-09-14 起）

技能代码内**不写任何项目字面量**，项目数据只活在配置里。配置分两层，互不掺杂：

| 层 | 位置 | 何时生效 |
|---|---|---|
| 结构性默认值 | 代码 `skills/project_config.py: DEFAULT_PROJECT_CONFIG` | 恒定，任何项目都继承（会话集合/安全等级/NRC/lint/生成维度） |
| **参考项目档** | 代码 `skills/project_config.py: REFERENCE_PROJECT_PROFILE`（**独立成段**） | **仅「未移植项目」时**读取：既没传 `--project-config`、包内也没有 `project_config.json` 时的兜底 |
| 项目配置 | 包内 `project_config.json`（或 CLI `--project-config <path>`） | **移植项目时**读取，覆盖参考档全部同名字段，改项目不改代码 |

项目身份字段（`identity`）：

```json
{
  "project": "YOUR_PROJECT",
  "identity": {
    "display_name": "报告抬头显示名",
    "run_id_prefix": "产物 run_id 前缀",
    "source_workbook": "只读来源工作簿名称（网络安全覆盖分析用）",
    "version_prefixes": ["短版本号要剥离的前缀"]
  }
}
```

- 未声明的字段回退**中性值**（展示名回退 `project`、`run_id_prefix` 回退 `UDS`、前缀回退空），**不会残留参考项目信息**。
- 样例：`skills/project_config.example.json`。

### 5.3 manifest 角色契约（与 §1 优先级总表对齐）

| 角色 role | 优先级 | 对应文件 |
|---|---|---|
| diag_survey / did_checklist / project_config | **P0** | 诊断调查表、DID 检查表、项目配置 |
| swrs / ldf / dbc | P1 | SWRS、LDF（LIN 节点）、DBC（CAN 节点） |
| srs / lin_matrix / security_key_doc | P2 | SRS、LIN Matrix、0x27 密钥文档 |
| flash_flowchart / security_req_list / cdd | P3 | 刷写流程图、安全清单、CDD |

- `path` 相对 manifest 所在目录；每项可带 `notes`
- **P1 相关性按总线过滤**：LIN 项目不要求 dbc，CAN 项目不要求 ldf/lin_matrix

### 5.4 一键校验

```powershell
& $vpy ".\srs-uds-testcase-designer\scripts\input_pack_validator.py" --pack "<包目录>"
```

- 输出 `pack_readiness.md/.json`：逐文件（存在/类型/哈希/深度体检）+ 模块级 READY/DEGRADED/BLOCKED + 下一步动作
- 退出码：0=READY / 1=PARTIAL（P1 缺，记录缺口继续）/ 2=NOT_READY（P0 缺，停止）
- 深度校验尽力而为（doc 类复用 srs_input_analyzer 体检、调查表调 uds_survey_parser、config 校验关键节点、LDF/DBC 特征嗅探），失败不阻断判定
- **哈希列用于搬运前后一致性核对**；换机器后重跑校验器即可恢复输入上下文

### 5.5 内容级检查（2026-09-04 真实项目包实测沉淀）

**文件在 ≠ 内容在**，存在性检查之外还有两类内容级降级：

1. **0x27 密钥文档内容级检查（security_key_doc）**：
   - 提取 docx/pdf/txt/json/xlsx 全文（docx 含表格），查实际密钥材料（≥8 字节 hex / key=value 定义）
   - **有算法流程+密钥名（如 AES_ctr_key_0102）但无密钥字节 → 0x27 仍 BLOCKED**，next_action 提示向客户/软件组索要密钥
   - 实测案例：BBS 项目 `27SecurityAccess秘钥.docx` 全文 0 个密钥字节（流程完整、密钥名齐全）；同目录 `VolvoKey.json` 是 RSA 公钥（非对称，0x29 用），**不等于 0x27 AES 对称密钥**，不能互相顶替
2. **正式项目资料形态 → 角色映射**（真实输入长什么样，不是理想化目录）：
   - `诊断相关文档/` → swrs（NOTE-SWRS-xxx.docx）+ diag_survey×3（SDDB_APP/PBL/SBL_diagnostic.xlsx，**同角色多文件合法**）
   - `通信矩阵/` → did_checklist（DID检查_xxx.xlsx）+ lin_matrix（LIN_Matrix_xxx.xlsx）
   - `系统功能需求文档/` → srs（System Requirement_xxx.docx）；散落根目录/相邻目录 → security_key_doc、ldf（GPAsystem_MAIN_xxx_BBS1LIN_SPA3.ldf）
   - 拿到正式资料先按此映射写 manifest（绝对路径直接引用原位文件亦可，交接时再拷贝收拢为相对路径包）

### 5.6 校验器自身的测试陷阱

- **假字节测试掩盖路径 bug**：单测用 `b"dummy"` 当 xlsx → 解析失败被"不阻断"吞掉，`_import_from` 的模块路径错了也全绿；必须有一个"真文件跑到解析器"的回归测试（test_survey_deep_check_reaches_parser）
- 跨技能 import 用 `os.path.join(here, "..", "..", "<兄弟技能>", "scripts", ...)`——`here` 是 `<技能>/scripts`，**兄弟技能要两级上跳**（一级上跳是 2026-09-04 真实包实测踩中的 bug）
