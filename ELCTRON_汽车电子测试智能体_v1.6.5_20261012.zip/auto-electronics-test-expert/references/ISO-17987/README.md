# ISO 17987 参考分支（LIN）

本分支承接 LIN 的链路、物理、节点配置、传输和诊断任务。现有工具专项资料仍保留在
skills/uds-diagnostic-test/references/，本目录负责把它们按 ISO 17987 分工重新组织，
避免 LIN 资料只以“UDS-over-LIN”形式出现。

## 任务到资产

| 任务 | 首选速查 | 追加资产 |
|---|---|---|
| LIN 帧、PID、校验和、帧类型 | ISO17987-3_协议与帧速查.md | lin-protocol-cheatsheet.md |
| LIN 电平、供电、波特率、唤醒 | ISO17987-4_电气物理层速查.md | lin-test-methodology.md |
| NAD、节点配置、产品 ID、帧 ID | ISO17987-6_节点配置与识别速查.md | 项目 LDF / LIN Matrix |
| LIN TP、0x3C/0x3D、UDS-over-LIN | ISO17987-7_传输层与诊断速查.md | f1l1-lin-uds.md + 14229 应用层速查 |
| LIN 回归/一致性/错误注入 | ISO17987-8_一致性测试速查.md | lin-test-methodology.md |

## 与 ISO 14229 的边界

- ISO 17987-7 负责 LIN 传输协议、诊断服务、NAD、MRF/SRF、PCI、多帧和传输时序。
- ISO 17987-8 负责一致性测试组织和判定入口。
- UDS-over-LIN 任务采用 ISO-17987 为主、ISO-14229 为应用层伴随分支；纯 LIN
  帧/调度任务不加载整套 UDS 服务表。

## 项目数据优先级

LDF / LIN Matrix / CDD / SWRS 优先于本分支的通用速查。特别是 configured_NAD、
functional_id、波特率、帧长度、调度表、P2/STmin 和诊断服务白名单，缺失时标注待确认，
不使用示例值代替。

## ISO 17987 分册映射（本包只覆盖测试最常用部分）

| 分册 | 本包入口 |
|---|---|
| -3 Protocol specification | ISO17987-3_协议与帧速查.md |
| -4 Electrical physical layer | ISO17987-4_电气物理层速查.md |
| -6 Node configuration and identification | ISO17987-6_节点配置与识别速查.md |
| -7 Transport protocol and diagnostic services | ISO17987-7_传输层与诊断速查.md |
| -8 Conformance test specification | ISO17987-8_一致性测试速查.md |

原文标准不随专家包分发；本目录是测试工程师速查和路由入口，不替代条款级证据。
