"""Regression tests for the deterministic automotive intake fact packet."""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from unittest.mock import patch

from runtime.orchestrator.input_context import build_automotive_input_context, normalize_input_role, resolve_input_source
from runtime.orchestrator.hashchain import digest_file


class AutomotiveInputContextTests(unittest.TestCase):
    @patch("runtime.orchestrator.input_context.os.path.realpath")
    def test_source_resolution_rejects_link_escape_after_mount(self, realpath):
        def resolve(path):
            return "C:/outside/secret.srs" if "linked.srs" in path else path

        realpath.side_effect = resolve
        with self.assertRaisesRegex(ValueError, "outside input root"):
            resolve_input_source("C:/controlled-input", "linked.srs")

    def test_modified_source_during_parse_does_not_create_facts(self):
        with tempfile.TemporaryDirectory() as root:
            source = os.path.join(root, "requirements.txt")
            with open(source, "w", encoding="utf-8") as handle:
                handle.write("REQ-UDS-001 initial")
            expected = digest_file(source)
            def mutate(_role, _source, **_kwargs):
                with open(source, "w", encoding="utf-8") as handle:
                    handle.write("REQ-UDS-999 replaced")
                return {"discovered": {"requirement_ids": ["REQ-UDS-999"]}}
            with patch("runtime.orchestrator.input_context._run_parser", side_effect=mutate):
                packet = build_automotive_input_context(root, [{"role": "srs", "path": "requirements.txt",
                                                               "sha256": expected, "bytes": os.path.getsize(source)}])
            self.assertEqual(packet["facts"], [])
            self.assertEqual(packet["parse_issues"][0]["code"], "parser_failed")

    def test_role_aliases_are_canonical_and_unknown_roles_are_rejected(self):
        self.assertEqual(normalize_input_role("sa-key"), "security_key_ref")
        self.assertEqual(normalize_input_role("requirement"), "srs")
        with self.assertRaisesRegex(ValueError, "unsupported input role"):
            normalize_input_role("arbitrary_upload")

    @patch("runtime.orchestrator.input_context.digest_file")
    @patch("runtime.orchestrator.input_context._run_parser")
    def test_fact_packet_has_parser_facts_but_no_paths_or_key_material(self, run_parser, digest):
        digest.side_effect = lambda source: {"vehicle_requirements.txt": "a", "network.dbc": "b", "lin.ldf": "c"}[os.path.basename(source)] * 64
        run_parser.side_effect = [
            {"discovered": {"dids": ["F190"], "services": [{"sid": "0x22"}],
                            "requirement_ids": ["REQ-UDS-001"]},
             "gaps": [], "verdict": {"can_generate": True}},
            {"nodes": ["ECU"], "messages": [{"name": "DiagReq", "signals": ["SID"]}]},
            {"lin_protocol_version": "2.2", "lin_speed_bps": 19200,
             "master": {"name": "Master"}, "slaves": ["ECU"],
             "frames": [{"frame_type": "diagnostic"}], "signals": ["NAD"], "warnings": []},
        ]
        entries = [
            {"role": "srs", "path": "vehicle_requirements.txt", "sha256": "a" * 64, "bytes": 7},
            {"role": "dbc", "path": "network.dbc", "sha256": "b" * 64, "bytes": 7},
            {"role": "ldf", "path": "lin.ldf", "sha256": "c" * 64, "bytes": 7},
            {"role": "security_key_ref", "path": "unlock.json", "sha256": "d" * 64, "bytes": 7},
        ]
        context = build_automotive_input_context("C:/trusted-input", entries)

        encoded = json.dumps(context, ensure_ascii=False)
        self.assertEqual(len(context["facts"]), 3)
        self.assertEqual(context["facts"][0]["summary"]["did_samples"], ["F190"])
        self.assertEqual(context["facts"][0]["summary"]["requirement_ids"], ["REQ-UDS-001"])
        self.assertEqual(context["secure_key_references"][0]["usage"], "runtime_executor_only")
        self.assertTrue(context["secure_key_references"][0]["material_in_context"] is False)
        self.assertNotIn("vehicle_requirements.txt", encoded)
        self.assertNotIn("unlock.json", encoded)
        self.assertTrue(context["model_context_exported"])
        self.assertEqual(context["model_context_policy"], "approved_sanitized_facts_only")


if __name__ == "__main__":
    unittest.main()
