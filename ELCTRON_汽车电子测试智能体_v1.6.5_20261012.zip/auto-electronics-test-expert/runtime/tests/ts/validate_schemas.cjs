/*
 * 用真实 zod 跑一遍契约样例，验证生成的 TS 类型「不只是生成了，而且是对的」。
 *
 * 用法：
 *   node validate_schemas.cjs <编译输出目录> <schema_examples.json>
 *
 * 三类断言：
 *   1. 每个契约 id 都能在 contractSchemas 里找到；
 *   2. 该契约的**每个样例都能通过 safeParse**（正向）；
 *   3. 样例**加一个未知字段必须被拒**、**删一个字段必须被拒**（负向）。
 *
 * 第 3 类是本校验器的要点：只做正向检查的话，一个 `z.any()` 也能全绿。
 */
"use strict";

const path = require("path");
const fs = require("fs");

const [compiledDir, examplesPath] = process.argv.slice(2);
if (!compiledDir || !examplesPath) {
  console.error("用法: node validate_schemas.cjs <编译输出目录> <schema_examples.json>");
  process.exit(2);
}

const mod = require(path.resolve(compiledDir, "schema_types.js"));
const { contractSchemas } = mod;

const payload = JSON.parse(fs.readFileSync(examplesPath, "utf8"));
const contracts = payload.contracts || {};

let checks = 0;
const failures = [];

function fail(what, detail) {
  failures.push(`${what}: ${detail}`);
}

// ---- 1. 索引完整性 ----
for (const id of Object.keys(contracts)) {
  if (!contractSchemas[id]) {
    fail(id, "contractSchemas 里找不到该契约");
  }
}
console.log(`  契约索引: ${Object.keys(contractSchemas).length} 个 id`);
console.log(`  含样例契约: ${Object.keys(contracts).length} 个`);

// ---- 2. 正向：样例必须通过，且必填项必须都在样例里 ----
for (const [id, info] of Object.entries(contracts)) {
  const schema = contractSchemas[id];
  if (!schema) continue;
  const samples = info.examples || [];
  const required = info.required || [];
  samples.forEach((sample, i) => {
    checks += 1;
    const r = schema.safeParse(sample);
    if (!r.success) {
      const issues = r.error.issues
        .slice(0, 3)
        .map((x) => `${x.path.join(".") || "<root>"} ${x.message}`)
        .join(" ; ");
      fail(`${id}#${i}`, `样例未通过 safeParse -> ${issues}`);
    }
    // 样例自身必须满足 schema 的 required —— 否则样例已经和契约脱节
    const missing = required.filter((k) => !(k in sample));
    if (missing.length) {
      fail(`${id}#${i}`, `样例缺少契约声明的必填项: ${missing.join(", ")}`);
    }
  });
}

// ---- 3. 负向：必须拒绝对不合法输入 ----
for (const [id, info] of Object.entries(contracts)) {
  const schema = contractSchemas[id];
  const samples = info.examples || [];
  if (!schema || !samples.length) continue;
  const sample = samples[0];

  checks += 1;
  if (schema.safeParse({ ...sample, __unexpected_field__: 1 }).success) {
    fail(id, "多一个未知字段竟然通过了（strictObject 失效）");
  }

  // 按契约声明的 required 删，不能靠「样例的第一个键」猜
  const victim = (info.required || []).find((k) => k in sample);
  if (!victim) {
    fail(id, "找不到可删的必填项，负向检查无法成立");
  } else {
    checks += 1;
    const missing = { ...sample };
    delete missing[victim];
    if (schema.safeParse(missing).success) {
      fail(id, `删掉必填字段 ${victim} 竟然通过了`);
    }
  }
}

console.log(`  实跑断言: ${checks} 条`);
if (failures.length) {
  console.log(`  失败: ${failures.length}`);
  for (const f of failures.slice(0, 20)) {
    console.log(`    * ${f}`);
  }
  process.exit(1);
}
console.log("  结果: 全部通过");
process.exit(0);
