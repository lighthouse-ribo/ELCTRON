#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T3.1–T3.7 执行器层回归测试。

不碰真硬件。设备 I/O 与探针全部注入，被测的是**编排与留证**：
  * 通道拿不到租约就不许往下走；
  * 预检未知即失败，绝不放行；
  * 最小复测非 PASS 一律阻断全量；
  * 异常必须封存成 ABORTED 并留证；
  * 任何路径下租约都要还回去。
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest
from datetime import timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.executor import asc_session as asc_mod  # noqa: E402
from runtime.executor import manifest as manifest_mod  # noqa: E402
from runtime.executor import preflight as pf  # noqa: E402
from runtime.executor import runner as runner_mod  # noqa: E402
from runtime.executor.lease import (  # noqa: E402
    ChannelBusy,
    ChannelLeaseManager,
    LeaseError,
)
from runtime.orchestrator import approval as A  # noqa: E402
from runtime.orchestrator.state import (  # noqa: E402
    AgentRole,
    GateStatus,
    RunFinalVerdict,
)

RUN_ID = "RUN-EXEC-001"
CHANNEL = "LIN1"
REF = "credential://aetex/read-only-did"


def make_token(*, actions=("execute", "0x10", "0x22"), expired=False, run_id=RUN_ID):
    """构造一个默认有效的审批令牌。"""
    now = A.now_utc()
    return A.issue(token_id="TOK-1", order_id="ORD-1", run_id=run_id, actions=list(actions),
                   valid_from=now - timedelta(hours=2 if expired else 0, minutes=5),
                   valid_until=now - timedelta(minutes=1) if expired else now + timedelta(minutes=55),
                   approved_by=AgentRole.HUMAN_APPROVER, credential_ref=REF)


def make_order(**over):
    """构造一个最小 ApprovedOrder。"""
    base = {
        "schema_version": "approved-order/v0.1",
        "order_id": "ORD-1", "run_id": RUN_ID, "flow": "basic_uds",
        "scope": {"services": ["0x10", "0x22"], "partitions": ["shared"]},
        "risk_level": "LOW", "plan_sha256": "d" * 64,
        "approval_token_ref": REF, "approval_status": "approved",
        "valid_from": "2026-09-15T06:00:00Z", "valid_until": "2026-09-15T09:00:00Z",
        "issued_by": "terra", "reversible": True, "minimal_retest_required": True,
    }
    base.update(over)
    return base


def _rewrite_lease(path: str, **changes) -> None:
    """把租约文件改成指定内容（用于模拟过期/被接管）。"""
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    data.update(changes)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False)


class FakeDevice:
    """假设备驱动：写真实时间戳的帧进 ASC，返回预设判决。"""

    def __init__(self, *, verdicts=None, default="PASS", raise_on=None, frames=2):
        self.calls: list[str] = []
        self.verdicts = dict(verdicts or {})
        self.default = default
        self.raise_on = set(raise_on or ())
        self.frames = frames
        self._t = 1000.0

    def __call__(self, case_id, session):
        self.calls.append(case_id)
        if case_id in self.raise_on:
            raise RuntimeError(f"模拟链路中断 @ {case_id}")
        for i in range(self.frames):
            self._t += 0.001
            session.record(self._t, "tx" if i % 2 == 0 else "rx", 0x3C, [0x22, 0xA0, 0x01])
        verdict = self.verdicts.get(case_id, self.default)
        return runner_mod.CaseResult(case_id=case_id, verdict=verdict,
                                     failure_class="NONE" if verdict == "PASS" else "ECU_FAIL")


class TempRun(unittest.TestCase):
    def setUp(self) -> None:
        self.run_dir = tempfile.mkdtemp(prefix="aetex-exec-")
        self.lease_dir = tempfile.mkdtemp(prefix="aetex-lease-")
        self.addCleanup(shutil.rmtree, self.run_dir, True)
        self.addCleanup(shutil.rmtree, self.lease_dir, True)

    def manager(self, **kw):
        return ChannelLeaseManager(self.lease_dir, **kw)

    def executor(self, device, *, probes=None, min_free=pf.DEFAULT_MIN_FREE_BYTES,
                 ttl=1800):
        config = pf.PreflightConfig(adapter="xcdevlay", channels=(CHANNEL,),
                                    min_free_bytes=min_free)
        preflight = pf.Preflight(config, probes or pf.SimulatedProbes(free_bytes=min_free * 4))
        return runner_mod.ControlledExecutor(
            run_dir=self.run_dir, lease_manager=self.manager(ttl_seconds=ttl),
            preflight=preflight, device_runner=device)

    def request(self, **over):
        base = dict(run_id=RUN_ID, flow="basic_uds", channel=CHANNEL, order=make_order(),
                    cases=("TC-1", "TC-2", "TC-3"), token=make_token(), minimal_case="TC-1",
                    device={"adapter": "xcdevlay", "channel": CHANNEL,
                            "driver_version": "1.3.8", "hardware_type": "CANVIEX_F1L1",
                            "transceiver_power": True})
        base.update(over)
        return runner_mod.ExecutionRequest(**base)


# --------------------------------------------------------------------------- #
class LeaseTest(TempRun):
    def test_acquire_then_release(self) -> None:
        m = self.manager()
        lease = m.acquire(CHANNEL, holder="run-1")
        self.assertEqual(lease.channel, CHANNEL)
        self.assertIsNotNone(m.current(CHANNEL))
        self.assertTrue(m.release(lease))
        self.assertIsNone(m.current(CHANNEL))

    def test_second_acquire_is_blocked(self) -> None:
        m = self.manager()
        first = m.acquire(CHANNEL, holder="run-1")
        with self.assertRaises(ChannelBusy) as ctx:
            m.acquire(CHANNEL, holder="run-2")
        self.assertEqual(ctx.exception.holder, "run-1")
        m.release(first)

    def test_expired_lease_can_be_reclaimed(self) -> None:
        m = self.manager(ttl_seconds=30)
        first = m.acquire(CHANNEL, holder="run-1")
        # 把租约改成已过期
        _rewrite_lease(m.path_for(CHANNEL), expires_at="2000-01-01T00:00:00Z")
        second = m.acquire(CHANNEL, holder="run-2")
        self.assertNotEqual(second.lease_id, first.lease_id)

    def test_renew_by_owner(self) -> None:
        m = self.manager()
        lease = m.acquire(CHANNEL, holder="run-1")
        renewed = m.renew(lease)
        self.assertEqual(renewed.lease_id, lease.lease_id)
        self.assertGreaterEqual(renewed.expires_at, lease.expires_at)

    def test_renew_by_non_owner_fails(self) -> None:
        m = self.manager()
        lease = m.acquire(CHANNEL, holder="run-1")
        other = m.acquire  # noqa: F841  (语义：另一持有者)
        _rewrite_lease(m.path_for(CHANNEL), lease_id="deadbeef")
        with self.assertRaises(LeaseError):
            m.renew(lease)

    def test_release_by_non_owner_is_refused(self) -> None:
        m = self.manager()
        lease = m.acquire(CHANNEL, holder="run-1")
        _rewrite_lease(m.path_for(CHANNEL), lease_id="other-lease")
        self.assertFalse(m.release(lease), "不得删除别人的租约")
        self.assertIsNotNone(m.current(CHANNEL))

    def test_invalid_channel_name_rejected(self) -> None:
        m = self.manager()
        for bad in ("../escape", "a/b", "", "x" * 40, "bad name"):
            with self.subTest(channel=bad):
                with self.assertRaises(LeaseError):
                    m.acquire(bad, holder="run-1")

    def test_reclaim_stale(self) -> None:
        m = self.manager()
        lease = m.acquire(CHANNEL, holder="run-1")
        _rewrite_lease(m.path_for(CHANNEL), expires_at="2000-01-01T00:00:00Z")
        self.assertEqual(m.reclaim_stale(), [CHANNEL])
        self.assertIsNone(m.current(CHANNEL))
        self.assertTrue(lease.lease_id)

    def test_snapshot_reports_status(self) -> None:
        m = self.manager()
        m.acquire(CHANNEL, holder="run-1")
        snap = m.snapshot()
        self.assertEqual(len(snap), 1)
        self.assertEqual(snap[0]["status"], "active")

    def test_ttl_floor(self) -> None:
        with self.assertRaises(LeaseError):
            ChannelLeaseManager(self.lease_dir, ttl_seconds=5)


class PreflightTest(TempRun):
    def _run(self, probes):
        config = pf.PreflightConfig(adapter="xcdevlay", channels=(CHANNEL,))
        return pf.Preflight(config, probes).run(self.run_dir, CHANNEL)

    def test_all_green_passes(self) -> None:
        report = self._run(pf.SimulatedProbes())
        self.assertTrue(report.passed)
        self.assertIs(report.status, GateStatus.PASS)

    def test_probe_provenance_is_recorded(self) -> None:
        report = self._run(pf.SimulatedProbes())
        self.assertIn("simulated", report.probe_provenance)

    def test_occupying_process_blocks(self) -> None:
        report = self._run(pf.SimulatedProbes(processes=("VickCAN",)))
        self.assertFalse(report.passed)
        self.assertIs(report.status, GateStatus.BLOCKED)
        self.assertIn("no_occupying_process", [c.name for c in report.failures])

    def test_unknown_device_blocks(self) -> None:
        """探测结果是"未知"时按失败处理，绝不放行。"""
        report = self._run(pf.SimulatedProbes(device=None))
        self.assertIs(report.status, GateStatus.BLOCKED)
        detail = [c for c in report.checks if c.name == "device_present"][0].detail
        self.assertIn("未知", detail)

    def test_device_absent_blocks(self) -> None:
        report = self._run(pf.SimulatedProbes(device=False))
        self.assertIs(report.status, GateStatus.BLOCKED)

    def test_low_disk_blocks(self) -> None:
        report = self._run(pf.SimulatedProbes(free_bytes=1024))
        self.assertIs(report.status, GateStatus.BLOCKED)
        self.assertIn("disk_space", [c.name for c in report.failures])

    def test_probe_exception_maps_to_error(self) -> None:
        class Boom(pf.SimulatedProbes):
            def occupied_processes(self):
                raise OSError("tasklist 不可用")

        report = self._run(Boom())
        self.assertIs(report.status, GateStatus.ERROR)

    def test_error_takes_precedence_over_blocked(self) -> None:
        config = pf.PreflightConfig(adapter="xcdevlay", channels=("OTHER",))
        probes = pf.SimulatedProbes(processes=("CANoe64",))
        report = pf.Preflight(config, probes).run(self.run_dir, CHANNEL)
        self.assertIs(report.status, GateStatus.ERROR, "通道不在白名单（ERROR）优先级高于占用（BLOCKED）")

    def test_config_hash_mismatch_is_error(self) -> None:
        config = pf.PreflightConfig(adapter="xcdevlay", channels=(CHANNEL,),
                                    expected_config_sha256="a" * 64)
        report = pf.Preflight(config, pf.SimulatedProbes(config_sha256="b" * 64)).run(self.run_dir, CHANNEL)
        self.assertIs(report.status, GateStatus.ERROR)

    def test_config_hash_skipped_is_not_a_pass_claim(self) -> None:
        report = self._run(pf.SimulatedProbes())
        check = [c for c in report.checks if c.name == "config_hash"][0]
        self.assertTrue(check.ok)
        self.assertFalse(check.blocking)
        self.assertIn("未校验", check.detail)

    def test_report_serialisable(self) -> None:
        payload = self._run(pf.SimulatedProbes()).to_dict()
        json.dumps(payload)          # 不应抛


class AscSessionTest(TempRun):
    def _session(self, **kw):
        s = asc_mod.AscSession(self.run_dir, run_id=RUN_ID, channel=CHANNEL, **kw)
        s.open()
        return s

    def test_record_and_seal_produces_captures(self) -> None:
        s = self._session()
        s.record(1000.0, "tx", 0x3C, [0x22, 0xA0, 0x01])
        s.record(1000.5, "rx", 0x3D, [0x62, 0xA0, 0x01])
        sealed = s.seal()
        self.assertEqual(len(sealed["captures"]), 1)
        cap = sealed["captures"][0]
        self.assertEqual(cap["kind"], "asc")
        self.assertTrue(cap["path"].startswith("03_execution/"))
        self.assertEqual(len(cap["sha256"]), 64)
        self.assertEqual(cap["frame_count"], 2)
        self.assertGreater(cap["bytes"], 0)

    def test_rejects_missing_timestamp(self) -> None:
        """不允许补造时间戳 —— 这是本项目证据链的底线。"""
        s = self._session()
        with self.assertRaises(asc_mod.AscSessionError):
            s.record(None, "tx", 0x3C, [0x22])

    def test_rejects_bad_direction(self) -> None:
        s = self._session()
        with self.assertRaises(asc_mod.AscSessionError):
            s.record(1000.0, "sideways", 0x3C, [0x22])

    def test_rejects_record_before_open(self) -> None:
        s = asc_mod.AscSession(self.run_dir, run_id=RUN_ID, channel=CHANNEL)
        with self.assertRaises(asc_mod.AscSessionError):
            s.record(1000.0, "tx", 0x3C, [0x22])

    def test_abort_seals_with_reason(self) -> None:
        s = self._session()
        s.record(1000.0, "tx", 0x3C, [0x22])
        sealed = s.abort("链路中断")
        self.assertTrue(sealed["aborted"])
        self.assertEqual(sealed["reason"], "链路中断")
        self.assertEqual(len(sealed["captures"]), 1)

    def test_seal_is_idempotent(self) -> None:
        s = self._session()
        s.record(1000.0, "tx", 0x3C, [0x22])
        first = s.seal()
        second = s.seal()
        self.assertEqual(first, second)

    def test_record_after_seal_rejected(self) -> None:
        s = self._session()
        s.record(1000.0, "tx", 0x3C, [0x22])
        s.seal()
        with self.assertRaises(asc_mod.AscSessionError):
            s.record(1001.0, "rx", 0x3D, [0x62])

    def test_reuses_existing_recorder(self) -> None:
        """必须复用既有 LiveAscRecorder，不另写一份实现。"""
        cls = asc_mod.load_recorder()
        self.assertEqual(cls.__module__, "asc_evidence")
        self.assertEqual(cls.__name__, "LiveAscRecorder")


class ManifestTest(TempRun):
    def _manifest(self, **over):
        base = dict(run_id=RUN_ID, flow="basic_uds",
                    device={"adapter": "xcdevlay", "channel": CHANNEL},
                    started_at=A.now_utc(), status="CAPTURED",
                    order_refs=[{"order_id": "ORD-1", "plan_sha256": "d" * 64}],
                    captures=[{"kind": "asc", "path": "03_execution/traces/a.asc",
                               "sha256": "a" * 64, "bytes": 100}])
        base.update(over)
        return manifest_mod.build_run_manifest(**base)

    def test_valid_manifest_builds(self) -> None:
        m = self._manifest()
        self.assertEqual(m["schema_version"], "run-manifest/v0.1")

    def test_invalid_status_rejected(self) -> None:
        with self.assertRaises(manifest_mod.ManifestInvalid):
            self._manifest(status="DONE")

    def test_write_and_read_round_trip(self) -> None:
        m = self._manifest()
        rel = manifest_mod.write_manifest(self.run_dir, m)
        self.assertEqual(rel, "03_execution/run_manifest.json")
        self.assertEqual(manifest_mod.read_manifest(self.run_dir), m)

    def test_read_missing_raises(self) -> None:
        with self.assertRaises(FileNotFoundError):
            manifest_mod.read_manifest(self.run_dir)


class ControlledExecutorTest(TempRun):
    def test_happy_path_captured(self) -> None:
        device = FakeDevice()
        out = self.executor(device).execute(self.request())

        self.assertIs(out.gate_status, GateStatus.PASS)
        self.assertIs(out.run_final_verdict, RunFinalVerdict.PASS)
        # 最小复测先跑 TC-1；全量跑完整用例集时 TC-1 会再跑一次 —— 这是有意的：
        # 最小复测证明链路可用，全量则是完整证据集，两者不共用同一份结果。
        self.assertEqual(device.calls, ["TC-1", "TC-1", "TC-2", "TC-3"])
        self.assertTrue(os.path.isfile(os.path.join(self.run_dir, "03_execution", "run_manifest.json")))
        self.assertEqual(out.manifest["status"], "CAPTURED")

    def test_lease_released_after_success(self) -> None:
        self.executor(FakeDevice()).execute(self.request())
        self.assertIsNone(self.manager().current(CHANNEL), "租约必须归还")

    def test_lease_released_after_failure(self) -> None:
        device = FakeDevice(raise_on={"TC-3"})
        self.executor(device).execute(self.request())
        self.assertIsNone(self.manager().current(CHANNEL))

    def test_channel_busy_blocks_when_lease_held(self) -> None:
        holder = self.manager().acquire(CHANNEL, holder="other-run")
        try:
            device = FakeDevice()
            out = self.executor(device).execute(self.request())
            self.assertIs(out.gate_status, GateStatus.BLOCKED)
            self.assertIn("通道被占用", out.blocked_reason)
            self.assertEqual(device.calls, [], "拿不到租约不该碰设备")
        finally:
            self.manager().release(holder)

    def test_preflight_failure_blocks(self) -> None:
        device = FakeDevice()
        probes = pf.SimulatedProbes(processes=("VickCAN",))
        out = self.executor(device, probes=probes).execute(self.request())
        self.assertIs(out.gate_status, GateStatus.BLOCKED)
        self.assertEqual(device.calls, [])
        self.assertIsNone(self.manager().current(CHANNEL))

    def test_missing_token_blocks(self) -> None:
        device = FakeDevice()
        out = self.executor(device).execute(self.request(token=None))
        self.assertIs(out.gate_status, GateStatus.BLOCKED)
        self.assertIn("审批校验未通过", out.blocked_reason)
        self.assertEqual(device.calls, [])

    def test_expired_token_raises_and_releases_lease(self) -> None:
        device = FakeDevice()
        with self.assertRaises(A.ApprovalError):
            self.executor(device).execute(self.request(token=make_token(expired=True)))
        self.assertIsNone(self.manager().current(CHANNEL))

    def test_minimal_retest_failure_blocks_full_run(self) -> None:
        """核心断言：最小复测非 PASS，全量一条都不许跑。"""
        device = FakeDevice(verdicts={"TC-1": "FAIL"})
        out = self.executor(device).execute(self.request())

        self.assertIs(out.gate_status, GateStatus.REVIEW_REQUIRED)
        self.assertEqual(device.calls, ["TC-1"], "只跑了最小复测，不该跑全量")
        self.assertTrue(out.aborted)
        self.assertEqual(out.manifest["status"], "ABORTED")
        self.assertIn("最小复测未通过", out.manifest["abort_reason"])

    def test_minimal_retest_blocked_also_blocks(self) -> None:
        device = FakeDevice(verdicts={"TC-1": "BLOCKED"})
        out = self.executor(device).execute(self.request())
        self.assertIs(out.gate_status, GateStatus.REVIEW_REQUIRED)
        self.assertEqual(device.calls, ["TC-1"])

    def test_execution_exception_is_sealed_as_aborted(self) -> None:
        device = FakeDevice(raise_on={"TC-3"})
        out = self.executor(device).execute(self.request())

        self.assertIs(out.gate_status, GateStatus.ABORTED)
        self.assertTrue(out.aborted)
        self.assertEqual(out.manifest["status"], "ABORTED")
        self.assertIn("执行异常已封存", out.blocked_reason)
        self.assertEqual(out.manifest["status"], "ABORTED")

    def test_aborted_run_still_keeps_asc_evidence(self) -> None:
        device = FakeDevice(raise_on={"TC-3"})
        out = self.executor(device).execute(self.request())
        captures = out.manifest.get("captures", [])
        self.assertTrue(captures, "ABORTED 也必须留下已落盘证据")
        for cap in captures:
            self.assertTrue(os.path.isfile(os.path.join(self.run_dir, *cap["path"].split("/"))))

    def test_no_frames_yields_inconclusive(self) -> None:
        """一条帧都没抓到 -> 证据不完整 -> 只能是 INCONCLUSIVE，不能是 PASS。"""
        device = FakeDevice(frames=0)
        out = self.executor(device).execute(self.request())
        self.assertIsNot(out.run_final_verdict, RunFinalVerdict.PASS)
        self.assertIs(out.gate_status, GateStatus.INCONCLUSIVE)

    def test_fail_case_yields_fail_verdict(self) -> None:
        device = FakeDevice(verdicts={"TC-2": "FAIL"})
        out = self.executor(device).execute(self.request())
        self.assertIs(out.run_final_verdict, RunFinalVerdict.FAIL)

    def test_evidence_chain_verifies(self) -> None:
        device = FakeDevice()
        ex = self.executor(device)
        out = ex.execute(self.request())
        self.assertEqual(ex.verify_evidence_chain(out.manifest), [])

    def test_manifest_carries_lease_and_environment(self) -> None:
        out = self.executor(FakeDevice()).execute(self.request())
        self.assertIn("channel_lease", out.manifest)
        self.assertEqual(out.manifest["channel_lease"]["lease_id"], out.lease_id)
        self.assertIn("occupying_processes_checked", out.manifest["environment"])

    def test_manifest_has_no_secret_material(self) -> None:
        out = self.executor(FakeDevice()).execute(self.request())
        text = json.dumps(out.manifest, ensure_ascii=False).lower()
        for banned in ("private key", "password", "secret"):
            self.assertNotIn(banned, text)

    def test_outcome_serialisable(self) -> None:
        out = self.executor(FakeDevice()).execute(self.request())
        json.dumps(out.to_dict(), ensure_ascii=False)


if __name__ == "__main__":
    unittest.main(verbosity=2)
