#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.7 哈希链回归测试。

重点覆盖**篡改与伪造**场景：改文件、改记录、引用不存在的上游、构造环。
一个只在正常数据上验证过的哈希链，等于没有哈希链。
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.orchestrator import hashchain as H  # noqa: E402
from runtime.orchestrator.acl import AclViolation  # noqa: E402


class TempRun(unittest.TestCase):
    def setUp(self) -> None:
        self.run_dir = tempfile.mkdtemp(prefix="aetex-run-")
        for d in ("02_plan", "03_execution", "04_evidence", "05_final"):
            os.makedirs(os.path.join(self.run_dir, d), exist_ok=True)

    def tearDown(self) -> None:
        shutil.rmtree(self.run_dir, ignore_errors=True)

    def write(self, rel: str, text: str) -> str:
        full = os.path.join(self.run_dir, *rel.split("/"))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(text)
        return full


class DigestTest(TempRun):
    def test_digest_is_deterministic(self) -> None:
        self.assertEqual(H.digest_bytes(b"abc"), H.digest_bytes(b"abc"))
        self.assertNotEqual(H.digest_bytes(b"abc"), H.digest_bytes(b"abd"))

    def test_digest_file_matches_bytes(self) -> None:
        full = self.write("02_plan/a.json", "hello")
        self.assertEqual(H.digest_file(full), H.digest_bytes(b"hello"))

    def test_is_digest(self) -> None:
        self.assertTrue(H.is_digest("a" * 64))
        self.assertFalse(H.is_digest("A" * 64))       # 大写不算
        self.assertFalse(H.is_digest("a" * 63))
        self.assertFalse(H.is_digest(None))

    def test_record_for_rejects_unsafe_path(self) -> None:
        with self.assertRaises(AclViolation):
            H.record_for(self.run_dir, "../x.json")

    def test_record_for_missing_file(self) -> None:
        with self.assertRaises(FileNotFoundError):
            H.record_for(self.run_dir, "02_plan/nope.json")


class ChainRootTest(TempRun):
    def _chain(self):
        self.write("02_plan/plan.json", "PLAN")
        self.write("02_plan/gate.json", "GATE")
        p = H.record_for(self.run_dir, "02_plan/plan.json", kind="draft_plan")
        g = H.record_for(self.run_dir, "02_plan/gate.json", inputs=[p.sha256], kind="gate")
        return p, g

    def test_root_is_order_independent(self) -> None:
        p, g = self._chain()
        self.assertEqual(H.chain_root([p, g]), H.chain_root([g, p]))

    def test_chain_verifies(self) -> None:
        p, g = self._chain()
        self.assertEqual(H.verify([p, g], run_dir=self.run_dir), [])
        self.assertEqual(H.assert_chain([p, g], run_dir=self.run_dir), H.chain_root([p, g]))

    def test_root_changes_when_artifact_changes(self) -> None:
        p, g = self._chain()
        before = H.chain_root([p, g])
        self.write("02_plan/plan.json", "PLAN-v2")
        p2 = H.record_for(self.run_dir, "02_plan/plan.json", kind="draft_plan")
        self.assertNotEqual(H.chain_root([p2, g]), before)

    def test_root_changes_when_inputs_change(self) -> None:
        p, g = self._chain()
        before = H.chain_root([p, g])
        g2 = H.ArtifactRecord(path=g.path, sha256=g.sha256, inputs=(), size=g.size, kind=g.kind)
        self.assertNotEqual(H.chain_root([p, g2]), before)

    def test_empty_chain_root_is_stable(self) -> None:
        self.assertEqual(H.chain_root([]), H.chain_root([]))


class TamperDetectionTest(TempRun):
    def _chain(self):
        self.write("02_plan/plan.json", "PLAN")
        self.write("03_execution/manifest.json", "MANIFEST")
        p = H.record_for(self.run_dir, "02_plan/plan.json")
        m = H.record_for(self.run_dir, "03_execution/manifest.json", inputs=[p.sha256])
        return p, m

    def test_file_tamper_detected(self) -> None:
        """记录没改、文件被改 —— 必须报出来。"""
        p, m = self._chain()
        self.write("03_execution/manifest.json", "MANIFEST-TAMPERED")
        errors = H.verify([p, m], run_dir=self.run_dir)
        self.assertTrue(any("磁盘摘要与记录不一致" in e for e in errors), errors)

    def test_dangling_upstream_rejected(self) -> None:
        """引用一个本 run 不存在的上游 —— 典型的伪造证据。"""
        self.write("03_execution/manifest.json", "MANIFEST")
        m = H.record_for(self.run_dir, "03_execution/manifest.json", inputs=["f" * 64])
        errors = H.verify([m], run_dir=self.run_dir)
        self.assertTrue(any("不存在于本 run" in e for e in errors), errors)

    def test_dangling_upstream_allowed_when_explicitly_permitted(self) -> None:
        self.write("03_execution/manifest.json", "MANIFEST")
        m = H.record_for(self.run_dir, "03_execution/manifest.json", inputs=["f" * 64])
        self.assertEqual(H.verify([m], allow_external_inputs=True), [])

    def test_cycle_detected(self) -> None:
        """哈希链成环说明有人用后置工件反推前置工件。"""
        self.write("02_plan/a.json", "A")
        self.write("02_plan/b.json", "B")
        a_sha, b_sha = "a" * 64, "b" * 64
        a = H.ArtifactRecord(path="02_plan/a.json", sha256=a_sha, inputs=(b_sha,), size=1)
        b = H.ArtifactRecord(path="02_plan/b.json", sha256=b_sha, inputs=(a_sha,), size=1)
        errors = H.verify([a, b])
        self.assertTrue(any("成环" in e for e in errors), errors)
        with self.assertRaises(H.ChainBroken):
            H.topological_order([a, b])

    def test_path_overwrite_detected(self) -> None:
        """同一路径两个摘要 —— 说明工件被覆盖过。"""
        rec1 = H.ArtifactRecord(path="02_plan/a.json", sha256="a" * 64, size=1)
        rec2 = H.ArtifactRecord(path="02_plan/a.json", sha256="b" * 64, size=2)
        errors = H.verify([rec1, rec2])
        self.assertTrue(any("被覆盖过" in e for e in errors), errors)

    def test_missing_file_detected(self) -> None:
        rec = H.ArtifactRecord(path="02_plan/ghost.json", sha256="a" * 64, size=1)
        errors = H.verify([rec], run_dir=self.run_dir)
        self.assertTrue(any("文件不存在" in e for e in errors), errors)

    def test_bad_digest_format_detected(self) -> None:
        rec = H.ArtifactRecord(path="02_plan/a.json", sha256="NOT-A-DIGEST", size=1)
        errors = H.verify([rec])
        self.assertTrue(any("格式非法" in e for e in errors), errors)

    def test_assert_chain_raises_with_summary(self) -> None:
        self.write("03_execution/m.json", "M")
        m = H.record_for(self.run_dir, "03_execution/m.json", inputs=["f" * 64])
        with self.assertRaises(H.ChainBroken) as ctx:
            H.assert_chain([m])
        self.assertIn("哈希链校验失败", str(ctx.exception))


class TopologyTest(TempRun):
    def test_topological_order_puts_upstream_first(self) -> None:
        a = H.ArtifactRecord(path="a", sha256="a" * 64, size=1)
        b = H.ArtifactRecord(path="b", sha256="b" * 64, inputs=("a" * 64,), size=1)
        c = H.ArtifactRecord(path="c", sha256="c" * 64, inputs=("b" * 64,), size=1)
        order = H.topological_order([c, b, a])
        self.assertLess(order.index("a" * 64), order.index("b" * 64))
        self.assertLess(order.index("b" * 64), order.index("c" * 64))

    def test_serialisation_round_trip(self) -> None:
        rec = H.ArtifactRecord(path="02_plan/a.json", sha256="a" * 64, inputs=("b" * 64,), size=7, kind="plan")
        self.assertEqual(H.ArtifactRecord.from_dict(rec.to_dict()), rec)


if __name__ == "__main__":
    unittest.main(verbosity=2)
