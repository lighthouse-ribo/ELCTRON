# -*- coding: utf-8 -*-
"""库模块分发器测试：白名单、禁止面、签名绑定、JSON 安全、输出上限。"""
import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.orchestrator import library_dispatch as D      # noqa: E402
from runtime.orchestrator import registry as R              # noqa: E402


def manifest():
    """加载库模块白名单清单。"""
    return D.load_manifest(PKG)


class ManifestTest(unittest.TestCase):
    """清单必须覆盖全部 19 个 pending 库模块，且永不包含 hardware/excluded。"""

    def test_manifest_covers_all_plan_evidence_library_modules(self) -> None:
        man = manifest()
        # 清单口径 = plan/evidence 组的 library 模块（即 web.pending 的来源）；
        # hardware 组的 library（f1l1_uds / xcdev_wrapper 等执行层库）不进清单。
        libs = {s.name for s in R.TOOL_REGISTRY
                if s.kind == "library" and s.group in ("plan", "evidence")}
        self.assertEqual(len(libs), 19, "pending 口径应为 19 个")
        self.assertEqual(set(man["modules"]), libs,
                         "清单必须与 plan/evidence 的 library 模块一一对应")
        self.assertFalse(man["empty_modules"],
                         "不允许空模块：每个模块至少暴露 1 个函数或常量")

    def test_no_hardware_module_in_manifest(self) -> None:
        man = manifest()
        hw = {s.name for s in R.TOOL_REGISTRY if s.group == "hardware"}
        self.assertEqual(set(man["modules"]) & hw, set(),
                         "hardware 组模块绝不允许进入清单")

    def test_manifest_functions_exist_on_disk(self) -> None:
        """负向能力：清单里登记了不存在的函数名必须能被检出。"""
        man = manifest()
        import ast
        for name, meta in man["modules"].items():
            src = open(os.path.join(PKG, meta["path"]), encoding="utf-8").read()
            tree = ast.parse(src)
            defined = {n.name for n in tree.body
                       if isinstance(n, ast.FunctionDef) and not n.name.startswith("_")}
            consts = {t.id for n in tree.body if isinstance(n, ast.Assign)
                      for t in n.targets if isinstance(t, ast.Name) and t.id.isupper()}
            for fn in meta["functions"]:
                self.assertIn(fn, defined, f"{name}.{fn} 在源码里不存在")
            for c in meta["constants"]:
                self.assertIn(c, consts, f"{name}.{c} 在源码里不存在")


class CallTest(unittest.TestCase):
    """真实调用（不 mock）：能力层函数本来就是纯校验/纯计算。"""

    def test_call_whitelisted_function(self) -> None:
        out = D.call("result_contract", "infer_failure_class", args=["PASS"], root=PKG)
        self.assertEqual(out["module"], "result_contract")
        self.assertEqual(out["target"], "infer_failure_class")
        self.assertIsInstance(out["result"], str)

    def test_read_whitelisted_constant(self) -> None:
        out = D.call("result_contract", "VALID_VERDICTS", root=PKG)
        self.assertIsInstance(out["result"], (list, tuple, dict))

    def test_rejects_function_not_in_manifest(self) -> None:
        """清单里没登记的函数必须拒绝——哪怕它在源码里存在。"""
        with self.assertRaises(D.LibraryDispatchError) as ctx:
            D.call("review_truth", "_some_private_helper", root=PKG)
        self.assertIn("NOT_IN_MANIFEST", str(ctx.exception))

    def test_rejects_hardware_module(self) -> None:
        with self.assertRaises(D.LibraryDispatchError) as ctx:
            D.call("can_init", "anything", root=PKG)
        self.assertIn("MODULE_FORBIDDEN", str(ctx.exception))

    def test_rejects_unknown_module(self) -> None:
        with self.assertRaises(D.LibraryDispatchError) as ctx:
            D.call("os", "system", root=PKG)          # 越权典型：标准库模块
        self.assertIn("MODULE_FORBIDDEN", str(ctx.exception))

    def test_bind_error_on_bad_signature(self) -> None:
        """已登记函数但参数错——必须报 BIND_ERROR，不静默吞掉。"""
        man = manifest()
        mod = "review_truth"
        fn = man["modules"][mod]["functions"][0]
        meta_fn = inspect_signature(mod, fn)
        if meta_fn == 0:
            self.skipTest("该函数无参，无法测绑定错误")
        with self.assertRaises(D.LibraryDispatchError) as ctx:
            D.call(mod, fn, args=["__no_such_arg__"], kwargs={"__bad__": 1}, root=PKG)
        self.assertIn("BIND_ERROR", str(ctx.exception))


def inspect_signature(module: str, function: str) -> int:
    """返回该函数的必需参数个数（用于决定是否跳过绑定测试）。"""
    import ast
    meta = manifest()["modules"][module]
    src = open(os.path.join(PKG, meta["path"]), encoding="utf-8").read()
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == function:
            defaults = node.args.defaults
            pos = node.args.posonlyargs + node.args.args
            required = len(pos) - len(defaults)
            if node.args.vararg or node.args.kwarg:
                return 0                     # 有 *args/**kwargs，绑定很难失败
            return required
    return 0


class OutputSafetyTest(unittest.TestCase):
    def test_jsonable_dataclass(self) -> None:
        import dataclasses

        @dataclasses.dataclass
        class Demo:
            name: str
            data: bytes

        out = D._jsonable(Demo("x", b"\x01\x02"))
        self.assertEqual(out["__dataclass__"], "Demo")
        self.assertEqual(out["data"], "0102")

    def test_jsonable_unknown_object_becomes_repr(self) -> None:
        class Weird:
            pass

        out = D._jsonable(Weird())
        self.assertIn("Weird", out)

    def test_capabilities_lists_groups(self) -> None:
        caps = D.capabilities(PKG)
        self.assertEqual(len(caps), len(manifest()["modules"]))
        for c in caps:
            self.assertIn(c["group"], ("plan", "evidence"),
                          "capabilities 里不允许出现 hardware/excluded 组")


if __name__ == "__main__":
    unittest.main()
