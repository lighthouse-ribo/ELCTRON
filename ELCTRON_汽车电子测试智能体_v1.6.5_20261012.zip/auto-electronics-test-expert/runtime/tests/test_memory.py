#!/usr/bin/env python3
"""P6 memory adapter: safe promotion, isolated retrieval, and no state ownership."""
from __future__ import annotations
import os
import shutil
import sys
import tempfile
import unittest
import uuid
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.memory import LocalSQLiteMemoryStore, MemoryGovernanceError, MemoryService  # noqa: E402

HASH = "a" * 64


class StaticEmbeddingProvider:
    """Test-only local vectors: prove hybrid mechanics without an ML dependency."""

    provider_id = "test-static/v1"
    allow_vector_only_recall = True

    def __init__(self, vectors):
        self.vectors = vectors

    def embed(self, text):
        return self.vectors[text]


def candidate(**over):
    value = {
        "schema_version": "memory-candidate/v0.1",
        "candidate_id": "MC-001",
        "kind": "runbook",
        "source_run_id": "RUN-001",
        "content": "LIN 从节点无响应时，先核对发送计数，再核对唤醒信号。",
        "proposed_by": "evidence_worker",
        "proposed_at": "2026-09-21T00:00:00Z",
        "contains_secret_material": False,
        "applicability": {"conditions": ["诊断会话已建立"], "scope": "project"},
        "approval": {
            "status": "approved",
            "approved_by": "human_approver",
            "approved_at": "2026-09-21T00:01:00Z",
            "version": 1,
        },
        "supersedes": None,
    }
    value.update(over)
    return value


class MemoryServiceTest(unittest.TestCase):
    def setUp(self):
        # In the DLP workstation, SQLite must use an already-provisioned directory.
        # AETEX_TEST_TMPDIR is optional for ordinary environments and required there.
        self._owned_root = None
        configured_root = os.environ.get("AETEX_TEST_TMPDIR")
        if configured_root:
            self.root = configured_root
            self.database_path = os.path.join(configured_root, f"memory-{uuid.uuid4().hex}.sqlite3")
        else:
            self.root = tempfile.mkdtemp(prefix="aetex-memory-")
            self._owned_root = self.root
            self.database_path = os.path.join(self.root, "memory.sqlite3")
        self.service = MemoryService(LocalSQLiteMemoryStore(self.database_path))

    def tearDown(self):
        if self._owned_root:
            shutil.rmtree(self._owned_root, ignore_errors=True)
            return
        for suffix in ("", "-shm", "-wal"):
            try:
                os.remove(self.database_path + suffix)
            except FileNotFoundError:
                pass

    def promote(self, value=None, **over):
        return self.service.promote(value or candidate(**over), project_id="project-a", evidence_sha256=HASH, rule_version="rules/v1")

    def test_approved_candidate_is_append_only_and_retrievable(self):
        record = self.promote()
        self.assertEqual(record.namespace, "project:project-a")
        self.assertEqual(record.evidence_sha256, HASH)
        found = self.service.retrieve(project_id="project-a", query="LIN 唤醒")
        self.assertEqual([item.memory_id for item in found], ["MC-001"])
        self.assertEqual(self.service.retrieve(project_id="project-b", query="LIN 唤醒"), [])

    def test_unapproved_candidate_never_enters_store(self):
        with self.assertRaisesRegex(MemoryGovernanceError, "approved"):
            self.promote(candidate(approval={"status": "pending"}))
        with self.assertRaisesRegex(MemoryGovernanceError, "approver"):
            self.promote(candidate(approval={"status": "approved", "approved_by": "plan_worker"}))
        self.assertEqual(self.service.retrieve(project_id="project-a", query="LIN"), [])

    def test_secret_runtime_and_token_material_are_rejected(self):
        for forbidden in ("API_KEY=sk-test", "approval_token=abc", "credential://aetex/operator", "run_state.json", "C:\\device\\trace.asc", "raw_trace.xct"):
            with self.subTest(forbidden=forbidden), self.assertRaises(MemoryGovernanceError):
                self.promote(candidate(content=f"经验：{forbidden}"))

    def test_missing_evidence_or_conditions_is_rejected(self):
        with self.assertRaisesRegex(MemoryGovernanceError, "SHA-256"):
            self.service.promote(candidate(), project_id="project-a", evidence_sha256="not-a-hash", rule_version="rules/v1")
        with self.assertRaisesRegex(MemoryGovernanceError, "conditions"):
            self.promote(candidate(applicability={"conditions": [], "scope": "project"}))
        with self.assertRaisesRegex(MemoryGovernanceError, "project_id"):
            self.promote(candidate(applicability={"conditions": ["x"], "scope": "project", "project_id": "project-b"}))

    def test_expired_and_revoked_memory_are_not_recalled(self):
        self.service.promote(candidate(candidate_id="MC-EXPIRED"), project_id="project-a", evidence_sha256=HASH,
                             rule_version="rules/v1", expires_at="2000-01-01T00:00:00Z")
        active = self.promote(candidate(candidate_id="MC-ACTIVE"))
        self.assertEqual([item.memory_id for item in self.service.retrieve(project_id="project-a", query="LIN")], ["MC-ACTIVE"])
        self.assertTrue(self.service.store.revoke(active.memory_id))
        self.assertEqual(self.service.retrieve(project_id="project-a", query="LIN"), [])

    def test_fts_retrieval_is_scoped_and_revocation_removes_derived_index(self):
        first = self.promote(candidate(candidate_id="MC-FTS-A", content="UDS DID 0xF190 读取超时，先核对会话与寻址。"))
        self.promote(candidate(candidate_id="MC-FTS-B", content="UDS DID 0xF18C 读取正常。"))
        self.assertEqual(
            [item.memory_id for item in self.service.retrieve(project_id="project-a", query="0xF190")],
            [first.memory_id],
        )
        self.assertEqual(self.service.retrieve(project_id="project-b", query="0xF190"), [])
        self.assertTrue(self.service.revoke(first.memory_id))
        self.assertEqual(self.service.retrieve(project_id="project-a", query="0xF190"), [])

    def test_search_sanitizes_fts_syntax_and_bounds_input(self):
        self.promote(candidate(content="UDS 响应超时的诊断步骤。"))
        self.assertEqual(len(self.service.retrieve(project_id="project-a", query="UDS OR ***")), 1)
        with self.assertRaisesRegex(ValueError, "512"):
            self.service.retrieve(project_id="project-a", query="x" * 513)
        with self.assertRaisesRegex(ValueError, "1..20"):
            self.service.retrieve(project_id="project-a", query="UDS", limit=21)

    def test_hybrid_retrieval_can_include_a_vector_only_record(self):
        self.service = MemoryService(LocalSQLiteMemoryStore(self.database_path, embedding_provider=StaticEmbeddingProvider({
            "CAN 物理层诊断": (0.0, 1.0), "无关键词的向量经验": (1.0, 0.0), "目标查询": (1.0, 0.0),
        })))
        self.promote(candidate(candidate_id="MC-LEXICAL", content="CAN 物理层诊断"))
        vector_only = self.promote(candidate(candidate_id="MC-VECTOR", content="无关键词的向量经验"))
        hits = self.service.retrieve_ranked(project_id="project-a", query="目标查询", limit=1)
        self.assertEqual([hit.record.memory_id for hit in hits], [vector_only.memory_id])
        self.assertIsNone(hits[0].lexical_rank)
        self.assertEqual(hits[0].vector_rank, 1)

    def test_mmr_diversifies_the_fused_shortlist(self):
        self.service = MemoryService(LocalSQLiteMemoryStore(self.database_path, embedding_provider=StaticEmbeddingProvider({
            "候选甲": (1.0, 0.0), "候选乙": (0.99, 0.01), "候选丙": (0.0, 1.0), "目标查询": (1.0, 0.0),
        })))
        first = self.promote(candidate(candidate_id="MC-MMR-A", content="候选甲"))
        self.promote(candidate(candidate_id="MC-MMR-B", content="候选乙"))
        diverse = self.promote(candidate(candidate_id="MC-MMR-C", content="候选丙"))
        hits = self.service.store.search_ranked(project_id="project-a", query="目标查询", limit=2, mmr_lambda=0.5)
        self.assertEqual([hit.record.memory_id for hit in hits], [first.memory_id, diverse.memory_id])

    def test_mem0_mirroring_is_explicit(self):
        with self.assertRaisesRegex(ValueError, "not configured"):
            self.service.promote(candidate(), project_id="project-a", evidence_sha256=HASH,
                                 rule_version="rules/v1", mirror_to_mem0=True)

    def test_contract_required_fields_are_rejected_before_promotion(self):
        for field in ("schema_version", "proposed_by", "proposed_at"):
            with self.subTest(field=field):
                invalid = candidate()
                invalid.pop(field)
                with self.assertRaisesRegex(MemoryGovernanceError, "memory-candidate/v0.1"):
                    self.promote(invalid)

    def test_store_explicitly_closes_each_write_connection(self):
        connection = mock.MagicMock()
        self.service.store._connect = mock.MagicMock(return_value=connection)  # type: ignore[method-assign]
        self.promote()
        connection.commit.assert_called_once()
        connection.close.assert_called_once()

    def test_memory_service_does_not_own_runtime_state(self):
        path = os.path.join(PKG_ROOT, "runtime", "memory", "service.py")
        with open(path, encoding="utf-8") as handle:
            source = handle.read()
        self.assertNotIn("load_checkpoint", source)
        self.assertNotIn("run_state.json", source)
        self.assertNotIn("ApprovalToken", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
