# -*- coding: utf-8 -*-
"""systemPrompt 装配引擎测试：确定性、无硬件、词汇真源、项目事实注入、源码洁癖。"""
import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.web import prompt as P  # noqa: E402


class AssembleTest(unittest.TestCase):
    def test_deterministic(self) -> None:
        """同输入必须产出逐字符相同的 prompt（否则 Web 层缓存与漂移检查失效）。"""
        a = P.assemble(PKG)
        b = P.assemble(PKG)
        self.assertEqual(a["prompt"], b["prompt"])
        self.assertEqual(a["prompt_version"], P.PROMPT_VERSION)

    def test_role_from_agents_md(self) -> None:
        out = P.assemble(PKG)
        self.assertIn("证据优先级", out["prompt"], "角色段落应来自 agents md 正文")
        self.assertIn("汽车电子软件测试专家", out["prompt"])
        self.assertGreater(out["agent_meta"]["max_turns"], 0)
        self.assertTrue(out["agent_meta"]["skills"])

    def test_no_hardware_tools_in_prompt(self) -> None:
        """红线 R2 的措辞面：工具列表里不允许出现任何 hardware 工具 id。"""
        out = P.assemble(PKG)
        self.assertNotIn("hardware__", out["prompt"])
        self.assertIn("硬件工具不在此列表中", out["prompt"])

    def test_vocabulary_from_truth_sources(self) -> None:
        """词汇表来自 state.py 真源与 library_dispatch 受控读取，不是本模块复制。"""
        out = P.assemble(PKG)
        self.assertIn("STATIC_PASSED", out["prompt"])
        self.assertIn("INCONCLUSIVE", out["prompt"])
        self.assertIn("result_contract.VALID_VERDICTS", out["prompt"])

    def test_red_lines_present(self) -> None:
        out = P.assemble(PKG)
        for rid, _, _ in P.RED_LINES:
            self.assertIn(rid, out["prompt"])
        self.assertIn("不拥有状态", out["prompt"], "三层解耦声明必须出现")

    def test_tool_count_matches_surface(self) -> None:
        out = P.assemble(PKG)
        with open(os.path.join(PKG, "runtime", "dist",
                               "web_tool_surface.json"), encoding="utf-8") as fh:
            surface = json.load(fh)
        self.assertEqual(out["tool_count"], len(surface["web"]["allowedTools"]))


class ProjectFactsTest(unittest.TestCase):
    """项目事实只能经参数注入；注入不同配置必须得到不同 prompt。"""

    def test_without_facts_says_not_injected(self) -> None:
        out = P.assemble(PKG)
        self.assertIn("未注入项目配置", out["prompt"])
        self.assertIn("先向用户询问", out["prompt"])

    def test_with_facts_injected(self) -> None:
        facts = {"project": "Demo-X", "nad": "0x42", "versions": ["V1", "V2"]}
        out = P.assemble(PKG, project_facts=facts)
        self.assertIn("Demo-X", out["prompt"])
        self.assertIn("0x42", out["prompt"])
        self.assertIn("V1、V2", out["prompt"])
        self.assertNotIn("未注入项目配置", out["prompt"])

    def test_different_facts_different_prompt(self) -> None:
        a = P.assemble(PKG, project_facts={"project": "A"})
        b = P.assemble(PKG, project_facts={"project": "B"})
        self.assertNotEqual(a["prompt"], b["prompt"])

    def test_source_contains_no_project_facts(self) -> None:
        """源码洁癖：prompt.py 自身不得含任何项目特定值（换项目不改代码的底线）。"""
        with open(os.path.join(PKG, "runtime", "web", "prompt.py"),
                  encoding="utf-8") as fh:
            src = fh.read()
        for banned in ("0x51", "BBS", "V436", "Vcan", "Volvo", "S2608"):
            self.assertNotIn(banned, src, f"prompt.py 源码里不允许出现 {banned!r}")


class BundleTest(unittest.TestCase):
    def test_write_bundle(self) -> None:
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "bundle.json")
            path = P.write_bundle(PKG, project_facts={"project": "T"}, out=out)
            self.assertEqual(path, out)
            with open(out, encoding="utf-8") as fh:
                data = json.load(fh)
            self.assertIn("prompt", data)
            self.assertEqual(data["prompt_version"], P.PROMPT_VERSION)
            self.assertEqual(set(data["sections"]),
                             set(P.assemble(PKG)["sections"]))


if __name__ == "__main__":
    unittest.main()
