import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.agents.test_case_spec import TestCaseSpecError, compile_test_case_specs  # noqa: E402


def draft(**overrides):
    value = {"cases": [{"case_id": "Read_F190", "title": "Read VIN DID", "procedure": "send 22 F1 90",
                          "expected": "62 F1 90", "precondition": "default session",
                          "source_refs": ["REQ-UDS-001"]}]}
    value.update(overrides)
    return value


class TestCaseSpecTests(unittest.TestCase):
    def test_compiles_platform_neutral_bundle(self):
        bundle = compile_test_case_specs(draft())
        self.assertEqual(bundle["schema_version"], "test-case-spec-bundle/v0.1")
        self.assertEqual(bundle["cases"][0]["request"], [0x22, 0xF1, 0x90])
        self.assertEqual(bundle["cases"][0]["traceability_status"], "UNBOUND")

    def test_rejects_positive_response_for_another_did(self):
        with self.assertRaisesRegex(TestCaseSpecError, "IDENTIFIER_MISMATCH"):
            compile_test_case_specs(draft(cases=[{"case_id": "wrong_did", "procedure": "22 F1 90",
                                                   "expected": "62 F1 91", "precondition": "default"}]))

    def test_rejects_negative_response_for_another_service(self):
        with self.assertRaisesRegex(TestCaseSpecError, "NEGATIVE_SID_MISMATCH"):
            compile_test_case_specs(draft(cases=[{"case_id": "wrong_sid", "procedure": "22 F1 90",
                                                   "expected": "7F 10 31", "precondition": "default"}]))

    def test_agent_provided_source_references_remain_unbound_until_verified(self):
        bundle = compile_test_case_specs(draft())
        self.assertEqual(bundle["cases"][0]["traceability_status"], "UNBOUND")

    def test_security_access_seed_and_key_bytes_never_enter_the_bundle(self):
        for procedure, expected in (("27 02 12 34", "67 02"),
                                    ("27 01", "67 01 12 34"),
                                    ("22 F1 90", "62 F1 90")):
            case = {"case_id": "safe_id", "title": "Read DID", "procedure": procedure,
                    "expected": expected, "precondition": "default session"}
            if procedure == "22 F1 90":
                case["title"] = "seed_key=do-not-export"
            with self.subTest(procedure=procedure, expected=expected):
                with self.assertRaisesRegex(TestCaseSpecError, "SECURITY_ACCESS|FORBIDDEN_SECRET"):
                    compile_test_case_specs(draft(cases=[case]))

    def test_rejects_secret_material_before_any_renderer(self):
        with self.assertRaisesRegex(TestCaseSpecError, "FORBIDDEN_SECRET"):
            compile_test_case_specs(draft(cases=[{"case_id": "unsafe", "procedure": "22 F1 90",
                                                   "expected": "62 F1 90", "precondition": "api key is abc"}]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
