import os
import sys
from types import ModuleType
import unittest
from unittest.mock import patch

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.agents.test_case_spec import compile_test_case_specs  # noqa: E402
from runtime.agents.runner import AgentDraft, AgentNodeRunner  # noqa: E402
from runtime.agents.swdl_uds import profile_for  # noqa: E402
from runtime.executor.canoe import CanoeAdapterError, CanoeControlPlane  # noqa: E402
from runtime.orchestrator.graph import RunContext  # noqa: E402
from runtime.renderers.canoe_capl import CanoeCaplRenderError, render_capl_test_unit  # noqa: E402


def bundle():
    return compile_test_case_specs({"cases": [{"case_id": "Read_F190", "title": "Read VIN DID",
                                                 "procedure": "send 22 F1 90", "expected": "62 F1 90",
                                                 "precondition": "default session"}]})


class _Invoker:
    def invoke(self, invocation):
        del invocation
        return AgentDraft("generated CANoe draft", {"target_platform": "canoe-capl",
            "canoe_target_qualifier": "ECU_DIAG", "cases": [{"case_id": "Read_F190", "title": "Read VIN DID",
            "procedure": "send 22 F1 90", "expected": "62 F1 90", "precondition": "default session"}]})


class CanoeCaplTests(unittest.TestCase):
    def test_renderer_uses_project_library_not_transport_reimplementation(self):
        rendered = render_capl_test_unit(bundle(), target_qualifier="ECU_DIAG")
        self.assertEqual(rendered["execution_mode"], "project-library-required")
        self.assertTrue(rendered["requires_project_library"])
        self.assertIn('#include "ELCTRON_UDS_Common.can"', rendered["capl_source"])
        self.assertIn('ELCTRON_UDS_RunCase("ECU_DIAG", "22 F1 90", "62 F1 90", -1);', rendered["capl_source"])
        self.assertNotIn("diagSendRequest", rendered["capl_source"])

    def test_renderer_requires_explicit_target(self):
        with self.assertRaisesRegex(CanoeCaplRenderError, "TARGET_QUALIFIER_REQUIRED"):
            render_capl_test_unit(bundle(), target_qualifier="")

    def test_writer_emits_spec_and_capl_draft_without_execution(self):
        outcome = AgentNodeRunner(profile_for("swdl-uds-test-designer")).run(
            RunContext("RUN-CANOE-001", "UDS", "unused"), _Invoker())
        self.assertEqual(outcome.payload["test_case_spec_bundle"]["schema_version"], "test-case-spec-bundle/v0.1")
        self.assertEqual(outcome.payload["canoe_capl_rendering"]["execution_mode"], "project-library-required")
        self.assertNotIn("vickcan_python_contract", outcome.payload)

    def test_managed_plan_never_implies_execution_authority(self):
        plan = CanoeControlPlane().managed_run_plan(configuration="C:\\project\\test.cfg", target_qualifier="ECU_DIAG",
                                                     generated_capl="C:\\project\\generated.can", report_directory="C:\\report",
                                                     run_id="RUN-CANOE-001")
        self.assertFalse(plan["execution_authorized"])
        with self.assertRaisesRegex(CanoeAdapterError, "TEST_SETUP_BINDING_REQUIRED"):
            CanoeControlPlane().start_managed_run(plan)

    def test_probe_is_fail_closed_when_com_is_unavailable(self):
        def unavailable(_prog_id):
            raise RuntimeError("not registered")

        win32com = ModuleType("win32com")
        win32com.__path__ = []
        client = ModuleType("win32com.client")
        client.GetActiveObject = unavailable
        win32com.client = client
        with patch.dict(sys.modules, {"win32com": win32com, "win32com.client": client}):
            probe = CanoeControlPlane().probe_active()
        self.assertFalse(probe.attached)
        self.assertEqual(probe.reason, "ACTIVE_OBJECT_UNAVAILABLE")


if __name__ == "__main__":
    unittest.main(verbosity=2)
