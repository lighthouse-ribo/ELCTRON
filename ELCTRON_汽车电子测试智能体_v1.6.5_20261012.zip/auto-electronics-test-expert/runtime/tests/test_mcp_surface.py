# -*- coding: utf-8 -*-
"""MCP 工具面拆分（T5.5）的测试。

核心断言只有一句：**`hardware-tools` 永不进入 Web 层的 `allowedTools`。**
而且要证明这个断言**能失败** —— 只测 happy path 的隔离检查等于没有检查。
"""
import copy
import json
import os
import subprocess
import tempfile
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.orchestrator import mcp_surface as M      # noqa: E402
from runtime.orchestrator import registry as R         # noqa: E402

MANIFEST = os.path.join(PKG, "runtime", "dist", "web_tool_surface.json")


class SurfaceShapeTest(unittest.TestCase):
    def setUp(self) -> None:
        self.s = M.build_surface()
        self.by_id = {g["id"]: g for g in self.s["groups"]}

    def test_three_groups_present(self) -> None:
        self.assertEqual(sorted(self.by_id), ["evidence-tools", "hardware-tools",
                                              "plan-tools"])

    def test_plan_and_evidence_are_web_facing(self) -> None:
        for gid in ("plan-tools", "evidence-tools"):
            with self.subTest(group=gid):
                self.assertTrue(self.by_id[gid]["expose_to_web"])

    def test_counts_match_registry(self) -> None:
        self.assertEqual(self.by_id["plan-tools"]["tool_count"],
                         len(R.tools_in_group(R.PLAN)))
        self.assertEqual(self.by_id["evidence-tools"]["tool_count"],
                         len(R.tools_in_group(R.EVIDENCE)))
        self.assertEqual(self.by_id["hardware-tools"]["tool_count"],
                         len(R.tools_in_group(R.HARDWARE)))

    def test_excluded_tools_absent_from_every_surface(self) -> None:
        names = {e["name"] for g in self.s["groups"] for e in g["tools"]}
        excluded = {s.name for s in R.TOOL_REGISTRY if s.group == R.EXCLUDED}
        self.assertEqual(names & excluded, set(),
                         "自检脚本不得进入任何工具面")

    def test_total_surfaced_equals_registry_minus_excluded(self) -> None:
        total = sum(g["tool_count"] for g in self.s["groups"])
        self.assertEqual(total, len(R.TOOL_REGISTRY) - len(R.tools_in_group(R.EXCLUDED)))


class HardwareIsolationTest(unittest.TestCase):
    """红线：硬件工具永不进入 Web 层。"""

    def setUp(self) -> None:
        self.s = M.build_surface()

    def test_hardware_group_not_exposed(self) -> None:
        grp = next(g for g in self.s["groups"] if g["id"] == "hardware-tools")
        self.assertFalse(grp["expose_to_web"])
        leaked = [e["id"] for e in grp["tools"] if e["expose_to_web"]]
        self.assertEqual(leaked, [])

    def test_allowed_tools_has_no_hardware(self) -> None:
        allowed = set(self.s["web"]["allowedTools"])
        hw = set(M.hardware_tool_ids(self.s))
        self.assertEqual(allowed & hw, set(), "allowedTools 混入硬件工具（红线）")
        self.assertEqual(len(hw), 22)

    def test_excluded_groups_declared(self) -> None:
        self.assertEqual(self.s["web"]["excluded_groups"], ["hardware-tools"])

    def test_web_tool_ids_are_plan_or_evidence_only(self) -> None:
        for tid in M.web_tool_ids(self.s):
            with self.subTest(tool=tid):
                self.assertTrue(tid.startswith(("plan__", "evidence__")))


class AllowedToolsTest(unittest.TestCase):
    def setUp(self) -> None:
        self.s = M.build_surface()

    def test_allowed_tools_are_serviceable(self) -> None:
        entries = {e["id"]: e for g in self.s["groups"] for e in g["tools"]}
        for tid in self.s["web"]["allowedTools"]:
            with self.subTest(tool=tid):
                self.assertIn(tid, entries)
                self.assertTrue(entries[tid]["serviceable"])
                # CLI 与库模块都必须声明调用方式；库模块经 library_dispatch 受控调用
                self.assertTrue(entries[tid].get("call_via"), f"{tid} 缺 call_via")
                if entries[tid]["kind"] == R.LIBRARY:
                    self.assertEqual(entries[tid]["call_via"]["dispatcher"],
                                     "library_dispatch")

    def test_library_tools_serviceable_via_manifest(self) -> None:
        """Only the read-only router CLI and pure libraries are serviceable."""
        pending = {p["id"] for p in self.s["web"]["pending"]}
        allowed = set(self.s["web"]["allowedTools"])
        self.assertEqual(pending & allowed, set())
        self.assertEqual(len(allowed), 17, "3 read-only CLI + 14 pure library modules")
        self.assertEqual(len(pending), 41,
                         "library-surface 清单已覆盖全部 plan/evidence 库模块")
        entries = {e["id"]: e for g in self.s["groups"] for e in g["tools"]}
        lib_entries = [e for e in entries.values()
                       if e["kind"] == R.LIBRARY and e["serviceable"]]
        self.assertEqual(len(lib_entries), 14)
        for e in lib_entries:
            with self.subTest(tool=e["id"]):
                self.assertTrue(e["call_via"]["functions"] or e["call_via"]["constants"],
                                f"{e['id']} 清单里函数与常量不能同时为空")

    def test_counts_consistent(self) -> None:
        web = self.s["web"]
        self.assertEqual(web["serviceable_count"], len(web["allowedTools"]))
        self.assertEqual(
            web["tool_count"],
            web["serviceable_count"] + len(web["pending"]))

    def test_as_allowed_tools_matches_manifest_field(self) -> None:
        self.assertEqual(tuple(self.s["web"]["allowedTools"]),
                         M.as_allowed_tools(self.s))


class InvariantCanFailTest(unittest.TestCase):
    """隔离检查必须能失败，否则它只是装饰。"""

    def _tampered(self):
        s = copy.deepcopy(M.build_surface())
        return s

    def test_detects_hardware_group_marked_exposed(self) -> None:
        s = self._tampered()
        next(g for g in s["groups"] if g["id"] == "hardware-tools")["expose_to_web"] = True
        problems = M.check_surface(s)
        self.assertTrue(any("hardware-tools 组被标记为可下发" in p for p in problems),
                        f"未检出：{problems}")

    def test_detects_entry_level_exposure(self) -> None:
        s = self._tampered()
        grp = next(g for g in s["groups"] if g["id"] == "hardware-tools")
        grp["tools"][0]["expose_to_web"] = True
        problems = M.check_surface(s)
        self.assertTrue(any("组内有条目 expose_to_web=true" in p for p in problems),
                        f"未检出：{problems}")

    def test_detects_hardware_leak_into_allowed_tools(self) -> None:
        s = self._tampered()
        hw_id = M.hardware_tool_ids(s)[0]
        s["web"]["allowedTools"] = sorted(s["web"]["allowedTools"] + [hw_id])
        problems = M.check_surface(s)
        self.assertTrue(any("混入硬件工具" in p for p in problems),
                        f"未检出：{problems}")

    def test_detects_unserviceable_tool_in_allowed_tools(self) -> None:
        """构造一个 serviceable=false 的条目塞进 allowedTools，必须被检出。"""
        s = self._tampered()
        grp = next(g for g in s["groups"] if g["id"] == "plan-tools")
        victim = grp["tools"][0]
        victim["serviceable"] = False
        victim["expose_to_web"] = False
        s["web"]["allowedTools"] = sorted(s["web"]["allowedTools"] + [victim["id"]])
        problems = M.check_surface(s)
        self.assertTrue(any("不可服务" in p for p in problems),
                        f"未检出：{problems}")

    def test_detects_unknown_id_in_allowed_tools(self) -> None:
        s = self._tampered()
        s["web"]["allowedTools"] = sorted(s["web"]["allowedTools"] + ["plan__no_such"])
        problems = M.check_surface(s)
        self.assertTrue(any("不在任何工具面内" in p for p in problems),
                        f"未检出：{problems}")


class ManifestDriftTest(unittest.TestCase):
    """清单是生成物：磁盘上的那份必须与代码生成的一致。"""

    def test_manifest_exists_and_matches(self) -> None:
        self.assertTrue(os.path.isfile(MANIFEST),
                        f"缺少生成的清单：{MANIFEST}（跑 mcp_surface.py --out）")
        with open(MANIFEST, encoding="utf-8") as fh:
            on_disk = json.load(fh)
        fresh = M.build_surface()
        self.assertEqual(on_disk["fingerprint"], fresh["fingerprint"],
                         "清单已过期：请重新生成 runtime/dist/web_tool_surface.json")

    def test_manifest_also_passes_invariants(self) -> None:
        with open(MANIFEST, encoding="utf-8") as fh:
            on_disk = json.load(fh)
        self.assertEqual(M.check_surface(on_disk), [])

    def test_fingerprint_covers_content_not_itself(self) -> None:
        """指纹必须按内容算、且排除自身，否则改内容不会让指纹失效。"""
        s = M.build_surface()
        tampered = copy.deepcopy(s)
        tampered["web"]["allowedTools"] = sorted(
            tampered["web"]["allowedTools"] + ["hardware__can_init"])
        self.assertNotEqual(M.surface_fingerprint(s), M.surface_fingerprint(tampered))
        # 指纹字段本身不参与计算：只改它不该改变指纹
        with_fp = dict(s, fingerprint=chr(100) * 8)
        self.assertEqual(M.surface_fingerprint(s), M.surface_fingerprint(with_fp))

    def test_tampered_manifest_is_detected(self) -> None:
        """回归：曾经把硬件工具注入清单的 allowedTools，门禁却 PASS。

        根因是当时只比了指纹字段、且不变量跑在新构建的清单上。
        现在必须同时报出「指纹不符」与「混入硬件工具」。
        """
        with open(MANIFEST, encoding="utf-8") as fh:
            data = json.load(fh)
        data["web"]["allowedTools"] = sorted(
            data["web"]["allowedTools"] + ["hardware__can_init"])
        with tempfile.TemporaryDirectory() as tmp:
            bad = os.path.join(tmp, "surface.json")
            with open(bad, "w", encoding="utf-8", newline="\n") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
            problems = M.verify_manifest(bad)
        self.assertTrue(any("指纹不符" in p for p in problems), problems)
        self.assertTrue(any("混入硬件工具" in p for p in problems), problems)

    def test_verify_manifest_reports_missing_file(self) -> None:
        problems = M.verify_manifest(
            os.path.join(tempfile.gettempdir(), "no_such_surface_xyz.json"))
        self.assertTrue(any("缺少" in p for p in problems), problems)


class CliCheckTest(unittest.TestCase):
    def test_check_mode_passes(self) -> None:
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        proc = subprocess.run(
            [sys.executable, os.path.join(PKG, "runtime", "orchestrator", "mcp_surface.py"),
             "--check"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            cwd=PKG, env=env)
        self.assertEqual(proc.returncode, 0, proc.stdout[-500:] + proc.stderr[-500:])
        self.assertIn("问题数            0", proc.stdout)


if __name__ == "__main__":
    unittest.main()
