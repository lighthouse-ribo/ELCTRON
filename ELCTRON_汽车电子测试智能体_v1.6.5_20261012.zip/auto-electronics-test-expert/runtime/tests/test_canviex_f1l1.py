from __future__ import annotations

import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.executor.canviex_f1l1 import CanviexF1L1Executor, CanviexF1L1Error


class _Client:
    def __init__(self, trace): self.trace, self.closed = trace, False
    def open(self, **_kwargs): pass
    def request_with_trace(self, *_args, **_kwargs): return [0x7E, 0x00], self.trace, 0.0, 0.1
    def close(self): self.closed = True


class _Asc:
    def __init__(self, *_args, **_kwargs): self.events, self.aborted = [], ""
    def open(self): pass
    def record(self, *event): self.events.append(event)
    def seal(self): return {"captures": [{"path": "captures/a.asc"}], "frames": len(self.events)}
    def abort(self, reason): self.aborted = reason; return {"captures": [], "frames": 0}


class CanviexF1L1ExecutorTest(unittest.TestCase):
    def test_real_trace_is_sealed_as_asc_evidence_and_client_closes(self):
        client, asc = _Client([(1.0, "TX", 0x3C, [0x51, 0x02, 0x3E, 0x00]),
                               (1.1, "RX", 0x3D, [0x51, 0x02, 0x7E, 0x00])]), _Asc()
        executor = CanviexF1L1Executor(client_factory=lambda: client, asc_factory=lambda *_a, **_k: asc)
        with tempfile.TemporaryDirectory() as root:
            result = executor.tester_present(run_dir=root, run_id="RUN-F1L1")
        self.assertTrue(result["response_positive"])
        self.assertEqual(len(asc.events), 2)
        self.assertTrue(client.closed)

    def test_empty_trace_is_rejected_and_session_aborted(self):
        client, asc = _Client([]), _Asc()
        executor = CanviexF1L1Executor(client_factory=lambda: client, asc_factory=lambda *_a, **_k: asc)
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaisesRegex(CanviexF1L1Error, "no timestamped"):
                executor.tester_present(run_dir=root, run_id="RUN-F1L1")
        self.assertTrue(asc.aborted)
        self.assertTrue(client.closed)


if __name__ == "__main__":
    unittest.main()
