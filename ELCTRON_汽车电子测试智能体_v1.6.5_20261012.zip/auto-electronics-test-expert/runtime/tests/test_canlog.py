# -*- coding: utf-8 -*-
"""VickCAN CANLOG（###CDXCAN）解析器测试。

这批测试钉住的是**实测出来的格式事实**，不是猜想的格式：

  * 头部 `###CDXCAN` + `# version` / `# app` / `# date` / `# brval,N=` / `# bsts`
  * 数据行有两个变体（实测）：
        VickCAN 2.37 : `<dt> <ch> <id> <bus> <dir> <dlc>, <data>`
        VickCAN 3.10 : `<dt> <ch> <id> <bus> <dir> <kind> <dlc>, <data>`
  * **第 1 字段是微秒级帧间增量**（2026-09-15 修正；判据：团队工具 parse_xct v2
    同语义 + 单帧响应累加差 p50=22.4ms 与 P2=50ms 吻合，ns 解释物理不可能）。
    逐行累加即得单调时间轴，`t_us` 可作时序证据。
  * 非 LIN 总线行（CAN 等）跳过并计数，不做诊断解析。
"""
import os
import sys
import tempfile
import unittest
from datetime import timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.evidence import asc_index as A          # noqa: E402
from runtime.evidence import canlog as C             # noqa: E402

RECORD = (r"C:\Users\80026384\Desktop\软件测试\BBS\BBS_Vcan_Project"
          r"\BBS_Vcan_Project\Vcan_Project\RECORD")

SAMPLE_237 = """###CDXCAN
# version = 2.0
# app = VickCAN,2.37
# date = 2026-6-9,16:50:14-269
# brval,1=250000,0
# brval,2=250000,0
       0 1 10 lin tx  2, 42 00
   55572 1 22 lin tx  0,
   58541 1 22 lin rx  4, 28 F0 00 00
"""

SAMPLE_310 = """###CDXCAN
# version = 2.0
# app = VickCAN,3.10
# date = 2026-9-11,15:8:10-104
# bsts = 45514
       0 1 0 lin tx wa 0,
  236966 1 3C lin tx cl  8,  51 03 22 D0 3A FF FF FF
   48801 1 3D lin tx ao 0,
"""

SAMPLE_MIXED = """###CDXCAN
# version = 2.0
# app = VickCAN,3.10
# date = 2026-8-10,10:31:24-100
       0 1 10 lin tx  2, 42 00
     100 1 3C lin tx cl  8,  51 03 22 D0 3A FF FF FF
       0 1      100s hs   tx  8,11 22 33 44 55 66 77 88
    2000 1 3D lin rx cl  4,  62 D0 3A 00
"""


def write(tmpdir: str, name: str, text: str) -> str:
    """在临时目录写样例文本并返回路径。"""
    path = os.path.join(tmpdir, name)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    return path


class RecognitionTest(unittest.TestCase):
    def test_recognises_magic(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            self.assertTrue(C.is_canlog(write(d, "a.xct", SAMPLE_237)))

    def test_rejects_non_canlog(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            p = write(d, "b.xct", "date Tue Sep 15 04:12:07.659 pm 2026\n1.0 Li 3c Tx 3\n")
            self.assertFalse(C.is_canlog(p))

    def test_rejects_missing_file(self) -> None:
        self.assertFalse(C.is_canlog(os.path.join(tempfile.gettempdir(), "no_such.xct")))


class HeaderTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.path = write(self.tmp.name, "s237.xct", SAMPLE_237)
        self.trace = C.parse_canlog(self.path)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_version_and_app(self) -> None:
        self.assertEqual(self.trace.version, "2.0")
        self.assertEqual(self.trace.app, "VickCAN,2.37")

    def test_started_at(self) -> None:
        dt = self.trace.started_at
        self.assertIsNotNone(dt)
        self.assertEqual((dt.year, dt.month, dt.day), (2026, 6, 9))
        self.assertEqual((dt.hour, dt.minute, dt.second), (16, 50, 14))
        self.assertEqual(dt.microsecond, 269000)

    def test_brvals(self) -> None:
        self.assertEqual(self.trace.brvals.get(1), 250000)
        self.assertEqual(self.trace.brvals.get(2), 250000)

    def test_no_brval_in_310_is_fine(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "s310.xct", SAMPLE_310))
        self.assertEqual(t.brvals, {})


class FrameTest(unittest.TestCase):
    def test_six_field_variant(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "s237.xct", SAMPLE_237))
        self.assertEqual(len(t.frames), 3)
        f = t.frames[0]
        self.assertEqual(f.channel, 1)
        self.assertEqual(f.frame_id, 0x10)
        self.assertEqual(f.bus, "lin")
        self.assertEqual(f.direction, "tx")
        self.assertEqual(f.dlc, 2)
        self.assertEqual(f.data, (0x42, 0x00))
        self.assertEqual(f.kind, "")

    def test_seven_field_variant_keeps_kind(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "s310.xct", SAMPLE_310))
        self.assertEqual(len(t.frames), 3)
        self.assertEqual(t.frames[1].frame_id, 0x3C)
        self.assertEqual(t.frames[1].kind, "cl")          # 原样保留，不解释
        self.assertEqual(t.frames[1].data, (0x51, 0x03, 0x22, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF))
        self.assertEqual(t.frames[2].kind, "ao")

    def test_zero_dlc_gives_empty_data(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "s237.xct", SAMPLE_237))
        self.assertEqual(t.frames[1].dlc, 0)
        self.assertEqual(t.frames[1].data, ())

    def test_line_numbers_are_source_line_numbers(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "s237.xct", SAMPLE_237))
        self.assertEqual([f.line_no for f in t.frames], [7, 8, 9])
        self.assertEqual([f.index for f in t.frames], [0, 1, 2])

    def test_dt_and_cumulative_time_axis(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "s237.xct", SAMPLE_237))
        # dt 原值保留；t_us 从 0 起累加
        self.assertEqual([f.dt_us for f in t.frames], [0, 55572, 58541])
        self.assertEqual([f.t_us for f in t.frames], [0, 55572, 114113])
        self.assertEqual(t.duration_us, 114113)

    def test_end_at_derived_from_header(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "s237.xct", SAMPLE_237))
        self.assertIsNotNone(t.started_at)
        self.assertIsNotNone(t.end_at)
        self.assertEqual(t.end_at - t.started_at, timedelta(microseconds=114113))


class MixedBusTest(unittest.TestCase):
    """实测 CANLOG_260810_103124.xct 混有 CAN 行（`100s hs tx ...`）：跳过，不报错。"""

    def test_non_lin_rows_skipped_and_counted(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "mix.xct", SAMPLE_MIXED))
        self.assertEqual(t.frame_count, 3)
        self.assertEqual(t.skipped_non_lin, 1)
        self.assertEqual(t.frames[1].frame_id, 0x3C)
        # 非 LIN 行的 dt 仍参与时间轴累加
        self.assertEqual(t.frames[2].t_us, 100 + 0 + 0 + 2000)

    def test_non_lin_rows_do_not_enter_diagnostics(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "mix.xct", SAMPLE_MIXED))
        diag = t.diagnostic_frames()
        # diagnostic_frames 只取主/从诊断帧（0x3C/0x3D），0x10 不在其中
        self.assertEqual([f.frame_id for f in diag], [0x3C, 0x3D])


class TimeAxisTest(unittest.TestCase):
    def test_time_axis_available(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            t = C.parse_canlog(write(d, "s237.xct", SAMPLE_237))
        self.assertTrue(t.time_axis_available)
        joined = " ".join(t.notes)
        self.assertIn("时间轴", joined)
        self.assertIn("微秒", joined)


class FailClosedTest(unittest.TestCase):
    def test_zero_frames_raises(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            p = write(d, "empty.xct", "###CDXCAN\n# version = 2.0\n")
            with self.assertRaises(C.CanlogError):
                C.parse_canlog(p)

    def test_malformed_data_line_raises(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            p = write(d, "bad.xct", "###CDXCAN\n# version = 2.0\n 12 1 3C lin tx 8, ZZ\n")
            with self.assertRaises(C.CanlogError):
                C.parse_canlog(p)

    def test_dlc_data_mismatch_raises(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            p = write(d, "mism.xct", "###CDXCAN\n# version = 2.0\n 12 1 3C lin tx 8, 01 02\n")
            with self.assertRaises(C.CanlogError):
                C.parse_canlog(p)


class AscIndexDispatchTest(unittest.TestCase):
    """证据层的入口必须按内容分派，而不是按后缀。"""

    def test_load_evidence_routes_canlog(self) -> None:
        with tempfile.TemporaryDirectory() as run_dir:
            write(run_dir, "CANLOG_x.xct", SAMPLE_237)
            ev = A.load_evidence("CANLOG_x.xct", run_dir)
        self.assertEqual(ev.frame_count, 3)
        self.assertIn("canlog", ev.source_format)
        # 有时间轴：时间区间必须给出来（文件头 + 累计时长）
        self.assertIsNotNone(ev.time_range, "有时间轴时必须给出时间区间")
        self.assertAlmostEqual(ev.duration_s, 114113 / 1e6, places=6)
        joined = " ".join(ev.unresolved)
        self.assertIn("时间轴", joined)

    def test_load_evidence_still_handles_asc(self) -> None:
        with tempfile.TemporaryDirectory() as run_dir:
            write(run_dir, "smoke.asc", "date Tue Sep 15 04:12:07.659 pm 2026\n"
                                        "0.000000 Li 3c  Tx  3  22 D0 3A\n")
            try:
                ev = A.load_evidence("smoke.asc", run_dir)
            except A.EvidenceError as exc:              # 既有解析器口径不变
                self.assertIn("解析失败", str(exc))
                return
            self.assertEqual(ev.source_format, "asc")


@unittest.skipUnless(os.path.isdir(RECORD), "真实录制目录不在本机")
class RealRecordingReplayTest(unittest.TestCase):
    """验收：真实上位机录制必须能解析出帧。这是本轮的核心出口条件。"""

    def test_all_real_recordings_parse(self) -> None:
        files = sorted(f for f in os.listdir(RECORD) if f.lower().endswith(".xct"))
        self.assertGreater(len(files), 20, "真实录制样本太少，验收不成立")
        failures = []
        total_frames = 0
        for name in files:
            path = os.path.join(RECORD, name)
            try:
                trace = C.parse_canlog(path)
            except Exception as exc:                    # noqa: BLE001
                failures.append((name, f"{type(exc).__name__}: {exc}"))
                continue
            if not trace.frames:
                failures.append((name, "0 帧"))
                continue
            total_frames += len(trace.frames)
        self.assertEqual(failures, [], f"解析失败的文件：{failures[:5]}")
        self.assertGreater(total_frames, 50_000, "真实录制总帧数低于预期，解析可能只覆盖了部分文件")

    def test_real_duration_is_physical(self) -> None:
        """时间轴物理性抽检：真实录制的时长必须是正数且在合理量级（分钟级以内）。"""
        name = "CANLOG_260911_150810_104.xct"
        trace = C.parse_canlog(os.path.join(RECORD, name))
        dur_s = trace.duration_us / 1e6
        self.assertGreater(dur_s, 0.0)
        self.assertLess(dur_s, 3600.0, "单个录制时长超过 1 小时，时间轴语义可疑")


if __name__ == "__main__":
    unittest.main()
