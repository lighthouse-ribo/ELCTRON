"""P6 outbox behaviour: approval admission, revocation, and mirror compensation."""
from __future__ import annotations
import os
import shutil
import sys
import tempfile
import unittest
import uuid
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.memory import LocalSQLiteMemoryStore, MemoryGovernanceError, MemoryService  # noqa: E402

HASH = "b" * 64


def candidate(**over):
    value = {
        "schema_version": "memory-candidate/v0.1",
        "candidate_id": "MC-OUTBOX-001",
        "kind": "runbook",
        "source_run_id": "RUN-OUTBOX-001",
        "content": "诊断会话建立后，先确认总线唤醒与响应计数。",
        "proposed_by": "evidence_worker",
        "proposed_at": "2026-09-21T00:00:00Z",
        "contains_secret_material": False,
        "applicability": {"conditions": ["已建立诊断会话"], "scope": "project"},
        "approval": {
            "status": "approved",
            "approved_by": "human_approver",
            "approved_at": "2026-09-21T00:01:00Z",
            "version": 1,
        },
        "supersedes": None,
    }
    value.update(over)
    return value


class MemoryOutboxTest(unittest.TestCase):
    def setUp(self):
        self._owned_root = None
        configured_root = os.environ.get("AETEX_TEST_TMPDIR")
        if configured_root:
            self.root = configured_root
            self.database_path = os.path.join(configured_root, f"outbox-{uuid.uuid4().hex}.sqlite3")
        else:
            self.root = tempfile.mkdtemp(prefix="aetex-outbox-")
            self._owned_root = self.root
            self.database_path = os.path.join(self.root, "memory.sqlite3")
        self.store = LocalSQLiteMemoryStore(self.database_path)
        self.mem0 = mock.Mock()
        self.service = MemoryService(self.store, mem0=self.mem0)

    def tearDown(self):
        if self._owned_root:
            shutil.rmtree(self._owned_root, ignore_errors=True)
            return
        for suffix in ("", "-shm", "-wal"):
            try:
                os.remove(self.database_path + suffix)
            except FileNotFoundError:
                pass

    def promote(self, value=None):
        return self.service.promote(value or candidate(), project_id="project-a", evidence_sha256=HASH,
                                    rule_version="rules/v1", mirror_to_mem0=True)

    def test_only_completed_approval_can_enter_store_or_outbox(self):
        with self.assertRaises(MemoryGovernanceError):
            self.promote(candidate(approval={"status": "pending"}))
        self.assertEqual(self.store.pending_mirrors(), [])
        self.assertEqual(self.service.retrieve(project_id="project-a", query="诊断"), [])

    def test_approved_record_is_queued_then_marked_mirrored(self):
        record = self.promote()
        self.mem0.mirror.assert_called_once_with(record)
        item = self.store.get_outbox_item(record.memory_id)
        self.assertIsNotNone(item)
        self.assertEqual(item.status, "mirrored")
        self.assertEqual(item.attempts, 0)

    def test_failed_mirror_stays_pending_and_retry_compensates(self):
        self.mem0.mirror.side_effect = [RuntimeError("temporary mirror outage"), None]
        record = self.promote()
        pending = self.store.get_outbox_item(record.memory_id)
        self.assertIsNotNone(pending)
        self.assertEqual(pending.status, "pending")
        self.assertEqual(pending.attempts, 1)
        self.assertIn("outage", pending.last_error or "")
        self.assertEqual(self.service.retrieve(project_id="project-a", query="诊断")[0].memory_id, record.memory_id)

        self.assertEqual(self.service.flush_mirror_outbox(), [f"mirrored:{record.memory_id}"])
        compensated = self.store.get_outbox_item(record.memory_id)
        self.assertEqual(compensated.status, "mirrored")
        self.assertEqual(self.mem0.mirror.call_count, 2)

    def test_revoke_cancels_pending_mirror_before_retry(self):
        self.mem0.mirror.side_effect = RuntimeError("offline")
        record = self.promote()
        self.assertTrue(self.service.revoke(record.memory_id))
        item = self.store.get_outbox_item(record.memory_id)
        self.assertEqual(item.status, "revoked")
        self.mem0.mirror.reset_mock()
        self.assertEqual(self.service.flush_mirror_outbox(), [])
        self.mem0.mirror.assert_not_called()
        self.assertEqual(self.service.retrieve(project_id="project-a", query="诊断"), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)