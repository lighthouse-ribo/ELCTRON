#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T2.1–T2.3 / T2.5 五主节点图内核回归测试。

要证明的四件事：
  1. 静态门禁非 PASS 时，**执行子图不可达**（不是"到了才拒绝"）；
  2. 进入执行子图必须持有效令牌，无令牌/过期令牌都进不去；
  3. 每步留下可复盘审计（NodeResult + GateRecord + 状态历史 + 哈希链）；
  4. 中断后能恢复，且**失败节点会被重试**而不是被跳过。
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import unittest
from datetime import timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.orchestrator import approval as A  # noqa: E402
from runtime.orchestrator import graph as G  # noqa: E402
from runtime.orchestrator import hashchain as H  # noqa: E402
from runtime.orchestrator import langgraph_adapter as LG  # noqa: E402
from runtime.orchestrator.state import (  # noqa: E402
    AgentRole,
    GateStatus,
    GraphNode,
    NodeStatus,
    TaskState,
)

RUN_ID = "RUN-0001"
EXEC_REF = "credential://aetex/read-only-did"


def token(*, actions=("execute", "0x10", "0x22"), expired=False, run_id=RUN_ID):
    """构造测试用审批令牌。"""
    now = A.now_utc()
    return A.issue(
        token_id="TOK-1", order_id="ORD-1", run_id=run_id, actions=list(actions),
        valid_from=now - timedelta(hours=2 if expired else 0, minutes=5),
        valid_until=now - timedelta(minutes=1) if expired else now + timedelta(minutes=55),
        approved_by=AgentRole.HUMAN_APPROVER, credential_ref=EXEC_REF,
    )


def make_nodes(*, static_gate=GateStatus.PASS, inspect_gate=GateStatus.PASS,
               execute_gate=GateStatus.PASS, inspect_status=NodeStatus.OK):
    """构造五个节点实现。每个节点写自己的工件并把上游当作 input，形成哈希链。"""

    def route(ctx):
        return G.NodeOutcome(
            status=NodeStatus.OK, summary="挂载 ISO-14229 主分支 + LIN 承载分支",
            artifact_path="01_command/reference_mount.json",
            payload={"primary_branch": "ISO-14229", "secondary_branches": ["ISO-17987"]},
            artifact_kind="reference_mount")

    def inspect(ctx):
        return G.NodeOutcome(
            status=inspect_status,
            summary="输入体检通过，未发现缺失项" if inspect_status is NodeStatus.OK else "缺少 DID 检查表",
            gate_status=inspect_gate, gate_name="input_inspection",
            artifact_path="02_plan/input_inspection.json",
            payload={"gaps": [], "complete": inspect_status is NodeStatus.OK},
            inputs=("01_command/reference_mount.json",),
            blocked_reason="" if inspect_status is NodeStatus.OK else "缺少 DID 检查表",
            artifact_kind="input_inspection")

    def generate(ctx):
        return G.NodeOutcome(
            status=NodeStatus.OK, summary="生成 DID 读取用例草案",
            artifact_path="02_plan/draft_plan.json",
            payload={"cases": ["TC-DID-A001"], "plan_version": "v1"},
            inputs=("02_plan/input_inspection.json",),
            artifact_kind="draft_plan")

    def static(ctx):
        findings = [] if static_gate is GateStatus.PASS else [
            {"code": "MISSING_NRC_FOR_NEGATIVE", "severity": "REVIEW_REQUIRED",
             "message": "负向用例未写明预期 NRC。"}]
        return G.NodeOutcome(
            status=NodeStatus.OK if static_gate is GateStatus.PASS else NodeStatus.REVIEW_REQUIRED,
            summary="lint 与脚本审查均通过" if static_gate is GateStatus.PASS else "静态门禁要求人工复核",
            gate_status=static_gate, gate_name="script_review",
            artifact_path="02_plan/static_gate.record.json",
            payload={"status": static_gate.value, "findings": findings},
            inputs=("02_plan/draft_plan.json",), findings=findings,
            blocked_reason="" if static_gate is GateStatus.PASS else "静态门禁未通过",
            artifact_kind="gate_record")

    def execute(ctx):
        return G.NodeOutcome(
            status=NodeStatus.OK, summary="最小复测 PASS，全量执行完成，ASC 已封存",
            gate_status=execute_gate, gate_name="preflight",
            artifact_path="03_execution/run_manifest.json",
            payload={"captures": ["03_execution/traces/session_001.asc"], "status": "CAPTURED"},
            inputs=("02_plan/static_gate.record.json",),
            artifact_kind="run_manifest")

    return {
        GraphNode.ROUTE_AND_MOUNT_REFERENCE: route,
        GraphNode.INSPECT_INPUTS: inspect,
        GraphNode.GENERATE_OR_DESIGN: generate,
        GraphNode.STATIC_GATE: static,
        GraphNode.HARDWARE_GATE_AND_EXECUTE: execute,
    }


class TempRun(unittest.TestCase):
    def setUp(self) -> None:
        self.run_dir = tempfile.mkdtemp(prefix="aetex-graph-")

    def tearDown(self) -> None:
        shutil.rmtree(self.run_dir, ignore_errors=True)

    def ctx(self, **over):
        base = dict(run_id=RUN_ID, flow="basic_uds", run_dir=self.run_dir)
        base.update(over)
        return G.RunContext(**base)


class GraphShapeTest(unittest.TestCase):
    def test_five_nodes_defined(self) -> None:
        self.assertEqual(len(G.GRAPH_NODES), 5)
        self.assertEqual({s.node for s in G.GRAPH_NODES}, set(GraphNode))

    def test_every_node_has_spec_and_producer(self) -> None:
        for node in GraphNode:
            with self.subTest(node=node.value):
                self.assertIn(node, G.NODE_SPEC)
                self.assertIn(node, G.NEXT_NODE)
                self.assertIsInstance(G.producer_for(node), AgentRole)

    def test_static_gate_to_execution_only_on_pass(self) -> None:
        """核心断言：静态门禁非 PASS 时，通往执行子图的边不存在。"""
        for gate in GateStatus:
            with self.subTest(gate=gate.value):
                target = G.next_node(GraphNode.STATIC_GATE, gate)
                if gate is GateStatus.PASS:
                    self.assertIs(target, GraphNode.HARDWARE_GATE_AND_EXECUTE)
                else:
                    self.assertIsNone(target)

    def test_gate_node_without_verdict_stops(self) -> None:
        """门禁节点没给结论一律停下，不靠默认放行。"""
        for spec in G.GRAPH_NODES:
            if not spec.produces_gate:
                continue
            with self.subTest(node=spec.node.value):
                self.assertIsNone(G.next_node(spec.node, None))

    def test_non_gate_node_advances_without_verdict(self) -> None:
        """非门禁节点（挂资料、生成草案）本来就不出结论，按默认路径推进。"""
        for spec in G.GRAPH_NODES:
            if spec.produces_gate or G.NEXT_NODE[spec.node] is None:
                continue
            with self.subTest(node=spec.node.value):
                self.assertIs(G.next_node(spec.node, None), G.NEXT_NODE[spec.node])

    def test_non_pass_gate_stops_everywhere(self) -> None:
        for node in GraphNode:
            for gate in GateStatus:
                if gate is GateStatus.PASS:
                    continue
                with self.subTest(node=node.value, gate=gate.value):
                    self.assertIsNone(G.next_node(node, gate))

    def test_execution_subgraph_flag(self) -> None:
        exec_nodes = {s.node for s in G.GRAPH_NODES if s.in_execution_subgraph}
        self.assertEqual(exec_nodes, {GraphNode.HARDWARE_GATE_AND_EXECUTE})


class HappyPathTest(TempRun):
    def test_full_run_reaches_captured(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes()).run(ctx)

        self.assertIs(ctx.state, TaskState.CAPTURED)
        self.assertEqual(len(ctx.node_results), 5)
        self.assertEqual([r["node"] for r in ctx.node_results],
                         [s.node.value for s in G.GRAPH_NODES])

    def test_state_history_is_monotonic(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes()).run(ctx)
        chain = [h["to"] for h in ctx.history]
        self.assertEqual(chain, ["INSPECTED", "DESIGNED", "STATIC_PASSED", "RUNNING", "CAPTURED"])
        self.assertTrue(all(h["by"] == "terra" for h in ctx.history))
        self.assertTrue(all(h["at"] for h in ctx.history))

    def test_gate_records_written_for_gate_nodes(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes()).run(ctx)
        kinds = {r["gate_name"] for r in ctx.gate_records}
        self.assertEqual(kinds, {"input_inspection", "script_review", "preflight"})
        self.assertTrue(all(r["decided_by"] == "code" for r in ctx.gate_records))

    def test_artifacts_form_verifiable_chain(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes()).run(ctx)
        self.assertEqual(len(ctx.artifacts), 5)
        errors = H.verify(ctx.artifacts, run_dir=self.run_dir)
        self.assertEqual(errors, [])
        root = H.chain_root(ctx.artifacts)
        self.assertEqual(H.assert_chain(ctx.artifacts, run_dir=self.run_dir), root)

    def test_node_results_validated_against_contract(self) -> None:
        from runtime.contracts import validation

        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes()).run(ctx)
        for result in ctx.node_results:
            with self.subTest(node=result["node"]):
                self.assertEqual(validation.report("node-result/v0.1", result), [])

    def test_audit_files_exist_on_disk(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes()).run(ctx)
        for rel in ("01_command/node_result.route_and_mount_reference.json",
                    "02_plan/gate_record.static_gate.json",
                    "03_execution/node_result.hardware_gate_and_execute.json",
                    G.CHECKPOINT_NAME):
            with self.subTest(rel=rel):
                self.assertTrue(os.path.isfile(os.path.join(self.run_dir, *rel.split("/"))), rel)


class StaticGateBlocksExecutionTest(TempRun):
    def test_review_required_blocks_execution_subgraph(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes(static_gate=GateStatus.REVIEW_REQUIRED)).run(ctx)

        self.assertIs(ctx.state, TaskState.DESIGNED)
        self.assertFalse(os.path.isdir(os.path.join(self.run_dir, "03_execution")),
                         "执行目录不该出现任何工件")
        self.assertEqual([r["node"] for r in ctx.node_results][-1], "static_gate")
        self.assertIn("静态门禁", ctx.blocked_reason)

    def test_error_blocks_execution_subgraph(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes(static_gate=GateStatus.ERROR)).run(ctx)
        self.assertIs(ctx.state, TaskState.DESIGNED)
        self.assertFalse(os.path.exists(os.path.join(self.run_dir, "03_execution")))

    def test_inspect_failure_stops_at_new(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes(inspect_status=NodeStatus.BLOCKED,
                                 inspect_gate=GateStatus.BLOCKED)).run(ctx)
        self.assertIs(ctx.state, TaskState.NEW)
        self.assertEqual([r["node"] for r in ctx.node_results][-1], "inspect_inputs")


class ApprovalGateTest(TempRun):
    def _run_with_token(self, tok):
        ctx = self.ctx(token=tok)
        G.GraphRunner(make_nodes()).run(ctx)
        return ctx

    def test_no_token_cannot_enter_execution(self) -> None:
        ctx = self.ctx(token=None)
        G.GraphRunner(make_nodes()).run(ctx)
        self.assertEqual(ctx.state, TaskState.STATIC_PASSED)
        self.assertEqual(ctx.last_node, GraphNode.STATIC_GATE)

    def test_expired_token_cannot_enter_execution(self) -> None:
        with self.assertRaises(A.ApprovalError) as e:
            self._run_with_token(token(expired=True))
        self.assertEqual(e.exception.reason, "EXPIRED")

    def test_token_for_other_run_cannot_enter(self) -> None:
        with self.assertRaises(A.ApprovalError) as e:
            self._run_with_token(token(run_id="RUN-9999"))
        self.assertEqual(e.exception.reason, "RUN_MISMATCH")

    def test_token_missing_execute_action_cannot_enter(self) -> None:
        with self.assertRaises(A.ApprovalError) as e:
            self._run_with_token(token(actions=("0x10",)))
        self.assertEqual(e.exception.reason, "ACTION_NOT_GRANTED")

    def test_extra_required_action_must_also_be_granted(self) -> None:
        ctx = self.ctx(token=token(actions=("execute",)), required_actions=("execute", "0x34"))
        with self.assertRaises(A.ApprovalError) as e:
            G.GraphRunner(make_nodes()).run(ctx)
        self.assertEqual(e.exception.reason, "ACTION_NOT_GRANTED")


class RobustnessTest(TempRun):
    def test_missing_node_implementation_raises(self) -> None:
        nodes = make_nodes()
        nodes.pop(GraphNode.STATIC_GATE)
        with self.assertRaises(G.GraphError) as e:
            G.GraphRunner(nodes).run(self.ctx(token=token()))
        self.assertIn("没有实现", str(e.exception))

    def test_node_writing_outside_its_dir_is_rejected(self) -> None:
        """节点想越权写到执行目录 —— ACL 必须拦。"""
        nodes = make_nodes()

        def rogue(ctx):
            return G.NodeOutcome(status=NodeStatus.OK, summary="越权写入",
                                 artifact_path="03_execution/evil.json", payload={"x": 1})

        nodes[GraphNode.GENERATE_OR_DESIGN] = rogue
        from runtime.orchestrator.acl import AclViolation
        with self.assertRaises(AclViolation):
            G.GraphRunner(nodes).run(self.ctx(token=token()))

    def test_payload_without_path_is_rejected(self) -> None:
        nodes = make_nodes()

        def sloppy(ctx):
            return G.NodeOutcome(status=NodeStatus.OK, summary="忘了给路径", payload={"x": 1})

        nodes[GraphNode.GENERATE_OR_DESIGN] = sloppy
        with self.assertRaises(G.GraphError) as e:
            G.GraphRunner(nodes).run(self.ctx(token=token()))
        self.assertIn("artifact_path", str(e.exception))

    def test_max_steps_guard(self) -> None:
        nodes = make_nodes()
        with self.assertRaises(G.GraphError):
            G.GraphRunner(nodes).run(self.ctx(token=token()), max_steps=2)


class CheckpointResumeTest(TempRun):
    def test_checkpoint_written_and_restored(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes()).run(ctx)
        restored = G.load_checkpoint(self.run_dir)
        self.assertIsNotNone(restored)
        assert restored is not None
        self.assertIs(restored.state, TaskState.CAPTURED)
        self.assertEqual(restored.last_node, GraphNode.HARDWARE_GATE_AND_EXECUTE)
        self.assertEqual(len(restored.node_results), len(ctx.node_results))
        self.assertEqual(H.chain_root(restored.artifacts), H.chain_root(ctx.artifacts))

    def test_resume_retries_failed_node(self) -> None:
        """门禁失败后恢复：上次节点是"失败态"，应当**重试它**而不是跳过。"""
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes(static_gate=GateStatus.REVIEW_REQUIRED)).run(ctx)

        restored = G.load_checkpoint(self.run_dir)
        assert restored is not None
        restored.run_dir = self.run_dir
        self.assertEqual(G.GraphRunner(make_nodes()).resolve_entry(restored),
                         GraphNode.STATIC_GATE)

    def test_resume_continues_from_success(self) -> None:
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes()).run(ctx)
        restored = G.load_checkpoint(self.run_dir)
        assert restored is not None
        self.assertIsNone(G.GraphRunner(make_nodes()).resolve_entry(restored),
                          "已到终点，不该再推进")

    def test_rerun_after_fix_completes(self) -> None:
        """完整恢复流程：第一次被门禁拦住，第二次带着令牌跑完。"""
        ctx = self.ctx(token=token())
        G.GraphRunner(make_nodes(static_gate=GateStatus.REVIEW_REQUIRED)).run(ctx)
        self.assertIs(ctx.state, TaskState.DESIGNED)

        restored = G.load_checkpoint(self.run_dir)
        assert restored is not None
        restored.run_dir = self.run_dir
        restored.token = token()
        G.GraphRunner(make_nodes()).run(restored)

        self.assertIs(restored.state, TaskState.CAPTURED)
        self.assertEqual(len(restored.node_results), 6, "static_gate 应被重跑一次，共 6 条审计")

    def test_checkpoint_version_guard(self) -> None:
        with self.assertRaises(G.GraphError):
            G.restore_context({"schema_version": "wrong/v9", "run_id": RUN_ID})

    def test_missing_checkpoint_returns_none(self) -> None:
        self.assertIsNone(G.load_checkpoint(self.run_dir))


class LangGraphAdapterTest(unittest.TestCase):
    def test_adapter_edges_match_core_semantics(self) -> None:
        """适配层导出的边必须与内核判定一致 —— 换框架不能换语义。"""
        for src, gate, dst in LG.describe_edges():
            with self.subTest(src=src, gate=gate):
                expected = G.next_node(GraphNode(src), gate)
                self.assertEqual(dst, expected.value if expected else "END")

    def test_unavailable_reports_clearly(self) -> None:
        if LG.available():
            self.skipTest("本机已安装 langgraph，跳过缺失分支")
        with self.assertRaises(LG.LangGraphUnavailable) as e:
            LG.build_graph(make_nodes())
        self.assertIn("langgraph", str(e.exception))

    def test_available_is_boolean(self) -> None:
        self.assertIsInstance(LG.available(), bool)


if __name__ == "__main__":
    unittest.main(verbosity=2)
