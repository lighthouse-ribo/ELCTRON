#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T4.1–T4.5 证据与报告闭环回归测试。

被测的是**闭环本身**：
  * 用真实 ASС（由既有的 LiveAscRecorder 产出）喂给证据解析 → 证明解析器接的是真数据；
  * 索引与 manifest 对不上时必须判缺失，不许照单全收；
  * 证据不全时，即便所有用例都写 PASS，最终也只能 INCONCLUSIVE（红线 R5）；
  * 二进制专有 XCT 必须 BLOCKED；
  * 报告只走既有脚本，不自造前端。
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.evidence import asc_index as asc  # noqa: E402
from runtime.evidence import index_builder as ib  # noqa: E402
from runtime.evidence import report as rpt  # noqa: E402
from runtime.evidence import verdict as vd  # noqa: E402
from runtime.executor.asc_session import AscSession  # noqa: E402
from runtime.executor.manifest import build_run_manifest  # noqa: E402
from runtime.orchestrator import approval as A  # noqa: E402
from runtime.orchestrator import tools as T  # noqa: E402
from runtime.orchestrator.state import RunFinalVerdict  # noqa: E402

RUN_ID = "RUN-EV-001"
RULE_VERSION = "expectation_check/2026-09-04"


class TempRun(unittest.TestCase):
    def setUp(self) -> None:
        self.run_dir = tempfile.mkdtemp(prefix="aetex-ev-")

    def tearDown(self) -> None:
        shutil.rmtree(self.run_dir, ignore_errors=True)

    def make_asc(self, *, frames=6, kinds=("req", "resp")) -> dict:
        """用既有 LiveAscRecorder 产一份真实 ASC，返回 capture 结构。"""
        session = AscSession(self.run_dir, run_id=RUN_ID, channel="LIN1",
                             case_id="TC-1", session_id="loop_ev_001")
        session.open()
        t = 1000.0
        for i in range(frames):
            t += 0.005
            if i % 2 == 0:
                session.record(t, "tx", 0x3C, [0x51, 0x03, 0x22, 0xA0, 0x01])
            else:
                session.record(t, "rx", 0x3D, [0x51, 0x04, 0x62, 0xA0, 0x01, 0x00])
        sealed = session.seal()
        return sealed["captures"][0]

    def make_manifest(self, captures) -> dict:
        return build_run_manifest(
            run_id=RUN_ID, flow="basic_uds",
            device={"adapter": "xcdevlay", "channel": "LIN1"},
            started_at=A.now_utc(), status="CAPTURED",
            order_refs=[{"order_id": "ORD-1", "plan_sha256": "d" * 64}],
            captures=captures)


# --------------------------------------------------------------------------- #
class AscIndexTest(TempRun):
    def test_parses_real_asc(self) -> None:
        cap = self.make_asc()
        parsed = asc.load_evidence(cap["path"], self.run_dir)
        self.assertEqual(parsed.source_format, "asc")
        self.assertEqual(parsed.frame_count, 6)
        self.assertEqual(len(parsed.sha256), 64)

    def test_time_range_uses_absolute_anchor(self) -> None:
        """ASC 头部有日期 + 帧是相对秒数 -> 必须能给出绝对时间段。"""
        cap = self.make_asc()
        parsed = asc.load_evidence(cap["path"], self.run_dir)
        rng = parsed.time_range
        self.assertIsNotNone(rng, "ASC 有头部日期，应当能推出绝对时间")
        assert rng is not None
        self.assertTrue(rng["from"].endswith("Z"))
        self.assertLess(rng["from"], rng["to"])

    def test_key_frames_reference_reassembled_messages(self) -> None:
        cap = self.make_asc()
        parsed = asc.load_evidence(cap["path"], self.run_dir)
        self.assertTrue(parsed.key_frames)
        first = parsed.key_frames[0]
        self.assertIn(first["direction"], ("tx", "rx"))
        self.assertTrue(first["frame_id"].startswith("0x"))
        self.assertIn("lines=", first["note"])

    def test_missing_file_raises(self) -> None:
        with self.assertRaises(asc.EvidenceError):
            asc.load_evidence("03_execution/traces/nope.asc", self.run_dir)

    def test_unsupported_suffix_raises(self) -> None:
        rel = "03_execution/traces/a.blf"
        full = os.path.join(self.run_dir, *rel.split("/"))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write("x")
        with self.assertRaises(asc.EvidenceError):
            asc.load_evidence(rel, self.run_dir)

    def test_empty_file_raises(self) -> None:
        rel = "03_execution/traces/empty.asc"
        full = os.path.join(self.run_dir, *rel.split("/"))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write("no frames here\n")
        with self.assertRaises(asc.EvidenceError):
            asc.load_evidence(rel, self.run_dir)

    def test_binary_xct_is_blocked(self) -> None:
        """T4.5：二进制专有 XCT 默认 BLOCKED，不猜布局。"""
        rel = "03_execution/traces/proprietary.xct"
        full = os.path.join(self.run_dir, *rel.split("/"))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as fh:
            fh.write(b"\x00\x01\x02PROPRIETARY\x00\xff\xfe")
        with self.assertRaises(asc.BinaryEvidenceBlocked) as ctx:
            asc.load_evidence(rel, self.run_dir)
        self.assertIn("BLOCKED", str(ctx.exception))

    def test_looks_binary(self) -> None:
        good = os.path.join(self.run_dir, "ok.txt")
        with open(good, "w", encoding="utf-8") as fh:
            fh.write("plain text")
        bad = os.path.join(self.run_dir, "bad.bin")
        with open(bad, "wb") as fh:
            fh.write(b"abc\x00def")
        self.assertFalse(asc.looks_binary(good))
        self.assertTrue(asc.looks_binary(bad))

    def test_load_many_partitions_success_and_failure(self) -> None:
        cap = self.make_asc()
        ok, bad = asc.load_many([cap["path"], "03_execution/traces/ghost.asc"], self.run_dir)
        self.assertEqual(len(ok), 1)
        self.assertEqual(len(bad), 1)
        self.assertIn("ghost.asc", bad[0][0])

    def test_parse_asc_start_time(self) -> None:
        head = "date Tue Sep 15 04:12:07.659 pm 2026\nbase hex  timestamps absolute\n"
        dt = asc.parse_asc_start_time(head)
        self.assertIsNotNone(dt)
        assert dt is not None
        self.assertEqual((dt.year, dt.month, dt.day, dt.hour), (2026, 9, 15, 16))

    def test_parse_asc_start_time_am(self) -> None:
        head = "date Mon Jan 05 09:00:00.000 am 2026\n"
        dt = asc.parse_asc_start_time(head)
        assert dt is not None
        self.assertEqual(dt.hour, 9)

    def test_parse_asc_start_time_absent(self) -> None:
        self.assertIsNone(asc.parse_asc_start_time("base hex  timestamps absolute\n"))

    def test_reuses_existing_parser(self) -> None:
        """必须复用既有解析器，不另写一份正则。"""
        mod = asc.load_trace_module()
        self.assertEqual(mod.__name__, "swdl_trace_import")
        self.assertTrue(hasattr(mod, "import_swdl_trace"))
        self.assertTrue(hasattr(mod, "TraceImportError"))


class IndexBuilderTest(TempRun):
    def _index(self, **over):
        cap = over.pop("cap", None) or self.make_asc()
        manifest = over.pop("manifest", None) or self.make_manifest([cap])
        kwargs = dict(run_id=RUN_ID, manifest=manifest, run_dir=self.run_dir,
                      rule_version=RULE_VERSION)
        kwargs.update(over)
        return ib.build_evidence_index(**kwargs)

    def test_builds_complete_index(self) -> None:
        index = self._index()
        self.assertEqual(index["schema_version"], "evidence-index/v0.1")
        self.assertTrue(index["complete"])
        self.assertEqual(len(index["entries"]), 1)
        self.assertEqual(index["missing"], [])
        entry = index["entries"][0]
        self.assertTrue(entry["immutable"])
        self.assertIn("time_range", entry)
        self.assertIn("key_frames", entry)

    def test_index_passes_contract(self) -> None:
        from runtime.contracts import validation

        self.assertEqual(validation.report("evidence-index/v0.1", self._index()), [])

    def test_write_and_read(self) -> None:
        index = self._index()
        rel = ib.write_index(self.run_dir, index)
        self.assertEqual(rel, "04_evidence/evidence_index.json")
        self.assertEqual(ib.read_index(self.run_dir), index)

    def test_refuses_to_overwrite(self) -> None:
        """索引不可覆盖：结论依赖它，被悄悄改写等于证据链失效。"""
        index = self._index()
        ib.write_index(self.run_dir, index)
        with self.assertRaises(ib.IndexExists):
            ib.write_index(self.run_dir, index)

    def test_replace_archives_previous(self) -> None:
        index = self._index()
        ib.write_index(self.run_dir, index)
        ib.write_index(self.run_dir, index, allow_replace=True)
        archived = os.path.join(self.run_dir, "04_evidence", "evidence_index.json.previous")
        self.assertTrue(os.path.isfile(archived))

    def test_tampered_evidence_is_marked_missing(self) -> None:
        """封存后改动文件 -> 既算缺失也算未解释项，绝不静默通过。"""
        cap = self.make_asc()
        manifest = self.make_manifest([cap])
        full = os.path.join(self.run_dir, *cap["path"].split("/"))
        with open(full, "a", encoding="utf-8") as fh:
            fh.write(" 9.999999 Li 3c                  Tx     3 22 a0 01  checksum = 00   BR = 19200  CSM = classic\n")
        index = ib.build_evidence_index(run_id=RUN_ID, manifest=manifest,
                                        run_dir=self.run_dir, rule_version=RULE_VERSION)
        self.assertFalse(index["complete"])
        self.assertTrue(any("不一致" in m["reason"] for m in index["missing"]))
        self.assertTrue(index.get("unresolved"))

    def test_required_cases_without_evidence_is_missing(self) -> None:
        index = self._index(required_cases=["TC-1", "TC-9"])
        self.assertFalse(index["complete"])
        self.assertIn("TC-9", [m["required_for"] for m in index["missing"]])

    def test_case_evidence_map_marks_coverage(self) -> None:
        index = self._index(case_evidence_map={"TC-1": ["EV-001"]})
        self.assertEqual(index["entries"][0]["covers_cases"], ["TC-1"])

    def test_no_captures_means_incomplete(self) -> None:
        manifest = self.make_manifest([])
        index = ib.build_evidence_index(run_id=RUN_ID, manifest=manifest,
                                        run_dir=self.run_dir, rule_version=RULE_VERSION)
        self.assertFalse(index["complete"])

    def test_verify_index_detects_tamper(self) -> None:
        cap = self.make_asc()
        index = self._index(cap=cap)
        self.assertEqual(ib.verify_index(self.run_dir, index), [])
        full = os.path.join(self.run_dir, *cap["path"].split("/"))
        with open(full, "a", encoding="utf-8") as fh:
            fh.write("tampered\n")
        self.assertTrue(ib.verify_index(self.run_dir, index))

    def test_read_missing_index_raises(self) -> None:
        with self.assertRaises(FileNotFoundError):
            ib.read_index(self.run_dir)


class VerdictDraftTest(unittest.TestCase):
    def _draft(self, **over):
        base = dict(run_id=RUN_ID, case_id="TC-1", verdict="PASS", rule_version=RULE_VERSION,
                    evidence_refs=["EV-001"], expected="0x22 A001 正响应",
                    observed="收到 0x62 A001 + 数据")
        base.update(over)
        return vd.build_verdict_draft(**base)

    def test_pass_with_evidence_ok(self) -> None:
        draft = self._draft()
        self.assertFalse(draft["final"])
        self.assertEqual(draft["evidence_refs"], ["EV-001"])

    def test_pass_without_evidence_is_refused(self) -> None:
        """红线 R5：没有证据的 PASS 连构造都构造不出来。"""
        with self.assertRaises(vd.VerdictInvalid) as ctx:
            self._draft(evidence_refs=[])
        self.assertIn("证据", str(ctx.exception))

    def test_fail_without_evidence_is_refused(self) -> None:
        with self.assertRaises(vd.VerdictInvalid):
            self._draft(verdict="FAIL", evidence_refs=[], failure_class="ECU_FAIL")

    def test_blocked_without_evidence_is_allowed(self) -> None:
        """BLOCKED 是"没执行"，本就不该要求证据。"""
        draft = self._draft(verdict="BLOCKED", evidence_refs=[], failure_class="BLOCKED")
        self.assertEqual(draft["verdict"], "BLOCKED")

    def test_invalid_verdict_rejected(self) -> None:
        with self.assertRaises(vd.VerdictInvalid):
            self._draft(verdict="MAYBE")

    def test_invalid_failure_class_rejected(self) -> None:
        with self.assertRaises(vd.VerdictInvalid):
            self._draft(failure_class="WHATEVER")

    def test_draft_passes_contract(self) -> None:
        from runtime.contracts import validation

        self.assertEqual(validation.report("verdict-draft/v0.1", self._draft()), [])

    def test_nrc_and_timing_optional(self) -> None:
        draft = self._draft(verdict="FAIL", failure_class="ECU_FAIL",
                            nrc="0x22", timing={"p2_ms": 60.0, "measured_by": "timing_trace.py"})
        self.assertEqual(draft["nrc"], "0x22")
        self.assertEqual(draft["timing"]["p2_ms"], 60.0)


class FinalizeTest(unittest.TestCase):
    def _index(self, *, complete=True, missing=(), unresolved=(), rule_version=RULE_VERSION):
        idx = {"schema_version": "evidence-index/v0.1", "run_id": RUN_ID,
               "rule_version": rule_version, "generated_by": "evidence_worker",
               "entries": [], "missing": list(missing), "complete": complete}
        if unresolved:
            idx["unresolved"] = list(unresolved)
        return idx

    def test_no_index_is_inconclusive(self) -> None:
        out = vd.finalize(case_verdicts=["PASS"], evidence_index=None)
        self.assertIs(out["final_verdict"], RunFinalVerdict.INCONCLUSIVE)
        self.assertFalse(out["evidence_complete"])

    def test_complete_index_with_all_pass_is_pass(self) -> None:
        out = vd.finalize(case_verdicts=["PASS", "NA"], evidence_index=self._index())
        self.assertIs(out["final_verdict"], RunFinalVerdict.PASS)
        self.assertTrue(out["evidence_complete"])

    def test_missing_evidence_forces_inconclusive_even_if_all_pass(self) -> None:
        """核心断言：证据不全时，全 PASS 也只能 INCONCLUSIVE。"""
        idx = self._index(complete=False, missing=[{"required_for": "TC-1", "reason": "ASC 未建立"}])
        out = vd.finalize(case_verdicts=["PASS", "PASS"], evidence_index=idx)
        self.assertIs(out["final_verdict"], RunFinalVerdict.INCONCLUSIVE)

    def test_unresolved_forces_inconclusive(self) -> None:
        idx = self._index(unresolved=["无法区分帧未发出与帧未被接收"])
        out = vd.finalize(case_verdicts=["PASS"], evidence_index=idx)
        self.assertIs(out["final_verdict"], RunFinalVerdict.INCONCLUSIVE)

    def test_blocked_case_prevents_closing(self) -> None:
        out = vd.finalize(case_verdicts=["PASS", "BLOCKED"], evidence_index=self._index())
        self.assertIsNone(out["final_verdict"])
        self.assertTrue(out["blocked"])

    def test_aborted_prevents_closing(self) -> None:
        out = vd.finalize(case_verdicts=["PASS"], evidence_index=self._index(), aborted=True)
        self.assertIsNone(out["final_verdict"])

    def test_rule_version_mismatch_downgrades(self) -> None:
        out = vd.finalize(case_verdicts=["PASS"], evidence_index=self._index(rule_version="old/v1"),
                          rule_version=RULE_VERSION)
        self.assertIs(out["final_verdict"], RunFinalVerdict.INCONCLUSIVE)

    def test_fail_wins(self) -> None:
        out = vd.finalize(case_verdicts=["PASS", "FAIL"], evidence_index=self._index())
        self.assertIs(out["final_verdict"], RunFinalVerdict.FAIL)

    def test_reasons_always_present(self) -> None:
        for idx in (None, self._index(), self._index(complete=False, missing=[{"required_for": "x", "reason": "y"}])):
            with self.subTest(index=idx is not None):
                self.assertTrue(vd.finalize(case_verdicts=["PASS"], evidence_index=idx)["reasons"])


class ReportReuseTest(unittest.TestCase):
    def test_framework_template_exists(self) -> None:
        self.assertTrue(os.path.isfile(rpt.assert_framework_available()))

    def test_missing_framework_is_an_error_not_a_fallback(self) -> None:
        tmp = tempfile.mkdtemp(prefix="aetex-nofw-")
        self.addCleanup(shutil.rmtree, tmp, True)
        with self.assertRaises(rpt.ReportError):
            rpt.assert_framework_available(tmp)

    def test_adapter_points_at_real_script(self) -> None:
        """证明接的是既有脚本本身（跑一次 --help）。"""
        result = T.run_cli(rpt.REPORT_TO_HTML, ["--help"])
        self.assertEqual(result.returncode, 0, msg=result.stderr[:300])
        for flag in ("--results", "--extra", "--swdl-report", "--out"):
            self.assertIn(flag, result.stdout)

    def test_describe_inputs_documents_existing_cli(self) -> None:
        inputs = rpt.describe_inputs()
        self.assertEqual(set(inputs), {"results", "extra", "swdl_report", "project_config"})

    def test_style_contract_is_explicit(self) -> None:
        self.assertIn("uds_report_framework.html", rpt.STYLE_CONTRACT)
        self.assertIn("不得另起", rpt.STYLE_CONTRACT)


if __name__ == "__main__":
    unittest.main(verbosity=2)
