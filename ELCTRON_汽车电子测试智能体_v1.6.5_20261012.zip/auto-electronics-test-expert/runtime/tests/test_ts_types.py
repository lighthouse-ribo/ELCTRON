# -*- coding: utf-8 -*-
"""T1.3 TS + zod 类型生成的测试。

这批测试不只检查「文件生成了」，而是**真的把 TS 编译并用 zod 跑一遍样例**：

    编译（tsc --strict）→ 加载（node require）→ 每个样例 safeParse
    → 正向必须通过 + 负向（多字段/删必填）必须被拒

最后一类负向断言是重点：只做正向检查的话，一个 `z.any()` 也能全绿。
并且额外用一个**篡改用例**证明这套校验本身能失败（今天刚踩过「不会失败的检查」）。
"""
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

GEN = os.path.join(PKG, "runtime", "tools", "gen_ts_types.py")
GEN_DIR = os.path.join(PKG, "runtime", "contracts", "generated")
TS_FILE = os.path.join(GEN_DIR, "schema_types.ts")
EX_FILE = os.path.join(GEN_DIR, "schema_examples.json")
VALIDATOR = os.path.join(HERE, "ts", "validate_schemas.cjs")
VALIDATION_PY = os.path.join(PKG, "runtime", "contracts", "validation.py")

NODE_CANDIDATES = sorted(glob.glob(
    r"C:\Users\80026384\.workbuddy\binaries\node\versions\*\node.exe"))
NODE = NODE_CANDIDATES[-1] if NODE_CANDIDATES else ""
NODE_WS = r"C:\Users\80026384\.workbuddy\binaries\node\workspace"
TSC = os.path.join(NODE_WS, "node_modules", "typescript", "bin", "tsc")
HAS_TOOLCHAIN = bool(NODE) and os.path.isfile(TSC) and os.path.isdir(
    os.path.join(NODE_WS, "node_modules", "zod"))

BUILD_DIR = os.path.join(NODE_WS, ".aetex-tsbuild")


def py_env() -> dict:
    """node 运行环境（NODE_PATH 指向受管工作区）。"""
    return dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(cmd, **kw):
    """以受管 node 执行脚本，返回 CompletedProcess。"""
    env = dict(os.environ, NODE_PATH=os.path.join(NODE_WS, "node_modules"),
               PYTHONDONTWRITEBYTECODE="1")
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", env=env, **kw)


class GeneratedFilesTest(unittest.TestCase):
    def test_files_exist(self) -> None:
        for p in (TS_FILE, EX_FILE):
            with self.subTest(path=p):
                self.assertTrue(os.path.isfile(p), f"缺少生成物：{p}")

    def test_no_drift(self) -> None:
        proc = run([sys.executable, GEN, "--root", PKG, "--check"], cwd=PKG)
        self.assertEqual(proc.returncode, 0,
                         f"TS 类型已漂移：{proc.stdout[-600:]}{proc.stderr[-300:]}")

    def test_no_unsupported_constructs(self) -> None:
        """棘轮：契约里出现 allOf/anyOf/oneOf/not/if 时必须先想清楚怎么表达。"""
        with open(EX_FILE, encoding="utf-8") as fh:
            payload = json.load(fh)
        self.assertEqual(payload["unsupported"], [],
                         "出现未支持的 schema 构造，已被 z.unknown 兜底（会丢类型）")

    def test_new_case_contract_keeps_upper_bounds(self) -> None:
        from runtime.tools.gen_ts_types import Ctx, expr_for
        context = Ctx({}, "test-case-spec-bundle/v0.1")
        self.assertEqual(expr_for({"type": "integer", "minimum": 0, "maximum": 255}, context, "byte"),
                         "z.int().min(0).max(255)")
        self.assertEqual(expr_for({"type": "array", "items": {"type": "integer"},
                                   "minItems": 1, "maxItems": 128}, context, "cases"),
                         "z.array(z.int()).min(1).max(128)")
        self.assertEqual(expr_for({"type": "string", "minLength": 1,
                                   "maxLength": 240}, context, "title"),
                         "z.string().min(1).max(240)")

    def test_no_unsupported_marker_in_ts(self) -> None:
        with open(TS_FILE, encoding="utf-8") as fh:
            ts = fh.read()
        self.assertNotIn("UNSUPPORTED", ts)
        self.assertNotIn("z.unknown()", ts, "不应有兜底的 unknown 类型")

    def test_header_warns_not_to_edit_by_hand(self) -> None:
        with open(TS_FILE, encoding="utf-8") as fh:
            head = fh.read(400)
        self.assertIn("自动生成", head)
        self.assertIn("gen_ts_types.py", head)


class StructureTest(unittest.TestCase):
    def setUp(self) -> None:
        with open(TS_FILE, encoding="utf-8") as fh:
            self.ts = fh.read()
        with open(EX_FILE, encoding="utf-8") as fh:
            self.payload = json.load(fh)

    def test_every_contract_has_exported_schema_and_type(self) -> None:
        for cid, info in self.payload["contracts"].items():
            name = "".join(part[:1].upper() + part[1:]
                           for part in re.split(r"[^0-9A-Za-z]+", info["title"]) if part)
            cls = name + "Schema"
            with self.subTest(contract=cid):
                self.assertIn(f"export const {cls} =", self.ts)
                self.assertIn(f"export type {name} = z.infer<typeof {cls}>", self.ts)

    def test_every_property_appears_as_optional_or_required(self) -> None:
        """每个契约属性都必须在 TS 里出现一次（作为键），不能静默丢字段。"""
        for cid, info in self.payload["contracts"].items():
            required = set(info["required"])
            for prop in info["properties"]:
                with self.subTest(contract=cid, prop=prop):
                    # 注意必须显式 re.M：assertRegex 不接受 flags，^ 只会匹配文件开头
                    key = prop if re.match(r"^[A-Za-z_$][A-Za-z0-9_$]*$", prop) else f'"{prop}"'
                    found = re.search(rf"^\s*{re.escape(key)}: ", self.ts, re.M)
                    self.assertIsNotNone(found, f"{prop} 未出现在 TS 里")
            self.assertTrue(required <= set(info["properties"]))

    def test_contract_ids_match_validation_module(self) -> None:
        """TS 索引与 Python 权威校验入口必须认同一批契约 id。"""
        with open(VALIDATION_PY, encoding="utf-8") as fh:
            src = fh.read()
        ids = set(re.findall(r'"(?:urn:)?[a-z-]+/v0\.1"', src))
        ids = {i.strip('"') for i in ids}
        ts_ids = set(self.payload["contracts"])
        # validation.py 里以 schema_version 常量形式出现
        missing = {i for i in ts_ids if i not in ids and i.split("/")[-1] not in src}
        self.assertEqual(missing, set(),
                         f"这些契约 id 在 validation.py 里找不到对应：{missing}")

    def test_vocabularies_come_from_enums_registry(self) -> None:
        """TS 词汇表必须与 enums.json 一致（单一来源）。"""
        enums_path = os.path.join(PKG, "runtime", "contracts", "enums.json")
        with open(enums_path, encoding="utf-8") as fh:
            enums = json.load(fh)
        for vname, entry in enums["vocabularies"].items():
            camel = "".join(p[:1].upper() + p[1:]
                            for p in re.split(r"[^0-9A-Za-z]+", vname) if p)
            with self.subTest(vocab=vname):
                m = re.search(rf"export const {camel}Values = (\[.*?\]) as const;", self.ts)
                self.assertIsNotNone(m, f"TS 里缺少词汇表 {camel}Values")
                self.assertEqual(json.loads(m.group(1)), entry["values"])

    def test_strict_objects_used_for_closed_schemas(self) -> None:
        with open(os.path.join(PKG, "runtime", "contracts",
                              "gate_record.v0.1.schema.json"), encoding="utf-8") as fh:
            doc = json.load(fh)
        self.assertIs(doc.get("additionalProperties"), False)
        self.assertIn("z.strictObject", self.ts)

    def test_python_keyword_field_keeps_original_name(self) -> None:
        """`from` 在 Python 里要改写成 from_，在 TS 里是合法属性名 —— 必须保持原名。"""
        self.assertIsNotNone(
            re.search(r"^\s*from: ", self.ts, re.M),
            "TS 侧不应把 from 改名（JSON 侧字段名必须与 JSON 一致）")
        self.assertNotIn("from_:", self.ts)


@unittest.skipUnless(HAS_TOOLCHAIN,
                     "缺少 node / typescript / zod（安装在受管 node 工作区）")
class RealTypecheckAndRuntimeTest(unittest.TestCase):
    """真编译 + 真执行。这是本模块唯一能证明「类型是对的」的检查。"""

    @classmethod
    def setUpClass(cls) -> None:
        # 注意：不要对 BUILD_DIR 做 rmtree 批量删除 —— 编译产物 50+ 文件会触发
        # 本机 safe-delete 钩子的单轮批量删除阈值（实测导致门禁 unittest 阶段 FAIL）。
        # tsc 原地覆盖，无需清理。
        os.makedirs(BUILD_DIR, exist_ok=True)

    @classmethod
    def tearDownClass(cls) -> None:
        pass  # 同上：不批量删除，tsc 覆盖即可

    def _build(self, ts_source: str | None = None):
        """把 TS 复制进 node 工作区再编译 —— tsc 的类型解析从文件位置向上找 node_modules。"""
        work = os.path.join(BUILD_DIR, "src")
        out = os.path.join(BUILD_DIR, "out")
        os.makedirs(work, exist_ok=True)
        os.makedirs(out, exist_ok=True)
        os.makedirs(work, exist_ok=True)
        if ts_source is None:
            with open(TS_FILE, encoding="utf-8") as fh:
                ts_source = fh.read()
        with open(os.path.join(work, "schema_types.ts"), "w",
                  encoding="utf-8", newline="\n") as fh:
            fh.write(ts_source)
        proc = run([NODE, TSC, os.path.join(work, "schema_types.ts"),
                    "--outDir", out, "--module", "commonjs", "--target", "es2020",
                    "--strict", "--skipLibCheck", "--esModuleInterop"])
        return proc, out

    def _validate(self, out: str):
        return run([NODE, VALIDATOR, out, EX_FILE])

    def test_typechecks_and_validates(self) -> None:
        proc, out = self._build()
        self.assertEqual(proc.returncode, 0,
                         f"tsc 失败：{proc.stdout[-800:]}{proc.stderr[-400:]}")
        self.assertTrue(os.path.isfile(os.path.join(out, "schema_types.js")))

        v = self._validate(out)
        self.assertEqual(v.returncode, 0, f"zod 校验失败：{v.stdout[-1200:]}")
        self.assertIn("全部通过", v.stdout)
        m = re.search(r"实跑断言: (\d+) 条", v.stdout)
        self.assertIsNotNone(m, v.stdout)
        self.assertGreaterEqual(int(m.group(1)), 27)

    def test_validation_can_fail_on_permissive_schema(self) -> None:
        """证明这套校验**能失败**：把 strictObject 退化成 object，负向检查必须报错。"""
        with open(TS_FILE, encoding="utf-8") as fh:
            src = fh.read().replace("z.strictObject", "z.object")
        proc, out = self._build(src)
        self.assertEqual(proc.returncode, 0, proc.stderr[-400:])
        v = self._validate(out)
        self.assertNotEqual(v.returncode, 0, "宽松 schema 竟然通过了校验")
        self.assertIn("strictObject 失效", v.stdout)

    def test_validation_can_fail_on_wrong_literal(self) -> None:
        """证明正向检查也能失败：改错 schema_version 常量。"""
        with open(TS_FILE, encoding="utf-8") as fh:
            src = fh.read().replace(
                'z.literal("gate-record/v0.1")', 'z.literal("gate-record/v9.9")')
        proc, out = self._build(src)
        self.assertEqual(proc.returncode, 0, proc.stderr[-400:])
        v = self._validate(out)
        self.assertNotEqual(v.returncode, 0, "错误的 literal 竟然通过了校验")


if __name__ == "__main__":
    unittest.main()
