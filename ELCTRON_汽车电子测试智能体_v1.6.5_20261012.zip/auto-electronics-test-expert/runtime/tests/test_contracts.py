#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.2 契约校验器的回归测试。

测的是「门禁能不能失败」，而不只是「能不能通过」：
任何只测 happy path 的校验器都可能因为静默跳过而永远 PASS。

运行:
  python -m unittest discover -s runtime/tests -v
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))          # <包根>
VALIDATOR = os.path.join(PKG_ROOT, "runtime", "tools", "validate_contracts.py")

# 真源比对需要能解析到的既有资产（相对包根）
SOURCE_FILES = [
    "skills/uds-diagnostic-test/scripts/result_contract.py",
    "skills/uds-diagnostic-test/scripts/uds_case_gate.py",
    "skills/uds-diagnostic-test/scripts/flow_contract.py",
    "schemas/portable-contract-v0.1.json",
    "runtime/orchestrator/state.py",
]


def run_validator(root: str) -> subprocess.CompletedProcess:
    """跑校验器。不加 --quiet：断言需要看到错误文本，而不只是退出码。"""
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    return subprocess.run(
        [sys.executable, VALIDATOR, "--root", root],
        capture_output=True, text=True, encoding="utf-8", errors="replace", env=env,
    )


def load_json(path: str) -> dict:
    """读 JSON（UTF-8）。"""
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def save_json(path: str, data: dict) -> None:
    """写 JSON（UTF-8，ensure_ascii=False）。"""
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False)


class ContractValidationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp(prefix="aetex-contracts-")
        # 契约目录
        shutil.copytree(os.path.join(PKG_ROOT, "runtime", "contracts"),
                        os.path.join(self.tmp, "runtime", "contracts"))
        # 真源资产
        for rel in SOURCE_FILES:
            dst = os.path.join(self.tmp, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(os.path.join(PKG_ROOT, rel), dst)
        self.enums = os.path.join(self.tmp, "runtime", "contracts", "enums.json")

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    # ---------- happy path ----------
    def test_real_contracts_pass(self) -> None:
        """真实契约必须通过校验。"""
        proc = run_validator(PKG_ROOT)
        self.assertEqual(proc.returncode, 0, msg=proc.stdout + proc.stderr)

    def test_copied_root_also_passes(self) -> None:
        """复制的等价根目录也必须通过，证明校验不依赖绝对路径。"""
        proc = run_validator(self.tmp)
        self.assertEqual(proc.returncode, 0, msg=proc.stdout + proc.stderr)

    # ---------- 能失败：词汇表漂移 ----------
    def test_detects_vocabulary_drift_against_python(self) -> None:
        """契约擅自给 case_verdict 加值 -> 必须报错。"""
        data = load_json(self.enums)
        data["vocabularies"]["case_verdict"]["values"].append("INCONCLUSIVE")
        save_json(self.enums, data)
        proc = run_validator(self.tmp)
        self.assertEqual(proc.returncode, 1, msg="词汇表漂移未被检出")
        self.assertIn("case_verdict", proc.stderr + proc.stdout)

    def test_detects_missing_python_source(self) -> None:
        """真源文件缺失 -> 必须报错，不得静默跳过。"""
        os.remove(os.path.join(self.tmp, SOURCE_FILES[0]))
        proc = run_validator(self.tmp)
        self.assertEqual(proc.returncode, 1, msg="真源缺失未被检出")

    # ---------- 能失败：schema / 样本 ----------
    def test_detects_invalid_example(self) -> None:
        """故意弄坏一个 example -> 必须报错。"""
        path = os.path.join(self.tmp, "runtime", "contracts", "verdict_draft.v0.1.schema.json")
        data = load_json(path)
        data["examples"][0]["verdict"] = "NOT_A_VERDICT"
        save_json(path, data)
        proc = run_validator(self.tmp)
        self.assertEqual(proc.returncode, 1, msg="非法 sample 未被检出")

    def test_detects_schema_version_mismatch(self) -> None:
        """schema_version 常量与文件名不符 -> 必须报错。"""
        path = os.path.join(self.tmp, "runtime", "contracts", "task_state.v0.1.schema.json")
        data = load_json(path)
        data["properties"]["schema_version"]["const"] = "task-state/v9.9"
        save_json(path, data)
        proc = run_validator(self.tmp)
        self.assertEqual(proc.returncode, 1, msg="schema_version 不一致未被检出")

    def test_detects_unregistered_vocabulary_reference(self) -> None:
        """引用未注册词汇表 -> 必须报错。"""
        path = os.path.join(self.tmp, "runtime", "contracts", "gate_record.v0.1.schema.json")
        data = load_json(path)
        data["properties"]["status"]["x-enum-vocabulary"] = "no_such_vocab"
        save_json(path, data)
        proc = run_validator(self.tmp)
        self.assertEqual(proc.returncode, 1, msg="未注册词汇表引用未被检出")


if __name__ == "__main__":
    unittest.main(verbosity=2)
