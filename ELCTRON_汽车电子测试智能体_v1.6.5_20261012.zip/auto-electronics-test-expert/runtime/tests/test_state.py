#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.4 / T1.5 状态机与条件边语义的回归测试。

重点不是「能跑通」，而是把红线钉死在测试里：
  * 只有 Terra 能写状态；
  * 跳过中间状态、反向迁移一律非法；
  * 只有 PASS 能进执行子图；
  * 证据不完整绝不可能得出 PASS。

运行:
  python -m unittest discover -s runtime/tests -v
"""
from __future__ import annotations

import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
for p in (PKG_ROOT,):
    if p not in sys.path:
        sys.path.insert(0, p)

from runtime.orchestrator import state as S  # noqa: E402

CONTRACTS = os.path.join(PKG_ROOT, "runtime", "contracts")


def schema_enums(vocab: str) -> set[str]:
    """从契约文件里收集某个词汇表实际出现的全部取值。"""
    found: set[str] = set()
    for name in sorted(os.listdir(CONTRACTS)):
        if not name.endswith(".schema.json"):
            continue
        with open(os.path.join(CONTRACTS, name), encoding="utf-8") as fh:
            doc = json.load(fh)
        _walk(doc, vocab, found)
    return found


def _walk(node, vocab: str, found: set[str]) -> None:
    if isinstance(node, dict):
        if node.get("x-enum-vocabulary") == vocab and isinstance(node.get("enum"), list):
            found.update(node["enum"])
        for v in node.values():
            _walk(v, vocab, found)
    elif isinstance(node, list):
        for v in node:
            _walk(v, vocab, found)


class VocabularySourceOfTruthTest(unittest.TestCase):
    """state.py 是运行时词汇表的唯一真源 —— 契约里的取值必须是它的子集。"""

    CASES = [
        ("task_state", S.TaskState),
        ("gate_status", S.GateStatus),
        ("node_status", S.NodeStatus),
        ("run_final_verdict", S.RunFinalVerdict),
        ("risk_level", S.RiskLevel),
        ("evidence_kind", S.EvidenceKind),
        ("memory_kind", S.MemoryKind),
        ("approval_status", S.ApprovalStatus),
        ("agent_role", S.AgentRole),
        ("graph_node", S.GraphNode),
    ]

    def test_contract_enums_come_from_state_py(self) -> None:
        for vocab, enum_cls in self.CASES:
            with self.subTest(vocab=vocab):
                declared = {m.value for m in enum_cls}
                used = schema_enums(vocab)
                self.assertTrue(used, f"{vocab} 未被任何 schema 引用")
                self.assertLessEqual(used, declared,
                                     f"{vocab} 在 schema 里出现未声明的取值：{sorted(used - declared)}")

    def test_enums_json_points_at_state_py(self) -> None:
        with open(os.path.join(CONTRACTS, "enums.json"), encoding="utf-8") as fh:
            reg = json.load(fh)
        for vocab, enum_cls in self.CASES:
            with self.subTest(vocab=vocab):
                entry = reg["vocabularies"][vocab]
                self.assertEqual(entry["status"], "existing")
                self.assertIn("runtime/orchestrator/state.py", entry["source_of_truth"])
                self.assertIn(enum_cls.__name__, entry["source_of_truth"])

    def test_no_vocabulary_left_unbacked(self) -> None:
        """不允许存在「没有代码真源」的词汇表。"""
        with open(os.path.join(CONTRACTS, "enums.json"), encoding="utf-8") as fh:
            reg = json.load(fh)
        leftovers = [n for n, e in reg["vocabularies"].items() if e.get("status") == "new"]
        self.assertEqual(leftovers, [], f"仍有词汇表没有代码真源：{leftovers}")


class TransitionTest(unittest.TestCase):
    def test_main_chain_forward_is_legal(self) -> None:
        for a, b in zip(S.MAIN_CHAIN, S.MAIN_CHAIN[1:]):
            with self.subTest(frm=a.value, to=b.value):
                self.assertTrue(S.can_transition(a, b))
                self.assertIsNotNone(S.assert_transition(a, b))

    def test_skipping_states_is_illegal(self) -> None:
        """不能跳过静态门禁直接进执行 —— 这是最基本的禁令。"""
        with self.assertRaises(S.IllegalTransition):
            S.assert_transition(S.TaskState.DESIGNED, S.TaskState.RUNNING)

    def test_backward_without_rollback_rule_is_illegal(self) -> None:
        with self.assertRaises(S.IllegalTransition):
            S.assert_transition(S.TaskState.RUNNING, S.TaskState.DESIGNED)

    def test_declared_rollbacks_are_legal(self) -> None:
        self.assertIsNone(S.assert_transition(S.TaskState.CAPTURED, S.TaskState.DESIGNED))
        self.assertIsNone(S.assert_transition(S.TaskState.ASSESSED, S.TaskState.CAPTURED))

    def test_self_transition_is_illegal(self) -> None:
        for st in S.TaskState:
            with self.subTest(state=st.value):
                self.assertFalse(S.can_transition(st, st))

    def test_only_terra_writes_state(self) -> None:
        """红线 R1：所有迁移的写入者必须是 terra。"""
        for frm, rules in S.TRANSITIONS.items():
            for rule in rules:
                with self.subTest(frm=frm.value, to=rule.to_state.value):
                    self.assertIs(rule.writer, S.AgentRole.TERRA)

    def test_workers_submit_events_not_states(self) -> None:
        """主链推进由 worker 提交事件；只有 Terra 自己的签核环节例外。"""
        exceptions = []
        for frm, rules in S.TRANSITIONS.items():
            for rule in rules:
                if rule.event_submitter is S.AgentRole.TERRA:
                    exceptions.append((frm.value, rule.to_state.value))
        self.assertEqual(exceptions, [("ASSESSED", "CLOSED")],
                         f"只有 ASSESSED->CLOSED 应由 Terra 自己提交，实际例外：{exceptions}")

    def test_terminal_state_has_no_outgoing(self) -> None:
        self.assertTrue(S.is_terminal(S.TaskState.CLOSED))
        self.assertEqual(S.next_states(S.TaskState.CLOSED), ())
        self.assertTrue(all(not S.is_terminal(s) for s in S.TaskState if s is not S.TaskState.CLOSED))

    def test_every_state_reachable_in_main_chain(self) -> None:
        for st in S.TaskState:
            with self.subTest(state=st.value):
                self.assertIn(st, S.MAIN_CHAIN)
                self.assertIn(st, S.TRANSITIONS)

    def test_unknown_state_raises(self) -> None:
        with self.assertRaises(S.IllegalTransition):
            S.can_transition("NOT_A_STATE", S.TaskState.NEW)

    def test_only_static_passed_enters_execution(self) -> None:
        self.assertEqual(S.EXECUTION_ENTRY_STATES, frozenset({S.TaskState.STATIC_PASSED}))


class ConditionalEdgeTest(unittest.TestCase):
    def test_only_pass_may_enter_execution(self) -> None:
        for g in S.GateStatus:
            with self.subTest(gate=g.value):
                self.assertEqual(S.may_enter_execution(g), g is S.GateStatus.PASS)

    def test_blocking_set_is_exactly_the_complement_of_pass(self) -> None:
        self.assertEqual(
            S.EXECUTION_BLOCKING_GATES,
            frozenset(g for g in S.GateStatus if g is not S.GateStatus.PASS),
        )

    def test_human_intervention_only_for_review_and_blocked(self) -> None:
        self.assertEqual(S.HUMAN_INTERVENTION_GATES,
                         frozenset({S.GateStatus.REVIEW_REQUIRED, S.GateStatus.BLOCKED}))

    def test_unknown_gate_raises(self) -> None:
        with self.assertRaises(ValueError):
            S.may_enter_execution("MAYBE")


class FinalVerdictTest(unittest.TestCase):
    """红线 R5 的代码化：证据不足只能 INCONCLUSIVE。"""

    def test_aborted_produces_no_verdict(self) -> None:
        self.assertIsNone(S.derive_final_verdict(["PASS"], evidence_complete=True, aborted=True))

    def test_blocked_case_prevents_closing(self) -> None:
        self.assertIsNone(S.derive_final_verdict(["PASS", "BLOCKED"], evidence_complete=True))

    def test_no_cases_produces_no_verdict(self) -> None:
        self.assertIsNone(S.derive_final_verdict([], evidence_complete=True))

    def test_incomplete_evidence_never_pass(self) -> None:
        for verdicts in (["PASS"], ["PASS", "PASS"], ["FAIL"], ["NA"], ["SKIP"]):
            with self.subTest(verdicts=verdicts):
                self.assertIs(S.derive_final_verdict(verdicts, evidence_complete=False),
                              S.RunFinalVerdict.INCONCLUSIVE)

    def test_unresolved_forces_inconclusive(self) -> None:
        self.assertIs(S.derive_final_verdict(["PASS"], evidence_complete=True,
                                             unresolved=["无法区分帧未发出与帧未被接收"]),
                      S.RunFinalVerdict.INCONCLUSIVE)

    def test_fail_wins_over_pass(self) -> None:
        self.assertIs(S.derive_final_verdict(["PASS", "FAIL"], evidence_complete=True),
                      S.RunFinalVerdict.FAIL)

    def test_clean_pass(self) -> None:
        self.assertIs(S.derive_final_verdict(["PASS", "NA", "SKIP"], evidence_complete=True),
                      S.RunFinalVerdict.PASS)

    def test_all_na_or_skip_is_inconclusive(self) -> None:
        self.assertIs(S.derive_final_verdict(["NA", "SKIP"], evidence_complete=True),
                      S.RunFinalVerdict.INCONCLUSIVE)

    def test_lowercase_input_is_normalised(self) -> None:
        self.assertIs(S.derive_final_verdict(["pass"], evidence_complete=True),
                      S.RunFinalVerdict.PASS)

    def test_blank_unresolved_entries_ignored(self) -> None:
        self.assertIs(S.derive_final_verdict(["PASS"], evidence_complete=True,
                                             unresolved=["", "   "]),
                      S.RunFinalVerdict.PASS)


if __name__ == "__main__":
    unittest.main(verbosity=2)
