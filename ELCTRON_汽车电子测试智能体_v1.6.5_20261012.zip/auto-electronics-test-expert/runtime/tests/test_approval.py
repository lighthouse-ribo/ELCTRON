#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.8 审批令牌回归测试（红线 R6）。

重点覆盖**越权与过期**：模型自批、跨 run 复用、越范围执行、过期复用、令牌带密钥。
"""
from __future__ import annotations

import os
import sys
import unittest
from dataclasses import replace
from datetime import timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.orchestrator import approval as A  # noqa: E402
from runtime.orchestrator.state import AgentRole, ApprovalStatus, RiskLevel  # noqa: E402

REF = "credential://aetex/bbs-p519/swdl-sbl"


def make_token(**over):
    """构造一个默认有效的审批令牌。"""
    base = dict(
        token_id="TOK-0001",
        order_id="ORD-0001",
        run_id="RUN-0001",
        actions=["0x10", "0x27", "0x34"],
        valid_from=A.now_utc() - timedelta(minutes=5),
        valid_until=A.now_utc() + timedelta(minutes=55),
        approved_by=AgentRole.HUMAN_APPROVER,
        credential_ref=REF,
        scope_note="SBL 下载，隔离台架",
    )
    base.update(over)
    return A.issue(**base)


def make_order(**over):
    """构造一个最小 ApprovedOrder。"""
    base = {
        "schema_version": "approved-order/v0.1",
        "order_id": "ORD-0001",
        "run_id": "RUN-0001",
        "flow": "swdl",
        "scope": {"services": ["0x10", "0x27"], "partitions": ["SBL"]},
        "risk_level": "CRITICAL",
        "plan_sha256": "d" * 64,
        "approval_token_ref": REF,
        "approval_status": "approved",
        "valid_from": "2026-09-16T01:00:00Z",
        "valid_until": "2026-09-16T03:00:00Z",
        "issued_by": "terra",
        "approved_by": "human_approver",
        "reversible": False,
        "minimal_retest_required": True,
    }
    base.update(over)
    return base


class IssueTest(unittest.TestCase):
    def test_only_human_can_issue(self) -> None:
        for role in (AgentRole.TERRA, AgentRole.PLAN_WORKER,
                     AgentRole.EXECUTION_WORKER, AgentRole.EVIDENCE_WORKER):
            with self.subTest(role=role.value):
                with self.assertRaises(A.ApprovalError) as ctx:
                    make_token(approved_by=role)
                self.assertEqual(ctx.exception.reason, "NOT_HUMAN_APPROVER")

    def test_empty_scope_rejected(self) -> None:
        with self.assertRaises(A.ApprovalError) as ctx:
            make_token(actions=[])
        self.assertEqual(ctx.exception.reason, "EMPTY_SCOPE")

    def test_bad_window_rejected(self) -> None:
        now = A.now_utc()
        with self.assertRaises(A.ApprovalError) as ctx:
            make_token(valid_from=now, valid_until=now)
        self.assertEqual(ctx.exception.reason, "BAD_WINDOW")

    def test_bad_credential_ref_rejected(self) -> None:
        for bad in ("C:/keys/swdl.json", "plain-key-name", "credential://"):
            with self.subTest(ref=bad):
                with self.assertRaises(A.ApprovalError) as ctx:
                    make_token(credential_ref=bad)
                self.assertEqual(ctx.exception.reason, "BAD_CREDENTIAL_REF")

    def test_secret_material_rejected(self) -> None:
        with self.assertRaises(A.ApprovalError) as ctx:
            make_token(scope_note="-----BEGIN RSA PRIVATE KEY-----")
        self.assertEqual(ctx.exception.reason, "SECRET_IN_TOKEN")

    def test_hex_key_material_rejected(self) -> None:
        with self.assertRaises(A.ApprovalError) as ctx:
            make_token(scope_note="a1b2c3d4e5f60718293a4b5c6d7e8f90")
        self.assertEqual(ctx.exception.reason, "SECRET_IN_TOKEN")


class CheckTest(unittest.TestCase):
    def test_no_token_is_rejected(self) -> None:
        self.assertEqual(A.check(None, run_id="RUN-0001", action="0x10"),
                         (False, "NO_TOKEN"))

    def test_valid_token_passes(self) -> None:
        tok = make_token()
        self.assertEqual(A.check(tok, run_id="RUN-0001", action="0x10"), (True, "OK"))
        A.verify(tok, run_id="RUN-0001", action="0x10")

    def test_cross_run_reuse_rejected(self) -> None:
        tok = make_token()
        self.assertEqual(A.check(tok, run_id="RUN-0002", action="0x10")[1], "RUN_MISMATCH")
        with self.assertRaises(A.ApprovalError):
            A.verify(tok, run_id="RUN-0002", action="0x10")

    def test_action_out_of_scope_rejected(self) -> None:
        tok = make_token(actions=["0x10"])
        self.assertEqual(A.check(tok, run_id="RUN-0001", action="0x34")[1], "ACTION_NOT_GRANTED")

    def test_expired_token_rejected(self) -> None:
        now = A.now_utc()
        tok = make_token(valid_from=now - timedelta(hours=2), valid_until=now - timedelta(hours=1))
        self.assertEqual(A.check(tok, run_id="RUN-0001", action="0x10")[1], "EXPIRED")
        self.assertIs(A.effective_status(tok), ApprovalStatus.EXPIRED)

    def test_not_yet_valid_rejected(self) -> None:
        now = A.now_utc()
        tok = make_token(valid_from=now + timedelta(hours=1), valid_until=now + timedelta(hours=2))
        self.assertEqual(A.check(tok, run_id="RUN-0001", action="0x10")[1], "NOT_YET_VALID")
        self.assertIs(A.effective_status(tok), ApprovalStatus.PENDING)

    def test_boundary_is_inclusive(self) -> None:
        now = A.now_utc()
        tok = make_token(valid_from=now, valid_until=now + timedelta(minutes=1))
        self.assertEqual(A.check(tok, run_id="RUN-0001", action="0x10", at=now)[1], "OK")
        self.assertEqual(A.check(tok, run_id="RUN-0001", action="0x10",
                                 at=now + timedelta(minutes=1))[1], "OK")

    def test_revoked_and_rejected(self) -> None:
        for status, reason in ((ApprovalStatus.REVOKED, "REVOKED"),
                               (ApprovalStatus.REJECTED, "REJECTED"),
                               (ApprovalStatus.PENDING, "NOT_APPROVED")):
            with self.subTest(status=status.value):
                tok = replace(make_token(), status=status)
                self.assertEqual(A.check(tok, run_id="RUN-0001", action="0x10")[1], reason)

    def test_expired_status_field_is_rejected(self) -> None:
        tok = replace(make_token(), status=ApprovalStatus.EXPIRED)
        self.assertEqual(A.check(tok, run_id="RUN-0001", action="0x10")[1], "EXPIRED")


class RequiredApproverTest(unittest.TestCase):
    def test_high_and_critical_need_human(self) -> None:
        for level in (RiskLevel.HIGH, RiskLevel.CRITICAL):
            with self.subTest(level=level.value):
                self.assertIs(A.required_approver(level, reversible=True), AgentRole.HUMAN_APPROVER)

    def test_irreversible_needs_human_even_if_low_risk(self) -> None:
        self.assertIs(A.required_approver(RiskLevel.LOW, reversible=False), AgentRole.HUMAN_APPROVER)

    def test_low_risk_reversible_can_be_signed_by_terra(self) -> None:
        self.assertIs(A.required_approver(RiskLevel.LOW, reversible=True), AgentRole.TERRA)


class ApprovedOrderLinkTest(unittest.TestCase):
    def test_consistent_order_and_token_pass(self) -> None:
        tok = make_token()
        self.assertEqual(A.validate_approved_order(make_order(), tok), [])

    def test_missing_token_blocks_order(self) -> None:
        errors = A.validate_approved_order(make_order(), None)
        self.assertTrue(any("缺少审批令牌" in e for e in errors), errors)

    def test_run_mismatch_detected(self) -> None:
        tok = make_token(run_id="RUN-9999")
        errors = A.validate_approved_order(make_order(), tok)
        self.assertTrue(any("绑定 run" in e for e in errors), errors)

    def test_ref_mismatch_detected(self) -> None:
        tok = make_token(credential_ref="credential://aetex/other")
        errors = A.validate_approved_order(make_order(), tok)
        self.assertTrue(any("不一致" in e for e in errors), errors)

    def test_service_outside_token_scope_detected(self) -> None:
        tok = make_token(actions=["0x10"])
        errors = A.validate_approved_order(make_order(), tok)
        self.assertTrue(any("不在令牌授权范围" in e for e in errors), errors)

    def test_critical_order_needs_human_token(self) -> None:
        """CRITICAL 且不可逆时，即便有令牌，签发人不是人工也必须拦。"""
        tok = replace(make_token(), approved_by=AgentRole.TERRA)   # 模拟伪造
        errors = A.validate_approved_order(make_order(), tok)
        self.assertTrue(any("必须人工审批" in e for e in errors), errors)

    def test_schema_violation_surfaces(self) -> None:
        errors = A.validate_approved_order(make_order(risk_level="SUPER_HIGH"), make_token())
        self.assertTrue(any(e.startswith("schema:") for e in errors), errors)

    def test_secret_ref_in_order_detected(self) -> None:
        errors = A.validate_approved_order(make_order(approval_token_ref="-----BEGIN RSA PRIVATE KEY-----"),
                                           make_token())
        self.assertTrue(any("原始密钥材料" in e for e in errors), errors)


class SerialisationTest(unittest.TestCase):
    def test_public_dict_has_no_secret_and_round_trips(self) -> None:
        tok = make_token()
        pub = tok.to_public_dict()
        text = str(pub).lower()
        for banned in ("private key", "secret", "password", "token_value"):
            self.assertNotIn(banned, text)
        self.assertEqual(A.ApprovalToken.from_dict(pub), tok)

    def test_iso_format_round_trip(self) -> None:
        tok = make_token()
        pub = tok.to_public_dict()
        self.assertTrue(pub["valid_until"].endswith("Z"))
        self.assertEqual(A.ApprovalToken.from_dict(pub).valid_until, tok.valid_until)


if __name__ == "__main__":
    unittest.main(verbosity=2)
