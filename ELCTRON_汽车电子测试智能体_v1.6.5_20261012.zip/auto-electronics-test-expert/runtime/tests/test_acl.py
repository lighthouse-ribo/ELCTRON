#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.6 目录 ACL 与单写者矩阵的回归测试。

重点：证明越权**会被拦住**，而不是证明合法路径能通过。
凡是只在 happy path 上验证过的权限系统，等于没有权限系统。

运行:
  python -m unittest discover -s runtime/tests -v
"""
from __future__ import annotations

import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.orchestrator import acl  # noqa: E402
from runtime.orchestrator.state import AgentRole, GraphNode  # noqa: E402

CONTRACTS = os.path.join(PKG_ROOT, "runtime", "contracts")


class PathSafetyTest(unittest.TestCase):
    SAFE = [
        "02_plan/draft_plan.json",
        "01_command/input_inspection.json",
        "03_execution/traces/session_001.asc",
        "05_final/final_verdict.json",
    ]
    UNSAFE = [
        "/etc/passwd",
        "C:/Windows/system32/x.dll",
        "C:\\Windows\\x.dll",
        "02_plan/../03_execution/x.json",
        "../outside.json",
        "02_plan/./x.json",
        "02_plan//x.json",
        "02_plan/",
        "/02_plan/x.json",
        "",
        "  02_plan/x.json",
        "02_plan/x.json  ",
        "02_plan/x.json\n",
    ]

    def test_safe_paths_accepted(self) -> None:
        for p in self.SAFE:
            with self.subTest(path=p):
                self.assertTrue(acl.is_safe_relpath(p))
                self.assertIn(acl.dir_of(p), acl.RUN_DIRS)

    def test_unsafe_paths_rejected(self) -> None:
        """绝对路径、盘符、反斜杠、路径穿越必须全部拒绝。"""
        for p in self.UNSAFE:
            with self.subTest(path=p):
                self.assertFalse(acl.is_safe_relpath(p), f"{p!r} 应被判为不安全")
                with self.assertRaises(acl.AclViolation):
                    acl.dir_of(p)

    def test_traversal_cannot_escape_run_dir(self) -> None:
        """即使首段看起来合法，`..` 也必须被拦。"""
        self.assertFalse(acl.is_safe_relpath("02_plan/../../05_final/x.json"))
        self.assertFalse(acl.can_write(AgentRole.PLAN_WORKER, "02_plan/../../05_final/x.json"))


class SingleWriterMatrixTest(unittest.TestCase):
    def test_role_to_dirs_exactly_as_designed(self) -> None:
        self.assertEqual(acl.dirs_for(AgentRole.TERRA), frozenset({"01_command", "05_final"}))
        self.assertEqual(acl.dirs_for(AgentRole.PLAN_WORKER), frozenset({"02_plan"}))
        self.assertEqual(acl.dirs_for(AgentRole.EXECUTION_WORKER), frozenset({"03_execution"}))
        self.assertEqual(acl.dirs_for(AgentRole.EVIDENCE_WORKER), frozenset({"04_evidence"}))
        self.assertEqual(acl.dirs_for(AgentRole.HUMAN_APPROVER), frozenset())

    def test_every_role_is_registered(self) -> None:
        for role in AgentRole:
            with self.subTest(role=role.value):
                self.assertIn(role, acl.ROLE_DIRS)

    def test_worker_cannot_write_other_workers_dir(self) -> None:
        """计划 worker 写执行目录必须被拒 —— 这是最典型的越权。"""
        with self.assertRaises(acl.AclViolation):
            acl.assert_write(AgentRole.PLAN_WORKER, "03_execution/run_manifest.json")
        with self.assertRaises(acl.AclViolation):
            acl.assert_write(AgentRole.EXECUTION_WORKER, "02_plan/draft_plan.json")
        with self.assertRaises(acl.AclViolation):
            acl.assert_write(AgentRole.EVIDENCE_WORKER, "03_execution/traces/a.asc")

    def test_terra_cannot_write_execution_dir(self) -> None:
        """Terra 能写命令与最终结论，但不能碰执行目录。"""
        self.assertTrue(acl.can_write(AgentRole.TERRA, "01_command/request.json"))
        self.assertTrue(acl.can_write(AgentRole.TERRA, "05_final/final_verdict.json"))
        self.assertFalse(acl.can_write(AgentRole.TERRA, "03_execution/traces/a.asc"))
        self.assertFalse(acl.can_write(AgentRole.TERRA, "02_plan/draft_plan.json"))

    def test_human_approver_writes_nothing_in_run_dir(self) -> None:
        for d in acl.RUN_DIRS:
            with self.subTest(dir=d):
                self.assertFalse(acl.can_write(AgentRole.HUMAN_APPROVER, f"{d}/x.json"))

    def test_unknown_dir_rejected(self) -> None:
        with self.assertRaises(acl.AclViolation):
            acl.assert_write(AgentRole.TERRA, "06_extra/x.json")

    def test_unknown_role_and_node_raise(self) -> None:
        with self.assertRaises(acl.AclViolation):
            acl.assert_write("not_a_role", "01_command/x.json")
        with self.assertRaises(acl.AclViolation):
            acl.dirs_for_node("not_a_node")


class NodeBindingTest(unittest.TestCase):
    def test_every_node_is_registered(self) -> None:
        for node in GraphNode:
            with self.subTest(node=node.value):
                self.assertIn(node, acl.NODE_DIRS)
                self.assertIn(node, acl.NODE_ROLES)
                self.assertTrue(acl.NODE_DIRS[node], "节点不允许任何目录，等于没法产出工件")

    def test_node_dir_is_unique_per_role(self) -> None:
        """每个 (节点, 角色) 组合必须能唯一定位一个目录。"""
        for node in GraphNode:
            for role in acl.NODE_ROLES[node]:
                with self.subTest(node=node.value, role=role.value):
                    d = acl.node_dir(node, role)
                    self.assertIn(d, acl.NODE_DIRS[node])
                    self.assertIn(d, acl.ROLE_DIRS[role])

    def test_terra_has_no_dir_for_worker_only_nodes(self) -> None:
        """Terra 不是 inspect_inputs 的产出角色，不应有可写目录。"""
        with self.assertRaises(acl.AclViolation):
            acl.node_dir(GraphNode.INSPECT_INPUTS, AgentRole.TERRA)

    def test_hardware_node_maps_to_execution_and_evidence(self) -> None:
        self.assertEqual(acl.node_dir(GraphNode.HARDWARE_GATE_AND_EXECUTE,
                                      AgentRole.EXECUTION_WORKER), "03_execution")
        self.assertEqual(acl.node_dir(GraphNode.HARDWARE_GATE_AND_EXECUTE,
                                      AgentRole.EVIDENCE_WORKER), "04_evidence")

    def test_node_and_dir_enums_match_contracts(self) -> None:
        """ACL 里写的节点名与目录名必须与契约 schema 完全一致。"""
        with open(os.path.join(CONTRACTS, "node_result.v0.1.schema.json"), encoding="utf-8") as fh:
            schema = json.load(fh)
        props = schema["properties"]
        self.assertEqual(set(props["node"]["enum"]), {n.value for n in GraphNode})
        self.assertEqual(set(props["writes_to"]["enum"]), set(acl.RUN_DIRS))


class NodeResultValidationTest(unittest.TestCase):
    def _sample(self, **overrides) -> dict:
        base = {
            "schema_version": "node-result/v0.1",
            "run_id": "RUN-0001",
            "node": "static_gate",
            "status": "OK",
            "produced_at": "2026-09-15T06:12:00Z",
            "produced_by": "plan_worker",
            "writes_to": "02_plan",
            "artifact_path": "02_plan/static_gate.record.json",
            "sha256": "b" * 64,
            "summary": "lint 与脚本审查均通过。",
            "gate_status": "PASS",
        }
        base.update(overrides)
        return base

    def test_contract_example_passes(self) -> None:
        with open(os.path.join(CONTRACTS, "node_result.v0.1.schema.json"), encoding="utf-8") as fh:
            example = json.load(fh)["examples"][0]
        self.assertEqual(acl.validate_node_result(example), [])

    def test_valid_sample_passes(self) -> None:
        self.assertEqual(acl.validate_node_result(self._sample()), [])

    def test_wrong_dir_for_node_rejected(self) -> None:
        errs = acl.validate_node_result(self._sample(writes_to="03_execution"))
        self.assertTrue(any("writes_to" in e for e in errs), errs)

    def test_wrong_role_for_node_rejected(self) -> None:
        errs = acl.validate_node_result(self._sample(produced_by="evidence_worker"))
        self.assertTrue(any("不允许由" in e for e in errs), errs)

    def test_artifact_path_must_match_writes_to(self) -> None:
        errs = acl.validate_node_result(self._sample(artifact_path="03_execution/x.json"))
        self.assertTrue(any("首段" in e for e in errs), errs)

    def test_traversal_in_artifact_path_rejected(self) -> None:
        errs = acl.validate_node_result(self._sample(artifact_path="02_plan/../05_final/x.json"))
        self.assertTrue(any("非法" in e or "首段" in e for e in errs), errs)

    def test_schema_violation_surfaces_too(self) -> None:
        """越权的 payload 同时也会被 schema 拦（枚举不允许 06_extra）。"""
        errs = acl.validate_node_result(self._sample(writes_to="06_extra"))
        self.assertTrue(errs)
        self.assertTrue(any(e.startswith("schema:") for e in errs), errs)

    def test_can_skip_schema_check(self) -> None:
        errs = acl.validate_node_result(self._sample(writes_to="06_extra"), check_schema=False)
        self.assertTrue(errs)
        self.assertFalse(any(e.startswith("schema:") for e in errs), errs)


if __name__ == "__main__":
    unittest.main(verbosity=2)
