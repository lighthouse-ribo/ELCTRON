"""Model selection remains runtime-owned, secret-free, and fail-closed."""
from __future__ import annotations

import os
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.agents.model_invokers import (  # noqa: E402
    CodexHeadInvoker,
    DeepSeekWorkerInvoker,
    ModelInvocationError,
    ModelInvokerFactory,
    _prompt,
)
from runtime.agents.runner import AgentInvocation  # noqa: E402
from runtime.agents.swdl_uds import profile_for  # noqa: E402
from runtime.config_layer import ConfigError, RuntimeConfig, load_runtime_config  # noqa: E402
from runtime.orchestrator import runtime_cli  # noqa: E402
from runtime.orchestrator.production_nodes import production_nodes  # noqa: E402
from runtime.orchestrator.state import GraphNode  # noqa: E402


class ModelInvokerFactoryTest(unittest.TestCase):
    def _config(self) -> RuntimeConfig:
        return RuntimeConfig(
            model_default_route="worker",
            model_profile_routes=(("swdl-uds-test-designer", "head"),),
            worker_base_url="https://worker.example/v1",
            worker_model="deepseek-flash",
            worker_credential_env="TEST_WORKER_KEY",
            head_command="missing-codex-for-test",
            head_model="head-model",
        )

    def test_profile_route_selects_head_or_worker_without_exposing_secret(self):
        factory = ModelInvokerFactory(self._config(), env={"TEST_WORKER_KEY": "not-returned"})
        self.assertIsInstance(factory.for_profile("swdl-uds-input-inspector"), DeepSeekWorkerInvoker)
        self.assertIsInstance(factory.for_profile("swdl-uds-test-designer"), CodexHeadInvoker)
        self.assertIsInstance(factory.for_profile("swdl-uds-script-reviewer"), DeepSeekWorkerInvoker)
        public = factory.public_config()
        self.assertTrue(public["worker"]["credential_present"])
        self.assertNotIn("not-returned", repr(public))

    def test_worker_without_credential_fails_before_network(self):
        factory = ModelInvokerFactory(self._config(), env={})
        invocation = AgentInvocation(profile_for("swdl-uds-input-inspector"), "RUN-MODEL-001", "UDS", ())
        with self.assertRaisesRegex(ModelInvocationError, "WORKER_CREDENTIAL_MISSING:TEST_WORKER_KEY"):
            factory.for_profile("swdl-uds-input-inspector").invoke(invocation)

    def test_model_prompt_contains_business_guidance_but_not_source_paths(self):
        invocation = AgentInvocation(profile_for("swdl-uds-test-designer"), "RUN-MODEL-002", "UDS", (),
                                     business_guidance={"rules": [{"id": "W-UDS-03", "directive": "SID"}]})
        rendered = _prompt(invocation)
        self.assertIn("business_guidance", rendered)
        self.assertIn("W-UDS-03", rendered)
        self.assertNotIn("skills/", rendered)

    def test_models_config_accepts_only_env_reference_and_valid_route(self):
        config = load_runtime_config(env={
            "AETEX_MODEL_DEFAULT_ROUTE": "head",
            "AETEX_DEEPSEEK_MODEL": "deepseek-flash",
            "AETEX_DEEPSEEK_CREDENTIAL_ENV": "LOCAL_DEEPSEEK_KEY",
        })
        self.assertEqual(config.model_default_route, "head")
        self.assertEqual(config.worker_credential_env, "LOCAL_DEEPSEEK_KEY")
        with self.assertRaisesRegex(ConfigError, "models.default_route"):
            load_runtime_config(env={"AETEX_MODEL_DEFAULT_ROUTE": "anything-else"})

    def test_runtime_cli_is_the_injection_boundary(self):
        invokers = {"swdl-uds-test-designer": object()}

        class FakeFactory:
            profiles = None

            def __init__(self, _config):
                pass

            def for_profiles(self, profiles):
                FakeFactory.profiles = profiles
                return invokers

        with patch.object(runtime_cli, "ModelInvokerFactory", FakeFactory):
            nodes = runtime_cli._nodes_for_runtime()
        self.assertEqual(FakeFactory.profiles[1].name, "swdl-uds-test-designer")
        self.assertEqual(FakeFactory.profiles[2].name, "swdl-uds-script-reviewer")
        self.assertIn(GraphNode.GENERATE_OR_DESIGN, nodes)

    def test_canviex_is_injected_only_for_exact_adapter_and_lin1(self):
        enabled = RuntimeConfig(adapter="canviex-f1l1", channels=("LIN1",))
        disabled = RuntimeConfig(adapter="canviex-f1l1", channels=("CAN1",))
        with patch.object(runtime_cli, "load_runtime_config", return_value=enabled):
            enabled_nodes = runtime_cli._nodes_for_runtime()
        with patch.object(runtime_cli, "load_runtime_config", return_value=disabled):
            disabled_nodes = runtime_cli._nodes_for_runtime()
        self.assertNotEqual(enabled_nodes[GraphNode.HARDWARE_GATE_AND_EXECUTE].__name__, "_execute")
        self.assertEqual(disabled_nodes[GraphNode.HARDWARE_GATE_AND_EXECUTE].__name__, "_execute")

    def test_runtime_cli_passes_only_controlled_manifest_to_graph(self):
        class DraftInvoker:
            def invoke(self, _request):
                from runtime.agents.runner import AgentDraft
                return AgentDraft("只读草案", {"target_platform": "vickcan-python", "cases": [{
                    "case_id": "UDS-CLI-001", "procedure": "发送 22 F1 90", "expected": "62 F1 90 正响应",
                    "precondition": "默认会话",
                }]})

        with tempfile.TemporaryDirectory() as input_root, tempfile.TemporaryDirectory() as run_dir:
            source = os.path.join(input_root, "requirements.txt")
            with open(source, "w", encoding="utf-8") as handle:
                handle.write("UDS requirements")
            nodes = production_nodes(agent_invokers={"swdl-uds-test-designer": DraftInvoker()})
            with patch.object(runtime_cli, "_nodes_for_runtime", return_value=nodes):
                result = runtime_cli.handle({
                    "action": "start", "run_id": "RUN-CLI-MODEL-001", "run_dir": run_dir,
                    "flow": "SWDL UDS", "input_root": input_root,
                    "input_manifest": [{"role": "srs", "path": "requirements.txt"}],
                })
        self.assertTrue(result["ok"])
        self.assertEqual(result["run"]["last_node"], "static_gate")
        self.assertEqual(result["run"]["last_gate"], "REVIEW_REQUIRED")

    def test_runtime_cli_rejects_path_traversal_before_graph_start(self):
        with self.assertRaisesRegex(ValueError, "traversal-free"):
            runtime_cli._input_manifest([{"role": "srs", "path": "../secret.txt"}])


if __name__ == "__main__":
    unittest.main(verbosity=2)
