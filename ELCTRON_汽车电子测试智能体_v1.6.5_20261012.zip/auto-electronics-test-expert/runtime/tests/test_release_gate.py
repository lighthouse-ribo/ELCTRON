import tempfile
import unittest

from runtime.executor.release_gate import DeviceTarget, run_release_gate


class ReleaseGateTest(unittest.TestCase):
    def test_real_e2e_requires_explicit_flag(self):
        report = run_release_gate(
            target=DeviceTarget("xcdevlay", "LIN1"),
            allowlist=[{"adapter": "xcdevlay", "channel": "LIN1", "serial": ""}],
            allow_real_e2e=False,
        )
        self.assertFalse(report.passed)
        self.assertFalse(report.checks["real_e2e_explicitly_enabled"])

    def test_unknown_device_is_blocked_before_drills(self):
        report = run_release_gate(
            target=DeviceTarget("xcdevlay", "LIN2"),
            allowlist=[{"adapter": "xcdevlay", "channel": "LIN1", "serial": ""}],
            allow_real_e2e=True,
        )
        self.assertFalse(report.passed)
        self.assertFalse(report.checks["device_whitelist"])
        self.assertNotIn("lease_conflict", report.checks)

    def test_all_real_machine_release_drills_pass(self):
        with tempfile.TemporaryDirectory(prefix="aetex-release-test-") as root:
            report = run_release_gate(
                target=DeviceTarget("xcdevlay", "LIN1"),
                allowlist=[{"adapter": "xcdevlay", "channel": "LIN1", "serial": ""}],
                allow_real_e2e=True,
                root=root,
            )
        self.assertTrue(report.passed, report.to_dict())
        self.assertEqual(set(report.checks), {
            "real_e2e_explicitly_enabled", "device_whitelist", "lease_conflict",
            "crash_recovery", "asc_first_frame_and_persistence",
        })
        self.assertTrue(all(report.checks.values()))


if __name__ == "__main__":
    unittest.main()
