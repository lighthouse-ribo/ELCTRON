# -*- coding: utf-8 -*-
"""LIN-TP 重组（CANLOG → UDS 事务）测试。

这批测试钉住的规则全部来自**真实录制的观察**，不是规范推演：

  1. 空帧（dlc=0）不参与重组 —— 实测 0x3D 上夹着 19 个 `ao` 空帧；
  2. **不使用 tx/rx 标签判角色** —— 实测同一 0x3D 数据帧既有 `tx` 也有 `rx`，
     标签不可靠；角色一律按 frame_id 判定（master_id=0x3C / slave_id=0x3D）；
  3. 请求分组：连续的非空 master 帧；响应分组：其后、下一个请求之前的非空 slave 帧；
  4. 重组算法**复用既有 `lin_tp.assemble`**，不重写。
"""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.evidence import canlog as C          # noqa: E402
from runtime.evidence import lin_uds as LU        # noqa: E402

RECORD = (r"C:\Users\80026384\Desktop\软件测试\BBS\BBS_Vcan_Project"
          r"\BBS_Vcan_Project\Vcan_Project\RECORD")

# 真实录制里的多帧响应（CANLOG_260909_100454_064.xct L27-L29）
MF_FF = (0x51, 0x10, 0x0D, 0x62, 0xFD, 0x18, 0x53, 0x32)
MF_CF1 = (0x51, 0x21, 0x36, 0x30, 0x38, 0x33, 0x31, 0x33)
MF_CF2 = (0x51, 0x22, 0x31, 0x38, 0xFF, 0xFF, 0xFF, 0xFF)


def frames_of(*items):
    """items: (line_no, frame_id, bus, data)"""
    return list(items)


class SingleFrameTest(unittest.TestCase):
    def test_single_frame_request_response(self) -> None:
        fr = frames_of(
            (6, 0x3C, "lin", (0x51, 0x02, 0x3E, 0x00, 0xFF, 0xFF, 0xFF, 0xFF)),
            (7, 0x3D, "lin", (0x51, 0x02, 0x7E, 0x00, 0xFF, 0xFF, 0xFF, 0xFF)),
        )
        txs = LU.transactions(fr)
        self.assertEqual(len(txs), 1)
        tx = txs[0]
        self.assertEqual(tx.request, (0x3E, 0x00))
        self.assertEqual(tx.response, (0x7E, 0x00))
        self.assertTrue(tx.complete)
        self.assertEqual(tx.request_lines, (6,))
        self.assertEqual(tx.response_lines, (7,))

    def test_functional_addressing_nad_preserved(self) -> None:
        fr = frames_of((6, 0x3C, "lin", (0x7E, 0x03, 0x22, 0xF1, 0x86, 0xFF, 0xFF, 0xFF)))
        txs = LU.transactions(fr)
        self.assertEqual(txs[0].request, (0x22, 0xF1, 0x86))
        self.assertFalse(txs[0].complete)

    def test_non_lin_bus_frames_excluded(self) -> None:
        fr = frames_of((6, 0x3C, "can", (0x51, 0x03, 0x22, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF)))
        self.assertEqual(LU.transactions(fr), ())

    def test_wakeup_frame_excluded(self) -> None:
        fr = frames_of(
            (6, 0x00, "lin", ()),
            (7, 0x3C, "lin", (0x51, 0x03, 0x22, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF)),
        )
        txs = LU.transactions(fr)
        self.assertEqual(len(txs), 1)
        self.assertEqual(txs[0].request, (0x22, 0xD0, 0x3A))


class EmptyFrameTest(unittest.TestCase):
    def test_empty_frames_do_not_break_grouping(self) -> None:
        fr = frames_of(
            (6, 0x3C, "lin", (0x51, 0x03, 0x22, 0xFD, 0x18, 0xFF, 0xFF, 0xFF)),
            (7, 0x3D, "lin", ()),
            (8, 0x3D, "lin", ()),
            (9, 0x3D, "lin", ()),
            (26, 0x3C, "lin", (0x51, 0x03, 0x22, 0xFD, 0x18, 0xFF, 0xFF, 0xFF)),
            (27, 0x3D, "lin", MF_FF),
        )
        txs = LU.transactions(fr)
        # 空帧后重发同一请求 → 折叠为一个事务（重试语义），最终仍未拿到响应
        self.assertEqual(len(txs), 1, "空帧后重发相同请求应折叠为一个事务")
        self.assertEqual(txs[0].retries, 1, "空帧轮询后的重发必须记为 retries")
        # 既有 lin_tp 语义：单 FF 帧即视为响应载体（原测试即断言 complete）
        self.assertTrue(txs[0].complete)
        self.assertEqual(txs[0].request_lines, (6, 26), "两次请求的行号都应保留")

    def test_unanswered_request_marked_incomplete(self) -> None:
        fr = frames_of(
            (7, 0x3C, "lin", (0x51, 0x03, 0x22, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF)),
            (8, 0x3D, "lin", ()),
            (9, 0x3D, "lin", ()),
        )
        tx = LU.transactions(fr)[0]
        self.assertFalse(tx.complete)
        self.assertIsNone(tx.response)
        self.assertIn("无响应", tx.note)


class MultiFrameTest(unittest.TestCase):
    def test_multiframe_response_reassembled(self) -> None:
        fr = frames_of(
            (26, 0x3C, "lin", (0x51, 0x03, 0x22, 0xFD, 0x18, 0xFF, 0xFF, 0xFF)),
            (27, 0x3D, "lin", MF_FF),
            (28, 0x3D, "lin", MF_CF1),
            (29, 0x3D, "lin", MF_CF2),
        )
        tx = LU.transactions(fr)[0]
        self.assertTrue(tx.complete)
        self.assertEqual(len(tx.response), 13)
        self.assertEqual(tx.response[:3], (0x62, 0xFD, 0x18))
        # FF 头 `51 10 0D` -> total = (0x0 << 8) | 0x0D = 13；
        # 去掉 62 FD 18 三个字节，数据区 10 字节 53 32 36 30 38 33 31 33 31 38
        text = bytes(tx.response[3:]).decode("ascii", errors="replace")
        self.assertEqual(text, "S260831318", "DID FD18 的零件号应被完整重组出来")
        self.assertEqual(tx.response_lines, (27, 28, 29))

    def test_sequence_gap_rejected(self) -> None:
        bad_cf = (0x51, 0x23, 0x36, 0x30, 0x38, 0x33, 0x31, 0x33)   # seq 跳号 1 -> 3
        fr = frames_of(
            (26, 0x3C, "lin", (0x51, 0x03, 0x22, 0xFD, 0x18, 0xFF, 0xFF, 0xFF)),
            (27, 0x3D, "lin", MF_FF),
            (28, 0x3D, "lin", bad_cf),
        )
        tx = LU.transactions(fr)[0]
        self.assertFalse(tx.complete, "序号不连续不得当成功响应")
        self.assertIsNone(tx.response)
        self.assertIn("序号", tx.note)

    def test_multiframe_request_supported(self) -> None:
        ff = (0x51, 0x10, 0x09, 0x2E, 0xAA, 0xBB, 0xCC, 0xDD)
        cf = (0x51, 0x21, 0xEE, 0xFF, 0x00, 0x11, 0x22, 0x33)
        fr = frames_of((6, 0x3C, "lin", ff), (7, 0x3C, "lin", cf))
        tx = LU.transactions(fr)[0]
        self.assertEqual(len(tx.request), 9)
        self.assertEqual(tx.request[:4], (0x2E, 0xAA, 0xBB, 0xCC))


class PendingTest(unittest.TestCase):
    def test_pending_then_final_response(self) -> None:
        pending = (0x51, 0x03, 0x7F, 0x31, 0x78, 0xFF, 0xFF, 0xFF)
        final = (0x51, 0x03, 0x71, 0x01, 0x02, 0xFF, 0xFF, 0xFF)
        fr = frames_of(
            (6, 0x3C, "lin", (0x51, 0x03, 0x31, 0x01, 0x02, 0xFF, 0xFF, 0xFF)),
            (7, 0x3D, "lin", pending),
            (8, 0x3D, "lin", final),
        )
        tx = LU.transactions(fr)[0]
        self.assertTrue(tx.pending_passed, "应识别出经过了 0x78 pending")
        self.assertEqual(tx.response, (0x71, 0x01, 0x02), "最终响应应取 pending 之后的那一帧")
        self.assertTrue(tx.complete)

    def test_pending_only_is_incomplete(self) -> None:
        pending = (0x51, 0x03, 0x7F, 0x31, 0x78, 0xFF, 0xFF, 0xFF)
        fr = frames_of(
            (6, 0x3C, "lin", (0x51, 0x03, 0x31, 0x01, 0x02, 0xFF, 0xFF, 0xFF)),
            (7, 0x3D, "lin", pending),
        )
        tx = LU.transactions(fr)[0]
        self.assertTrue(tx.pending_passed)
        self.assertFalse(tx.complete)
        self.assertIn("pending", tx.note)


class OrderingTest(unittest.TestCase):
    def test_direction_labels_are_not_used(self) -> None:
        """CANLOG 的 tx/rx 不可靠（实测同一 0x3D 既有 tx 也有 rx）。
        分组的输入里根本不带方向，这里用同一份帧数据验证结果稳定。"""
        fr = frames_of(
            (6, 0x3C, "lin", (0x51, 0x03, 0x22, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF)),
            (7, 0x3D, "lin", (0x51, 0x03, 0x62, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF)),
        )
        self.assertEqual(LU.transactions(fr)[0].response, (0x62, 0xD0, 0x3A))

    def test_multiple_transactions_keep_file_order(self) -> None:
        req = (0x51, 0x03, 0x22, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF)
        rsp = (0x51, 0x03, 0x62, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF)
        fr = frames_of((6, 0x3C, "lin", req), (7, 0x3D, "lin", rsp),
                       (8, 0x3C, "lin", req), (9, 0x3D, "lin", rsp),
                       (10, 0x3C, "lin", req))
        txs = LU.transactions(fr)
        self.assertEqual([t.index for t in txs], [0, 1, 2])
        self.assertEqual([t.request_lines for t in txs], [(6,), (8,), (10,)])
        self.assertEqual([t.complete for t in txs], [True, True, False])


@unittest.skipUnless(os.path.isdir(RECORD), "真实录制目录不在本机")
class RealDiagnosticReplayTest(unittest.TestCase):
    """验收：真实诊断录制里的 UDS 事务必须能被重组出来。"""

    DIAG_FILES = [
        "CANLOG_260909_100454_064.xct",
        "CANLOG_260910_185945_219.xct",
        "CANLOG_260911_145819_494.xct",
        "CANLOG_260911_150810_104.xct",
        "CANLOG_260610_103946.xct",        # 该文件 0x3C 上是 NAD=0x00/PCI=0xFF 的非 UDS 流量
    ]

    def _collect(self):
        out = []
        for name in self.DIAG_FILES:
            trace = C.parse_canlog(os.path.join(RECORD, name))
            payload = [(f.line_no, f.frame_id, f.bus, f.data) for f in trace.frames]
            out.extend(LU.transactions(payload))
        return out

    def test_real_transactions_recovered(self) -> None:
        txs = self._collect()
        # 10 段请求流量里有 1 对是未应答前的重发，折叠后为 9 个事务
        # （与团队工具 parse_xct v2 的 retries 语义一致）
        self.assertEqual(len(txs), 9, "折叠重发后 5 个诊断录制共 9 个事务")
        self.assertEqual(sum(t.retries for t in txs), 1, "恰好一对重发")
        complete = [t for t in txs if t.complete]
        self.assertEqual(len(complete), 4, "其中只有 4 个事务拿到响应")

    def test_request_sids(self) -> None:
        sids = {t.request[0] for t in self._collect() if t.request}
        self.assertEqual(sids, {0x22, 0x3E}, "实测请求只有 ReadDataByIdentifier 与 TesterPresent")

    def test_part_number_recovered_from_real_multiframe(self) -> None:
        txs = [t for t in self._collect() if t.complete and t.response
               and t.response[0] == 0x62]
        self.assertTrue(txs, "应至少恢复一条 0x62 正响应")
        text = bytes(txs[0].response[3:]).decode("ascii", errors="replace")
        self.assertEqual(text, "S260831318")

    def test_evidence_index_reports_service_level(self) -> None:
        """端到端：真实诊断录制经证据层后，必须给出服务级（而非仅帧级）结论。"""
        from runtime.evidence import asc_index as A

        name = "CANLOG_260909_100454_064.xct"
        ev = A.load_evidence(name, RECORD)
        self.assertEqual(ev.frame_count, 32)
        self.assertEqual(ev.message_count, 3, "该文件 4 次请求里有 3 次拿到响应")

        self.assertTrue(ev.key_frames, "关键帧不应为空")
        joined = " ".join(k["note"] for k in ev.key_frames)
        self.assertIn("SID=0x22", joined, "请求 SID 应出现在关键帧里")
        self.assertIn("SID=0x62", joined, "正响应 SID 应出现在关键帧里")
        self.assertIn("line", ev.key_frames[0]["at"], "行号定位始终保留（亚毫秒排序依据）")
        self.assertIn("t_ms", ev.key_frames[0], "有时间轴时关键帧必须带累计时刻")

        self.assertIsNotNone(ev.time_range, "CANLOG 时间轴可用（dt 累加），必须给出时间区间")
        notes = " ".join(ev.unresolved)
        self.assertNotIn("未拿到响应", notes, "折叠后该文件 3 个事务全部拿到响应")
        self.assertIn("请求重发", " ".join(k["note"] for k in ev.key_frames),
                      "重发信息必须出现在关键帧里")


class RequestRetryFoldingTest(unittest.TestCase):
    """请求重发必须折叠为同一事务（retries 计数），不得虚增事务数。

    参考语义：团队工具 parse_xct v2 对未应答前的相同请求按重发折叠。
    实测影响：SWDL 压测录制里不折叠会把事务数虚增约 30%。
    """

    REQ = (0x51, 0x02, 0x22, 0xD0)                  # SF，载荷 22 D0
    RSP = (0x51, 0x04, 0x62, 0xD0, 0x00, 0x11)      # SF，载荷 62 D0 00 11

    def test_identical_unanswered_request_folds(self) -> None:
        frames = [
            (1, 0x3C, "lin", self.REQ),
            (2, 0x3C, "lin", self.REQ),             # 重发
            (3, 0x3D, "lin", self.RSP),
        ]
        txs = LU.transactions(frames)
        self.assertEqual(len(txs), 1, "重发+应答应折叠为一个事务")
        self.assertEqual(txs[0].retries, 1)
        self.assertTrue(txs[0].complete)
        self.assertEqual(txs[0].request_lines, (1, 2), "重发行号应保留以便追溯")
        self.assertEqual(txs[0].response_lines, (3,))

    def test_different_request_does_not_fold(self) -> None:
        other_req = (0x51, 0x02, 0x3E, 0x00)
        frames = [
            (1, 0x3C, "lin", self.REQ),
            (2, 0x3C, "lin", other_req),
        ]
        txs = LU.transactions(frames)
        self.assertEqual(len(txs), 2)
        self.assertEqual([t.retries for t in txs], [0, 0])

    def test_answered_then_same_request_does_not_fold(self) -> None:
        """已应答的事务关账；之后的相同请求是新事务。"""
        frames = [
            (1, 0x3C, "lin", self.REQ),
            (2, 0x3D, "lin", self.RSP),
            (3, 0x3C, "lin", self.REQ),
        ]
        txs = LU.transactions(frames)
        self.assertEqual(len(txs), 2)
        self.assertEqual([t.retries for t in txs], [0, 0])


class NadFilterTest(unittest.TestCase):
    """NAD 过滤：LIN 诊断帧 ID（0x3C/0x3D）是总线级的，载荷首字节决定目标节点。

    实测 260709_210504.xct：0x3C 上 78779 帧 NAD=0x51、14 帧 NAD=0x7E（其它节点）。
    不过滤会把别的节点流量算进本节点事务。NAD 由调用方传入，本层不硬编码项目值。
    """

    OTHER = (0x7E, 0x03, 0x22, 0xD0, 0x1C, 0xFF, 0xFF, 0xFF)   # 实测 L3101 原帧
    OWN   = (0x51, 0x03, 0x22, 0xD0, 0x1C, 0xFF, 0xFF, 0xFF)

    def test_other_node_traffic_excluded(self) -> None:
        frames = [
            (1, 0x3C, "lin", self.OTHER),
            (2, 0x3C, "lin", self.OWN),
        ]
        txs = LU.transactions(frames, nad=0x51)
        self.assertEqual(len(txs), 1, "NAD 过滤后只剩本节点事务")
        self.assertEqual(txs[0].request, (0x22, 0xD0, 0x1C))
        self.assertEqual(txs[0].request_lines, (2,), "被过滤帧的行号不应出现")

    def test_no_filter_keeps_both(self) -> None:
        frames = [
            (1, 0x3C, "lin", self.OTHER),
            (2, 0x3C, "lin", self.OWN),
        ]
        self.assertEqual(len(LU.transactions(frames)), 2)


class InvalidDiagnosticTrafficTest(unittest.TestCase):
    """诊断帧 ID 上的非 UDS 流量必须如实报 invalid，不得误报成"序号跳变"。

    实测来源：CANLOG_260610_103946.xct L2832 / L3071，数据为 `00 FF FF FF FF FF FF FF`
    （NAD=0x00 / PCI=0xFF），parse_frame 判为 unknown。
    """

    def test_invalid_first_frame_is_not_reported_as_sequence_gap(self) -> None:
        junk = (0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF)
        txs = LU.transactions(frames_of((2832, 0x3C, "lin", junk)))
        self.assertEqual(len(txs), 1)
        tx = txs[0]
        self.assertFalse(tx.complete)
        self.assertIsNone(tx.request)
        self.assertIn("NAD/PCI 非法", tx.note)
        self.assertNotIn("序号", tx.note, "这不是序号问题，不能误报")


if __name__ == "__main__":
    unittest.main()
