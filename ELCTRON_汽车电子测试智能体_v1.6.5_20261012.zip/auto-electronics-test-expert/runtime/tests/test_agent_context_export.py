"""Tests for the explicitly approved, facts-only model context bridge."""
from __future__ import annotations

import json
import unittest
from unittest.mock import mock_open, patch

from runtime.agents.model_invokers import _prompt
from runtime.agents.runner import AgentInvocation, AgentNodeRunner
from runtime.agents.swdl_uds import profile_for
from runtime.orchestrator.graph import RunContext


class AgentContextExportTests(unittest.TestCase):
    @patch("runtime.agents.runner.open", new_callable=mock_open)
    def test_facts_are_not_exported_without_explicit_approved_policy(self, mocked_open):
        mocked_open.return_value.read.return_value = json.dumps({
            "automotive_input_context": {
                "secret_material_in_context": False,
                "model_context_exported": False,
                "facts": [{"role": "srs", "summary": {"did_samples": ["F190"]}}],
            }
        })
        ctx = RunContext("RUN-CONTEXT-POLICY", "UDS design", "C:/controlled-run")

        request = AgentNodeRunner(profile_for("swdl-uds-test-designer")).prepare(ctx)

        self.assertEqual(request.input_context, {})

    @patch("runtime.agents.runner.digest_file", return_value="a" * 64)
    @patch("runtime.agents.runner.open", new_callable=mock_open)
    def test_only_bounded_facts_cross_to_model_context(self, mocked_open, _digest):
        persisted = {
            "automotive_input_context": {
                "secret_material_in_context": False,
                "model_context_exported": True,
                "model_context_policy": "approved_sanitized_facts_only",
                "facts": [{"role": "diag_survey", "source_id": "diag:abc",
                           "summary": {"did_samples": ["F190"], "raw_path": "C:/do-not-export"}}],
                "secure_key_references": [{"source_id": "key:def", "material_in_context": False}],
            }
        }
        mocked_open.return_value.read.return_value = json.dumps(persisted)
        ctx = RunContext("RUN-CONTEXT-001", "UDS design", "C:/controlled-run")
        ctx.note_artifact("02_plan/input_inspection.json", "a" * 64, kind="input_inspection")
        request = AgentNodeRunner(profile_for("swdl-uds-test-designer")).prepare(ctx)
        prompt = _prompt(request)

        self.assertEqual(request.input_context["facts"][0]["summary"]["did_samples"], ["F190"])
        self.assertNotIn("raw_path", request.input_context["facts"][0]["summary"])
        self.assertEqual(request.input_context["secure_key_reference_count"], 1)
        self.assertFalse(request.input_context["key_material_available_to_model"])
        self.assertIn("F190", prompt)
        self.assertNotIn("C:/do-not-export", prompt)
        self.assertNotIn("key:def", prompt)

    def test_artifact_paths_are_not_exported_to_the_model(self):
        ctx = RunContext("RUN-CONTEXT-003", "UDS", "C:/controlled-run")
        ctx.note_artifact("02_plan/internal.json", "a" * 64, kind="input")
        request = AgentNodeRunner(profile_for("swdl-uds-test-designer")).prepare(ctx)
        self.assertNotIn("path", request.artifacts[0])

    def test_legacy_invocations_default_to_empty_export_context(self):
        request = AgentInvocation(profile_for("swdl-uds-test-designer"), "RUN-CONTEXT-002", "UDS", ())
        self.assertEqual(request.input_context, {})


if __name__ == "__main__":
    unittest.main()
