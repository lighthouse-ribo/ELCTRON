#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""MCP skillpack：仅 AETEX Web 显式启用、只读返回、完整性 fail-closed。"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
SERVER = os.path.join(PKG, "runtime", "mcp", "server.py")


class McpSkillpackTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", AETEX_ENABLE_SKILLPACKS="1")
        cls.proc = subprocess.Popen(
            [sys.executable, SERVER], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, encoding="utf-8", cwd=PKG, env=env,
        )

    @classmethod
    def tearDownClass(cls) -> None:
        cls.proc.terminate()
        cls.proc.wait(timeout=10)

    @classmethod
    def rpc(cls, method: str, params: dict, msg_id: int) -> dict:
        assert cls.proc.stdin and cls.proc.stdout
        cls.proc.stdin.write(json.dumps({"jsonrpc": "2.0", "id": msg_id,
                                         "method": method, "params": params}) + "\n")
        cls.proc.stdin.flush()
        return json.loads(cls.proc.stdout.readline())

    def test_only_the_two_versioned_read_only_skillpacks_are_exposed(self) -> None:
        response = self.rpc("tools/list", {}, 1)
        tools = {item["name"]: item for item in response["result"]["tools"]}
        self.assertIn("skill__grilling", tools)
        self.assertIn("skill__design_taste_frontend", tools)
        self.assertEqual(tools["skill__grilling"]["inputSchema"]["properties"], {})
        self.assertEqual(tools["skill__design_taste_frontend"]["inputSchema"]["properties"], {})

    def test_skillpack_returns_guidance_not_execution(self) -> None:
        response = self.rpc("tools/call", {"name": "skill__grilling", "arguments": {}}, 2)
        self.assertFalse(response["result"].get("isError", False))
        payload = json.loads(response["result"]["content"][0]["text"])
        self.assertEqual(payload["skill"], "grilling")
        self.assertEqual(payload["mode"], "read_only_guidance")
        self.assertIn("cannot execute code", payload["guardrails"][0])
        self.assertIn("design tree", payload["instructions"])

    def test_skillpack_rejects_arguments_and_hardware_remains_absent(self) -> None:
        rejected = self.rpc("tools/call", {
            "name": "skill__design_taste_frontend", "arguments": {"path": "../state.json"},
        }, 3)
        self.assertTrue(rejected["result"]["isError"])
        self.assertIn("SKILLPACK_ARGUMENTS_NOT_ALLOWED", rejected["result"]["content"][0]["text"])
        listed = self.rpc("tools/list", {}, 4)
        self.assertFalse(any("hardware" in item["name"] for item in listed["result"]["tools"]))


if __name__ == "__main__":
    unittest.main()
