"""Fail-closed behavior of the Vector preflight CLI."""
from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[2] / "skills" / "uds-diagnostic-test" / "scripts" / "can_init.py"
SPEC = importlib.util.spec_from_file_location("can_init_preflight_under_test", SCRIPT)
CAN_INIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CAN_INIT)


class CanInitPreflightTest(unittest.TestCase):
    def test_tasklist_failure_is_unknown_not_no_occupancy(self):
        result = SimpleNamespace(returncode=1, stderr="Access is denied", stdout="")
        with patch("subprocess.run", return_value=result):
            with self.assertRaisesRegex(RuntimeError, "tasklist exited 1"):
                CAN_INIT.check_process_occupancy()

    def test_preflight_missing_channels_exits_nonzero(self):
        with patch.object(sys, "argv", ["can_init.py", "--preflight"]), \
             patch.object(CAN_INIT, "check_vector_backend", return_value=True), \
             patch.object(CAN_INIT, "check_process_occupancy", return_value=[]), \
             patch.object(CAN_INIT, "list_channels", return_value=[]):
            with self.assertRaises(SystemExit) as result:
                CAN_INIT.main()
        self.assertEqual(result.exception.code, 2)

    def test_preflight_unknown_process_state_exits_nonzero(self):
        with patch.object(sys, "argv", ["can_init.py", "--preflight"]), \
             patch.object(CAN_INIT, "check_vector_backend", return_value=True), \
             patch.object(CAN_INIT, "check_process_occupancy", side_effect=RuntimeError("unknown")):
            with self.assertRaises(SystemExit) as result:
                CAN_INIT.main()
        self.assertEqual(result.exception.code, 2)

    def test_preflight_ready_exits_zero(self):
        with patch.object(sys, "argv", ["can_init.py", "--preflight"]), \
             patch.object(CAN_INIT, "check_vector_backend", return_value=True), \
             patch.object(CAN_INIT, "check_process_occupancy", return_value=[]), \
             patch.object(CAN_INIT, "list_channels", return_value=[{"channel": 2}]):
            with self.assertRaises(SystemExit) as result:
                CAN_INIT.main()
        self.assertEqual(result.exception.code, 0)
