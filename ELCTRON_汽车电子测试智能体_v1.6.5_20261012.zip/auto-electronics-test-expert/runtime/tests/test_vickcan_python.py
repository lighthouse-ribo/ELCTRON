"""VickCAN Python-only agent draft contract tests."""
from __future__ import annotations

import importlib.util
import os
import sys
import unittest
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.agents.runner import AgentDraft, AgentNodeRunner, AgentPolicyError  # noqa: E402
from runtime.agents.swdl_uds import profile_for  # noqa: E402
from runtime.agents.vickcan_python import VickCanPythonDraftError, compile_vickcan_python_draft  # noqa: E402
from runtime.orchestrator.graph import RunContext  # noqa: E402


def draft(**overrides):
    value = {
        "target_platform": "vickcan-python",
        "cases": [{"case_id": "UDS-READ-F190", "procedure": "发送 22 F1 90",
                   "expected": "62 F1 90 正响应", "precondition": "扩展会话已建立"}],
    }
    value.update(overrides)
    return value


def load_existing_generator():
    script = Path(PKG) / "skills" / "uds-diagnostic-test" / "scripts" / "gen_case_scripts.py"
    sys.path.insert(0, str(script.parent))
    try:
        spec = importlib.util.spec_from_file_location("agent_case_generator_probe", script)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        sys.path.pop(0)


class _Invoker:
    def __init__(self, payload): self.payload = payload
    def invoke(self, _request): return AgentDraft("VickCAN Python 草案", self.payload)


class VickCanPythonDraftTests(unittest.TestCase):
    def test_complete_case_is_normalized_for_existing_python_generator(self):
        contract = compile_vickcan_python_draft(draft())
        self.assertEqual(contract["execution_mode"], "python-generator-ready")
        self.assertEqual(contract["cases"][0]["request"], [0x22, 0xF1, 0x90])
        self.assertEqual(contract["cases"][0]["expectation"], {
            "kind": "positive_prefix", "bytes": [0x62, 0xF1, 0x90],
        })
        self.assertEqual(contract["cases"][0]["generator_case_id"], "UDS_0x22_UDS-READ-F190")
        self.assertEqual(contract["generator_case_schema"][0], {
            "case_id": "UDS_0x22_UDS-READ-F190", "agent_case_id": "UDS-READ-F190",
            "procedure": "发送 22 F1 90", "expected": "62 F1 90", "precondition": "扩展会话已建立",
        })
        generator = load_existing_generator()
        generated = contract["generator_case_schema"][0]
        self.assertEqual(generator.service_token(generated["case_id"]), "0x22")
        self.assertEqual(generator.request_payload(generated["procedure"], "can", 0x51,
                                                   service_hint="0x22")[0], [0x22, 0xF1, 0x90])

    def test_negative_case_requires_explicit_nrc(self):
        contract = compile_vickcan_python_draft(draft(cases=[{
            "case_id": "UDS-READ-F190-NEG", "procedure": "发送 22 F1 90", "expected": "NRC 0x13",
            "precondition": "默认会话",
        }]))
        self.assertEqual(contract["cases"][0]["expectation"], {"kind": "nrc", "nrc": 0x13})
        with self.assertRaisesRegex(VickCanPythonDraftError, "NEGATIVE_SID_MISMATCH"):
            compile_vickcan_python_draft(draft(cases=[{
                "case_id": "UDS-WRONG-NEGATIVE-SID", "procedure": "发送 22 F1 90",
                "expected": "7F 10 31", "precondition": "默认会话",
            }]))

    def test_canoe_capl_and_protocol_mismatch_are_rejected(self):
        with self.assertRaisesRegex(VickCanPythonDraftError, "TARGET_REQUIRED"):
            compile_vickcan_python_draft(draft(target_platform="canoe-capl"))
        with self.assertRaisesRegex(VickCanPythonDraftError, "POSITIVE_SID_MISMATCH"):
            compile_vickcan_python_draft(draft(cases=[{
                "case_id": "UDS-BAD", "procedure": "发送 22 F1 90", "expected": "6E F1 90",
                "precondition": "默认会话",
            }]))
        with self.assertRaisesRegex(VickCanPythonDraftError, "POSITIVE_IDENTIFIER_MISMATCH"):
            compile_vickcan_python_draft(draft(cases=[{
                "case_id": "UDS-WRONG-DID", "procedure": "发送 22 F1 90", "expected": "62 F1 91",
                "precondition": "默认会话",
            }]))
        with self.assertRaisesRegex(VickCanPythonDraftError, "POSITIVE_ROUTINE_MISMATCH"):
            compile_vickcan_python_draft(draft(cases=[{
                "case_id": "UDS-WRONG-RID", "procedure": "发送 31 01 12 34", "expected": "71 01 12 35",
                "precondition": "默认会话",
            }]))

    def test_missing_precondition_is_rejected(self):
        with self.assertRaisesRegex(VickCanPythonDraftError, "CASE_FIELDS_INVALID"):
            compile_vickcan_python_draft(draft(cases=[{
                "case_id": "UDS-NO-PRECONDITION", "procedure": "发送 22 F1 90",
                "expected": "62 F1 90",
            }]))

    def test_case_id_is_compatible_with_downstream_generator_paths(self):
        with self.assertRaisesRegex(VickCanPythonDraftError, "CASE_ID_INVALID"):
            compile_vickcan_python_draft(draft(cases=[{
                "case_id": "UDS.READ.F190", "procedure": "发送 22 F1 90",
                "expected": "62 F1 90", "precondition": "默认会话",
            }]))

    def test_security_access_seed_and_key_bytes_are_rejected(self):
        for procedure, expected in (("27 02 12 34", "67 02"),
                                    ("27 01", "67 01 12 34"),
                                    ("27 02", "67 02")):
            with self.subTest(procedure=procedure, expected=expected):
                with self.assertRaisesRegex(VickCanPythonDraftError, "SECURITY_ACCESS"):
                    compile_vickcan_python_draft(draft(cases=[{
                        "case_id": "UDS-SECURITY-001", "procedure": procedure,
                        "expected": expected, "precondition": "default session",
                    }]))

    def test_writer_cannot_persist_an_incomplete_or_non_python_draft(self):
        runner = AgentNodeRunner(profile_for("swdl-uds-test-designer"))
        with self.assertRaisesRegex(AgentPolicyError, "VICKCAN_TARGET_REQUIRED"):
            runner.run(RunContext("RUN-VICKCAN-001", "UDS", "unused"), _Invoker({"cases": []}))
        raw = draft()
        raw["unreviewed_metadata"] = {"nested": "must not be persisted"}
        raw["cases"][0]["debug_note"] = "unvalidated model output"
        outcome = runner.run(RunContext("RUN-VICKCAN-002", "UDS", "unused"), _Invoker(raw))
        self.assertEqual(outcome.payload["vickcan_python_contract"]["case_count"], 1)
        self.assertNotIn("unreviewed_metadata", outcome.payload)
        self.assertNotIn("debug_note", repr(outcome.payload))
        self.assertEqual(outcome.payload["cases"], outcome.payload["vickcan_python_contract"]["generator_case_schema"])

    def test_forbidden_secret_key_names_are_rejected_recursively(self):
        raw = draft()
        raw["diagnostics"] = {"seed_key": "must never be persisted"}
        with self.assertRaisesRegex(AgentPolicyError, "GOVERNANCE_OR_SECRET_FIELD"):
            AgentNodeRunner(profile_for("swdl-uds-test-designer")).run(
                RunContext("RUN-VICKCAN-003", "UDS", "unused"), _Invoker(raw))


if __name__ == "__main__":
    unittest.main(verbosity=2)
