from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.config_layer import ConfigError, inspect_mem0_environment, load_runtime_config  # noqa: E402
from runtime.executor.vickcan import VickCanNotReady, VickCanReadOnlyAdapter, VickCanTarget  # noqa: E402
from runtime.failure_samples import FailureSample, FailureSampleError, FailureSampleLibrary  # noqa: E402


class P6FoundationTest(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="aetex-p6-")

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def config_path(self, payload):
        path = os.path.join(self.root, "runtime.json")
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle)
        return path

    def test_layered_config_accepts_non_secret_policy_and_env_overrides(self):
        path = self.config_path({
            "hardware": {"adapter": "vickcan", "channels": ["CAN1"], "expected_config_sha256": "a" * 64},
            "memory": {"mem0_mirror_enabled": False, "mem0_credential_env": "AETEX_MEM0_KEY"},
        })
        config = load_runtime_config(path, env={"AETEX_HARDWARE_CHANNELS": "CAN2,CAN3", "AETEX_MEM0_MIRROR": "true"})
        self.assertEqual(config.channels, ("CAN2", "CAN3"))
        self.assertTrue(config.mem0_mirror_enabled)
        self.assertEqual(config.real_e2e_errors(), [])
        self.assertEqual(config.preflight().channels, ("CAN2", "CAN3"))

    def test_config_rejects_secret_content_and_incomplete_real_e2e_profile(self):
        path = self.config_path({"memory": {"api_key": "must-not-be-here"}})
        with self.assertRaises(ConfigError):
            load_runtime_config(path)
        config = load_runtime_config(None, env={})
        self.assertGreaterEqual(len(config.real_e2e_errors()), 3)

    def test_mem0_readiness_never_returns_credential_value(self):
        path = self.config_path({"memory": {"mem0_mirror_enabled": True, "mem0_credential_env": "AETEX_MEM0_KEY"}})
        report = inspect_mem0_environment(load_runtime_config(path), env={"AETEX_MEM0_KEY": "not-disclosed"}).public_dict()
        self.assertTrue(report["credential_present"])
        self.assertNotIn("not-disclosed", json.dumps(report))
        self.assertNotIn("credential_value", report)

    def test_failure_library_requires_approval_and_redacted_summary(self):
        library = FailureSampleLibrary(os.path.join(self.root, "samples.jsonl"))
        sample = FailureSample("FS-1", "INFRA_ERROR", "RUN-1", "b" * 64, "adapter timeout after lease acquired", "operator", "p6/v1")
        with self.assertRaises(FailureSampleError):
            library.admit(sample, approved=False)
        library.admit(sample, approved=True)
        self.assertEqual(library.list(failure_class="INFRA_ERROR"), [sample])
        leaking = FailureSample("FS-2", "INFRA_ERROR", "RUN-2", "c" * 64, "api_key=do-not-store", "operator", "p6/v1")
        with self.assertRaises(FailureSampleError):
            library.admit(leaking, approved=True)

    def test_vickcan_boundary_never_opens_an_unbound_device(self):
        target = VickCanTarget(channel="CAN1", serial="SERIAL-1")
        adapter = VickCanReadOnlyAdapter([target])
        self.assertFalse(adapter.readiness(target)["ready"])
        with self.assertRaises(VickCanNotReady):
            adapter.open_capture(target)
        with self.assertRaises(VickCanNotReady):
            adapter.open_capture(VickCanTarget(channel="CAN9", serial="unknown"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
