"""Worker tool calls must traverse the runtime-owned MCP authorization path."""
from __future__ import annotations

import json
import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import patch

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.agents.mcp_gateway import AgentToolError, RuntimeMcpToolGateway  # noqa: E402
from runtime.agents.model_invokers import CodexHeadInvoker, DeepSeekWorkerInvoker  # noqa: E402
from runtime.agents.runner import AgentInvocation  # noqa: E402
from runtime.agents.swdl_uds import profile_for  # noqa: E402


class _Response:
    def __init__(self, payload):
        self.payload = payload

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self):
        return json.dumps(self.payload).encode("utf-8")


class _Gateway:
    def __init__(self):
        self.calls = []

    def describe(self, _invocation):
        return [{"type": "function", "function": {
            "name": "swdl_case_generator", "description": "safe test tool", "parameters": {"type": "object"},
        }}]

    def call(self, _invocation, call):
        self.calls.append(call)
        return {"tool": call.name, "is_error": False, "content": "generated 3 candidate cases"}


class WorkerMcpToolLoopTest(unittest.TestCase):
    def test_native_tool_call_is_executed_then_result_returns_to_worker(self):
        invocation = AgentInvocation(profile_for("swdl-uds-test-designer"), "RUN-MCP-001", "SWDL UDS", ())
        gateway = _Gateway()
        invoker = DeepSeekWorkerInvoker(base_url="https://model.invalid/v1", model="test",
                                        credential_env="WORKER_KEY", env={"WORKER_KEY": "test-key"}, gateway=gateway)
        responses = [
            _Response({"choices": [{"message": {"content": None, "tool_calls": [{
                "id": "tool-1", "type": "function", "function": {
                    "name": "swdl_case_generator",
                    "arguments": '{"target":"build_swdl_cases","kwargs":{"requirement_ids":["REQ-1"]}}',
                },
            }]}}]}),
            _Response({"choices": [{"message": {"content": '{"summary":"draft ready","payload":{"case_count":3}}'}}]}),
        ]
        with patch("runtime.agents.model_invokers.request.urlopen", side_effect=responses) as opened:
            draft = invoker.invoke(invocation)
        self.assertEqual(draft.summary, "draft ready")
        self.assertEqual(draft.payload["case_count"], 3)
        self.assertEqual([call.name for call in gateway.calls], ["swdl_case_generator"])
        second_request = json.loads(opened.call_args_list[1].args[0].data.decode("utf-8"))
        self.assertEqual(second_request["messages"][-1]["role"], "tool")
        self.assertNotIn("test-key", json.dumps(second_request))

    def test_head_tool_call_uses_the_same_gateway(self):
        invocation = AgentInvocation(profile_for("swdl-uds-test-designer"), "RUN-HEAD-001", "SWDL UDS", ())
        gateway = _Gateway()
        first = json.dumps({"item": {"text": json.dumps({"tool_calls": [
            {"name": "swdl_case_generator", "arguments": {"target": "build_swdl_cases"}}
        ]})}})
        second = json.dumps({"item": {"text": json.dumps({"summary": "draft ready", "payload": {"case_count": 3}})}})
        responses = [SimpleNamespace(returncode=0, stdout=first), SimpleNamespace(returncode=0, stdout=second)]
        with patch("runtime.agents.model_invokers.shutil.which", return_value="codex"), \
             patch("runtime.agents.model_invokers.subprocess.run", side_effect=responses) as run:
            draft = CodexHeadInvoker(command="codex", gateway=gateway).invoke(invocation)
        self.assertEqual(draft.payload["case_count"], 3)
        self.assertEqual([call.name for call in gateway.calls], ["swdl_case_generator"])
        self.assertIn("read-only", run.call_args_list[0].args[0])
        self.assertIn("generated 3 candidate cases", run.call_args_list[1].args[0][-1])

    def test_gateway_rejects_non_profile_hardware_or_file_access(self):
        invocation = AgentInvocation(profile_for("swdl-uds-test-designer"), "RUN-MCP-002", "SWDL UDS", ())
        gateway = RuntimeMcpToolGateway()
        self.assertEqual([item["function"]["name"] for item in gateway.describe(invocation)],
                         ["swdl_case_generator"])
        from runtime.agents.mcp_gateway import AgentToolCall
        with self.assertRaisesRegex(AgentToolError, "PROFILE_ALLOWED"):
            gateway.call(invocation, AgentToolCall("uds_runner", {"args": []}))
        with self.assertRaisesRegex(AgentToolError, "NOT_SERVICEABLE"):
            gateway.call(invocation, AgentToolCall("uds_req_matrix_generator", {"args": ["C:/private/input.xlsx"]}))
        with self.assertRaisesRegex(AgentToolError, "NOT_SERVICEABLE"):
            gateway.call(invocation, AgentToolCall("uds_req_matrix_generator", {
                "target": "build", "kwargs": {"input_path": "C:/private/input.xlsx"},
            }))

    def test_gateway_executes_profile_library_through_shared_mcp_server(self):
        invocation = AgentInvocation(profile_for("swdl-uds-test-designer"), "RUN-MCP-003", "SWDL UDS", ())
        from runtime.agents.mcp_gateway import AgentToolCall
        result = RuntimeMcpToolGateway().call(invocation, AgentToolCall("swdl_case_generator", {
            "target": "build_swdl_cases", "kwargs": {"requirement_ids": ["REQ-LOCAL-1"]},
        }))
        self.assertFalse(result["is_error"])
        self.assertIn("REQ-LOCAL-1", result["content"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
