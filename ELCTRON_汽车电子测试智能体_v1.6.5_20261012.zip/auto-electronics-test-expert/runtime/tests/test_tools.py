#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T2.4 / T2.6 CLI 适配层回归测试。

关键断言：
  * 适配层真的能跑通既有 CLI（不是 mock）；
  * 出口码映射**没有**"未知即通过"的分支；
  * 输出无法解析时抛错，不降级成通过。
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.orchestrator import tools as T  # noqa: E402
from runtime.orchestrator.state import GateStatus  # noqa: E402


class ResolveScriptTest(unittest.TestCase):
    def test_resolves_existing_script(self) -> None:
        full = T.resolve_script(T.REFERENCE_ROUTER)
        self.assertTrue(os.path.isfile(full))

    def test_rejects_absolute_path(self) -> None:
        with self.assertRaises(T.CliToolError):
            T.resolve_script("C:/Windows/system32/calc.exe")

    def test_rejects_traversal(self) -> None:
        with self.assertRaises(T.CliToolError):
            T.resolve_script("../../outside.py")

    def test_rejects_missing(self) -> None:
        with self.assertRaises(T.CliToolError):
            T.resolve_script("skills/no_such_script.py")

    def test_available_tools_means_callable_not_present(self) -> None:
        """`available_tools()` 的语义是「可 CLI 调用」，不是「文件存在」。

        实测缺陷（2026-09-15）：`review_truth.py` 与 `project_artifact_binding.py`
        没有 `__main__` 入口，按 CLI 调得到「退出码 0 + 空输出」，被映射成 PASS。
        旧断言只检查文件存在，等于把这个缺陷固化进测试 —— 所以这里显式反过来断言。
        """
        report = T.available_tools()
        callable_tools = [k for k, ok in report.items() if ok]
        not_callable = [k for k, ok in report.items() if not ok]

        self.assertEqual(len(callable_tools), 3, f"可调用的 CLI 应为 3 个：{report}")
        for rel in not_callable:
            with self.subTest(script=rel):
                self.assertIn("review_truth" if "review_truth" in rel
                              else "project_artifact_binding", rel)
        with self.assertRaises(T.CliToolError):
            T.run_cli("skills/uds-diagnostic-test/scripts/review_truth.py", ["--help"])


class ExitCodeMappingTest(unittest.TestCase):
    def test_known_codes(self) -> None:
        self.assertIs(T.static_gate_from_exit(0), GateStatus.PASS)
        self.assertIs(T.static_gate_from_exit(2), GateStatus.REVIEW_REQUIRED)
        self.assertIs(T.static_gate_from_exit(1), GateStatus.ERROR)

    def test_unknown_codes_are_error_never_pass(self) -> None:
        """最危险的写法是 `return PASS if code == 0 else ERROR` 写成 `if code != 2`。
        这里逐个验证未知码一律 ERROR。"""
        for code in (3, 4, 127, 255, -1, -9, 99):
            with self.subTest(code=code):
                self.assertIs(T.static_gate_from_exit(code), GateStatus.ERROR)

    def test_timeout_is_error(self) -> None:
        self.assertIs(T.static_gate_from_exit(0, timed_out=True), GateStatus.ERROR)

    def test_zero_is_the_only_pass(self) -> None:
        passing = [c for c in range(-2, 10) if T.static_gate_from_exit(c) is GateStatus.PASS]
        self.assertEqual(passing, [0])


class ReferenceRouterIntegrationTest(unittest.TestCase):
    """真跑既有 CLI，不用 mock。"""

    def test_lin_uds_task_returns_iso17987_primary(self) -> None:
        payload, result = T.reference_router("UDS-over-LIN 使用 F1L1 诊断 NAD 0x3C")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(payload["primary_branch"], "ISO-17987")
        self.assertIn("ISO-14229", payload.get("secondary_branches", []))
        self.assertTrue(payload.get("mounted_assets"))

    def test_explicit_bus_override(self) -> None:
        payload, _ = T.reference_router("随便问一个 UDS 问题", bus="CAN")
        self.assertEqual(payload["bus"], "CAN")

    def test_output_is_json_parseable(self) -> None:
        _, result = T.reference_router("LIN 帧 PID 校验和")
        json.loads(result.stdout)          # 不应抛


class CaseLintIntegrationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp(prefix="aetex-lint-")

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _write_cases(self, data) -> str:
        path = os.path.join(self.tmp, "cases.json")
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        return path

    def test_missing_case_file_maps_to_error(self) -> None:
        gate, result = T.case_lint(os.path.join(self.tmp, "nope.json"))
        self.assertIs(gate, GateStatus.ERROR)
        self.assertNotEqual(result.returncode, 0)

    def test_empty_case_list_passes_lint(self) -> None:
        gate, result = T.case_lint(self._write_cases([]))
        self.assertIs(gate, GateStatus.PASS, msg=result.stdout[-400:])

    def test_findings_extraction_is_conservative(self) -> None:
        out = T.CliResult(script="x.py", args=(), returncode=2, stdout="  - R1 违规：xxx\n普通行\n", stderr="", duration_s=0.1)
        findings = T.findings_from_output(out, severity="REVIEW_REQUIRED")
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["severity"], "REVIEW_REQUIRED")
        self.assertIn("R1", findings[0]["message"])


class RunCliTest(unittest.TestCase):
    def test_python_syntax_error_is_captured_not_raised(self) -> None:
        """被调脚本崩了要如实返回非零码与错误输出，不在适配层吞掉。"""
        tmp = tempfile.mkdtemp(prefix="aetex-cli-")
        self.addCleanup(shutil.rmtree, tmp, True)
        os.makedirs(os.path.join(tmp, "skills"), exist_ok=True)
        bad = os.path.join(tmp, "skills", "bad.py")
        with open(bad, "w", encoding="utf-8") as fh:
            # 先给一个 __main__ 守卫（适配层会先断言可调用性），
            # 再放一个真正的语法错误 —— 测的仍然是「崩溃要如实返回」。
            fh.write('if __name__ == "__main__":\n    pass\ndef broken(:\n')
        result = T.run_cli("skills/bad.py", root=tmp)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("SyntaxError", result.stderr + result.stdout)

    def test_timeout_is_reported(self) -> None:
        tmp = tempfile.mkdtemp(prefix="aetex-cli-")
        self.addCleanup(shutil.rmtree, tmp, True)
        os.makedirs(os.path.join(tmp, "skills"), exist_ok=True)
        slow = os.path.join(tmp, "skills", "slow.py")
        with open(slow, "w", encoding="utf-8") as fh:
            fh.write('import time\nif __name__ == "__main__":\n    time.sleep(5)\n')
        result = T.run_cli("skills/slow.py", root=tmp, timeout=1.0)
        self.assertTrue(result.timed_out)
        self.assertIs(T.static_gate_from_exit(result.returncode, timed_out=True), GateStatus.ERROR)


if __name__ == "__main__":
    unittest.main(verbosity=2)
