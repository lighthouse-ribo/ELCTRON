"""Business-guidance cards are bounded, role-scoped and path-free."""
from __future__ import annotations

import os
import sys
import unittest
from unittest.mock import patch

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.agents.business_guidance import BusinessGuidanceError, guidance_for_profile  # noqa: E402
from runtime.agents.runner import AgentNodeRunner  # noqa: E402
from runtime.agents.swdl_uds import profile_for  # noqa: E402
from runtime.orchestrator.graph import RunContext  # noqa: E402


class BusinessGuidanceTests(unittest.TestCase):
    def test_writer_and_reviewer_receive_distinct_path_free_rule_cards(self):
        writer = guidance_for_profile("swdl-uds-test-designer")
        reviewer = guidance_for_profile("swdl-uds-script-reviewer")
        self.assertEqual(writer["role"], "script_writer")
        self.assertEqual(reviewer["role"], "script_reviewer")
        self.assertTrue(all(rule["id"].startswith("W-") for rule in writer["rules"]))
        self.assertTrue(all(rule["id"].startswith("R-") for rule in reviewer["rules"]))
        self.assertNotIn("path", repr(writer).lower())
        self.assertNotIn("path", repr(reviewer).lower())
        self.assertLess(len(repr(writer).encode("utf-8")), 8_000)

    def test_profile_preparation_injects_local_guidance_without_history(self):
        request = AgentNodeRunner(profile_for("swdl-uds-test-designer")).prepare(
            RunContext("RUN-GUIDANCE-001", "SWDL UDS", "unused"))
        self.assertEqual(request.business_guidance["role"], "script_writer")
        self.assertFalse(request.handoff)

    def test_missing_source_asset_fails_closed(self):
        asset = {
            "schema_version": "agent-business-guidance/v0.1",
            "roles": {"script_writer": [{"id": "W-X", "directive": "safe"}]},
            "sources": [{"id": "missing", "path": "not-here.md"}],
        }
        with patch("runtime.agents.business_guidance._load_asset", return_value=asset):
            with self.assertRaisesRegex(BusinessGuidanceError, "SOURCE_MISSING"):
                guidance_for_profile("swdl-uds-test-designer", root=PKG)

    def test_asset_cannot_reference_a_source_outside_the_package(self):
        asset = {
            "schema_version": "agent-business-guidance/v0.1",
            "roles": {"script_writer": [{"id": "W-X", "directive": "safe"}]},
            "sources": [{"id": "escape", "path": "../outside.md"}],
        }
        with patch("runtime.agents.business_guidance._load_asset", return_value=asset):
            with self.assertRaisesRegex(BusinessGuidanceError, "SOURCE_INVALID"):
                guidance_for_profile("swdl-uds-test-designer", root=PKG)


if __name__ == "__main__":
    unittest.main(verbosity=2)
