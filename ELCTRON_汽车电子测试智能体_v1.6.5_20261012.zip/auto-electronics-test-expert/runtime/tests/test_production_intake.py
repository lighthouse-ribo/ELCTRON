"""Production-node wiring tests for automotive intake facts."""
from __future__ import annotations

import json
import unittest
from unittest.mock import mock_open, patch

from runtime.orchestrator.graph import RunContext
from runtime.orchestrator.production_nodes import _inspect, _route
from runtime.orchestrator.state import GateStatus, NodeStatus


class ProductionIntakeTests(unittest.TestCase):
    @patch("runtime.orchestrator.production_nodes.reference_router")
    @patch("runtime.orchestrator.production_nodes.os.path.isfile", return_value=True)
    @patch("runtime.orchestrator.production_nodes.os.path.getsize", return_value=40 * 1024 * 1024)
    @patch("runtime.orchestrator.production_nodes.digest_file", return_value="a" * 64)
    def test_route_blocks_total_input_size_before_parser_execution(self, _digest, _size, _isfile, router):
        router.return_value = ({"primary_branch": "ISO-14229", "secondary_branches": []}, object())
        ctx = RunContext("RUN-INTAKE-SIZE", "UDS design", "C:/controlled-run")
        ctx.input_root = "C:/controlled-input"
        ctx.input_manifest = (
            {"role": "srs", "path": "requirements-a.txt"},
            {"role": "srs", "path": "requirements-b.txt"},
            {"role": "dbc", "path": "network.dbc"},
            {"role": "ldf", "path": "network.ldf"},
            {"role": "sddb", "path": "diagnostics.sddb"},
            {"role": "diag_survey", "path": "survey.xlsx"},
        )

        outcome = _route(ctx)

        self.assertEqual(outcome.status, NodeStatus.BLOCKED)
        self.assertEqual(outcome.blocked_reason, "input_total_too_large")

    @patch("runtime.orchestrator.production_nodes.reference_router")
    @patch("runtime.orchestrator.production_nodes.os.path.isfile", return_value=True)
    @patch("runtime.orchestrator.production_nodes.os.path.getsize", return_value=128)
    @patch("runtime.orchestrator.production_nodes.os.path.realpath")
    def test_route_blocks_manifest_entry_resolving_outside_root(self, realpath, _size, _isfile, router):
        def resolve(path):
            return "C:/outside/secret.srs" if "linked.srs" in path else path

        realpath.side_effect = resolve
        router.return_value = ({"primary_branch": "ISO-14229", "secondary_branches": []}, object())
        ctx = RunContext("RUN-INTAKE-LINK", "UDS design", "C:/controlled-run")
        ctx.input_root = "C:/controlled-input"
        ctx.input_manifest = ({"role": "srs", "path": "linked.srs"},)

        outcome = _route(ctx)

        self.assertEqual(outcome.status, NodeStatus.BLOCKED)
        self.assertEqual(outcome.blocked_reason, "input_manifest_invalid")

    @patch("runtime.orchestrator.production_nodes.build_automotive_input_context")
    @patch("runtime.orchestrator.production_nodes.open", new_callable=mock_open)
    def test_inspection_persists_local_fact_packet_without_model_export(self, mocked_open, build_context):
        mounted = [{"role": "diag_survey", "path": "survey.xlsx", "sha256": "a" * 64, "bytes": 12}]
        mocked_open.return_value.read.return_value = json.dumps({"files": mounted})
        build_context.return_value = {
            "schema_version": "automotive-input-context/v0.1", "facts": [],
            "secret_material_in_context": False, "model_context_exported": True,
        }
        ctx = RunContext("RUN-INTAKE-001", "UDS design", "C:/controlled-run")
        ctx.input_root = "C:/controlled-input"
        ctx.note_artifact("01_command/reference_mount.json", "b" * 64, kind="reference_mount")

        outcome = _inspect(ctx)

        self.assertEqual(outcome.status, NodeStatus.OK)
        self.assertEqual(outcome.gate_status, GateStatus.PASS)
        self.assertEqual(outcome.artifact_path, "02_plan/input_inspection.json")
        self.assertTrue(outcome.payload["automotive_input_context"]["model_context_exported"])
        build_context.assert_called_once_with("C:/controlled-input", mounted, scratch_root="C:/controlled-run")

    @patch("runtime.orchestrator.production_nodes.build_automotive_input_context")
    @patch("runtime.orchestrator.production_nodes.open", new_callable=mock_open)
    def test_parser_failure_blocks_instead_of_designing_from_file_names(self, mocked_open, build_context):
        mounted = [{"role": "dbc", "path": "network.dbc", "sha256": "c" * 64, "bytes": 12},
                   {"role": "srs", "path": "requirements.txt", "sha256": "d" * 64, "bytes": 12}]
        mocked_open.return_value.read.return_value = json.dumps({"files": mounted})
        build_context.return_value = {"facts": [], "parse_issues": [
            {"source_id": "dbc:cccccccccccc", "role": "dbc", "code": "parser_failed"}],
            "secret_material_in_context": False, "model_context_exported": True}
        ctx = RunContext("RUN-INTAKE-002", "UDS design", "C:/controlled-run")
        ctx.input_root = "C:/controlled-input"
        ctx.note_artifact("01_command/reference_mount.json", "e" * 64, kind="reference_mount")

        outcome = _inspect(ctx)

        self.assertEqual(outcome.status, NodeStatus.BLOCKED)
        self.assertEqual(outcome.gate_status, GateStatus.BLOCKED)
        self.assertEqual(outcome.blocked_reason, "input_parser_failed")


if __name__ == "__main__":
    unittest.main()
