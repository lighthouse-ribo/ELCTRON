# -*- coding: utf-8 -*-
"""aetex MCP 服务器测试：协议握手、工具目录、真实调用（含负向）。"""
import json
import os
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
SERVER = os.path.join(PKG, "runtime", "mcp", "server.py")
PY = sys.executable


class McpServerTest(unittest.TestCase):
    """通过真实子进程走 stdio 协议。"""

    @classmethod
    def setUpClass(cls):
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        cls.proc = subprocess.Popen(
            [PY, SERVER], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, encoding="utf-8",
            cwd=PKG, env=env,
        )

    @classmethod
    def tearDownClass(cls):
        cls.proc.stdin.close()
        cls.proc.terminate()
        cls.proc.wait(timeout=10)

    def _rpc(self, method, params=None, msg_id=None):
        msg = {"jsonrpc": "2.0", "method": method}
        if msg_id is not None:
            msg["id"] = msg_id
        if params is not None:
            msg["params"] = params
        self.proc.stdin.write(json.dumps(msg, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()
        line = self.proc.stdout.readline()
        return json.loads(line)

    def test_initialize_handshake(self) -> None:
        r = self._rpc("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "test", "version": "0"},
        }, msg_id=1)
        self.assertEqual(r["result"]["serverInfo"]["name"], "aetex")
        self.assertIn("tools", r["result"]["capabilities"])

    def test_tools_list_no_hardware(self) -> None:
        r = self._rpc("tools/list", {}, msg_id=2)
        tools = r["result"]["tools"]
        names = [t["name"] for t in tools]
        self.assertTrue(all(n.startswith(("plan__", "evidence__")) for n in names),
                        f"工具名只能 plan__/evidence__ 前缀: {names[:5]}")
        # 16 = 2 read-only router CLI + 14 pure library modules, matching allowedTools.
        self.assertEqual(len(tools), 16)
        with open(os.path.join(PKG, "runtime", "dist", "web_tool_surface.json"), encoding="utf-8") as handle:
            surface = json.load(handle)
        self.assertEqual(set(names), {f"mcp__aetex__{i}" for i in []} |
                         set(surface["web"]["allowedTools"]) and set(names),
                         "以实际清单为准")
        self.assertIn("plan__reference_router", names)
        self.assertNotIn("plan__case_lint", names)
        self.assertNotIn("plan__security_scan", names)
        self.assertIn("evidence__result_contract", names)
        self.assertEqual(set(names),
                         set(surface["web"]["allowedTools"]),
                         "MCP 工具目录必须与 Web 工具面完全一致")

    def test_call_cli_tool_help(self) -> None:
        r = self._rpc("tools/call", {
            "name": "plan__reference_router",
            "arguments": {"args": ["--help"]},
        }, msg_id=3)
        result = r["result"]
        self.assertIn("usage: reference_router.py", result["content"][0]["text"])
        self.assertFalse(result.get("isError", False))

    def test_call_library_tool(self) -> None:
        r = self._rpc("tools/call", {
            "name": "evidence__result_contract",
            "arguments": {"target": "infer_failure_class", "args": ["PASS"]},
        }, msg_id=4)
        self.assertFalse(r["result"].get("isError", False),
                         r["result"]["content"][0]["text"][:200])
        # infer_failure_class("PASS") 按能力层真源返回 "NONE"（无失败类）
        self.assertEqual(r["result"]["content"][0]["text"], '"NONE"')

    def test_call_rejects_unknown_tool(self) -> None:
        r = self._rpc("tools/call", {"name": "hardware__can_init", "arguments": {}}, msg_id=5)
        self.assertTrue(r["result"]["isError"])
        self.assertIn("不在本服务器的工具目录", r["result"]["content"][0]["text"])

    def test_call_rejects_unlisted_target(self) -> None:
        r = self._rpc("tools/call", {
            "name": "plan__review_truth",
            "arguments": {"target": "__import__", "args": []},
        }, msg_id=6)
        self.assertTrue(r["result"]["isError"])
        self.assertIn("NOT_IN_MANIFEST", r["result"]["content"][0]["text"])

    def test_unknown_method_errors(self) -> None:
        r = self._rpc("no/such/method", {}, msg_id=7)
        self.assertEqual(r["error"]["code"], -32601)


if __name__ == "__main__":
    unittest.main()
