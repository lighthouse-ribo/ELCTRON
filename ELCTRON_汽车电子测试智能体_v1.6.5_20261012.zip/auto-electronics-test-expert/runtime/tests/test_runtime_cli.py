"""Runtime CLI exposes only verified evidence summaries and controlled report artifacts."""
from __future__ import annotations
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.evidence.index_builder import build_evidence_index, write_index  # noqa: E402
from runtime.orchestrator.graph import GraphRunner, RunContext  # noqa: E402
from runtime.orchestrator import acl, runtime_cli  # noqa: E402


class RuntimeCliReadOnlyTest(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="aetex-runtime-cli-")
        self.run_id = "RUN-CLI-001"
        self.ctx = RunContext(run_id=self.run_id, flow="test", run_dir=self.root)
        os.makedirs(os.path.join(self.root, runtime_cli._REPORT_DIR), exist_ok=True)
        self.report_rel = runtime_cli._REPORT_DIR + "/approved.html"
        report_path = os.path.join(self.root, *self.report_rel.split("/"))
        with open(report_path, "w", encoding="utf-8") as handle:
            handle.write("<!doctype html><title>Controlled report</title><p>ok</p>")
        from runtime.orchestrator.hashchain import digest_file
        self.ctx.note_artifact(self.report_rel, digest_file(report_path), size=os.path.getsize(report_path), kind="report")
        GraphRunner({}).save_checkpoint(self.ctx)
        write_index(self.root, build_evidence_index(run_id=self.run_id, manifest={"captures": []}, run_dir=self.root, rule_version="test/v1"))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def request(self, action, **extra):
        return runtime_cli.handle({"action": action, "run_id": self.run_id, "run_dir": self.root, **extra})

    def test_evidence_is_summary_only_and_integrity_checked(self):
        result = self.request("evidence")
        self.assertTrue(result["ok"])
        self.assertTrue(result["evidence"]["integrity"]["verified"])
        self.assertFalse(result["evidence"]["index"]["complete"])
        self.assertIn("missing", result["evidence"]["index"])

    def test_only_artifact_backed_report_is_listed_and_readable(self):
        reports = self.request("reports")["reports"]
        self.assertEqual([report["report_id"] for report in reports], [self.report_rel])
        report = self.request("report", report_id=self.report_rel)["report"]
        self.assertIn("Controlled report", report["html"])
        with self.assertRaises(ValueError):
            self.request("report", report_id="../outside.html")

    def test_tampered_report_is_not_exposed(self):
        with open(os.path.join(self.root, *self.report_rel.split("/")), "a", encoding="utf-8") as handle:
            handle.write("tampered")
        self.assertEqual(self.request("reports")["reports"], [])

    def test_report_dir_is_acl_whitelisted(self):
        """防漂移：报告目录必须来自 ACL 白名单；历史上误用的 05_report 会被 ACL 拒绝。"""
        self.assertIn(runtime_cli._REPORT_DIR, acl.RUN_DIRS)
        with self.assertRaises(acl.AclViolation):
            acl.assert_write("terra", "05_report/approved.html")

    def test_legacy_05_report_dir_is_not_treated_as_report(self):
        """回归：报告只认 05_final；误建的 05_report 目录不得混入受控报告清单。"""
        legacy_rel = "05_report/legacy.html"
        legacy_path = os.path.join(self.root, *legacy_rel.split("/"))
        os.makedirs(os.path.dirname(legacy_path), exist_ok=True)
        with open(legacy_path, "w", encoding="utf-8") as handle:
            handle.write("<!doctype html><title>legacy</title>")
        from runtime.orchestrator.hashchain import digest_file
        self.ctx.note_artifact(legacy_rel, digest_file(legacy_path), size=os.path.getsize(legacy_path), kind="report")
        GraphRunner({}).save_checkpoint(self.ctx)
        report_ids = [report["report_id"] for report in self.request("reports")["reports"]]
        self.assertNotIn(legacy_rel, report_ids)
        self.assertIn(self.report_rel, report_ids)


if __name__ == "__main__":
    unittest.main(verbosity=2)