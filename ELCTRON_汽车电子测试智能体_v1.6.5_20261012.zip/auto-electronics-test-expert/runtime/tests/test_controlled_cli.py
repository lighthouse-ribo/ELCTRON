"""The file CLI entry is typed, hash-bound, and confined to a run."""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from runtime.orchestrator.controlled_cli import ControlledCliError, run_design_generator
from runtime.orchestrator.hashchain import digest_file


class ControlledCliTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.source_root = os.path.join(self.temp.name, "inputs")
        self.run_dir = os.path.join(self.temp.name, "run")
        os.makedirs(self.source_root)
        os.makedirs(self.run_dir)
        self.source = os.path.join(self.source_root, "cases.json")
        with open(self.source, "w", encoding="utf-8") as handle:
            json.dump({"cases": []}, handle)
        self.sha = digest_file(self.source)

    def invoke(self, **changes):
        args = {"tool_name": "steps_generator", "source_root": self.source_root,
                "source_rel": "cases.json", "source_sha256": self.sha,
                "run_dir": self.run_dir, "output_name": "steps.json"}
        args.update(changes)
        return run_design_generator(**args)

    def test_typed_call_writes_only_inside_run(self):
        def cli(_script, argv, **_kwargs):
            self.assertEqual(argv[:2], ["--cases", self.source])
            with open(argv[-1], "w", encoding="utf-8") as handle:
                json.dump({"steps": []}, handle)
            return SimpleNamespace(returncode=0, timed_out=False)
        with patch("runtime.orchestrator.controlled_cli.run_cli", side_effect=cli):
            result = self.invoke()
        self.assertEqual(result["output_path"], "02_plan/generated/steps.json")
        self.assertEqual(result["data"], {"steps": []})
        self.assertEqual(len(result["output_sha256"]), 64)

    def test_bad_source_or_output_is_rejected_before_cli(self):
        with patch("runtime.orchestrator.controlled_cli.run_cli") as cli:
            for change in ({"source_rel": "../outside.json"},
                           {"source_sha256": "0" * 64},
                           {"output_name": "../outside.json"},
                           {"tool_name": "uds_runner"}):
                with self.subTest(change=change), self.assertRaises(ControlledCliError):
                    self.invoke(**change)
            cli.assert_not_called()

    def test_output_link_is_rejected_after_cli(self):
        output = os.path.join(self.run_dir, "02_plan", "generated", "steps.json")
        def cli(_script, argv, **_kwargs):
            with open(argv[-1], "w", encoding="utf-8") as handle:
                json.dump({"steps": []}, handle)
            return SimpleNamespace(returncode=0, timed_out=False)
        with patch("runtime.orchestrator.controlled_cli.run_cli", side_effect=cli):
            with patch("runtime.orchestrator.controlled_cli.os.path.islink", side_effect=lambda path: path == output):
                with self.assertRaisesRegex(ControlledCliError, "OUTPUT_INVALID"):
                    self.invoke()

    def test_existing_output_is_never_overwritten(self):
        output = os.path.join(self.run_dir, "02_plan", "generated", "steps.json")
        os.makedirs(os.path.dirname(output))
        with open(output, "w", encoding="utf-8") as handle:
            handle.write("existing")
        with patch("runtime.orchestrator.controlled_cli.run_cli") as cli:
            with self.assertRaisesRegex(ControlledCliError, "OUTPUT_EXISTS"):
                self.invoke()
            cli.assert_not_called()
