#!/usr/bin/env python
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.agents.runner import AgentDraft, AgentNodeRunner, AgentPolicyError, AgentProfile
from runtime.agents.swdl_uds import SWDL_UDS_PROFILES, profile_for
from runtime.orchestrator.graph import RunContext
from runtime.orchestrator.graph import GraphRunner
from runtime.orchestrator.hashchain import digest_file
from runtime.orchestrator.production_nodes import _static, production_nodes
from runtime.orchestrator.state import AgentRole, GateStatus, GraphNode, NodeStatus, TaskState


class FakeInvoker:
    def __init__(self, draft: AgentDraft):
        self.draft = draft
        self.request = None

    def invoke(self, request):
        self.request = request
        return self.draft


def vickcan_draft(case_id="UDS-001"):
    return {"target_platform": "vickcan-python", "cases": [{
        "case_id": case_id, "procedure": "发送 22 F1 90", "expected": "62 F1 90 正响应",
        "precondition": "扩展会话已建立",
    }]}


class SwdlUdsAgentProfileTest(unittest.TestCase):
    def test_profiles_are_plan_only_and_no_hardware_tool_is_visible(self):
        for profile in SWDL_UDS_PROFILES:
            runner = AgentNodeRunner(profile)
            self.assertEqual(profile.role, AgentRole.PLAN_WORKER)
            self.assertNotEqual(profile.node, GraphNode.HARDWARE_GATE_AND_EXECUTE)
            self.assertFalse(any("runner" in tool or "vick" in tool for tool in runner.allowed_tools))

    def test_runner_exposes_only_artifact_summaries_and_returns_a_draft(self):
        profile = profile_for("swdl-uds-test-designer")
        ctx = RunContext(run_id="RUN-AGENT-001", flow="SWDL UDS test", run_dir="unused")
        ctx.note_artifact("02_plan/input.json", "a" * 64, kind="input")
        invoker = FakeInvoker(AgentDraft("已生成待审查的 SWDL/UDS 用例草案", vickcan_draft()))
        outcome = AgentNodeRunner(profile).run(ctx, invoker)
        self.assertEqual(outcome.status, NodeStatus.OK)
        self.assertEqual(outcome.artifact_path, "02_plan/agent.swdl-uds-test-designer.draft.json")
        self.assertEqual(invoker.request.artifacts[0]["sha256"], "a" * 64)
        self.assertFalse(hasattr(invoker.request, "token"))

    def test_profile_cannot_borrow_tool_from_another_node_or_hardware(self):
        wrong_node = AgentProfile("bad", GraphNode.INSPECT_INPUTS, AgentRole.PLAN_WORKER,
                                  "bad", ("uds_req_matrix_generator",), "draft")
        with self.assertRaisesRegex(AgentPolicyError, "AGENT_TOOL_NOT_IN_NODE"):
            AgentNodeRunner(wrong_node)
        hardware = AgentProfile("bad-hw", GraphNode.HARDWARE_GATE_AND_EXECUTE,
                                AgentRole.EXECUTION_WORKER, "bad", ("uds_runner",), "draft")
        with self.assertRaisesRegex(AgentPolicyError, "AGENT_HARDWARE_TOOL_FORBIDDEN"):
            AgentNodeRunner(hardware)

    def test_input_profile_has_only_registered_automotive_intake_tools(self):
        profile = profile_for("swdl-uds-input-inspector")
        self.assertEqual(profile.allowed_tools, (
            "srs_input_analyzer", "extract_srs_text", "srs_focus_extractor", "uds_survey_parser",
            "dbc_parser", "ldf_parser", "sddb_extract", "jcodemunch_bridge",
        ))
        self.assertNotIn("seedkey_gen2", profile.allowed_tools)

    def test_script_reviewer_receives_content_free_immutable_handoff(self):
        writer = profile_for("swdl-uds-test-designer")
        reviewer = profile_for("swdl-uds-script-reviewer")
        ctx = RunContext("RUN-HANDOFF-001", "SWDL UDS", "unused")
        ctx.note_artifact("02_plan/agent.swdl-uds-test-designer.draft.json", "b" * 64,
                          size=321, kind=writer.output_kind)
        request = AgentNodeRunner(reviewer).prepare(ctx)
        self.assertEqual(request.handoff["schema_version"], "agent-handoff/v0.1")
        self.assertFalse(request.handoff["history_included"])
        self.assertFalse(request.handoff["content_included"])
        self.assertEqual(request.handoff["source"], {
            "kind": writer.output_kind, "sha256": "b" * 64, "bytes": 321,
        })
        self.assertNotIn("path", repr(request.handoff).lower())

    def test_long_run_history_is_reduced_to_the_latest_eight_artifact_references(self):
        profile = profile_for("swdl-uds-test-designer")
        ctx = RunContext("RUN-HANDOFF-003", "SWDL UDS", "unused")
        for index in range(12):
            ctx.note_artifact(f"02_plan/private-{index}.json", f"{index:064x}", kind="draft")
        request = AgentNodeRunner(profile).prepare(ctx)
        self.assertEqual(len(request.artifacts), 8)
        self.assertEqual(request.artifacts[0]["sha256"], f"{4:064x}")
        self.assertNotIn("private", repr(request.artifacts))

    def test_reviewer_is_a_separate_static_gate_agent_and_cannot_pass_execution(self):
        writer = profile_for("swdl-uds-test-designer")
        reviewer = FakeInvoker(AgentDraft("需要检查 NRC 覆盖", {"rework_items": ["NRC coverage"]}))
        ctx = RunContext("RUN-HANDOFF-002", "SWDL UDS", "unused", state=TaskState.DESIGNED)
        ctx.note_artifact("02_plan/agent.swdl-uds-test-designer.draft.json", "c" * 64,
                          size=321, kind=writer.output_kind)
        with patch("runtime.orchestrator.production_nodes._check_draft",
                   return_value=({"test_case_spec_bundle": {"cases": [{}]}},
                                 [{"code": "SOURCE_BINDING_UNVERIFIED", "severity": "REVIEW_REQUIRED", "message": "unbound"}], "")):
            outcome = _static(ctx, reviewer)
        self.assertEqual(outcome.artifact_kind, "swdl_uds_script_review_draft")
        self.assertEqual(outcome.gate_status, GateStatus.REVIEW_REQUIRED)
        self.assertEqual(outcome.inputs, ("02_plan/agent.swdl-uds-test-designer.draft.json",))
        self.assertEqual(reviewer.request.profile.name, "swdl-uds-script-reviewer")
        self.assertFalse(reviewer.request.handoff["content_included"])

    def test_deterministic_gate_requires_hashed_draft_and_verified_source_binding(self):
        with tempfile.TemporaryDirectory() as run_dir:
            ctx = RunContext("RUN-STATIC-001", "SWDL UDS", run_dir, state=TaskState.DESIGNED)
            inspection_rel = "02_plan/input_inspection.json"
            draft_rel = "02_plan/agent.swdl-uds-test-designer.draft.json"
            inspection = {"automotive_input_context": {"parse_issues": [], "facts": [
                {"source_id": "srs:verified123", "role": "srs", "summary": {"can_generate": True,
                 "requirement_ids": ["REQ-UDS-001"]}}
            ]}}
            os.makedirs(os.path.join(run_dir, "02_plan"), exist_ok=True)
            inspection_path = os.path.join(run_dir, *inspection_rel.split("/"))
            with open(inspection_path, "w", encoding="utf-8") as handle:
                json.dump(inspection, handle)
            ctx.note_artifact(inspection_rel, digest_file(inspection_path), kind="input_inspection")
            source_draft = vickcan_draft()
            source_draft["cases"][0]["source_refs"] = ["srs:verified123", "REQ-UDS-001"]
            profile = profile_for("swdl-uds-test-designer")
            produced = AgentNodeRunner(profile).run(ctx, FakeInvoker(AgentDraft("draft", source_draft)))
            draft_path = os.path.join(run_dir, *draft_rel.split("/"))
            with open(draft_path, "w", encoding="utf-8") as handle:
                json.dump(produced.payload, handle)
            ctx.note_artifact(draft_rel, digest_file(draft_path), kind=profile.output_kind)
            self.assertEqual(_static(ctx).gate_status, GateStatus.PASS)
            produced.payload["test_case_spec_bundle"]["cases"][0]["source_refs"][1] = "REQ-NOT-IN-SRS"
            with open(draft_path, "w", encoding="utf-8") as handle:
                json.dump(produced.payload, handle)
            ctx.note_artifact(draft_rel, digest_file(draft_path), kind=profile.output_kind)
            self.assertEqual(_static(ctx).gate_status, GateStatus.REVIEW_REQUIRED)
            with open(draft_path, "a", encoding="utf-8") as handle:
                handle.write(" ")
            self.assertEqual(_static(ctx).blocked_reason, "draft_hash_mismatch")

    def test_model_context_rejects_tampered_inspection_artifact(self):
        profile = profile_for("swdl-uds-test-designer")
        with tempfile.TemporaryDirectory() as run_dir:
            os.makedirs(os.path.join(run_dir, "02_plan"))
            context_path = os.path.join(run_dir, "02_plan", "input_inspection.json")
            packet = {"automotive_input_context": {"secret_material_in_context": False,
                      "model_context_exported": True,
                      "model_context_policy": "approved_sanitized_facts_only",
                      "facts": [{"role": "srs", "source_id": "srs:verified123",
                                 "summary": {"requirement_ids": ["REQ-UDS-001"]}}]}}
            with open(context_path, "w", encoding="utf-8") as handle:
                json.dump(packet, handle)
            ctx = RunContext("RUN-CONTEXT-HASH", "UDS", run_dir)
            ctx.note_artifact("02_plan/input_inspection.json", digest_file(context_path), kind="input_inspection")
            self.assertEqual(AgentNodeRunner(profile).prepare(ctx).input_context["facts"][0]["source_id"],
                             "srs:verified123")
            packet["automotive_input_context"]["facts"][0]["source_id"] = "srs:tampered"
            with open(context_path, "w", encoding="utf-8") as handle:
                json.dump(packet, handle)
            self.assertEqual(AgentNodeRunner(profile).prepare(ctx).input_context, {})

    def test_agent_cannot_smuggle_approval_or_secret_fields_into_a_draft(self):
        profile = profile_for("swdl-uds-input-inspector")
        for payload in ({"approval_token": "secret"}, {"draft": {"api_key": "secret"}}):
            with self.subTest(payload=payload):
                invoker = FakeInvoker(AgentDraft("bad", payload))
                with self.assertRaisesRegex(AgentPolicyError, "AGENT_DRAFT_CONTAINS"):
                    AgentNodeRunner(profile).run(RunContext("RUN-AGENT-002", "UDS", "unused"), invoker)

    def test_missing_manifest_blocks_before_any_model_invocation(self):
        invokers = {
            "swdl-uds-input-inspector": FakeInvoker(AgentDraft("资料体检草案", {"missing": []})),
            "swdl-uds-test-designer": FakeInvoker(AgentDraft("用例设计草案", vickcan_draft())),
        }
        with tempfile.TemporaryDirectory() as run_dir:
            ctx = RunContext("RUN-AGENT-003", "SWDL UDS", run_dir)
            GraphRunner(production_nodes(agent_invokers=invokers)).run(ctx)
            self.assertEqual(ctx.last_node, GraphNode.ROUTE_AND_MOUNT_REFERENCE)
            self.assertEqual(ctx.last_status, NodeStatus.BLOCKED)
            self.assertEqual(ctx.blocked_reason, "input_manifest_required")
            self.assertIsNone(invokers["swdl-uds-input-inspector"].request)
            self.assertIsNone(invokers["swdl-uds-test-designer"].request)

    def test_design_agent_runs_in_the_runtime_graph_and_stops_for_human_review(self):
        invokers = {"swdl-uds-test-designer": FakeInvoker(AgentDraft("用例设计草案", vickcan_draft()))}
        with tempfile.TemporaryDirectory() as run_dir:
            ctx = RunContext("RUN-AGENT-004", "SWDL UDS", run_dir, state=TaskState.INSPECTED)
            GraphRunner(production_nodes(agent_invokers=invokers)).run(
                ctx, start_at=GraphNode.GENERATE_OR_DESIGN)
            self.assertEqual(ctx.last_node, GraphNode.STATIC_GATE)
            self.assertEqual(ctx.last_status, NodeStatus.OK)
            self.assertEqual(ctx.last_gate, GateStatus.REVIEW_REQUIRED)
            self.assertEqual([item.path for item in ctx.artifacts], [
                "02_plan/agent.swdl-uds-test-designer.draft.json",
                "02_plan/static_gate.review_required.json",
            ])

    def test_manifest_drives_read_only_design_chain_without_execution(self):
        designer = FakeInvoker(AgentDraft("用例设计草案", vickcan_draft()))
        with tempfile.TemporaryDirectory() as root, tempfile.TemporaryDirectory() as run_dir:
            source = os.path.join(root, "requirements.txt")
            with open(source, "w", encoding="utf-8") as handle:
                handle.write("REQ-001: Read 0xF190 via UDS service 0x22.")
            ctx = RunContext("RUN-AGENT-005", "SWDL UDS", run_dir)
            ctx.input_root = root
            ctx.input_manifest = ({"role": "srs", "path": "requirements.txt"},)
            GraphRunner(production_nodes(agent_invokers={"swdl-uds-test-designer": designer})).run(ctx)
            self.assertEqual(ctx.last_node, GraphNode.STATIC_GATE)
            self.assertEqual(ctx.last_gate, GateStatus.REVIEW_REQUIRED)
            self.assertEqual([item.path for item in ctx.artifacts], [
                "01_command/reference_mount.json",
                "02_plan/input_inspection.json",
                "02_plan/agent.swdl-uds-test-designer.draft.json",
                "02_plan/static_gate.review_required.json",
            ])
            self.assertTrue(designer.request is not None)
            self.assertFalse(any(item.path.startswith("03_execution/") for item in ctx.artifacts))

    def test_canviex_executor_is_never_wired_without_explicit_injection(self):
        nodes = production_nodes()
        self.assertEqual(nodes[GraphNode.HARDWARE_GATE_AND_EXECUTE].__name__, "_execute")


if __name__ == "__main__":
    unittest.main()
