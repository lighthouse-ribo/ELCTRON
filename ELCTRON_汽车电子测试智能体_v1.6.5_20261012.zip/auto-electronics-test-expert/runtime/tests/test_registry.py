# -*- coding: utf-8 -*-
"""工具注册表与可调用性硬化的测试。

这批测试保护的是一个**已实测发生的静默失效**：

    review_truth.py / project_artifact_binding.py 没有 __main__ 入口，
    按 CLI 调用得到「退出码 0 + 空输出」，而 0 被映射成 PASS
    -> 静态门禁的两条规则从未执行，却每次通过。

所以关键断言不是"注册表好看"，而是：
  * 库模块**必须被拒绝**，不得静默返回空输出；
  * 注册表与磁盘事实**必须一致**，新增脚本不登记就要红（棘轮）；
  * `hardware` 组**不得**出现在 Web 层工具面里（红线）。
"""
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
if PKG not in sys.path:
    sys.path.insert(0, PKG)

from runtime.orchestrator import registry as R      # noqa: E402
from runtime.orchestrator import tools as T          # noqa: E402
from runtime.orchestrator.graph import GraphNode     # noqa: E402

LIBRARY_ONLY = [
    "skills/uds-diagnostic-test/scripts/review_truth.py",
    "skills/uds-diagnostic-test/scripts/project_artifact_binding.py",
]


class RegistryConsistencyTest(unittest.TestCase):
    def test_no_problems_against_real_package(self) -> None:
        self.assertEqual(R.verify_registry(PKG), [])

    def test_registry_covers_every_non_test_script(self) -> None:
        # 注册表以 basename 为键；磁盘扫描返回相对路径，这里统一成 basename 再比。
        on_disk = {os.path.splitext(os.path.basename(r))[0]
                   for r in R.classify_on_disk(PKG)}
        registered = {s.name for s in R.TOOL_REGISTRY}
        self.assertEqual(
            on_disk - registered, set(),
            "磁盘上出现未登记脚本：新增脚本必须进注册表（棘轮）")
        self.assertEqual(
            registered - on_disk, set(),
            "注册表里有磁盘上不存在的脚本")

    def test_kind_matches_reality(self) -> None:
        disk = R.classify_on_disk(PKG)
        for spec in R.TOOL_REGISTRY:
            rel = next(r for r in disk
                       if os.path.splitext(os.path.basename(r))[0] == spec.name)
            with self.subTest(tool=spec.name):
                self.assertEqual(spec.kind, disk[rel],
                                 f"{rel} 的 kind 声明与磁盘入口事实不符")

    def test_counts_match_measured_facts(self) -> None:
        self.assertEqual(len(R.TOOL_REGISTRY), 81)
        self.assertEqual(len(R.cli_tools()), 50)
        self.assertEqual(len(R.library_tools()), 31)

    def test_node_keys_are_real_graph_nodes(self) -> None:
        valid = {n.value for n in GraphNode}
        for spec in R.TOOL_REGISTRY:
            if not spec.node:
                continue
            with self.subTest(tool=spec.name):
                self.assertIn(spec.node, valid,
                              f"{spec.name} 挂到了不存在的节点 {spec.node}")


class WebSurfaceTest(unittest.TestCase):
    def test_hardware_never_exposed_to_web(self) -> None:
        leaked = [s.name for s in R.web_surface() if s.group == R.HARDWARE]
        self.assertEqual(leaked, [], "硬件工具不得下发 Web 层（红线）")

    def test_web_surface_is_read_only_groups(self) -> None:
        groups = {s.group for s in R.web_surface()}
        self.assertTrue(groups <= {R.PLAN, R.EVIDENCE})

    def test_library_modules_are_excluded_from_execution_groups(self) -> None:
        """库模块可以是 PLAN/EVIDENCE，但不得被当成可直接执行的 CLI。"""
        for spec in R.library_tools():
            with self.subTest(tool=spec.name):
                self.assertNotEqual(spec.kind, R.CLI)


class CliCallableGuardTest(unittest.TestCase):
    """核心安全断言：库模块必须被拒绝，而不是返回空输出。"""

    def test_run_cli_refuses_library_modules(self) -> None:
        for rel in LIBRARY_ONLY:
            with self.subTest(script=rel):
                with self.assertRaises(T.CliToolError) as ctx:
                    T.run_cli(rel, ["--help"], timeout=30)
                self.assertIn("__main__", str(ctx.exception))

    def test_library_modules_report_not_callable(self) -> None:
        avail = T.available_tools()
        for rel in LIBRARY_ONLY:
            with self.subTest(script=rel):
                self.assertFalse(avail[rel],
                                 "库模块不得被报告为可 CLI 调用")

    def test_real_cli_tools_still_callable(self) -> None:
        for rel in ("skills/uds-diagnostic-test/scripts/reference_router.py",
                    "skills/srs-uds-testcase-designer/scripts/case_lint.py",
                    "skills/uds-diagnostic-test/scripts/script_review.py"):
            with self.subTest(script=rel):
                self.assertTrue(T.cli_callable(rel))

    def test_cli_callable_false_for_missing_script(self) -> None:
        self.assertFalse(T.cli_callable("skills/uds-diagnostic-test/scripts/no_such.py"))


class CatalogTest(unittest.TestCase):
    def test_catalog_shape(self) -> None:
        cat = T.tool_catalog()
        self.assertEqual(len(cat), len(R.TOOL_REGISTRY))
        for row in cat:
            self.assertEqual(
                set(row), {"name", "group", "node", "kind", "purpose", "web_exposed"})
        self.assertEqual(sum(1 for r in cat if r["web_exposed"]),
                         len(R.web_surface()))

    def test_web_exposed_matches_group(self) -> None:
        for row in T.tool_catalog():
            expected = row["group"] in (R.PLAN, R.EVIDENCE)
            with self.subTest(tool=row["name"]):
                self.assertEqual(row["web_exposed"], expected)


class RatchetCanFailTest(unittest.TestCase):
    """门禁必须能失败。只测 happy path 的检查等于没检查。"""

    def test_unregistered_script_is_detected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            script_dir = os.path.join(tmp, "skills", "uds-diagnostic-test", "scripts")
            os.makedirs(script_dir)
            rogue = os.path.join(script_dir, "rogue_tool.py")
            with open(rogue, "w", encoding="utf-8", newline="\n") as fh:
                fh.write('if __name__ == "__main__":\n    print("hi")\n')
            problems = R.verify_registry(tmp)
        self.assertTrue(any("未登记" in p for p in problems),
                        f"未登记脚本没有被检出：{problems}")

    def test_kind_mismatch_is_detected(self) -> None:
        """把库模块声明成 cli，必须被检出。"""
        original = R.TOOL_REGISTRY
        try:
            patched = tuple(
                R.ToolSpec(s.name, s.group, s.node,
                           R.CLI if s.name == "review_truth" else s.kind,
                           s.purpose)
                for s in original)
            R.TOOL_REGISTRY = patched
            problems = R.verify_registry(PKG)
        finally:
            R.TOOL_REGISTRY = original
        self.assertTrue(any("没有 __main__ 入口" in p for p in problems),
                        f"kind 声明错误没有被检出：{problems}")


if __name__ == "__main__":
    unittest.main()
