#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.2 生成模型的一致性测试。

四条主线：
  1. **漂移**：生成物必须与 schema 一致（`gen_models.py --check`）。
  2. **一致**：schema 里的每个 example 都能被对应 pydantic 模型构造，且回写 JSON
     后仍通过权威 schema 校验（模型与 schema 不得语义分叉）。
  3. **能失败**：非法取值、非白名单字段、跨字段约束违例都必须被拒。
  4. **不空跑**：每个 schema 都必须有对应模型，不允许静默跳过。

运行:
  python -m unittest discover -s runtime/tests -v
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
for p in (PKG_ROOT, os.path.join(PKG_ROOT, "runtime", "tools")):
    if p not in sys.path:
        sys.path.insert(0, p)

CONTRACTS = os.path.join(PKG_ROOT, "runtime", "contracts")
GEN = os.path.join(PKG_ROOT, "runtime", "tools", "gen_models.py")


def schema_files() -> list[str]:
    """全部契约 schema 文件路径列表。"""
    return sorted(f for f in os.listdir(CONTRACTS) if f.endswith(".schema.json"))


def load_schema(name: str) -> dict:
    """读单个 schema 文档。"""
    with open(os.path.join(CONTRACTS, name), encoding="utf-8") as fh:
        return json.load(fh)


def model_for(name: str):
    """task_state.v0.1.schema.json -> generated.models.TaskState"""
    from runtime.contracts.generated import models
    cls_name = name[: -len(".schema.json")].split(".")[0]
    return getattr(models, "".join(p[:1].upper() + p[1:] for p in cls_name.split("_")))


class GenerationDriftTest(unittest.TestCase):
    def test_generated_models_are_up_to_date(self) -> None:
        """改了 schema 没重新生成 -> 必须失败。"""
        proc = subprocess.run([sys.executable, GEN, "--root", PKG_ROOT, "--check"],
                              capture_output=True, text=True, encoding="utf-8",
                              errors="replace", env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        self.assertEqual(proc.returncode, 0, msg=proc.stdout + proc.stderr)

    def test_generated_file_marked_do_not_edit(self) -> None:
        """生成物必须自带「勿手工编辑」标记，否则人可能直接改它。"""
        path = os.path.join(CONTRACTS, "generated", "models.py")
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        self.assertIn("自动生成", text.splitlines()[1] + text.splitlines()[2])
        self.assertIn("gen_models.py", text)

    def test_every_schema_has_a_model(self) -> None:
        """不允许静默跳过：每个 schema 都要有对应模型类。"""
        from runtime.contracts.generated import models
        for name in schema_files():
            with self.subTest(schema=name):
                cls = model_for(name)
                self.assertTrue(issubclass(cls, __import__("pydantic").BaseModel))
                self.assertIn(cls.__name__, models.__all__)

    def test_every_contract_has_examples(self) -> None:
        """没有样本的契约无法自证，视为未完成。"""
        for name in schema_files():
            with self.subTest(schema=name):
                self.assertTrue(load_schema(name).get("examples"), f"{name} 缺少 examples")


class ModelSchemaConformanceTest(unittest.TestCase):
    def test_examples_build_and_roundtrip(self) -> None:
        """schema 的每个 example：模型能构造，且回写后仍过权威 schema。"""
        from runtime.contracts import validation

        checked = 0
        for name in schema_files():
            cls = model_for(name)
            schema = load_schema(name)
            for idx, sample in enumerate(schema.get("examples", [])):
                with self.subTest(schema=name, example=idx):
                    model = cls.model_validate(sample)
                    dumped = model.model_dump(mode="json", exclude_unset=True, by_alias=True)
                    cid = schema["properties"]["schema_version"]["const"]
                    self.assertEqual(validation.report(cid, dumped), [])
                    checked += 1
        self.assertGreaterEqual(checked, 12, "样本总数异常偏少，可能漏扫")

    def test_required_fields_enforced(self) -> None:
        """必填字段缺失 -> pydantic 必须拒绝。"""
        cls = model_for("task_state.v0.1.schema.json")
        with self.assertRaises(Exception):
            cls.model_validate({"schema_version": "task-state/v0.1"})

    def test_extra_field_rejected(self) -> None:
        """additionalProperties:false -> 非白名单字段必须被拒。"""
        cls = model_for("gate_record.v0.1.schema.json")
        sample = load_schema("gate_record.v0.1.schema.json")["examples"][0]
        with self.assertRaises(Exception):
            cls.model_validate({**sample, "unexpected_field": 1})

    def test_illegal_enum_rejected(self) -> None:
        """枚举外的取值必须被拒（这里是最容易被模型放水的地方）。"""
        cls = model_for("verdict_draft.v0.1.schema.json")
        sample = load_schema("verdict_draft.v0.1.schema.json")["examples"][0]
        with self.assertRaises(Exception):
            cls.model_validate({**sample, "verdict": "NOT_A_VERDICT"})

    def test_pattern_enforced(self) -> None:
        """sha256 必须 64 位小写十六进制。"""
        cls = model_for("approved_order.v0.1.schema.json")
        sample = load_schema("approved_order.v0.1.schema.json")["examples"][0]
        with self.assertRaises(Exception):
            cls.model_validate({**sample, "plan_sha256": "NOT-A-HASH"})

    def test_final_verdict_is_never_true(self) -> None:
        """VerdictDraft.final 恒为 false —— 草案不得冒充最终结论。"""
        cls = model_for("verdict_draft.v0.1.schema.json")
        sample = load_schema("verdict_draft.v0.1.schema.json")["examples"][0]
        cls.model_validate(sample)                      # false 通过
        with self.assertRaises(Exception):
            cls.model_validate({**sample, "final": True})

    def test_secret_material_flag_is_never_true(self) -> None:
        """MemoryCandidate.contains_secret_material 恒为 false。"""
        cls = model_for("memory_candidate.v0.1.schema.json")
        sample = load_schema("memory_candidate.v0.1.schema.json")["examples"][0]
        cls.model_validate(sample)
        with self.assertRaises(Exception):
            cls.model_validate({**sample, "contains_secret_material": True})


class AuthoritativeCrossFieldTest(unittest.TestCase):
    """含 allOf / if-then 的契约：pydantic 声明式语法表达不了，必须回放权威 schema。"""

    def test_evidence_index_missing_forces_incomplete(self) -> None:
        cls = model_for("evidence_index.v0.1.schema.json")
        bad = {
            "schema_version": "evidence-index/v0.1",
            "run_id": "RUN-001",
            "rule_version": "expectation_check/2026-09-04",
            "entries": [],
            "missing": [{"required_for": "TC-1", "reason": "ASC 未建立"}],
            "complete": True,          # 与 missing 非空冲突
        }
        with self.assertRaises(Exception) as ctx:
            cls.model_validate(bad)
        self.assertIn("complete", str(ctx.exception))

    def test_evidence_index_consistent_passes(self) -> None:
        cls = model_for("evidence_index.v0.1.schema.json")
        for sample in load_schema("evidence_index.v0.1.schema.json")["examples"]:
            cls.model_validate(sample)

    def test_authoritative_hook_only_on_needed_contracts(self) -> None:
        """只给含跨字段约束的契约挂回放校验，其余零额外开销。"""
        from runtime.contracts.generated import models
        self.assertIn("EvidenceIndex", models.AUTHORITATIVE_CONTRACTS)
        self.assertEqual(len(models.AUTHORITATIVE_CONTRACTS), 1)
        for cls_name in ("TaskState", "GateRecord", "RunManifest", "VerdictDraft"):
            with self.subTest(cls=cls_name):
                cls = getattr(models, cls_name)
                self.assertFalse(hasattr(cls, "__contract_id__"))


if __name__ == "__main__":
    unittest.main(verbosity=2)


class RuntimeSourceHygieneTest(unittest.TestCase):
    """运行时目录的卫生检查。

    加这一组的原因：本轮实际遇到过「文件头声明 utf-8、磁盘却是 GBK」的情况，
    表现为 `python xxx.py` 直接 SyntaxError，而文件本身看着没问题。
    这类问题必须在门禁里拦，而不是靠人眼看。
    """

    ROOT = os.path.join(PKG_ROOT, "runtime")

    def _source_files(self):
        for dirpath, dirnames, filenames in os.walk(self.ROOT):
            dirnames[:] = [d for d in dirnames if d != "__pycache__"]
            for fn in filenames:
                if fn.endswith((".py", ".json", ".md")):
                    yield os.path.join(dirpath, fn)

    def test_all_runtime_sources_are_utf8(self) -> None:
        """runtime/ 下所有 .py/.json/.md 必须是合法 UTF-8。"""
        bad = []
        for path in self._source_files():
            with open(path, "rb") as fh:
                raw = fh.read()
            try:
                raw.decode("utf-8")
            except UnicodeDecodeError as exc:
                bad.append(f"{os.path.relpath(path, PKG_ROOT)} @byte {exc.start}")
        self.assertEqual(bad, [], f"以下文件不是 UTF-8：{bad}")

    def test_no_pycache_inside_runtime(self) -> None:
        """运行时目录不应留下 __pycache__（跑测试请带 PYTHONDONTWRITEBYTECODE=1）。"""
        found = []
        for dirpath, dirnames, _ in os.walk(self.ROOT):
            if "__pycache__" in dirnames:
                found.append(os.path.relpath(os.path.join(dirpath, "__pycache__"), PKG_ROOT))
        self.assertEqual(found, [], f"发现缓存目录：{found}")

    def test_generated_dir_is_declared_generated(self) -> None:
        """生成目录必须带明确标记，避免有人把生成物当真源改。"""
        path = os.path.join(CONTRACTS, "generated", "models.py")
        with open(path, encoding="utf-8") as fh:
            head = "".join(fh.readlines()[:12])
        self.assertIn("自动生成", head)
        self.assertIn("gen_models.py", head)
