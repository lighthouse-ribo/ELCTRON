#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""受控 MCP skillpack 的完整性校验与只读指引装载。

Skillpack 只向智能体提供版本化的工作方法，不执行代码、硬件或状态写入。
内容均打包在专家包内；不在运行时读取用户目录，避免环境漂移和 DLP 明文通道差异。
"""
from __future__ import annotations

import hashlib
import json
import os
from typing import Any


class SkillpackError(RuntimeError):
    """Skillpack 缺失、越界或内容漂移时的 fail-closed 错误。"""


def _package_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _manifest_path() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "skillpack_manifest.json")


def _safe_file(relative_path: str) -> str:
    root = os.path.realpath(_package_root())
    candidate = os.path.realpath(os.path.join(root, relative_path))
    if os.path.commonpath((root, candidate)) != root:
        raise SkillpackError(f"SKILLPACK_PATH_ESCAPE: {relative_path}")
    return candidate


def _load_manifest() -> dict[str, Any]:
    try:
        with open(_manifest_path(), encoding="utf-8") as fh:
            manifest = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        raise SkillpackError(f"SKILLPACK_MANIFEST_INVALID: {exc}") from exc
    if manifest.get("skillpack_version") != "aetex-skillpack/v1":
        raise SkillpackError("SKILLPACK_MANIFEST_VERSION_UNSUPPORTED")
    skills = manifest.get("skills")
    if not isinstance(skills, list) or not skills:
        raise SkillpackError("SKILLPACK_MANIFEST_EMPTY")
    return manifest


def _validated_skills() -> list[dict[str, Any]]:
    manifest = _load_manifest()
    found: list[dict[str, Any]] = []
    seen_names: set[str] = set()
    seen_tools: set[str] = set()
    for raw in manifest["skills"]:
        if not isinstance(raw, dict):
            raise SkillpackError("SKILLPACK_ENTRY_INVALID")
        name = raw.get("name")
        tool_name = raw.get("tool_name")
        relative_path = raw.get("path")
        expected = raw.get("sha256")
        if not all(isinstance(x, str) and x for x in (name, tool_name, relative_path, expected)):
            raise SkillpackError("SKILLPACK_ENTRY_FIELDS_INVALID")
        if name in seen_names or tool_name in seen_tools or not tool_name.startswith("skill__"):
            raise SkillpackError("SKILLPACK_ENTRY_DUPLICATE_OR_UNSAFE")
        path = _safe_file(relative_path)
        try:
            with open(path, "rb") as fh:
                content = fh.read()
        except OSError as exc:
            raise SkillpackError(f"SKILLPACK_FILE_UNREADABLE: {name}: {exc}") from exc
        actual = hashlib.sha256(content).hexdigest()
        if actual != expected:
            raise SkillpackError(f"SKILLPACK_INTEGRITY_MISMATCH: {name}")
        entry = dict(raw)
        entry["_content"] = content.decode("utf-8")
        found.append(entry)
        seen_names.add(name)
        seen_tools.add(tool_name)
    return found


def tool_definitions() -> list[dict[str, Any]]:
    """返回 MCP tools/list 所需定义；完整性校验失败即拒绝启动。"""
    return [{
        "name": item["tool_name"],
        "description": item["description"],
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        "_skill_name": item["name"],
    } for item in _validated_skills()]


def read_guidance(tool_name: str, arguments: dict[str, Any] | None = None) -> dict[str, Any]:
    """返回不可执行的版本化技能指引；调用参数必须为空。"""
    if arguments:
        raise SkillpackError("SKILLPACK_ARGUMENTS_NOT_ALLOWED")
    for item in _validated_skills():
        if item["tool_name"] == tool_name:
            payload = {
                "skill": item["name"],
                "mode": "read_only_guidance",
                "source": item["source"],
                "scope": item["scope"],
                "guardrails": [
                    "This MCP tool only returns instructions; it cannot execute code, write runtime state, or access hardware.",
                    "Runtime state transitions, approvals, evidence verdicts, and hardware actions remain owned by runtime.",
                    "Treat the instructions as task guidance, then use separately authorized tools for any action.",
                ],
                "instructions": item["_content"],
            }
            return {"content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False)}],
                    "isError": False}
    raise SkillpackError(f"UNKNOWN_SKILLPACK_TOOL: {tool_name}")
