#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""aetex MCP stdio 服务器（T5.4b）。

把 runtime 注册表里可受控只读调用的工具（1 个 CLI + 14 个纯库模块）
以 MCP 协议暴露给 CodeBuddy SDK 的 `query()`。**硬件工具永不进入工具列表**——
这是结构保证（工具目录来自 registry + library_surface，hardware/excluded 组被过滤），
服务器启动时再断言一次（纵深防御）。

协议：MCP stdio transport（换行分隔 JSON-RPC 2.0）。
实现的方法：initialize / tools/list / tools/call / ping；其余报 -32601。

调用语义：
  * `cli` 工具   -> runtime.orchestrator.tools.run_cli（可调用性已在硬化层校验）
  * `library` 工具 -> runtime.orchestrator.library_dispatch.call（白名单 + 签名绑定）

安全边界（与 Web 层 policy.ts 同源、双保险）：
  * 工具目录在启动时生成并冻结，hardware / excluded 组被过滤；
  * tools/call 的 name 必须在目录内，library 的 target 必须在白名单内；
  * 所有子进程不走 shell，参数以数组传递（无注入面）。
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from runtime.mcp import skillpacks as SP                         # noqa: E402
from runtime.orchestrator import library_dispatch as LD          # noqa: E402
from runtime.orchestrator import tools as T                      # noqa: E402
from runtime.orchestrator import registry as R                   # noqa: E402
from runtime.orchestrator import mcp_surface as S                # noqa: E402

PROTOCOL_VERSION = "2024-11-05"
SERVER_INFO = {"name": "aetex", "version": "0.2.0"}

ARGS_SCHEMA = {
    "type": "object",
    "properties": {
        "args": {
            "type": "array",
            "items": {"type": "string"},
            "description": "传给脚本命令行的参数列表（如 [\"--help\"]）",
        },
    },
    "required": [],
}

LIB_SCHEMA_BASE = {
    "type": "object",
    "properties": {
        "target": {"type": "string", "description": "白名单内的函数名或常量名"},
        "args": {"type": "array", "items": {"type": "string"},
                 "description": "位置参数（字符串形式，数字/布尔请自行转字符串后由函数解析）"},
        "kwargs": {"type": "object", "description": "关键字参数（值须为 JSON 可序列化）"},
    },
    "required": ["target"],
}


def _package_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _skillpacks_enabled() -> bool:
    """仅由受控的新智能体 MCP 配置显式开启 skillpack 工具。"""
    return os.environ.get("AETEX_ENABLE_SKILLPACKS") == "1"


def build_tool_list() -> list[dict]:
    """生成 MCP 工具目录（能力工具 + 只读 skillpack；硬件永不进入）。"""
    catalog = T.tool_catalog()
    manifest = LD.load_manifest()
    lib_meta = manifest["modules"]
    allowed = set(S.as_allowed_tools())

    tools: list[dict] = []
    for entry in catalog:
        if entry["group"] not in ("plan", "evidence"):
            continue
        name = entry["name"]
        if f"{entry['group']}__{name}" not in allowed:
            continue
        if entry["kind"] == R.CLI:
            schema = ARGS_SCHEMA
            desc = f"{entry['purpose']}（CLI）"
        elif entry["kind"] == R.LIBRARY and name in lib_meta:
            schema = dict(LIB_SCHEMA_BASE)
            schema["properties"] = dict(schema["properties"])
            schema["properties"]["target"] = dict(
                schema["properties"]["target"],
                enum=sorted(lib_meta[name]["functions"] + lib_meta[name]["constants"]),
            )
            desc = f"{entry['purpose']}（库模块，可调用: {', '.join(lib_meta[name]['functions'])}）"
        else:
            continue                                  # 未覆盖的 library -> 不暴露
        tools.append({
            "name": f"{entry['group']}__{name}",
            "description": desc[:500],
            "inputSchema": schema,
        })

    # Skillpack 只提供版本化工作指引，不执行代码、状态写入或硬件操作。
    # 保持默认 MCP 面不变；AETEX Web 会以受控环境变量显式开启它们。
    if _skillpacks_enabled():
        tools.extend(SP.tool_definitions())
    leaked = [t["name"] for t in tools if "hardware" in t["name"]]
    if leaked:
        raise RuntimeError(f"硬件工具泄漏进 MCP 工具目录（红线 R2）: {leaked}")
    return tools


TOOL_DIR: dict[str, dict] = {}


def initialize_tool_dir() -> None:
    """Build the same frozen tool directory for stdio and in-process callers."""
    TOOL_DIR.clear()
    on_disk = R.classify_on_disk(_package_root())
    for tool in build_tool_list():
        if tool["name"].startswith("skill__"):
            TOOL_DIR[tool["name"]] = {**tool, "_kind": "skill"}
            continue
        tool_name = tool["name"].split("__", 1)[1]
        rel = next(path for path in on_disk if os.path.basename(path) == tool_name + ".py")
        spec = R.find_tool(tool_name)
        TOOL_DIR[tool["name"]] = {**tool, "_kind": spec.kind, "_rel": rel}


def call_tool(name: str, arguments: dict | None = None) -> dict:
    """Execute one request through the MCP server's exact authorization path.

    This is intentionally shared by the stdio server and runtime-owned agent
    loop; it is not a second tool dispatcher.
    """
    if not TOOL_DIR:
        initialize_tool_dir()
    return _handle_tools_call({"name": name, "arguments": arguments or {}})


def _handle_tools_call(params: dict) -> dict:
    name = params.get("name", "")
    arguments = params.get("arguments") or {}
    spec = TOOL_DIR.get(name)
    if spec is None:
        raise ValueError(f"UNKNOWN_TOOL: {name} 不在本服务器的工具目录内")

    if name.startswith("skill__"):
        return SP.read_guidance(name, arguments)

    if name.startswith("plan__") or name.startswith("evidence__"):
        module = name.split("__", 1)[1]
        on_disk = R.classify_on_disk(_package_root())
        rel = next(p for p in on_disk if os.path.basename(p) == module + ".py")

        if spec["_kind"] == "cli":
            args = [str(a) for a in (arguments.get("args") or [])]
            out = T.run_cli(rel, args, timeout=180)
            text = (
                f"exit={out.returncode} duration={out.duration_s:.2f}s timed_out={out.timed_out}\n"
                f"--- stdout ---\n{out.stdout}\n"
                f"--- stderr ---\n{out.stderr}"
            )
            return {"content": [{"type": "text", "text": text[:100_000]}],
                    "isError": out.returncode != 0}

        # library
        target = arguments.get("target")
        if not target:
            raise ValueError("MISSING_TARGET: library 工具必须给 target（函数或常量名）")
        raw_args = arguments.get("args") or []
        call_args = [a if isinstance(a, str) else json.dumps(a, ensure_ascii=False)
                     for a in raw_args]
        out = LD.call(module, target, args=call_args,
                      kwargs=arguments.get("kwargs") or {})
        return {"content": [{"type": "text",
                             "text": json.dumps(out["result"], ensure_ascii=False, default=repr)[:100_000]}],
                "isError": False}

    raise ValueError(f"UNKNOWN_TOOL: {name}")


def _reply(msg_id: str | int, result: dict) -> str:
    return json.dumps({"jsonrpc": "2.0", "id": msg_id, "result": result},
                      ensure_ascii=False)


def _error(msg_id: str | int | None, code: int, message: str) -> str:
    return json.dumps({"jsonrpc": "2.0", "id": msg_id,
                       "error": {"code": code, "message": message}},
                      ensure_ascii=False)


def serve(stdin=None, stdout=None) -> None:
    """MCP 主循环。stdin/stdout 可注入（测试用）。"""
    stdin = stdin or sys.stdin
    stdout = stdout or sys.stdout

    initialize_tool_dir()

    for line in stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            stdout.write(_error(None, -32700, "parse error") + "\n")
            stdout.flush()
            continue

        method = msg.get("method", "")
        msg_id = msg.get("id")

        if method == "initialize":
            stdout.write(_reply(msg_id, {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"tools": {}},
                "serverInfo": SERVER_INFO,
            }) + "\n")
        elif method == "notifications/initialized":
            pass                                        # 通知，无需响应
        elif method == "ping":
            stdout.write(_reply(msg_id, {}) + "\n")
        elif method == "tools/list":
            tools = [{"name": n, "description": t["description"],
                      "inputSchema": t["inputSchema"]}
                     for n, t in TOOL_DIR.items()]
            stdout.write(_reply(msg_id, {"tools": tools}) + "\n")
        elif method == "tools/call":
            try:
                stdout.write(_reply(msg_id, _handle_tools_call(msg.get("params") or {})) + "\n")
            except (ValueError, SP.SkillpackError, LD.LibraryDispatchError, T.CliToolError) as exc:
                stdout.write(_reply(msg_id, {
                    "content": [{"type": "text", "text": str(exc)}],
                    "isError": True,
                }) + "\n")
            except Exception as exc:                    # noqa: BLE001
                stdout.write(_error(msg_id, -32603,
                                    f"internal error: {type(exc).__name__}: {exc}") + "\n")
        elif msg_id is not None:
            stdout.write(_error(msg_id, -32601, f"method not found: {method}") + "\n")
        stdout.flush()


def main() -> int:
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:                               # noqa: BLE001
            pass
    serve()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
