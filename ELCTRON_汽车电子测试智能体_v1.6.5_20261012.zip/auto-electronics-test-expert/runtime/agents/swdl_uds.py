"""SWDL/UDS 测试工作流的节点内嵌智能体 profile。

两项 profile 都只能生成草案；静态门禁、审批和硬件执行仍由 runtime 的确定性节点负责。
"""
from __future__ import annotations

from .runner import AgentProfile
from runtime.orchestrator.state import AgentRole, GraphNode


SWDL_UDS_PROFILES: tuple[AgentProfile, ...] = (
    AgentProfile(
        name="swdl-uds-input-inspector",
        node=GraphNode.INSPECT_INPUTS,
        role=AgentRole.PLAN_WORKER,
        purpose="识别 SWDL/UDS 输入资料、会话、安全访问、分区和缺失前置条件",
        allowed_tools=("srs_input_analyzer", "extract_srs_text", "srs_focus_extractor", "uds_survey_parser",
                       "dbc_parser", "ldf_parser", "sddb_extract", "jcodemunch_bridge",
                       "web_probe"),
        output_kind="swdl_uds_input_inspection_draft",
        requires_deterministic_gate=True,
    ),
    AgentProfile(
        name="swdl-uds-test-designer",
        node=GraphNode.GENERATE_OR_DESIGN,
        role=AgentRole.PLAN_WORKER,
        # 保留既有 profile 名称，避免现有模型路由配置失效；职责已收窄为脚本编写。
        purpose="编写 SWDL/UDS 用例、步骤和脚本草案；不得给出审查或执行结论",
        allowed_tools=("uds_req_matrix_generator", "steps_generator", "gen_case_scripts", "swdl_case_generator"),
        output_kind="swdl_uds_script_draft",
        max_turns=4,
    ),
    AgentProfile(
        name="swdl-uds-script-reviewer",
        node=GraphNode.STATIC_GATE,
        role=AgentRole.PLAN_WORKER,
        purpose="基于不可变脚本草案引用提出审查清单与返工项；不得读取脚本内容或放行执行",
        allowed_tools=("case_lint", "script_review", "consistency_check", "review_depth"),
        output_kind="swdl_uds_script_review_draft",
        max_turns=3,
        handoff_from_kinds=("swdl_uds_script_draft",),
    ),
)


def profile_for(name: str) -> AgentProfile:
    for profile in SWDL_UDS_PROFILES:
        if profile.name == name:
            return profile
    raise KeyError(f"未知 SWDL/UDS agent profile: {name}")


__all__ = ["SWDL_UDS_PROFILES", "profile_for"]
