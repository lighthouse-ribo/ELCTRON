"""节点内嵌智能体的最小受控执行器。

它不是全局自治 Agent Loop：GraphRunner 仍拥有流程、状态、门禁和审批。
本模块只把某个业务节点的受限上下文、工具白名单及结构化草案交给模型适配器。
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol

from runtime.orchestrator import acl
from runtime.orchestrator import registry as R
from runtime.orchestrator.graph import NodeOutcome, RunContext
from runtime.orchestrator.hashchain import digest_file
from runtime.renderers.canoe_capl import CanoeCaplRenderError, render_capl_test_unit
from runtime.orchestrator.state import AgentRole, GateStatus, GraphNode, NodeStatus
from .business_guidance import BusinessGuidanceError, guidance_for_profile
from .test_case_spec import TestCaseSpecError, compile_test_case_specs
from .vickcan_python import VickCanPythonDraftError, compile_vickcan_python_draft


class AgentPolicyError(ValueError):
    """节点内嵌智能体的 profile、上下文或草案违反治理边界。"""


@dataclass(frozen=True)
class AgentProfile:
    name: str
    node: GraphNode
    role: AgentRole
    purpose: str
    allowed_tools: tuple[str, ...]
    output_kind: str
    max_turns: int = 8
    requires_deterministic_gate: bool = False
    handoff_from_kinds: tuple[str, ...] = ()


@dataclass(frozen=True)
class AgentInvocation:
    profile: AgentProfile
    run_id: str
    flow: str
    artifacts: tuple[dict[str, str], ...]
    input_context: Mapping[str, Any] = field(default_factory=dict)
    handoff: Mapping[str, Any] = field(default_factory=dict)
    business_guidance: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AgentDraft:
    summary: str
    payload: Mapping[str, Any]


class AgentInvoker(Protocol):
    """由 CodeBuddy/其他已批准模型适配器实现；不得绕开本 runner 的 profile。"""

    def invoke(self, request: AgentInvocation) -> AgentDraft: ...


_FORBIDDEN_PAYLOAD_KEYS = frozenset({
    "approval", "approval_token", "api_key", "apikey", "credential", "credential_ref", "password",
    "private_key", "privatekey", "secret", "seed_key", "seedkey", "state", "token",
    "key_bytes", "key_material",
})
_FORBIDDEN_CONTEXT_KEYS = frozenset({
    "path", "file", "filepath", "file_path", "directory", "dir", "output", "out", "content", "text",
    "secret", "token", "api_key", "credential", "approval", "state",
})
_MAX_ARTIFACT_REFS = 8


def _context_key_allowed(key: object) -> bool:
    normalized = str(key).lower()
    return (normalized not in _FORBIDDEN_CONTEXT_KEYS
            and not any(fragment in normalized for fragment in ("path", "file", "secret", "token", "credential", "key")))


def _bounded_context_value(value: Any, *, depth: int = 0) -> Any:
    """Defence in depth for the approved facts-only model context."""
    if depth > 5:
        return None
    if isinstance(value, Mapping):
        return {str(key): _bounded_context_value(nested, depth=depth + 1)
                for key, nested in list(value.items())[:64]
                if _context_key_allowed(key)}
    if isinstance(value, (list, tuple)):
        return [_bounded_context_value(item, depth=depth + 1) for item in list(value)[:64]]
    if isinstance(value, str):
        return value[:256]
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return str(value)[:256]


def _approved_model_context(persisted: object) -> Mapping[str, Any]:
    """Return approved parser facts only; paths and secret material never cross this boundary."""
    if (not isinstance(persisted, Mapping)
            or persisted.get("secret_material_in_context") is not False
            or persisted.get("model_context_exported") is not True
            or persisted.get("model_context_policy") != "approved_sanitized_facts_only"):
        return {}
    raw_facts = persisted.get("facts")
    if not isinstance(raw_facts, list):
        return {}
    facts: list[dict[str, Any]] = []
    for raw in raw_facts[:32]:
        if not isinstance(raw, Mapping) or not isinstance(raw.get("role"), str):
            continue
        summary = raw.get("summary")
        if isinstance(summary, Mapping):
            facts.append({"role": raw["role"], "source_id": str(raw.get("source_id") or "")[:80],
                          "summary": _bounded_context_value(summary)})
    key_refs = persisted.get("secure_key_references")
    return {
        "schema_version": "automotive-model-context/v0.1",
        "export_policy": "approved_sanitized_facts_only",
        "facts": facts,
        "secure_key_reference_count": len(key_refs) if isinstance(key_refs, list) else 0,
        "key_material_available_to_model": False,
    }


def _contains_forbidden_key(value: Any) -> bool:
    if isinstance(value, Mapping):
        for key, nested in value.items():
            normalized = str(key).lower().replace("-", "_").replace(" ", "_")
            if (normalized in _FORBIDDEN_PAYLOAD_KEYS
                    or any(fragment in normalized for fragment in (
                        "approval", "api_key", "apikey", "credential", "password", "private_key",
                        "privatekey", "secret", "seed_key", "seedkey", "key_bytes", "key_material", "token"))
                    or _contains_forbidden_key(nested)):
                return True
    elif isinstance(value, (list, tuple)):
        return any(_contains_forbidden_key(item) for item in value)
    return False


def _tool_specs(profile: AgentProfile) -> tuple[R.ToolSpec, ...]:
    if not profile.name or not profile.output_kind or profile.max_turns < 1:
        raise AgentPolicyError("AGENT_PROFILE_INVALID")
    if profile.role not in acl.roles_for_node(profile.node):
        raise AgentPolicyError(f"AGENT_ROLE_NOT_ALLOWED: {profile.role.value} @ {profile.node.value}")
    if len(set(profile.allowed_tools)) != len(profile.allowed_tools):
        raise AgentPolicyError("AGENT_TOOL_DUPLICATE")

    available = {tool.name: tool for tool in R.tools_for_node(profile.node.value)}
    found: list[R.ToolSpec] = []
    for name in profile.allowed_tools:
        spec = available.get(name)
        if spec is None:
            raise AgentPolicyError(f"AGENT_TOOL_NOT_IN_NODE: {name} @ {profile.node.value}")
        if spec.group == R.HARDWARE:
            raise AgentPolicyError(f"AGENT_HARDWARE_TOOL_FORBIDDEN: {name}")
        found.append(spec)
    return tuple(found)


class AgentNodeRunner:
    """把智能体限制在一个 GraphNode 内，并把输出降格为待验证草案工件。"""

    def __init__(self, profile: AgentProfile):
        self.profile = profile
        self._tools = _tool_specs(profile)

    def _handoff(self, ctx: RunContext) -> Mapping[str, Any]:
        """Return a content-free, immutable handoff reference for a downstream agent.

        The source artifact stays in the runtime.  This prevents project scripts
        or long chat history from entering a worker-model request while giving the
        deterministic static gate an exact object to review locally.
        """
        if not self.profile.handoff_from_kinds:
            return {}
        source = next((item for item in reversed(ctx.artifacts)
                       if item.kind in self.profile.handoff_from_kinds), None)
        if source is None:
            raise AgentPolicyError("AGENT_HANDOFF_SOURCE_MISSING")
        return {
            "schema_version": "agent-handoff/v0.1",
            "history_included": False,
            "content_included": False,
            "source": {"kind": source.kind, "sha256": source.sha256, "bytes": source.size},
        }

    def prepare(self, ctx: RunContext) -> AgentInvocation:
        """构造受控上下文；仅导出获准的解析事实，不含路径或密钥材料。"""
        artifacts = tuple({"sha256": item.sha256, "kind": item.kind}
                          for item in ctx.artifacts[-_MAX_ARTIFACT_REFS:])
        input_context: Mapping[str, Any] = {}
        context_path = os.path.join(ctx.run_dir, "02_plan", "input_inspection.json")
        try:
            recorded_sha = ctx.sha_of("02_plan/input_inspection.json")
            if not recorded_sha or digest_file(context_path) != recorded_sha:
                raise ValueError("input_inspection_hash_mismatch")
            with open(context_path, encoding="utf-8") as handle:
                document = json.load(handle)
            if isinstance(document, Mapping):
                input_context = _approved_model_context(document.get("automotive_input_context"))
        except (OSError, ValueError):
            pass
        try:
            guidance = guidance_for_profile(self.profile.name)
        except BusinessGuidanceError as exc:
            raise AgentPolicyError(str(exc)) from exc
        return AgentInvocation(profile=self.profile, run_id=ctx.run_id, flow=ctx.flow,
                               artifacts=artifacts, input_context=input_context,
                               handoff=self._handoff(ctx), business_guidance=guidance)

    def run(self, ctx: RunContext, invoker: AgentInvoker) -> NodeOutcome:
        draft = invoker.invoke(self.prepare(ctx))
        if not isinstance(draft, AgentDraft) or not isinstance(draft.payload, Mapping):
            raise AgentPolicyError("AGENT_DRAFT_INVALID")
        if not isinstance(draft.summary, str) or not draft.summary.strip():
            raise AgentPolicyError("AGENT_DRAFT_SUMMARY_REQUIRED")
        if _contains_forbidden_key(draft.payload):
            raise AgentPolicyError("AGENT_DRAFT_CONTAINS_GOVERNANCE_OR_SECRET_FIELD")

        payload = dict(draft.payload)
        if self.profile.name == "swdl-uds-test-designer":
            try:
                target_platform = str(payload.get("target_platform") or "").strip().lower()
                # Keep the legacy VickCAN error code for callers that omitted a
                # platform while introducing renderer-neutral specifications.
                if not target_platform:
                    raise VickCanPythonDraftError("VICKCAN_TARGET_REQUIRED")
                bundle = compile_test_case_specs(payload)
                payload = {"target_platform": target_platform, "test_case_spec_bundle": bundle}
                if "leadership" in draft.payload:
                    payload["leadership"] = draft.payload["leadership"]
                if target_platform == "vickcan-python":
                    vickcan_contract = compile_vickcan_python_draft(draft.payload)
                    payload["vickcan_python_contract"] = vickcan_contract
                    payload["cases"] = vickcan_contract["generator_case_schema"]
                elif target_platform == "canoe-capl":
                    payload["canoe_capl_rendering"] = render_capl_test_unit(
                        bundle, target_qualifier=str(draft.payload.get("canoe_target_qualifier") or ""))
                    payload["cases"] = bundle["cases"]
                else:
                    raise AgentPolicyError("AGENT_TARGET_PLATFORM_UNSUPPORTED")
            except (TestCaseSpecError, VickCanPythonDraftError, CanoeCaplRenderError) as exc:
                raise AgentPolicyError(str(exc)) from exc
        output_dir = acl.node_dir(self.profile.node, self.profile.role)
        artifact = f"{output_dir}/agent.{self.profile.name}.draft.json"
        needs_gate = self.profile.requires_deterministic_gate
        return NodeOutcome(
            NodeStatus.BLOCKED if needs_gate else NodeStatus.OK,
            draft.summary[:2000],
            gate_status=GateStatus.BLOCKED if needs_gate else None,
            gate_name="agent_draft_requires_deterministic_gate" if needs_gate else "",
            artifact_path=artifact,
            payload=payload,
            artifact_kind=self.profile.output_kind,
            blocked_reason="agent_draft_requires_deterministic_gate" if needs_gate else "",
        )

    @property
    def allowed_tools(self) -> tuple[str, ...]:
        return tuple(spec.name for spec in self._tools)


__all__ = [
    "AgentDraft", "AgentInvocation", "AgentInvoker", "AgentNodeRunner", "AgentPolicyError", "AgentProfile",
]
