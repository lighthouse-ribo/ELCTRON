# runtime/agents —— 受控模型与 MCP 工具循环

`runtime_cli.py` 是模型调用的唯一生产注入点。Web 只能提交任务、显示运行事件和提交审批；它不导入
`model_invokers.py`、不持有密钥、也不能写入 run 状态。

## DeepSeek Worker 工具循环

`DeepSeekWorkerInvoker` 使用兼容 OpenAI 的原生 function calling：模型提出调用 →
`RuntimeMcpToolGateway` 按 profile、图节点、服务能力再次授权 → 调用与外部客户端相同的
`runtime.mcp.server.call_tool()` → 将最多 24KB 的结果回传给下一轮模型。循环最多执行 profile
的 `max_turns` 轮，超过上限即 `MODEL_TOOL_TURN_LIMIT`。

当前只允许计划/证据组的可服务 MCP 工具；参数中禁止密钥字段、文件路径和输出参数，因此模型不能
借此读取任意本机文件或让既有 CLI 在图外写入。结构化结果仍经 `AgentNodeRunner` 写为草案工件。

## 风险分层

| 行为 | 是否由模型直接触发 | 条件 |
|---|---|---|
| 纯计划/证据计算 | 是 | profile 工具白名单 + MCP 二次校验 |
| 运行目录工件写入 | 否 | 仅 GraphRunner/ACL 单写者落盘 |
| 硬件读取与执行 | 否 | 必须进入执行子图，且通过设备白名单、租约和预检 |
| 有副作用的 UDS 动作 | 否 | 静态 PASS + `ApprovalToken(run, action, scope, expiry)` |

硬件**证据输出**不是被隐藏：它应在受控执行节点完成后成为哈希化工件，再由证据/报告路径读取。
禁止的是设计节点绕过图门禁直接向设备发送请求。当前 `production_nodes` 的执行节点仍 fail-closed，
所以不会假装已经具备实机模型工具调用。

Codex Head 以只读沙箱运行；其结构化工具请求通过同一个 `RuntimeMcpToolGateway`
授权和回传。两条模型路线都只展示 MCP 当前可服务的工具。

## 文件型生成工具的运行边界

`runtime/orchestrator/controlled_cli.py` 为 `uds_req_matrix_generator` 与 `steps_generator` 提供
runtime 内部的受控入口：仅接受已登记的相对输入路径及 SHA-256，输出固定在本次运行的
`02_plan/generated/`，拒绝路径越界和覆盖已有工件，并复核执行后输入与 JSON 输出。该入口尚未接入
生产图的设计节点；模型 MCP 仍不展示这两种文件工具，避免绕过 GraphRunner 的工件单写者规则。

## 脚本编写与审查的交接

SWDL/UDS 的 `swdl-uds-test-designer` 只负责脚本草案，`swdl-uds-script-reviewer` 位于
`static_gate`，只负责提出审查清单与返工项。两者不是共享聊天记录：runtime 传递
`agent-handoff/v0.1`，其中只有草案工件的 `kind`、SHA-256 与字节数，且明确标注
`history_included=false`、`content_included=false`。完整脚本始终留在 runtime。静态节点复核草案哈希、Schema、平台渲染一致性与已解析资料的
`source_id` 与同一份 SRS/SWRS 中实际解析出的 `REQ-...` 需求编号绑定；缺失或伪造编号则为
`REVIEW_REQUIRED`，完整通过才为 `PASS`。输入解析前后与模型读取事实包时均校验已登记 SHA-256。
审查 Agent 的建议
不能自行改写确定性门禁结论。`PASS` 后流程停在 `STATIC_PASSED`，等待有效审批令牌。

## 业务引导资产库

`assets/swdl_uds_guidance.v1.json` 是编写与审查 Agent 的版本化规则卡。它引用包内的 UDS
生成规范、NRC 处置、测试方法学、`script_review.py` 与 `review_depth.py`；runtime 每次计算本地
来源摘要，缺失任一来源即阻断。模型只接收资产版本、来源 SHA-256、规则编号和短指令，绝不接收
规范文件路径或全文。当前编写规则覆盖输入缺口、SID/NRC 语义、正反 DID、SecurityAccess；审查规则
覆盖草案可追溯性、协议一致性、深度覆盖、NA/BLOCKED 判定与门禁职责。

## 平台无关用例与输出平台

脚本编写 Agent 的输出先由 `test_case_spec.py` 编译成平台无关的 UDS 用例契约：每条用例必须有
唯一 `case_id`、完整请求字节、明确的正响应前缀或 NRC，以及非空前置条件；请求和响应标识不一致
会被拒绝。`target_platform=vickcan-python` 再经 `vickcan_python.py` 形成
`python-generator-ready` 草案，可交给既有 `gen_case_scripts.py` 生成 Python-can/Vector 脚本。
`target_platform=canoe-capl` 则由 `canoe_capl.py` 生成 CAPL 草案。两条路径各自渲染，
不会把 CAPL 翻译成 Python；生成草案均不等于硬件授权，仍须通过静态门禁与执行审批。
