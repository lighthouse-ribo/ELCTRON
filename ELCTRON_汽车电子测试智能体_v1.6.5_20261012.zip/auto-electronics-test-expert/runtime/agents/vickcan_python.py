"""Deterministic preflight for agent-authored VickCAN Python test-case drafts.

This is not a hardware adapter.  It turns a structured, Python-only test-case
draft into a normalized contract consumed by the package's existing Python
generators.  CANoe/CAPL is intentionally rejected rather than translated.
"""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any

# Keep this strictly narrower than (and therefore compatible with) the
# downstream generator's path-safe case-id grammar.  In particular, dots are
# not accepted there and would otherwise make a validated draft fail later.
_CASE_ID = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,79}$")
_HEX = re.compile(r"(?<![0-9A-Fa-f])(?:0x)?([0-9A-Fa-f]{2})(?![0-9A-Fa-f])")
_NEGATIVE_FRAME = re.compile(
    r"(?<![0-9A-Fa-f])(?:0x)?7F\s+(?:0x)?([0-9A-Fa-f]{2})\s+"
    r"(?:0x)?([0-9A-Fa-f]{2})(?![0-9A-Fa-f])", re.I)
_NEGATIVE_PREFIX = re.compile(r"(?<![0-9A-Fa-f])(?:0x)?7F\s+(?:0x)?([0-9A-Fa-f]{2})(?![0-9A-Fa-f])", re.I)
_FORBIDDEN = re.compile(r"(?:\bcapl\b|\bcanoe\b|seed[\s_/-]*key|api[\s_-]*key|private[\s_-]*key)", re.I)


class VickCanPythonDraftError(ValueError):
    """The agent draft cannot be safely rendered by the Python generation path."""


def _bytes_from_text(value: object, field: str) -> list[int]:
    tokens = _HEX.findall(str(value or ""))
    if not tokens:
        raise VickCanPythonDraftError(f"VICKCAN_{field.upper()}_MISSING")
    return [int(token, 16) for token in tokens]


def _expected(expected: object, sid: int) -> dict[str, object]:
    text = str(expected or "")
    negative_frame = _NEGATIVE_FRAME.search(text)
    if negative_frame:
        response_sid, nrc = (int(value, 16) for value in negative_frame.groups())
        if response_sid != sid:
            raise VickCanPythonDraftError("VICKCAN_NEGATIVE_SID_MISMATCH")
        return {"kind": "nrc", "nrc": nrc}
    negative_prefix = _NEGATIVE_PREFIX.search(text)
    if negative_prefix:
        if int(negative_prefix.group(1), 16) != sid:
            raise VickCanPythonDraftError("VICKCAN_NEGATIVE_SID_MISMATCH")
        raise VickCanPythonDraftError("VICKCAN_NEGATIVE_RESPONSE_INVALID")
    nrc = re.search(r"(?:NRC\s*(?:=|:)?\s*|7F\s+[0-9A-Fa-f]{2}\s+)(?:0x)?([0-9A-Fa-f]{2})", text, re.I)
    if nrc:
        return {"kind": "nrc", "nrc": int(nrc.group(1), 16)}
    prefix = _bytes_from_text(text, "expected")
    if prefix[0] != ((sid + 0x40) & 0xFF):
        raise VickCanPythonDraftError("VICKCAN_POSITIVE_SID_MISMATCH")
    return {"kind": "positive_prefix", "bytes": prefix}


def _validate_positive_correlation(request: list[int], expectation: Mapping[str, object]) -> None:
    """Reject a positive response that names a different UDS object.

    A matching positive SID alone is insufficient: an agent could otherwise
    accept a response for another DID/routine while the bus transaction itself
    succeeded.  Restrict this to services with normative echo fields; other
    service-specific checks remain the responsibility of the existing
    generator and static review gate.
    """
    if expectation.get("kind") != "positive_prefix":
        return
    response = expectation.get("bytes")
    if not isinstance(response, list):
        raise VickCanPythonDraftError("VICKCAN_EXPECTATION_INVALID")
    sid = request[0]
    if sid in (0x22, 0x2E, 0x2F) and len(request) >= 3:
        if len(response) < 3 or response[1:3] != request[1:3]:
            raise VickCanPythonDraftError("VICKCAN_POSITIVE_IDENTIFIER_MISMATCH")
    elif sid == 0x31 and len(request) >= 4:
        if len(response) < 4 or response[1:4] != request[1:4]:
            raise VickCanPythonDraftError("VICKCAN_POSITIVE_ROUTINE_MISMATCH")
    elif sid in (0x10, 0x27, 0x28, 0x3E, 0x85) and len(request) >= 2:
        if len(response) < 2 or response[1] != request[1]:
            raise VickCanPythonDraftError("VICKCAN_POSITIVE_SUBFUNCTION_MISMATCH")


def _validate_security_access_material(request: list[int], expectation: Mapping[str, object]) -> None:
    if not request or request[0] != 0x27:
        return
    if len(request) < 2:
        raise VickCanPythonDraftError("VICKCAN_SECURITY_ACCESS_SUBFUNCTION_REQUIRED")
    if len(request) > 2:
        raise VickCanPythonDraftError("VICKCAN_SECURITY_ACCESS_MATERIAL_FORBIDDEN")
    if expectation.get("kind") != "positive_prefix":
        return
    response = expectation.get("bytes")
    if not isinstance(response, list):
        raise VickCanPythonDraftError("VICKCAN_EXPECTATION_INVALID")
    if len(response) > 2:
        raise VickCanPythonDraftError("VICKCAN_SECURITY_ACCESS_MATERIAL_FORBIDDEN")
    if request[1] % 2 == 0:
        raise VickCanPythonDraftError("VICKCAN_SECURITY_ACCESS_KEY_MATERIAL_REQUIRED")


def _generator_case_id(agent_case_id: str, sid: int) -> str:
    """Make the UDS service explicit for the existing Python generator.

    ``gen_case_scripts.py`` uses the second underscore-delimited case-id
    component as its service hint for service-specific prerequisites.  Agent
    IDs are deliberately human-readable and may use hyphens, so passing them
    through unchanged would silently drop that hint.  Preserve the original
    ID separately and emit a bounded canonical ID for the downstream tool.
    """
    return f"UDS_0x{sid:02X}_{agent_case_id}"


def compile_vickcan_python_draft(payload: Mapping[str, Any]) -> dict[str, object]:
    """Validate agent cases and return a bounded, Python-generator-ready contract."""
    if str(payload.get("target_platform") or "").strip().lower() != "vickcan-python":
        raise VickCanPythonDraftError("VICKCAN_TARGET_REQUIRED")
    cases = payload.get("cases")
    if not isinstance(cases, Sequence) or isinstance(cases, (str, bytes)) or not cases:
        raise VickCanPythonDraftError("VICKCAN_CASES_REQUIRED")
    if len(cases) > 128:
        raise VickCanPythonDraftError("VICKCAN_CASES_LIMIT")
    normalized: list[dict[str, object]] = []
    generator_cases: list[dict[str, str]] = []
    seen: set[str] = set()
    for raw in cases:
        if not isinstance(raw, Mapping):
            raise VickCanPythonDraftError("VICKCAN_CASE_INVALID")
        case_id = str(raw.get("case_id") or raw.get("id") or "").strip()
        procedure, expected = str(raw.get("procedure") or "").strip(), str(raw.get("expected") or "").strip()
        precondition = str(raw.get("precondition") or "").strip()
        if not _CASE_ID.fullmatch(case_id) or case_id in seen:
            raise VickCanPythonDraftError("VICKCAN_CASE_ID_INVALID")
        if not procedure or not expected or not precondition or _FORBIDDEN.search(" ".join((procedure, expected, precondition))):
            raise VickCanPythonDraftError("VICKCAN_CASE_FIELDS_INVALID")
        request = _bytes_from_text(procedure, "request")
        if not 0x10 <= request[0] <= 0x3E:
            raise VickCanPythonDraftError("VICKCAN_SERVICE_INVALID")
        expectation = _expected(expected, request[0])
        _validate_positive_correlation(request, expectation)
        _validate_security_access_material(request, expectation)
        generator_case_id = _generator_case_id(case_id, request[0])
        normalized.append({"case_id": case_id, "generator_case_id": generator_case_id,
                           "request": request, "expectation": expectation, "precondition": precondition[:500]})
        request_text = " ".join(f"{byte:02X}" for byte in request)
        expected_text = (f"NRC 0x{int(expectation['nrc']):02X}"
                         if expectation["kind"] == "nrc"
                         else " ".join(f"{byte:02X}" for byte in expectation["bytes"]))
        generator_cases.append({"case_id": generator_case_id, "agent_case_id": case_id,
                                "procedure": f"发送 {request_text}", "expected": expected_text,
                                "precondition": precondition[:500]})
        seen.add(case_id)
    return {"schema_version": "vickcan-python-draft/v0.1", "target_platform": "vickcan-python",
            "execution_mode": "python-generator-ready", "case_count": len(normalized), "cases": normalized,
            "generator_case_schema": generator_cases}


__all__ = ["VickCanPythonDraftError", "compile_vickcan_python_draft"]
