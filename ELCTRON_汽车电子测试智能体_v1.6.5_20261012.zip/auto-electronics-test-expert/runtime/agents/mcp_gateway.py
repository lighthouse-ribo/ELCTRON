"""Runtime-only bridge from an agent profile to the shared MCP tool surface."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Mapping

from runtime.mcp import server as mcp_server
from runtime.orchestrator import registry as registry

from .runner import AgentInvocation

_FORBIDDEN_TEXT = re.compile(r"(?:api[_-]?key|authorization|credential|password|secret|token)", re.I)
_SECRET_VALUE = re.compile(r"(?:\bsk-[A-Za-z0-9_-]{12,}\b|\bBearer\s+[A-Za-z0-9._-]{16,}\b)", re.I)
_OUTPUT_FLAGS = frozenset({"--out", "--output", "--out-dir", "--audit", "--report", "-o"})
_PATHLIKE = re.compile(r"(?:[\\/]|^[.~]|^[A-Za-z]:)")
_FILE_OR_OUTPUT_KEY = re.compile(r"(?:^|[_-])(?:file|path|dir|output|out|report|audit)(?:$|[_-])", re.I)


class AgentToolError(ValueError):
    """A model proposed a call outside its governed MCP capability."""


@dataclass(frozen=True)
class AgentToolCall:
    name: str
    arguments: Mapping[str, Any]


class RuntimeMcpToolGateway:
    """A profile-scoped view of the same MCP server used by external clients.

    No hardware tool is ever described or callable. CLI output flags are
    rejected in the read-only design slice; structured products return through
    the agent draft and GraphRunner remains the only artifact writer.
    """

    def _entry(self, invocation: AgentInvocation, name: str) -> tuple[str, Any]:
        if name not in invocation.profile.allowed_tools:
            raise AgentToolError(f"AGENT_TOOL_NOT_PROFILE_ALLOWED:{name}")
        spec = registry.find_tool(name)
        if spec is None or spec.node != invocation.profile.node.value:
            raise AgentToolError(f"AGENT_TOOL_NOT_NODE_ALLOWED:{name}")
        if spec.group not in (registry.PLAN, registry.EVIDENCE):
            raise AgentToolError(f"AGENT_TOOL_GROUP_FORBIDDEN:{name}")
        mcp_name = f"{spec.group}__{name}"
        mcp_server.initialize_tool_dir()
        entry = mcp_server.TOOL_DIR.get(mcp_name)
        if entry is None:
            raise AgentToolError(f"AGENT_TOOL_NOT_SERVICEABLE:{name}")
        return mcp_name, entry

    def describe(self, invocation: AgentInvocation) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for name in invocation.profile.allowed_tools:
            try:
                mcp_name, entry = self._entry(invocation, name)
            except AgentToolError:
                continue
            # The model sees plain profile tool names; runtime maps them back to
            # the shared MCP identity after authorization.
            result.append({"type": "function", "function": {
                "name": name,
                "description": str(entry["description"])[:500],
                "parameters": entry["inputSchema"],
            }})
        return result

    @staticmethod
    def _validate_arguments(arguments: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(arguments, Mapping):
            raise AgentToolError("AGENT_TOOL_ARGUMENTS_NOT_OBJECT")
        try:
            encoded = json.dumps(arguments, ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            raise AgentToolError("AGENT_TOOL_ARGUMENTS_NOT_JSON") from exc
        if len(encoded) > 24_000 or _FORBIDDEN_TEXT.search(encoded):
            raise AgentToolError("AGENT_TOOL_ARGUMENTS_FORBIDDEN")
        args = arguments.get("args", [])
        if not isinstance(args, list) or len(args) > 32:
            raise AgentToolError("AGENT_TOOL_ARGS_INVALID")
        if any(str(item) in _OUTPUT_FLAGS for item in args):
            raise AgentToolError("AGENT_TOOL_WRITE_ARGUMENT_FORBIDDEN")
        if any(_PATHLIKE.search(str(item)) for item in RuntimeMcpToolGateway._scalar_values(arguments)):
            raise AgentToolError("AGENT_TOOL_FILE_ARGUMENT_FORBIDDEN")
        if RuntimeMcpToolGateway._contains_file_or_output_key(arguments):
            raise AgentToolError("AGENT_TOOL_FILE_ARGUMENT_FORBIDDEN")
        return dict(arguments)

    @staticmethod
    def _scalar_values(value: object):
        if isinstance(value, Mapping):
            for child in value.values():
                yield from RuntimeMcpToolGateway._scalar_values(child)
        elif isinstance(value, (list, tuple)):
            for child in value:
                yield from RuntimeMcpToolGateway._scalar_values(child)
        elif isinstance(value, str):
            yield value

    @staticmethod
    def _contains_file_or_output_key(value: object) -> bool:
        if not isinstance(value, Mapping):
            return False
        for key, child in value.items():
            if _FILE_OR_OUTPUT_KEY.search(str(key)):
                return True
            if RuntimeMcpToolGateway._contains_file_or_output_key(child):
                return True
            if isinstance(child, list) and any(RuntimeMcpToolGateway._contains_file_or_output_key(item) for item in child):
                return True
        return False

    def call(self, invocation: AgentInvocation, call: AgentToolCall) -> dict[str, Any]:
        mcp_name, _entry = self._entry(invocation, call.name)
        try:
            result = mcp_server.call_tool(mcp_name, self._validate_arguments(call.arguments))
        except AgentToolError:
            raise
        except Exception as exc:  # MCP replies normally carry a bounded error payload.
            return {"tool": call.name, "is_error": True, "content": f"MCP_CALL_FAILED:{type(exc).__name__}"}
        content = result.get("content", []) if isinstance(result, Mapping) else []
        text = "\n".join(str(part.get("text", "")) for part in content if isinstance(part, Mapping))[:24_000]
        text = _FORBIDDEN_TEXT.sub("[REDACTED_FIELD]", text)
        text = _SECRET_VALUE.sub("[REDACTED_VALUE]", text)
        return {"tool": call.name, "is_error": bool(result.get("isError", False)), "content": text}


__all__ = ["AgentToolCall", "AgentToolError", "RuntimeMcpToolGateway"]
