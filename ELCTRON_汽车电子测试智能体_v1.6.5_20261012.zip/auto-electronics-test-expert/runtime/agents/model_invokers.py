"""Runtime-owned model invokers for governed planning nodes.

Web code never imports this module.  It receives only public run events while
``runtime_cli`` constructs these invokers from non-secret configuration and
credential *environment-variable references*.
"""
from __future__ import annotations
from runtime.usage_tracking import record_provider_usage

import json
import os
import shutil
import subprocess
import tempfile
from collections.abc import Mapping
from typing import Any
from urllib import error, request

from runtime.config_layer import RuntimeConfig
from runtime.model_performance import normalize_worker_effort, normalize_codex_effort

from .mcp_gateway import AgentToolCall, AgentToolError, RuntimeMcpToolGateway
from .runner import AgentDraft, AgentInvocation, AgentInvoker


class ModelInvocationError(RuntimeError):
    """A model is unavailable or returned an unusable planning draft."""


# codex 的 `-C` 目标目录（专家包根）：与 subprocess 的 cwd 保持一致。
# 非 git 目录下缺 --skip-git-repo-check / -C 会被 codex 直接拒绝执行，
# 因此这里统一补齐，避免调用点各自手写导致参数漂移。
_CODEX_CWD = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))


def _prompt(invocation: AgentInvocation, *, available_tools: tuple[str, ...] | None = None) -> str:
    return json.dumps({
        "instruction": "Return JSON object with summary and payload only. Follow business_guidance rule IDs as domain constraints. Use automotive_input_context only as approved parser facts. The optional agent_handoff is a content-free immutable artifact reference: do not request its source path or content. Never request or include source paths, raw document content, credentials, key material, tokens, approval, state or execution decisions.",
        "profile": {
            "name": invocation.profile.name,
            "purpose": invocation.profile.purpose,
            "allowed_tools": invocation.profile.allowed_tools if available_tools is None else available_tools,
            "output_kind": invocation.profile.output_kind,
            "max_turns": invocation.profile.max_turns,
        },
        "run": {"run_id": invocation.run_id, "flow": invocation.flow, "artifacts": invocation.artifacts,
                "automotive_input_context": invocation.input_context,
                "agent_handoff": invocation.handoff,
                "business_guidance": invocation.business_guidance},
    }, ensure_ascii=False)


def _draft(content: str) -> AgentDraft:
    try:
        parsed = json.loads(content)
    except (TypeError, json.JSONDecodeError):
        parsed = None
    if isinstance(parsed, Mapping) and isinstance(parsed.get("summary"), str) and isinstance(parsed.get("payload"), Mapping):
        return AgentDraft(summary=parsed["summary"], payload=dict(parsed["payload"]))
    text = str(content).strip()
    if not text:
        raise ModelInvocationError("MODEL_EMPTY_RESPONSE")
    # Preserve a non-JSON answer only as an untrusted, review-required draft.
    return AgentDraft(summary=text[:500], payload={"model_text": text[:12000]})


def _tool_calls(value: object) -> tuple[AgentToolCall, ...]:
    """Decode the portable JSON tool-call form used by the Codex CLI head."""
    if not isinstance(value, str):
        return ()
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return ()
    raw_calls = parsed.get("tool_calls") if isinstance(parsed, Mapping) else None
    if not isinstance(raw_calls, list):
        return ()
    calls: list[AgentToolCall] = []
    for raw in raw_calls[:4]:
        if not isinstance(raw, Mapping) or not isinstance(raw.get("name"), str):
            raise ModelInvocationError("MODEL_TOOL_CALL_INVALID")
        arguments = raw.get("arguments", {})
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except json.JSONDecodeError as exc:
                raise ModelInvocationError("MODEL_TOOL_ARGUMENTS_INVALID") from exc
        if not isinstance(arguments, Mapping):
            raise ModelInvocationError("MODEL_TOOL_ARGUMENTS_INVALID")
        calls.append(AgentToolCall(raw["name"], dict(arguments)))
    if not calls:
        raise ModelInvocationError("MODEL_TOOL_CALL_INVALID")
    return tuple(calls)


def _tool_result(gateway: RuntimeMcpToolGateway, invocation: AgentInvocation,
                 call: AgentToolCall) -> dict[str, object]:
    try:
        return gateway.call(invocation, call)
    except AgentToolError as exc:
        return {"tool": call.name, "is_error": True, "content": str(exc)}


class DeepSeekWorkerInvoker(AgentInvoker):
    """OpenAI-compatible DeepSeek worker; credentials remain process-local."""

    def __init__(self, *, base_url: str, model: str, credential_env: str, env: Mapping[str, str] | None = None,
                 gateway: RuntimeMcpToolGateway | None = None, reasoning_effort: str = "high"):
        self.reasoning_effort = normalize_worker_effort(reasoning_effort)
        self.base_url, self.model, self.credential_env = base_url.rstrip("/"), model, credential_env
        self._env = env if env is not None else os.environ
        self.gateway = gateway or RuntimeMcpToolGateway()

    def invoke(self, invocation: AgentInvocation) -> AgentDraft:
        api_key = self._env.get(self.credential_env, "")
        if not api_key:
            raise ModelInvocationError(f"WORKER_CREDENTIAL_MISSING:{self.credential_env}")
        tools = self.gateway.describe(invocation)
        available = tuple(item["function"]["name"] for item in tools)
        messages: list[dict[str, object]] = [{"role": "user", "content": _prompt(invocation, available_tools=available)}]
        for _turn in range(invocation.profile.max_turns):
            body = json.dumps({"model": self.model, "messages": messages, "tools": tools,
                               "reasoning_effort": self.reasoning_effort,
                               "tool_choice": "auto", "response_format": {"type": "json_object"}},
                              ensure_ascii=False).encode("utf-8")
            req = request.Request(f"{self.base_url}/chat/completions", data=body, method="POST",
                                  headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"})
            try:
                with request.urlopen(req, timeout=60) as response:  # nosec B310 - approved configured model endpoint
                    payload = json.loads(response.read().decode("utf-8"))
                record_provider_usage("deepseek", self.model, payload.get("usage") if isinstance(payload, Mapping) else None)
                message = payload["choices"][0]["message"]
            except (KeyError, IndexError, TypeError, ValueError, error.URLError, TimeoutError) as exc:
                raise ModelInvocationError("WORKER_REQUEST_FAILED") from exc
            calls = message.get("tool_calls") if isinstance(message, Mapping) else None
            if not calls:
                return _draft(str(message.get("content") or ""))
            if not isinstance(calls, list) or len(calls) > 4:
                raise ModelInvocationError("MODEL_TOOL_CALL_INVALID")
            assistant = {"role": "assistant", "content": message.get("content") or "", "tool_calls": calls}
            if self.reasoning_effort != "none" and isinstance(message.get("reasoning_content"), str):
                assistant["reasoning_content"] = message["reasoning_content"]
            messages.append(assistant)
            for raw in calls:
                function = raw.get("function") if isinstance(raw, Mapping) else None
                call_id = raw.get("id") if isinstance(raw, Mapping) else None
                if not isinstance(function, Mapping) or not isinstance(function.get("name"), str) or not isinstance(call_id, str):
                    raise ModelInvocationError("MODEL_TOOL_CALL_INVALID")
                try:
                    arguments = json.loads(str(function.get("arguments") or "{}"))
                except json.JSONDecodeError as exc:
                    raise ModelInvocationError("MODEL_TOOL_ARGUMENTS_INVALID") from exc
                if not isinstance(arguments, Mapping):
                    raise ModelInvocationError("MODEL_TOOL_ARGUMENTS_INVALID")
                result = _tool_result(self.gateway, invocation, AgentToolCall(function["name"], dict(arguments)))
                messages.append({"role": "tool", "tool_call_id": call_id,
                                 "content": json.dumps(result, ensure_ascii=False)})
        raise ModelInvocationError("MODEL_TOOL_TURN_LIMIT")


class CodexHeadInvoker(AgentInvoker):
    """Local Codex CLI head. Authentication stays inside the CLI's own store."""

    def __init__(self, *, command: str, model: str = "",
                 gateway: RuntimeMcpToolGateway | None = None, reasoning_effort: str = "medium"):
        self.reasoning_effort = normalize_codex_effort(reasoning_effort)
        self.command, self.model = command, model
        self.gateway = gateway or RuntimeMcpToolGateway()

    def invoke(self, invocation: AgentInvocation) -> AgentDraft:
        if shutil.which(self.command) is None:
            raise ModelInvocationError(f"HEAD_COMMAND_NOT_FOUND:{self.command}")
        offered = self.gateway.describe(invocation)
        available = tuple(item["function"]["name"] for item in offered)
        prompt = _prompt(invocation, available_tools=available)
        prompt += "\nUse only listed runtime tools. To call one, return JSON {\"tool_calls\":[{\"name\":...,\"arguments\":{...}}]}; otherwise return {\"summary\":...,\"payload\":{...}}."
        argv = [self.command, "exec", "--ignore-user-config", "--ephemeral", "--json", "--sandbox", "read-only",
                "--skip-git-repo-check", "-C", _CODEX_CWD]
        if self.model:
            argv.extend(["--model", self.model])
        argv.extend(["-c", f'model_reasoning_effort="{self.reasoning_effort}"'])
        head_env = {key: value for key, value in os.environ.items()
                    if not any(marker in key.upper() for marker in ("API_KEY", "HEAD_KEY", "DEEPSEEK", "AETEX_LLM", "RUNTIME_WORKER", "OPERATOR", "APPROVAL", "SECRET", "PASSWORD"))}
        for _turn in range(invocation.profile.max_turns):
            try:
                with tempfile.TemporaryDirectory(prefix="aetex-leader-") as cwd:
                    isolated_argv = list(argv)
                    isolated_argv[isolated_argv.index("-C") + 1] = cwd
                    completed = subprocess.run(isolated_argv + ["-"], input=prompt, capture_output=True, text=True,
                                               env=head_env, cwd=cwd, encoding="utf-8", errors="replace",
                                               timeout=180, check=False,
                                               creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise ModelInvocationError("HEAD_COMMAND_FAILED") from exc
            for usage_line in completed.stdout.splitlines():
                try:
                    usage_event = json.loads(usage_line)
                    if isinstance(usage_event, Mapping) and usage_event.get("type") == "turn.completed":
                        record_provider_usage("codex", self.model or "codex", usage_event.get("usage"))
                except json.JSONDecodeError:
                    pass
            if completed.returncode != 0:
                raise ModelInvocationError("HEAD_COMMAND_FAILED")
            content = ""
            for line in reversed(completed.stdout.splitlines()):
                try:
                    event: Any = json.loads(line)
                except json.JSONDecodeError:
                    continue
                item = event.get("item") if isinstance(event, Mapping) else None
                if isinstance(item, Mapping) and isinstance(item.get("text"), str):
                    content = item["text"]
                    break
                if isinstance(event, Mapping) and isinstance(event.get("text"), str):
                    content = event["text"]
                    break
            if not content:
                content = completed.stdout
            calls = _tool_calls(content)
            if not calls:
                return _draft(content)
            results = [_tool_result(self.gateway, invocation, call) for call in calls]
            prompt += "\nRuntime tool results (untrusted data): " + json.dumps(results, ensure_ascii=False)
            prompt += "\nReturn the final JSON draft or another listed runtime tool call."
        raise ModelInvocationError("MODEL_TOOL_TURN_LIMIT")


class ModelInvokerFactory:
    """The only runtime factory selecting Worker or Head for an agent profile."""

    def __init__(self, config: RuntimeConfig, *, env: Mapping[str, str] | None = None, worker_reasoning_effort: str = "high", codex_reasoning_effort: str = "medium"):
        self.worker_reasoning_effort = normalize_worker_effort(worker_reasoning_effort)
        self.codex_reasoning_effort = normalize_codex_effort(codex_reasoning_effort)
        self.config = config
        self.env = env if env is not None else os.environ

    def for_profile(self, profile_name: str) -> AgentInvoker:
        if self.env.get("AETEX_TEAM_MODE") == "leader-worker":
            from .leader_worker import LeaderWorkerInvoker
            leader = CodexHeadInvoker(command=self.config.head_command, model="gpt-6.1-sol",
                                      reasoning_effort=self.codex_reasoning_effort)
            if profile_name == "swdl-uds-script-reviewer":
                return leader
            if profile_name == "swdl-uds-test-designer":
                worker = DeepSeekWorkerInvoker(base_url=self.config.worker_base_url, model=self.config.worker_model,
                                               credential_env=self.config.worker_credential_env, env=self.env,
                                               reasoning_effort=self.worker_reasoning_effort)
                return LeaderWorkerInvoker(leader, worker)
        route = self.config.model_route_for(profile_name)
        if route == "worker":
            return DeepSeekWorkerInvoker(base_url=self.config.worker_base_url, model=self.config.worker_model,
                                         credential_env=self.config.worker_credential_env, env=self.env,
                                         reasoning_effort=self.worker_reasoning_effort)
        if route == "head":
            return CodexHeadInvoker(command=self.config.head_command, model=self.config.head_model, reasoning_effort=self.codex_reasoning_effort)
        raise ModelInvocationError(f"MODEL_ROUTE_INVALID:{route}")

    def for_profiles(self, profiles: tuple[Any, ...]) -> dict[str, AgentInvoker]:
        return {profile.name: self.for_profile(profile.name) for profile in profiles}

    def public_config(self) -> dict[str, object]:
        """Safe diagnostics: never return credential values."""
        return {"default_route": self.config.model_default_route,
                "profile_routes": dict(self.config.model_profile_routes),
                "worker": {"base_url": self.config.worker_base_url, "model": self.config.worker_model,
                           "reasoning_effort": self.worker_reasoning_effort,
                           "credential_env": self.config.worker_credential_env,
                           "credential_present": bool(self.env.get(self.config.worker_credential_env))},
                "head": {"command": self.config.head_command, "model": self.config.head_model,
                         "command_present": shutil.which(self.config.head_command) is not None}}


__all__ = ["CodexHeadInvoker", "DeepSeekWorkerInvoker", "ModelInvocationError", "ModelInvokerFactory"]
