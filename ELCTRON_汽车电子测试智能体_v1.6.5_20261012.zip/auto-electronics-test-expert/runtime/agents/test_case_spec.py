"""Platform-neutral UDS test-case specification compiler.

The model may describe a case in the legacy human-readable form, but no
renderer receives that unverified text.  This module normalizes it once into
the contract shared by CANoe/CAPL and Python renderers.
"""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any

from runtime.contracts.validation import ContractViolation, validate_payload

_CASE_ID = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,79}$")
_HEX = re.compile(r"(?<![0-9A-Fa-f])(?:0x)?([0-9A-Fa-f]{2})(?![0-9A-Fa-f])")
_NEGATIVE_FRAME = re.compile(
    r"(?<![0-9A-Fa-f])(?:0x)?7F\s+(?:0x)?([0-9A-Fa-f]{2})\s+"
    r"(?:0x)?([0-9A-Fa-f]{2})(?![0-9A-Fa-f])", re.I)
_NEGATIVE_PREFIX = re.compile(r"(?<![0-9A-Fa-f])(?:0x)?7F\s+(?:0x)?([0-9A-Fa-f]{2})(?![0-9A-Fa-f])", re.I)
_FORBIDDEN = re.compile(r"(?:seed[\s_/-]*key|api[\s_-]*key|private[\s_-]*key)", re.I)


class TestCaseSpecError(ValueError):
    """The agent output cannot become a platform-neutral test specification."""


def _bytes_from_text(value: object, field: str) -> list[int]:
    tokens = _HEX.findall(str(value or ""))
    if not tokens:
        raise TestCaseSpecError(f"TEST_CASE_{field.upper()}_MISSING")
    return [int(token, 16) for token in tokens]


def _expectation(expected: object, sid: int) -> dict[str, object]:
    text = str(expected or "")
    negative_frame = _NEGATIVE_FRAME.search(text)
    if negative_frame:
        response_sid, nrc = (int(value, 16) for value in negative_frame.groups())
        if response_sid != sid:
            raise TestCaseSpecError("TEST_CASE_NEGATIVE_SID_MISMATCH")
        return {"kind": "nrc", "nrc": nrc}
    negative_prefix = _NEGATIVE_PREFIX.search(text)
    if negative_prefix:
        if int(negative_prefix.group(1), 16) != sid:
            raise TestCaseSpecError("TEST_CASE_NEGATIVE_SID_MISMATCH")
        raise TestCaseSpecError("TEST_CASE_NEGATIVE_RESPONSE_INVALID")
    nrc = re.search(r"(?:NRC\s*(?:=|:)?\s*|7F\s+[0-9A-Fa-f]{2}\s+)(?:0x)?([0-9A-Fa-f]{2})", text, re.I)
    if nrc:
        return {"kind": "nrc", "nrc": int(nrc.group(1), 16)}
    response = _bytes_from_text(text, "expected")
    if response[0] != ((sid + 0x40) & 0xFF):
        raise TestCaseSpecError("TEST_CASE_POSITIVE_SID_MISMATCH")
    return {"kind": "positive_prefix", "bytes": response}


def _validate_positive_correlation(request: list[int], expectation: Mapping[str, object]) -> None:
    if expectation.get("kind") != "positive_prefix":
        return
    response = expectation.get("bytes")
    if not isinstance(response, list):
        raise TestCaseSpecError("TEST_CASE_EXPECTATION_INVALID")
    sid = request[0]
    if sid in (0x22, 0x2E, 0x2F) and len(request) >= 3:
        if len(response) < 3 or response[1:3] != request[1:3]:
            raise TestCaseSpecError("TEST_CASE_POSITIVE_IDENTIFIER_MISMATCH")
    elif sid == 0x31 and len(request) >= 4:
        if len(response) < 4 or response[1:4] != request[1:4]:
            raise TestCaseSpecError("TEST_CASE_POSITIVE_ROUTINE_MISMATCH")
    elif sid in (0x10, 0x27, 0x28, 0x3E, 0x85) and len(request) >= 2:
        if len(response) < 2 or response[1] != request[1]:
            raise TestCaseSpecError("TEST_CASE_POSITIVE_SUBFUNCTION_MISMATCH")


def _validate_security_access_material(request: list[int], expectation: Mapping[str, object]) -> None:
    if not request or request[0] != 0x27:
        return
    if len(request) < 2:
        raise TestCaseSpecError("TEST_CASE_SECURITY_ACCESS_SUBFUNCTION_REQUIRED")
    if len(request) > 2:
        raise TestCaseSpecError("TEST_CASE_SECURITY_ACCESS_MATERIAL_FORBIDDEN")
    if expectation.get("kind") != "positive_prefix":
        return
    response = expectation.get("bytes")
    if not isinstance(response, list):
        raise TestCaseSpecError("TEST_CASE_EXPECTATION_INVALID")
    if len(response) > 2:
        raise TestCaseSpecError("TEST_CASE_SECURITY_ACCESS_MATERIAL_FORBIDDEN")
    if request[1] % 2 == 0:
        raise TestCaseSpecError("TEST_CASE_SECURITY_ACCESS_KEY_MATERIAL_REQUIRED")


def _text_items(value: object) -> list[str]:
    if isinstance(value, str):
        return [part.strip() for part in re.split(r"[\r\n,;]+", value) if part.strip()]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [str(part).strip() for part in value if str(part).strip()]
    return []


def compile_test_case_specs(payload: Mapping[str, Any]) -> dict[str, object]:
    """Compile legacy agent cases into the renderer-neutral contract.

    Missing source links are preserved as ``UNBOUND`` rather than invented.
    Static review must reject or explicitly resolve those cases before a
    hardware route can ever be entered.
    """
    raw_cases = payload.get("cases")
    if not isinstance(raw_cases, Sequence) or isinstance(raw_cases, (str, bytes)) or not raw_cases:
        raise TestCaseSpecError("TEST_CASES_REQUIRED")
    if len(raw_cases) > 128:
        raise TestCaseSpecError("TEST_CASES_LIMIT")
    cases: list[dict[str, object]] = []
    seen: set[str] = set()
    for raw in raw_cases:
        if not isinstance(raw, Mapping):
            raise TestCaseSpecError("TEST_CASE_INVALID")
        case_id = str(raw.get("case_id") or raw.get("id") or "").strip()
        title = str(raw.get("title") or raw.get("test_point") or case_id).strip()
        procedure = str(raw.get("procedure") or "").strip()
        expected = str(raw.get("expected") or "").strip()
        preconditions = _text_items(raw.get("preconditions") or raw.get("precondition"))
        source_refs = _text_items(raw.get("source_refs") or raw.get("req_sources"))
        if not _CASE_ID.fullmatch(case_id) or case_id in seen:
            raise TestCaseSpecError("TEST_CASE_ID_INVALID")
        if not title or not procedure or not expected or not preconditions:
            raise TestCaseSpecError("TEST_CASE_FIELDS_INVALID")
        if _FORBIDDEN.search(" ".join([case_id, title, procedure, expected, *preconditions, *source_refs])):
            raise TestCaseSpecError("TEST_CASE_FORBIDDEN_SECRET_FIELD")
        request = _bytes_from_text(procedure, "request")
        if not 0x10 <= request[0] <= 0x3E:
            raise TestCaseSpecError("TEST_CASE_SERVICE_INVALID")
        expectation = _expectation(expected, request[0])
        _validate_positive_correlation(request, expectation)
        _validate_security_access_material(request, expectation)
        cases.append({"case_id": case_id, "title": title[:240], "request": request,
                      "expectation": expectation, "preconditions": preconditions[:32],
                      "source_refs": source_refs[:32], "traceability_status": "UNBOUND"})
        seen.add(case_id)
    bundle: dict[str, object] = {"schema_version": "test-case-spec-bundle/v0.1", "cases": cases}
    try:
        validate_payload("test-case-spec-bundle/v0.1", bundle)
    except ContractViolation as exc:
        raise TestCaseSpecError(f"TEST_CASE_CONTRACT_INVALID:{exc}") from exc
    return bundle


__all__ = ["TestCaseSpecError", "compile_test_case_specs"]
