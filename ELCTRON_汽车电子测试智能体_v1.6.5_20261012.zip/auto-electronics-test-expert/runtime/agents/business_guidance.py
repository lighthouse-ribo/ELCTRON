"""Versioned, local business-guidance cards for automotive test agents.

The cards reference package-owned standards but export only concise directives,
rule IDs and source digests to a model.  Source paths and full documents remain
inside the runtime, which keeps guidance auditable without growing agent context.
"""
from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Mapping
from typing import Any

_ASSET_REL = "runtime/agents/assets/swdl_uds_guidance.v1.json"
_MAX_GUIDANCE_BYTES = 8_000
_PROFILE_ROLES = {
    "swdl-uds-test-designer": "script_writer",
    "swdl-uds-script-reviewer": "script_reviewer",
}


class BusinessGuidanceError(ValueError):
    """The local standards asset is unavailable or violates its bounded contract."""


def _package_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _load_asset(root: str) -> Mapping[str, Any]:
    try:
        with open(os.path.join(root, *_ASSET_REL.split("/")), encoding="utf-8") as handle:
            asset = json.load(handle)
    except (OSError, ValueError) as exc:
        raise BusinessGuidanceError("BUSINESS_GUIDANCE_ASSET_INVALID") from exc
    if not isinstance(asset, Mapping) or asset.get("schema_version") != "agent-business-guidance/v0.1":
        raise BusinessGuidanceError("BUSINESS_GUIDANCE_SCHEMA_INVALID")
    return asset


def guidance_for_profile(profile_name: str, *, root: str | None = None) -> dict[str, object]:
    """Return a bounded, path-free guide; missing local standard assets fail closed."""
    role = _PROFILE_ROLES.get(profile_name)
    if role is None:
        return {}
    package_root = root or _package_root()
    asset = _load_asset(package_root)
    roles = asset.get("roles")
    sources = asset.get("sources")
    rules = roles.get(role) if isinstance(roles, Mapping) else None
    if not isinstance(rules, list) or not isinstance(sources, list):
        raise BusinessGuidanceError("BUSINESS_GUIDANCE_ROLE_INVALID")
    source_refs: list[dict[str, str]] = []
    for source in sources:
        if not isinstance(source, Mapping) or not isinstance(source.get("id"), str) or not isinstance(source.get("path"), str):
            raise BusinessGuidanceError("BUSINESS_GUIDANCE_SOURCE_INVALID")
        rel = source["path"].replace("\\", "/")
        if not rel or rel.startswith("/") or ":" in rel or ".." in rel.split("/"):
            raise BusinessGuidanceError("BUSINESS_GUIDANCE_SOURCE_INVALID")
        source_path = os.path.realpath(os.path.join(package_root, *rel.split("/")))
        try:
            contained = os.path.normcase(os.path.commonpath((os.path.realpath(package_root), source_path))) == os.path.normcase(os.path.realpath(package_root))
        except ValueError:
            contained = False
        if not contained:
            raise BusinessGuidanceError("BUSINESS_GUIDANCE_SOURCE_INVALID")
        try:
            with open(source_path, "rb") as handle:
                digest = hashlib.sha256(handle.read()).hexdigest()
        except OSError as exc:
            raise BusinessGuidanceError("BUSINESS_GUIDANCE_SOURCE_MISSING") from exc
        source_refs.append({"id": source["id"], "sha256": digest})
    exported_rules: list[dict[str, str]] = []
    for rule in rules:
        if not isinstance(rule, Mapping) or not isinstance(rule.get("id"), str) or not isinstance(rule.get("directive"), str):
            raise BusinessGuidanceError("BUSINESS_GUIDANCE_RULE_INVALID")
        exported_rules.append({"id": rule["id"], "directive": rule["directive"][:800]})
    result: dict[str, object] = {
        "schema_version": "agent-business-guidance/v0.1",
        "asset_id": str(asset.get("asset_id") or ""),
        "asset_version": str(asset.get("asset_version") or ""),
        "role": role,
        "sources": source_refs,
        "rules": exported_rules,
    }
    if len(json.dumps(result, ensure_ascii=False, separators=(",", ":")).encode("utf-8")) > _MAX_GUIDANCE_BYTES:
        raise BusinessGuidanceError("BUSINESS_GUIDANCE_EXCEEDS_BUDGET")
    return result


__all__ = ["BusinessGuidanceError", "guidance_for_profile"]
