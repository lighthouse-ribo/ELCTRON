#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""systemPrompt bundle 生成 CLI（供 Web 层运维调用）。

用法：
  python runtime/web/prompt_cli.py                                  # 默认 bundle
  python runtime/web/prompt_cli.py --project BBS --facts-file projects/BBS.json
                                                                    # 项目 bundle
产物：runtime/dist/system_prompt.json 或 system_prompt.<project>.json
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from runtime.web.prompt import write_bundle  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--pkg", default=None, help="包根（默认按本文件自定位）")
    ap.add_argument("--project", default=None, help="项目名（生成 system_prompt.<name>.json）")
    ap.add_argument("--facts-file", default=None, help="项目事实 JSON 文件")
    args = ap.parse_args()

    facts = None
    if args.facts_file:
        with open(args.facts_file, encoding="utf-8") as fh:
            facts = json.load(fh)

    out = write_bundle(root=args.pkg, project_facts=facts)
    if args.project:
        base = os.path.dirname(out)
        out = os.path.join(base, f"system_prompt.{args.project}.json")
        from runtime.web.prompt import assemble

        bundle = assemble(root=args.pkg, project_facts=facts)
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(bundle, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")

    print(f"已生成 {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
