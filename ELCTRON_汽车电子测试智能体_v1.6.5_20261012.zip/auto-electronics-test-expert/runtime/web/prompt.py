#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""systemPrompt 动态装配引擎（T5.2）。

为 CodeBuddy SDK Web 层装配系统提示词。**七个段落全部动态取数**，
本模块不硬编码任何项目事实（项目名 / NAD / 版本号一律由 `project_facts`
参数注入；换项目只换配置不改代码）：

| 段落 | 来源 |
|---|---|
| 角色 | `agents/auto-electronics-test-expert.md` 正文（剥离 frontmatter） |
| 元信息 | 同文件 frontmatter（maxTurns / 技能列表） |
| 参考路由 | `references/reference-routing.json` 的选择策略与分支 |
| 技能索引 | 各 `skills/*/SKILL.md` 的 name + description |
| 工具面 | `runtime/dist/web_tool_surface.json`（allowedTools + call_via；hardware 组天然缺席） |
| 词汇表 | `runtime.orchestrator.state`（运行时词汇真源）+ 经 library_dispatch 读 `result_contract` 常量 |
| 项目事实 | 调用方传入的 `project_facts`；未传则明确写「未注入」，要求向用户询问 |

三条解耦声明写死在提示词里（治理不变量，非项目事实）：
* Web 层只做交互与推理，**不拥有状态机**——状态唯一真源是 runtime 编排层（R1）；
* 工具列表里没有硬件工具——硬件动作必须经审批令牌由执行器层实施（R2/R6）；
* 结论词汇必须使用契约词汇表，禁止自创 PASS/FAIL 变体（R5 的措辞面）。
"""
from __future__ import annotations

import json
import os
import re
import sys

__all__ = ["PROMPT_VERSION", "assemble", "write_bundle"]

PROMPT_VERSION = "system-prompt/v0.1"

#: 治理红线（措辞面摘要；完整定义与执行位置见各模块）。这是运行时治理常量，
#: 不是项目事实——项目无关，换项目也不变。
RED_LINES = (
    ("R1", "状态唯一性", "你不得维护第二份任务状态；状态迁移只能由编排层（Terra）写入，"
     "你提交的是事件与建议，不是状态。"),
    ("R2", "硬件隔离", "你的工具列表里没有硬件工具；任何涉及通道/设备/刷写的请求，"
     "你只能解释流程并提示需要审批，不得声称自己能执行。"),
    ("R4", "条件边", "能否进入执行子图只由静态门禁 PASS 决定；不要建议『跳过静态检查先跑一下』。"),
    ("R5", "证据口径", "结论必须用契约词汇：单条用例 PASS/FAIL/BLOCKED/NA/SKIP；"
     "run 级 PASS/FAIL/INCONCLUSIVE。证据不足只能说 INCONCLUSIVE，不许猜 PASS。"),
    ("R6", "高风险人工审批", "SWDL / 写 DID / 分区切换等动作必须先取得人工审批令牌。"),
    ("R8", "权限模式", "运行环境禁止 bypassPermissions；不要建议绕过权限确认。"),
)


def _package_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _split_frontmatter(text: str) -> tuple[dict, str]:
    """极简 frontmatter 解析（name/description/maxTurns/skills 列表），返回 (meta, body)。"""
    meta: dict = {}
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            block = text[3:end]
            body_start = text.find("\n", end + 1) + 1
            current_list: list | None = None
            for line in block.splitlines():
                if not line.strip() or line.strip().startswith("#"):
                    continue
                m = re.match(r"^(\w[\w-]*):\s*(.*)$", line)
                if m and not line.startswith((" ", "\t", "-")):
                    key, val = m.group(1), m.group(2).strip()
                    if val:
                        meta[key] = val.strip("\"'")
                        current_list = None
                    else:
                        current_list = meta.setdefault(key, [])
                elif line.lstrip().startswith("-") and current_list is not None:
                    current_list.append(line.lstrip()[1:].strip())
            return meta, text[body_start:]
    return meta, text


def _role_section(root: str) -> tuple[str, dict]:
    raw = _read(os.path.join(root, "agents", "auto-electronics-test-expert.md"))
    meta, body = _split_frontmatter(raw)
    return body.strip(), {
        "name": meta.get("name", ""),
        "max_turns": int(meta.get("maxTurns", "50")),
        "skills": meta.get("skills", []) if isinstance(meta.get("skills"), list) else [],
    }


def _routing_section(root: str) -> str:
    doc = json.loads(_read(os.path.join(root, "references", "reference-routing.json")))
    lines = ["## 参考路由（摘要，全文见 references/reference-routing.json）"]
    policy = doc.get("selection_policy", {})
    for key, label in (("primary_branch", "主分支"), ("secondary_branch", "辅分支"),
                       ("selection_order", "选择顺序"), ("evidence_priority", "证据优先级")):
        val = policy.get(key)
        if isinstance(val, list):
            lines.append(f"- {label}：" + "；".join(str(v) for v in val))
        elif val:
            lines.append(f"- {label}：{val}")
    branches = doc.get("branches") or []
    names = []
    for b in branches:
        bid = b.get("id", "?") if isinstance(b, dict) else str(b)
        scope = (b.get("scope", "") if isinstance(b, dict) else "").split("：")[0]
        names.append(f"{bid}（{scope}）" if scope else bid)
    if names:
        lines.append("- 分支：" + "；".join(names))
    return "\n".join(lines)


def _skills_section(root: str, skill_names: list[str]) -> str:
    lines = ["## 技能索引"]
    for skill in skill_names:
        path = os.path.join(root, "skills", skill, "SKILL.md")
        if not os.path.isfile(path):
            lines.append(f"- {skill}（SKILL.md 缺失——登记与磁盘不一致，请检查）")
            continue
        meta, _ = _split_frontmatter(_read(path))
        desc = str(meta.get("description", "")).strip()
        lines.append(f"- {skill}：{desc[:160]}")
    return "\n".join(lines)


def _tools_section(root: str) -> tuple[str, int]:
    surface_path = os.path.join(root, "runtime", "dist", "web_tool_surface.json")
    if not os.path.isfile(surface_path):
        return ("## 工具面\n\n工具面清单尚未生成（运行 mcp_surface.py --out）。"
                "生成前不要声称拥有任何工具。"), 0
    s = json.loads(_read(surface_path))
    web = s["web"]
    lines = ["## 工具面（摘要；完整清单见 runtime/dist/web_tool_surface.json）"]
    for g in s["groups"]:
        if not g["expose_to_web"]:
            continue
        lines.append(f"- {g['id']}：{g['tool_count']} 个工具（只读）")
    lib = sum(1 for g in s["groups"] if g["expose_to_web"]
              for e in g["tools"] if e.get("call_via", "") != "cli"
              and isinstance(e.get("call_via"), dict))
    lines.append(f"- 可调用工具共 {len(web['allowedTools'])} 个："
                 f"CLI 直接调用 + {lib} 个库模块经 library_dispatch 受控调用"
                 "（白名单函数，参数不匹配会拒绝）")
    lines.append("- **硬件工具不在此列表中**：通道/设备/刷写请求只能解释流程并走审批，"
                 "由执行器层实施。")
    return "\n".join(lines), len(web["allowedTools"])


def _vocabulary_section(root: str) -> str:
    sys.path.insert(0, root)
    from runtime.orchestrator import state as ST          # noqa: WPS433

    chain = " → ".join(st.value for st in ST.TASK_ORDER) if hasattr(ST, "TASK_ORDER") \
        else "见 runtime/orchestrator/state.py"
    lines = ["## 契约词汇表（结论必须用这些词，禁止自创变体）"]
    lines.append(f"- 任务状态链：{chain}")
    lines.append("- 门禁结论：" + ", ".join(g.value for g in ST.GateStatus))
    lines.append("- run 级结论：" + ", ".join(v.value for v in ST.RunFinalVerdict)
                 + "（证据不足只能是 INCONCLUSIVE）")
    lines.append("- 执行入口：" + ", ".join(s.value for s in ST.EXECUTION_ENTRY_STATES)
                 + " —— 只有静态门禁 PASS 才存在通往执行的边")
    # 单条用例级 verdict 经受控分发读取真源，不在本模块复制
    try:
        from runtime.orchestrator import library_dispatch as D  # noqa: WPS433
        out = D.call("result_contract", "VALID_VERDICTS", root=root)
        vals = out["result"]
        if isinstance(vals, (set, frozenset)):
            vals = sorted(vals)
        lines.append("- 用例级结论：" + ", ".join(str(v) for v in vals)
                     + "（真源 result_contract.VALID_VERDICTS）")
    except Exception as exc:                                # noqa: BLE001
        lines.append(f"- 用例级结论：读取失败（{exc}）——请检查库模块清单")
    return "\n".join(lines)


def _facts_section(project_facts: dict | None) -> str:
    if not project_facts:
        return ("## 项目事实\n\n**未注入项目配置。**在了解项目专属信息（NAD、波特率、"
                "DID 清单、软件版本等）之前，先向用户询问或让其提供项目配置；"
                "禁止凭记忆或推测填充这些值。")
    lines = ["## 项目事实（由项目配置注入，换项目只换配置）"]
    for k in sorted(project_facts):
        v = project_facts[k]
        if isinstance(v, (list, tuple)):
            v = "、".join(str(x) for x in v)
        lines.append(f"- {k}: {v}")
    return "\n".join(lines)


def assemble(root: str | None = None,
             project_facts: dict | None = None) -> dict:
    """装配 systemPrompt。返回 dict：prompt / sections / agent_meta / tool_count。"""
    root = root or _package_root()
    role, agent_meta = _role_section(root)
    tools_text, tool_count = _tools_section(root)   # 只读一次，两处复用

    sections = {
        "role": role,
        "layers": (
            "## 三层边界（你的定位）\n"
            "- 你是**交互与推理层**：会话、资料理解、用例设计建议、证据解释。\n"
            "- 治理编排（状态机、门禁、审批）归 runtime 编排层；能力执行归既有 CLI/执行器。\n"
            "- 你不拥有状态、不持有硬件、不伪造证据。"),
        "routing": _routing_section(root),
        "skills": _skills_section(root, agent_meta.get("skills", [])),
        "tools": tools_text,
        "vocabulary": _vocabulary_section(root),
        "red_lines": "## 治理红线（无条件遵守）\n" + "\n".join(
            f"- {rid} {title}：{text}" for rid, title, text in RED_LINES),
        "project_facts": _facts_section(project_facts),
    }

    order = ("role", "layers", "routing", "skills", "tools",
             "vocabulary", "red_lines", "project_facts")
    prompt = "\n\n".join(sections[k] for k in order)

    return {
        "prompt_version": PROMPT_VERSION,
        "agent_meta": agent_meta,
        "tool_count": _tools_section(root)[1],
        "sections": sections,
        "prompt": prompt,
    }


def write_bundle(root: str | None = None, project_facts: dict | None = None,
                 out: str | None = None) -> str:
    """装配并写出 JSON bundle（Web 层 server/prompt.ts 的消费入口）。"""
    root = root or _package_root()
    bundle = assemble(root, project_facts)
    out = out or os.path.join(root, "runtime", "dist", "system_prompt.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(bundle, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")
    return out
