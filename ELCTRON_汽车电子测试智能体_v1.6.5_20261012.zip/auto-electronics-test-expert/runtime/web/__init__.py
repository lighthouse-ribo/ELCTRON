"""Web 层装配件（systemPrompt 等）。Web server 只做薄消费，语义归 runtime。"""
