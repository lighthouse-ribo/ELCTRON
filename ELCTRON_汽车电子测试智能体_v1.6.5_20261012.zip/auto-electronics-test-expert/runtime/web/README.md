# runtime/web —— Web 层装配件

Web 工程（T5.1，`aetex-web/`）是薄消费层；**语义与装配归本目录**，换 Web 框架不动语义。

## T5.2 systemPrompt 动态装配（prompt.py）

`assemble(root, project_facts=None)` → `{prompt, sections, agent_meta, tool_count}`；
`write_bundle(...)` → `runtime/dist/system_prompt.json`（Web `server/prompt.ts` 的消费入口）。

七个段落全部动态取数，**本模块不硬编码任何项目事实**：

| 段落 | 来源 |
|---|---|
| 角色 / 元信息 | `agents/auto-electronics-test-expert.md`（正文 + frontmatter 的 maxTurns/skills） |
| 参考路由 | `references/reference-routing.json`（选择策略 + 三分支摘要） |
| 技能索引 | 各 `skills/*/SKILL.md` 的 name/description |
| 工具面 | `runtime/dist/web_tool_surface.json`（allowedTools + call_via；hardware 组天然缺席） |
| 词汇表 | `runtime.orchestrator.state` 真源 + 经 library_dispatch 读 `result_contract.VALID_VERDICTS` |
| 红线 | prompt.py 内治理常量 R1/R2/R4/R5/R6/R8（措辞面摘要，含执行位置） |
| 项目事实 | 仅从 `project_facts` 参数注入；未传则明确写「未注入」并要求向用户询问 |

## 测试钉住的不变量（test_prompt.py，11 项）

* 同输入逐字符确定（Web 缓存与漂移检查的前提）
* prompt 里无任何 `hardware__` 工具 id（R2 措辞面）
* 词汇表来自真源：`STATIC_PASSED` / `INCONCLUSIVE` / `result_contract.VALID_VERDICTS`
* 三层解耦声明出现（「不拥有状态」）
* 注入不同 `project_facts` 得到不同 prompt；未注入时明确要求询问
* **源码洁癖**：prompt.py 自身不得含 `0x51` / `BBS` / `V436` / `Vcan` / `Volvo` 等项目特定值

## 换项目操作

只传不同的 `project_facts`（或让 Web 层从项目配置文件读取后传入），
不改本模块一行代码。项目事实的建议字段：项目名、NAD、波特率、DID 清单、
软件版本、参考文档路径——全部由调用方决定，这里不设默认。
