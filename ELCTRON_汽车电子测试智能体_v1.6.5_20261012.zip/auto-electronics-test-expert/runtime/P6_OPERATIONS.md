# P6 运行边界（dormant）

下列能力均是 **P6 dormant**：已有数据结构、离线测试或 fail-closed 入口，但尚未接入生产
`GraphRunner` 的运行事件钩子，不能计入已交付的运行能力或完成度。接线的前置条件是：为每个
run 定义 `approved`、`revoked`、`mirror_retry`、`execution_failed` 等不可伪造事件，并把来源
run 与工件哈希传入；Web 不得直接写入这些存储。

`runtime/config_layer.py` 的配置文件只保存非敏感的硬件白名单、配置哈希和 Mem0 开关；它拒绝 `api_key`、`token`、`secret` 等字段。优先级为默认值、受版本控制的配置文件、显式白名单环境变量。真实只读 e2e 还必须通过 `runtime.executor.release_gate`，且必须提供设备白名单与 `AETEX_REAL_E2E=1`。

记忆/Mem0 是 dormant 的可选镜像：本地 SQLite 是未来事实源，只有已审批的记忆可进入 outbox。启用前，在隔离环境安装 `mem0ai`，将凭据仅注入由 `mem0_credential_env` 指向的进程环境变量，再用 `inspect_mem0_environment()` 验证包可用和凭据存在；该报告不输出凭据值。镜像失败保留为可重试的 outbox 项，撤回会取消待发送项。

VICKCAN 仍是 dormant 的 fail-closed 集成边界。CANviex F1L1 已有经过 `xcdevlay.h` 1.3.8 验证的 `runtime.executor.canviex_f1l1` 适配器：`probe_f1l1()` 只读取 DLL 版本和设备可用位图；`CanviexF1L1Executor` 只把真实 SDK 时间戳轨迹封存为 ASC 证据。它尚未接入生产执行节点，因而不能绕过静态 PASS、运行时令牌、租约、预检及 ASC 落盘完整性演练。

失败样本库是 dormant：只存已审批、带来源 run 和证据哈希的红摘要；不存原始 ASC、报文或凭据。`FailureSampleLibrary` 是追加式 JSONL，按失败类别检索仅作离线分析，不参与执行决策。
