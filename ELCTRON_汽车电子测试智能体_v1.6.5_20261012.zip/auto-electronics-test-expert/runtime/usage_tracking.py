"""Provider-reported counters only; never collect prompts or credentials."""
from datetime import datetime,timezone
from uuid import uuid4
_events=[]
def reset_usage_events():
    _events.clear()
def usage_events():
    return list(_events)
def record_provider_usage(provider,model,raw):
    if provider not in ('codex','deepseek') or not isinstance(raw,dict):return
    input_tokens=raw.get('input_tokens',raw.get('prompt_tokens'))
    output_tokens=raw.get('output_tokens',raw.get('completion_tokens'))
    details=raw.get('prompt_tokens_details') or raw.get('input_tokens_details') or {}
    cached=raw.get('cached_input_tokens',raw.get('prompt_cache_hit_tokens',details.get('cached_tokens',0) if isinstance(details,dict) else 0))
    def valid(n):return type(n) is int and 0<=n<=9007199254740991
    if not all(valid(n) for n in (input_tokens,output_tokens,cached)) or cached>input_tokens:return
    total=raw.get('total_tokens',input_tokens+output_tokens)
    if not valid(total) or total<input_tokens+output_tokens:return
    _events.append(dict(id=str(uuid4()),provider=provider,model=str(model)[:120],at=datetime.now(timezone.utc).isoformat(),input=input_tokens,output=output_tokens,cached=cached,total=total))
