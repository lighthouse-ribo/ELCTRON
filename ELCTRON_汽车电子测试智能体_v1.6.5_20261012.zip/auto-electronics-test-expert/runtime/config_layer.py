"""Fail-closed runtime configuration layering for the P6 rollout.

Only non-secret operational policy is allowed in a configuration file.  Values
are resolved in this order: built-in defaults < checked configuration file <
explicit allow-listed environment overrides.  Secrets stay in the process
environment and are represented here only by their environment-variable name.
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from .executor.preflight import PreflightConfig

_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_FORBIDDEN_KEY = re.compile(r"(?:api[_-]?key|token|secret|password|authorization|credential)", re.I)


class ConfigError(ValueError):
    """A configuration violates the non-secret, explicitly layered contract."""


@dataclass(frozen=True)
class RuntimeConfig:
    adapter: str = ""
    channels: tuple[str, ...] = ()
    expected_config_sha256: str = ""
    mem0_mirror_enabled: bool = False
    mem0_credential_env: str = "MEM0_API_KEY"
    model_default_route: str = "worker"
    model_profile_routes: tuple[tuple[str, str], ...] = ()
    worker_base_url: str = "https://api.deepseek.com/v1"
    worker_model: str = "deepseek-flash"
    worker_credential_env: str = "DEEPSEEK_API_KEY"
    head_command: str = "codex"
    head_model: str = ""

    def model_route_for(self, profile_name: str) -> str:
        return dict(self.model_profile_routes).get(profile_name, self.model_default_route)

    def preflight(self) -> PreflightConfig:
        return PreflightConfig(
            adapter=self.adapter,
            channels=self.channels,
            expected_config_sha256=self.expected_config_sha256,
        )

    def real_e2e_errors(self) -> list[str]:
        errors: list[str] = []
        if not self.adapter:
            errors.append("hardware.adapter is required")
        if not self.channels:
            errors.append("hardware.channels must contain an allow-listed channel")
        if not _SHA256.fullmatch(self.expected_config_sha256):
            errors.append("hardware.expected_config_sha256 must be a lowercase SHA-256")
        return errors


@dataclass(frozen=True)
class Mem0EnvironmentReport:
    enabled: bool
    package_available: bool
    credential_env: str
    credential_present: bool

    @property
    def ready(self) -> bool:
        return not self.enabled or (self.package_available and self.credential_present)

    def public_dict(self) -> dict[str, object]:
        return {
            "enabled": self.enabled,
            "package_available": self.package_available,
            "credential_env": self.credential_env,
            "credential_present": self.credential_present,
            "ready": self.ready,
        }


def _reject_secrets(value: object, prefix: str = "") -> None:
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            full_key = f"{prefix}{key_text}".rstrip(".")
            # This is a variable *name* reference, never a credential value.
            if _FORBIDDEN_KEY.search(key_text) and full_key not in {
                "memory.mem0_credential_env",
                "models.worker_credential_env",
            }:
                raise ConfigError(f"secret-like key is forbidden in runtime config: {prefix}{key_text}")
            _reject_secrets(child, f"{prefix}{key_text}.")
    elif isinstance(value, list):
        for child in value:
            _reject_secrets(child, prefix)


def _as_mapping(value: object, name: str) -> Mapping[str, object]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ConfigError(f"{name} must be an object")
    return value


def _channels(value: object) -> tuple[str, ...]:
    if not isinstance(value, list) or not value or not all(isinstance(item, str) and item.strip() for item in value):
        raise ConfigError("hardware.channels must be a non-empty string array")
    return tuple(item.strip() for item in value)


def _bool(value: object, name: str) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.lower() in {"0", "1", "true", "false"}:
        return value.lower() in {"1", "true"}
    raise ConfigError(f"{name} must be a boolean")


def load_runtime_config(path: str | os.PathLike[str] | None = None, *, env: Mapping[str, str] | None = None) -> RuntimeConfig:
    """Load an auditable non-secret profile without touching devices or Mem0."""
    environment = env or os.environ
    source_path = path or environment.get("AETEX_RUNTIME_CONFIG")
    raw: Mapping[str, object] = {}
    if source_path:
        with open(Path(source_path), encoding="utf-8") as handle:
            parsed = json.load(handle)
        raw = _as_mapping(parsed, "runtime config")
    _reject_secrets(raw)
    unknown = set(raw) - {"hardware", "memory", "models"}
    if unknown:
        raise ConfigError(f"unknown runtime config sections: {sorted(unknown)}")
    hardware = _as_mapping(raw.get("hardware"), "hardware")
    memory = _as_mapping(raw.get("memory"), "memory")
    models = _as_mapping(raw.get("models"), "models")
    if set(hardware) - {"adapter", "channels", "expected_config_sha256"}:
        raise ConfigError("unknown hardware configuration key")
    if set(memory) - {"mem0_mirror_enabled", "mem0_credential_env"}:
        raise ConfigError("unknown memory configuration key")
    if set(models) - {"default_route", "profile_routes", "worker_base_url", "worker_model",
                      "worker_credential_env", "head_command", "head_model"}:
        raise ConfigError("unknown models configuration key")

    adapter = str(hardware.get("adapter", "")).strip()
    channels = _channels(hardware["channels"]) if "channels" in hardware else ()
    digest = str(hardware.get("expected_config_sha256", "")).strip().lower()
    mirror = _bool(memory.get("mem0_mirror_enabled", False), "memory.mem0_mirror_enabled")
    credential_env = str(memory.get("mem0_credential_env", "MEM0_API_KEY")).strip()
    default_route = str(models.get("default_route", "worker")).strip().lower()
    profile_routes_raw = _as_mapping(models.get("profile_routes"), "models.profile_routes")
    profile_routes = tuple(sorted((str(name).strip(), str(route).strip().lower())
                                  for name, route in profile_routes_raw.items()))
    worker_base_url = str(models.get("worker_base_url", "https://api.deepseek.com/v1")).rstrip("/")
    worker_model = str(models.get("worker_model", "deepseek-flash")).strip()
    worker_credential_env = str(models.get("worker_credential_env", "DEEPSEEK_API_KEY")).strip()
    head_command = str(models.get("head_command", "codex")).strip()
    head_model = str(models.get("head_model", "")).strip()

    if environment.get("AETEX_HARDWARE_ADAPTER"):
        adapter = environment["AETEX_HARDWARE_ADAPTER"].strip()
    if environment.get("AETEX_HARDWARE_CHANNELS"):
        channels = tuple(item.strip() for item in environment["AETEX_HARDWARE_CHANNELS"].split(",") if item.strip())
    if environment.get("AETEX_HARDWARE_CONFIG_SHA256"):
        digest = environment["AETEX_HARDWARE_CONFIG_SHA256"].strip().lower()
    if environment.get("AETEX_MEM0_MIRROR") is not None:
        mirror = _bool(environment["AETEX_MEM0_MIRROR"], "AETEX_MEM0_MIRROR")
    if environment.get("AETEX_MEM0_CREDENTIAL_ENV"):
        credential_env = environment["AETEX_MEM0_CREDENTIAL_ENV"].strip()
    if environment.get("AETEX_MODEL_DEFAULT_ROUTE"):
        default_route = environment["AETEX_MODEL_DEFAULT_ROUTE"].strip().lower()
    if environment.get("AETEX_DEEPSEEK_BASE_URL"):
        worker_base_url = environment["AETEX_DEEPSEEK_BASE_URL"].rstrip("/")
    if environment.get("AETEX_DEEPSEEK_MODEL"):
        worker_model = environment["AETEX_DEEPSEEK_MODEL"].strip()
    if environment.get("AETEX_DEEPSEEK_CREDENTIAL_ENV"):
        worker_credential_env = environment["AETEX_DEEPSEEK_CREDENTIAL_ENV"].strip()
    if environment.get("AETEX_CODEX_COMMAND"):
        head_command = environment["AETEX_CODEX_COMMAND"].strip()
    if environment.get("AETEX_CODEX_MODEL"):
        head_model = environment["AETEX_CODEX_MODEL"].strip()
    if not re.fullmatch(r"[A-Z][A-Z0-9_]*", credential_env):
        raise ConfigError("memory.mem0_credential_env must be an uppercase environment-variable reference")
    if default_route not in {"head", "worker"}:
        raise ConfigError("models.default_route must be head or worker")
    if any(not name or route not in {"head", "worker"} for name, route in profile_routes):
        raise ConfigError("models.profile_routes values must be head or worker")
    if not worker_base_url.startswith(("https://", "http://")) or not worker_model or not head_command:
        raise ConfigError("models requires a http(s) worker_base_url, worker_model and head_command")
    if not re.fullmatch(r"[A-Z][A-Z0-9_]*", worker_credential_env):
        raise ConfigError("models.worker_credential_env must be an uppercase environment-variable reference")
    return RuntimeConfig(adapter, channels, digest, mirror, credential_env, default_route, profile_routes,
                         worker_base_url, worker_model, worker_credential_env, head_command, head_model)


def inspect_mem0_environment(config: RuntimeConfig, *, env: Mapping[str, str] | None = None) -> Mem0EnvironmentReport:
    """Report readiness without returning a credential value or contacting Mem0."""
    environment = env or os.environ
    return Mem0EnvironmentReport(
        enabled=config.mem0_mirror_enabled,
        package_available=importlib.util.find_spec("mem0") is not None,
        credential_env=config.mem0_credential_env,
        credential_present=bool(environment.get(config.mem0_credential_env)),
    )


__all__ = ["ConfigError", "Mem0EnvironmentReport", "RuntimeConfig", "inspect_mem0_environment", "load_runtime_config"]
