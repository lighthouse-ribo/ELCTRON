#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.2 契约校验器（只读）。

做三件事，任一不过即退出码 1：

  1. Schema 自检：dialect 必须是 2020-12，$id 唯一，schema_version 常量与文件名一致，
     且每个 schema 至少带一个 examples 样本。
  2. 样本校验：用 Draft202012Validator 逐条校验 schema 内嵌的 examples。
  3. 词汇表漂移校验：
     - schema 里的 enum 必须是对 enums.json 中对应词汇表的**子集**；
     - enums.json 中 status=existing 的词汇表，其值必须与其 source_of_truth
       指向的既有 Python 常量 / JSON 字段**完全一致**（防止运行时另起一套词汇）；
     - status=new 的词汇表必须被至少一个 schema 引用（防孤儿词汇）。

运行时依赖：jsonschema>=4.18（Draft 2020-12）。

用法:
  python validate_contracts.py [--root <包根目录>] [--quiet]
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

try:
    from jsonschema import Draft202012Validator
    from jsonschema.exceptions import SchemaError
except ImportError:  # pragma: no cover
    print("ERROR: 需要 jsonschema>=4.18（pip install jsonschema）")
    sys.exit(2)

CONTRACTS_DIR = "runtime/contracts"
DIALECT = "https://json-schema.org/draft/2020-12/schema"

_STR_RX = re.compile(r"""["']([^"']+)["']""")
_BLOCK_OPEN_RX = r"\b{name}\s*=\s*(?:frozenset|set|tuple|list)?\s*[\(\[]?\s*\{{"


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.checks = 0

    def ok(self) -> None:
        self.checks += 1

    def error(self, msg: str) -> None:
        self.errors.append(msg)

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)


def _balanced_slice(text: str, start: int, open_ch: str = "{", close_ch: str = "}") -> str:
    """从 start（指向 open_ch）起返回配对闭合的内容（含首尾）。"""
    depth = 0
    i = start
    while i < len(text):
        ch = text[i]
        if ch == '"' or ch == "'":
            quote = ch
            i += 1
            while i < len(text) and text[i] != quote:
                if text[i] == "\\":
                    i += 1
                i += 1
        elif ch == open_ch:
            depth += 1
        elif ch == close_ch:
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
        i += 1
    return text[start:]


def extract_py_const_set(root: str, rel_path: str, name: str) -> list[str] | None:
    """静态提取 Python 常量的字符串集合（不导入模块，避免副作用）。"""
    path = os.path.join(root, rel_path)
    if not os.path.isfile(path):
        return None
    text = open(path, encoding="utf-8", errors="replace").read()

    # 情况 A：模块级集合常量，如 VALID_VERDICTS = frozenset({...})
    m = re.search(_BLOCK_OPEN_RX.format(name=re.escape(name)), text)
    if m:
        brace_at = text.index("{", m.start())
        block = _balanced_slice(text, brace_at)
        values = [v for v in _STR_RX.findall(block)]
        if values:
            return sorted(set(values))

    # 情况 B：枚举类，如 class FlowKind(str, Enum) 内的 NAME = "value"
    cm = re.search(rf"^class\s+{re.escape(name)}\b.*?(?=^class\s|\Z)", text, re.M | re.S)
    if cm:
        body = cm.group(0)
        values = re.findall(r"^\s{4}[A-Z][A-Z0-9_]*\s*=\s*[\"']([^\"']+)[\"']", body, re.M)
        if values:
            return sorted(set(values))
    return None


def extract_json_field(root: str, rel_path: str, dotted: str) -> list[str] | None:
    """从 Python 源码静态提取模块级字面量字段（不导入模块）。"""
    path = os.path.join(root, rel_path)
    if not os.path.isfile(path):
        return None
    try:
        data = json.load(open(path, encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    cur = data
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    if isinstance(cur, list) and all(isinstance(x, str) for x in cur):
        return sorted(set(cur))
    return None


def resolve_source_of_truth(root: str, spec: str) -> tuple[list[str] | None, str]:
    """解析 'rel/path.py :: CONST' 或 'rel/path.json :: a.b.c'。"""
    if "::" not in spec:
        return None, "无法解析的 source_of_truth（缺 '::'）"
    rel, _, target = spec.partition("::")
    rel = rel.strip()
    target = target.strip()
    if rel.endswith(".json"):
        vals = extract_json_field(root, rel, target)
        return vals, ("json path" if vals is not None else "JSON 路径取值失败")
    if rel.endswith(".py"):
        vals = extract_py_const_set(root, rel, target)
        return vals, ("python const" if vals is not None else "Python 常量静态提取失败")
    return None, "不支持的 source_of_truth 文件类型"


def collect_schema_enums(node, path="$", found=None):
    """递归收集 (annotation, json_pointer, enum_values)。"""
    if found is None:
        found = []
    if isinstance(node, dict):
        ann = node.get("x-enum-vocabulary")
        if ann and isinstance(node.get("enum"), list):
            found.append((ann, path, list(node["enum"])))
        for k, v in node.items():
            collect_schema_enums(v, f"{path}.{k}", found)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            collect_schema_enums(v, f"{path}[{i}]", found)
    return found


def main() -> int:
    """命令行入口：--root 指定包根。"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.root or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    contracts = os.path.join(root, CONTRACTS_DIR)
    rep = Report()

    if not os.path.isdir(contracts):
        print(f"ERROR: 找不到契约目录 {contracts}")
        return 2

    enums_path = os.path.join(contracts, "enums.json")
    if not os.path.isfile(enums_path):
        print(f"ERROR: 找不到词汇表注册表 {enums_path}")
        return 2
    registry = json.load(open(enums_path, encoding="utf-8"))
    vocab = registry["vocabularies"]

    schema_files = sorted(f for f in os.listdir(contracts)
                          if f.endswith(".schema.json"))
    if not schema_files:
        print("ERROR: 没有发现任何 *.schema.json")
        return 2

    used_vocab: set[str] = set()
    ids: dict[str, str] = {}

    for fname in schema_files:
        fpath = os.path.join(contracts, fname)
        try:
            schema = json.load(open(fpath, encoding="utf-8"))
        except json.JSONDecodeError as exc:
            rep.error(f"[{fname}] JSON 解析失败：{exc}")
            continue

        # --- 1. Schema 自检 ---
        if schema.get("$schema") != DIALECT:
            rep.error(f"[{fname}] $schema 必须是 {DIALECT}")
        sid = schema.get("$id")
        if not sid:
            rep.error(f"[{fname}] 缺 $id")
        elif sid in ids:
            rep.error(f"[{fname}] $id 与 {ids[sid]} 重复：{sid}")
        else:
            ids[sid] = fname

        try:
            Draft202012Validator.check_schema(schema)
            rep.ok()
        except SchemaError as exc:
            rep.error(f"[{fname}] 不是合法 JSON Schema：{exc.message[:160]}")
            continue

        # schema_version 常量与文件名一致（如 task_state.v0.1 -> task-state/v0.1）
        stem = fname[: -len(".schema.json")]           # task_state.v0.1
        m = re.match(r"^(.+?)\.(v\d+\.\d+)$", stem)
        if m:
            expected_const = f"{m.group(1).replace('_', '-')}/{m.group(2)}"
            got = schema.get("properties", {}).get("schema_version", {}).get("const")
            if got != expected_const:
                rep.error(f"[{fname}] schema_version 常量应为 {expected_const!r}，实为 {got!r}")
            else:
                rep.ok()

        # --- 2. 样本校验 ---
        examples = schema.get("examples")
        if not isinstance(examples, list) or not examples:
            rep.error(f"[{fname}] 缺少 examples 样本，契约无法自证")
        else:
            validator = Draft202012Validator(schema)
            for idx, sample in enumerate(examples):
                errs = sorted(validator.iter_errors(sample), key=lambda e: list(e.path))
                if errs:
                    e = errs[0]
                    loc = "/".join(str(p) for p in e.path) or "<root>"
                    rep.error(f"[{fname}] example[{idx}] 校验失败 @ {loc}：{e.message[:200]}")
                else:
                    rep.ok()

        # --- 3a. 词汇表引用检查 ---
        for ann, ptr, values in collect_schema_enums(schema):
            used_vocab.add(ann)
            if ann not in vocab:
                rep.error(f"[{fname}] 引用了未注册词汇表 {ann!r} @ {ptr}")
                continue
            allowed = set(vocab[ann]["values"])
            extra = sorted(set(values) - allowed)
            if extra:
                rep.error(f"[{fname}] {ann} 出现未登记取值 {extra} @ {ptr}")
            else:
                rep.ok()

    # --- 3b. existing 词汇表必须与既有真源完全一致 ---
    for name, entry in vocab.items():
        sot = entry.get("source_of_truth", "")
        if entry.get("status") != "existing":
            continue
        vals, how = resolve_source_of_truth(root, sot)
        if vals is None:
            rep.error(f"[enums] {name} 真源无法解析（{how}）：{sot}")
            continue
        declared = sorted(set(entry["values"]))
        if declared != vals:
            only_decl = sorted(set(declared) - set(vals))
            only_src = sorted(set(vals) - set(declared))
            rep.error(f"[enums] {name} 与真源漂移；契约多出={only_decl} 真源多出={only_src}（{sot}）")
        else:
            rep.ok()

    # --- 3c. new 词汇表不应是孤儿 ---
    for name, entry in vocab.items():
        if entry.get("status") == "new" and name not in used_vocab:
            rep.warn(f"[enums] 词汇表 {name} 未被任何 schema 引用（孤儿词汇）")

    # --- 输出 ---
    if not args.quiet:
        print(f"contracts : {contracts}")
        print(f"schemas   : {len(schema_files)}  ->  " + ", ".join(schema_files))
        print(f"vocab     : {len(vocab)} 已注册，{len(used_vocab)} 被引用")
        print(f"checks    : {rep.checks} 通过")
        for w in rep.warnings:
            print(f"  WARN  {w}")
        if rep.errors:
            print(f"\n{len(rep.errors)} 项错误：")
            for e in rep.errors:
                print(f"  ERROR {e}")
        else:
            print("\n结果：PASS（Schema 自检 + 样本校验 + 词汇表漂移校验全部通过）")

    return 1 if rep.errors else 0


if __name__ == "__main__":
    sys.exit(main())
