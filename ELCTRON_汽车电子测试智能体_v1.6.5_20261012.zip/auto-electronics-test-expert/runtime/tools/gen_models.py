#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.2 契约代码生成器：JSON Schema → pydantic v2 模型。

设计要点
--------
1. **Schema 是唯一来源**。`runtime/contracts/generated/models.py` 是派生产物，
   禁止手工编辑。改了 schema 必须重新生成；漂移由 `runtime/tests/test_models.py` 拦截。
2. **模块级类 + 类型别名**。嵌套对象展开为 `<契约><属性链>` 形式的模块级类；
   `$defs` 若是标量/数组（如 sha256、runId 这类带 pattern 的字符串），
   生成**类型别名**而不是空模型 —— 这是本生成器最早踩到的坑。
3. **共享 `$defs` 去重**。多个 schema 中内容相同的 `$defs` 只生成一次；
   同名不同体视为冲突并直接报错（宁可失败，不要静默生成错误模型）。
4. **跨字段约束不丢**。`allOf/if/then/anyOf/oneOf/not` 无法映射到 pydantic 声明式语法，
   因此对**含这类关键字的契约**在根类注入 `model_validator(mode="after")`，
   构造后回放权威 schema（`runtime/contracts/validation.py`）。
   只对需要的契约开启，其余契约零额外开销。

用法:
  python runtime/tools/gen_models.py            # 生成
  python runtime/tools/gen_models.py --check    # 只校验生成物是否为最新（漂移门禁）
"""
from __future__ import annotations

import argparse
import hashlib
import json
import keyword
import os
import re
import sys

CONTRACTS_DIR = "runtime/contracts"
OUT_DIR = "runtime/contracts/generated"
OUT_FILE = "models.py"
INIT_FILE = "__init__.py"

COMPLEX_KEYWORDS = ("allOf", "anyOf", "oneOf", "not", "if")

HEADER = '''# -*- coding: utf-8 -*-
"""！！ 本文件由 runtime/tools/gen_models.py 自动生成，请勿手工编辑 ！！

来源（唯一真源）：runtime/contracts/*.schema.json
重新生成：python runtime/tools/gen_models.py
漂移校验：python -m unittest discover -s runtime/tests

契约指纹：{fingerprint}
"""
from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

AUTHORITATIVE_CONTRACTS: dict[str, str] = {{
{authoritative_map}
}}

__all__ = [
{all_names}
]
'''

VALIDATOR_BLOCK = '''
    @model_validator(mode="after")
    def _enforce_authoritative_schema(self):
        """本契约含跨字段约束，构造后回放权威 schema。"""
        from ..validation import validate_payload

        cid = AUTHORITATIVE_CONTRACTS[type(self).__name__]
        validate_payload(cid, self.model_dump(mode="json", exclude_unset=True, by_alias=True))
        return self
'''


def camel(name: str) -> str:
    """snake_case → UpperCamelCase。"""
    parts = re.split(r"[^0-9A-Za-z]+", name)
    out = "".join(p[:1].upper() + p[1:] for p in parts if p)
    if not out:
        out = "Value"
    if out[0].isdigit():
        out = "N" + out
    return out


def field_name(raw: str) -> str:
    """JSON 字段名 → Python 属性名（关键字避让，如 from → from_）。"""
    return raw + "_" if keyword.iskeyword(raw) or raw in {"model_config"} else raw


# --------------------------------------------------------------------------- #
# 上下文
# --------------------------------------------------------------------------- #
class Ctx:
    def __init__(self, doc: dict):
        self.doc = doc
        self.def_class: dict[str, str] = {}
        self.classes: list[tuple[str, list[tuple[str, str, str, str]]]] = []
        self.aliases: list[tuple[str, str]] = []
        self.used: set[str] = set()

    def unique(self, name: str) -> str:
        base, i = name, 2
        while name in self.used:
            name = f"{base}{i}"
            i += 1
        self.used.add(name)
        return name

    def alias(self, name: str, ann: str) -> None:
        self.aliases.append((name, ann))

    def add(self, cls: str, fields: list[tuple[str, str, str, str]]) -> None:
        self.classes.append((cls, fields))


def _merge_kw(kw: str, extra: str) -> str:
    return f"{kw}, {extra}" if kw else extra


def _field_kw(node: dict) -> str:
    text = node.get("description") or node.get("title")
    return f"description={text!r}" if text else ""


# --------------------------------------------------------------------------- #
# 类型映射
# --------------------------------------------------------------------------- #
def annotation_for(node: dict, ctx: Ctx, owner: str, prefix: str) -> tuple[str, str]:
    """返回 (python 注解字符串, Field 附加关键字)。"""
    if not isinstance(node, dict):
        return "Any", ""

    if "$ref" in node:
        ref = node["$ref"]
        if not ref.startswith("#/$defs/"):
            raise ValueError(f"暂不支持的 $ref：{ref}")
        return ctx.def_class[ref.split("/")[-1]], ""

    if "const" in node:
        return f"Literal[{node['const']!r}]", _field_kw(node)

    if "enum" in node:
        return "Literal[" + ", ".join(repr(v) for v in node["enum"]) + "]", _field_kw(node)

    raw_type = node.get("type")
    nullable = False
    if isinstance(raw_type, list):
        nullable = "null" in raw_type
        rest = [t for t in raw_type if t != "null"]
        if not rest:
            return "None", ""
        raw_type = rest[0]

    kw = _field_kw(node)

    if raw_type == "string":
        ann = "datetime" if node.get("format") == "date-time" else "str"
        cons = []
        for src, arg in (("pattern", "pattern"), ("minLength", "min_length"), ("maxLength", "max_length")):
            if src in node:
                cons.append(f"{arg}={node[src]!r}")
        if cons:
            ann = f"Annotated[{ann}, StringConstraints({', '.join(cons)})]"
        return _opt(ann, nullable), kw

    if raw_type in ("integer", "number"):
        ann = "int" if raw_type == "integer" else "float"
        bounds = []
        for src, arg in (("minimum", "ge"), ("maximum", "le"),
                         ("exclusiveMinimum", "gt"), ("exclusiveMaximum", "lt")):
            if src in node:
                bounds.append(f"{arg}={node[src]!r}")
        if bounds:
            ann = f"Annotated[{ann}, Field({', '.join(bounds)})]"
        return _opt(ann, nullable), kw

    if raw_type == "boolean":
        return _opt("bool", nullable), kw

    if raw_type == "array":
        item_ann, _ = annotation_for(node.get("items", {}), ctx, owner, prefix + "Item")
        if "minItems" in node:
            kw = _merge_kw(kw, f"min_length={node['minItems']!r}")
        return _opt(f"list[{item_ann}]", nullable), kw

    if raw_type == "object":
        if node.get("properties"):
            cls = ctx.unique(f"{owner}{camel(prefix) or 'Obj'}")
            _emit_object(cls, node, ctx, cls)
            return _opt(cls, nullable), kw
        addl = node.get("additionalProperties")
        if isinstance(addl, dict):
            val_ann, _ = annotation_for(addl, ctx, owner, prefix + "Value")
            return _opt(f"dict[str, {val_ann}]", nullable), kw
        return _opt("dict[str, Any]", nullable), kw

    return "Any", kw


def _opt(ann: str, nullable: bool) -> str:
    return ann if not nullable or ann.startswith("Optional[") else f"Optional[{ann}]"


def _emit_object(cls: str, node: dict, ctx: Ctx, owner: str) -> None:
    props = node.get("properties", {})
    required = set(node.get("required", []))
    fields: list[tuple[str, str, str, str]] = []
    for pname, pnode in props.items():
        ann, kw = annotation_for(pnode, ctx, owner, camel(pname))
        # Python 关键字（如 from）不能作字段名：改用安全名 + alias 保留 JSON 原名
        safe = field_name(pname)
        if safe != pname:
            kw = _merge_kw(kw, f"alias={pname!r}")
        if pname not in required:
            ann = _opt(ann, True)
            kw = _merge_kw(kw, "default=None")
        note = ""
        if isinstance(pnode, dict) and pnode.get("x-enum-vocabulary"):
            note = pnode["x-enum-vocabulary"]
        fields.append((safe, ann, kw, note))
    ctx.add(cls, fields)


def emit_shared_defs(ctx: Ctx) -> None:
    """$defs 去重生成：object → 模型类；标量/数组 → 类型别名。"""
    seen: dict[str, str] = {}
    for key, node in ctx.doc.get("$defs", {}).items():
        canon = json.dumps(node, sort_keys=True, ensure_ascii=False)
        if canon in seen:
            ctx.def_class[key] = seen[canon]
            continue
        name = ctx.unique(camel(key))
        seen[canon] = name
        ctx.def_class[key] = name
        if isinstance(node, dict) and node.get("type") == "object" and node.get("properties"):
            _emit_object(name, node, ctx, name)
        else:
            ann, _ = annotation_for(node, ctx, name, name)
            ctx.alias(name, ann)


# --------------------------------------------------------------------------- #
# 渲染
# --------------------------------------------------------------------------- #
def render_alias(name: str, ann: str) -> str:
    """为改名属性生成 Field(alias=...) 声明行。"""
    return f"{name} = {ann}"


def render_classes(ctx: Ctx, root_cls: str, description: str, authoritative: bool) -> str:
    """按字段表渲染 pydantic 模型类代码块。"""
    lines: list[str] = []
    for cls, fields in ctx.classes:
        lines.append(f"class {cls}(BaseModel):")
        lines.append(f'    """{description}"""' if cls == root_cls and description
                     else f'    """契约对象 {cls}。"""')
        lines.append('    model_config = ConfigDict(extra="forbid", populate_by_name=True)')
        if not fields:
            lines.append("    pass")
        for fname, ann, kw, note in fields:
            if note:
                lines.append(f"    # vocabulary: {note}")
            lines.append(f"    {fname}: {ann} = Field({kw})" if kw else f"    {fname}: {ann}")
        if cls == root_cls and authoritative:
            lines.append(VALIDATOR_BLOCK.rstrip())
        lines.append("")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def gen_one(path: str) -> dict:
    """把单份 schema 编译为 pydantic 模型文本。"""
    doc = json.load(open(path, encoding="utf-8"))
    stem = os.path.basename(path)[: -len(".schema.json")]
    root_cls = camel(stem.split(".")[0])
    contract_id = doc["properties"]["schema_version"]["const"]

    ctx = Ctx(doc)
    emit_shared_defs(ctx)
    _emit_object(root_cls, doc, ctx, root_cls)

    authoritative = any(k in doc for k in COMPLEX_KEYWORDS)
    return {
        "root_cls": root_cls,
        "contract_id": contract_id,
        "body": render_classes(ctx, root_cls, str(doc.get("description", "")), authoritative),
        "authoritative": authoritative,
        "aliases": ctx.aliases,
        "classes": [c for c, _ in ctx.classes],
    }


def build(root: str) -> str:
    """编译全部 schema 为 models.py 全文（含头部声明与别名区）。"""
    cdir = os.path.join(root, CONTRACTS_DIR)
    files = sorted(f for f in os.listdir(cdir) if f.endswith(".schema.json"))
    if not files:
        raise SystemExit("no *.schema.json found")

    fp = hashlib.sha256()
    for f in files:
        fp.update(f.encode())
        with open(os.path.join(cdir, f), "rb") as fh:
            fp.update(fh.read())

    alias_pool: dict[str, str] = {}
    name_owner: dict[str, str] = {}
    bodies: list[str] = []
    names: list[str] = []
    auth: dict[str, str] = {}

    for f in files:
        res = gen_one(os.path.join(cdir, f))
        bodies.append(res["body"])
        names.append(res["root_cls"])
        if res["authoritative"]:
            auth[res["root_cls"]] = res["contract_id"]

        # 跨 schema 名称冲突检测：同名必须同体，否则报错而不是静默生成错的模型
        for n in res["classes"] + [a for a, _ in res["aliases"]]:
            if n in name_owner and name_owner[n] != res["root_cls"]:
                pass
            name_owner.setdefault(n, res["root_cls"])
        for a_name, a_ann in res["aliases"]:
            if a_name in alias_pool and alias_pool[a_name] != a_ann:
                raise SystemExit(
                    f"类型别名冲突：{a_name} 在两个 schema 中定义不同\n"
                    f"  已有：{alias_pool[a_name]}\n  新值：{a_ann}"
                )
            alias_pool[a_name] = a_ann

    aliases = [f"{n} = {a}" for n, a in sorted(alias_pool.items())]
    alias_names = sorted(alias_pool)

    auth_map_src = "\n".join(f'    "{k}": "{v}",' for k, v in sorted(auth.items())) or "    # 无"
    all_names = "\n".join(f'    "{n}",' for n in sorted(set(names) | set(alias_names)))
    head = HEADER.format(fingerprint=fp.hexdigest()[:16],
                         authoritative_map=auth_map_src, all_names=all_names)

    parts = [head, ""]
    if aliases:
        parts.append("# " + "-" * 72)
        parts.append("# $defs 标量别名（共享去重）")
        parts.append("# " + "-" * 72)
        parts.extend(aliases)
        parts.append("")
    parts.append("\n".join(bodies).rstrip())
    return "\n".join(parts) + "\n"


def main() -> int:
    """命令行入口：默认生成，--check 漂移校验。"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.root or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    text = build(root)
    out_path = os.path.join(root, OUT_DIR, OUT_FILE)

    if args.check:
        if not os.path.isfile(out_path):
            print(f"ERROR: 生成物不存在：{out_path}")
            return 1
        if open(out_path, encoding="utf-8").read() != text:
            print("ERROR: 生成物与 schema 不一致，请运行 python runtime/tools/gen_models.py")
            return 1
        print("OK: 生成物与 schema 一致")
        return 0

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(text)
    init_path = os.path.join(root, OUT_DIR, INIT_FILE)
    if not os.path.isfile(init_path):
        with open(init_path, "w", encoding="utf-8") as fh:
            fh.write('"""由 gen_models.py 生成的契约模型包，请勿手工编辑。"""\n')
        print(f"created  : {init_path}")
    print(f"generated: {out_path}  ({len(text)} bytes)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
