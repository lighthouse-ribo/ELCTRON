#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""生成库模块白名单清单（library-surface）。

对 web.pending 里的每个库模块，用 AST 提取**模块级公开函数与公开常量**，
生成 `runtime/contracts/library_surface.json`。只做声明，不做执行；
分发器（runtime/orchestrator/library_dispatch.py）按这份清单放行调用。

规则：
  * 只收 `plan` / `evidence` 组的 `library` 模块（hardware/excluded 永不进入）；
  * 函数：模块级 `def`，名字不以 `_` 开头；
  * 常量：模块级赋值，名字全大写且值为 JSON 可序列化标量/列表/字典；
  * `--check` 模式：清单与磁盘 AST 不一致时退出码 1（漂移门禁）。
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import sys

__all__ = ["SURFACE_VERSION", "build_manifest", "main"]

SURFACE_VERSION = "library-surface/v0.1"
MANIFEST_REL = os.path.join("runtime", "contracts", "library_surface.json")


def _package_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _pending_library_modules(root: str) -> dict[str, str]:
    """从工具注册表取 library 模块：{模块名: 相对路径}。"""
    sys.path.insert(0, root)
    from runtime.orchestrator import registry as R  # noqa: WPS433

    on_disk = R.classify_on_disk(root)
    out: dict[str, str] = {}
    for spec in R.TOOL_REGISTRY:
        if spec.kind != "library" or spec.group not in ("plan", "evidence"):
            continue
        rel = next((p for p, k in on_disk.items()
                    if os.path.basename(p) == spec.name + ".py"), None)
        if rel is None:
            raise RuntimeError(f"注册表里的库模块在磁盘上找不到：{spec.name}")
        out[spec.name] = rel
    return out


def _is_literalish(node: ast.AST) -> bool:
    """字面量，或 frozenset/set/tuple/dict/sorted 包着字面量（常见词汇表定义式）。"""
    try:
        ast.literal_eval(node)
        return True
    except (ValueError, SyntaxError):
        pass
    if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
            and node.func.id in ("frozenset", "set", "tuple", "dict", "sorted")
            and all(_is_literalish(a) for a in node.args)):
        return True
    return False


def _module_surface(rel_path: str) -> dict:
    full = os.path.join(_package_root(), rel_path)
    src = open(full, encoding="utf-8", errors="strict").read()
    tree = ast.parse(src)
    top = list(tree.body)

    functions: list[str] = []
    for node in top:
        if isinstance(node, ast.FunctionDef) and not node.name.startswith("_"):
            functions.append(node.name)

    constants: list[str] = []
    for node in top:
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if not (isinstance(target, ast.Name) and target.id.isupper()
                    and not target.id.startswith("_")):
                continue
            if not _is_literalish(node.value):
                continue          # 非字面量常量不收（运行时对象交给函数返回）
            constants.append(target.id)

    doc = (ast.get_docstring(tree) or "").strip().splitlines()
    return {
        "path": rel_path.replace("\\", "/"),
        "doc": doc[0][:120] if doc else "",
        "functions": sorted(functions),
        "constants": sorted(constants),
    }


def build_manifest(root: str) -> dict:
    """从注册表与 AST 构建库模块白名单清单。"""
    modules = {name: _module_surface(rel)
               for name, rel in sorted(_pending_library_modules(root).items())}
    empty = [n for n, m in modules.items() if not m["functions"] and not m["constants"]]
    return {
        "surface_version": SURFACE_VERSION,
        "note": "库模块白名单：仅列出的函数/常量可经 library_dispatch 调用；"
                "hardware/excluded 组永不进入。由 gen_library_surface.py 生成。",
        "modules": modules,
        "empty_modules": sorted(empty),
    }


def main() -> int:
    """命令行入口：默认生成，--check 漂移校验。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=_package_root())
    parser.add_argument("--check", action="store_true", help="漂移检查：不一致退出码 1")
    args = parser.parse_args()

    manifest = build_manifest(args.root)
    manifest_path = os.path.join(args.root, MANIFEST_REL)

    if args.check:
        if not os.path.isfile(manifest_path):
            print("缺少库模块清单：请先运行 gen_library_surface.py 生成", file=sys.stderr)
            return 1
        on_disk = json.load(open(manifest_path, encoding="utf-8"))
        if on_disk != manifest:
            print("库模块清单与磁盘 API 不一致：请重新生成 gen_library_surface.py",
                  file=sys.stderr)
            return 1
        print(f"[PASS] 库模块清单与磁盘一致（{len(manifest['modules'])} 模块）")
        return 0

    os.makedirs(os.path.dirname(manifest_path), exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")
    n_funcs = sum(len(m["functions"]) for m in manifest["modules"].values())
    print(f"已生成 {MANIFEST_REL}：{len(manifest['modules'])} 模块，"
          f"{n_funcs} 个函数，空模块 {len(manifest['empty_modules'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
