#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""工具面覆盖度门禁。

检查三件事，任一项不过即退出码 1：

1. **注册表与磁盘事实一致** —— 缺失脚本、重复条目、`cli`/`library` 声明与实际入口不符；
2. **无未登记脚本** —— `skills/` 下每个非测试 `.py` 都必须在注册表里有归属
   （这是"棘轮"：新增脚本不登记就会红）；
3. **硬件工具不下发 Web 层** —— `web_surface()` 里不得出现 `hardware` 组条目。

用法：

    python runtime/tools/check_tool_coverage.py                 # 门禁，只打印摘要
    python runtime/tools/check_tool_coverage.py --report <路径>  # 同时写出完整报告
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))                 # runtime/tools
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.orchestrator import mcp_surface as S                 # noqa: E402
from runtime.orchestrator import registry as R                    # noqa: E402


def build_report(root: str) -> tuple[list[str], list[str]]:
    """构建注册表↔磁盘一致性与 Web 隔离报告。"""
    lines: list[str] = []
    problems = R.verify_registry(root)
    on_disk = R.classify_on_disk(root)

    lines.append("# 工具面覆盖度报告")
    lines.append("")
    lines.append(f"生成时间：{datetime.now():%Y-%m-%d %H:%M}")
    lines.append(f"包根：{root}")
    lines.append("")

    # --- 第 3 项：硬件不下发 ---
    ws = R.web_surface()
    leaked = [s.name for s in ws if s.is_hardware]
    if leaked:
        problems.append(f"Web 层工具面混入硬件工具（红线）：{leaked}")

    # --- 第 4 项：MCP 工具面三组拆分的不变量 ---
    surface = S.build_surface()
    problems.extend(S.check_surface(surface))

    manifest = os.path.join(root, "runtime", "dist", "web_tool_surface.json")
    problems.extend(S.verify_manifest(manifest))

    # --- 计数 ---
    by_group = Counter(s.group for s in R.TOOL_REGISTRY)
    by_kind = Counter(s.kind for s in R.TOOL_REGISTRY)

    lines.append("## 一、总览")
    lines.append("")
    lines.append(f"| 项 | 数 |")
    lines.append("|---|---|")
    lines.append(f"| 注册表条目 | {len(R.TOOL_REGISTRY)} |")
    lines.append(f"| 磁盘非测试脚本 | {len(on_disk)} |")
    lines.append(f"| 可作为 CLI 调用 | {by_kind.get(R.CLI, 0)} |")
    lines.append(f"| 仅可作为库调用 | {by_kind.get(R.LIBRARY, 0)} |")
    lines.append(f"| Web 层可下发 | {len(ws)} |")
    lines.append(f"| 硬件组（不下发） | {by_group.get(R.HARDWARE, 0)} |")
    lines.append("")

    lines.append("## 二、按能力面分组")
    lines.append("")
    lines.append("| 组 | 含义 | 数量 | 可下发 Web 层 |")
    lines.append("|---|---|---|---|")
    for g, meaning, exposed in (
        (R.PLAN, "解析 / 设计 / 静态门禁（只读）", "是"),
        (R.EVIDENCE, "证据解析与报告（只读）", "是"),
        (R.HARDWARE, "接触设备或只服务硬件执行流程", "**否**"),
        (R.EXCLUDED, "自检与测试", "否"),
    ):
        lines.append(f"| `{g}` | {meaning} | {by_group.get(g, 0)} | {exposed} |")
    lines.append("")

    lines.append("## 三、按图节点分布")
    lines.append("")
    lines.append("| 节点 | 工具数 | 其中可 CLI 调用 |")
    lines.append("|---|---|---|")
    for node in ("route_and_mount_reference", "inspect_inputs", "generate_or_design",
                 "static_gate", "hardware_gate_and_execute"):
        items = R.tools_for_node(node)
        lines.append(f"| `{node}` | {len(items)} | {sum(1 for s in items if s.kind == R.CLI)} |")
    lines.append("")

    lines.append("## 四、实测发现的关键缺陷（本轮修复）")
    lines.append("")
    lines.append("`review_truth.py`（400 行）与 `project_artifact_binding.py`（174 行）")
    lines.append("**没有 `__main__` 入口**，以 CLI 方式调用得到「退出码 0 + stdout 为空」。")
    lines.append("旧 `static_gate_from_exit(0)` 把它映射成 **PASS**，于是静态门禁的这两条规则")
    lines.append("**从未真正执行过，却每次返回通过**。")
    lines.append("")
    lines.append("本轮的修法不是给它们补 `__main__`（那会改动能力层），而是：")
    lines.append("")
    lines.append("1. `run_cli` 调用前断言脚本确实可作为 CLI 运行，否则抛 `CliToolError`；")
    lines.append("2. `available_tools()` 语义从「文件存在」改为「可 CLI 调用」，库模块返回 False；")
    lines.append("3. 注册表把 `kind` 变成显式声明，声明与入口不符即报错。")
    lines.append("")

    lines.append("## 五、MCP 工具面三组拆分（T5.5）")
    lines.append("")
    lines.append("| 工具面 | 工具数 | 下发 Web 层 |")
    lines.append("|---|---|---|")
    for g in surface["groups"]:
        lines.append(f"| `{g['id']}` | {g['tool_count']} | "
                     f"{'是' if g['expose_to_web'] else '**否**'} |")
    lines.append("")
    web = surface["web"]
    lines.append(f"* `allowedTools`（可直接喂给 CodeBuddy SDK）：**{web['serviceable_count']}** 个")
    lines.append(f"* 库模块待包装（进 pending、不进 allowedTools）：{len(web['pending'])} 个")
    lines.append(f"* 不下发的组：`{', '.join(web['excluded_groups'])}`")
    lines.append(f"* 清单指纹：`{surface['fingerprint'][:16]}…`")
    lines.append("")
    hw = set(S.hardware_tool_ids(surface))
    allowed = set(web["allowedTools"])
    lines.append(f"* **allowedTools 与硬件工具交集：{sorted(allowed & hw) or '空（正确）'}**")
    lines.append("")
    lines.append("## 六、仅可作为库调用的模块（不能按 CLI 调）")
    lines.append("")
    lines.append("| 脚本 | 组 | 用途 |")
    lines.append("|---|---|---|")
    for s in sorted(R.library_tools(), key=lambda x: x.name):
        lines.append(f"| `{s.name}.py` | `{s.group}` | {s.purpose} |")
    lines.append("")

    lines.append("## 七、检查结果")
    lines.append("")
    if problems:
        lines.append(f"**未通过，{len(problems)} 项问题：**")
        lines.append("")
        for p in problems:
            lines.append(f"- {p}")
    else:
        lines.append("**全部通过**：注册表与磁盘事实一致、无未登记脚本、硬件工具零下发。")
    lines.append("")
    return lines, problems


def main(argv: list[str]) -> int:
    """命令行入口：--report 写文件，--quiet 只给结论。"""
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=PKG_ROOT)
    ap.add_argument("--report", default="", help="写出完整报告到该路径")
    ap.add_argument("--quiet", action="store_true", help="只打印一行结论")
    args = ap.parse_args(argv)

    lines, problems = build_report(args.root)

    if args.report:
        os.makedirs(os.path.dirname(os.path.abspath(args.report)), exist_ok=True)
        with open(args.report, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("\n".join(lines) + "\n")
        print(f"报告已写出：{args.report}")

    if args.quiet:
        print(f"tool-coverage: {'FAIL' if problems else 'PASS'} ({len(problems)} 问题)")
    else:
        print(f"注册项 {len(R.TOOL_REGISTRY)} ｜ 可 CLI {len(R.cli_tools())} ｜ "
              f"仅库 {len(R.library_tools())} ｜ Web 可下发 {len(R.web_surface())}")
        print(f"问题数：{len(problems)}")
        for p in problems:
            print(f"   * {p}")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
