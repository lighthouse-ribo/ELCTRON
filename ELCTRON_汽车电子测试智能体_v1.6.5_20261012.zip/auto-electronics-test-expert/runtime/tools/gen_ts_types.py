#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""T1.3 由契约生成 TypeScript + zod 类型（供 P5 Web 层复用）。

为什么由生成而不是手写
----------------------
契约（`runtime/contracts/*.schema.json`）是结构与词汇的**唯一来源**。
手写第二份 TS 类型必然漂移，而漂移的类型比没有类型更危险：它会让前端
「看起来校验过了」，实际和后端不是一套规则。

本生成器与 `gen_models.py` 是**同一批输入、两种目标语言**：

    runtime/contracts/*.schema.json ─┬─> runtime/contracts/generated/models.py      (pydantic v2)
    runtime/contracts/enums.json    ─┴─> runtime/contracts/generated/schema_types.ts (zod 4)

同时产出一份 `schema_examples.json`，供 node 侧把每个 schema 的 examples
真实跑一遍 `safeParse` —— 让「TS 类型对不对」变成可执行断言，而不是靠肉眼。

不支持的构造
------------
`allOf` / `anyOf` / `not` / `if` 一律**不猜**：产出 `z.unknown()`。
`oneOf` 仅支持互斥常量联合：标量 `const`，或带共同必填 const 判别字段的对象。
并在文件里留 `UNSUPPORTED` 标记、在 stdout 汇总。测试会断言当前契约集里
这类标记为 0（棘轮：新增复杂契约会让测试红，逼人先想清楚怎么表达）。

用法
----
    python runtime/tools/gen_ts_types.py            # 生成
    python runtime/tools/gen_ts_types.py --check    # 只比对，不写盘（漂移门禁）
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

CONTRACTS_DIR = "runtime/contracts"
OUT_DIR = "runtime/contracts/generated"
OUT_TS = "schema_types.ts"
OUT_EXAMPLES = "schema_examples.json"
SCHEMA_SUFFIX = ".schema.json"
COMPLEX_KEYWORDS = ("allOf", "anyOf", "not", "if", "patternProperties")

HEADER = '''/* eslint-disable */
/**
 * 自动生成，请勿手工编辑。
 *
 * 来源：runtime/contracts/*.schema.json + runtime/contracts/enums.json
 * 生成器：runtime/tools/gen_ts_types.py
 * 目标：zod 4（已验证 z.strictObject / z.iso.datetime / z.enum 可用）
 *
 * 修改契约请改 schema 后重跑生成器；直接改本文件会在漂移门禁里失败。
 */

import { z } from "zod";
'''

_vocab_warn: list[str] = []
_unsupported: list[str] = []


def camel(name: str) -> str:
    """snake / kebab / 点分 → UpperCamel。"""
    parts = re.split(r"[^0-9A-Za-z]+", name)
    return "".join(p[:1].upper() + p[1:] for p in parts if p)


def ts_str(value: str) -> str:
    """JSON Schema 字符串约束 → zod 链式表达式（regex/min/ literal）。"""
    return json.dumps(value, ensure_ascii=False)


def ts_array(values) -> str:
    """数组类型 → z.array(...) 表达式。"""
    return "[" + ", ".join(ts_str(v) if isinstance(v, str) else json.dumps(v)
                           for v in values) + "]"


class Ctx:
    def __init__(self, doc: dict, owner: str):
        self.doc = doc
        self.owner = owner
        self.defs: dict[str, str] = {}          # $def name -> TS 表达式
        self.blocks: list[str] = []             # 需要额外输出的对象常量
        self.emitted: set[str] = set()

    def unique(self, name: str) -> str:
        candidate, i = name, 2
        while candidate in self.emitted:
            candidate, i = f"{name}{i}", i + 1
        self.emitted.add(candidate)
        return candidate


def _regex_expr(pattern: str) -> str:
    """用 new RegExp(字符串) 而非正则字面量，避免 / 与转义差异。"""
    return f"z.string().regex(new RegExp({ts_str(pattern)}))"


def expr_for(node: dict, ctx: Ctx, prefix: str) -> str:
    """JSON Schema 片段 → zod 表达式。"""
    if not isinstance(node, dict):
        return "z.unknown()"

    if "oneOf" in node:
        variants = node.get("oneOf")
        if not isinstance(variants, list) or not variants:
            _unsupported.append(f"{ctx.owner}:{prefix}:oneOf:invalid variants")
            return "z.unknown() /* UNSUPPORTED: oneOf */"
        discriminants: list[tuple[str, str]] = []
        mode = ""
        for variant in variants:
            if not isinstance(variant, dict):
                discriminants = []
                break
            if "const" in variant:
                current_mode = "const"
                key, value = "$const", variant["const"]
            elif variant.get("type") == "object" and isinstance(variant.get("properties"), dict):
                required = set(variant.get("required") or [])
                tags = [(name, prop["const"]) for name, prop in variant["properties"].items()
                        if name in required and isinstance(prop, dict) and "const" in prop]
                if len(tags) != 1:
                    discriminants = []
                    break
                current_mode = "object"
                key, value = tags[0]
            else:
                discriminants = []
                break
            if mode and current_mode != mode:
                discriminants = []
                break
            mode = current_mode
            signature = (key, json.dumps(value, ensure_ascii=False, sort_keys=True))
            if signature in discriminants:
                discriminants = []
                break
            discriminants.append(signature)
        if (not discriminants or len(discriminants) != len(variants)
                or (mode == "object" and len({key for key, _ in discriminants}) != 1)):
            _unsupported.append(f"{ctx.owner}:{prefix}:oneOf:non-disjoint variants")
            return "z.unknown() /* UNSUPPORTED: oneOf */"
        parts = [expr_for(variant, ctx, f"{prefix}:oneOf[{index}]")
                 for index, variant in enumerate(variants)]
        return "z.union([" + ", ".join(parts) + "])"

    for kw in COMPLEX_KEYWORDS:
        if kw in node:
            _unsupported.append(f"{ctx.owner}:{prefix}:{kw}")
            return "z.unknown() /* UNSUPPORTED: " + kw + " */"

    if "$ref" in node:
        ref = str(node["$ref"])
        name = ref.rsplit("/", 1)[-1]
        if name not in ctx.defs:
            _unsupported.append(f"{ctx.owner}:{prefix}:dangling $ref {ref}")
            return "z.unknown() /* UNSUPPORTED: dangling $ref */"
        return ctx.defs[name]

    if "const" in node:
        return f"z.literal({json.dumps(node['const'], ensure_ascii=False)})"

    if "enum" in node:
        vocab = node.get("x-enum-vocabulary")
        values = node["enum"]
        if vocab:
            _vocab_warn.append(str(vocab))
            return f"{camel(str(vocab))}Enum"
        return f"z.enum({ts_array(values)})"

    t = node.get("type")

    if isinstance(t, list):
        # 可空/联合类型：JSON Schema 允许 type 是数组。实测契约里有 7 处
        # `["string", "null"]` —— 用 z.unknown() 兜底等于把类型丢掉，必须真表达。
        non_null = [x for x in t if x != "null"]
        base = {k: v for k, v in node.items()
                if k not in ("type", "x-enum-vocabulary", "description")}
        if not non_null:
            return "z.null()"
        parts = [expr_for({**base, "type": x}, ctx, prefix) for x in non_null]
        inner = parts[0] if len(parts) == 1 else "z.union([" + ", ".join(parts) + "])"
        return inner + ".nullable()" if "null" in t else inner

    if t == "string":
        if "pattern" in node:
            out = _regex_expr(str(node["pattern"]))
        elif node.get("format") == "date-time":
            out = "z.iso.datetime()"
        else:
            out = "z.string()"
        if "minLength" in node:
            out += f".min({int(node['minLength'])})"
        if "maxLength" in node:
            out += f".max({int(node['maxLength'])})"
        return out

    if t == "integer":
        out = "z.int()"
        if "minimum" in node:
            out += f".min({int(node['minimum'])})"
        if "maximum" in node:
            out += f".max({int(node['maximum'])})"
        return out
    if t == "number":
        return "z.number()"
    if t == "boolean":
        return "z.boolean()"
    if t == "null":
        return "z.null()"

    if t == "array":
        items = node.get("items")
        inner = expr_for(items, ctx, prefix + "[]") if isinstance(items, dict) else "z.unknown()"
        out = f"z.array({inner})"
        if "minItems" in node:
            out += f".min({int(node['minItems'])})"
        if "maxItems" in node:
            out += f".max({int(node['maxItems'])})"
        return out

    if t == "object":
        return _emit_object(node, ctx, prefix)

    if t is None:
        # 不带 type 的裸对象也可能出现
        if "properties" in node:
            return _emit_object(node, ctx, prefix)
        return "z.unknown()"

    _unsupported.append(f"{ctx.owner}:{prefix}:type={t}")
    return "z.unknown() /* UNSUPPORTED: type */"


def _emit_object(node: dict, ctx: Ctx, prefix: str) -> str:
    props: dict = node.get("properties") or {}
    required = set(node.get("required") or [])
    strict = node.get("additionalProperties") is False
    child_prefix = f"{prefix}_" if prefix else ""
    fields: list[str] = []
    for pname, pnode in props.items():
        inner = expr_for(pnode, ctx, child_prefix + pname)
        ann = inner + ("" if pname in required else ".optional()")
        desc = (pnode or {}).get("description")
        if desc:
            safe = str(desc).replace("*/", "* /").replace("\n", " ")
            fields.append(f"  /** {safe} */")
        fields.append(f"  {ts_key(pname)}: {ann},")
    body = "\n".join(fields) if fields else ""
    ctor = "z.strictObject" if strict else "z.object"
    return f"{ctor}({{\n{body}\n}})"


_TS_IDENT = re.compile(r"^[A-Za-z_$][A-Za-z0-9_$]*$")


def ts_key(name: str) -> str:
    """TS 对象键：合法标识符直接用，否则加引号。

    注意 `from` 这类词在 TS 里**是合法属性名**（不需要像 Python 那样改写），
    所以这里保持原样，保证与 JSON 侧字段名一致。
    """
    return name if _TS_IDENT.match(name) else ts_str(name)


def collect_defs(doc: dict, ctx: Ctx) -> None:
    """先登记 $defs：标量 → 别名；对象 → 独立常量。"""
    defs = doc.get("$defs") or {}
    for name, node in defs.items():
        node = node or {}
        is_object = node.get("type") == "object" or "properties" in node
        if is_object:
            cls = camel(name) + "Schema"
            ctx.defs[name] = cls
            ctx.blocks.append(f"export const {cls} = {_emit_object(node, ctx, name)};\n")
        else:
            alias = camel(name)
            body = expr_for(node, ctx, name)
            ctx.defs[name] = alias
            ctx.blocks.append(f"export const {alias} = {body};\n")


def gen_one(path: str) -> dict:
    """把单份 schema 编译为 TS/zod 声明文本。"""
    with open(path, encoding="utf-8") as fh:
        doc = json.load(fh)
    contract_id = (doc.get("properties", {}).get("schema_version", {}) or {}).get("const")
    title = doc.get("title") or camel(os.path.basename(path)[: -len(SCHEMA_SUFFIX)])
    return {"path": path, "doc": doc, "contract_id": contract_id, "title": title}


def build(root: str) -> tuple[str, dict]:
    """把全部契约 schema 编译为 TS/zod 模块文本与样例负载。"""
    global _vocab_warn, _unsupported
    _vocab_warn, _unsupported = [], []

    cdir = os.path.join(root, *CONTRACTS_DIR.split("/"))
    schemas = sorted(f for f in os.listdir(cdir) if f.endswith(SCHEMA_SUFFIX))
    if not schemas:
        raise SystemExit(f"未找到任何契约：{cdir}")

    with open(os.path.join(cdir, "enums.json"), encoding="utf-8") as fh:
        enums = json.load(fh)

    out: list[str] = [HEADER]
    contracts_payload: dict[str, dict] = {}
    contract_map: list[tuple[str, str]] = []
    seen_names: dict[str, str] = {}

    # ---- 词汇表 ----
    out.append("/* ---------- 词汇表（真源见 enums.json 的 source_of_truth）---------- */\n")
    for vname, entry in sorted(enums["vocabularies"].items()):
        cn = camel(vname)
        out.append(f"/** 真源：{entry.get('source_of_truth', '?')} */")
        out.append(f"export const {cn}Values = {ts_array(entry['values'])} as const;")
        out.append(f"export const {cn}Enum = z.enum({cn}Values);\n")

    # ---- 共享 $defs ----
    out.append("/* ---------- 共享类型定义 ---------- */\n")
    def_blocks: list[str] = []
    for fname in schemas:
        info = gen_one(os.path.join(cdir, fname))
        ctx = Ctx(info["doc"], info["title"])
        collect_defs(info["doc"], ctx)
        def_blocks.extend(ctx.blocks)

    seen_block: set[str] = set()
    for blk in def_blocks:
        head = blk.split(" = ", 1)[0]
        if head in seen_block:
            continue
        seen_block.add(head)
        out.append(blk)

    # ---- 各契约 ----
    out.append("/* ---------- 契约 ---------- */\n")
    for fname in schemas:
        info = gen_one(os.path.join(cdir, fname))
        title = info["title"]
        cls = camel(title) + "Schema"
        if title in seen_names:
            raise SystemExit(f"契约 title 重复：{title}（{fname} 与 {seen_names[title]}）")
        seen_names[title] = fname

        ctx = Ctx(info["doc"], title)
        collect_defs(info["doc"], ctx)
        body = _emit_object(info["doc"], ctx, "")
        out.append(f"/** {info['doc'].get('description', '')} */")
        out.append(f"export const {cls} = {body};")
        out.append(f"export type {camel(title)} = z.infer<typeof {cls}>;\n")

        if info["contract_id"]:
            contract_map.append((info["contract_id"], cls))
        # 样例与必填清单一并产出：node 侧要按**真必填项**做负向断言，
        # 不能靠「样例的第一个键」猜（json 的 sort_keys 会把键重排）。
        contracts_payload[info["contract_id"] or title] = {
            "title": title,
            "required": sorted(info["doc"].get("required") or []),
            "properties": sorted((info["doc"].get("properties") or {}).keys()),
            "examples": info["doc"].get("examples") or [],
        }

    # ---- 按契约 id 索引（与 validation.py 的口径一致）----
    out.append("/* ---------- 按 schema_version 常量索引 ---------- */\n")
    out.append("/** 与 runtime/contracts/validation.py 同一口径：契约 id = schema_version 常量。 */")
    out.append("export const contractSchemas = {")
    for cid, cls in sorted(contract_map):
        out.append(f"  {ts_str(cid)}: {cls},")
    out.append("} as const;\n")
    out.append("export type ContractId = keyof typeof contractSchemas;\n")

    ts = "\n".join(out).rstrip() + "\n"
    payload = {
        "source": CONTRACTS_DIR,
        "contract_count": len(schemas),
        "contracts": contracts_payload,
        "unsupported": _unsupported,
    }
    return ts, payload


def main() -> int:
    """命令行入口：默认生成，--check 漂移校验。"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))))
    ap.add_argument("--check", action="store_true", help="只比对，不写盘")
    args = ap.parse_args()

    ts, payload = build(args.root)
    outdir = os.path.join(args.root, *OUT_DIR.split("/"))
    ts_path = os.path.join(outdir, OUT_TS)
    ex_path = os.path.join(outdir, OUT_EXAMPLES)

    if payload["unsupported"]:
        print("不支持的构造（z.unknown 兜底，需处理）：")
        for u in payload["unsupported"]:
            print("   *", u)

    if args.check:
        current = ""
        if os.path.isfile(ts_path):
            with open(ts_path, encoding="utf-8") as fh:
                current = fh.read()
        if current != ts:
            print("TS 类型已漂移：请重跑 gen_ts_types.py")
            return 1
        print(f"TS 类型无漂移（{len(ts)} 字节，{payload['contract_count']} 份契约）")
        return 0

    os.makedirs(outdir, exist_ok=True)
    with open(ts_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(ts)
    with open(ex_path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")
    print(f"已生成 {ts_path}（{len(ts)} 字节）")
    print(f"已生成 {ex_path}（{payload['contract_count']} 份契约样例）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
