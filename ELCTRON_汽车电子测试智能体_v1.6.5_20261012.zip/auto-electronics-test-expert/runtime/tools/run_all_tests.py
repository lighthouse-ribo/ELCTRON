#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P1 统一测试入口：包级能力层回归 + runtime 层测试，一次跑完。

为什么不直接改 `skills/uds-diagnostic-test/scripts/run_tests.py`：
能力层（A–I 九层）在本阶段只增不改，改造侧的门禁应作为**外层包装**，
而不是往既有收口脚本里塞新逻辑。

顺序：
  1. 能力层回归 `run_tests.py`（完全不改动它，原样调用）
  2. 契约漂移检查 `gen_models.py --check`
  3. runtime 单元测试 `unittest discover -s runtime/tests`

用法:
  python runtime/tools/run_all_tests.py              # 全跑
  python runtime/tools/run_all_tests.py --fast       # 跳过能力层回归（改 runtime 时用）
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))

LEGACY_RUNNER = os.path.join(PKG_ROOT, "skills", "uds-diagnostic-test", "scripts", "run_tests.py")
GEN_MODELS = os.path.join(PKG_ROOT, "runtime", "tools", "gen_models.py")
CONTRACTS_TOOL = os.path.join(PKG_ROOT, "runtime", "tools", "validate_contracts.py")
COVERAGE_TOOL = os.path.join(PKG_ROOT, "runtime", "tools", "check_tool_coverage.py")
LIB_SURFACE_GEN = os.path.join(PKG_ROOT, "runtime", "tools", "gen_library_surface.py")
TS_GEN = os.path.join(PKG_ROOT, "runtime", "tools", "gen_ts_types.py")


def _env() -> dict:
    return dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def step(title: str, argv: list[str], cwd: str = PKG_ROOT) -> bool:
    """执行一个门禁阶段：打印标题与退出码，返回是否成功。"""
    print(f"\n=== {title} ===")
    print("$ " + " ".join(argv[1:]))
    t0 = time.time()
    proc = subprocess.run(argv, cwd=cwd, env=_env(), capture_output=True,
                          text=True, encoding="utf-8", errors="replace")
    tail = [ln for ln in proc.stdout.splitlines() if ln.strip()][-6:]
    for ln in tail:
        print("  " + ln)
    if proc.returncode != 0 and proc.stderr.strip():
        print("  [stderr] " + proc.stderr.strip()[:400])
    print(f"  -> 退出码 {proc.returncode}（{time.time() - t0:.1f}s）")
    return proc.returncode == 0


def main() -> int:
    """命令行入口：--fast 跳过能力层全量回归。"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--fast", action="store_true", help="跳过能力层全量回归")
    args = ap.parse_args()

    results: list[tuple[str, bool]] = []

    if not args.fast:
        results.append(("能力层回归（49 项）", step(
            "能力层回归：skills/*/scripts/test_*.py",
            [sys.executable, LEGACY_RUNNER],
            cwd=os.path.join(PKG_ROOT, "skills", "uds-diagnostic-test", "scripts"),
        )))

    results.append(("契约校验", step("契约校验：Schema + 样本 + 词汇表漂移",
                                     [sys.executable, CONTRACTS_TOOL])))
    results.append(("模型漂移检查", step("模型漂移检查：生成物是否与 schema 一致",
                                     [sys.executable, GEN_MODELS, "--root", PKG_ROOT, "--check"])))
    results.append(("TS 类型漂移检查", step(
        "TS 类型漂移检查：zod 生成物是否与 schema 一致",
        [sys.executable, TS_GEN, "--root", PKG_ROOT, "--check"])))
    results.append(("工具面覆盖度", step(
        "工具面覆盖度：注册表↔磁盘一致 + 硬件不下发 Web 层",
        [sys.executable, COVERAGE_TOOL, "--quiet"])))
    results.append(("库模块清单漂移", step(
        "库模块清单漂移：library-surface 与磁盘 API 一致",
        [sys.executable, LIB_SURFACE_GEN, "--check"])))
    results.append(("runtime 单元测试", step("runtime 单元测试",
                                          [sys.executable, "-m", "unittest", "discover",
                                           "-s", "runtime/tests"])))

    print("\n" + "=" * 60)
    for name, ok in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {name}")
    failed = [n for n, ok in results if not ok]
    print("=" * 60)
    print("结果：" + ("全部通过" if not failed else f"{len(failed)} 项失败 -> {failed}"))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
