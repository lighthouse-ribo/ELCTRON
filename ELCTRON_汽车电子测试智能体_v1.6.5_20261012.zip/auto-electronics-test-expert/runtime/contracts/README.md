# runtime/contracts —— T1.1 契约单一来源

本目录是受控运行时的**唯一契约来源**。Python（orchestrator / executor / evidence）
与 TypeScript（Web 层）都必须消费这里的定义，不得各自另写一份。

版本：`v0.1` ｜ 校验：`python runtime/tools/validate_contracts.py`

---

## 1 九份契约

| 契约 | 文件 | 关键约束 |
|---|---|---|
| TaskState | `task_state.v0.1.schema.json` | 八状态线性主链；`state_writer` 恒为 `terra`；`history` 只追加；`final_verdict` 仅 CLOSED 可写 |
| NodeResult | `node_result.v0.1.schema.json` | 五主节点；`writes_to` 受单写者矩阵约束；`gate_status` 仅门禁节点可产出 |
| GateRecord | `gate_record.v0.1.schema.json` | `decided_by` 只能是 `code` 或 `human`；`checked_artifacts` 为空不得判 PASS |
| ApprovedOrder | `approved_order.v0.1.schema.json` | 令牌只存引用不存原文；`reversible=false` 时必须人工授权；`valid_until` 过期即失效 |
| TaskPacket | `task_packet.v0.1.schema.json` | `allowed_actions` 白名单，未列出即禁止；`required_evidence` 缺一项即不可判完成 |
| RunManifest | `run_manifest.v0.1.schema.json` | 运行后只追加；`channel_lease` 保证通道独占；`minimal_retest` 非 PASS 不得进全量 |
| EvidenceIndex | `evidence_index.v0.1.schema.json` | `missing` 非空 → 强制 `complete=false`（allOf 约束）；`immutable` 恒为 true |
| VerdictDraft | `verdict_draft.v0.1.schema.json` | `final` 恒为 `false`，草案不等于最终结论 |
| MemoryCandidate | `memory_candidate.v0.1.schema.json` | `contains_secret_material` 恒为 false；`scope=project` 只能留项目包 |

每份契约都内嵌 `examples`，校验器逐条验证。**没有样本的契约视为未完成。**

---

## 2 词汇表注册表 `enums.json`

三原则：

1. **既有词汇表的真源是 Python 常量**，不是本目录。注册表只登记「哪个词汇表归谁管」。
2. **禁止在 schema 中重新定义既有词汇表**，只能引用。
3. 运行时新增词汇表同样**必须先有代码真源**（`runtime/orchestrator/state.py` 里的 Enum），
   再由本文件登记指向。**不允许存在只在 JSON 里写、没有代码真源的词汇表** ——
   自 T1.4 起，全部 16 个词汇表均为 `status: existing`，没有 `new` 遗留。

| 词汇表 | 真源 | 状态 |
|---|---|---|
| `flow_kind` | `skills/uds-diagnostic-test/scripts/flow_contract.py :: FlowKind` | existing |
| `case_verdict` | `.../result_contract.py :: VALID_VERDICTS` | existing |
| `failure_class` | `.../result_contract.py :: FAILURE_CLASSES` | existing |
| `gate_decision` | `.../uds_case_gate.py :: DECISIONS` | existing |
| `finding_severity` | `.../uds_case_gate.py :: SEVERITIES` | existing |
| `fact_status` | `schemas/portable-contract-v0.1.json :: context.statuses` | existing |
| `task_state` | `runtime/orchestrator/state.py :: TaskState` | existing |
| `gate_status` | `runtime/orchestrator/state.py :: GateStatus` | existing |
| `node_status` | `runtime/orchestrator/state.py :: NodeStatus` | existing |
| `run_final_verdict` | `runtime/orchestrator/state.py :: RunFinalVerdict` | existing |
| `risk_level` | `runtime/orchestrator/state.py :: RiskLevel` | existing |
| `evidence_kind` | `runtime/orchestrator/state.py :: EvidenceKind` | existing |
| `memory_kind` | `runtime/orchestrator/state.py :: MemoryKind` | existing |
| `approval_status` | `runtime/orchestrator/state.py :: ApprovalStatus` | existing |
| `agent_role` | `runtime/orchestrator/state.py :: AgentRole` | existing |
| `graph_node` | `runtime/orchestrator/state.py :: GraphNode` | existing |

`gate_decision` 与 `fact_status` 已注册但本轮未被 schema 引用，属既有词汇表，
将在 T2.4 静态门禁节点接入时消费。

---

## 3 三处语义调和（必须遵守，否则两套词汇会打架）

### 3.1 `gate_status` ≠ `gate_decision`

| | 语义 | 取值 | 产出者 |
|---|---|---|---|
| `gate_decision` | 用例**设计**决策 | GENERATE / NEGATIVE / BLOCKED / REVIEW_REQUIRED / REJECT | `uds_case_gate` |
| `gate_status` | 编排**门禁**结论（条件边唯一可读） | PASS / REVIEW_REQUIRED / ERROR / BLOCKED / ABORTED / INCONCLUSIVE | 确定性代码 / 人工 |

两者不得互相替代。条件边只读 `gate_status`，且必须由代码产出。

### 3.2 单条用例级没有 `INCONCLUSIVE`

现有 `case_verdict` 是 `PASS / FAIL / BLOCKED / NA / SKIP`，**不新增 INCONCLUSIVE**。
`INCONCLUSIVE` 是 run 级结论，落在 `task_state.final_verdict`（`PASS / FAIL / INCONCLUSIVE`）。

### 3.3 `BLOCKED` 与 `INCONCLUSIVE` 必须区分

| 状态 | 含义 |
|---|---|
| `BLOCKED` | 前置条件未满足，**从未执行**（如缺客户授权的 `$27` 密钥、缺刷写流程图） |
| `INCONCLUSIVE` | 已执行，但**证据不足**（如 ASC 未建立、缺失原始响应） |

不得把 `BLOCKED` 当作脚本错误的替身，也不得把 `INCONCLUSIVE` 降级为 PASS。

---

## 4 用法

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"

# 校验全部契约（Schema 自检 + 样本校验 + 词汇表漂移）
"$PY" runtime/tools/validate_contracts.py

# 回归测试（含 5 个「门禁必须能失败」的负向用例）
"$PY" -m unittest discover -s runtime/tests
```

退出码：`0` 通过 ｜ `1` 存在错误 ｜ `2` 环境或路径问题。

---

## 5 校验器实际检查什么

| # | 检查 | 不过的后果 |
|---|---|---|
| 1 | dialect 必须为 2020-12；`$id` 唯一 | 报 ERROR |
| 2 | `schema_version` 常量必须与文件名一致（`task_state.v0.1` → `task-state/v0.1`） | 报 ERROR |
| 3 | 每份契约必须内嵌 `examples` | 报 ERROR |
| 4 | 逐条校验 samples | 报 ERROR |
| 5 | `x-enum-vocabulary` 必须已注册，且取值 ⊆ 注册值 | 报 ERROR |
| 6 | `status=existing` 的词汇表必须与 Python/JSON 真源**完全一致** | 报 ERROR |
| 7 | `status=new` 的词汇表不得成为孤儿 | 报 WARN |

第 6 条是这套契约最关键的防线：**它防止运行时悄悄另起一套词汇表**。
真源用静态解析提取（不导入模块，避免副作用与循环依赖）。

---

## 6 pydantic 模型由生成，不手写（T1.2）

`runtime/contracts/generated/models.py` 是**生成物**，不要手工编辑。

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"

"$PY" runtime/tools/gen_models.py            # 生成
"$PY" runtime/tools/gen_models.py --check    # 漂移门禁：生成物是否与 schema 一致
```

| 生成规则 | 说明 |
|---|---|
| 根类命名 | `task_state.v0.1.schema.json` → `TaskState` |
| 嵌套对象 | 展开为模块级类 `<契约><属性链>`，如 `RunManifestDevice`、`GateRecordFindingsItem` |
| `$defs` 是标量 | 生成**类型别名**而非模型，如 `Sha256 = Annotated[str, StringConstraints(pattern='^[0-9a-f]{64}$')]` |
| `$defs` 是对象 | 生成模块级类；跨 schema 内容相同则去重，同名不同体直接报错 |
| Python 关键字字段 | 如 `history[].from` → 字段名 `from_` + `Field(alias='from')`，配 `populate_by_name=True`，JSON 侧仍是 `from` |
| 枚举 | `Literal[...]`；含 `x-enum-vocabulary` 的字段上方加注释标明归属 |
| 跨字段约束 | 契约含 `allOf/if/then/anyOf/oneOf/not` 时，根类注入 `model_validator`，构造后回放权威 schema |
| 严格性 | `ConfigDict(extra="forbid")`，非白名单字段一律拒绝 |

当前只有 `EvidenceIndex` 因 `missing 非空 → complete 必须为 false` 进入 `AUTHORITATIVE_CONTRACTS`，
其余契约零额外运行开销。

### 权威校验入口

一切契约校验都走 `runtime/contracts/validation.py`，不要各处自行 `json.load(schema)`：

```python
from runtime.contracts import validation

validation.report("task-state/v0.1", payload)   # -> [] 表示通过
validation.validate_payload("task-state/v0.1", payload)  # 失败抛 ContractViolation
```

> `format: date-time` 只作文档性描述，不做格式断言（JSON Schema 的 `format` 默认不校验）。
> 日期时间字段由 pydantic 侧保证可解析。

---

## 7 现状

```
schemas      : 9
vocab        : 16 已注册（全部 existing，无 new 遗留），14 被引用
checks       : 78 通过
runtime 测试 : 123 通过（contracts 7 + models 17 + state 28 + acl 23 + hashchain 20 + approval 28）
生成物       : runtime/contracts/generated/models.py（约 21 KB）
```

编排层（`runtime/orchestrator/`）已消费本目录契约：`acl.py` 校验 `NodeResult` 四字段自洽，
`approval.py` 校验 `ApprovedOrder` 与令牌一致，`state.py` 提供 10 个运行时词汇表的真源。

统一门禁（含能力层 49 项回归）：

```bash
"$PY" runtime/tools/run_all_tests.py          # 全跑
"$PY" runtime/tools/run_all_tests.py --fast   # 只跑 runtime 侧
```

---

## 8 待办

| # | 事项 | 归属 |
|---|---|---|
| 1 | 由契约生成 TS zod 类型，供 Web 层复用 | T1.3 |
| 2 | 共享 `$defs` 目前按 schema 内去重；跨 schema 已做同名同体检查，但尚未抽成公共 defs 文件 | T1.1 收尾 |

## T1.3 TypeScript + zod 类型（由同一批 Schema 生成）

契约是结构与词汇的唯一来源。第二语言不是手写第二份，而是**再生成一次**：

```
runtime/contracts/*.schema.json ─┬─> generated/models.py        (pydantic v2，Python 侧)
runtime/contracts/enums.json    ─┴─> generated/schema_types.ts  (zod 4，Web 侧)
```

手写第二份必然漂移，而**漂移的类型比没有类型更危险**：它会让前端以为校验过了，
实际和后端不是一套规则。

### 与 Python 侧对齐的三处口径

| 项 | Python（models.py） | TS（schema_types.ts） |
|---|---|---|
| 封闭对象 | `extra="forbid"` | `z.strictObject` |
| 契约 id | 取自 `schema_version` 常量 | 同一常量，产出 `contractSchemas` 索引 |
| 词汇表 | 引用 `enums.json` 的真源 | 同源生成 `XxxValues` / `XxxEnum` |

`from` 这类字段：Python 侧必须改写为 `from_` + `alias="from"`（关键字），
但 **TS 侧 `from` 是合法属性名，必须保持原名** —— 否则两边 JSON 不一致。
已有测试同时钉住两条。

### 支持的 schema 构造

| JSON Schema | zod |
|---|---|
| `const` | `z.literal(...)` |
| `enum` + `x-enum-vocabulary` | 引用词汇表 `XxxEnum` |
| `enum`（无词汇表） | `z.enum([...])` |
| `type: ["string","null"]` | `z.string().nullable()` |
| `pattern` | `z.string().regex(new RegExp(...))` |
| `format: date-time` | `z.iso.datetime()` |
| `additionalProperties: false` | `z.strictObject({...})` |
| `$defs` 标量 | 类型别名 |

**不猜的构造**：`allOf` / `anyOf` / `oneOf` / `not` / `if` 一律产出 `z.unknown()`
并在文件里留 `UNSUPPORTED` 标记、stdout 汇总。测试断言当前契约集里这类标记为 **0**
（棘轮：新增复杂契约会让测试红，逼人先想清楚怎么表达，而不是让类型静默退化）。

### 验证不是「文件生成了」，而是「真的能跑」

`runtime/tests/test_ts_types.py` 走完整链路：

```
把 schema_types.ts 复制进 node 工作区（tsc 从文件位置向上找 node_modules）
  -> tsc --strict 编译（同时完成类型检查）
  -> node 加载编译产物
  -> 对每个契约的每个样例 safeParse（正向必须通过）
  -> 样例必须满足契约声明的 required（防样例与契约脱节）
  -> 加未知字段必须被拒；删必填项必须被拒（负向）
```

实测：**9 份契约、31 条断言、全部通过**。

并且用两个**篡改用例**证明这套校验本身能失败：

| 篡改 | 预期 |
|---|---|
| `z.strictObject` → `z.object` | 必须报「strictObject 失效」 |
| 改错 `schema_version` literal | 正向样例必须失败 |

> 不这么做的检查会退化成装饰 —— 本会话已经踩过一次「不会失败的检查」。

### 生成与校验

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
"$PY" runtime/tools/gen_ts_types.py            # 生成 ts + schema_examples.json
"$PY" runtime/tools/gen_ts_types.py --check    # 漂移门禁
```

TS 漂移已并入 `run_all_tests.py`，与 Python 模型漂移并列。

依赖：`zod 4.6.5` + `typescript 7.0.2`，安装在受管 node 工作区
（`~/.workbuddy/binaries/node/workspace`），**不进包、不污染全局**。
