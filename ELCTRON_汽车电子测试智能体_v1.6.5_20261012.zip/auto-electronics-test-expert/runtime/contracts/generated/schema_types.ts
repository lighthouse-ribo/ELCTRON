/* eslint-disable */
/**
 * 自动生成，请勿手工编辑。
 *
 * 来源：runtime/contracts/*.schema.json + runtime/contracts/enums.json
 * 生成器：runtime/tools/gen_ts_types.py
 * 目标：zod 4（已验证 z.strictObject / z.iso.datetime / z.enum 可用）
 *
 * 修改契约请改 schema 后重跑生成器；直接改本文件会在漂移门禁里失败。
 */

import { z } from "zod";

/* ---------- 词汇表（真源见 enums.json 的 source_of_truth）---------- */

/** 真源：runtime/orchestrator/state.py :: AgentRole */
export const AgentRoleValues = ["terra", "plan_worker", "execution_worker", "evidence_worker", "human_approver"] as const;
export const AgentRoleEnum = z.enum(AgentRoleValues);

/** 真源：runtime/orchestrator/state.py :: ApprovalStatus */
export const ApprovalStatusValues = ["pending", "approved", "rejected", "expired", "revoked"] as const;
export const ApprovalStatusEnum = z.enum(ApprovalStatusValues);

/** 真源：skills/uds-diagnostic-test/scripts/result_contract.py :: VALID_VERDICTS */
export const CaseVerdictValues = ["PASS", "FAIL", "BLOCKED", "NA", "SKIP"] as const;
export const CaseVerdictEnum = z.enum(CaseVerdictValues);

/** 真源：runtime/orchestrator/state.py :: EvidenceKind */
export const EvidenceKindValues = ["asc", "xct_text", "response", "trace_json"] as const;
export const EvidenceKindEnum = z.enum(EvidenceKindValues);

/** 真源：schemas/portable-contract-v0.1.json :: context.statuses */
export const FactStatusValues = ["confirmed", "derived", "pending", "conflict", "blocked"] as const;
export const FactStatusEnum = z.enum(FactStatusValues);

/** 真源：skills/uds-diagnostic-test/scripts/result_contract.py :: FAILURE_CLASSES */
export const FailureClassValues = ["NONE", "ECU_FAIL", "SCRIPT_ERROR", "INFRA_ERROR", "INPUT_INVALID", "RESULT_INVALID", "BLOCKED"] as const;
export const FailureClassEnum = z.enum(FailureClassValues);

/** 真源：skills/uds-diagnostic-test/scripts/uds_case_gate.py :: SEVERITIES */
export const FindingSeverityValues = ["ERROR", "BLOCKED", "REVIEW_REQUIRED", "INFO"] as const;
export const FindingSeverityEnum = z.enum(FindingSeverityValues);

/** 真源：skills/uds-diagnostic-test/scripts/flow_contract.py :: FlowKind */
export const FlowKindValues = ["basic_uds", "swdl", "cybersecurity"] as const;
export const FlowKindEnum = z.enum(FlowKindValues);

/** 真源：skills/uds-diagnostic-test/scripts/uds_case_gate.py :: DECISIONS */
export const GateDecisionValues = ["GENERATE", "NEGATIVE", "BLOCKED", "REVIEW_REQUIRED", "REJECT"] as const;
export const GateDecisionEnum = z.enum(GateDecisionValues);

/** 真源：runtime/orchestrator/state.py :: GateStatus */
export const GateStatusValues = ["PASS", "REVIEW_REQUIRED", "ERROR", "BLOCKED", "ABORTED", "INCONCLUSIVE"] as const;
export const GateStatusEnum = z.enum(GateStatusValues);

/** 真源：runtime/orchestrator/state.py :: GraphNode */
export const GraphNodeValues = ["route_and_mount_reference", "inspect_inputs", "generate_or_design", "static_gate", "hardware_gate_and_execute"] as const;
export const GraphNodeEnum = z.enum(GraphNodeValues);

/** 真源：runtime/orchestrator/state.py :: MemoryKind */
export const MemoryKindValues = ["rule", "template", "runbook", "compat"] as const;
export const MemoryKindEnum = z.enum(MemoryKindValues);

/** 真源：runtime/orchestrator/state.py :: NodeStatus */
export const NodeStatusValues = ["OK", "REVIEW_REQUIRED", "ERROR", "BLOCKED"] as const;
export const NodeStatusEnum = z.enum(NodeStatusValues);

/** 真源：runtime/orchestrator/state.py :: RiskLevel */
export const RiskLevelValues = ["LOW", "MEDIUM", "HIGH", "CRITICAL"] as const;
export const RiskLevelEnum = z.enum(RiskLevelValues);

/** 真源：runtime/orchestrator/state.py :: RunFinalVerdict */
export const RunFinalVerdictValues = ["PASS", "FAIL", "INCONCLUSIVE"] as const;
export const RunFinalVerdictEnum = z.enum(RunFinalVerdictValues);

/** 真源：runtime/orchestrator/state.py :: TaskState */
export const TaskStateValues = ["NEW", "INSPECTED", "DESIGNED", "STATIC_PASSED", "RUNNING", "CAPTURED", "ASSESSED", "CLOSED"] as const;
export const TaskStateEnum = z.enum(TaskStateValues);

/* ---------- 共享类型定义 ---------- */

export const Sha256 = z.string().regex(new RegExp("^[0-9a-f]{64}$"));

export const RunId = z.string().regex(new RegExp("^[A-Za-z0-9][A-Za-z0-9_.-]{2,63}$"));

export const Byte = z.int().min(0).max(255);

export const CaseSchema = z.strictObject({
  case_id: z.string().regex(new RegExp("^[A-Za-z][A-Za-z0-9_-]{0,79}$")),
  title: z.string().min(1).max(240),
  request: z.array(Byte).min(1).max(4095),
  expectation: z.union([z.strictObject({
  kind: z.literal("positive_prefix"),
  bytes: z.array(Byte).min(1).max(4095),
}), z.strictObject({
  kind: z.literal("nrc"),
  nrc: Byte,
})]),
  preconditions: z.array(z.string().min(1).max(500)).min(1).max(32),
  source_refs: z.array(z.string().min(1).max(160)).max(32),
  traceability_status: z.union([z.literal("BOUND"), z.literal("UNBOUND")]),
});

/* ---------- 契约 ---------- */

/** 已授权的执行指令。模型只能提交本结构，不能直接调用硬件。令牌本身不写入本结构，只存引用。 */
export const ApprovedOrderSchema = z.strictObject({
  schema_version: z.literal("approved-order/v0.1"),
  order_id: z.string().min(1),
  run_id: RunId,
  flow: FlowKindEnum,
  /** 授权范围。执行器只接受本范围内的动作，越范围即拒绝。 */
  scope: z.strictObject({
  /** 允许的服务 ID，如 0x22、0x10。 */
  services: z.array(z.string().regex(new RegExp("^0x[0-9A-Fa-f]{2}$"))).min(1),
  dids: z.array(z.string().regex(new RegExp("^(0x)?[0-9A-Fa-f]{4}$"))).optional(),
  routines: z.array(z.string().regex(new RegExp("^(0x)?[0-9A-Fa-f]{4}$"))).optional(),
  partitions: z.array(z.enum(["APP", "PBL", "SBL", "shared"])).optional(),
  /** 目标硬件通道标识。属本机配置，不得从模型上下文推导。 */
  channel: z.string().optional(),
}),
  risk_level: RiskLevelEnum,
  /** 被批准的 TestPlan/DraftPlan 哈希，防止批准后被改写。 */
  plan_sha256: Sha256,
  /** 令牌引用（如 credential:// 或凭据库键名）。禁止写入令牌原文。 */
  approval_token_ref: z.string(),
  approval_status: ApprovalStatusEnum.optional(),
  valid_from: z.iso.datetime(),
  /** 过期即失效，不得复用。 */
  valid_until: z.iso.datetime(),
  issued_by: AgentRoleEnum,
  /** 高风险动作的最终授权人，必须是人工。 */
  approved_by: AgentRoleEnum.optional(),
  /** 不可逆动作（如刷写）必须为 false，且强制人工授权。 */
  reversible: z.boolean(),
  /** 是否必须先跑最小复测且 PASS 才允许全量执行。 */
  minimal_retest_required: z.boolean().optional(),
});
export type ApprovedOrder = z.infer<typeof ApprovedOrderSchema>;

/** 证据索引。每个最终结论都必须能通过本索引定位到原始报文与规则版本。本结构不可覆盖，只能新建版本。 */
export const EvidenceIndexSchema = z.strictObject({
  schema_version: z.literal("evidence-index/v0.1"),
  run_id: RunId,
  /** 判定所依据的规则与模板版本，必须与 GateRecord 一致。 */
  rule_version: z.string(),
  generated_at: z.iso.datetime().optional(),
  generated_by: AgentRoleEnum.optional(),
  /** 证据条目。只追加，不重写既有条目。 */
  entries: z.array(z.strictObject({
  evidence_id: z.string().min(1),
  kind: EvidenceKindEnum,
  /** 相对 runs/<run_id>/ 的路径。 */
  path: z.string(),
  sha256: Sha256,
  /** 该证据覆盖的时间区间。结论引用证据时必须落在区间内。 */
  time_range: z.strictObject({
  from: z.iso.datetime().optional(),
  to: z.iso.datetime().optional(),
}).optional(),
  /** 关键帧引用，不含整份日志。 */
  key_frames: z.array(z.strictObject({
  /** 时间戳或行号定位。 */
  at: z.string(),
  direction: z.enum(["tx", "rx"]),
  frame_id: z.string().optional(),
  note: z.string().optional(),
})).optional(),
  covers_cases: z.array(z.string()).optional(),
  /** 原始证据只追加只读复核，恒为 true。 */
  immutable: z.literal(true).optional(),
})),
  /** 缺失证据清单。非空即 complete=false，最终结论不得为 PASS。 */
  missing: z.array(z.strictObject({
  /** 用例 ID 或结论 ID。 */
  required_for: z.string(),
  reason: z.string(),
  expected_kind: EvidenceKindEnum.optional(),
})),
  /** 无法解释的现象。存在时结论应降级为 INCONCLUSIVE。 */
  unresolved: z.array(z.string()).optional(),
  /** missing 非空时必须为 false。 */
  complete: z.boolean(),
});
export type EvidenceIndex = z.infer<typeof EvidenceIndexSchema>;

/** 门禁结论记录。条件边唯一可读的机器可读状态码。必须由代码或人工审批产出，模型不得代为判定。 */
export const GateRecordSchema = z.strictObject({
  schema_version: z.literal("gate-record/v0.1"),
  gate_id: z.string().min(1),
  run_id: RunId,
  /** inspect 输入体检 / static 静态质量 / hardware 执行前预检 / evidence 证据完备性 / approval 人工授权。 */
  gate_kind: z.enum(["inspect", "static", "hardware", "evidence", "approval"]),
  /** 具体门禁实现名，如 case_lint、script_review、review_truth。 */
  gate_name: z.string().optional(),
  status: GateStatusEnum,
  /** code = 确定性程序判定；human = 人工审批。模型不是合法取值。 */
  decided_by: z.enum(["code", "human"]),
  decided_at: z.iso.datetime(),
  /** 判定所依据的规则/模板版本，用于回溯。 */
  rule_version: z.string(),
  /** 本次门禁实际检查的工件与哈希。为空即视为未检查，不得判 PASS。 */
  checked_artifacts: z.array(z.strictObject({
  path: z.string(),
  sha256: Sha256,
})).optional(),
  findings: z.array(z.strictObject({
  code: z.string(),
  severity: FindingSeverityEnum,
  message: z.string(),
  artifact: z.string().optional(),
  /** 如用例 ID、脚本行号、DID。 */
  locator: z.string().optional(),
})).optional(),
  /** 本门禁阻断的下游节点。 */
  blocks: z.array(z.enum(["route_and_mount_reference", "inspect_inputs", "generate_or_design", "static_gate", "hardware_gate_and_execute"])).optional(),
  /** gate_kind=approval 时指向 approval_token 记录。 */
  approval_ref: z.string().optional(),
});
export type GateRecord = z.infer<typeof GateRecordSchema>;

/** 长期记忆候选。worker 只能提交候选，只有 Terra 或确定性校验器可提升为项目长期记忆。禁止自动提升。 */
export const MemoryCandidateSchema = z.strictObject({
  schema_version: z.literal("memory-candidate/v0.1"),
  candidate_id: z.string().min(1),
  /** rule 稳定规则 / template 协议模板 / runbook 排障手册 / compat 项目兼容性信息。 */
  kind: MemoryKindEnum,
  /** 来源 run，用于追溯与撤回。 */
  source_run_id: RunId,
  /** 适用条件。缺少适用条件的候选不得提升。 */
  applicability: z.strictObject({
  conditions: z.array(z.string()).min(1),
  /** generic 可进通用包；project 只能留在项目包。 */
  scope: z.enum(["generic", "project"]).optional(),
  project_id: z.string().nullable().optional(),
}).optional(),
  /** 候选内容本身。禁止包含密钥、设备路径、原始 ASC/XCT 或当前任务状态。 */
  content: z.string().min(1).max(8000),
  proposed_by: AgentRoleEnum,
  proposed_at: z.iso.datetime(),
  approval: z.strictObject({
  status: ApprovalStatusEnum,
  approved_by: AgentRoleEnum.optional(),
  approved_at: z.iso.datetime().optional(),
  /** 提升后的记忆版本号。增量追加，禁止整份重压。 */
  version: z.int().min(1).optional(),
}),
  /** 被本候选取代的既有候选/记忆 ID。撤回时按此链回滚。 */
  supersedes: z.string().nullable().optional(),
  /** 恒为 false。为 true 的候选一律拒绝。 */
  contains_secret_material: z.literal(false).optional(),
});
export type MemoryCandidate = z.infer<typeof MemoryCandidateSchema>;

/** 单个图节点执行后的交接件。worker 之间不传长对话，只传本结构与工件路径。 */
export const NodeResultSchema = z.strictObject({
  schema_version: z.literal("node-result/v0.1"),
  run_id: RunId,
  /** 五个主节点。节点是业务步骤，不等于 agent。 */
  node: GraphNodeEnum,
  status: NodeStatusEnum,
  produced_at: z.iso.datetime(),
  produced_by: AgentRoleEnum,
  /** 本节点被允许写入的目录（单写者矩阵）。 */
  writes_to: z.enum(["01_command", "02_plan", "03_execution", "04_evidence", "05_final"]).optional(),
  /** 相对 runs/<run_id>/ 的路径。 */
  artifact_path: z.string().optional(),
  sha256: Sha256.optional(),
  summary: z.string().min(1).max(2000),
  /** 本节点消费的上游工件及其哈希，用于哈希链闭合。 */
  inputs: z.array(z.strictObject({
  path: z.string(),
  sha256: Sha256,
})).optional(),
  /** 仅 static_gate 与 hardware_gate_and_execute 产出。必须由代码生成，模型不得填写。 */
  gate_status: GateStatusEnum.optional(),
  /** 不可变事件追加流。 */
  events: z.array(z.strictObject({
  at: z.iso.datetime(),
  kind: z.string(),
  detail: z.string().optional(),
})).optional(),
});
export type NodeResult = z.infer<typeof NodeResultSchema>;

/** 一次硬件运行的封存记录。运行后只允许追加状态，不得改写初始配置。 */
export const RunManifestSchema = z.strictObject({
  schema_version: z.literal("run-manifest/v0.1"),
  run_id: RunId,
  flow: FlowKindEnum,
  device: z.strictObject({
  /** 驱动适配器名，如 xcdevlay。 */
  adapter: z.string(),
  /** 通道标识。属本机配置，运行后不可改。 */
  channel: z.string().optional(),
  driver_version: z.string().optional(),
  hardware_type: z.string().optional(),
  /** LIN 收发器供电状态（对应 xLinOpt.outputV）。 */
  transceiver_power: z.boolean().nullable().optional(),
}),
  /** 执行配置哈希，用于证明配置未被中途替换。 */
  config_sha256: Sha256.optional(),
  started_at: z.iso.datetime(),
  ended_at: z.iso.datetime().nullable().optional(),
  /** ABORTED 表示异常终止，必须配合 abort_reason 与已落盘 capture。 */
  status: z.enum(["PREFLIGHT", "RUNNING", "CAPTURED", "ABORTED"]),
  /** 本 run 依据的 ApprovedOrder 引用。无订单不得进入 RUNNING。 */
  order_refs: z.array(z.strictObject({
  order_id: z.string(),
  plan_sha256: Sha256,
})).min(1),
  /** 通道独占租约。同一通道同一时刻只允许一个 run 持有。 */
  channel_lease: z.strictObject({
  lease_id: z.string().optional(),
  holder: z.string().optional(),
  acquired_at: z.iso.datetime().optional(),
  expires_at: z.iso.datetime().optional(),
}).optional(),
  /** 原始证据封存记录。只追加。 */
  captures: z.array(z.strictObject({
  kind: EvidenceKindEnum,
  path: z.string(),
  sha256: Sha256,
  bytes: z.int().min(0),
  /** ASC 分卷序号。 */
  segment_index: z.int().min(0).optional(),
  frame_count: z.int().min(0).optional(),
})),
  /** 最小复测结果。非 PASS 时不得进入全量执行。 */
  minimal_retest: z.strictObject({
  required: z.boolean().optional(),
  case_id: z.string().optional(),
  verdict: CaseVerdictEnum.optional(),
  evidence_ref: z.string().optional(),
}).optional(),
  abort_reason: z.string().optional(),
  /** 运行环境快照。不含密钥、不含凭据值。 */
  environment: z.strictObject({
  python_version: z.string().optional(),
  os: z.string().optional(),
  occupying_processes_checked: z.array(z.string()).optional(),
}).optional(),
});
export type RunManifest = z.infer<typeof RunManifestSchema>;

/** 头领下发给 worker 的任务交接包。worker 之间不直接对话，所有协作经由此结构。 */
export const TaskPacketSchema = z.strictObject({
  schema_version: z.literal("task-packet/v0.1"),
  task_id: z.string().min(1),
  run_id: RunId,
  parent_task_id: z.string().nullable().optional(),
  from_role: AgentRoleEnum,
  to_role: AgentRoleEnum,
  /** 范围明确、可复核的单一目标。 */
  goal: z.string().min(1),
  /** 前置条件。未满足则 worker 必须回 BLOCKED，不得自行放宽。 */
  preconditions: z.array(z.string()).optional(),
  input_artifacts: z.array(z.strictObject({
  path: z.string(),
  sha256: Sha256,
})).optional(),
  /** 白名单动作。未列出即禁止。 */
  allowed_actions: z.array(z.string()).min(1),
  /** 显式禁止项，用于高风险任务。 */
  forbidden_actions: z.array(z.string()).optional(),
  /** 输出契约名，必须与 contracts/ 中某个 schema 对应。 */
  expected_output: z.string().min(1),
  /** 完成该任务必须具备的证据种类。缺一项即不可判完成。 */
  required_evidence: z.array(z.string()).min(1),
  /** 升级规则：命中条件时应升级给谁。 */
  escalation: z.array(z.strictObject({
  condition: z.string(),
  escalate_to: AgentRoleEnum,
})).optional(),
  expires_at: z.iso.datetime().optional(),
});
export type TaskPacket = z.infer<typeof TaskPacketSchema>;

/** 唯一任务状态。只有 Terra 可写；worker 与 Web 层只提交事件。所有字段必须由代码写入，模型不得直接构造。 */
export const TaskStateSchema = z.strictObject({
  schema_version: z.literal("task-state/v0.1"),
  run_id: RunId,
  flow: FlowKindEnum,
  project_id: z.string().min(1).optional(),
  state: TaskStateEnum,
  /** 唯一状态写入者。 */
  state_writer: z.literal("terra").optional(),
  created_at: z.iso.datetime(),
  updated_at: z.iso.datetime(),
  input_hash: Sha256.optional(),
  /** 本轮挂载的参考资料清单（由 reference_router 产出）。 */
  reference_mount: z.strictObject({
  primary_branch: z.string().optional(),
  secondary_branches: z.array(z.string()).optional(),
  mounted_assets: z.array(z.string()).optional(),
}).optional(),
  /** 本 run 的门禁记录路径，按发生顺序。 */
  gate_records: z.array(z.string()).optional(),
  artifacts: z.array(z.strictObject({
  kind: z.string(),
  path: z.string(),
  sha256: Sha256,
})).optional(),
  /** 仅允许在 CLOSED 时写入。证据不足只能 INCONCLUSIVE。 */
  final_verdict: RunFinalVerdictEnum.optional(),
  /** 前置条件未满足时的机器可读原因码或短句。 */
  blocked_reason: z.string().optional(),
  /** 状态迁移审计。禁止改写，只追加。 */
  history: z.array(z.strictObject({
  from: z.string().nullable(),
  to: z.string(),
  at: z.iso.datetime(),
  by: AgentRoleEnum,
  reason: z.string().optional(),
  evidence_ref: z.string().optional(),
})).min(1),
});
export type TaskState = z.infer<typeof TaskStateSchema>;

/**  */
export const PlatformNeutralUDSTestCaseSpecificationBundleSchema = z.strictObject({
  schema_version: z.literal("test-case-spec-bundle/v0.1"),
  cases: z.array(CaseSchema).min(1).max(128),
});
export type PlatformNeutralUDSTestCaseSpecificationBundle = z.infer<typeof PlatformNeutralUDSTestCaseSpecificationBundleSchema>;

/** 证据分析 worker 的判定草案。草案不是最终结论：final 恒为 false，签发 FinalVerdict 属 Terra 的职责。 */
export const VerdictDraftSchema = z.strictObject({
  schema_version: z.literal("verdict-draft/v0.1"),
  run_id: RunId,
  case_id: z.string().min(1),
  /** 单条用例级结论。沿用既有 result_contract 词汇表，不新增 INCONCLUSIVE。 */
  verdict: CaseVerdictEnum,
  /** 失败根因分类。非法 verdict 归一为 FAIL + RESULT_INVALID，不得伪装成 ECU_FAIL。 */
  failure_class: FailureClassEnum,
  /** 判定依据的规则版本，必须能在 EvidenceIndex 中找到同值。 */
  rule_version: z.string(),
  /** 本判定引用的证据 ID。PASS 与 FAIL 都必须非空，否则只能 INCONCLUSIVE（run 级）。 */
  evidence_refs: z.array(z.string()),
  /** 预期结果，来自用例定义。 */
  expected: z.string().optional(),
  /** 实测观察。必须来自原始证据，不得由模型改写。 */
  observed: z.string().optional(),
  nrc: z.string().regex(new RegExp("^0x[0-9A-Fa-f]{2}$")).nullable().optional(),
  /** 时序相关指标。高实时指标须来自 timing_trace 采集后离线分析，不得用上位机往返时间代替。 */
  timing: z.strictObject({
  p2_ms: z.number().optional(),
  p2_star_ms: z.number().optional(),
  measured_by: z.string().optional(),
}).optional(),
  /** 不确定项。非空时 Terra 应在最终结论中体现或降级。 */
  uncertainties: z.array(z.string()).optional(),
  produced_by: AgentRoleEnum,
  produced_at: z.iso.datetime(),
  /** 草案恒为非最终。FinalVerdict 由 Terra 另行签发。 */
  final: z.literal(false),
});
export type VerdictDraft = z.infer<typeof VerdictDraftSchema>;

/* ---------- 按 schema_version 常量索引 ---------- */

/** 与 runtime/contracts/validation.py 同一口径：契约 id = schema_version 常量。 */
export const contractSchemas = {
  "approved-order/v0.1": ApprovedOrderSchema,
  "evidence-index/v0.1": EvidenceIndexSchema,
  "gate-record/v0.1": GateRecordSchema,
  "memory-candidate/v0.1": MemoryCandidateSchema,
  "node-result/v0.1": NodeResultSchema,
  "run-manifest/v0.1": RunManifestSchema,
  "task-packet/v0.1": TaskPacketSchema,
  "task-state/v0.1": TaskStateSchema,
  "test-case-spec-bundle/v0.1": PlatformNeutralUDSTestCaseSpecificationBundleSchema,
  "verdict-draft/v0.1": VerdictDraftSchema,
} as const;

export type ContractId = keyof typeof contractSchemas;
