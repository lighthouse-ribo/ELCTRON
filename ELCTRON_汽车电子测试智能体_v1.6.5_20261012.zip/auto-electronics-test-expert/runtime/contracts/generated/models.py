# -*- coding: utf-8 -*-
"""！！ 本文件由 runtime/tools/gen_models.py 自动生成，请勿手工编辑 ！！

来源（唯一真源）：runtime/contracts/*.schema.json
重新生成：python runtime/tools/gen_models.py
漂移校验：python -m unittest discover -s runtime/tests

契约指纹：e38bdf58417a9463
"""
from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

AUTHORITATIVE_CONTRACTS: dict[str, str] = {
    "EvidenceIndex": "evidence-index/v0.1",
}

__all__ = [
    "ApprovedOrder",
    "Byte",
    "EvidenceIndex",
    "GateRecord",
    "MemoryCandidate",
    "NodeResult",
    "RunId",
    "RunManifest",
    "Sha256",
    "TaskPacket",
    "TaskState",
    "TestCaseSpecBundle",
    "VerdictDraft",
]


# ------------------------------------------------------------------------
# $defs 标量别名（共享去重）
# ------------------------------------------------------------------------
Byte = Annotated[int, Field(ge=0, le=255)]
RunId = Annotated[str, StringConstraints(pattern='^[A-Za-z0-9][A-Za-z0-9_.-]{2,63}$')]
Sha256 = Annotated[str, StringConstraints(pattern='^[0-9a-f]{64}$')]

class ApprovedOrderScope(BaseModel):
    """契约对象 ApprovedOrderScope。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    services: list[Annotated[str, StringConstraints(pattern='^0x[0-9A-Fa-f]{2}$')]] = Field(description='允许的服务 ID，如 0x22、0x10。', min_length=1)
    dids: Optional[list[Annotated[str, StringConstraints(pattern='^(0x)?[0-9A-Fa-f]{4}$')]]] = Field(default=None)
    routines: Optional[list[Annotated[str, StringConstraints(pattern='^(0x)?[0-9A-Fa-f]{4}$')]]] = Field(default=None)
    partitions: Optional[list[Literal['APP', 'PBL', 'SBL', 'shared']]] = Field(default=None)
    channel: Optional[str] = Field(description='目标硬件通道标识。属本机配置，不得从模型上下文推导。', default=None)


class ApprovedOrder(BaseModel):
    """已授权的执行指令。模型只能提交本结构，不能直接调用硬件。令牌本身不写入本结构，只存引用。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['approved-order/v0.1']
    order_id: Annotated[str, StringConstraints(min_length=1)]
    run_id: RunId
    # vocabulary: flow_kind
    flow: Literal['basic_uds', 'swdl', 'cybersecurity']
    scope: ApprovedOrderScope = Field(description='授权范围。执行器只接受本范围内的动作，越范围即拒绝。')
    # vocabulary: risk_level
    risk_level: Literal['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']
    plan_sha256: Sha256
    approval_token_ref: str = Field(description='令牌引用（如 credential:// 或凭据库键名）。禁止写入令牌原文。')
    # vocabulary: approval_status
    approval_status: Optional[Literal['pending', 'approved', 'rejected', 'expired', 'revoked']] = Field(default=None)
    valid_from: datetime
    valid_until: datetime = Field(description='过期即失效，不得复用。')
    # vocabulary: agent_role
    issued_by: Literal['terra', 'human_approver']
    # vocabulary: agent_role
    approved_by: Optional[Literal['human_approver']] = Field(description='高风险动作的最终授权人，必须是人工。', default=None)
    reversible: bool = Field(description='不可逆动作（如刷写）必须为 false，且强制人工授权。')
    minimal_retest_required: Optional[bool] = Field(description='是否必须先跑最小复测且 PASS 才允许全量执行。', default=None)

class EvidenceIndexEntriesItemTimeRange(BaseModel):
    """契约对象 EvidenceIndexEntriesItemTimeRange。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    from_: Optional[datetime] = Field(alias='from', default=None)
    to: Optional[datetime] = Field(default=None)


class EvidenceIndexEntriesItemKeyFramesItem(BaseModel):
    """契约对象 EvidenceIndexEntriesItemKeyFramesItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    at: str = Field(description='时间戳或行号定位。')
    direction: Literal['tx', 'rx']
    frame_id: Optional[str] = Field(default=None)
    note: Optional[str] = Field(default=None)


class EvidenceIndexEntriesItem(BaseModel):
    """契约对象 EvidenceIndexEntriesItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    evidence_id: Annotated[str, StringConstraints(min_length=1)]
    # vocabulary: evidence_kind
    kind: Literal['asc', 'xct_text', 'response', 'trace_json']
    path: str = Field(description='相对 runs/<run_id>/ 的路径。')
    sha256: Sha256
    time_range: Optional[EvidenceIndexEntriesItemTimeRange] = Field(description='该证据覆盖的时间区间。结论引用证据时必须落在区间内。', default=None)
    key_frames: Optional[list[EvidenceIndexEntriesItemKeyFramesItem]] = Field(description='关键帧引用，不含整份日志。', default=None)
    covers_cases: Optional[list[str]] = Field(default=None)
    immutable: Optional[Literal[True]] = Field(description='原始证据只追加只读复核，恒为 true。', default=None)


class EvidenceIndexMissingItem(BaseModel):
    """契约对象 EvidenceIndexMissingItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    required_for: str = Field(description='用例 ID 或结论 ID。')
    reason: str
    # vocabulary: evidence_kind
    expected_kind: Optional[Literal['asc', 'xct_text', 'response', 'trace_json']] = Field(default=None)


class EvidenceIndex(BaseModel):
    """证据索引。每个最终结论都必须能通过本索引定位到原始报文与规则版本。本结构不可覆盖，只能新建版本。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['evidence-index/v0.1']
    run_id: RunId
    rule_version: str = Field(description='判定所依据的规则与模板版本，必须与 GateRecord 一致。')
    generated_at: Optional[datetime] = Field(default=None)
    # vocabulary: agent_role
    generated_by: Optional[Literal['evidence_worker']] = Field(default=None)
    entries: list[EvidenceIndexEntriesItem] = Field(description='证据条目。只追加，不重写既有条目。')
    missing: list[EvidenceIndexMissingItem] = Field(description='缺失证据清单。非空即 complete=false，最终结论不得为 PASS。')
    unresolved: Optional[list[str]] = Field(description='无法解释的现象。存在时结论应降级为 INCONCLUSIVE。', default=None)
    complete: bool = Field(description='missing 非空时必须为 false。')

    @model_validator(mode="after")
    def _enforce_authoritative_schema(self):
        """本契约含跨字段约束，构造后回放权威 schema。"""
        from ..validation import validate_payload

        cid = AUTHORITATIVE_CONTRACTS[type(self).__name__]
        validate_payload(cid, self.model_dump(mode="json", exclude_unset=True, by_alias=True))
        return self

class GateRecordCheckedArtifactsItem(BaseModel):
    """契约对象 GateRecordCheckedArtifactsItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    path: str
    sha256: Sha256


class GateRecordFindingsItem(BaseModel):
    """契约对象 GateRecordFindingsItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    code: str
    # vocabulary: finding_severity
    severity: Literal['ERROR', 'BLOCKED', 'REVIEW_REQUIRED', 'INFO']
    message: str
    artifact: Optional[str] = Field(default=None)
    locator: Optional[str] = Field(description='如用例 ID、脚本行号、DID。', default=None)


class GateRecord(BaseModel):
    """门禁结论记录。条件边唯一可读的机器可读状态码。必须由代码或人工审批产出，模型不得代为判定。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['gate-record/v0.1']
    gate_id: Annotated[str, StringConstraints(min_length=1)]
    run_id: RunId
    gate_kind: Literal['inspect', 'static', 'hardware', 'evidence', 'approval'] = Field(description='inspect 输入体检 / static 静态质量 / hardware 执行前预检 / evidence 证据完备性 / approval 人工授权。')
    gate_name: Optional[str] = Field(description='具体门禁实现名，如 case_lint、script_review、review_truth。', default=None)
    # vocabulary: gate_status
    status: Literal['PASS', 'REVIEW_REQUIRED', 'ERROR', 'BLOCKED', 'ABORTED', 'INCONCLUSIVE']
    decided_by: Literal['code', 'human'] = Field(description='code = 确定性程序判定；human = 人工审批。模型不是合法取值。')
    decided_at: datetime
    rule_version: str = Field(description='判定所依据的规则/模板版本，用于回溯。')
    checked_artifacts: Optional[list[GateRecordCheckedArtifactsItem]] = Field(description='本次门禁实际检查的工件与哈希。为空即视为未检查，不得判 PASS。', default=None)
    findings: Optional[list[GateRecordFindingsItem]] = Field(default=None)
    blocks: Optional[list[Literal['route_and_mount_reference', 'inspect_inputs', 'generate_or_design', 'static_gate', 'hardware_gate_and_execute']]] = Field(description='本门禁阻断的下游节点。', default=None)
    approval_ref: Optional[str] = Field(description='gate_kind=approval 时指向 approval_token 记录。', default=None)

class MemoryCandidateApplicability(BaseModel):
    """契约对象 MemoryCandidateApplicability。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    conditions: list[str] = Field(min_length=1)
    scope: Optional[Literal['generic', 'project']] = Field(description='generic 可进通用包；project 只能留在项目包。', default=None)
    project_id: Optional[str] = Field(default=None)


class MemoryCandidateApproval(BaseModel):
    """契约对象 MemoryCandidateApproval。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    # vocabulary: approval_status
    status: Literal['pending', 'approved', 'rejected', 'expired', 'revoked']
    # vocabulary: agent_role
    approved_by: Optional[Literal['terra', 'human_approver']] = Field(default=None)
    approved_at: Optional[datetime] = Field(default=None)
    version: Optional[Annotated[int, Field(ge=1)]] = Field(description='提升后的记忆版本号。增量追加，禁止整份重压。', default=None)


class MemoryCandidate(BaseModel):
    """长期记忆候选。worker 只能提交候选，只有 Terra 或确定性校验器可提升为项目长期记忆。禁止自动提升。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['memory-candidate/v0.1']
    candidate_id: Annotated[str, StringConstraints(min_length=1)]
    # vocabulary: memory_kind
    kind: Literal['rule', 'template', 'runbook', 'compat'] = Field(description='rule 稳定规则 / template 协议模板 / runbook 排障手册 / compat 项目兼容性信息。')
    source_run_id: RunId
    applicability: Optional[MemoryCandidateApplicability] = Field(description='适用条件。缺少适用条件的候选不得提升。', default=None)
    content: Annotated[str, StringConstraints(min_length=1, max_length=8000)] = Field(description='候选内容本身。禁止包含密钥、设备路径、原始 ASC/XCT 或当前任务状态。')
    # vocabulary: agent_role
    proposed_by: Literal['plan_worker', 'evidence_worker']
    proposed_at: datetime
    approval: MemoryCandidateApproval
    supersedes: Optional[str] = Field(description='被本候选取代的既有候选/记忆 ID。撤回时按此链回滚。', default=None)
    contains_secret_material: Optional[Literal[False]] = Field(description='恒为 false。为 true 的候选一律拒绝。', default=None)

class NodeResultInputsItem(BaseModel):
    """契约对象 NodeResultInputsItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    path: str
    sha256: Sha256


class NodeResultEventsItem(BaseModel):
    """契约对象 NodeResultEventsItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    at: datetime
    kind: str
    detail: Optional[str] = Field(default=None)


class NodeResult(BaseModel):
    """单个图节点执行后的交接件。worker 之间不传长对话，只传本结构与工件路径。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['node-result/v0.1']
    run_id: RunId
    # vocabulary: graph_node
    node: Literal['route_and_mount_reference', 'inspect_inputs', 'generate_or_design', 'static_gate', 'hardware_gate_and_execute'] = Field(description='五个主节点。节点是业务步骤，不等于 agent。')
    # vocabulary: node_status
    status: Literal['OK', 'REVIEW_REQUIRED', 'ERROR', 'BLOCKED']
    produced_at: datetime
    # vocabulary: agent_role
    produced_by: Literal['terra', 'plan_worker', 'execution_worker', 'evidence_worker', 'human_approver']
    writes_to: Optional[Literal['01_command', '02_plan', '03_execution', '04_evidence', '05_final']] = Field(description='本节点被允许写入的目录（单写者矩阵）。', default=None)
    artifact_path: Optional[str] = Field(description='相对 runs/<run_id>/ 的路径。', default=None)
    sha256: Optional[Sha256] = Field(default=None)
    summary: Annotated[str, StringConstraints(min_length=1, max_length=2000)]
    inputs: Optional[list[NodeResultInputsItem]] = Field(description='本节点消费的上游工件及其哈希，用于哈希链闭合。', default=None)
    # vocabulary: gate_status
    gate_status: Optional[Literal['PASS', 'REVIEW_REQUIRED', 'ERROR', 'BLOCKED', 'ABORTED', 'INCONCLUSIVE']] = Field(description='仅 static_gate 与 hardware_gate_and_execute 产出。必须由代码生成，模型不得填写。', default=None)
    events: Optional[list[NodeResultEventsItem]] = Field(description='不可变事件追加流。', default=None)

class RunManifestDevice(BaseModel):
    """契约对象 RunManifestDevice。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    adapter: str = Field(description='驱动适配器名，如 xcdevlay。')
    channel: Optional[str] = Field(description='通道标识。属本机配置，运行后不可改。', default=None)
    driver_version: Optional[str] = Field(default=None)
    hardware_type: Optional[str] = Field(default=None)
    transceiver_power: Optional[bool] = Field(description='LIN 收发器供电状态（对应 xLinOpt.outputV）。', default=None)


class RunManifestOrderRefsItem(BaseModel):
    """契约对象 RunManifestOrderRefsItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    order_id: str
    plan_sha256: Sha256


class RunManifestChannelLease(BaseModel):
    """契约对象 RunManifestChannelLease。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    lease_id: Optional[str] = Field(default=None)
    holder: Optional[str] = Field(default=None)
    acquired_at: Optional[datetime] = Field(default=None)
    expires_at: Optional[datetime] = Field(default=None)


class RunManifestCapturesItem(BaseModel):
    """契约对象 RunManifestCapturesItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    # vocabulary: evidence_kind
    kind: Literal['asc', 'xct_text', 'response', 'trace_json']
    path: str
    sha256: Sha256
    bytes: Annotated[int, Field(ge=0)]
    segment_index: Optional[Annotated[int, Field(ge=0)]] = Field(description='ASC 分卷序号。', default=None)
    frame_count: Optional[Annotated[int, Field(ge=0)]] = Field(default=None)


class RunManifestMinimalRetest(BaseModel):
    """契约对象 RunManifestMinimalRetest。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    required: Optional[bool] = Field(default=None)
    case_id: Optional[str] = Field(default=None)
    # vocabulary: case_verdict
    verdict: Optional[Literal['PASS', 'FAIL', 'BLOCKED', 'NA', 'SKIP']] = Field(default=None)
    evidence_ref: Optional[str] = Field(default=None)


class RunManifestEnvironment(BaseModel):
    """契约对象 RunManifestEnvironment。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    python_version: Optional[str] = Field(default=None)
    os: Optional[str] = Field(default=None)
    occupying_processes_checked: Optional[list[str]] = Field(default=None)


class RunManifest(BaseModel):
    """一次硬件运行的封存记录。运行后只允许追加状态，不得改写初始配置。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['run-manifest/v0.1']
    run_id: RunId
    # vocabulary: flow_kind
    flow: Literal['basic_uds', 'swdl', 'cybersecurity']
    device: RunManifestDevice
    config_sha256: Optional[Sha256] = Field(default=None)
    started_at: datetime
    ended_at: Optional[datetime] = Field(default=None)
    status: Literal['PREFLIGHT', 'RUNNING', 'CAPTURED', 'ABORTED'] = Field(description='ABORTED 表示异常终止，必须配合 abort_reason 与已落盘 capture。')
    order_refs: list[RunManifestOrderRefsItem] = Field(description='本 run 依据的 ApprovedOrder 引用。无订单不得进入 RUNNING。', min_length=1)
    channel_lease: Optional[RunManifestChannelLease] = Field(description='通道独占租约。同一通道同一时刻只允许一个 run 持有。', default=None)
    captures: list[RunManifestCapturesItem] = Field(description='原始证据封存记录。只追加。')
    minimal_retest: Optional[RunManifestMinimalRetest] = Field(description='最小复测结果。非 PASS 时不得进入全量执行。', default=None)
    abort_reason: Optional[str] = Field(default=None)
    environment: Optional[RunManifestEnvironment] = Field(description='运行环境快照。不含密钥、不含凭据值。', default=None)

class TaskPacketInputArtifactsItem(BaseModel):
    """契约对象 TaskPacketInputArtifactsItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    path: str
    sha256: Sha256


class TaskPacketEscalationItem(BaseModel):
    """契约对象 TaskPacketEscalationItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    condition: str
    # vocabulary: agent_role
    escalate_to: Literal['terra', 'human_approver']


class TaskPacket(BaseModel):
    """头领下发给 worker 的任务交接包。worker 之间不直接对话，所有协作经由此结构。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['task-packet/v0.1']
    task_id: Annotated[str, StringConstraints(min_length=1)]
    run_id: RunId
    parent_task_id: Optional[str] = Field(default=None)
    # vocabulary: agent_role
    from_role: Literal['terra', 'plan_worker', 'execution_worker', 'evidence_worker', 'human_approver']
    # vocabulary: agent_role
    to_role: Literal['terra', 'plan_worker', 'execution_worker', 'evidence_worker', 'human_approver']
    goal: Annotated[str, StringConstraints(min_length=1)] = Field(description='范围明确、可复核的单一目标。')
    preconditions: Optional[list[str]] = Field(description='前置条件。未满足则 worker 必须回 BLOCKED，不得自行放宽。', default=None)
    input_artifacts: Optional[list[TaskPacketInputArtifactsItem]] = Field(default=None)
    allowed_actions: list[str] = Field(description='白名单动作。未列出即禁止。', min_length=1)
    forbidden_actions: Optional[list[str]] = Field(description='显式禁止项，用于高风险任务。', default=None)
    expected_output: Annotated[str, StringConstraints(min_length=1)] = Field(description='输出契约名，必须与 contracts/ 中某个 schema 对应。')
    required_evidence: list[str] = Field(description='完成该任务必须具备的证据种类。缺一项即不可判完成。', min_length=1)
    escalation: Optional[list[TaskPacketEscalationItem]] = Field(description='升级规则：命中条件时应升级给谁。', default=None)
    expires_at: Optional[datetime] = Field(default=None)

class TaskStateReferenceMount(BaseModel):
    """契约对象 TaskStateReferenceMount。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    primary_branch: Optional[str] = Field(default=None)
    secondary_branches: Optional[list[str]] = Field(default=None)
    mounted_assets: Optional[list[str]] = Field(default=None)


class TaskStateArtifactsItem(BaseModel):
    """契约对象 TaskStateArtifactsItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    kind: str
    path: str
    sha256: Sha256


class TaskStateHistoryItem(BaseModel):
    """契约对象 TaskStateHistoryItem。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    from_: Optional[str] = Field(alias='from')
    to: str
    at: datetime
    # vocabulary: agent_role
    by: Literal['terra']
    reason: Optional[str] = Field(default=None)
    evidence_ref: Optional[str] = Field(default=None)


class TaskState(BaseModel):
    """唯一任务状态。只有 Terra 可写；worker 与 Web 层只提交事件。所有字段必须由代码写入，模型不得直接构造。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['task-state/v0.1']
    run_id: RunId
    # vocabulary: flow_kind
    flow: Literal['basic_uds', 'swdl', 'cybersecurity']
    project_id: Optional[Annotated[str, StringConstraints(min_length=1)]] = Field(default=None)
    # vocabulary: task_state
    state: Literal['NEW', 'INSPECTED', 'DESIGNED', 'STATIC_PASSED', 'RUNNING', 'CAPTURED', 'ASSESSED', 'CLOSED']
    state_writer: Optional[Literal['terra']] = Field(description='唯一状态写入者。', default=None)
    created_at: datetime
    updated_at: datetime
    input_hash: Optional[Sha256] = Field(default=None)
    reference_mount: Optional[TaskStateReferenceMount] = Field(description='本轮挂载的参考资料清单（由 reference_router 产出）。', default=None)
    gate_records: Optional[list[str]] = Field(description='本 run 的门禁记录路径，按发生顺序。', default=None)
    artifacts: Optional[list[TaskStateArtifactsItem]] = Field(default=None)
    # vocabulary: run_final_verdict
    final_verdict: Optional[Literal['PASS', 'FAIL', 'INCONCLUSIVE']] = Field(description='仅允许在 CLOSED 时写入。证据不足只能 INCONCLUSIVE。', default=None)
    blocked_reason: Optional[str] = Field(description='前置条件未满足时的机器可读原因码或短句。', default=None)
    history: list[TaskStateHistoryItem] = Field(description='状态迁移审计。禁止改写，只追加。', min_length=1)

class Case(BaseModel):
    """契约对象 Case。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    case_id: Annotated[str, StringConstraints(pattern='^[A-Za-z][A-Za-z0-9_-]{0,79}$')]
    title: Annotated[str, StringConstraints(min_length=1, max_length=240)]
    request: list[Byte] = Field(min_length=1)
    expectation: Any
    preconditions: list[Annotated[str, StringConstraints(min_length=1, max_length=500)]] = Field(min_length=1)
    source_refs: list[Annotated[str, StringConstraints(min_length=1, max_length=160)]]
    traceability_status: Any


class TestCaseSpecBundle(BaseModel):
    """契约对象 TestCaseSpecBundle。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['test-case-spec-bundle/v0.1']
    cases: list[Case] = Field(min_length=1)

class VerdictDraftTiming(BaseModel):
    """契约对象 VerdictDraftTiming。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    p2_ms: Optional[Annotated[float, Field(ge=0)]] = Field(default=None)
    p2_star_ms: Optional[Annotated[float, Field(ge=0)]] = Field(default=None)
    measured_by: Optional[str] = Field(default=None)


class VerdictDraft(BaseModel):
    """证据分析 worker 的判定草案。草案不是最终结论：final 恒为 false，签发 FinalVerdict 属 Terra 的职责。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    schema_version: Literal['verdict-draft/v0.1']
    run_id: RunId
    case_id: Annotated[str, StringConstraints(min_length=1)]
    # vocabulary: case_verdict
    verdict: Literal['PASS', 'FAIL', 'BLOCKED', 'NA', 'SKIP'] = Field(description='单条用例级结论。沿用既有 result_contract 词汇表，不新增 INCONCLUSIVE。')
    # vocabulary: failure_class
    failure_class: Literal['NONE', 'ECU_FAIL', 'SCRIPT_ERROR', 'INFRA_ERROR', 'INPUT_INVALID', 'RESULT_INVALID', 'BLOCKED'] = Field(description='失败根因分类。非法 verdict 归一为 FAIL + RESULT_INVALID，不得伪装成 ECU_FAIL。')
    rule_version: str = Field(description='判定依据的规则版本，必须能在 EvidenceIndex 中找到同值。')
    evidence_refs: list[str] = Field(description='本判定引用的证据 ID。PASS 与 FAIL 都必须非空，否则只能 INCONCLUSIVE（run 级）。')
    expected: Optional[str] = Field(description='预期结果，来自用例定义。', default=None)
    observed: Optional[str] = Field(description='实测观察。必须来自原始证据，不得由模型改写。', default=None)
    nrc: Optional[Annotated[str, StringConstraints(pattern='^0x[0-9A-Fa-f]{2}$')]] = Field(default=None)
    timing: Optional[VerdictDraftTiming] = Field(description='时序相关指标。高实时指标须来自 timing_trace 采集后离线分析，不得用上位机往返时间代替。', default=None)
    uncertainties: Optional[list[str]] = Field(description='不确定项。非空时 Terra 应在最终结论中体现或降级。', default=None)
    # vocabulary: agent_role
    produced_by: Literal['evidence_worker']
    produced_at: datetime
    final: Literal[False] = Field(description='草案恒为非最终。FinalVerdict 由 Terra 另行签发。')
