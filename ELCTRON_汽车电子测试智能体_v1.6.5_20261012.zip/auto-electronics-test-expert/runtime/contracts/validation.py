#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.2 契约校验入口（唯一权威通道）。

所有契约校验都必须经过本模块，避免各处自行 `json.load(schema)`：
  * schema 只加载一次并缓存；
  * 以 `schema_version` 常量作为契约 ID（如 ``task-state/v0.1``）；
  * 提供「抛异常」与「拿报告」两种形态；
  * 生成的 pydantic 模型对含跨字段约束的契约，构造后回放本模块做权威校验。

本模块不做格式断言（JSON Schema 的 ``format`` 默认不校验）。日期时间字段由
pydantic 侧保证可解析，`format: date-time` 仅作文档性描述。
"""
from __future__ import annotations

import json
import os
from typing import Any

from jsonschema import Draft202012Validator

HERE = os.path.dirname(os.path.abspath(__file__))          # runtime/contracts
REPO_ROOT = os.path.dirname(os.path.dirname(HERE))         # <包根>

_CACHE: dict[str, dict] | None = None


class ContractViolation(ValueError):
    """载荷不符合契约。"""

    def __init__(self, contract_id: str, errors: list[str]):
        self.contract_id = contract_id
        self.errors = errors
        super().__init__(f"{contract_id} 校验失败（{len(errors)} 项）：" + "；".join(errors[:4]))


def _load() -> dict[str, dict]:
    global _CACHE
    if _CACHE is None:
        index: dict[str, dict] = {}
        for name in sorted(os.listdir(HERE)):
            if not name.endswith(".schema.json"):
                continue
            with open(os.path.join(HERE, name), encoding="utf-8") as fh:
                schema = json.load(fh)
            cid = schema.get("properties", {}).get("schema_version", {}).get("const")
            if not cid:
                raise RuntimeError(f"{name} 缺少 properties.schema_version.const，无法登记为契约")
            if cid in index:
                raise RuntimeError(f"契约 ID 冲突：{cid}")
            Draft202012Validator.check_schema(schema)
            index[cid] = schema
        _CACHE = index
    return _CACHE


def contract_ids() -> list[str]:
    """已注册契约 id 列表（即各 schema 的 schema_version 常量）。"""
    return sorted(_load())


def schema_for(contract_id: str) -> dict:
    """按契约 id 取 JSON Schema 文档；未注册抛 KeyError。"""
    try:
        return _load()[contract_id]
    except KeyError:
        raise ContractViolation(contract_id, [f"未登记的契约 ID；已登记：{contract_ids()}"]) from None


def report(contract_id: str, payload: Any) -> list[str]:
    """返回错误列表（空列表 = 通过）。不抛异常。"""
    schema = schema_for(contract_id)
    validator = Draft202012Validator(schema)
    out = []
    for err in sorted(validator.iter_errors(payload), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "<root>"
        out.append(f"{loc}: {err.message}")
    return out


def validate_payload(contract_id: str, payload: Any) -> Any:
    """校验通过则原样返回 payload，否则抛 ContractViolation。"""
    errors = report(contract_id, payload)
    if errors:
        raise ContractViolation(contract_id, errors)
    return payload


def is_valid(contract_id: str, payload: Any) -> bool:
    """数据是否符合契约（布尔快捷方式；错误详情用 report()）。"""
    return not report(contract_id, payload)
