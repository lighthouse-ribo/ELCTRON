"""Validated, non-secret DeepSeek per-run performance selection."""
WORKER_EFFORTS = ("none", "low", "high", "max")
def normalize_worker_effort(value=None):
    if value is None:
        return "high"
    if not isinstance(value, str) or value not in WORKER_EFFORTS:
        raise ValueError("WORKER_REASONING_EFFORT_INVALID")
    return value

CODEX_EFFORTS = ("low", "medium", "high", "xhigh")
def normalize_codex_effort(value=None):
    if value is None:
        return "medium"
    if not isinstance(value, str) or value not in CODEX_EFFORTS:
        raise ValueError("CODEX_REASONING_EFFORT_INVALID")
    return value
