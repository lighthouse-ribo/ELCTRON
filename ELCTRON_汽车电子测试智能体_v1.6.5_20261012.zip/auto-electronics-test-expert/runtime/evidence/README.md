# runtime/evidence —— 证据与报告闭环

T4 起建立。本目录负责把执行留下的原始记录变成**可追溯、可复核**的结论。

当前内容：

| 文件 | 作用 |
|---|---|
| `asc_index.py` | T4.1 / T4.5 证据解析：复用既有解析器、推绝对时间段、挑关键帧、二进制 XCT 直接 BLOCKED |
| `index_builder.py` | T4.2 EvidenceIndex 生成：与 RunManifest 对账、缺失显式列出、索引不可覆盖 |
| `verdict.py` | T4.3 VerdictDraft 与最终结论门槛（红线 R5 的落点） |
| `report.py` | T4.4 报告生成：只走既有 `report_to_html.py`，不自造前端 |

---

## 1 不重造解析器（T4.1 / T4.5）

ASC / 文本 XCT 的逐帧解析与 LIN-TP 重组**已经存在**：
`skills/uds-diagnostic-test/scripts/swdl_trace_import.py`（`parse_trace` / `import_swdl_trace`）。
本层只做整理，不写第二套正则。测试里有断言：

```python
mod = asc.load_trace_module()
assert mod.__name__ == "swdl_trace_import"
```

### 绝对时间段怎么来

ASC 头部有一行 `date Tue Sep 15 04:12:07.659 pm 2026`，帧时间戳是**相对首帧的秒数**。
两者相加得到真实墙钟区间 —— 这样「结论可定位到文件与**时间段**」才成立。

文本 XCT 没有头部日期 → `time_range` 置空，同时把「无绝对时间锚点」记进 `unresolved`，
**不编造时间**。

### 关键帧

直接用既有解析器产出的 `transactions`（请求与最终响应已配对，含 `elapsed_ms` 与原始行号）：

```
at=25.410000s-25.415000s  direction=tx  frame_id=0x3C
note=req SID=0x22；resp SID=0x62；elapsed=5.0ms；lines=[11, 12]
```

负响应会标出 `resp 负响应 NRC=0x22`；无响应会标 `无响应`。

### 二进制专有 XCT：BLOCKED（T4.5）

```python
load_evidence("traces/proprietary.xct", run_dir)
# -> BinaryEvidenceBlocked: ... 本项目默认 BLOCKED，不猜测布局；请先导出为文本/ASC
```

用嗅探判定：出现 NUL 字节或无法按 UTF-8 解码即视为二进制。**不做"尽力解析"**——
布局随厂商与版本变化，猜错会造出假证据。

---

## 2 EvidenceIndex（T4.2）

```python
index = build_evidence_index(run_id=..., manifest=manifest, run_dir=...,
                             rule_version="expectation_check/2026-09-04",
                             required_cases=("TC-1", "TC-2"))
write_index(run_dir, index)     # -> 04_evidence/evidence_index.json
```

三条纪律：

| 纪律 | 落地方式 |
|---|---|
| **与 manifest 对账** | 磁盘摘要必须等于 RunManifest 里记录的 `sha256`；不一致说明封存后被改过 → 记为缺失 + 未解释项 |
| **缺失必须显式** | 有缺失项时 `complete` 强制 false；**零证据条目同样判不完整**（「没有证据」不是「没有缺失」） |
| **索引不可覆盖** | 已存在时抛 `IndexExists`；确需重建要显式 `allow_replace=True`，旧索引归档为 `.previous` |

`verify_index(run_dir, index)` 可随时重算条目哈希，确认索引指向的文件没被改动。

---

## 3 结论门槛（T4.3）

### 草案级：没有证据的断言构造不出来

```python
build_verdict_draft(..., verdict="PASS", evidence_refs=[])
# -> VerdictInvalid: PASS 必须引用至少一条证据
```

`PASS` / `FAIL` 必须带证据引用；`BLOCKED` / `NA` / `SKIP` 不要求（本来就没执行）。
`final` 恒为 `false` —— 草案不是最终结论。

### run 级：证据不足只能是 INCONCLUSIVE

```python
out = finalize(case_verdicts=["PASS", "PASS"], evidence_index=index)
out["final_verdict"]    # PASS / FAIL / INCONCLUSIVE / None
out["reasons"]          # 判定理由，逐条可读
```

降级条件（任一命中即 INCONCLUSIVE）：

- 没有 EvidenceIndex
- 索引有 `missing` 或 `unresolved`
- `rule_version` 与本次不一致

不结案（返回 `None`）：

- `aborted=True`（异常中止）
- 存在 `BLOCKED` 用例（前置未满足、从未执行）

**`BLOCKED`（没执行）与 `INCONCLUSIVE`（执行了但证据不足）始终是两个东西。**

---

## 4 报告复用（T4.4）

```python
render_report(out_path="report.html", results_path="results.json",
              extra_path="extra.json", project_config="config.json")
```

`runtime/evidence/report.py` **不生成任何 HTML**，只做两件事：

1. 以子进程调用既有 `report_to_html.py`（参数面与它的 `--help` 完全一致）；
2. `assert_framework_available()` 校验 `templates/uds_report_framework.html` 在位。

框架模板缺失时**直接报错**，不会退化成一个自造页面 —— 自造前端会破坏既有的展示规范。

风格契约（`STYLE_CONTRACT`）：

> 报告必须复用 `report_to_html.py` + `templates/uds_report_framework.html`；
> 时间轴只切换软件版本，同一版本内通过 `modules[]` 切换模块；
> 不得另起 v2 页面或改变原始 DOM/CSS 风格。

---

## 5 验证

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
"$PY" -m unittest runtime.tests.test_evidence     # 46 项
"$PY" runtime/tools/run_all_tests.py              # 完整门禁
```

测试用**真实的 ASC**（由既有 `LiveAscRecorder` 产出）喂给证据解析，
证明这条链路接的是真数据，不是构造出来的假样本。

## T4.6 证据格式兼容：CANLOG 解析器（canlog.py）

### 为什么必须有它

实测（2026-09-15）：把上位机**真实录制** `RECORD\CANLOG_*.xct` 交给既有
`swdl_trace_import.parse_trace`，**全部抛 `TraceImportError`**。
也就是说本层此前「在夹具上全绿、在真实证据上全失败」——证据根本进不来。

### 格式（实测口径）

```
###CDXCAN
# version = 2.0
# app = VickCAN,2.37      （也有 3.10）
# date = 2026-6-9,16:50:14-269
# brval,1=250000,0        （每通道一条，可能缺）
# bsts = 45514            （部分文件才有）
       0 1 10 lin tx  2, 42 00                        <- VickCAN 2.37
  236966 1 3C lin tx cl  8,  51 03 22 D0 3A FF FF FF  <- VickCAN 3.10（多一个 kind）
```

数据行两个变体**必须都支持**：

| 版本 | 字段 |
|---|---|
| 2.37 | `<t> <ch> <id> <bus> <dir> <dlc>, <data…>` |
| 3.10 | `<t> <ch> <id> <bus> <dir> <kind> <dlc>, <data…>` |

`kind` 实测有 `wa` / `cl` / `ao`。**语义未验证**，原样保留、不解释、不参与判定。

### 第 1 字段是微秒级帧间增量（2026-09-15 修正：初版结论错误）

**初版曾断言它是"每帧位时间测量值、无时间轴"——该结论已被推翻**，此处保留勘误记录。

正确语义：第 1 字段是**相对上一数据行的增量时间（µs）**，逐行累加即得单调时间轴
（`t_us`）。三条独立证据：

1. **物理约束**：单帧响应事务的「请求→响应」累加差 p50 = 22454，按 **µs** 解释 =
   22.4 ms，与 P2=50 ms、LIN 调度节奏吻合；按初版主张的 **ns** 解释 = 22 µs，
   而一次 LIN 帧传输本身就要约 1.77 ms（19200 bps）——物理上不可能。
2. **团队参考实现** `lin_uds_tool(1)/analysis/parse_xct.py` v2 采用同一语义
   （`t += int(dt)`），对 128 个真实文件的重组结果与本实现一致。
3. 初版的"22865 次递减 → 不是时间戳"推理错在把**增量序列**当**绝对时间戳**检验
   单调性——增量本来就不需要单调。

| 能做到 | 说明 |
|---|---|
| 帧级时刻 = 文件头 `# date` + 累计 `t_us` | µs 精度，单调 |
| P2 / P2* 服务时序、帧间间隔 | **可以**从 CANLOG 得出（初版"做不到"的结论一并修正） |
| 源文件行号定位 | 保留；dt=0 的行表示同刻，亚毫秒排序按行号 |

因此 `ParsedEvidence.time_axis_available=False`，`time_range` 恒为 `None`，
原因写进 `unresolved` —— **宁可不给时间段，也不编造**。

### 接入方式

`asc_index.load_evidence()` 按**内容**分派（不看后缀）：

```python
if _canlog.is_canlog(full):          # 首行是否 ###CDXCAN
    return _evidence_from_canlog(...)
mod = load_trace_module()            # 否则仍走既有 ASC / SWDL-XCT 路径
```

### 验收证据

`baseline/evidence/canlog_replay_2026-09-15.txt`

```
文件数      26 / 26 成功，0 失败
总帧数      459899
诊断帧      96（0x3C 主请求 10 / 0x3D 从响应 86）
录制工具    VickCAN 2.37 × 22，VickCAN 3.10 × 4
```

### 尚未做（明确的下一步，不假装已有）

1. ~~**LIN-TP 重组**~~ —— **已由 T4.7 完成**，见下节 `lin_uds.py`。
2. **kind 语义**：`wa` / `cl` / `ao` 的真实含义需要对照上位机文档确认后，才能参与判定。
3. **0x2C / 0x2E 帧**：全量回放里各出现 130 次，尚不清楚其业务含义，未做特殊处理。

## T4.7 LIN-TP 重组：帧 → UDS 事务（lin_uds.py）

### 为什么必须有它

`canlog.py` 把录制解析到**帧级**，但结论需要**服务级**：哪个 SID、哪个 DID、
正响应还是 NRC。没有重组，证据链就停在「抓到了帧」，M4 门禁（缺证据不可能 PASS）
也就无从落地。

### 不重写重组算法

直接复用既有 `skills/uds-diagnostic-test/scripts/lin_tp.py` 的
`parse_frame` / `assemble`。本模块只负责**分组与角色判定**，字节级重组交回既有实现
（能力层只增不改）。

### 三条规则全部来自真实观察，不是规范推演

| # | 规则 | 观察依据 |
|---|---|---|
| 1 | **空帧不参与重组** | `CANLOG_260909_100454_064.xct` 里一次请求后夹着 **19 个 `0x3D` 空帧**（`dlc=0`,`kind=ao`），它们是「发了头但没收到数据」的占位记录 |
| 2 | **不用 `tx`/`rx` 判角色** | 实测**同一个 `0x3D` 数据帧既有 `tx` 也有 `rx`**，标签不可靠 → 角色一律按 `frame_id` 判定，本模块输入**根本不带方向字段** |
| 3 | **分组边界靠请求帧** | 一次请求开启一个事务；多帧请求只在'上一组是未收齐的 FF'时才并入下一帧，避免把两次独立请求误并成一个 |

### 失败一律如实分类，不混为一谈

| error | 含义 | 触发实例（实测） |
|---|---|---|
| `sequence` | CF 序号跳变，多帧重组失败 | 合成用例覆盖 |
| `invalid` | 首帧 NAD/PCI 非法，**根本不是 UDS 请求** | `CANLOG_260610_103946.xct` L2832/L3071 = `00 FF FF FF FF FF FF FF` |
| `pending` | 只见 0x78，最终响应未出现 | 合成用例覆盖 |

> `invalid` 与 `sequence` 必须分开：把「诊断帧 ID 上的无关流量」报成「重组失败」，
> 会污染对 ECU 行为的判断。这是本轮修掉的一个**归因错误**。

### 时序指标可以从 CANLOG 得出（2026-09-15 修正）

初版"必须改录 ASC 才能拿到时序"的结论**已修正**：CANLOG 第 1 字段是 µs 级增量，
累加即得时间轴（见 T4.6 勘误）。`lin_tp.analyze_trace()` 需要的
`[(ts, direction, frame_id, data)]` 可由 `t_us / 1e6` 直接提供。

注意两点：
* 方向字段实测不可靠（同一 0x3D 帧既有 tx 也有 rx），喂给 `analyze_trace` 前
  应按帧 ID 重写方向（0x3C=TX、0x3D=RX）；
* `# date` 缺失的文件只有相对时间轴，无绝对时刻。

### 验收证据

`baseline/evidence/t4_7_transactions_2026-09-15.txt`

```
含诊断帧的文件    5 / 26
UDS 事务总数      10
拿到响应          4      （其余 6 次未应答或非 UDS 流量）
请求 SID          0x22 ×7，0x3E ×1
负响应 NRC        无
```

真实恢复出的第一条多帧事务（`CANLOG_260909_100454_064.xct` L26-L29）：

```
请求  22 FD 18                       -> ReadDataByIdentifier，DID 0xFD18
响应  62 FD 18 53 32 36 30 38 33 31 33 31 38   -> 正响应，数据区为 ASCII 'S260831318'
       首帧 51 10 0D -> total = (0x0 << 8) | 0x0D = 13 字节（FF + 2×CF）
```

### 尚未做

1. `kind`（`wa`/`cl`/`ao`）语义仍需对照上位机文档确认；实测相关性：`wa` 只出现在
   帧 ID `0x00` 且 `dlc=0`（疑似唤醒）、`ao` 只出现在空帧、`cl` 出现在带数据的帧。
2. 请求/响应配对按文件顺序（有时间轴后可做时序窗口校验，尚未接）。

---

## T4.8 交叉验证与三处语义修正（2026-09-15 v2）

对照物：团队参考实现 `lin_uds_tool(1)/analysis/parse_xct.py` v2。
样本：全盘 **128 个 .xct**（VickCAN 2.37 ×? / 3.10 ×? 混合，RECORD 目录 26 个 + 压测/异常目录 102 个）。
证据：`baseline/evidence/crosscheck_2026-09-15_v2.txt`

| 修正 | 内容 |
|---|---|
| **时间轴** | 第 1 字段 = µs 级帧间增量，累加成单调时间轴（初版"位时间"结论错误，见上） |
| **请求重发折叠** | 未应答前的相同请求（同 NAD + 同载荷）折叠为一个事务，`retries` 计数；不折叠会把 SWDL 压测录制的事务数虚增约 30% |
| **NAD 过滤** | 0x3C/0x3D 是总线级帧 ID，载荷首字节（NAD）决定目标 ECU；实测 210504.xct 上 0x3C 有 78779 帧 NAD=0x51、14 帧 NAD=0x7E（其它节点）。`transactions(nad=...)` 由调用方传项目值，本层不硬编码 |

交叉验证结论（127 文件可比，1 个纯 CAN 文件跳过）：

* **参考实现没有本方缺失的任何事务**（`ref 独有请求 = {}` 全部 128 文件）；
* 本方比参考多恢复 **90+ 个响应事务**——参考按 `tx/rx` 标签过滤，实测标签不可靠
  （小文件整文件 ref=0 而本方完整恢复）；
* 大文件 ±1 事务差异为 EOF 尾部口径，不影响结论。

新增/修改文件：`canlog.py`（时间轴 + 跳过非 LIN 行）、`lin_uds.py`（折叠 + NAD）、
`asc_index.py`（透传 + 关键帧带 `t_ms`）、对应测试（`test_canlog` 24、`test_lin_uds` 22）。
