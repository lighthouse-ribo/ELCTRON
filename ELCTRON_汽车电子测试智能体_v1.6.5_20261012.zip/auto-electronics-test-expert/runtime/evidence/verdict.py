#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T4.3 VerdictDraft 与最终结论门槛。

红线 R5 的落点：**证据不足，只可能是 INCONCLUSIVE**。

本模块把这条规则做成两道不可绕过的关卡：

1. **草案级**：`PASS` / `FAIL` 这类断言性结论，必须声明至少一条证据引用；
   没有证据的断言根本无法构造出 VerdictDraft。
2. **run 级**：`finalize()` 用 EvidenceIndex 的完备性 + 未解释项 + 是否中止，
   推导三态结论。索引不完整时，即便所有用例都写了 PASS，最终也只能 INCONCLUSIVE。

`BLOCKED`（前置未满足、从未执行）与 `INCONCLUSIVE`（已执行但证据不足）始终分开。
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping, Sequence

from ..contracts import validation
from ..orchestrator.state import RunFinalVerdict, derive_final_verdict

ASSERTIVE_VERDICTS = frozenset({"PASS", "FAIL"})
VALID_CASE_VERDICTS = frozenset({"PASS", "FAIL", "BLOCKED", "NA", "SKIP"})
VALID_FAILURE_CLASSES = frozenset({
    "NONE", "ECU_FAIL", "SCRIPT_ERROR", "INFRA_ERROR", "INPUT_INVALID",
    "RESULT_INVALID", "BLOCKED",
})


class VerdictInvalid(ValueError):
    """VerdictDraft 不合法。"""


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def build_verdict_draft(*, run_id: str, case_id: str, verdict: str, rule_version: str,
                        evidence_refs: Sequence[str], failure_class: str = "NONE",
                        expected: str = "", observed: str = "", nrc: str | None = None,
                        timing: Mapping[str, Any] | None = None,
                        uncertainties: Sequence[str] = (),
                        produced_at: datetime | None = None) -> dict[str, Any]:
    """构造一条判定草案。不合规直接抛 VerdictInvalid。"""
    verdict = str(verdict or "").upper()
    if verdict not in VALID_CASE_VERDICTS:
        raise VerdictInvalid(f"非法 verdict {verdict!r}；可选 {sorted(VALID_CASE_VERDICTS)}")

    failure_class = str(failure_class or "NONE").upper()
    if failure_class not in VALID_FAILURE_CLASSES:
        raise VerdictInvalid(f"非法 failure_class {failure_class!r}")

    if verdict in ASSERTIVE_VERDICTS and not list(evidence_refs):
        raise VerdictInvalid(
            f"{verdict} 必须引用至少一条证据；"
            "没有证据的断言不可构造（红线 R5：证据不足只能 INCONCLUSIVE）")

    draft: dict[str, Any] = {
        "schema_version": "verdict-draft/v0.1",
        "run_id": run_id,
        "case_id": case_id,
        "verdict": verdict,
        "failure_class": failure_class,
        "rule_version": rule_version,
        "evidence_refs": list(evidence_refs),
        "produced_by": "evidence_worker",
        "produced_at": _iso(produced_at or datetime.now(timezone.utc)),
        "final": False,
    }
    if expected:
        draft["expected"] = expected
    if observed:
        draft["observed"] = observed
    if nrc is not None:
        draft["nrc"] = nrc
    if timing:
        draft["timing"] = dict(timing)
    if uncertainties:
        draft["uncertainties"] = [u for u in uncertainties if str(u).strip()]

    errors = validation.report("verdict-draft/v0.1", draft)
    if errors:
        raise VerdictInvalid("；".join(errors[:5]))
    return draft


def finalize(*, case_verdicts: Sequence[str], evidence_index: Mapping[str, Any] | None,
             rule_version: str = "", aborted: bool = False) -> dict[str, Any]:
    """推导 run 级三态结论。

    返回结构（含理由，便于审计）::

        {"final_verdict": "PASS"|"FAIL"|"INCONCLUSIVE"|None,
         "evidence_complete": bool,
         "blocked": bool,
         "reasons": [...]}
    """
    reasons: list[str] = []

    if aborted:
        reasons.append("本轮异常中止，不产生最终结论")
        return {"final_verdict": None, "evidence_complete": False,
                "blocked": False, "reasons": reasons}

    if evidence_index is None:
        reasons.append("没有 EvidenceIndex：无法证明结论有证据支撑")
        return {"final_verdict": RunFinalVerdict.INCONCLUSIVE, "evidence_complete": False,
                "blocked": False, "reasons": reasons}

    missing = list(evidence_index.get("missing") or [])
    unresolved = [str(u) for u in (evidence_index.get("unresolved") or []) if str(u).strip()]
    complete = bool(evidence_index.get("complete")) and not missing and not unresolved

    if missing:
        reasons.append(f"存在 {len(missing)} 项缺失证据")
    if unresolved:
        reasons.append(f"存在 {len(unresolved)} 项未解释现象")
    if rule_version and evidence_index.get("rule_version") and \
            evidence_index["rule_version"] != rule_version:
        complete = False
        reasons.append(f"规则版本不一致：索引={evidence_index['rule_version']} 本次={rule_version}")

    case_list = [str(v or "").upper() for v in case_verdicts]
    blocked = any(v == "BLOCKED" for v in case_list)
    if blocked:
        reasons.append("存在 BLOCKED 用例：前置条件未满足，本轮不结案")

    final = derive_final_verdict(case_list, evidence_complete=complete,
                                 unresolved=unresolved, aborted=aborted)
    if final is None:
        reasons.append("本轮不产生最终结论（前置受限或无法结案）")
    elif final is RunFinalVerdict.INCONCLUSIVE:
        reasons.append("证据不足以支撑断言，结论降级为 INCONCLUSIVE")
    else:
        reasons.append(f"证据完整且用例结论一致，最终结论 {final.value}")

    return {"final_verdict": final, "evidence_complete": complete,
            "blocked": blocked, "reasons": reasons}


__all__ = [
    "ASSERTIVE_VERDICTS",
    "VALID_CASE_VERDICTS",
    "VALID_FAILURE_CLASSES",
    "VerdictInvalid",
    "build_verdict_draft",
    "finalize",
]
