#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T4.4 报告生成：复用既有前端，不另起风格。

约束（来自专家包总原则）
------------------------
报告统一调用既有 `report_to_html.py`，并复用
`templates/uds_report_framework.html` 的原始展示框架。
**不得另起 v2 页面或改变原始 DOM/CSS 风格。**

因此本模块不生成任何 HTML，只做两件事：
1. 以子进程方式调用既有脚本（参数面与它自己的 `--help` 一致）；
2. 校验框架模板存在，缺了就明确报错，而不是退化成一个自造页面。
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from ..orchestrator.tools import CliResult, CliToolError, run_cli

REPORT_TO_HTML = "skills/uds-diagnostic-test/scripts/report_to_html.py"
FRAMEWORK_TEMPLATE = "skills/uds-diagnostic-test/templates/uds_report_framework.html"

STYLE_CONTRACT = (
    "报告必须复用 report_to_html.py + templates/uds_report_framework.html；"
    "时间轴只切换软件版本，同一版本内通过 modules[] 切换模块；"
    "不得另起 v2 页面或改变原始 DOM/CSS 风格。"
)


class ReportError(RuntimeError):
    """报告生成错误。"""


@dataclass(frozen=True)
class ReportResult:
    out_path: str
    cli: CliResult

    @property
    def ok(self) -> bool:
        return self.cli.returncode == 0 and os.path.isfile(self.out_path)


def package_root() -> str:
    """包根目录（脚本自定位，供 report_to_html 调用前的路径解析）。"""
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def template_path(root: str | None = None) -> str:
    """报告框架模板 uds_report_framework.html 的路径。"""
    return os.path.join(root or package_root(), *FRAMEWORK_TEMPLATE.split("/"))


def assert_framework_available(root: str | None = None) -> str:
    """确认既有报告框架在位。缺失即报错，不允许退化自造。"""
    path = template_path(root)
    if not os.path.isfile(path):
        raise ReportError(
            f"找不到报告框架模板：{path}。"
            "本项目禁止另起一套报告前端；请先恢复既有模板，或改用既有 report_to_html.py")
    return path


def render_report(*, out_path: str, results_path: str | None = None,
                  extra_path: str | None = None, swdl_report_path: str | None = None,
                  project_config: str = "", root: str | None = None,
                  timeout: float = 180.0) -> ReportResult:
    """调用既有 `report_to_html.py` 生成报告。

    参数与既有脚本的 `--help` 一一对应；不传就不带该开关，不做任何"补默认值"。
    """
    assert_framework_available(root)

    args: list[str] = []
    if results_path:
        args += ["--results", results_path]
    if extra_path:
        args += ["--extra", extra_path]
    if swdl_report_path:
        args += ["--swdl-report", swdl_report_path]
    if project_config:
        args += ["--project-config", project_config]
    args += ["--out", out_path]

    cli = run_cli(REPORT_TO_HTML, args, root=root or package_root(), timeout=timeout)
    if cli.returncode != 0:
        raise ReportError(
            f"report_to_html.py 退出码 {cli.returncode}："
            f"{(cli.stderr or cli.stdout).strip()[:400]}")
    if not os.path.isfile(out_path):
        raise ReportError(f"报告脚本返回 0 但没有产出文件：{out_path}")
    return ReportResult(out_path=out_path, cli=cli)


def describe_inputs() -> dict[str, Any]:
    """列出既有报告脚本接受的输入，供上层构造数据时对照。"""
    return {
        "results": "执行结果 JSON（results[] 含 verdict）",
        "extra": "附加报告数据 JSON（meta/versions/modules/links/evidence/blocked/timing/coverage/mapping/legend）",
        "swdl_report": "SWDL 执行报告 JSON；自动转换为统一报告输入",
        "project_config": "项目配置 JSON（可选）；决定短版本号展示前缀",
    }


__all__ = [
    "FRAMEWORK_TEMPLATE",
    "REPORT_TO_HTML",
    "STYLE_CONTRACT",
    "ReportError",
    "ReportResult",
    "assert_framework_available",
    "describe_inputs",
    "package_root",
    "render_report",
    "template_path",
]
