"""运行时证据层（T4 起）：ASC/XCT 解析、EvidenceIndex、VerdictDraft 与结论门槛、报告复用。"""
