#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T4.1 / T4.5 证据解析与索引原料。

**不重造解析器。** ASC / 文本 XCT 的逐帧解析与 LIN-TP 重组已由既有
`skills/uds-diagnostic-test/scripts/swdl_trace_import.py` 实现（含 `parse_trace`
与 `import_swdl_trace` 两个公开入口）。本模块只做三件事：

1. 把既有解析结果整理成 EvidenceIndex 需要的形状（绝对时间区间、关键帧）；
2. **二进制专有 XCT 明确 BLOCKED**（T4.5），不装作能解析；
3. 解析失败如实上报为缺失项，不静默丢弃。

绝对时间怎么来
--------------
ASC 头部有一行 `date Tue Sep 15 04:12:07.659 pm 2026`，帧时间戳是相对首帧的秒数。
两者相加即可得到真实墙钟区间 —— 这样「结论可定位到文件与**时间段**」才成立。
文本 XCT 没有头部，缺少绝对时间时如实标记为未知，不编造。
"""
from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Sequence

from ..orchestrator import hashchain as H
from . import canlog as _canlog
from . import lin_uds as _lin_uds

_SCRIPTS_REL = os.path.join("skills", "uds-diagnostic-test", "scripts")
_ASC_DATE_RX = re.compile(
    r"^\s*date\s+\w{3}\s+(?P<mon>\w{3})\s+(?P<day>\d{1,2})\s+"
    r"(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2})(?:\.(?P<ms>\d{1,6}))?\s*"
    r"(?P<ap>am|pm)?\s*(?P<year>\d{4})",
    re.IGNORECASE)
_MONTHS = {m: i for i, m in enumerate(
    ("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), start=1)}

SUPPORTED_SUFFIXES = (".asc", ".xct")


class EvidenceError(RuntimeError):
    """证据处理错误。"""


class BinaryEvidenceBlocked(EvidenceError):
    """二进制专有 XCT：默认 BLOCKED，不尝试解析。"""


@dataclass(frozen=True)
class ParsedEvidence:
    rel_path: str
    sha256: str
    source_format: str
    frame_count: int
    message_count: int
    first_ts: float
    last_ts: float
    started_at: datetime | None = None
    key_frames: tuple[dict[str, Any], ...] = ()
    unresolved: tuple[str, ...] = ()
    #: 该格式是否提供可用时间轴。ASC / CANLOG 均提供
    #:（CANLOG 第 1 字段是微秒级帧间增量，逐行累加成单调时间轴，
    #: 经团队工具 parse_xct v2 与 P2=50ms 物理约束交叉验证，2026-09-15 修正）。
    time_axis_available: bool = True

    @property
    def time_range(self) -> dict[str, str] | None:
        """绝对时间区间；无法确定时返回 None（不编造）。"""
        if self.started_at is None or not self.time_axis_available:
            return None
        return {
            "from": _iso(self.started_at + timedelta(seconds=self.first_ts)),
            "to": _iso(self.started_at + timedelta(seconds=self.last_ts)),
        }

    @property
    def duration_s(self) -> float:
        return max(0.0, self.last_ts - self.first_ts)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _package_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def load_trace_module():
    """按路径加载既有 `swdl_trace_import` 模块。找不到就明确报错。"""
    scripts = os.path.join(_package_root(), _SCRIPTS_REL)
    if not os.path.isdir(scripts):
        raise EvidenceError(f"找不到技能脚本目录：{scripts}")
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    try:
        import swdl_trace_import  # noqa: WPS433
    except ImportError as exc:
        raise EvidenceError(f"无法导入既有 ACE/XCT 解析器 swdl_trace_import：{exc}") from exc
    return swdl_trace_import


def looks_binary(path: str, *, sniff_bytes: int = 4096) -> bool:
    """二进制嗅探：NUL 字节或无法按 UTF-8 解码即视为二进制。"""
    try:
        with open(path, "rb") as fh:
            head = fh.read(sniff_bytes)
    except OSError:
        return False
    if b"\x00" in head:
        return True
    try:
        head.decode("utf-8")
    except UnicodeDecodeError:
        return True
    return False


def parse_asc_start_time(text_head: str) -> datetime | None:
    """从 ASC 头部解析测量起始墙钟时间。解析不出返回 None。"""
    for line in text_head.splitlines()[:40]:
        m = _ASC_DATE_RX.match(line)
        if not m:
            continue
        month = _MONTHS.get(m.group("mon").lower())
        if not month:
            return None
        hour = int(m.group("h")) % 12
        if (m.group("ap") or "").lower() == "pm":
            hour += 12
        ms = (m.group("ms") or "0").ljust(3, "0")[:3]
        try:
            naive = datetime(int(m.group("year")), month, int(m.group("day")),
                             hour, int(m.group("m")), int(m.group("s")), int(ms) * 1000)
        except ValueError:
            return None
        return naive.replace(tzinfo=timezone.utc)
    return None


def _read_head(path: str, *, limit: int = 8192) -> str:
    try:
        with open(path, "rb") as fh:
            return fh.read(limit).decode("utf-8", errors="replace")
    except OSError:
        return ""


def _key_frames(transactions: Sequence[dict[str, Any]], *, limit: int,
                master_id: int = 0x3C) -> tuple[dict[str, Any], ...]:
    """从既有解析器产出的 transactions 里挑关键帧。

    `transactions` 已经把请求与最终响应配好对（含 `elapsed_ms` 与原始行号），
    比自己去猜帧更可靠，也直接满足「结论可定位到文件与时间段」。
    """
    out: list[dict[str, Any]] = []
    for txn in transactions[:limit]:
        request = list(txn.get("request") or [])
        response = txn.get("response")
        response = list(response) if response is not None else None
        req_ts = txn.get("request_ts")
        resp_ts = txn.get("response_ts")

        note_parts: list[str] = []
        if request:
            note_parts.append(f"req SID=0x{request[0]:02X}")
        if response is None:
            note_parts.append("无响应")
        elif response and response[0] == 0x7F:
            nrc = response[2] if len(response) > 2 else None
            note_parts.append(f"resp 负响应 NRC=0x{nrc:02X}" if isinstance(nrc, int) else "resp 负响应")
        elif response:
            note_parts.append(f"resp SID=0x{response[0]:02X}")
        if txn.get("elapsed_ms") is not None:
            note_parts.append(f"elapsed={txn['elapsed_ms']}ms")
        lines = list(txn.get("request_frame_lines") or []) + list(txn.get("response_frame_lines") or [])
        if lines:
            note_parts.append(f"lines={lines}")

        at = f"{float(req_ts):.6f}s" if req_ts is not None else "?"
        if resp_ts is not None:
            at += f"-{float(resp_ts):.6f}s"

        out.append({
            "at": at,
            "direction": "tx",                       # 请求由主节点发出
            "frame_id": f"0x{master_id:02X}",
            "note": "；".join(note_parts)[:200],
        })
    return tuple(out)


def _evidence_from_canlog(rel_path: str, full: str, *,
                          master_id: int = 0x3C, slave_id: int = 0x3D,
                          key_frame_limit: int = 20,
                          nad: int | None = None) -> ParsedEvidence:
    """把 CANLOG 录制收敛成 ParsedEvidence。

    CANLOG 时间轴 = 第 1 字段（微秒级帧间增量）逐行累加（2026-09-15 修正，
    初版误判为位时间测量；判据见 canlog 模块 docstring）：
      * `time_axis_available=True`，`time_range` / `duration_s` 可用；
      * 关键帧同时带**源文件行号**（亚毫秒排序按行号）与累计时刻 `t_ms`；
      * 请求重发折叠为同一事务（`retries`），不虚增事务数。
    """
    trace = _canlog.parse_canlog(full)

    # 帧级 -> 服务级：经既有 lin_tp 重组出 UDS 事务（只增不改，复用能力层实现）。
    # 角色按 frame_id 判定，不依赖实测不可靠的 tx/rx 标签。
    payloads = [(f.line_no, f.frame_id, f.bus, f.data) for f in trace.frames]
    txs = _lin_uds.transactions(payloads, master_id=master_id, slave_id=slave_id,
                                nad=nad)
    line_to_t = {f.line_no: f.t_us for f in trace.frames}

    key_frames: list[dict[str, Any]] = []
    for t in txs[:key_frame_limit]:
        parts: list[str] = []
        if t.request:
            parts.append(f"req SID=0x{t.request[0]:02X}")
        else:
            parts.append("请求未重组成功")
        nrc = t.negative_response_code
        if nrc is not None:
            parts.append(f"resp 负响应 NRC=0x{nrc:02X}")
        elif t.response:
            parts.append(f"resp SID=0x{t.response[0]:02X}")
        elif t.pending_passed:
            parts.append("resp 仅 pending(0x78)")
        else:
            parts.append("无响应")
        if t.retries:
            parts.append(f"请求重发 {t.retries} 次（已折叠）")
        lines = list(t.request_lines) + list(t.response_lines)
        if lines:
            parts.append(f"lines={lines}")
        if t.note:
            parts.append(t.note)
        at = f"line {t.request_lines[0]}" if t.request_lines else "?"
        if t.response_lines:
            at += f"-{t.response_lines[-1]}"
        kf = {
            "at": at,
            "direction": "tx",             # 请求由主节点发出
            "frame_id": f"0x{master_id:02X}",
            "note": "；".join(parts)[:200],
        }
        tvals = [line_to_t[l] for l in lines if l in line_to_t]
        if tvals:
            kf["t_ms"] = round(tvals[0] / 1000.0, 3)
            if len(tvals) > 1:
                kf["t_ms_end"] = round(tvals[-1] / 1000.0, 3)
        key_frames.append(kf)

    unresolved = list(trace.notes)
    if not txs:
        unresolved.append("未重组出任何 UDS 事务：本文件不含 0x3C/0x3D 诊断帧")
    else:
        incomplete = sum(1 for t in txs if not t.complete)
        if incomplete:
            unresolved.append(
                f"{incomplete} / {len(txs)} 次请求未拿到响应，这些事务不能作为正/负响应证据")
    if trace.started_at is None:
        unresolved.append("文件头无 # date，只有相对时间轴，无法给出绝对时间区间")

    return ParsedEvidence(
        rel_path=rel_path,
        sha256=H.digest_file(full),
        source_format="canlog-xct",
        frame_count=trace.frame_count,
        message_count=sum(1 for t in txs if t.complete),
        first_ts=0.0,
        last_ts=trace.duration_us / 1_000_000.0,
        started_at=trace.started_at,
        key_frames=tuple(key_frames),
        unresolved=tuple(unresolved),
        time_axis_available=True,
    )


def load_evidence(rel_path: str, run_dir: str, *, master_id: int = 0x3C,
                  slave_id: int = 0x3D, key_frame_limit: int = 20,
                  nad: int | None = None) -> ParsedEvidence:
    """解析单个证据文件。失败一律抛错，绝不返回"空但成功"的结果。

    * 后缀不在 `.asc` / `.xct` 内 -> `EvidenceError`
    * 内容是二进制（专有 XCT）-> `BinaryEvidenceBlocked`（T4.5）
    * 帧解析出 0 帧 -> `EvidenceError`
    """
    full = os.path.join(run_dir, *rel_path.split("/"))
    if not os.path.isfile(full):
        raise EvidenceError(f"证据文件不存在：{rel_path}")

    suffix = os.path.splitext(full)[1].lower()
    if suffix not in SUPPORTED_SUFFIXES:
        raise EvidenceError(
            f"不支持的证据格式 {suffix or '<无后缀>'}；只接受 {list(SUPPORTED_SUFFIXES)}。"
            "二进制专有 XCT 请先导出为文本")
    if looks_binary(full):
        raise BinaryEvidenceBlocked(
            f"{rel_path} 看起来是二进制专有 XCT。该格式随厂商与版本变化，"
            "本项目**默认 BLOCKED**，不猜测布局；请先用工具导出为文本/ASC 后再作为证据")

    if _canlog.is_canlog(full):
        # 按**内容**分派，不看后缀：上位机默认录的就是 CANLOG，
        # 而既有解析器只认 SWDL 版语法（实测全部 TraceImportError）。
        return _evidence_from_canlog(rel_path, full, master_id=master_id,
                                     slave_id=slave_id, key_frame_limit=key_frame_limit, nad=nad)

    mod = load_trace_module()
    try:
        payload = mod.import_swdl_trace(full, master_id=master_id, slave_id=slave_id)
    except mod.TraceImportError as exc:
        raise EvidenceError(f"{rel_path} 解析失败：{exc}") from exc
    except Exception as exc:                     # 解析器内部异常也要如实上报
        raise EvidenceError(f"{rel_path} 解析异常：{type(exc).__name__}: {exc}") from exc

    frames = payload.get("frames") or []
    if not frames:
        raise EvidenceError(f"{rel_path} 未解析出任何帧；此类文件不能作为证据")

    ts_values = [float(f["ts"]) for f in frames]
    transactions = payload.get("transactions") or []
    started_at = parse_asc_start_time(_read_head(full)) if suffix == ".asc" else None

    unresolved: list[str] = []
    if started_at is None:
        unresolved.append("缺少绝对时间锚点（XCT 文本无头部日期），只能按相对时间定位")

    return ParsedEvidence(
        rel_path=rel_path,
        sha256=H.digest_file(full),
        source_format=str(payload.get("provenance", {}).get("source_format", "")),
        frame_count=len(frames),
        message_count=int(payload.get("message_count", 0) or 0),
        first_ts=min(ts_values),
        last_ts=max(ts_values),
        started_at=started_at,
        key_frames=_key_frames(transactions, limit=key_frame_limit, master_id=master_id),
        unresolved=tuple(unresolved),
    )


def load_many(rel_paths: Iterable[str], run_dir: str, *, master_id: int = 0x3C,
              slave_id: int = 0x3D) -> tuple[list[ParsedEvidence], list[tuple[str, str]]]:
    """批量解析。返回 (成功列表, [(路径, 原因)])，失败项不抛断整批。"""
    ok: list[ParsedEvidence] = []
    bad: list[tuple[str, str]] = []
    for rel in rel_paths:
        try:
            ok.append(load_evidence(rel, run_dir, master_id=master_id, slave_id=slave_id))
        except EvidenceError as exc:
            bad.append((rel, str(exc)))
    return ok, bad


__all__ = [
    "BinaryEvidenceBlocked",
    "EvidenceError",
    "ParsedEvidence",
    "SUPPORTED_SUFFIXES",
    "load_evidence",
    "load_many",
    "load_trace_module",
    "looks_binary",
    "parse_asc_start_time",
]
