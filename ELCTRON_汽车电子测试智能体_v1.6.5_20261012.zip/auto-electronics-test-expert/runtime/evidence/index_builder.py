#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T4.2 EvidenceIndex 生成。

三条纪律
--------
1. **与 manifest 对账**：证据的 sha256 必须与 RunManifest 里记录的一致。
   不一致说明文件在封存后被改过，直接记为缺失 + 未解释项，而不是照单全收。
2. **缺失必须显式列出**。有缺失项时 `complete` 强制为 false（契约层的 allOf 约束也会兜住）。
3. **索引不可覆盖**。已存在索引时默认拒绝重写；要重来必须显式传 `allow_replace=True`，
   并把旧索引留档。结论依赖的索引被悄悄改写，等于证据链失效。
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

from ..contracts import validation
from ..orchestrator import hashchain as H
from .asc_index import EvidenceError, load_evidence

INDEX_NAME = "evidence_index.json"


class IndexInvalid(ValueError):
    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__("EvidenceIndex 不合规（%d 项）：%s" % (len(errors), "；".join(errors[:5])))


class IndexExists(FileExistsError):
    """索引已存在。默认不允许覆盖。"""


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def build_evidence_index(*, run_id: str, manifest: Mapping[str, Any], run_dir: str,
                         rule_version: str, generated_at: datetime | None = None,
                         required_cases: Sequence[str] = (),
                         case_evidence_map: Mapping[str, Sequence[str]] | None = None,
                         master_id: int = 0x3C, slave_id: int = 0x3D) -> dict[str, Any]:
    """由 RunManifest 的 captures 构建 EvidenceIndex。"""
    captures = list(manifest.get("captures") or [])
    entries: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    unresolved: list[str] = []

    for index, cap in enumerate(captures):
        rel = str(cap.get("path", ""))
        expected_sha = str(cap.get("sha256", ""))
        evidence_id = f"EV-{index + 1:03d}"
        try:
            parsed = load_evidence(rel, run_dir, master_id=master_id, slave_id=slave_id)
        except EvidenceError as exc:
            missing.append({"required_for": run_id, "reason": f"{rel}：{exc}",
                            "expected_kind": cap.get("kind") if cap.get("kind") in
                            ("asc", "xct_text", "response", "trace_json") else "asc"})
            continue

        if expected_sha and parsed.sha256 != expected_sha:
            # 封存后被改动 —— 既算缺失也算未解释项，绝不静默通过
            missing.append({"required_for": run_id,
                            "reason": f"{rel}：磁盘摘要与 RunManifest 记录不一致，文件在封存后被改动",
                            "expected_kind": "asc"})
            unresolved.append(f"{rel}：manifest={expected_sha[:12]}… disk={parsed.sha256[:12]}…")
            continue

        entry: dict[str, Any] = {
            "evidence_id": evidence_id,
            "kind": _kind_of(cap.get("kind")),
            "path": rel,
            "sha256": parsed.sha256,
            "immutable": True,
        }
        time_range = parsed.time_range
        if time_range:
            entry["time_range"] = time_range
        else:
            unresolved.append(f"{rel}：无绝对时间锚点，仅能按相对时间定位")
        if parsed.key_frames:
            entry["key_frames"] = [dict(k) for k in parsed.key_frames]
        covered = _covers(evidence_id, case_evidence_map)
        if covered:
            entry["covers_cases"] = covered
        entries.append(entry)

    for case_id in required_cases:
        if not any(case_id in (e.get("covers_cases") or []) for e in entries):
            missing.append({"required_for": case_id,
                            "reason": "没有任何证据条目声明覆盖该用例",
                            "expected_kind": "asc"})

    if not entries:
        # 没有任何可用证据条目 —— 无论 captures 是否为空，都必须判为不完整。
        # "没有证据"绝不能被当成"没有缺失"。
        reason = ("captures 为空：本 run 没有采集到任何证据"
                  if not captures else "所有 captures 都无法解析，本 run 没有可用证据")
        missing.append({"required_for": run_id, "reason": reason, "expected_kind": "asc"})
        unresolved.append(reason)

    index: dict[str, Any] = {
        "schema_version": "evidence-index/v0.1",
        "run_id": run_id,
        "rule_version": rule_version,
        "generated_at": _iso(generated_at or datetime.now(timezone.utc)),
        "generated_by": "evidence_worker",
        "entries": entries,
        "missing": missing,
        "complete": not missing,
    }
    if unresolved:
        index["unresolved"] = unresolved

    errors = validation.report("evidence-index/v0.1", index)
    if errors:
        raise IndexInvalid(errors)
    return index


def _kind_of(capture_kind: Any) -> str:
    kind = str(capture_kind or "asc")
    return kind if kind in ("asc", "xct_text", "response", "trace_json") else "asc"


def _covers(evidence_id: str, mapping: Mapping[str, Sequence[str]] | None) -> list[str]:
    if not mapping:
        return []
    return sorted(case for case, ids in mapping.items() if evidence_id in set(ids))


def write_index(run_dir: str, index: Mapping[str, Any], *, allow_replace: bool = False) -> str:
    """写 `04_evidence/evidence_index.json`。已存在时默认拒绝覆盖。"""
    errors = validation.report("evidence-index/v0.1", index)
    if errors:
        raise IndexInvalid(errors)
    rel = f"04_evidence/{INDEX_NAME}"
    full = os.path.join(run_dir, *rel.split("/"))
    if os.path.exists(full) and not allow_replace:
        raise IndexExists(f"证据索引已存在，拒绝覆盖：{full}（确需重建请显式传 allow_replace=True）")
    os.makedirs(os.path.dirname(full), exist_ok=True)
    if allow_replace and os.path.exists(full):
        archive = full + ".previous"
        os.replace(full, archive)
    with open(full, "w", encoding="utf-8") as fh:
        json.dump(index, fh, ensure_ascii=False, indent=2, sort_keys=True)
    return rel


def read_index(run_dir: str) -> dict[str, Any]:
    """从 run 目录读 evidence_index.json；缺失抛 EvidenceError。"""
    full = os.path.join(run_dir, "04_evidence", INDEX_NAME)
    if not os.path.isfile(full):
        raise FileNotFoundError(f"运行目录里没有 EvidenceIndex：{full}")
    with open(full, encoding="utf-8") as fh:
        return json.load(fh)


def verify_index(run_dir: str, index: Mapping[str, Any]) -> list[str]:
    """重算条目哈希，确认索引指向的文件没有被改动。"""
    records = [H.ArtifactRecord(path=str(e["path"]), sha256=str(e["sha256"])) for e in index.get("entries", [])]
    return H.verify(records, run_dir=run_dir)


__all__ = [
    "INDEX_NAME",
    "IndexExists",
    "IndexInvalid",
    "build_evidence_index",
    "read_index",
    "verify_index",
    "write_index",
]
