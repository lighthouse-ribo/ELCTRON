#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""LIN-TP 重组：帧序列 → UDS 事务。

为什么需要它
------------
`canlog.py` 把真实录制解析到**帧级**，但结论需要**服务级**：哪个 SID、哪个 DID、
正响应还是 NRC。没有重组，证据链就停在"抓到了帧"，M4 门禁（缺证据不可能 PASS）
也就无从落地。

本模块把帧序列重组成事务，并经 `asc_index` 进入 `EvidenceIndex`。
**不重写重组算法** —— 直接复用既有 `skills/uds-diagnostic-test/scripts/lin_tp.py`
的 `parse_frame` / `assemble`（能力层只增不改）。

三条规则全部来自真实录制的观察，不是规范推演
--------------------------------------------
1. **空帧不参与重组。** 实测 `CANLOG_260909_100454_064.xct` 里一次请求后面夹着
   **19 个 `0x3D` 空帧**（`dlc=0`，`kind=ao`）。它们是"主机发了头但没收到数据"的
   占位记录，不带任何字节。
2. **不使用 `tx` / `rx` 标签判定角色。** 实测同一个 `0x3D` **数据帧既有 `tx` 也有 `rx`**，
   标签不可靠。角色一律按 `frame_id` 判定：`master_id`（默认 0x3C）是请求，
   `slave_id`（默认 0x3D）是响应。所以本模块的输入**根本不带方向字段**。
3. **分组边界靠请求帧。** 一次请求开启一个事务；其后、下一个请求之前的非空响应帧
   归属它。多帧请求只在"上一组是未收齐的 FF"时才继续并入，避免把两次独立请求
   误并成一个事务。

⚠️ 无法做到的事（如实标注）
--------------------------
**CANLOG 没有时间轴**（见 `canlog.py`），因此 `lin_tp.analyze_trace()` 用不了：
P2 / P2* 时序、帧隙抖动这些指标**无法从 CANLOG 得出**。要时序证据必须改录 ASC 格式
（既有 ASC 解析器认，且带真实时间戳）。本模块不猜时序，也不给任何时间字段。
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from typing import Iterable, Sequence

__all__ = [
    "LinUdsError",
    "UdsTransaction",
    "transactions",
]

_SCRIPTS_REL = os.path.join("skills", "uds-diagnostic-test", "scripts")
_LIN_TP = None


class LinUdsError(RuntimeError):
    """重组层错误。"""


def load_lin_tp():
    """按路径加载既有 `lin_tp` 模块；找不到就明确报错，不静默退化成自造实现。"""
    global _LIN_TP
    if _LIN_TP is not None:
        return _LIN_TP
    pkg = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    scripts = os.path.join(pkg, _SCRIPTS_REL)
    if not os.path.isdir(scripts):
        raise LinUdsError(f"找不到技能脚本目录：{scripts}")
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    try:
        import lin_tp  # noqa: WPS433
    except ImportError as exc:
        raise LinUdsError(f"无法导入既有 LIN-TP 实现 lin_tp：{exc}") from exc
    _LIN_TP = lin_tp
    return lin_tp


@dataclass(frozen=True)
class UdsTransaction:
    """一次 UDS 事务（请求 + 可能的响应）。"""

    index: int
    request_lines: tuple[int, ...]
    request: tuple[int, ...] | None
    response_lines: tuple[int, ...]
    response: tuple[int, ...] | None
    pending_passed: bool = False
    note: str = ""
    #: 请求重发次数（同一请求在收到最终响应前被重发 N 次，折叠为一个事务；
    #: 与团队参考实现 parse_xct v2 的 retries 语义一致）。
    retries: int = 0

    @property
    def complete(self) -> bool:
        return self.request is not None and self.response is not None

    @property
    def request_sid(self) -> int | None:
        return self.request[0] if self.request else None

    @property
    def response_sid(self) -> int | None:
        return self.response[0] if self.response else None

    @property
    def negative_response_code(self) -> int | None:
        """负响应（0x7F SID NRC）时的 NRC；不是负响应返回 None。"""
        r = self.response
        if r and len(r) >= 3 and r[0] == 0x7F:
            return r[2]
        return None


def _is_pending_frame(parsed) -> bool:
    """`parsed` 是 lin_tp.parse_frame 的输出元组。识别 0x7F xx 78（响应未就绪）。"""
    if parsed[0] != "sf":
        return False
    payload = parsed[3]
    return len(payload) >= 3 and payload[0] == 0x7F and payload[2] == 0x78


def _multiframe_open(frames: Sequence[tuple[int, ...]]) -> bool:
    """这一组是不是"多帧起始但还没收齐"（只有这种情况才允许并入下一帧）。"""
    if not frames:
        return False
    lin = load_lin_tp()
    parsed = lin.parse_frame(bytes(frames[0]))
    if parsed[0] != "ff":
        return False
    total = parsed[4]
    have = len(parsed[3]) + 6 * (len(frames) - 1)
    return have < total


def _reassemble(frames: Sequence[tuple[int, ...]]):
    """返回 (payload | None, pending_passed, error)。error: '' / 'pending' / 'sequence' / 'invalid'。

    区分 `sequence` 与 `invalid` 很重要：实测 `CANLOG_260610_103946.xct` 在 0x3C 上
    出现过 `00 FF FF FF FF FF FF FF`（NAD=0x00 / PCI=0xFF）—— 那**不是**序号问题，
    而是这压根不是一条 UDS 请求。如实报 `invalid`，不把无关流量误报成"重组失败"。
    """
    lin = load_lin_tp()
    idx = 0
    pending = False
    while idx < len(frames):
        if _is_pending_frame(lin.parse_frame(bytes(frames[idx]))):
            pending = True
            idx += 1
            continue
        break
    if idx >= len(frames):
        return None, pending, "pending"
    rest = [lin.parse_frame(bytes(f)) for f in frames[idx:]]
    if rest[0][0] not in ("sf", "ff"):
        return None, pending, "invalid"
    payload = lin.assemble(rest)
    if payload is None:
        return None, pending, "sequence"
    if payload == b"PENDING":
        return None, True, "pending"
    return tuple(payload), pending, ""


def _note_for(request_error: str, response_error: str, has_response: bool) -> str:
    if request_error == "invalid":
        return "该帧不是 UDS 请求：NAD/PCI 非法（既非单帧也非首帧），属诊断帧 ID 上的其它流量"
    if request_error == "sequence":
        return "请求帧序号不连续，请求本体重组失败（不得当作有效请求）"
    if request_error == "pending":
        return "请求侧只见到 pending，无有效请求本体"
    if response_error == "invalid":
        return "响应首帧 NAD/PCI 非法，无法重组（不得当作有效响应）"
    if response_error == "sequence":
        return "响应帧序号不连续，重组失败（序号跳变），不得当作有效响应"
    if response_error == "pending":
        return "仅收到 0x78 pending，最终响应未出现（pending）"
    if not has_response:
        return "请求后未收到任何非空响应帧（无响应）"
    return ""


def transactions(frames: Iterable[tuple[int, int, str, Sequence[int]]], *,
                 master_id: int = 0x3C, slave_id: int = 0x3D,
                 bus: str = "lin", nad: int | None = None) -> tuple[UdsTransaction, ...]:
    """把帧序列重组成 UDS 事务。

    `frames` 每项为 `(line_no, frame_id, bus, data)`：
      * `line_no` 源文件行号（CANLOG 无时间轴，行号是唯一可靠定位手段）；
      * `data` 含 NAD + PCI + 载荷的完整帧字节；
      * **不提供方向**——实测 tx/rx 标签不可靠，角色由 frame_id 决定。

    `nad`：目标从节点的 NAD 过滤。LIN 诊断帧 ID（0x3C/0x3D）是**总线级**的，
    载荷首字节（NAD）决定目标 ECU —— 同一录制里会混有发往其它节点的流量
    （实测 260709_210504.xct：0x3C 上 78779 帧 NAD=0x51、14 帧 NAD=0x7E）。
    传 `nad=0x51` 只保留该节点的事务；默认 `None` 不过滤。
    **NAD 是项目分配值，本层不设默认** —— 由调用方（项目配置）传入。
    """
    bus_key = str(bus).lower()
    groups: list[dict] = []
    cur: dict | None = None

    for item in frames:
        line_no, frame_id, bus_name, data = item[0], item[1], item[2], item[3]
        if str(bus_name).lower() != bus_key:
            continue
        payload = tuple(data)
        if not payload:
            continue                                     # 规则 1：空帧不参与
        if nad is not None and payload[0] != nad:
            continue                                     # 其它节点的流量，不进本节点事务
        if frame_id == master_id:
            if cur is not None and not cur["rsp"] and _multiframe_open(
                    [f for _l, f in cur["req"]]):
                cur["req"].append((line_no, payload))
            else:
                cur = {"req": [(line_no, payload)], "rsp": []}
                groups.append(cur)
        elif frame_id == slave_id and cur is not None:
            cur["rsp"].append((line_no, payload))

    out: list[dict] = []
    for i, g in enumerate(groups):
        req_frames = [f for _l, f in g["req"]]
        req_lines = tuple(l for l, _f in g["req"])
        req, _rp, req_err = _reassemble(req_frames)

        rsp_frames = [f for _l, f in g["rsp"]]
        rsp_lines = tuple(l for l, _f in g["rsp"])
        if rsp_frames:
            rsp, pending, rsp_err = _reassemble(rsp_frames)
        else:
            rsp, pending, rsp_err = None, False, ""

        entry = {
            "index": i, "req_lines": req_lines, "req": req,
            "rsp_lines": rsp_lines if rsp is not None else (),
            "rsp": rsp, "pending": pending,
            "note": _note_for(req_err, rsp_err, bool(rsp_frames)),
            "retries": 0,
            # 折叠还要求同 NAD：不同节点的相同载荷是两次独立请求，不是重发
            "nad0": req_frames[0][0] if req_frames else None,
        }
        # 请求重发折叠：上一事务尚未收到最终响应、且本事务请求 payload 与之相同
        # → 是重发，不是新事务（与参考实现 parse_xct v2 语义一致）。
        # 响应与行号以后到的组为准（谁最终应答用谁），行号保留全部用于追溯。
        if (out and out[-1]["req"] is not None and entry["req"] is not None
                and out[-1]["rsp"] is None and entry["req"] == out[-1]["req"]
                and entry["nad0"] == out[-1]["nad0"]):
            prev = out[-1]
            prev["retries"] += 1
            prev["req_lines"] = prev["req_lines"] + entry["req_lines"]
            prev["rsp_lines"] = entry["rsp_lines"]
            prev["rsp"] = entry["rsp"]
            prev["pending"] = entry["pending"]
            prev["note"] = entry["note"]
            continue
        out.append(entry)

    return tuple(UdsTransaction(
        index=n,
        request_lines=e["req_lines"],
        request=e["req"],
        response_lines=e["rsp_lines"],
        response=e["rsp"],
        pending_passed=e["pending"],
        note=e["note"],
        retries=e["retries"],
    ) for n, e in enumerate(out))
