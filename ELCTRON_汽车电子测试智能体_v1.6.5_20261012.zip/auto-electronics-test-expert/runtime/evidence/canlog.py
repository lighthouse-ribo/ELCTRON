#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""VickCAN CANLOG（`###CDXCAN`）文本录制解析器。

为什么单独写一个
----------------
既有 `swdl_trace_import.parse_trace` 认的是 SWDL 版 XCT / ASC 语法。实测（2026-09-15）：
把上位机真实录制 `RECORD\\CANLOG_*.xct` 交给它，**全部抛 `TraceImportError`**：

    TraceImportError: 未识别到可验证的时间戳、方向、ID、DLC 和数据字节帧

也就是说证据层此前在**夹具上全绿、在真实证据上全失败**。本模块补上这一格式，
不改动能力层的任何文件（只增不改）。

实测格式（128 个真实文件交叉验证）
--------------------------------
    ###CDXCAN
    # version = 2.0
    # app = VickCAN,2.37            （也有 3.10）
    # date = 2026-6-9,16:50:14-269  （日期,时:分:秒-毫秒）
    # brval,1=250000,0              （每通道一个，可能缺）
    # bsts = 45514                  （部分文件才有）
    <数据行>

数据行有两个变体（**必须都支持**）：

    VickCAN 2.37 : <dt> <ch> <id> <bus> <dir> <dlc>, <data…>
                   55572 1 22 lin tx  0,
                    58541 1 22 lin rx  4, 28 F0 00 00
    VickCAN 3.10 : <dt> <ch> <id> <bus> <dir> <kind> <dlc>, <data…>
                   236966 1 3C lin tx cl  8,  51 03 22 D0 3A FF FF FF

同一文件里可能混入 CAN 总线行（bus 不是 `lin`，帧 ID 可带后缀字母，
如 `100s hs tx 8, ...`）。这些行**跳过并计数**（与团队工具 parse_xct v2 一致），
不做诊断解析，但 dt 仍参与时间轴累加。

`kind` 取值实测有 `wa` / `cl` / `ao`。**语义未经验证**，本模块原样保留、不解释、
不参与任何判定。

第 1 字段是微秒级帧间增量（2026-09-15 修正）
--------------------------------------------
**本节推翻本模块初版的错误结论**（初版曾断言它是"每帧位时间测量值、无时间轴"）。

第 1 字段是**相对上一数据行的增量时间，单位微秒（µs）**；逐行累加即得单调时间轴。
判据（交叉验证，非推测）：

  1. 团队参考实现 `lin_uds_tool(1)/analysis/parse_xct.py` v2 采用同一语义
     （`t += int(dt)`），其事务重组结果与本模块对 128 个真实文件一致；
  2. 物理约束检验：单帧响应事务的「请求->响应」累加差 p50 = 22454，
     按 **µs** 解释 = 22.4 ms —— 与 P2=50 ms、LIN 调度节奏吻合；
     按初版主张的 **ns** 解释 = 22 µs —— 一次 LIN 帧传输本身就要约 1.77 ms
     （19200 bps），物理上不可能；
  3. 初版的「22865 次递减 → 不是时间戳」推理错在把**增量序列**当**绝对时间戳**
     检验单调性——增量本来就不需要单调。

因此 CANLOG **有可用时间轴**：
  * 帧级时刻 = 文件头 `# date` + 该帧累计 `t_us`（µs 精度）；
  * `time_axis_available=True`，`duration_us` / `end_at` 可直接使用；
  * dt 为 0 的行表示与上一行同刻（亚精度排序仍按行号）。

时区沿用既有 ASC 解析的约定（`# date` 视为 UTC），以便与既有一致；这是既有口径，
不在本模块内改变。
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

__all__ = [
    "CANLOG_MAGIC",
    "CanlogError",
    "CanlogFrame",
    "CanlogTrace",
    "is_canlog",
    "parse_canlog",
]

CANLOG_MAGIC = "###CDXCAN"
MAGIC_SNIFF_BYTES = 64
NOTE_TIME_AXIS = (
    "CANLOG 时间轴 = 第 1 字段（微秒级帧间增量）逐行累加；帧时刻 = 文件头 # date + 累计 t_us；"
    "dt=0 的行与上一行同刻，亚毫秒排序按行号"
)
NOTE_KIND_UNVERIFIED = (
    "数据行含帧类型标记（wa/cl/ao 等），其语义未经验证，原样保留且不参与判定"
)


class CanlogError(RuntimeError):
    """CANLOG 解析错误。一律显式抛出，绝不返回"空但成功"的结果。"""


_HEADER_TX = re.compile(
    r"^\s*#\s*(?P<key>[A-Za-z_]+)\s*=\s*(?P<val>.*?)\s*$"
)
_BRVAL_TX = re.compile(
    r"^\s*#\s*brval\s*,\s*(?P<ch>\d+)\s*=\s*(?P<val>[^,]*)\s*(?:,\s*(?P<flag>\S*))?\s*$"
)
_DATE_TX = re.compile(
    r"^\s*#\s*date\s*=\s*(?P<y>\d{4})-(?P<mo>\d{1,2})-(?P<d>\d{1,2})\s*,"
    r"\s*(?P<h>\d{1,2}):(?P<mi>\d{1,2}):(?P<s>\d{1,2})\s*-\s*(?P<ms>\d{1,3})\s*$"
)
# 数据行：帧 ID 允许带一个后缀字母（实测 CAN 行 `100s hs tx ...`）。
_DATA_TX = re.compile(
    r"^\s*(?P<t>\d+)\s+(?P<ch>\d+)\s+(?P<id>[0-9A-Fa-f]{1,8})[A-Za-z]?\s+"
    r"(?P<bus>[A-Za-z][A-Za-z0-9_\-]*)\s+(?P<dir>tx|rx)\s+"
    r"(?:(?P<kind>[a-z]{1,4})\s+)?"
    r"(?P<dlc>\d+)\s*,\s*(?P<data>[0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2})*)?\s*$"
)


@dataclass(frozen=True)
class CanlogFrame:
    """一条录制帧（仅 LIN 总线行进入 frames；CAN 等其它总线行跳过计数）。

    `dt_us` 是第 1 字段原值（相对上一数据行的增量，微秒）；`t_us` 是从文件头
    累加得到的单调时间轴（微秒）。时间轴语义经团队工具 parse_xct v2 与物理
    约束双重交叉验证（见模块 docstring），可作为时序证据使用。
    """

    index: int
    line_no: int
    dt_us: int
    t_us: int
    channel: int
    frame_id: int
    bus: str
    direction: str
    kind: str
    dlc: int
    data: tuple[int, ...]


@dataclass(frozen=True)
class CanlogTrace:
    path: str
    version: str = ""
    app: str = ""
    started_at: datetime | None = None
    brvals: dict[int, int] = field(default_factory=dict)
    frames: tuple[CanlogFrame, ...] = ()
    skipped_non_lin: int = 0
    notes: tuple[str, ...] = ()

    @property
    def frame_count(self) -> int:
        return len(self.frames)

    @property
    def time_axis_available(self) -> bool:
        """CANLOG 有可用时间轴（dt 累加，µs 精度）。"""
        return True

    @property
    def duration_us(self) -> int:
        """录制时长（微秒）；空 trace 为 0。"""
        return self.frames[-1].t_us if self.frames else 0

    @property
    def end_at(self) -> datetime | None:
        """录制结束时刻 = 文件头时刻 + 时长；无起始锚点时为 None。"""
        if self.started_at is None:
            return None
        return self.started_at + timedelta(microseconds=self.duration_us)

    def by_id(self) -> dict[int, int]:
        """按帧 ID 统计条数，便于快速核对抓到了哪些 ID。"""
        out: dict[int, int] = {}
        for f in self.frames:
            out[f.frame_id] = out.get(f.frame_id, 0) + 1
        return out

    def diagnostic_frames(self, master_id: int = 0x3C,
                          slave_id: int = 0x3D) -> tuple[CanlogFrame, ...]:
        """只取 LIN 诊断帧（默认主请求 0x3C / 从响应 0x3D）。"""
        return tuple(f for f in self.frames
                     if f.bus.lower() == "lin" and f.frame_id in (master_id, slave_id))


def _sniff(path: str) -> str:
    try:
        with open(path, "rb") as fh:
            head = fh.read(MAGIC_SNIFF_BYTES)
    except OSError:
        return ""
    return head.decode("utf-8", errors="replace")


def is_canlog(path: str) -> bool:
    """按内容判定（不看后缀）：首行是否为 `###CDXCAN`。"""
    return _sniff(path).lstrip("\ufeff \t\r\n").startswith(CANLOG_MAGIC)


def _parse_date(text: str) -> datetime | None:
    m = _DATE_TX.match(text)
    if not m:
        return None
    ms = (m.group("ms") or "0").ljust(3, "0")[:3]
    try:
        naive = datetime(int(m.group("y")), int(m.group("mo")), int(m.group("d")),
                         int(m.group("h")), int(m.group("mi")), int(m.group("s")),
                         int(ms) * 1000)
    except ValueError:
        return None
    return naive.replace(tzinfo=timezone.utc)


def parse_canlog(path: str) -> CanlogTrace:
    """解析一个 CANLOG 文本录制。

    失败一律抛 `CanlogError`，包括：缺魔数、零帧、LIN 数据行语法错、
    DLC 与字节数不一致。非 LIN 总线行跳过并计数（`skipped_non_lin`）。
    """
    if not os.path.isfile(path):
        raise CanlogError(f"文件不存在：{path}")

    version = app = ""
    started_at: datetime | None = None
    brvals: dict[int, int] = {}
    frames: list[CanlogFrame] = []
    saw_kind = False
    saw_magic = False
    skipped_non_lin = 0
    t_us = 0

    try:
        with open(path, encoding="utf-8", errors="strict") as fh:
            for line_no, raw in enumerate(fh, 1):
                line = raw.rstrip("\r\n")
                if not line.strip():
                    continue
                if not saw_magic:
                    if line.lstrip("\ufeff \t").startswith(CANLOG_MAGIC):
                        saw_magic = True
                        continue
                    raise CanlogError(
                        f"{path} 不是 CANLOG 录制：首行应为 {CANLOG_MAGIC!r}，"
                        f"实际为 {line.strip()[:40]!r}")
                if line.lstrip().startswith("#"):
                    stripped = line.strip()
                    if stripped.startswith("# brval"):
                        bm = _BRVAL_TX.match(line)
                        if bm:
                            try:
                                brvals[int(bm.group("ch"))] = int(bm.group("val"))
                            except ValueError:
                                pass
                        continue
                    if stripped.startswith("# date"):
                        started_at = _parse_date(line)
                        continue
                    hm = _HEADER_TX.match(line)
                    if hm:
                        key = hm.group("key").lower()
                        if key == "version":
                            version = hm.group("val")
                        elif key == "app":
                            app = hm.group("val")
                    continue

                dm = _DATA_TX.match(line)
                if not dm:
                    raise CanlogError(
                        f"{path} 第 {line_no} 行不是合法 CANLOG 数据行：{line.strip()[:80]!r}")
                # 时间轴对**所有**总线行累加（同一时钟）；诊断解析只针对 lin 行。
                t_us += int(dm.group("t"))
                bus = dm.group("bus").lower()
                if bus != "lin":
                    skipped_non_lin += 1
                    continue
                dlc = int(dm.group("dlc"))
                data_text = (dm.group("data") or "").strip()
                data = tuple(int(b, 16) for b in data_text.split()) if data_text else ()
                if len(data) != dlc:
                    raise CanlogError(
                        f"{path} 第 {line_no} 行 DLC 与字节数不一致："
                        f"DLC={dlc} 实际 {len(data)} 字节")
                kind = dm.group("kind") or ""
                if kind:
                    saw_kind = True
                frames.append(CanlogFrame(
                    index=len(frames),
                    line_no=line_no,
                    dt_us=int(dm.group("t")),
                    t_us=t_us,
                    channel=int(dm.group("ch")),
                    frame_id=int(dm.group("id"), 16),
                    bus=bus,
                    direction=dm.group("dir").lower(),
                    kind=kind,
                    dlc=dlc,
                    data=data,
                ))
    except UnicodeDecodeError as exc:
        raise CanlogError(
            f"{path} 不是文本 CANLOG（UTF-8 解码失败 @ {exc.start}）；"
            "二进制专有 XCT 请先用工具导出为文本") from exc

    if not saw_magic:
        raise CanlogError(f"{path} 是空文件或缺少 {CANLOG_MAGIC!r} 魔数")
    if not frames:
        raise CanlogError(f"{path} 未解析出任何帧；此类文件不能作为证据")

    notes: list[str] = [NOTE_TIME_AXIS]
    if saw_kind:
        notes.append(NOTE_KIND_UNVERIFIED)
    if skipped_non_lin:
        notes.append(f"跳过 {skipped_non_lin} 条非 LIN 总线数据行（CAN 等），不做诊断解析")
    if started_at is None:
        notes.append("缺少绝对时间锚点（文件头无 # date），只能提供相对时间轴")

    return CanlogTrace(
        path=path,
        version=version,
        app=app,
        started_at=started_at,
        brvals=brvals,
        frames=tuple(frames),
        skipped_non_lin=skipped_non_lin,
        notes=tuple(notes),
    )


if __name__ == "__main__":
    import sys

    for target in sys.argv[1:]:
        tr = parse_canlog(target)
        ids = ", ".join(f"0x{i:02X}×{n}" for i, n in sorted(tr.by_id().items()))
        print(f"{os.path.basename(target)}: {tr.frame_count} 帧  "
              f"app={tr.app}  start={tr.started_at}  时长={tr.duration_us / 1e6:.3f}s  "
              f"跳过非LIN={tr.skipped_non_lin}")
        print(f"  帧 ID: {ids}")
