"""Renderer implementations for platform-neutral test specifications."""
