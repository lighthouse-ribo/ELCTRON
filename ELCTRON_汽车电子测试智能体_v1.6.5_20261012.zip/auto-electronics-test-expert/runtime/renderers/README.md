# CANoe renderer boundary

`TestCaseSpec` is the single, platform-neutral UDS case contract emitted by the
writer agent. Renderers consume that contract:

- `vickcan-python` keeps using the existing Python generator contract;
- `canoe-capl` renders a CAPL Test Unit which delegates UDS traffic to a
  project-owned common CAPL library (`ELCTRON_UDS_Common.can`).

The CAPL renderer must not reimplement ISO-TP, diagnostic session handling,
security access, timing, or bus access. Those details already belong to the
existing diagnostic assets and the selected CANoe configuration.

`runtime.executor.canoe.CanoeControlPlane` is deliberately control-plane only:
it can probe a pre-existing COM object and build an explicit managed-run plan,
but cannot launch CANoe, open a configuration, compile CAPL, start measurement,
or send diagnostic traffic. A future real execution binding needs a reviewed
CANoe `.cfg`/`.can` configuration, target qualifier, report directory, and the
normal runtime approval/lease/preflight path.
