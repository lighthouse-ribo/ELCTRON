#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.8 审批令牌：高风险动作的授权载体与校验器。

红线 R6：SWDL / 写 DID / 分区切换必须有人工 approval token，
且令牌绑定 **run_id + 动作 + 范围 + 有效期**。本模块把这条红线变成可执行校验。

三条不可让步的性质
------------------
1. **人工签发**。`approved_by` 只能是人工审批人；模型与头领都不得自批。
2. **四要素绑定**。run_id、动作、有效期必须同时匹配；任一不符即拒绝，
   不接受"模糊匹配"或"就近有效期"。
3. **只存引用，不存材料**。令牌里只有 `credential://` 形式的引用；
   出现疑似原始密钥材料直接判错，不允许"顺手带一下"。

令牌本身不落运行目录、不进模型上下文。`to_public_dict()` 只导出可审计元数据。
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from .state import AgentRole, ApprovalStatus, RiskLevel

#: 允许出现在 credential_ref 里的引用形式
_CRED_REF_RX = re.compile(r"^credential://[A-Za-z0-9_./-]+$")

#: 疑似原始密钥材料的特征（命中即判错，不允许出现在令牌里）
_SECRET_HINTS = (
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"^[0-9a-fA-F]{32,}$"),          # 纯十六进制长串，多半是原始密钥
    re.compile(r"^[A-Za-z0-9+/]{40,}={0,2}$"),  # 长 base64，多半是原始密钥
)

_NOT_YET_VALID, _EXPIRED = "NOT_YET_VALID", "EXPIRED"


class ApprovalError(PermissionError):
    """审批校验失败。`reason` 是机器可读原因码。"""

    def __init__(self, reason: str, message: str):
        self.reason = reason
        super().__init__(f"[{reason}] {message}")


@dataclass(frozen=True)
class ApprovalToken:
    token_id: str
    order_id: str
    run_id: str
    actions: tuple[str, ...]
    valid_from: datetime
    valid_until: datetime
    approved_by: AgentRole
    status: ApprovalStatus = ApprovalStatus.PENDING
    requested_by: AgentRole = AgentRole.TERRA
    credential_ref: str = ""
    scope_note: str = ""

    # ---------- 序列化 ----------
    def to_public_dict(self) -> dict[str, Any]:
        """可审计元数据。不含任何密钥材料。"""
        return {
            "token_id": self.token_id,
            "order_id": self.order_id,
            "run_id": self.run_id,
            "actions": list(self.actions),
            "valid_from": _iso(self.valid_from),
            "valid_until": _iso(self.valid_until),
            "approved_by": self.approved_by.value,
            "requested_by": self.requested_by.value,
            "status": self.status.value,
            "credential_ref": self.credential_ref,
            "scope_note": self.scope_note,
        }

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "ApprovalToken":
        return ApprovalToken(
            token_id=str(data["token_id"]),
            order_id=str(data["order_id"]),
            run_id=str(data["run_id"]),
            actions=tuple(data.get("actions", ()) or ()),
            valid_from=_parse_dt(data["valid_from"]),
            valid_until=_parse_dt(data["valid_until"]),
            approved_by=AgentRole(str(data.get("approved_by", ""))),
            status=ApprovalStatus(str(data.get("status", ApprovalStatus.PENDING.value))),
            requested_by=AgentRole(str(data.get("requested_by", AgentRole.TERRA.value))),
            credential_ref=str(data.get("credential_ref", "")),
            scope_note=str(data.get("scope_note", "")),
        )


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_dt(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    text = str(value).strip().replace("Z", "+00:00")
    dt = datetime.fromisoformat(text)
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def now_utc() -> datetime:
    """当前 UTC 时刻（令牌有效期判定的统一时钟）。"""
    return datetime.now(timezone.utc)


# --------------------------------------------------------------------------- #
# 签发
# --------------------------------------------------------------------------- #
def issue(*, token_id: str, order_id: str, run_id: str, actions: list[str] | tuple[str, ...],
          valid_from: datetime, valid_until: datetime,
          approved_by: AgentRole | str, credential_ref: str,
          requested_by: AgentRole | str = AgentRole.TERRA, scope_note: str = "") -> ApprovalToken:
    """签发令牌。只允许人工审批人签发；参数不合法直接抛 ApprovalError。"""
    approver = _as_role(approved_by)
    if approver is not AgentRole.HUMAN_APPROVER:
        raise ApprovalError("NOT_HUMAN_APPROVER",
                            f"只有人工审批人可签发令牌，实为 {approver.value}")
    actions = tuple(actions)
    if not actions:
        raise ApprovalError("EMPTY_SCOPE", "令牌必须至少授权一个动作")
    if valid_until <= valid_from:
        raise ApprovalError("BAD_WINDOW", "valid_until 必须晚于 valid_from")
    if "@" in credential_ref and not credential_ref.startswith("credential://"):
        raise ApprovalError("BAD_CREDENTIAL_REF", "credential_ref 只接受 credential:// 形式")
    if credential_ref and not _CRED_REF_RX.match(credential_ref):
        raise ApprovalError("BAD_CREDENTIAL_REF", f"credential_ref 形式非法：{credential_ref!r}")
    if _looks_like_secret(credential_ref) or _looks_like_secret(scope_note):
        raise ApprovalError("SECRET_IN_TOKEN", "令牌中不得出现原始密钥材料")
    return ApprovalToken(
        token_id=token_id, order_id=order_id, run_id=run_id, actions=actions,
        valid_from=valid_from, valid_until=valid_until, approved_by=approver,
        status=ApprovalStatus.APPROVED, requested_by=_as_role(requested_by),
        credential_ref=credential_ref, scope_note=scope_note,
    )


def _looks_like_secret(text: str) -> bool:
    if not text:
        return False
    return any(rx.search(text) for rx in _SECRET_HINTS)


def _as_role(value: AgentRole | str) -> AgentRole:
    if isinstance(value, AgentRole):
        return value
    try:
        return AgentRole(str(value))
    except ValueError:
        raise ApprovalError("UNKNOWN_ROLE", f"未知角色 {value!r}") from None


# --------------------------------------------------------------------------- #
# 校验
# --------------------------------------------------------------------------- #
def effective_status(token: ApprovalToken, at: datetime | None = None) -> ApprovalStatus:
    """考虑时间后的实际状态：过窗口即 expired，未到窗口即 pending。"""
    at = at or now_utc()
    if token.status in (ApprovalStatus.REJECTED, ApprovalStatus.REVOKED):
        return token.status
    if at < token.valid_from:
        return ApprovalStatus.PENDING
    if at > token.valid_until:
        return ApprovalStatus.EXPIRED
    return token.status


def check(token: ApprovalToken | None, *, run_id: str, action: str,
          at: datetime | None = None) -> tuple[bool, str]:
    """四要素校验。返回 (是否放行, 原因码)。"""
    if token is None:
        return False, "NO_TOKEN"
    if token.run_id != run_id:
        return False, "RUN_MISMATCH"
    if action not in token.actions:
        return False, "ACTION_NOT_GRANTED"
    at = at or now_utc()
    if at < token.valid_from:
        return False, _NOT_YET_VALID
    if at > token.valid_until:
        return False, _EXPIRED
    status = token.status
    if status is ApprovalStatus.REVOKED:
        return False, "REVOKED"
    if status is ApprovalStatus.REJECTED:
        return False, "REJECTED"
    if status is ApprovalStatus.EXPIRED:
        return False, _EXPIRED
    if status is not ApprovalStatus.APPROVED:
        return False, "NOT_APPROVED"
    return True, "OK"


def verify(token: ApprovalToken | None, *, run_id: str, action: str,
           at: datetime | None = None) -> None:
    """四要素校验不通过即抛 ApprovalError。"""
    ok, reason = check(token, run_id=run_id, action=action, at=at)
    if not ok:
        raise ApprovalError(reason, f"动作 {action!r} 在 run {run_id} 上未获授权")


# --------------------------------------------------------------------------- #
# 与 ApprovedOrder 的联动
# --------------------------------------------------------------------------- #
def _as_risk(value: RiskLevel | str) -> RiskLevel:
    """RiskLevel 继承 (str, Enum)，str(member) 得到的是 "RiskLevel.LOW" 而不是 "LOW"，
    因此必须先做 isinstance 短路，否则传枚举进来会炸。"""
    if isinstance(value, RiskLevel):
        return value
    try:
        return RiskLevel(str(value))
    except ValueError:
        raise ApprovalError("UNKNOWN_RISK_LEVEL",
                            f"未知风险等级 {value!r}；可选：{[r.value for r in RiskLevel]}") from None


def required_approver(risk_level: RiskLevel | str, *, reversible: bool) -> AgentRole:
    """高风险或不可逆动作必须由人工审批。"""
    level = _as_risk(risk_level)
    if not reversible or level in (RiskLevel.HIGH, RiskLevel.CRITICAL):
        return AgentRole.HUMAN_APPROVER
    return AgentRole.TERRA


def validate_approved_order(order: Any, token: ApprovalToken | None, *,
                            check_schema: bool = True) -> list[str]:
    """校验 ApprovedOrder 与其引用的令牌是否自洽。返回错误列表。"""
    errors: list[str] = []
    if check_schema:
        from ..contracts import validation

        errors.extend(f"schema: {e}" for e in validation.report("approved-order/v0.1", order))
    if not isinstance(order, dict):
        return errors or ["order 不是对象"]

    run_id = str(order.get("run_id", ""))
    risk = order.get("risk_level")
    reversible = order.get("reversible")
    services = (order.get("scope") or {}).get("services") or []
    ref = str(order.get("approval_token_ref", ""))

    if token is None:
        errors.append("缺少审批令牌：无令牌不得生成或执行 ApprovedOrder")
        return errors

    if token.run_id != run_id:
        errors.append(f"令牌绑定 run {token.run_id}，订单属于 run {run_id}")
    if ref != token.credential_ref:
        errors.append(f"approval_token_ref {ref!r} 与令牌引用 {token.credential_ref!r} 不一致")
    if token.status is not ApprovalStatus.APPROVED:
        errors.append(f"令牌状态为 {token.status.value}，不可用于执行")

    if risk is not None and reversible is not None:
        try:
            need = required_approver(risk, reversible=bool(reversible))
        except ApprovalError as exc:
            errors.append(str(exc))
            need = None
        if need is not None and need is AgentRole.HUMAN_APPROVER and \
                token.approved_by is not AgentRole.HUMAN_APPROVER:
            errors.append(f"风险 {risk} / reversible={reversible} 必须人工审批，实为 {token.approved_by.value}")

    for service in services:
        if service not in token.actions:
            errors.append(f"服务 {service} 不在令牌授权范围 {list(token.actions)} 内")

    if _looks_like_secret(ref):
        errors.append("approval_token_ref 疑似原始密钥材料，必须使用 credential:// 引用")

    return errors


__all__ = [
    "ApprovalError",
    "ApprovalToken",
    "check",
    "effective_status",
    "issue",
    "now_utc",
    "required_approver",
    "validate_approved_order",
    "verify",
]
