#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T2.1–T2.3 / T2.5 五主节点图内核（与编排框架无关）。

为什么先不直接依赖 LangGraph
----------------------------
LangGraph 只负责「把状态机跑起来」，真正需要被证明的是**语义**：
静态失败不能进执行子图、执行必须持令牌、每步留审计、中断能恢复。
这些语义与框架无关，先在本模块用零依赖实现并压上测试，
LangGraph 之后作为**薄适配层**接入（`langgraph_adapter.py`），换框架不动语义。

五个主节点与状态迁移
--------------------
| 节点 | 入口状态 | 出口状态 |
|---|---|---|
| `route_and_mount_reference` | NEW | （不变，只挂资料） |
| `inspect_inputs` | NEW | INSPECTED |
| `generate_or_design` | INSPECTED | DESIGNED |
| `static_gate` | DESIGNED | STATIC_PASSED |
| `hardware_gate_and_execute` | STATIC_PASSED | CAPTURED（内部先 RUNNING） |

条件边
------
条件边只读 `GateStatus`，且只看代码产出的值。`static_gate` 不是 PASS 时，
图里**根本不存在**通往执行子图的边 —— 这不是约定，是 `next_node()` 里写死的。
"""
from __future__ import annotations
from runtime.model_performance import normalize_worker_effort, normalize_codex_effort

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Protocol

from . import acl
from . import approval as approval_mod
from . import hashchain as H
from .state import (
    AgentRole,
    GateStatus,
    GraphNode,
    NodeStatus,
    TaskState,
    assert_transition,
    may_enter_execution,
)

CHECKPOINT_NAME = ".checkpoint.json"
CHECKPOINT_VERSION = "graph-checkpoint/v0.1"


class GraphError(RuntimeError):
    """图执行错误（缺节点实现、缺令牌、非法推进、产出不合规等）。"""


# --------------------------------------------------------------------------- #
# 节点规格
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class NodeSpec:
    node: GraphNode
    title: str
    entry_state: TaskState | None
    exit_state: TaskState | None
    produces_gate: bool
    in_execution_subgraph: bool
    description: str
    entry_via: tuple[TaskState, ...] = ()
    """进入节点后、执行节点体**之前**需要走的状态（如执行子图先到 RUNNING）。

    节点本身不碰状态：状态迁移一律由 Runner 以 Terra 身份完成（红线 R1），
    节点只提交事实与门禁值。
    """


GRAPH_NODES: tuple[NodeSpec, ...] = (
    NodeSpec(GraphNode.ROUTE_AND_MOUNT_REFERENCE, "挂载参考资料",
             TaskState.NEW, None, False, False,
             "按任务意图选择唯一主规范分支，挂载项目资料与 ISO 速查；不改任务状态。"),
    NodeSpec(GraphNode.INSPECT_INPUTS, "输入体检",
             TaskState.NEW, TaskState.INSPECTED, True, False,
             "检查输入是否足以支持目标输出并列出缺口；资料不足不补造参数。"),
    NodeSpec(GraphNode.GENERATE_OR_DESIGN, "生成或设计",
             TaskState.INSPECTED, TaskState.DESIGNED, False, False,
             "产出版本化工作件（草案/脚本 + manifest），全部过 Schema 校验。"),
    NodeSpec(GraphNode.STATIC_GATE, "静态门禁",
             TaskState.DESIGNED, TaskState.STATIC_PASSED, True, False,
             "lint、脚本审查、映射与上下文哈希校验；非 PASS 阻断执行子图。"),
    NodeSpec(GraphNode.HARDWARE_GATE_AND_EXECUTE, "受控执行子图",
             TaskState.STATIC_PASSED, TaskState.CAPTURED, True, True,
             "预检、通道独占、最小复测、全量执行与证据封存；必须持有效审批令牌。",
             entry_via=(TaskState.RUNNING,)),
)

NODE_SPEC: dict[GraphNode, NodeSpec] = {s.node: s for s in GRAPH_NODES}

#: 乐观推进路径；`static_gate` → 执行子图这一步由条件边把关。
NEXT_NODE: dict[GraphNode, GraphNode | None] = {
    GraphNode.ROUTE_AND_MOUNT_REFERENCE: GraphNode.INSPECT_INPUTS,
    GraphNode.INSPECT_INPUTS: GraphNode.GENERATE_OR_DESIGN,
    GraphNode.GENERATE_OR_DESIGN: GraphNode.STATIC_GATE,
    GraphNode.STATIC_GATE: GraphNode.HARDWARE_GATE_AND_EXECUTE,
    GraphNode.HARDWARE_GATE_AND_EXECUTE: None,
}

#: 进入执行子图时需要令牌授权的动作名
EXECUTION_ACTION = "execute"


def next_node(node: GraphNode | str, gate_status: GateStatus | str | None) -> GraphNode | None:
    """条件边唯一入口：给定节点与门禁结论，返回下一节点或 None（停下）。

    三条硬规则：
      * 目标是执行子图时，**只有 PASS 才存在这条边**；
      * 门禁节点（`produces_gate=True`）没有给出结论一律停下，不靠"默认放行"；
      * 任何非 PASS 结论都停下。
    非门禁节点（挂资料、生成草案）本来就不出结论，按默认路径推进。
    """
    n = node if isinstance(node, GraphNode) else GraphNode(str(node))
    default = NEXT_NODE[n]
    if default is None:
        return None

    gate = None
    if gate_status is not None:
        gate = gate_status if isinstance(gate_status, GateStatus) else GateStatus(str(gate_status))

    if default is GraphNode.HARDWARE_GATE_AND_EXECUTE:
        return default if (gate is not None and may_enter_execution(gate)) else None

    if NODE_SPEC[n].produces_gate and gate is None:
        return None
    if gate is not None and gate is not GateStatus.PASS:
        return None
    return default


# --------------------------------------------------------------------------- #
# 节点产出
# --------------------------------------------------------------------------- #
@dataclass
class NodeOutcome:
    """一个节点执行后的产出。节点只提交事实与门禁值，不宣布业务结论。"""

    status: NodeStatus
    summary: str
    gate_status: GateStatus | None = None
    gate_name: str = ""
    artifact_path: str | None = None
    payload: dict[str, Any] | None = None
    inputs: tuple[str, ...] = ()
    findings: list[dict[str, Any]] = field(default_factory=list)
    blocked_reason: str = ""
    artifact_kind: str = ""


class NodeFn(Protocol):
    def __call__(self, ctx: "RunContext") -> NodeOutcome: ...


# --------------------------------------------------------------------------- #
# 运行上下文
# --------------------------------------------------------------------------- #
@dataclass
class RunContext:
    run_id: str
    flow: str
    run_dir: str
    state: TaskState = TaskState.NEW
    last_node: GraphNode | None = None
    last_gate: GateStatus | None = None
    last_status: NodeStatus | None = None
    artifacts: list[H.ArtifactRecord] = field(default_factory=list)
    node_results: list[dict[str, Any]] = field(default_factory=list)
    gate_records: list[dict[str, Any]] = field(default_factory=list)
    history: list[dict[str, Any]] = field(default_factory=list)
    blocked_reason: str = ""
    worker_reasoning_effort: str = "high"
    codex_reasoning_effort: str = "medium"
    token: approval_mod.ApprovalToken | None = None
    required_actions: tuple[str, ...] = (EXECUTION_ACTION,)
    clock: Callable[[], datetime] = field(default=lambda: datetime.now(timezone.utc))

    # ---------- 状态回写（只有 Terra 的身份） ----------
    def advance(self, target: TaskState | str, *, reason: str, evidence: str = "") -> None:
        tgt = target if isinstance(target, TaskState) else TaskState(str(target))
        if tgt is self.state:
            return
        assert_transition(self.state, tgt)
        self.history.append({
            "from": self.state.value,
            "to": tgt.value,
            "at": self.clock().isoformat(),
            "by": AgentRole.TERRA.value,
            "reason": reason[:200],
            **({"evidence_ref": evidence} if evidence else {}),
        })
        self.state = tgt

    def sha_of(self, rel_path: str) -> str:
        for a in self.artifacts:
            if a.path == rel_path:
                return a.sha256
        return ""

    def note_artifact(self, rel_path: str, sha256: str, *, inputs: tuple[str, ...] = (),
                      size: int = 0, kind: str = "") -> H.ArtifactRecord:
        rec = H.ArtifactRecord(path=rel_path, sha256=sha256, inputs=tuple(inputs),
                               size=size, kind=kind)
        self.artifacts.append(rec)
        return rec


# --------------------------------------------------------------------------- #
# 执行器
# --------------------------------------------------------------------------- #
class GraphRunner:
    """顺序执行五主节点；每步落 NodeResult、门禁记录与检查点。"""

    def __init__(self, nodes: dict[GraphNode, NodeFn], *, checkpoint: bool = True):
        self.nodes = dict(nodes)
        self.checkpoint_enabled = checkpoint

    # ---------- 主循环 ----------
    def run(self, ctx: RunContext, *, start_at: GraphNode | None = None, max_steps: int = 16) -> RunContext:
        os.makedirs(ctx.run_dir, exist_ok=True)
        node = start_at or self.resolve_entry(ctx)
        steps = 0

        while node is not None:
            steps += 1
            if steps > max_steps:
                raise GraphError(f"节点推进超过 {max_steps} 步，疑似环；最后节点 {node.value}")

            spec = NODE_SPEC[node]
            fn = self.nodes.get(node)
            if fn is None:
                raise GraphError(f"节点 {node.value} 没有实现；拒绝以缺失实现继续推进")

            self._guard(spec, ctx)
            self._enter_via(spec, ctx)
            outcome = fn(ctx)
            self._record(spec, ctx, outcome)

            ctx.last_node = spec.node
            ctx.last_gate = outcome.gate_status
            ctx.last_status = outcome.status

            if outcome.status is not NodeStatus.OK:
                ctx.blocked_reason = outcome.blocked_reason or outcome.summary
                if self.checkpoint_enabled:
                    self.save_checkpoint(ctx)
                break

            self._advance_after(spec, ctx, outcome)
            if self.checkpoint_enabled:
                self.save_checkpoint(ctx)

            node = next_node(spec.node, outcome.gate_status)
            if node is GraphNode.HARDWARE_GATE_AND_EXECUTE and ctx.token is None:
                break  # Persist STATIC_PASSED; an explicit approve action resumes execution.

        return ctx

    def resolve_entry(self, ctx: RunContext) -> GraphNode | None:
        """决定从哪里开始。

        * 无中断记录 -> 从头（`route_and_mount_reference`）；
        * 上次节点**失败**（非 OK）-> 重试同一节点，而不是跳过它；
        * 上次成功 -> 按条件边取下一节点。
        """
        if ctx.last_node is None:
            return GraphNode.ROUTE_AND_MOUNT_REFERENCE
        if ctx.last_status is not None and ctx.last_status is not NodeStatus.OK:
            return ctx.last_node
        return next_node(ctx.last_node, ctx.last_gate)

    # ---------- 硬门禁 ----------
    def _guard(self, spec: NodeSpec, ctx: RunContext) -> None:
        """进入执行子图前必须持有效令牌（红线 R6）。"""
        if not spec.in_execution_subgraph:
            return
        if ctx.token is None:
            raise GraphError("执行子图必须持审批令牌；无令牌不得进入")
        for action in ctx.required_actions:
            approval_mod.verify(ctx.token, run_id=ctx.run_id, action=action, at=ctx.clock())

    def _enter_via(self, spec: NodeSpec, ctx: RunContext) -> None:
        """令牌校验通过后、节点体执行前，走 `entry_via` 里声明的状态。"""
        for target in spec.entry_via:
            ctx.advance(target, reason=f"{spec.title}：预检通过，进入{target.value}")

    # ---------- 落审计 ----------
    def _record(self, spec: NodeSpec, ctx: RunContext, outcome: NodeOutcome) -> None:
        role = producer_for(spec.node)
        sha256 = ""
        if outcome.artifact_path:
            acl.assert_write(role, outcome.artifact_path)
            sha256 = self._write_artifact(ctx, role, outcome)
        elif outcome.payload is not None:
            raise GraphError(f"节点 {spec.node.value} 给了 payload 却没给 artifact_path，工件无处落盘")

        result: dict[str, Any] = {
            "schema_version": "node-result/v0.1",
            "run_id": ctx.run_id,
            "node": spec.node.value,
            "status": outcome.status.value,
            "produced_at": ctx.clock().isoformat(),
            "produced_by": role.value,
            "summary": outcome.summary[:2000],
        }
        if outcome.artifact_path:
            result["writes_to"] = acl.dir_of(outcome.artifact_path)
            result["artifact_path"] = outcome.artifact_path
            result["sha256"] = sha256
        if outcome.inputs:
            result["inputs"] = [{"path": p, "sha256": ctx.sha_of(p)} for p in outcome.inputs]
        if outcome.gate_status is not None:
            result["gate_status"] = outcome.gate_status.value

        errors = acl.validate_node_result(result)
        if errors:
            raise GraphError(f"节点 {spec.node.value} 的 NodeResult 不合规：{errors}")

        ctx.node_results.append(result)
        self._persist(ctx, role, f"{acl.dir_of(outcome.artifact_path) if outcome.artifact_path else '01_command'}"
                                  f"/node_result.{spec.node.value}.json", result)

        if outcome.gate_status is not None:
            record = self._gate_record(spec, ctx, outcome)
            ctx.gate_records.append(record)
            base = acl.dir_of(outcome.artifact_path) if outcome.artifact_path else "01_command"
            self._persist(ctx, role, f"{base}/gate_record.{spec.node.value}.json", record)

    def _write_artifact(self, ctx: RunContext, role: AgentRole, outcome: NodeOutcome) -> str:
        rel = outcome.artifact_path
        full = os.path.join(ctx.run_dir, *rel.split("/"))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            json.dump(outcome.payload, fh, ensure_ascii=False, indent=2, sort_keys=True)
        sha = H.digest_file(full)

        # 哈希链的 inputs 必须是**上游摘要**，不是路径；引用不存在上游直接判错
        upstream: list[str] = []
        for path in outcome.inputs:
            up = ctx.sha_of(path)
            if not up:
                raise GraphError(
                    f"节点声明了上游 {path!r}，但本 run 里没有该工件的哈希记录；"
                    "不允许引用不存在的前置证据")
            upstream.append(up)

        ctx.note_artifact(rel, sha, inputs=tuple(upstream),
                          size=os.path.getsize(full), kind=outcome.artifact_kind)
        return sha

    def _gate_record(self, spec: NodeSpec, ctx: RunContext, outcome: NodeOutcome) -> dict[str, Any]:
        kind = ("hardware" if spec.in_execution_subgraph
                else "inspect" if spec.node is GraphNode.INSPECT_INPUTS
                else "static")
        return {
            "schema_version": "gate-record/v0.1",
            "gate_id": f"GATE-{spec.node.value.upper()}",
            "run_id": ctx.run_id,
            "gate_kind": kind,
            "gate_name": outcome.gate_name or spec.node.value,
            "status": (outcome.gate_status or GateStatus.PASS).value,
            "decided_by": "code",
            "decided_at": ctx.clock().isoformat(),
            "rule_version": "graph/v0.1",
            "checked_artifacts": [
                {"path": p, "sha256": ctx.sha_of(p)} for p in outcome.inputs if ctx.sha_of(p)
            ],
            "findings": outcome.findings,
            "blocks": ([] if spec.in_execution_subgraph
                       else [GraphNode.HARDWARE_GATE_AND_EXECUTE.value]),
        }

    def _advance_after(self, spec: NodeSpec, ctx: RunContext, outcome: NodeOutcome) -> None:
        if spec.exit_state is None:
            return
        ctx.advance(spec.exit_state, reason=outcome.summary, evidence=outcome.artifact_path or "")

    def _persist(self, ctx: RunContext, role: AgentRole, rel: str, payload: dict[str, Any]) -> None:
        acl.assert_write(role, rel)
        full = os.path.join(ctx.run_dir, *rel.split("/"))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2, sort_keys=True)

    # ---------- 检查点（T2.3） ----------
    def save_checkpoint(self, ctx: RunContext) -> str:
        path = os.path.join(ctx.run_dir, CHECKPOINT_NAME)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(dump_context(ctx), fh, ensure_ascii=False, indent=2, sort_keys=True)
        return path


# --------------------------------------------------------------------------- #
# 上下文序列化（T2.3 恢复用）
# --------------------------------------------------------------------------- #
def dump_context(ctx: RunContext) -> dict[str, Any]:
    """把运行上下文序列化为可存检查点的字典。"""
    return {
        "schema_version": CHECKPOINT_VERSION,
        "run_id": ctx.run_id,
        "flow": ctx.flow,
        "state": ctx.state.value,
        "last_node": ctx.last_node.value if ctx.last_node else None,
        "last_gate": ctx.last_gate.value if ctx.last_gate else None,
        "last_status": ctx.last_status.value if ctx.last_status else None,
        "blocked_reason": ctx.blocked_reason,
        "worker_reasoning_effort": normalize_worker_effort(ctx.worker_reasoning_effort),
        "codex_reasoning_effort": normalize_codex_effort(ctx.codex_reasoning_effort),
        "artifacts": [a.to_dict() for a in ctx.artifacts],
        "node_results": ctx.node_results,
        "gate_records": ctx.gate_records,
        "history": ctx.history,
    }


def restore_context(data: dict[str, Any]) -> RunContext:
    """从字典恢复运行上下文（与 dump_context 对偶）。"""
    if data.get("schema_version") != CHECKPOINT_VERSION:
        raise GraphError(f"检查点版本不匹配：{data.get('schema_version')!r}")
    ctx = RunContext(run_id=str(data["run_id"]), flow=str(data.get("flow", "")), run_dir="")
    ctx.state = TaskState(str(data.get("state", TaskState.NEW.value)))
    ctx.last_node = GraphNode(data["last_node"]) if data.get("last_node") else None
    ctx.last_gate = GateStatus(data["last_gate"]) if data.get("last_gate") else None
    ctx.last_status = NodeStatus(data["last_status"]) if data.get("last_status") else None
    ctx.blocked_reason = str(data.get("blocked_reason", ""))
    ctx.worker_reasoning_effort = normalize_worker_effort(data.get("worker_reasoning_effort"))
    ctx.codex_reasoning_effort = normalize_codex_effort(data.get("codex_reasoning_effort"))
    ctx.artifacts = [H.ArtifactRecord.from_dict(d) for d in data.get("artifacts", [])]
    ctx.node_results = list(data.get("node_results", []))
    ctx.gate_records = list(data.get("gate_records", []))
    ctx.history = list(data.get("history", []))
    return ctx


def load_checkpoint(run_dir: str) -> RunContext | None:
    """从运行目录读最近检查点；无则返回 None。"""
    path = os.path.join(run_dir, CHECKPOINT_NAME)
    if not os.path.isfile(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return restore_context(json.load(fh))


# --------------------------------------------------------------------------- #
# 辅助
# --------------------------------------------------------------------------- #
_PRODUCER: dict[GraphNode, AgentRole] = {
    GraphNode.ROUTE_AND_MOUNT_REFERENCE: AgentRole.TERRA,
    GraphNode.INSPECT_INPUTS: AgentRole.PLAN_WORKER,
    GraphNode.GENERATE_OR_DESIGN: AgentRole.PLAN_WORKER,
    GraphNode.STATIC_GATE: AgentRole.PLAN_WORKER,
    GraphNode.HARDWARE_GATE_AND_EXECUTE: AgentRole.EXECUTION_WORKER,
}


def producer_for(node: GraphNode) -> AgentRole:
    """返回声明生产某目录工件的节点（审计用）。"""
    return _PRODUCER[node]


__all__ = [
    "CHECKPOINT_NAME",
    "CHECKPOINT_VERSION",
    "EXECUTION_ACTION",
    "GRAPH_NODES",
    "NEXT_NODE",
    "NODE_SPEC",
    "GraphError",
    "GraphRunner",
    "NodeFn",
    "NodeOutcome",
    "NodeSpec",
    "RunContext",
    "dump_context",
    "load_checkpoint",
    "next_node",
    "producer_for",
    "restore_context",
]
