#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.4 / T1.5 状态机与条件边语义 —— 运行时词汇表的**唯一真源**。

本模块是「运行时新增词汇表」的权威定义处。`runtime/contracts/enums.json` 里
status=new 的那批词汇表，其 source_of_truth 全部指向本文件；契约侧的 enum
一经与本文件不一致，`runtime/tools/validate_contracts.py` 立即报 ERROR。

三条铁律
--------
1. **只有 Terra 能写状态**。worker 与 Web 层只提交事件；迁移由代码校验后落盘。
2. **条件边只读代码枚举**。`GateStatus` 必须由确定性代码或人工审批产出，
   LLM 可以解释原因，但不得产出控制边的最终结果。
3. **BLOCKED 与 INCONCLUSIVE 不是一回事**。前者是前置未满足、从未执行；
   后者是已执行但证据不足。不得互相顶替，也不得降级为 PASS。

用法::

    from runtime.orchestrator import state

    state.assert_transition(state.TaskState.DESIGNED, state.TaskState.STATIC_PASSED)
    state.may_enter_execution(state.GateStatus.REVIEW_REQUIRED)   # -> False
    state.derive_final_verdict(["PASS"], evidence_complete=False) # -> INCONCLUSIVE
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Sequence

# --------------------------------------------------------------------------- #
# 词汇表（与 runtime/contracts/*.schema.json 的 enum 必须逐字一致）
# --------------------------------------------------------------------------- #
class TaskState(str, Enum):
    """任务状态主链。线性推进，失败与中断走旁支，不污染主链。"""

    NEW = "NEW"
    INSPECTED = "INSPECTED"
    DESIGNED = "DESIGNED"
    STATIC_PASSED = "STATIC_PASSED"
    RUNNING = "RUNNING"
    CAPTURED = "CAPTURED"
    ASSESSED = "ASSESSED"
    CLOSED = "CLOSED"


class GateStatus(str, Enum):
    """门禁结论。条件边唯一可读的枚举。"""

    PASS = "PASS"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    ERROR = "ERROR"
    BLOCKED = "BLOCKED"
    ABORTED = "ABORTED"
    INCONCLUSIVE = "INCONCLUSIVE"


class NodeStatus(str, Enum):
    """单节点执行结果的粗粒度状态。节点不宣布业务结论。"""

    OK = "OK"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    ERROR = "ERROR"
    BLOCKED = "BLOCKED"


class RunFinalVerdict(str, Enum):
    """run 级三态结论（仅 CLOSED 时可写）。"""

    PASS = "PASS"
    FAIL = "FAIL"
    INCONCLUSIVE = "INCONCLUSIVE"


class RiskLevel(str, Enum):
    """风险等级。CRITICAL 触发强制人工审批。"""

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class EvidenceKind(str, Enum):
    """可接受的证据种类。二进制专有 XCT 不在其中（默认 BLOCKED）。"""

    ASC = "asc"
    XCT_TEXT = "xct_text"
    RESPONSE = "response"
    TRACE_JSON = "trace_json"


class MemoryKind(str, Enum):
    """长期记忆候选的类别。"""

    RULE = "rule"
    TEMPLATE = "template"
    RUNBOOK = "runbook"
    COMPAT = "compat"


class ApprovalStatus(str, Enum):
    """审批令牌状态。过期即 expired，不得复用。"""

    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    REVOKED = "revoked"


class AgentRole(str, Enum):
    """参与者角色。单写者矩阵的基础。"""

    TERRA = "terra"
    PLAN_WORKER = "plan_worker"
    EXECUTION_WORKER = "execution_worker"
    EVIDENCE_WORKER = "evidence_worker"
    HUMAN_APPROVER = "human_approver"


class GraphNode(str, Enum):
    """五个主节点。节点是业务步骤，不等于 agent。"""

    ROUTE_AND_MOUNT_REFERENCE = "route_and_mount_reference"
    INSPECT_INPUTS = "inspect_inputs"
    GENERATE_OR_DESIGN = "generate_or_design"
    STATIC_GATE = "static_gate"
    HARDWARE_GATE_AND_EXECUTE = "hardware_gate_and_execute"


# --------------------------------------------------------------------------- #
# 迁移表
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class TransitionRule:
    """一条合法的状态迁移。"""

    to_state: TaskState
    entry_condition: str
    event_submitter: AgentRole
    writer: AgentRole
    description: str


_STATE_WRITER = AgentRole.TERRA

TRANSITIONS: dict[TaskState, tuple[TransitionRule, ...]] = {
    TaskState.NEW: (
        TransitionRule(TaskState.INSPECTED, "InputInspection 通过 Schema 校验",
                       AgentRole.PLAN_WORKER, _STATE_WRITER, "资料体检通过"),
    ),
    TaskState.INSPECTED: (
        TransitionRule(TaskState.DESIGNED, "DraftPlan/DraftScript 通过 Schema 校验",
                       AgentRole.PLAN_WORKER, _STATE_WRITER, "设计完成"),
    ),
    TaskState.DESIGNED: (
        TransitionRule(TaskState.STATIC_PASSED, "lint、脚本审查、映射均 PASS",
                       AgentRole.PLAN_WORKER, _STATE_WRITER, "静态门禁通过"),
    ),
    TaskState.STATIC_PASSED: (
        TransitionRule(TaskState.RUNNING, "人工令牌有效 + 通道锁获取 + 预检通过",
                       AgentRole.EXECUTION_WORKER, _STATE_WRITER, "进入执行"),
    ),
    TaskState.RUNNING: (
        TransitionRule(TaskState.CAPTURED, "执行结束，ASC 与原始响应已封存",
                       AgentRole.EXECUTION_WORKER, _STATE_WRITER, "证据已封存"),
    ),
    TaskState.CAPTURED: (
        TransitionRule(TaskState.ASSESSED, "EvidenceIndex 与 DecisionDraft 均已校验",
                       AgentRole.EVIDENCE_WORKER, _STATE_WRITER, "证据判定完成"),
    ),
    TaskState.ASSESSED: (
        TransitionRule(TaskState.CLOSED, "证据哈希链、规则版本与结论齐全",
                       _STATE_WRITER, _STATE_WRITER, "结案"),
    ),
    TaskState.CLOSED: (),
}

#: 状态主链顺序（用于回退判断与展示）
MAIN_CHAIN: tuple[TaskState, ...] = (
    TaskState.NEW,
    TaskState.INSPECTED,
    TaskState.DESIGNED,
    TaskState.STATIC_PASSED,
    TaskState.RUNNING,
    TaskState.CAPTURED,
    TaskState.ASSESSED,
    TaskState.CLOSED,
)

#: 回退（退回上游重做）允许的目标；只允许退到最近的可重做边界
ALLOWED_ROLLBACKS: dict[TaskState, tuple[TaskState, ...]] = {
    TaskState.CAPTURED: (TaskState.DESIGNED,),
    TaskState.ASSESSED: (TaskState.DESIGNED, TaskState.CAPTURED),
}

#: 只有这些状态允许进入硬件执行子图
EXECUTION_ENTRY_STATES: frozenset[TaskState] = frozenset({TaskState.STATIC_PASSED})


class IllegalTransition(ValueError):
    """非法状态迁移。"""


def can_transition(current: TaskState | str, target: TaskState | str) -> bool:
    """判断迁移是否合法（主链前进或白名单回退）。"""
    cur, tgt = _as_state(current), _as_state(target)
    if cur == tgt:
        return False
    if any(rule.to_state is tgt for rule in TRANSITIONS[cur]):
        return True
    return tgt in ALLOWED_ROLLBACKS.get(cur, ())


def assert_transition(current: TaskState | str, target: TaskState | str) -> TransitionRule | None:
    """合法则返回迁移规则（回退返回 None），非法抛 IllegalTransition。"""
    cur, tgt = _as_state(current), _as_state(target)
    for rule in TRANSITIONS[cur]:
        if rule.to_state is tgt:
            return rule
    if tgt in ALLOWED_ROLLBACKS.get(cur, ()):
        return None
    allowed = [r.to_state.value for r in TRANSITIONS[cur]] + \
              [s.value for s in ALLOWED_ROLLBACKS.get(cur, ())]
    raise IllegalTransition(
        f"非法迁移 {cur.value} -> {tgt.value}；{cur.value} 只允许 -> {allowed or ['<终态>']}"
    )


def next_states(current: TaskState | str) -> tuple[TaskState, ...]:
    """某状态的合法后继集合（含回退白名单）。"""
    cur = _as_state(current)
    return tuple(r.to_state for r in TRANSITIONS[cur])


def is_terminal(state: TaskState | str) -> bool:
    """是否终态（CLOSED 或中止）。"""
    return not TRANSITIONS[_as_state(state)]


def main_chain_index(state: TaskState | str) -> int:
    """状态在主链上的序号；不在主链返回 -1。"""
    return MAIN_CHAIN.index(_as_state(state))


def _as_state(value: TaskState | str) -> TaskState:
    if isinstance(value, TaskState):
        return value
    try:
        return TaskState(str(value))
    except ValueError:
        raise IllegalTransition(f"未知状态 {value!r}；可选：{[s.value for s in TaskState]}") from None


# --------------------------------------------------------------------------- #
# T1.5 条件边语义（代码产出，模型不得参与）
# --------------------------------------------------------------------------- #
#: 阻断进入硬件执行子图的门禁结论
EXECUTION_BLOCKING_GATES: frozenset[GateStatus] = frozenset({
    GateStatus.REVIEW_REQUIRED,
    GateStatus.ERROR,
    GateStatus.BLOCKED,
    GateStatus.ABORTED,
    GateStatus.INCONCLUSIVE,
})

#: 需要人工介入（人工审批或人工复核）的门禁结论
HUMAN_INTERVENTION_GATES: frozenset[GateStatus] = frozenset({
    GateStatus.REVIEW_REQUIRED,
    GateStatus.BLOCKED,
})

#: 本轮 run 不再推进（不产生最终结论）
ABORTING_GATES: frozenset[GateStatus] = frozenset({GateStatus.ABORTED})


def may_enter_execution(gate_status: GateStatus | str) -> bool:
    """条件边唯一判定：只有 PASS 允许进入执行子图。"""
    return _as_gate(gate_status) is GateStatus.PASS


def requires_human(gate_status: GateStatus | str) -> bool:
    """该迁移是否强制人工审批（HIGH/CRITICAL 或不可逆）。"""
    return _as_gate(gate_status) in HUMAN_INTERVENTION_GATES


def _as_gate(value: GateStatus | str) -> GateStatus:
    if isinstance(value, GateStatus):
        return value
    try:
        return GateStatus(str(value))
    except ValueError:
        raise ValueError(f"未知门禁结论 {value!r}；可选：{[g.value for g in GateStatus]}") from None


# --------------------------------------------------------------------------- #
# run 级结论推导（红线 R5 的代码化）
# --------------------------------------------------------------------------- #
def derive_final_verdict(
    case_verdicts: Sequence[str],
    *,
    evidence_complete: bool,
    unresolved: Iterable[str] = (),
    aborted: bool = False,
) -> RunFinalVerdict | None:
    """由用例级结论与证据完备性推导 run 级结论。

    返回 None 表示**本轮不结案**（状态应停在原地），而不是给出一个结论：

    * ``aborted=True``            -> 异常终止，不产生最终结论
    * 存在用例 BLOCKED            -> 前置受限、从未执行完，不结案
    * 用例为空且无 PASS           -> 无有效执行，不结案

    三态判定规则（红线 R5：证据不足只能 INCONCLUSIVE）：

    1. 证据不完整或存在未解释现象 -> INCONCLUSIVE
    2. 否则存在 FAIL             -> FAIL
    3. 否则至少一条 PASS 且无 FAIL -> PASS
    4. 其余情况（全 NA/SKIP）      -> INCONCLUSIVE
    """
    if aborted:
        return None

    verdicts = [str(v or "").strip().upper() for v in case_verdicts]
    if any(v == "BLOCKED" for v in verdicts):
        return None
    if not verdicts:
        return None

    unresolved = [u for u in unresolved if str(u).strip()]
    if not evidence_complete or unresolved:
        return RunFinalVerdict.INCONCLUSIVE

    if any(v == "FAIL" for v in verdicts):
        return RunFinalVerdict.FAIL
    if any(v == "PASS" for v in verdicts):
        return RunFinalVerdict.PASS
    return RunFinalVerdict.INCONCLUSIVE


__all__ = [
    "ABORTING_GATES",
    "ALLOWED_ROLLBACKS",
    "AgentRole",
    "ApprovalStatus",
    "EvidenceKind",
    "EXECUTION_BLOCKING_GATES",
    "EXECUTION_ENTRY_STATES",
    "GateStatus",
    "GraphNode",
    "HUMAN_INTERVENTION_GATES",
    "IllegalTransition",
    "MAIN_CHAIN",
    "MemoryKind",
    "NodeStatus",
    "RiskLevel",
    "RunFinalVerdict",
    "TaskState",
    "TRANSITIONS",
    "TransitionRule",
    "assert_transition",
    "can_transition",
    "derive_final_verdict",
    "is_terminal",
    "main_chain_index",
    "may_enter_execution",
    "next_states",
    "requires_human",
]
