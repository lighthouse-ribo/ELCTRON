"""Runtime orchestration JSON CLI. Web may invoke it, but it remains the sole reader of run state."""
from __future__ import annotations
from runtime.usage_tracking import reset_usage_events, usage_events
import json
import os
import sys
import uuid
from datetime import timedelta
from typing import Any
from . import acl as acl_mod
from . import approval as approval_mod
from . import artifact_paths
from .graph import GraphRunner, RunContext, dump_context, load_checkpoint

#: 受控报告（HTML）与最终结论同处 05_final —— 该目录在 ACL 白名单（`acl.RUN_DIRS`）
#: 内且仅 Terra 可写；不存在独立的 `05_report` 目录，写它会被 `AclViolation` 拒绝。
#: 从 ACL 白名单派生而非硬编码，避免两侧漂移（`test_runtime_cli` 另有断言把关）。
_REPORT_DIR = next((d for d in acl_mod.RUN_DIRS if d.endswith("_final")), "")
from .production_nodes import production_nodes
from runtime.agents.model_invokers import ModelInvokerFactory
from runtime.agents.swdl_uds import SWDL_UDS_PROFILES
from runtime.config_layer import load_runtime_config
from runtime.model_performance import normalize_worker_effort, normalize_codex_effort
from runtime.executor.canviex_f1l1 import CanviexF1L1Executor
from .input_context import normalize_input_role
from ..orchestrator import hashchain as hashchain
def _load_run(run_id: str, run_dir: str) -> RunContext:
    ctx = load_checkpoint(run_dir)
    if ctx is None:
        raise approval_mod.ApprovalError("RUN_NOT_FOUND", f"run {run_id} has no checkpoint")
    if ctx.run_id != run_id:
        raise approval_mod.ApprovalError("RUN_MISMATCH", "checkpoint run_id does not match request")
    ctx.run_dir = run_dir
    return ctx
def _public_evidence(run_id: str, run_dir: str) -> dict[str, Any]:
    from ..evidence.index_builder import read_index, verify_index

    _load_run(run_id, run_dir)
    index = read_index(run_dir)
    if index.get("run_id") != run_id:
        raise ValueError("EvidenceIndex run_id does not match request")
    errors = verify_index(run_dir, index)
    entries = []
    for entry in index.get("entries", []):
        if not isinstance(entry, dict):
            continue
        entries.append({key: entry[key] for key in (
            "evidence_id", "kind", "path", "sha256", "immutable", "time_range", "key_frames", "covers_cases"
        ) if key in entry})
    public_index = {
        "schema_version": index.get("schema_version"),
        "run_id": run_id,
        "rule_version": index.get("rule_version"),
        "generated_at": index.get("generated_at"),
        "complete": bool(index.get("complete")),
        "entries": entries,
        "missing": list(index.get("missing") or []),
        "unresolved": list(index.get("unresolved") or []),
    }
    return {"index": public_index, "integrity": {"verified": not errors, "errors": errors}}
def _controlled_reports(ctx: RunContext, run_dir: str) -> list[dict[str, Any]]:
    root = os.path.abspath(run_dir)
    reports: list[dict[str, Any]] = []
    for artifact in ctx.artifacts:
        rel = artifact.path.replace("\\", "/")
        if not rel.startswith(_REPORT_DIR + "/") or not rel.lower().endswith((".html", ".htm")):
            continue
        full = os.path.abspath(os.path.join(root, *rel.split("/")))
        if os.path.commonpath((root, full)) != root or not os.path.isfile(full):
            continue
        if hashchain.digest_file(full) != artifact.sha256:
            continue
        reports.append({"report_id": rel, "path": rel, "sha256": artifact.sha256, "size": os.path.getsize(full)})
    return reports
def _read_controlled_report(run_id: str, run_dir: str, report_id: object) -> dict[str, Any]:
    ctx = _load_run(run_id, run_dir)
    reports = _controlled_reports(ctx, run_dir)
    selected = next((item for item in reports if item["report_id"] == report_id), None)
    if selected is None:
        raise ValueError("report is not a generated, controlled artifact")
    full = os.path.join(run_dir, *selected["path"].split("/"))
    with open(full, encoding="utf-8") as handle:
        return {**selected, "html": handle.read()}
def _input_manifest(value: object) -> tuple[dict[str, str], ...]:
    """Accept only relative, auditable file references for read-only routing."""
    if not isinstance(value, list) or not value:
        raise ValueError("start requires a non-empty input_manifest list")
    if len(value) > 64:
        raise ValueError("input_manifest may contain at most 64 files")
    result: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, dict):
            raise ValueError("input_manifest entries must be objects")
        role, path = item.get("role"), item.get("path")
        if not isinstance(role, str) or not role.strip() or not isinstance(path, str) or not path.strip():
            raise ValueError("input_manifest entries require non-empty role and path")
        normalized = path.replace("\\", "/")
        if normalized.startswith("/") or ":" in normalized or ".." in normalized.split("/"):
            raise ValueError("input_manifest paths must be relative and traversal-free")
        result.append({"role": normalize_input_role(role), "path": normalized})
    return tuple(result)


def _nodes_for_runtime(worker_reasoning_effort=None, codex_reasoning_effort=None):
    config = load_runtime_config()
    factory = ModelInvokerFactory(config)
    if worker_reasoning_effort is not None:
        factory.worker_reasoning_effort = normalize_worker_effort(worker_reasoning_effort)
    if codex_reasoning_effort is not None:
        factory.codex_reasoning_effort = normalize_codex_effort(codex_reasoning_effort)
    # Hardware is opt-in by an exact adapter/channel declaration.  Merely
    # having an SDK installed never changes the production execution path.
    if config.adapter == "canviex-f1l1" and "LIN1" in config.channels:
        return production_nodes(agent_invokers=factory.for_profiles(SWDL_UDS_PROFILES),
                                canviex_executor=CanviexF1L1Executor(lin_output_voltage=
                                    int(os.environ["AETEX_LIN_OUTPUT_VOLTAGE"]) if os.environ.get("AETEX_LIN_OUTPUT_VOLTAGE") in ("0", "1") else None), canviex_channel="LIN1")
    return production_nodes(agent_invokers=factory.for_profiles(SWDL_UDS_PROFILES))


def handle(request: dict[str, Any]) -> dict[str, Any]:
    action = request.get("action")
    run_id = str(request.get("run_id") or uuid.uuid4())
    # 默认落产物根（%LOCALAPPDATA%\AETEX\runs），不再是相对当前工作目录的 "runs/"：
    # Web 侧 cwd 绑定在专家包上，相对默认值会把运行证据写进主体目录。
    run_dir = os.path.abspath(str(request.get("run_dir") or artifact_paths.run_dir(run_id)))
    if action == "start":
        ctx = RunContext(run_id=run_id, flow=str(request.get("flow") or ""), run_dir=run_dir,
                         worker_reasoning_effort=normalize_worker_effort(request.get("worker_reasoning_effort")),
                         codex_reasoning_effort=normalize_codex_effort(request.get("codex_reasoning_effort")))
        # These references are converted to a hashed route artifact before the
        # graph advances; checkpoints persist the artifact rather than paths.
        ctx.input_root = os.path.abspath(str(request.get("input_root") or "."))
        ctx.input_manifest = _input_manifest(request.get("input_manifest"))
        GraphRunner(_nodes_for_runtime(ctx.worker_reasoning_effort, ctx.codex_reasoning_effort)).run(ctx)
        # 终态把 run 树的 05_final/ 链接发布到扁平交付目录（尚不存在时不建空壳）。
        artifact_paths.publish_deliverables(run_id, run_dir)
        return {"ok": True, "run": dump_context(ctx)}
    if action == "status":
        ctx = load_checkpoint(run_dir)
        return {"ok": ctx is not None, "run": dump_context(ctx) if ctx else None}
    if action == "evidence":
        return {"ok": True, "evidence": _public_evidence(run_id, run_dir)}
    if action == "reports":
        return {"ok": True, "reports": _controlled_reports(_load_run(run_id, run_dir), run_dir)}
    if action == "report":
        return {"ok": True, "report": _read_controlled_report(run_id, run_dir, request.get("report_id"))}
    if action == "issue_approval":
        _load_run(run_id, run_dir)
        requested_action = str(request.get("approval_action") or "execute")
        now = approval_mod.now_utc()
        ttl = int(request.get("ttl_seconds") or 300)
        if ttl <= 0 or ttl > 3600:
            raise approval_mod.ApprovalError("BAD_WINDOW", "approval token lifetime must be in 1..3600 seconds")
        token = approval_mod.issue(
            token_id=str(request.get("token_id") or uuid.uuid4()),
            order_id=str(request.get("order_id") or f"workflow:{run_id}"),
            run_id=run_id,
            actions=[requested_action],
            valid_from=now,
            valid_until=now + timedelta(seconds=ttl),
            approved_by="human_approver",
            requested_by=str(request.get("requested_by") or "terra"),
            credential_ref=str(request.get("credential_ref") or "credential://aetex/operator-session"),
            scope_note=f"run:{run_id};action:{requested_action}",
        )
        return {"ok": True, "approval": token.to_public_dict()}
    if action == "approve":
        requested_action = str(request.get("approval_action") or "execute")
        raw_token = request.get("approval")
        if not isinstance(raw_token, dict):
            raise approval_mod.ApprovalError("NO_TOKEN", "runtime approval requires ApprovalToken")
        token = approval_mod.ApprovalToken.from_dict(raw_token)
        approval_mod.verify(token, run_id=run_id, action=requested_action)
        ctx = _load_run(run_id, run_dir)
        ctx.token = token
        GraphRunner(_nodes_for_runtime(ctx.worker_reasoning_effort, ctx.codex_reasoning_effort)).run(ctx)
        # 审批通过后同样发布交付物（审批链是高风险动作的唯一入口）。
        artifact_paths.publish_deliverables(run_id, run_dir)
        return {"ok": True, "run": dump_context(ctx), "approval": token.to_public_dict()}
    raise ValueError("action must be start, status, evidence, reports, report, issue_approval, or approve")
def main() -> int:
    for line in sys.stdin:
        reset_usage_events()
        try:
            result = handle(json.loads(line))
            result["usage_events"] = usage_events()
            print(json.dumps(result, ensure_ascii=False), flush=True)
        except Exception as exc:
            print(json.dumps({"ok": False, "error": str(exc), "usage_events": usage_events()}, ensure_ascii=False), flush=True)
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
