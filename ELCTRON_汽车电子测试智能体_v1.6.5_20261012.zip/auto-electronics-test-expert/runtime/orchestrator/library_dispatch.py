#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""库模块受控分发器：library-surface 清单驱动的唯一调用入口。

为什么需要它
------------
工具注册表把 19 个能力层脚本判定为 `library`（无 `__main__` 入口）——
以 CLI 调用会得到「退出码 0 + 空输出」从而**假通过**（T2.7 修掉的缺陷）。
它们的能力又不该对 Web 层永远不可见。本分发器给出第三条路：
**清单白名单 + 签名绑定 + JSON 安全转换** 的受控调用。

安全边界（全部硬编码在行为里，不靠纪律）：
  1. 只放行 `runtime/contracts/library_surface.json` 里声明的 (模块, 函数/常量)；
  2. 模块必须出现在注册表且 kind=library、组属于 plan/evidence；
     hardware / excluded 组**永远**查不到（`_HARDWARE_NEVER`）；
  3. 参数用 `inspect.signature` 绑定，缺参/多参立刻报错，不静默；
  4. 返回值经 `_jsonable` 转换，无法序列化的对象转 `repr` 截断，
     单次调用输出上限 `_MAX_OUTPUT` 字节，防止把 Web 会话撑爆；
  5. 本分发器不提供任何文件写入原语——写入能力仍归执行器层。
"""
from __future__ import annotations

import dataclasses
import inspect
import json
import os
import sys
from pathlib import Path
from typing import Any

__all__ = [
    "LibraryDispatchError",
    "call",
    "capabilities",
    "load_manifest",
    "MAX_OUTPUT_BYTES",
]

MAX_OUTPUT_BYTES = 256 * 1024


class LibraryDispatchError(RuntimeError):
    """分发失败。原因码：NOT_IN_MANIFEST / MODULE_FORBIDDEN / LOAD_FAILED /
    BIND_ERROR / CALL_FAILED / NOT_SERIALIZABLE / OUTPUT_TOO_LARGE。"""


def _package_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def load_manifest(root: str | None = None) -> dict:
    """读库模块白名单清单；缺失时抛 LibraryDispatchError。"""
    root = root or _package_root()
    path = os.path.join(root, "runtime", "contracts", "library_surface.json")
    if not os.path.isfile(path):
        raise LibraryDispatchError(
            f"NOT_IN_MANIFEST: 缺少库模块清单 {path}，先运行 gen_library_surface.py")
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _ensure_import_paths(root: str) -> None:
    sys.path.insert(0, root)
    from runtime.orchestrator import registry as R  # noqa: WPS433

    for rel in R.classify_on_disk(root):
        d = os.path.dirname(os.path.join(root, rel))
        if d not in sys.path:
            sys.path.insert(0, d)


def _check_registration(root: str, module: str, manifest: dict) -> None:
    """注册表复核：kind / 组 / 清单一致性，三道都过才放行。"""
    sys.path.insert(0, root)
    from runtime.orchestrator import registry as R  # noqa: WPS433

    spec = R.find_tool(module)
    if spec is None:
        raise LibraryDispatchError(f"MODULE_FORBIDDEN: {module} 不在工具注册表里")
    if spec.kind != "library" or spec.group not in ("plan", "evidence"):
        raise LibraryDispatchError(
            f"MODULE_FORBIDDEN: {module} 组={spec.group} kind={spec.kind}，"
            "hardware/excluded 组不可经分发器调用")
    if module not in manifest["modules"]:
        raise LibraryDispatchError(f"NOT_IN_MANIFEST: {module} 未登记在库模块清单里")


def _jsonable(obj: Any, depth: int = 0) -> Any:
    """把任意返回值转成 JSON 安全结构。不可序列化的转 repr 截断，不静默丢内容。"""
    if depth > 8:
        return repr(obj)[:200]
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, bytes):
        return obj.hex()
    if isinstance(obj, (list, tuple, set, frozenset)):
        return [_jsonable(v, depth + 1) for v in list(obj)[:2000]]
    if isinstance(obj, dict):
        return {str(k): _jsonable(v, depth + 1) for k, v in list(obj.items())[:2000]}
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {"__dataclass__": type(obj).__name__,
                **{f.name: _jsonable(getattr(obj, f.name), depth + 1)
                   for f in dataclasses.fields(obj)}}
    if isinstance(obj, Path):
        return str(obj)
    return repr(obj)[:200]


def call(module: str, target: str, *, args: list | None = None,
         kwargs: dict | None = None, root: str | None = None) -> dict:
    """按清单调用 `<module>.<target>`。

    `target` 可以是函数名（带参调用）或常量名（无参，直接返回值）。
    返回 `{"module", "target", "result"}`；任何失败抛 `LibraryDispatchError`，
    原因码前缀机器可读。
    """
    root = root or _package_root()
    args = list(args or [])
    kwargs = dict(kwargs or {})
    manifest = load_manifest(root)
    _check_registration(root, module, manifest)

    meta = manifest["modules"][module]
    if target in meta["functions"]:
        _ensure_import_paths(root)
        try:
            mod = __import__(module)
            fn = getattr(mod, target)
        except Exception as exc:                              # noqa: BLE001
            raise LibraryDispatchError(
                f"LOAD_FAILED: 加载 {module}.{target} 失败：{exc}") from exc
        try:
            sig = inspect.signature(fn)
            bound = sig.bind(*args, **kwargs)
            bound.apply_defaults()
        except TypeError as exc:
            raise LibraryDispatchError(
                f"BIND_ERROR: {module}.{target} 参数不匹配：{exc}") from exc
        try:
            result = fn(*bound.args, **bound.kwargs)
        except Exception as exc:                              # noqa: BLE001
            raise LibraryDispatchError(
                f"CALL_FAILED: {module}.{target} 执行异常："
                f"{type(exc).__name__}: {exc}") from exc
        payload = _jsonable(result)
    elif target in meta["constants"]:
        _ensure_import_paths(root)
        try:
            mod = __import__(module)
            payload = _jsonable(getattr(mod, target))
        except Exception as exc:                              # noqa: BLE001
            raise LibraryDispatchError(
                f"LOAD_FAILED: 读取 {module}.{target} 失败：{exc}") from exc
    else:
        raise LibraryDispatchError(
            f"NOT_IN_MANIFEST: {module}.{target} 未登记在库模块清单里"
            f"（可用函数 {len(meta['functions'])} 个 / 常量 {len(meta['constants'])} 个）")

    text = json.dumps(payload, ensure_ascii=False, default=repr)
    if len(text.encode("utf-8")) > MAX_OUTPUT_BYTES:
        raise LibraryDispatchError(
            f"OUTPUT_TOO_LARGE: {module}.{target} 输出超过 {MAX_OUTPUT_BYTES} 字节，"
            "请缩小参数范围或改用离线批处理")
    return {"module": module, "target": target, "result": payload}


def capabilities(root: str | None = None) -> list[dict]:
    """给 Web 层的工具目录：每个模块可调用的函数/常量一览（组名从注册表补）。"""
    root = root or _package_root()
    manifest = load_manifest(root)
    sys.path.insert(0, root)
    from runtime.orchestrator import registry as R  # noqa: WPS433

    out = []
    for name, meta in manifest["modules"].items():
        spec = R.find_tool(name)
        out.append({
            "module": name,
            "group": spec.group if spec else "unknown",
            "doc": meta["doc"],
            "functions": meta["functions"],
            "constants": meta["constants"],
        })
    return out
