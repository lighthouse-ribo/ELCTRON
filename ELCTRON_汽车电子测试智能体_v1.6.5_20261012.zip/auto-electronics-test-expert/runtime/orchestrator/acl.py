#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.6 运行目录 ACL 与单写者矩阵。

把「谁能写哪个目录」从文档约定变成**可执行校验**。任何一次运行目录写入
都必须先过 `assert_write()`；`NodeResult` 的 `node / produced_by / writes_to /
artifact_path` 四个字段之间的自洽也在这里强制。

目录布局（相对 `runs/<run_id>/`）::

    01_command/     请求、输入体检结论、路由挂载清单        -> 仅 Terra
    02_plan/        用例草案、脚本、静态门禁记录            -> 仅计划 worker
    03_execution/   RunManifest、ASC、原始响应              -> 仅执行 worker
    04_evidence/    EvidenceIndex、VerdictDraft            -> 仅证据 worker
    05_final/       最终结论、报告、发布说明                -> 仅 Terra

设计原则
--------
1. **按角色而非按文件授权**。不给单文件开例外，避免 ACL 越用越碎。
2. **路径先过安全检查再看权限**。绝对路径、盘符、`..`、反斜杠、空段一律拒绝，
   防止借路径规范化绕过目录限制。
3. **节点与目录强绑定**。`hardware_gate_and_execute` 只可能写 03/04，
   `route_and_mount_reference` 只可能写 01，不存在"顺手写到别处"的合法路径。
"""
from __future__ import annotations

import re
from typing import Any

from .state import AgentRole, GraphNode

# --------------------------------------------------------------------------- #
# 布局
# --------------------------------------------------------------------------- #
RUN_DIRS: tuple[str, ...] = (
    "01_command",
    "02_plan",
    "03_execution",
    "04_evidence",
    "05_final",
)

DEFAULT_RUN_ID_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9_.-]{2,63}$"

RUN_DIR_PURPOSE: dict[str, str] = {
    "01_command": "请求、输入体检结论、路由挂载清单",
    "02_plan": "用例草案、脚本、静态门禁记录",
    "03_execution": "RunManifest、ASC、原始响应",
    "04_evidence": "EvidenceIndex、VerdictDraft",
    "05_final": "最终结论、报告、发布说明",
}

#: 单写者矩阵：一个角色只允许写自己的目录
ROLE_DIRS: dict[AgentRole, frozenset[str]] = {
    AgentRole.TERRA: frozenset({"01_command", "05_final"}),
    AgentRole.PLAN_WORKER: frozenset({"02_plan"}),
    AgentRole.EXECUTION_WORKER: frozenset({"03_execution"}),
    AgentRole.EVIDENCE_WORKER: frozenset({"04_evidence"}),
    # 人工审批人不写运行目录：只签发令牌，令牌不落运行目录
    AgentRole.HUMAN_APPROVER: frozenset(),
}

#: 每个主节点允许的写入目录
NODE_DIRS: dict[GraphNode, frozenset[str]] = {
    GraphNode.ROUTE_AND_MOUNT_REFERENCE: frozenset({"01_command"}),
    GraphNode.INSPECT_INPUTS: frozenset({"02_plan"}),
    GraphNode.GENERATE_OR_DESIGN: frozenset({"02_plan"}),
    GraphNode.STATIC_GATE: frozenset({"02_plan"}),
    GraphNode.HARDWARE_GATE_AND_EXECUTE: frozenset({"03_execution", "04_evidence"}),
}

#: 每个主节点允许的产出角色（节点是业务步骤，可由不同角色实现）
NODE_ROLES: dict[GraphNode, frozenset[AgentRole]] = {
    GraphNode.ROUTE_AND_MOUNT_REFERENCE: frozenset({AgentRole.TERRA}),
    GraphNode.INSPECT_INPUTS: frozenset({AgentRole.PLAN_WORKER}),
    GraphNode.GENERATE_OR_DESIGN: frozenset({AgentRole.PLAN_WORKER}),
    GraphNode.STATIC_GATE: frozenset({AgentRole.PLAN_WORKER}),
    GraphNode.HARDWARE_GATE_AND_EXECUTE: frozenset(
        {AgentRole.EXECUTION_WORKER, AgentRole.EVIDENCE_WORKER}
    ),
}


class AclViolation(PermissionError):
    """越权写入或非法路径。"""


# --------------------------------------------------------------------------- #
# 路径安全
# --------------------------------------------------------------------------- #
_SEG_RX = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
_DRIVE_RX = re.compile(r"^[A-Za-z]:")


def is_safe_relpath(rel: str) -> bool:
    """相对路径安全检查：禁止绝对路径、盘符、反斜杠、空段、`.`、`..`。"""
    if not isinstance(rel, str) or not rel or rel != rel.strip():
        return False
    if "\\" in rel or rel.startswith("/") or _DRIVE_RX.match(rel):
        return False
    parts = rel.split("/")
    if any(p in ("", ".", "..") for p in parts):
        return False
    return all(_SEG_RX.match(p) for p in parts)


def dir_of(rel: str) -> str:
    """取相对路径的首段目录；路径不合法直接抛。"""
    if not is_safe_relpath(rel):
        raise AclViolation(f"非法相对路径：{rel!r}")
    return rel.split("/", 1)[0]


# --------------------------------------------------------------------------- #
# 授权
# --------------------------------------------------------------------------- #
def dirs_for(role: AgentRole | str) -> frozenset[str]:
    """某角色的可写目录白名单（单写者矩阵）。"""
    return ROLE_DIRS[_as_role(role)]


def dirs_for_node(node: GraphNode | str) -> frozenset[str]:
    """某图节点允许写入的目录（节点与目录强绑定）。"""
    return NODE_DIRS[_as_node(node)]


def roles_for_node(node: GraphNode | str) -> frozenset[AgentRole]:
    """某图节点的执行角色。"""
    return NODE_ROLES[_as_node(node)]


def node_dir(node: GraphNode | str, role: AgentRole | str) -> str:
    """返回该角色在该节点下唯一可写的目录；不存在唯一解则抛错。"""
    n, r = _as_node(node), _as_role(role)
    common = NODE_DIRS[n] & ROLE_DIRS[r]
    if len(common) != 1:
        raise AclViolation(
            f"节点 {n.value} 与角色 {r.value} 的可写目录不是唯一解：{sorted(common) or '空集'}"
        )
    return next(iter(common))


def can_write(role: AgentRole | str, rel_path: str) -> bool:
    """不抛异常的授权判断。"""
    try:
        assert_write(role, rel_path)
    except AclViolation:
        return False
    return True


def assert_write(role: AgentRole | str, rel_path: str) -> str:
    """校验「某角色可写某路径」，通过则返回目录名，否则抛 AclViolation。"""
    r = _as_role(role)
    if not is_safe_relpath(rel_path):
        raise AclViolation(f"非法相对路径：{rel_path!r}（禁止绝对路径、盘符、.. 与反斜杠）")
    d = dir_of(rel_path)
    if d not in RUN_DIRS:
        raise AclViolation(f"未知运行目录 {d!r}；合法目录：{list(RUN_DIRS)}")
    if d not in ROLE_DIRS[r]:
        allowed = sorted(ROLE_DIRS[r]) or ["<无>"]
        raise AclViolation(f"角色 {r.value} 不可写 {d}；其可写目录：{allowed}")
    return d


def _as_role(value: AgentRole | str) -> AgentRole:
    if isinstance(value, AgentRole):
        return value
    try:
        return AgentRole(str(value))
    except ValueError:
        raise AclViolation(f"未知角色 {value!r}；可选：{[r.value for r in AgentRole]}") from None


def _as_node(value: GraphNode | str) -> GraphNode:
    if isinstance(value, GraphNode):
        return value
    try:
        return GraphNode(str(value))
    except ValueError:
        raise AclViolation(f"未知节点 {value!r}；可选：{[n.value for n in GraphNode]}") from None


# --------------------------------------------------------------------------- #
# NodeResult 四字段自洽校验（把契约声明变成强校验）
# --------------------------------------------------------------------------- #
def validate_node_result(payload: Any, *, check_schema: bool = True) -> list[str]:
    """校验一份 NodeResult：先过契约 schema，再过 ACL 自洽。

    返回错误列表，空列表表示通过。不抛异常，便于聚合上报。
    """
    errors: list[str] = []

    if check_schema:
        from ..contracts import validation

        errors.extend(f"schema: {e}" for e in validation.report("node-result/v0.1", payload))

    if not isinstance(payload, dict):
        return errors or ["payload 不是对象"]

    node = payload.get("node")
    role = payload.get("produced_by")
    writes_to = payload.get("writes_to")
    artifact = payload.get("artifact_path")

    # 1) 节点必须已登记
    try:
        n = _as_node(node)
    except AclViolation as exc:
        return errors + [str(exc)]

    # 2) 角色必须在节点允许的产出角色里
    try:
        r = _as_role(role)
    except AclViolation as exc:
        errors.append(str(exc))
        r = None
    if r is not None and r not in NODE_ROLES[n]:
        errors.append(
            f"节点 {n.value} 不允许由 {r.value} 产出；允许：{sorted(x.value for x in NODE_ROLES[n])}"
        )

    # 3) writes_to 必须在节点允许的目录里
    if writes_to is not None and writes_to not in NODE_DIRS[n]:
        errors.append(
            f"节点 {n.value} 的 writes_to 只能是 {sorted(NODE_DIRS[n])}，实为 {writes_to!r}"
        )

    # 4) writes_to 必须在该角色的可写目录里
    if r is not None and writes_to is not None and writes_to not in ROLE_DIRS[r]:
        errors.append(f"角色 {r.value} 不可写 {writes_to}；其可写目录：{sorted(ROLE_DIRS[r]) or '无'}")

    # 5) artifact_path 必须安全，且首段等于 writes_to
    if artifact is not None:
        if not is_safe_relpath(artifact):
            errors.append(f"artifact_path 非法：{artifact!r}")
        else:
            first = dir_of(artifact)
            if writes_to is not None and first != writes_to:
                errors.append(f"artifact_path 首段 {first!r} 必须等于 writes_to {writes_to!r}")
            if r is not None and not can_write(r, artifact):
                errors.append(f"角色 {r.value} 无权写入 {artifact!r}")

    return errors


__all__ = [
    "AclViolation",
    "DEFAULT_RUN_ID_PATTERN",
    "NODE_DIRS",
    "NODE_ROLES",
    "ROLE_DIRS",
    "RUN_DIRS",
    "RUN_DIR_PURPOSE",
    "assert_write",
    "can_write",
    "dir_of",
    "dirs_for",
    "dirs_for_node",
    "is_safe_relpath",
    "node_dir",
    "roles_for_node",
    "validate_node_result",
]
