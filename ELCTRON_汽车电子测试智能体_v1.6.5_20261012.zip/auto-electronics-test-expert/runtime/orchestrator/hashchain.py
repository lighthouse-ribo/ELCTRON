#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1.7 工件哈希链。

每个工件记录自己的 SHA-256 与**上游工件的 SHA-256**，形成一条可校验的有向无环链：

    DraftPlan  --sha-->  GateRecord  --sha-->  RunManifest  --sha-->  EvidenceIndex  --sha-->  FinalVerdict

只要链闭合并与磁盘一致，就能回答「这个结论到底基于哪一版输入」；
任何一环被改写或缺失，`verify()` 立刻报出**具体哪一条断了**。

设计原则
--------
1. **引用用摘要，不用路径**。路径会变、会被覆盖；摘要不会。路径只作展示。
2. **上游必须可达**。`inputs` 里出现的每个摘要都必须能在本 run 的记录集合里解析到，
   否则就是「引用了一个不存在的证据」——这正是最危险的伪造方式。
3. **必须无环**。哈希链若成环，说明有人用后置工件反推前置工件，直接判错。
4. **磁盘一致可选但建议开启**。带 `run_dir` 时逐文件重算摘要，防「记录没改、文件被改」。
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from typing import Any, Iterable, Sequence

from .acl import AclViolation, is_safe_relpath

_SHA_RX_LEN = 64


class ChainBroken(ValueError):
    """哈希链断裂。"""


@dataclass(frozen=True)
class ArtifactRecord:
    """一个工件的哈希记录。"""

    path: str
    sha256: str
    inputs: tuple[str, ...] = ()
    size: int = 0
    kind: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "sha256": self.sha256,
            "inputs": list(self.inputs),
            "size": self.size,
            "kind": self.kind,
        }

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "ArtifactRecord":
        return ArtifactRecord(
            path=str(data.get("path", "")),
            sha256=str(data.get("sha256", "")),
            inputs=tuple(data.get("inputs", ()) or ()),
            size=int(data.get("size", 0) or 0),
            kind=str(data.get("kind", "")),
        )


# --------------------------------------------------------------------------- #
# 摘要
# --------------------------------------------------------------------------- #
def digest_bytes(data: bytes) -> str:
    """字节串 SHA-256 摘要。"""
    return hashlib.sha256(data).hexdigest()


def digest_file(path: str) -> str:
    """文件 SHA-256 摘要（分块读取，防大文件占内存）。"""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def is_digest(value: Any) -> bool:
    """是否为合法的 64 位十六进制摘要。"""
    return (isinstance(value, str) and len(value) == _SHA_RX_LEN
            and all(c in "0123456789abcdef" for c in value))


def record_for(run_dir: str, rel_path: str, *, inputs: Iterable[str] = (), kind: str = "") -> ArtifactRecord:
    """按磁盘现状生成一条工件记录。路径必须是安全相对路径。"""
    if not is_safe_relpath(rel_path):
        raise AclViolation(f"非法相对路径：{rel_path!r}")
    full = os.path.join(run_dir, *rel_path.split("/"))
    if not os.path.isfile(full):
        raise FileNotFoundError(f"工件不存在：{rel_path}")
    return ArtifactRecord(
        path=rel_path,
        sha256=digest_file(full),
        inputs=tuple(inputs),
        size=os.path.getsize(full),
        kind=kind,
    )


# --------------------------------------------------------------------------- #
# 链根
# --------------------------------------------------------------------------- #
def canonical_record(rec: ArtifactRecord) -> str:
    """确定性序列化：排序后的 inputs，固定字段顺序，便于稳定比对。"""
    return json.dumps(
        {
            "path": rec.path,
            "sha256": rec.sha256,
            "inputs": sorted(rec.inputs),
            "size": rec.size,
            "kind": rec.kind,
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def chain_root(records: Sequence[ArtifactRecord]) -> str:
    """链根：对所有记录按 path 排序后串联摘要。空集合返回全零摘要。"""
    h = hashlib.sha256()
    for rec in sorted(records, key=lambda r: r.path):
        h.update(canonical_record(rec).encode("utf-8"))
    return h.hexdigest()


# --------------------------------------------------------------------------- #
# 校验
# --------------------------------------------------------------------------- #
def parents_of(records: Sequence[ArtifactRecord]) -> dict[str, tuple[str, ...]]:
    """按 sha256 建立「摘要 -> 上游摘要」索引。"""
    return {rec.sha256: tuple(sorted(rec.inputs)) for rec in records}


def topological_order(records: Sequence[ArtifactRecord]) -> list[str]:
    """返回 sha256 的拓扑序（上游在前）。有环则抛 ChainBroken。"""
    parents = parents_of(records)
    order: list[str] = []
    state: dict[str, int] = {}          # 0=未访问 1=在栈 2=已完成

    def visit(node: str, trail: list[str]) -> None:
        mark = state.get(node, 0)
        if mark == 2:
            return
        if mark == 1:
            cycle = " -> ".join(trail[trail.index(node):] + [node])
            raise ChainBroken(f"哈希链成环：{cycle}")
        state[node] = 1
        for up in parents.get(node, ()):
            if up in parents:
                visit(up, trail + [node])
        state[node] = 2
        order.append(node)

    for node in parents:
        visit(node, [])
    return order


def verify(records: Sequence[ArtifactRecord], *, run_dir: str | None = None,
           allow_external_inputs: bool = False) -> list[str]:
    """校验哈希链，返回错误列表（空 = 通过）。不抛异常，便于聚合上报。"""
    errors: list[str] = []
    known = {rec.sha256 for rec in records}

    seen_paths: dict[str, str] = {}
    for rec in records:
        if not is_safe_relpath(rec.path):
            errors.append(f"非法工件路径：{rec.path!r}")
        if not is_digest(rec.sha256):
            errors.append(f"{rec.path}: sha256 格式非法 {rec.sha256!r}")
        prev = seen_paths.get(rec.path)
        if prev is not None and prev != rec.sha256:
            errors.append(f"{rec.path}: 同一路径出现两个不同摘要，路径被覆盖过")
        seen_paths[rec.path] = rec.sha256

        for up in rec.inputs:
            if not is_digest(up):
                errors.append(f"{rec.path}: 上游摘要格式非法 {up!r}")
            elif up not in known and not allow_external_inputs:
                errors.append(f"{rec.path}: 引用了不存在于本 run 的上游摘要 {up[:12]}…")

    try:
        topological_order(records)
    except ChainBroken as exc:
        errors.append(str(exc))

    if run_dir is not None:
        for rec in records:
            full = os.path.join(run_dir, *rec.path.split("/"))
            if not os.path.isfile(full):
                errors.append(f"{rec.path}: 文件不存在，无法核对哈希")
                continue
            actual = digest_file(full)
            if actual != rec.sha256:
                errors.append(f"{rec.path}: 磁盘摘要与记录不一致（记录 {rec.sha256[:12]}… 实际 {actual[:12]}…）")
            size = os.path.getsize(full)
            if rec.size and rec.size != size:
                errors.append(f"{rec.path}: 字节数不一致（记录 {rec.size} 实际 {size}）")

    return errors


def assert_chain(records: Sequence[ArtifactRecord], *, run_dir: str | None = None,
                 allow_external_inputs: bool = False) -> str:
    """通过则返回链根，否则抛 ChainBroken。"""
    errors = verify(records, run_dir=run_dir, allow_external_inputs=allow_external_inputs)
    if errors:
        raise ChainBroken("哈希链校验失败（%d 项）：%s" % (len(errors), "；".join(errors[:5])))
    return chain_root(records)


__all__ = [
    "ArtifactRecord",
    "ChainBroken",
    "assert_chain",
    "canonical_record",
    "chain_root",
    "digest_bytes",
    "digest_file",
    "is_digest",
    "parents_of",
    "record_for",
    "topological_order",
    "verify",
]
