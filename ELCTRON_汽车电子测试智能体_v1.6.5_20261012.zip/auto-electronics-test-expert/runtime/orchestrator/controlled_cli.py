"""Typed, run-scoped entry for file-based design generators.

Only runtime code supplies the roots and the expected source hash. Model and
MCP callers never receive path or arbitrary argv control through this API.
"""
from __future__ import annotations

import json
import os
import re

from . import registry
from .hashchain import digest_file
from .tools import CliToolError, run_cli

_TOOL_PATHS = {
    "uds_req_matrix_generator": "skills/srs-uds-testcase-designer/scripts/uds_req_matrix_generator.py",
    "steps_generator": "skills/srs-uds-testcase-designer/scripts/steps_generator.py",
}
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_OUTPUT_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}\.json$")
_MAX_INPUT = 50 * 1024 * 1024
_MAX_OUTPUT = 20 * 1024 * 1024


class ControlledCliError(RuntimeError):
    """A file CLI could not be called within its declared run boundary."""


def _inside(root: str, candidate: str) -> bool:
    try:
        return os.path.normcase(os.path.commonpath((root, candidate))) == os.path.normcase(root)
    except ValueError:
        return False


def run_design_generator(tool_name: str, *, source_root: str, source_rel: str,
                         source_sha256: str, run_dir: str, output_name: str) -> dict:
    """Run a registered generator against one hashed file and one fixed output.

    The output is always ``02_plan/generated/<output_name>`` in ``run_dir``.
    A missing, changed, or symlink-escaped source fails before the CLI starts.
    """
    rel_script = _TOOL_PATHS.get(tool_name)
    spec = registry.find_tool(tool_name)
    if not rel_script or spec is None or spec.kind != registry.CLI or spec.node != "generate_or_design":
        raise ControlledCliError("CONTROLLED_TOOL_NOT_ALLOWED")
    if not _SHA256.fullmatch(source_sha256) or not _OUTPUT_NAME.fullmatch(output_name):
        raise ControlledCliError("CONTROLLED_ARGUMENT_INVALID")
    rel = source_rel.replace("\\", "/")
    if not rel or rel.startswith("/") or ":" in rel or any(part in {"", ".", ".."} for part in rel.split("/")):
        raise ControlledCliError("CONTROLLED_SOURCE_PATH_INVALID")
    source_base = os.path.realpath(os.path.abspath(source_root))
    source = os.path.realpath(os.path.join(source_base, *rel.split("/")))
    if not _inside(source_base, source) or not os.path.isfile(source):
        raise ControlledCliError("CONTROLLED_SOURCE_OUTSIDE_ROOT")
    if os.path.getsize(source) > _MAX_INPUT or digest_file(source) != source_sha256:
        raise ControlledCliError("CONTROLLED_SOURCE_HASH_MISMATCH")
    run_root = os.path.realpath(os.path.abspath(run_dir))
    output_dir = os.path.join(run_root, "02_plan", "generated")
    os.makedirs(output_dir, exist_ok=True)
    output_dir = os.path.realpath(output_dir)
    if not _inside(run_root, output_dir):
        raise ControlledCliError("CONTROLLED_OUTPUT_OUTSIDE_RUN")
    output = os.path.join(output_dir, output_name)
    if os.path.lexists(output):
        raise ControlledCliError("CONTROLLED_OUTPUT_EXISTS")
    args = ([source, "--out", output] if tool_name == "uds_req_matrix_generator"
            else ["--cases", source, "--out", output])
    try:
        result = run_cli(rel_script, args, timeout=180)
    except CliToolError as exc:
        raise ControlledCliError("CONTROLLED_CLI_UNAVAILABLE") from exc
    if result.timed_out or result.returncode != 0:
        raise ControlledCliError("CONTROLLED_CLI_FAILED")
    if digest_file(source) != source_sha256:
        raise ControlledCliError("CONTROLLED_SOURCE_CHANGED_DURING_RUN")
    if (os.path.islink(output) or not _inside(output_dir, os.path.realpath(output))
            or not os.path.isfile(output) or os.path.getsize(output) > _MAX_OUTPUT):
        raise ControlledCliError("CONTROLLED_OUTPUT_INVALID")
    try:
        with open(output, encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, ValueError) as exc:
        raise ControlledCliError("CONTROLLED_OUTPUT_NOT_JSON") from exc
    return {"tool": tool_name, "source_sha256": source_sha256,
            "output_path": f"02_plan/generated/{output_name}",
            "output_sha256": digest_file(output), "data": data}
