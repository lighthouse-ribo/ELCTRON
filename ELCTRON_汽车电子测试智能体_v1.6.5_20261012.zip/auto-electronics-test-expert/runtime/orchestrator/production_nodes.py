"""生产图节点注册表。

所有未接入确定性能力的节点必须 fail-closed，禁止复用测试夹具返回假产物。
"""
from __future__ import annotations

import json
import os
from typing import Mapping

from runtime.agents.runner import AgentInvoker, AgentNodeRunner, AgentPolicyError
from runtime.agents.model_invokers import ModelInvocationError
from runtime.agents.leader_worker import LeadershipError
from runtime.agents.swdl_uds import SWDL_UDS_PROFILES
from runtime.contracts.validation import ContractViolation, validate_payload
from runtime.renderers.canoe_capl import CanoeCaplRenderError, render_capl_test_unit
from runtime.executor.canviex_f1l1 import CanviexF1L1Error, CanviexF1L1Executor, probe_f1l1
from runtime.executor.lease import ChannelBusy, ChannelLeaseManager
from .hashchain import digest_file
from .graph import NodeOutcome, NodeFn, RunContext
from .input_context import build_automotive_input_context
from .state import GraphNode, GateStatus, NodeStatus
from .tools import CliToolError, reference_router


_MAX_INPUT_FILE_BYTES = 50 * 1024 * 1024
_MAX_INPUT_TOTAL_BYTES = 200 * 1024 * 1024


def _is_within_root(root: str, candidate: str) -> bool:
    """Return whether a resolved candidate remains inside a resolved root."""
    try:
        return os.path.normcase(os.path.commonpath((root, candidate))) == os.path.normcase(root)
    except ValueError:
        return False


def _route(ctx: RunContext) -> NodeOutcome:
    if not ctx.flow.strip():
        return NodeOutcome(NodeStatus.BLOCKED, "缺少任务意图，无法挂载参考资料", blocked_reason="flow_required")
    root = os.path.realpath(os.path.abspath(str(getattr(ctx, "input_root", "") or "")))
    manifest = tuple(getattr(ctx, "input_manifest", ()))
    if not root or not manifest:
        return NodeOutcome(NodeStatus.BLOCKED, "缺少受控输入清单，拒绝猜测资料", blocked_reason="input_manifest_required")
    try:
        routed, _raw = reference_router(ctx.flow)
    except CliToolError as exc:
        return NodeOutcome(NodeStatus.BLOCKED, "资料路由器不可用，拒绝猜测规范分支",
                           blocked_reason=f"reference_router_failed:{str(exc)[:160]}")
    mounted: list[dict[str, object]] = []
    total_bytes = 0
    for item in manifest:
        role, rel_path = str(item.get("role", "")), str(item.get("path", ""))
        full_path = os.path.realpath(os.path.abspath(os.path.join(root, *rel_path.split("/"))))
        if not _is_within_root(root, full_path) or not os.path.isfile(full_path):
            return NodeOutcome(NodeStatus.BLOCKED, "资料清单包含不存在或越界文件",
                               blocked_reason="input_manifest_invalid")
        size = os.path.getsize(full_path)
        if size > _MAX_INPUT_FILE_BYTES:
            return NodeOutcome(NodeStatus.BLOCKED, "单个资料超过只读路由上限", blocked_reason="input_too_large")
        total_bytes += size
        if total_bytes > _MAX_INPUT_TOTAL_BYTES:
            return NodeOutcome(NodeStatus.BLOCKED, "资料包总量超过只读路由上限", blocked_reason="input_total_too_large")
        mounted.append({"role": role, "path": rel_path, "sha256": digest_file(full_path), "bytes": size})
    roles = {str(item["role"]) for item in mounted}
    routes = ["srs-uds-testcase-designer"]
    if "diag_survey" in roles:
        routes.append("uds-diagnostic-test")
    if "ldf" in roles:
        routes.append("lin-network-test")
    route_summary = {
        "primary_branch": str(routed.get("primary_branch", "")),
        "secondary_branches": [str(item) for item in routed.get("secondary_branches", [])][:8],
    }
    if not route_summary["primary_branch"]:
        return NodeOutcome(NodeStatus.BLOCKED, "资料路由器未给出主规范分支", blocked_reason="reference_router_invalid")
    return NodeOutcome(
        NodeStatus.OK,
        "已完成受控只读资料路由与规范分支选择",
        artifact_path="01_command/reference_mount.json",
        payload={"flow": ctx.flow, "files": mounted, "selected_skills": routes,
                 "reference_route": route_summary, "read_only": True},
        artifact_kind="reference_mount",
    )


def _inspect(ctx: RunContext) -> NodeOutcome:
    route_path = "01_command/reference_mount.json"
    if not ctx.sha_of(route_path):
        return NodeOutcome(NodeStatus.BLOCKED, "缺少受控资料路由工件", gate_status=GateStatus.BLOCKED,
                           gate_name="input_inspection", blocked_reason="reference_mount_not_available",
                           artifact_path="02_plan/input_inspection.blocked.json", artifact_kind="input_inspection")
    full_path = os.path.join(ctx.run_dir, *route_path.split("/"))
    try:
        with open(full_path, encoding="utf-8") as handle:
            mounted = json.load(handle).get("files", [])
    except (OSError, ValueError, AttributeError):
        return NodeOutcome(NodeStatus.BLOCKED, "资料路由工件不可读取", gate_status=GateStatus.BLOCKED,
                           gate_name="input_inspection", blocked_reason="reference_mount_invalid",
                           artifact_path="02_plan/input_inspection.blocked.json", artifact_kind="input_inspection")
    roles = {str(item.get("role", "")) for item in mounted if isinstance(item, dict)}
    if not roles.intersection({"diag_survey", "srs", "swrs"}):
        return NodeOutcome(NodeStatus.BLOCKED, "缺少诊断调查表或需求资料", gate_status=GateStatus.BLOCKED,
                           gate_name="input_inspection", blocked_reason="required_input_missing",
                           artifact_path="02_plan/input_inspection.blocked.json", artifact_kind="input_inspection",
                           inputs=(route_path,))
    try:
        input_context = build_automotive_input_context(str(getattr(ctx, "input_root", "")), mounted,
                                                       scratch_root=ctx.run_dir)
    except (OSError, ValueError):
        return NodeOutcome(NodeStatus.BLOCKED, "受控输入事实包无法构建", gate_status=GateStatus.BLOCKED,
                           gate_name="input_inspection", blocked_reason="input_context_invalid",
                           artifact_path="02_plan/input_inspection.blocked.json", artifact_kind="input_inspection",
                           inputs=(route_path,))
    parse_issues = list(input_context.get("parse_issues") or [])
    if parse_issues:
        return NodeOutcome(NodeStatus.BLOCKED, "输入资料存在解析失败，禁止以文件名或猜测继续设计",
                           gate_status=GateStatus.BLOCKED, gate_name="input_inspection",
                           blocked_reason="input_parser_failed", artifact_path="02_plan/input_inspection.blocked.json",
                           artifact_kind="input_inspection", payload={"roles": sorted(roles),
                           "automotive_input_context": input_context}, findings=parse_issues, inputs=(route_path,))
    return NodeOutcome(
        NodeStatus.OK,
        "输入体检通过；允许生成只读测试设计草案",
        gate_status=GateStatus.PASS,
        gate_name="input_inspection",
        artifact_path="02_plan/input_inspection.json",
        payload={"roles": sorted(roles), "file_count": len(mounted), "read_only_design_only": True,
                 "automotive_input_context": input_context},
        artifact_kind="input_inspection",
        inputs=(route_path,),
    )


def _not_wired(_ctx: RunContext) -> NodeOutcome:
    return NodeOutcome(
        NodeStatus.BLOCKED,
        "生产能力尚未接入 runtime；禁止使用测试夹具推进",
        gate_status=GateStatus.BLOCKED,
        blocked_reason="production_node_not_wired",
    )


def _generate(ctx: RunContext) -> NodeOutcome:
    out = _not_wired(ctx)
    out.artifact_path = "02_plan/generate.blocked.json"
    return out


def _check_draft(ctx: RunContext, draft) -> tuple[dict | None, list[dict[str, str]], str]:
    """Verify the persisted draft and bind each case to a parsed input source."""
    root = os.path.realpath(os.path.abspath(ctx.run_dir))
    full = os.path.realpath(os.path.join(root, *draft.path.split("/")))
    if not _is_within_root(root, full) or not os.path.isfile(full):
        return None, [], "draft_missing_or_outside_run"
    try:
        actual_draft_hash = digest_file(full)
    except OSError:
        return None, [], "draft_unreadable"
    if actual_draft_hash != draft.sha256:
        return None, [], "draft_hash_mismatch"
    try:
        with open(full, encoding="utf-8") as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict):
            return None, [], "draft_not_object"
        bundle = payload.get("test_case_spec_bundle")
        validate_payload("test-case-spec-bundle/v0.1", bundle)
        cases = bundle["cases"]
        platform = payload.get("target_platform")
        if platform == "vickcan-python":
            contract = payload.get("vickcan_python_contract")
            if not isinstance(contract, dict) or contract.get("case_count") != len(cases):
                return None, [], "vickcan_contract_mismatch"
            normalized = contract.get("cases")
            if not isinstance(normalized, list) or [c.get("case_id") for c in normalized] != [c["case_id"] for c in cases]:
                return None, [], "vickcan_case_ids_mismatch"
            if any(c.get("request") != spec["request"] or c.get("expectation") != spec["expectation"]
                   for c, spec in zip(normalized, cases)):
                return None, [], "vickcan_cases_mismatch"
        elif platform == "canoe-capl":
            rendering = payload.get("canoe_capl_rendering")
            if not isinstance(rendering, dict) or render_capl_test_unit(
                    bundle, target_qualifier=str(rendering.get("target_qualifier") or "")) != rendering:
                return None, [], "canoe_rendering_mismatch"
        else:
            return None, [], "target_platform_invalid"
    except (OSError, ValueError, TypeError, KeyError, ContractViolation, CanoeCaplRenderError):
        return None, [], "draft_contract_invalid"

    requirements_by_source: dict[str, set[str]] = {}
    inspection_rel = "02_plan/input_inspection.json"
    inspection_full = os.path.join(root, *inspection_rel.split("/"))
    try:
        inspection_valid = (bool(ctx.sha_of(inspection_rel)) and os.path.isfile(inspection_full)
                            and digest_file(inspection_full) == ctx.sha_of(inspection_rel))
    except OSError:
        inspection_valid = False
    if inspection_valid:
        try:
            with open(inspection_full, encoding="utf-8") as handle:
                inspection = json.load(handle)
            packet = inspection.get("automotive_input_context", {})
            if not packet.get("parse_issues"):
                for fact in packet.get("facts", []):
                    if not isinstance(fact, dict) or fact.get("role") not in {"srs", "swrs"}:
                        continue
                    source_id = str(fact.get("source_id") or "")
                    summary = fact.get("summary")
                    if source_id and isinstance(summary, dict):
                        requirements_by_source[source_id] = {
                            str(req).upper() for req in summary.get("requirement_ids", [])
                            if isinstance(req, str)}
        except (OSError, ValueError, AttributeError, TypeError):
            pass
    known_requirements = set().union(*requirements_by_source.values()) if requirements_by_source else set()
    known_refs = set(requirements_by_source) | known_requirements
    findings = []
    for case in cases:
        refs = {str(ref).upper() if str(ref).upper().startswith("REQ-") else str(ref)
                for ref in case["source_refs"]}
        bound = (bool(refs) and refs <= known_refs and any(
            source_id in refs and bool(requirements & refs)
            for source_id, requirements in requirements_by_source.items()))
        if not bound:
            findings.append({"code": "REQUIREMENT_BINDING_UNVERIFIED", "severity": "REVIEW_REQUIRED",
                             "message": f"{case['case_id']}: source_refs must include a verified SRS source_id and a requirement ID in that source"})
    return payload, findings, ""


def _static(ctx: RunContext, reviewer: AgentInvoker | None = None) -> NodeOutcome:
    drafts = [item for item in ctx.artifacts if item.kind == "swdl_uds_script_draft"]
    if not drafts:
        out = _not_wired(ctx)
        out.artifact_path = "02_plan/static_gate.blocked.json"
        return out
    draft = drafts[-1]
    payload, findings, problem = _check_draft(ctx, draft)
    if problem:
        return NodeOutcome(NodeStatus.BLOCKED, "草案完整性或契约校验失败；禁止执行",
                           gate_status=GateStatus.BLOCKED, gate_name="deterministic_static_gate",
                           blocked_reason=problem, artifact_path="02_plan/static_gate.blocked.json",
                           artifact_kind="static_review", findings=[{"code": problem, "severity": "BLOCKED",
                           "message": problem}], inputs=(draft.path,))
    if not findings:
        return NodeOutcome(NodeStatus.OK, "草案、渲染结果及输入来源绑定通过确定性校验",
                           gate_status=GateStatus.PASS, gate_name="deterministic_static_gate",
                           artifact_path="02_plan/static_gate.pass.json",
                           payload={"draft_sha256": draft.sha256, "case_count": len(payload["test_case_spec_bundle"]["cases"]),
                                    "source_binding": "verified_srs_source_and_requirement_id"},
                           artifact_kind="static_review", inputs=(draft.path,))
    if reviewer is not None:
        profile = next(item for item in SWDL_UDS_PROFILES if item.name == "swdl-uds-script-reviewer")
        try:
            review = AgentNodeRunner(profile).run(ctx, reviewer)
        except (AgentPolicyError, ModelInvocationError) as exc:
            return NodeOutcome(NodeStatus.BLOCKED, "脚本审查 Agent 不可用；禁止进入执行子图",
                               gate_status=GateStatus.BLOCKED, gate_name="script_agent_review",
                               blocked_reason=str(exc), artifact_path="02_plan/script_review.blocked.json",
                               artifact_kind="static_review", inputs=(draft.path,))
        review.gate_status = GateStatus.REVIEW_REQUIRED
        review.findings = findings
        review.gate_name = "script_agent_review"
        review.inputs = (draft.path,)
        review.summary = f"脚本审查草案已生成；等待人工与确定性静态门禁：{review.summary}"[:2000]
        return review
    return NodeOutcome(
        NodeStatus.OK,
        "只读测试设计草案已生成，等待人工审查；未进入执行子图",
        gate_status=GateStatus.REVIEW_REQUIRED,
        gate_name="test_design_review",
        artifact_path="02_plan/static_gate.review_required.json",
        payload={"draft_path": draft.path, "draft_sha256": draft.sha256, "execution_permitted": False},
        findings=findings,
        artifact_kind="static_review",
        inputs=(draft.path,),
    )


def _execute(ctx: RunContext) -> NodeOutcome:
    out = _not_wired(ctx)
    out.artifact_path = "03_execution/execute.blocked.json"
    return out


def _canviex_execute(executor: CanviexF1L1Executor, channel: str) -> NodeFn:
    """Execution-node adapter: GraphRunner already verified the ApprovalToken."""
    def invoke(ctx: RunContext) -> NodeOutcome:
        drafts = [item for item in ctx.artifacts if item.kind == "swdl_uds_script_draft"]
        payload, _findings, problem = _check_draft(ctx, drafts[-1]) if drafts else (None, [], "draft_missing")
        cases = payload.get("test_case_spec_bundle", {}).get("cases", []) if payload else []
        if (problem or not payload or payload.get("target_platform") != "vickcan-python" or len(cases) != 1
                or cases[0].get("request") != [0x3E, 0x00]
                or cases[0].get("expectation", {}).get("kind") != "positive_prefix"
                or cases[0].get("expectation", {}).get("bytes") != [0x7E, 0x00]):
            return NodeOutcome(NodeStatus.BLOCKED, "当前执行器只支持已批准的单项 TesterPresent；其它草案用例未执行",
                               blocked_reason="canviex_approved_cases_unsupported",
                               artifact_path="03_execution/canviex_scope.blocked.json", artifact_kind="execution")
        try:
            readiness = probe_f1l1()
        except CanviexF1L1Error as exc:
            return NodeOutcome(NodeStatus.BLOCKED, "CANviex SDK 预检失败", blocked_reason=str(exc),
                               artifact_path="03_execution/canviex_preflight.blocked.json", artifact_kind="execution")
        if not readiness.available:
            return NodeOutcome(NodeStatus.BLOCKED, "CANviex F1L1 不可用或被占用",
                               blocked_reason="canviex_device_unavailable",
                               artifact_path="03_execution/canviex_preflight.blocked.json", artifact_kind="execution",
                               payload={"dll_version": readiness.dll_version, "device_count": readiness.device_count,
                                        "available_bitmap": readiness.available_bitmap})
        manager = ChannelLeaseManager(os.path.join(os.path.dirname(ctx.run_dir), ".channel-leases"))
        try:
            lease = manager.acquire(channel, holder=ctx.run_id, executor_id="canviex-f1l1")
        except ChannelBusy:
            return NodeOutcome(NodeStatus.BLOCKED, "LIN 通道租约冲突", blocked_reason="channel_lease_busy",
                               artifact_path="03_execution/canviex_preflight.blocked.json", artifact_kind="execution")
        try:
            result = executor.tester_present(run_dir=ctx.run_dir, run_id=ctx.run_id, channel=channel)
        except CanviexF1L1Error as exc:
            return NodeOutcome(NodeStatus.BLOCKED, "CANviex 最小诊断执行失败", blocked_reason=str(exc),
                               artifact_path="03_execution/canviex_result.blocked.json", artifact_kind="execution")
        finally:
            manager.release(lease)
        if not result.get("response_positive"):
            return NodeOutcome(NodeStatus.BLOCKED, "最小诊断未收到匹配的正响应，不能报告通过",
                               blocked_reason="canviex_response_not_positive",
                               artifact_path="03_execution/canviex_response.blocked.json", artifact_kind="execution",
                               payload={"result": result})
        return NodeOutcome(NodeStatus.OK, "CANviex F1L1 最小诊断与 ASC 证据已封存",
                           artifact_path="03_execution/canviex_tester_present.json", artifact_kind="execution",
                           payload={"adapter": "canviex-f1l1", "channel": channel, "probe": readiness.__dict__,
                                    "result": result})
    return invoke


def _agent_node(profile, invoker: AgentInvoker) -> NodeFn:
    """将模型调用限制在已登记 profile 的单一计划节点内。"""
    runner = AgentNodeRunner(profile)

    def invoke(ctx: RunContext) -> NodeOutcome:
        try:
            return runner.run(ctx, invoker)
        except (ModelInvocationError, LeadershipError) as exc:
            return NodeOutcome(NodeStatus.BLOCKED, "模型调用不可用；只读设计链已安全停止",
                               blocked_reason=str(exc), artifact_path=f"02_plan/{profile.name}.blocked.json",
                               payload={"profile": profile.name, "reason": str(exc)},
                               artifact_kind="model_unavailable")

    return invoke


def production_nodes(*, agent_invokers: Mapping[str, AgentInvoker] | None = None,
                     canviex_executor: CanviexF1L1Executor | None = None,
                     canviex_channel: str = "LIN1") -> dict[GraphNode, NodeFn]:
    """构造生产图节点。

    未注入模型适配器时，所有尚未接线的业务节点继续 fail-closed；注入的 SWDL/UDS
    Agent 也只能生成计划草案，静态门禁与硬件节点绝不由 Agent 替换。
    """
    nodes: dict[GraphNode, NodeFn] = {
        GraphNode.ROUTE_AND_MOUNT_REFERENCE: _route,
        GraphNode.INSPECT_INPUTS: _inspect,
        GraphNode.GENERATE_OR_DESIGN: _generate,
        GraphNode.STATIC_GATE: _static,
        GraphNode.HARDWARE_GATE_AND_EXECUTE: _execute,
    }
    for profile in SWDL_UDS_PROFILES:
        invoker = (agent_invokers or {}).get(profile.name)
        # Input inspection is deterministic. Only the design node is model-assisted.
        if invoker is not None and profile.node is GraphNode.GENERATE_OR_DESIGN:
            nodes[profile.node] = _agent_node(profile, invoker)
        if invoker is not None and profile.node is GraphNode.STATIC_GATE:
            nodes[profile.node] = lambda ctx, reviewer=invoker: _static(ctx, reviewer)
    if canviex_executor is not None:
        nodes[GraphNode.HARDWARE_GATE_AND_EXECUTE] = _canviex_execute(canviex_executor, canviex_channel)
    return nodes


__all__ = ["production_nodes"]
