"""运行产物根解析：run 树与对外交付物必须落在专家包（运行主体）之外。

为什么必须外置：专家包是被 git 管理、被 cache 快照安装、需要整体交接的主体。
任何一次运行只要在其中留下 `runs/`，就会污染索引、混入打包快照、并可能被
`git clean -x` 一锅端（证据不可逆丢失）。因此产物根是**用户级目录**，
默认 `%LOCALAPPDATA%\\AETEX`（POSIX 回落 `~/.aetex`），不在任何仓库内。

环境变量（优先级从高到低）：
    AETEX_HOME             产物总根，默认 %LOCALAPPDATA%\\AETEX
    AETEX_RUNS_DIR         覆盖 run 树根，默认 <AETEX_HOME>/runs
    AETEX_DELIVERABLES_DIR 覆盖交付物发布根，默认 <AETEX_HOME>/deliverables

交付物发布走**目录链接**（Windows junction / POSIX symlink），零复制：
交付物始终只有一份真相（run 树里的 `05_final/`），扁平目录只是它的入口。
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ENV_HOME = "AETEX_HOME"
ENV_RUNS = "AETEX_RUNS_DIR"
ENV_DELIVERABLES = "AETEX_DELIVERABLES_DIR"

#: run 树内被视作「对外交付物」的目录（见 acl.py 的 NODE_DIRS 约定）。
DELIVERABLE_SUBDIR = "05_final"


def _explicit(raw: object) -> Path | None:
    """空串/空白/非字符串一律视为未设置，避免把空环境变量当成根路径。"""
    if not isinstance(raw, str):
        return None
    value = raw.strip()
    if not value:
        return None
    return Path(os.path.expandvars(value)).expanduser().resolve()


def aetex_home() -> Path:
    """产物总根：AETEX_HOME > %LOCALAPPDATA%\\AETEX > ~/.aetex。"""
    explicit = _explicit(os.environ.get(ENV_HOME))
    if explicit is not None:
        return explicit
    local = _explicit(os.environ.get("LOCALAPPDATA"))
    if local is not None:
        return local / "AETEX"
    return Path.home() / ".aetex"


def runs_root() -> Path:
    """run 树根。禁止回落到专家包内。"""
    return _explicit(os.environ.get(ENV_RUNS)) or aetex_home() / "runs"


def deliverables_root() -> Path:
    """扁平交付目录根。禁止回落到专家包内。"""
    return _explicit(os.environ.get(ENV_DELIVERABLES)) or aetex_home() / "deliverables"


def run_dir(run_id: str) -> Path:
    return runs_root() / run_id


def deliverable_dir(run_id: str) -> Path:
    return deliverables_root() / run_id


def publish_deliverables(run_id: str, run_dir_path: str | os.PathLike[str]) -> Path | None:
    """把 run 的 `05_final/` 以目录链接方式发布到扁平交付目录（幂等）。

    返回发布后的链接路径；`05_final/` 尚未生成时返回 None，不建空壳目录，
    避免制造「交付物存在但为空」的假象。
    """
    source = Path(run_dir_path) / DELIVERABLE_SUBDIR
    if not source.is_dir():
        return None
    link = deliverable_dir(run_id)
    if link.is_dir() or link.is_symlink():
        return link
    try:
        link.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        return None
    return link if _link_dir(link, source) else None


def _link_dir(link: Path, target: Path) -> bool:
    """建立目录链接。Windows 用 junction（无需管理员权限，不占额外空间）。"""
    try:
        if sys.platform == "win32":
            # cmd 的输出随系统 locale（中文机为 GBK），固定 utf-8+replace 解码，
            # 否则 subprocess 的读取线程会因 UnicodeDecodeError 抛栈（returncode 虽不受影响，但会污染日志）。
            result = subprocess.run(
                ["cmd", "/c", "mklink", "/J", str(link), str(target)],
                capture_output=True, text=True, encoding="utf-8", errors="replace", check=False,
            )
            return result.returncode == 0
        link.symlink_to(target, target_is_directory=True)
        return True
    except OSError:
        return False
