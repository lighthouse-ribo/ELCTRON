"""受控汽车电子测试输入资料解析。

解析器在 runtime 内以确定性方式运行。此模块只产生可审计工件；模型调用方
只会取得获授权的脱敏事实摘要，不会取得原始文件内容、路径或安全访问密钥材料。
"""
from __future__ import annotations

import json
import os
import tempfile
from typing import Any, Mapping

from .tools import run_cli
from .hashchain import digest_file


INPUT_ROLE_ALIASES = {
    "requirement": "srs", "requirements": "srs", "security_key": "security_key_ref",
    "seed_key": "security_key_ref", "sa_key": "security_key_ref", "key": "security_key_ref",
}
SUPPORTED_INPUT_ROLES = frozenset({
    "srs", "swrs", "diag_survey", "dbc", "ldf", "sddb", "cdd", "security_key_ref",
})

_SRS_ANALYZER = "skills/srs-uds-testcase-designer/scripts/srs_input_analyzer.py"
_SURVEY_PARSER = "skills/uds-diagnostic-test/scripts/uds_survey_parser.py"
_DBC_PARSER = "skills/uds-diagnostic-test/scripts/dbc_parser.py"
_LDF_PARSER = "skills/uds-diagnostic-test/scripts/ldf_parser.py"
_SDDB_EXTRACTOR = "skills/uds-diagnostic-test/scripts/sddb_extract.py"


def normalize_input_role(value: str) -> str:
    """Return a canonical manifest role or reject an ungoverned input type."""
    role = str(value or "").strip().lower().replace("-", "_")
    role = INPUT_ROLE_ALIASES.get(role, role)
    if role not in SUPPORTED_INPUT_ROLES:
        raise ValueError(f"unsupported input role: {value!r}")
    return role


def resolve_input_source(input_root: str, relative_path: str) -> str:
    """Resolve an already-validated manifest entry without following it outside the root.

    The route node performs the first mount check.  Repeating the real-path
    containment check here closes the interval between mounting and parser
    invocation, including Windows junctions or symlinks replaced in that interval.
    """
    root = os.path.realpath(os.path.abspath(input_root))
    source = os.path.realpath(os.path.abspath(os.path.join(root, *relative_path.split("/"))))
    try:
        contained = os.path.normcase(os.path.commonpath((root, source))) == os.path.normcase(root)
    except ValueError:
        contained = False
    if not contained:
        raise ValueError("resolved input source is outside input root")
    return source


def _read_json(path: str) -> Mapping[str, Any]:
    with open(path, encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, Mapping):
        raise ValueError("parser output must be a JSON object")
    return value


def _source_id(item: Mapping[str, object]) -> str:
    return f"{item.get('role', 'unknown')}:{str(item.get('sha256', ''))[:12]}"


def _compact_srs(value: Mapping[str, Any]) -> dict[str, object]:
    discovered = value.get("discovered") if isinstance(value.get("discovered"), Mapping) else {}
    verdict = value.get("verdict") if isinstance(value.get("verdict"), Mapping) else {}
    return {
        "did_samples": [str(v) for v in list(discovered.get("dids") or [])[:64]],
        "requirement_ids": [str(v).upper() for v in list(discovered.get("requirement_ids") or [])[:4096]],
        "service_samples": [str(v.get("sid")) for v in list(discovered.get("services") or [])[:32]
                            if isinstance(v, Mapping) and v.get("sid") is not None],
        "gap_count": len(list(value.get("gaps") or [])), "can_generate": bool(verdict.get("can_generate")),
    }


def _compact_survey(value: Mapping[str, Any]) -> dict[str, object]:
    dids = list(value.get("dids") or [])
    return {
        "did_count": len(dids),
        "did_samples": [str(v.get("did_number")) for v in dids[:64] if isinstance(v, Mapping)],
        "dtc_count": len(list(value.get("dtcs") or [])),
        "io_control_count": len(list(value.get("io_controls") or [])),
        "routine_count": len(list(value.get("routines") or [])),
        "default_assumption_count": len(list(value.get("defaults_used") or [])),
    }


def _compact_dbc(value: Mapping[str, Any]) -> dict[str, object]:
    messages = list(value.get("messages") or [])
    return {
        "node_count": len(list(value.get("nodes") or [])), "message_count": len(messages),
        "signal_count": sum(len(list(m.get("signals") or [])) for m in messages if isinstance(m, Mapping)),
        "message_samples": [str(m.get("name")) for m in messages[:32] if isinstance(m, Mapping)],
    }


def _compact_ldf(value: Mapping[str, Any]) -> dict[str, object]:
    frames = list(value.get("frames") or [])
    master = value.get("master") if isinstance(value.get("master"), Mapping) else {}
    return {
        "lin_protocol_version": str(value.get("lin_protocol_version") or ""), "lin_speed_bps": value.get("lin_speed_bps"),
        "master": str(master.get("name") or ""), "slave_count": len(list(value.get("slaves") or [])),
        "frame_count": len(frames),
        "diagnostic_frame_count": sum(1 for v in frames if isinstance(v, Mapping) and v.get("frame_type") == "diagnostic"),
        "signal_count": len(list(value.get("signals") or [])), "warning_count": len(list(value.get("warnings") or [])),
    }


def _compact_sddb(value: Mapping[str, Any]) -> dict[str, object]:
    services = value.get("services") if isinstance(value.get("services"), Mapping) else {}
    counts: dict[str, int] = {}
    for sid in ("0x22", "0x2e", "0x2f", "0x31"):
        service = services.get(sid) if isinstance(services.get(sid), Mapping) else {}
        counts[sid] = len(list(service.get("objects") or []))
    return {"service_object_counts": counts}


def _run_parser(role: str, source: str, *, scratch_root: str | None = None) -> Mapping[str, Any]:
    """Run a package-owned parser; transient output never enters the run evidence tree."""
    with tempfile.TemporaryDirectory(prefix="aetex-input-", dir=scratch_root) as work:
        output = os.path.join(work, "parsed.json")
        if role in {"srs", "swrs"}:
            result = run_cli(_SRS_ANALYZER, (source, "--out", output))
        elif role in {"diag_survey", "cdd"}:
            result = run_cli(_SURVEY_PARSER, ("--input", source, "--output", output))
        elif role == "dbc":
            result = run_cli(_DBC_PARSER, ("--input", source, "--output", output))
        elif role == "ldf":
            result = run_cli(_LDF_PARSER, ("--input", source, "--output", output))
        elif role == "sddb":
            result = run_cli(_SDDB_EXTRACTOR, ("--input", source, "--output", output))
        else:
            raise ValueError(f"parser not defined for {role}")
        if result.timed_out or result.returncode != 0:
            raise RuntimeError("parser_failed")
        return _read_json(output)


def build_automotive_input_context(input_root: str, mounted: list[Mapping[str, object]], *,
                                   scratch_root: str | None = None) -> dict[str, object]:
    """Create a bounded, secret-free fact packet from the validated manifest."""
    compactors = {
        "srs": _compact_srs, "swrs": _compact_srs, "diag_survey": _compact_survey,
        "cdd": _compact_survey, "dbc": _compact_dbc, "ldf": _compact_ldf, "sddb": _compact_sddb,
    }
    sources: list[dict[str, object]] = []
    facts: list[dict[str, object]] = []
    issues: list[dict[str, str]] = []
    key_refs: list[dict[str, object]] = []
    for item in mounted:
        role = normalize_input_role(str(item.get("role") or ""))
        source_id = _source_id(item)
        sources.append({"source_id": source_id, "role": role, "sha256": str(item.get("sha256") or ""),
                        "bytes": int(item.get("bytes") or 0)})
        if role == "security_key_ref":
            key_refs.append({"source_id": source_id, "present": True, "material_in_context": False,
                             "usage": "runtime_executor_only"})
            continue
        try:
            source = resolve_input_source(input_root, str(item.get("path") or ""))
            expected_sha = str(item.get("sha256") or "")
            if digest_file(source) != expected_sha:
                raise ValueError("source_changed_before_parse")
            parsed = _run_parser(role, source, scratch_root=scratch_root)
            if digest_file(source) != expected_sha:
                raise ValueError("source_changed_during_parse")
            facts.append({"source_id": source_id, "role": role, "parser": f"{role}_parser",
                          "summary": compactors[role](parsed)})
        except (OSError, ValueError, RuntimeError):
            issues.append({"source_id": source_id, "role": role, "code": "parser_failed"})
    return {
        "schema_version": "automotive-input-context/v0.1", "sources": sources, "facts": facts,
        "parse_issues": issues, "secure_key_references": key_refs, "secret_material_in_context": False,
        "model_context_exported": True,
        "model_context_policy": "approved_sanitized_facts_only",
    }


__all__ = ["INPUT_ROLE_ALIASES", "SUPPORTED_INPUT_ROLES", "build_automotive_input_context", "normalize_input_role",
           "resolve_input_source"]
