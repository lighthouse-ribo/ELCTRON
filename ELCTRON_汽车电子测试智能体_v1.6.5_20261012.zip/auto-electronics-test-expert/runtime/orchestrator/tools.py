#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T2.4 / T2.6 既有 CLI 适配层。

把专家包里已验证的 Python CLI 接到图上，**不重写任何一条既有逻辑**：

| 节点 | 调用的既有 CLI |
|---|---|
| `route_and_mount_reference` | `skills/uds-diagnostic-test/scripts/reference_router.py` |
| `static_gate` | `case_lint.py`、`script_review.py`、`review_truth.py`、`project_artifact_binding.py` |

出口码映射原则
--------------
**只有明确的"全部通过"才映射为 PASS**。崩溃、超时、输出无法解析一律映射为 ERROR，
不允许出现"看不懂就当通过"的路径 —— 那正是本项目历史上误判 FAIL/PASS 的根源。

| case_lint 退出码 | 含义 | 映射 |
|---|---|---|
| 0 | 全部规则通过 | PASS |
| 2 | 存在规则 FAIL，阻断交付 | REVIEW_REQUIRED |
| 1 | 输入或项目配置错误 | ERROR |
| 其它 / 超时 / 无法解析 | 工具异常 | ERROR |
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import Any, Sequence

from . import registry as _registry
from .state import GateStatus

HERE = os.path.dirname(os.path.abspath(__file__))              # runtime/orchestrator
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))              # <包根>

REFERENCE_ROUTER = "skills/uds-diagnostic-test/scripts/reference_router.py"
CASE_LINT = "skills/srs-uds-testcase-designer/scripts/case_lint.py"
SCRIPT_REVIEW = "skills/uds-diagnostic-test/scripts/script_review.py"
REVIEW_TRUTH = "skills/uds-diagnostic-test/scripts/review_truth.py"
PROJECT_ARTIFACT_BINDING = "skills/uds-diagnostic-test/scripts/project_artifact_binding.py"

#: case_lint 出口码 -> 门禁结论
CASE_LINT_EXIT_MAP: dict[int, GateStatus] = {
    0: GateStatus.PASS,
    2: GateStatus.REVIEW_REQUIRED,
    1: GateStatus.ERROR,
}


class CliToolError(RuntimeError):
    """适配层自身的错误（脚本不存在、越界路径等），不是被测工具的业务结论。"""


@dataclass(frozen=True)
class CliResult:
    script: str
    args: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str
    duration_s: float
    timed_out: bool = False

    @property
    def tail(self) -> str:
        """末尾若干行，用于写进 summary 或 findings。"""
        lines = [ln for ln in (self.stdout or "").splitlines() if ln.strip()]
        return " | ".join(lines[-3:])[:500]


def resolve_script(rel_path: str, *, root: str = PKG_ROOT) -> str:
    """把包内相对脚本路径解析成绝对路径；越界或不存在即抛错。"""
    if os.path.isabs(rel_path) or ".." in rel_path.split("/"):
        raise CliToolError(f"只允许包内相对路径：{rel_path!r}")
    full = os.path.abspath(os.path.join(root, *rel_path.split("/")))
    if not full.startswith(os.path.abspath(root) + os.sep):
        raise CliToolError(f"脚本路径越出包根：{rel_path!r}")
    if not os.path.isfile(full):
        raise CliToolError(f"脚本不存在：{rel_path}")
    return full


def run_cli(rel_script: str, args: Sequence[str] = (), *, root: str = PKG_ROOT,
            timeout: float = 180.0, python: str | None = None) -> CliResult:
    """以子进程方式运行包内既有 CLI，捕获输出。不修改被调用脚本。

    **调用前断言它确实是 CLI**：库模块（无 `__main__` 入口）按 CLI 运行只会得到
    「退出码 0 + 空输出」，而 0 会被映射成 PASS —— 静默假通过比报错危险得多。
    """
    full = resolve_script(rel_script, root=root)
    _assert_cli_callable(rel_script, full)
    exe = python or sys.executable
    argv = [exe, full, *[str(a) for a in args]]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")

    started = time.time()
    try:
        proc = subprocess.run(argv, cwd=os.path.dirname(full), env=env, timeout=timeout,
                              capture_output=True, text=True, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired as exc:
        return CliResult(rel_script, tuple(str(a) for a in args), -1,
                         exc.stdout or "", f"timeout after {timeout}s", time.time() - started, True)
    return CliResult(rel_script, tuple(str(a) for a in args), proc.returncode,
                     proc.stdout or "", proc.stderr or "", time.time() - started, False)


# --------------------------------------------------------------------------- #
# T2.6 资料挂载
# --------------------------------------------------------------------------- #
def reference_router(task: str, *, bus: str | None = None,
                     root: str = PKG_ROOT) -> tuple[dict[str, Any], CliResult]:
    """调用既有 reference_router，返回解析后的挂载清单与原始结果。

    输出不是合法 JSON 时抛 `CliToolError` —— 不猜、不降级。
    """
    args = [task] + (["--bus", bus] if bus else [])
    result = run_cli(REFERENCE_ROUTER, args, root=root)
    if result.returncode != 0:
        raise CliToolError(f"reference_router 退出码 {result.returncode}：{result.stderr.strip()[:200]}")
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise CliToolError(f"reference_router 输出不是合法 JSON：{exc}") from exc
    if not isinstance(payload, dict) or "primary_branch" not in payload:
        raise CliToolError("reference_router 输出缺少 primary_branch，拒绝当作有效挂载结果")
    return payload, result


# --------------------------------------------------------------------------- #
# T2.4 静态门禁
# --------------------------------------------------------------------------- #
def static_gate_from_exit(code: int, *, timed_out: bool = False) -> GateStatus:
    """把静态门禁类工具（case_lint 系）的出口码映射为门禁结论。

    未知出口码、超时一律 ERROR。**不存在把未知当 PASS 的分支。**
    """
    if timed_out:
        return GateStatus.ERROR
    return CASE_LINT_EXIT_MAP.get(code, GateStatus.ERROR)


def case_lint(cases_path: str, *, project_config: str = "", out: str = "",
              ro_dids: str | None = None, root: str = PKG_ROOT) -> tuple[GateStatus, CliResult]:
    """跑既有 case_lint，返回 (门禁结论, 原始结果)。"""
    args = ["--cases", cases_path]
    if project_config:
        args += ["--project-config", project_config]
    if out:
        args += ["--out", out]
    if ro_dids is not None:
        args += ["--ro-dids", ro_dids]
    result = run_cli(CASE_LINT, args, root=root)
    return static_gate_from_exit(result.returncode, timed_out=result.timed_out), result


def findings_from_output(result: CliResult, *, severity: str) -> list[dict[str, str]]:
    """从 CLI 文本输出里提取 FAIL 行，作为门禁 findings。辅助函数，只做保守提取。"""
    out: list[dict[str, str]] = []
    for line in (result.stdout or "").splitlines():
        stripped = line.strip()
        if stripped.startswith("- "):
            out.append({"code": "CLI_FINDING", "severity": severity,
                        "message": stripped[2:][:300], "artifact": result.script})
    return out


def _assert_cli_callable(rel_script: str, full: str) -> None:
    """断言该脚本可以作为 CLI 运行。库模块一律拒绝，不做静默降级。"""
    name = os.path.splitext(os.path.basename(rel_script))[0]
    spec = _registry.find_tool(name)
    if spec is not None and spec.kind != _registry.CLI:
        raise CliToolError(
            f"{rel_script} 是库模块（无 __main__ 入口），不能按 CLI 调用；"
            "请以 import 方式使用（按 CLI 调只会得到空输出，而空输出会被误判为通过）")
    if not _registry.has_main_entry(full):
        raise CliToolError(
            f"{rel_script} 没有 __main__ 入口，按 CLI 调用只会得到空输出；已拒绝调用")


def cli_callable(rel_script: str, *, root: str = PKG_ROOT) -> bool:
    """该脚本此刻能否作为 CLI 运行（存在 + 有 __main__ 入口 + 注册为 cli）。"""
    try:
        full = resolve_script(rel_script, root=root)
    except CliToolError:
        return False
    name = os.path.splitext(os.path.basename(rel_script))[0]
    spec = _registry.find_tool(name)
    if spec is not None and spec.kind != _registry.CLI:
        return False
    return _registry.has_main_entry(full)


def available_tools(*, root: str = PKG_ROOT) -> dict[str, bool]:
    """各适配工具**能否作为 CLI 调用**，供预检使用。

    注意语义是「可调用」而不是「文件存在」：库模块返回 False。
    只查存在性会把库模块报成可用，进而在门禁里产生静默假通过。
    """
    out: dict[str, bool] = {}
    for rel in (REFERENCE_ROUTER, CASE_LINT, SCRIPT_REVIEW, REVIEW_TRUTH, PROJECT_ARTIFACT_BINDING):
        out[rel] = cli_callable(rel, root=root)
    return out


def tool_catalog() -> list[dict[str, object]]:
    """全包工具目录（供 Web 层工具面与覆盖度检查使用）。

    `web_exposed=True` 的条目才允许下发 Web 层；hardware 组恒为 False。
    """
    return [
        {
            "name": s.name,
            "group": s.group,
            "node": s.node,
            "kind": s.kind,
            "purpose": s.purpose,
            "web_exposed": s.web_exposed,
        }
        for s in _registry.TOOL_REGISTRY
    ]


__all__ = [
    "CASE_LINT",
    "CASE_LINT_EXIT_MAP",
    "CliResult",
    "CliToolError",
    "PKG_ROOT",
    "PROJECT_ARTIFACT_BINDING",
    "REFERENCE_ROUTER",
    "REVIEW_TRUTH",
    "SCRIPT_REVIEW",
    "available_tools",
    "case_lint",
    "cli_callable",
    "tool_catalog",
    "findings_from_output",
    "reference_router",
    "resolve_script",
    "run_cli",
    "static_gate_from_exit",
]
