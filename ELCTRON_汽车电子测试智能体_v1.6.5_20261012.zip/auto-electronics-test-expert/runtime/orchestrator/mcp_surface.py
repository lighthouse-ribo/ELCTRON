#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""MCP 工具面拆分（T5.5）：把注册表切成三个可下发的工具面。

三个工具面
----------
| id | 名称 | 下发 Web 层 | 内容 |
|---|---|---|---|
| `plan-tools` | 计划与设计 | **是**（只读） | 解析、输入体检、用例设计、静态门禁 |
| `evidence-tools` | 证据与报告 | **是**（只读） | 证据解析、报告生成 |
| `hardware-tools` | 硬件执行 | **否** | 通道、设备、执行器 |

**`hardware-tools` 永不下发。** 这不是纪律约定，而是本模块用结构保证的：
`hardware` 组条目的 `expose_to_web` 恒为 `False`，且不会进入 `allowedTools`；
`check_surface()` 会在任何一次违反时列出问题。

关于「能不能真的被调用」
------------------------
注册表记录所有脚本能力。MCP 的只读工具面只开放无文件副作用的路由 CLI
以及已确认的纯库函数。需文件输入或输出的 CLI 和路径读取库函数留在 pending 清单中，
由 runtime 的受控流程在明确输入根、输出目录和审计上下文内调用。

用法
----
    python runtime/orchestrator/mcp_surface.py --out runtime/dist/web_tool_surface.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from runtime.orchestrator import registry as R      # noqa: E402

__all__ = [
    "SURFACE_VERSION",
    "build_surface",
    "check_surface",
    "as_allowed_tools",
    "surface_fingerprint",
    "verify_manifest",
    "hardware_tool_ids",
    "web_tool_ids",
]

SURFACE_VERSION = "mcp-surface/v0.1"

#: 工具面 id -> (标题, 是否下发 Web 层, 来源组)
SURFACE_GROUPS = (
    ("plan-tools", "计划与设计（只读）", True, (R.PLAN,)),
    ("evidence-tools", "证据与报告（只读）", True, (R.EVIDENCE,)),
    ("hardware-tools", "硬件执行（不下发）", False, (R.HARDWARE,)),
)

#: 组 -> MCP 工具 id 前缀
_PREFIX = {R.PLAN: "plan", R.EVIDENCE: "evidence", R.HARDWARE: "hardware"}

#: 库模块暂不可服务的统一原因
LIBRARY_REASON = "库模块（无 __main__ 入口），需先写 import 包装才能作为 MCP 工具下发"
CLI_CONTROLLED_RUN_REASON = "CLI 需要文件输入或输出；须由受控运行流程调用"
READ_ONLY_CLI = frozenset({"reference_router", "jcodemunch_bridge", "web_probe"})
PURE_LIBRARY = frozenset({
    "cybersecurity_case_generator", "generate_security_cases", "lin_case_matrix",
    "lin_case_model", "project_capability_gate", "project_fact_mapper",
    "reference_case_adapter", "result_contract", "review_truth", "swdl_case_generator",
    "swdl_case_review", "swdl_report_adapter", "testcase_headers", "uds_case_gate",
})
LIBRARY_SCOPED_REASON = "库模块可读取文件路径；须由受控运行流程调用"


def _library_surface() -> dict:
    """library-surface 清单（模块 -> 暴露的函数/常量）；缺失视为空（全部 pending）。"""
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "contracts", "library_surface.json")
    if not os.path.isfile(path):
        return {}
    with open(path, encoding="utf-8") as fh:
        return json.load(fh).get("modules", {})


_LIBRARY_SURFACE = _library_surface()


def _tool_id(spec) -> str:
    """MCP 工具 id。未知组用组名本身作前缀，不抛错（自检脚本也要能被指出来）。"""
    return f"{_PREFIX.get(spec.group, spec.group)}__{spec.name}"


def _entry(spec) -> dict:
    entry = {
        "id": _tool_id(spec),
        "name": spec.name,
        "kind": spec.kind,
        "node": spec.node,
        "purpose": spec.purpose,
        "serviceable": False,
        "expose_to_web": False,
        "reason": "",
    }
    if spec.kind == R.CLI and spec.name in READ_ONLY_CLI:
        entry["serviceable"] = True
        entry["call_via"] = "cli"
    elif spec.kind == R.CLI:
        entry["reason"] = CLI_CONTROLLED_RUN_REASON
    elif spec.kind == R.LIBRARY and spec.name in _LIBRARY_SURFACE and spec.name in PURE_LIBRARY:
        # 清单覆盖的库模块经 library_dispatch 受控调用（白名单 + 签名绑定）
        meta = _LIBRARY_SURFACE[spec.name]
        entry["serviceable"] = True
        entry["call_via"] = {"dispatcher": "library_dispatch",
                             "functions": meta["functions"],
                             "constants": meta["constants"]}
    elif spec.kind == R.LIBRARY and spec.name in _LIBRARY_SURFACE:
        entry["reason"] = LIBRARY_SCOPED_REASON
    else:
        entry["reason"] = LIBRARY_REASON
    entry["expose_to_web"] = spec.web_exposed and entry["serviceable"]
    return entry


def surface_fingerprint(surface: dict) -> str:
    """按内容算指纹。

    **必须排除 `fingerprint` 字段本身**，否则改动其它字段时旧指纹不会被发现 ——
    那会让一致性检查变成「不会失败的检查」。
    """
    body = {k: v for k, v in surface.items() if k != "fingerprint"}
    return hashlib.sha256(
        json.dumps(body, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()


def build_surface() -> dict:
    """构造工具面清单（确定性输出，可直接做漂移比对）。"""
    groups: list[dict] = []
    for gid, title, expose, source_groups in SURFACE_GROUPS:
        specs = [s for s in R.TOOL_REGISTRY if s.group in source_groups]
        entries = [_entry(s) for s in sorted(specs, key=lambda x: x.name)]
        groups.append({
            "id": gid,
            "title": title,
            "expose_to_web": expose,
            "tool_count": len(entries),
            "tools": entries,
        })

    web_tools = [e for g in groups if g["expose_to_web"] for e in g["tools"]]
    allowed = sorted(e["id"] for e in web_tools if e["serviceable"])
    pending = [
        {"id": e["id"], "name": e["name"], "reason": e["reason"]}
        for e in sorted(web_tools, key=lambda x: x["id"]) if not e["serviceable"]
    ]

    surface = {
        "surface_version": SURFACE_VERSION,
        "generated_from": "runtime/orchestrator/registry.py",
        "groups": groups,
        "web": {
            "allowedTools": allowed,
            "excluded_groups": [g["id"] for g in groups if not g["expose_to_web"]],
            "tool_count": len(web_tools),
            "serviceable_count": len(allowed),
            "pending": pending,
        },
    }
    surface["fingerprint"] = surface_fingerprint(surface)
    return surface


def verify_manifest(path: str) -> list[str]:
    """校验磁盘上的清单：既查**内容自洽**，也查**是否与当前注册表一致**。

    三项检查缺一不可（少哪项都会让门禁变成装饰）：

      1. 内容重算指纹 == 文件里存的指纹 —— 否则说明清单被改动过；
      2. **对磁盘内容跑 `check_surface()`** —— 否则改动过的清单能绕过不变量；
      3. 内容指纹 == 当前 `build_surface()` 的指纹 —— 否则说明清单已过期。
    """
    if not os.path.isfile(path):
        return [f"缺少生成的工具面清单：{path}"]
    with open(path, encoding="utf-8") as fh:
        on_disk = json.load(fh)

    problems: list[str] = []
    stored = on_disk.get("fingerprint", "")
    computed = surface_fingerprint(on_disk)
    if stored != computed:
        problems.append("工具面清单内容与自身指纹不符（文件被改动过）")

    problems.extend(check_surface(on_disk))

    if computed != build_surface()["fingerprint"]:
        problems.append("工具面清单已过期：与当前注册表不一致，请重新生成")
    return problems


def check_surface(surface: dict | None = None) -> list[str]:
    """校验工具面不变量。返回问题清单（空 = 通过）。

    五条不变量：
      1. `hardware-tools` 组必须 `expose_to_web=false`；
      2. 该组内任何条目都不得 `expose_to_web=true`；
      3. `web.allowedTools` 不得出现任何硬件工具 id；
      4. `allowedTools` 里的每个 id 都必须在组内存在，且 `serviceable=true`；
      5. `excluded` 组的脚本不得出现在任何工具面里。
    """
    s = surface or build_surface()
    problems: list[str] = []

    hw_group = next((g for g in s["groups"] if g["id"] == "hardware-tools"), None)
    if hw_group is None:
        problems.append("缺少 hardware-tools 组")
    else:
        if hw_group["expose_to_web"]:
            problems.append("hardware-tools 组被标记为可下发 Web 层（红线）")
        leaked = [e["id"] for e in hw_group["tools"] if e["expose_to_web"]]
        if leaked:
            problems.append(f"hardware-tools 组内有条目 expose_to_web=true：{leaked}")

    hw_ids = set(hardware_tool_ids(s))
    crossed = sorted(hw_ids & set(s["web"]["allowedTools"]))
    if crossed:
        problems.append(f"Web 层 allowedTools 混入硬件工具（红线）：{crossed}")

    by_id = {e["id"]: e for g in s["groups"] for e in g["tools"]}
    for tid in s["web"]["allowedTools"]:
        entry = by_id.get(tid)
        if entry is None:
            problems.append(f"allowedTools 里的 {tid} 不在任何工具面内")
        elif not entry["serviceable"]:
            problems.append(f"allowedTools 里的 {tid} 不可服务（库模块），不应下发")

    excluded = {_tool_id(sp) for sp in R.TOOL_REGISTRY if sp.group == R.EXCLUDED}
    surfaced = set(by_id)
    if excluded & surfaced:
        problems.append(f"自检脚本出现在工具面里：{sorted(excluded & surfaced)}")

    if s["web"]["tool_count"] != len(
            [e for g in s["groups"] if g["expose_to_web"] for e in g["tools"]]):
        problems.append("web.tool_count 与实际条目数不一致")
    return problems


def as_allowed_tools(surface: dict | None = None) -> tuple[str, ...]:
    """直接喂给 CodeBuddy SDK `allowedTools` 的白名单。"""
    s = surface or build_surface()
    return tuple(s["web"]["allowedTools"])


def hardware_tool_ids(surface: dict | None = None) -> tuple[str, ...]:
    """hardware-tools 组内全部工具 id。"""
    s = surface or build_surface()
    grp = next((g for g in s["groups"] if g["id"] == "hardware-tools"), None)
    return tuple(e["id"] for e in (grp["tools"] if grp else []))


def web_tool_ids(surface: dict | None = None) -> tuple[str, ...]:
    """可下发 Web 层的工具 id（plan/evidence 组）。"""
    s = surface or build_surface()
    return tuple(sorted(e["id"] for g in s["groups"] if g["expose_to_web"]
                        for e in g["tools"]))


def main(argv: list[str]) -> int:
    """命令行入口：--out 生成清单，--check 校验。"""
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="", help="写出清单 JSON 到该路径")
    ap.add_argument("--check", action="store_true", help="只校验，不写文件")
    args = ap.parse_args(argv)

    surface = build_surface()
    problems = check_surface(surface)

    if args.out and not args.check:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        with open(args.out, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(surface, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")
        print(f"清单已写出：{args.out}")

    for g in surface["groups"]:
        print(f"  {g['id']:16} 工具 {g['tool_count']:>3}  下发 Web "
              f"{'是' if g['expose_to_web'] else '否'}")
    print(f"  web.allowedTools  {surface['web']['serviceable_count']}")
    print(f"  web.pending       {len(surface['web']['pending'])}（需受控调用包装）")
    print(f"  fingerprint       {surface['fingerprint'][:16]}…")
    print(f"  问题数            {len(problems)}")
    for p in problems:
        print(f"     * {p}")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
