#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""工具注册表：专家包内每个脚本的**能力面归属**与**可调用方式**。

为什么需要它
------------
`tools.py` 原先用 `available_tools()` 只查**文件是否存在**，就宣称工具可用。
实测（2026-09-15）这会造成一个静默失效：`review_truth.py`（400 行）与
`project_artifact_binding.py`（174 行）**没有 `__main__` 入口**，以 CLI 方式调用得到

    退出码 0，stdout 为空

而 `static_gate_from_exit(0)` 把它映射成 **PASS** —— 静态门禁的两条规则
**从未真正执行过，却每次返回通过**。这正是本项目历史上误判的同一类根因。

因此本模块把三件事变成机器可查的事实：

1. **可调用方式**（`ToolKind`）：`cli` 必须有 `__main__` 入口；`library` 只能被 import。
   两者声明反了，`verify_registry()` 直接报错。
2. **能力面分组**（`ToolGroup`）：决定它能否下发到 Web 层。
   `hardware` 组**永不下发**（对应红线"Web 层工具列表里无任何硬件工具"）。
3. **归属节点**：每个工具挂在图里的哪个节点下，便于"某节点有哪些工具可用"。

分组判据（写死，避免各人各解）
------------------------------
* `PLAN`     —— 与设备无关：解析、设计、静态门禁、项目参考。可下发 Web 层（只读）。
* `EVIDENCE` —— 与设备无关：证据解析、报告生成。可下发 Web 层（只读）。
* `HARDWARE` —— **直接接触设备/通道**，或**只服务于硬件执行流程**的模块。不下发 Web 层。
* `EXCLUDED` —— 自检与测试工具，不进入工具面。

计数口径（实测）
----------------
`skills/` 下非测试 `.py` 共 **80** 个，其中 **49** 个有 `__main__` 入口、**31** 个没有。
本表必须覆盖全部 80 个，`runtime/tools/check_tool_coverage.py` 会逐条核对。
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass

__all__ = [
    "EXCLUDED",
    "HARDWARE",
    "PLAN",
    "EVIDENCE",
    "SCRIPT_DIRS",
    "TOOL_REGISTRY",
    "ToolSpec",
    "classify_on_disk",
    "find_tool",
    "library_tools",
    "cli_tools",
    "tools_for_node",
    "tools_in_group",
    "verify_registry",
    "web_surface",
]

PLAN = "plan"
EVIDENCE = "evidence"
HARDWARE = "hardware"
EXCLUDED = "excluded"

CLI = "cli"
LIBRARY = "library"

#: 脚本所在目录（相对包根）。注册表只存 basename，加载时在这些目录里解析。
SCRIPT_DIRS = (
    "skills/uds-diagnostic-test/scripts",
    "skills/srs-uds-testcase-designer/scripts",
    "skills/srs-doc-extract/scripts",
    "skills/cybersecurity-test/scripts",
    "skills/lin-network-test/scripts",
    "skills",
)

_MAIN_RX = re.compile(r"__name__\s*==")
_SKIP_DIRS = {"__pycache__", "references", "data", "templates", "schemas"}


@dataclass(frozen=True)
class ToolSpec:
    """一个脚本的能力面归属。

    `kind` 是**可调用方式**，不是"重要性"：
      * `cli`     —— 有 `__main__` 入口，可用子进程调用；
      * `library` —— 无入口，只能 `import` 使用。**按 CLI 调它会静默返回空输出。**
    """

    name: str
    group: str
    node: str
    kind: str
    purpose: str

    @property
    def is_hardware(self) -> bool:
        return self.group == HARDWARE

    @property
    def web_exposed(self) -> bool:
        """能否下发到 Web 层：只有 PLAN / EVIDENCE 可以（且都是只读）。"""
        return self.group in (PLAN, EVIDENCE)


# (name, group, node, kind, purpose)
_T = (
    # ---------------- 入口与路由 ----------------
    ("reference_router", PLAN, "route_and_mount_reference", CLI, "按意图选唯一主规范分支"),

    # ---------------- 输入体检 ----------------
    ("srs_input_analyzer", PLAN, "inspect_inputs", CLI, "SRS 输入体检与缺口清单"),
    ("extract_srs_text", PLAN, "inspect_inputs", CLI, "抽取 SRS 全文文本"),
    ("srs_focus_extractor", PLAN, "inspect_inputs", CLI, "SRS 重点章节精读"),
    ("uds_survey_parser", PLAN, "inspect_inputs", CLI, "诊断调查表解析"),
    ("dbc_parser", PLAN, "inspect_inputs", CLI, "DBC 解析"),
    ("ldf_parser", PLAN, "inspect_inputs", CLI, "LDF 解析"),
    ("sddb_extract", PLAN, "inspect_inputs", CLI, "SDDB/CDD 诊断库抽取"),
    ("project_context_builder", PLAN, "inspect_inputs", CLI, "项目上下文构建"),
    ("project_parser_adapter", PLAN, "inspect_inputs", CLI, "项目资料解析适配"),
    ("input_pack_validator", PLAN, "inspect_inputs", CLI, "输入包完整性校验"),
    ("portable_pack_reader", PLAN, "inspect_inputs", LIBRARY, "便携项目包读取"),
    ("project_capability_gate", PLAN, "inspect_inputs", LIBRARY, "项目能力门禁"),
    ("project_fact_mapper", PLAN, "inspect_inputs", LIBRARY, "项目事实映射"),
    ("project_config", PLAN, "inspect_inputs", LIBRARY, "项目配置装载"),
    ("jcodemunch_bridge", PLAN, "inspect_inputs", CLI,
     "jCodeMunch 代码索引检索桥（只读子命令白名单）"),
    ("web_probe", PLAN, "inspect_inputs", CLI,
     "只读网页探测（Playwright 截图/文本，http/https 白名单）"),

    # ---------------- 设计与生成 ----------------
    ("uds_full_matrix_generator", PLAN, "generate_or_design", CLI, "对象驱动全量矩阵"),
    ("uds_req_matrix_generator", PLAN, "generate_or_design", CLI, "需求驱动矩阵"),
    ("steps_generator", PLAN, "generate_or_design", CLI, "操作步骤生成"),
    ("gen_case_scripts", PLAN, "generate_or_design", CLI, "用例脚本生成"),
    ("uds_test_generator", PLAN, "generate_or_design", CLI, "UDS 测试生成"),
    ("build_testcase_xlsx", PLAN, "generate_or_design", CLI, "用例表 xlsx 产出"),
    ("build_testcase_template", PLAN, "generate_or_design", CLI, "用例表模板产出"),
    ("generate_reference_cases", PLAN, "generate_or_design", CLI, "参考用例生成"),
    ("generate_lin_matrix_cli", PLAN, "generate_or_design", CLI, "LIN 矩阵生成"),
    ("script_header_template", PLAN, "generate_or_design", CLI, "脚本头模板"),
    ("testcase_headers", PLAN, "generate_or_design", LIBRARY, "用例表头定义"),
    ("lin_case_matrix", PLAN, "generate_or_design", LIBRARY, "LIN 用例矩阵"),
    ("lin_case_model", PLAN, "generate_or_design", LIBRARY, "LIN 用例模型"),
    ("swdl_case_generator", PLAN, "generate_or_design", LIBRARY, "SWDL 用例生成"),
    ("cybersecurity_case_generator", PLAN, "generate_or_design", LIBRARY, "网络安全用例生成"),
    ("generate_security_cases", PLAN, "generate_or_design", LIBRARY, "安全用例生成"),
    ("reference_case_adapter", PLAN, "generate_or_design", LIBRARY, "参考用例适配"),

    # ---------------- 静态门禁 ----------------
    ("case_lint", PLAN, "static_gate", CLI, "用例规则 lint"),
    ("script_review", PLAN, "static_gate", CLI, "生成后脚本审查"),
    ("review_truth", PLAN, "static_gate", LIBRARY, "审查真实性核对（无 CLI 入口）"),
    ("project_artifact_binding", PLAN, "static_gate", LIBRARY, "用例↔脚本绑定核对（无 CLI 入口）"),
    ("check_template_drift", PLAN, "static_gate", CLI, "模板漂移检查"),
    ("consistency_check", PLAN, "static_gate", CLI, "一致性检查"),
    ("coverage", PLAN, "static_gate", CLI, "覆盖率检查"),
    ("req_coverage", PLAN, "static_gate", CLI, "需求覆盖率检查"),
    ("source_coverage", PLAN, "static_gate", CLI, "来源覆盖率检查"),
    ("review_depth", PLAN, "static_gate", CLI, "审查深度检查"),
    ("swdl_case_review", PLAN, "static_gate", LIBRARY, "SWDL 用例审查"),
    ("uds_case_gate", PLAN, "static_gate", LIBRARY, "用例设计门禁词汇"),
    ("security_framework", PLAN, "static_gate", LIBRARY, "安全测试框架"),
    ("security_scan", PLAN, "static_gate", LIBRARY, "安全扫描"),

    # ---------------- 证据与报告 ----------------
    ("asc_evidence", EVIDENCE, "static_gate", CLI, "ASC 证据记录与封存"),
    ("swdl_trace_import", EVIDENCE, "static_gate", CLI, "轨迹导入与 LIN-TP 重组"),
    ("build_report", EVIDENCE, "static_gate", CLI, "报告构建"),
    ("build_framework", EVIDENCE, "static_gate", CLI, "报告框架构建"),
    ("report_to_html", EVIDENCE, "static_gate", CLI, "报告转 HTML（唯一报告入口）"),
    ("error_log", EVIDENCE, "static_gate", CLI, "错误日志"),
    ("parse_cache", EVIDENCE, "static_gate", CLI, "解析缓存"),
    ("trace_env_mixin", EVIDENCE, "static_gate", CLI, "轨迹环境混入"),
    ("swdl_report_adapter", EVIDENCE, "static_gate", LIBRARY, "SWDL 报告适配"),
    ("result_contract", EVIDENCE, "static_gate", LIBRARY, "结果词汇契约"),

    # ---------------- 硬件执行（不下发 Web 层）----------------
    ("uds_runner", HARDWARE, "hardware_gate_and_execute", CLI, "UDS 执行器（设备）"),
    ("can_init", HARDWARE, "hardware_gate_and_execute", CLI, "通道初始化与占用检查"),
    ("link_check", HARDWARE, "hardware_gate_and_execute", CLI, "链路通探测"),
    ("expectation_check", HARDWARE, "hardware_gate_and_execute", CLI, "期望值核对"),
    ("tp_layout", HARDWARE, "hardware_gate_and_execute", CLI, "传输层布局"),
    ("timing_trace", HARDWARE, "hardware_gate_and_execute", CLI, "高实时时序采集"),
    ("nrc_guide", HARDWARE, "hardware_gate_and_execute", CLI, "NRC 判定指引"),
    ("rsa_4096", HARDWARE, "hardware_gate_and_execute", CLI, "0x27 安全访问材料"),
    ("seedkey_gen2", HARDWARE, "hardware_gate_and_execute", CLI, "SeedKey 计算"),
    ("execution_profile", HARDWARE, "hardware_gate_and_execute", CLI, "执行配置装载"),
    ("f1l1_uds", HARDWARE, "hardware_gate_and_execute", LIBRARY, "F1L1 设备收发（设备）"),
    ("xcdev_wrapper", HARDWARE, "hardware_gate_and_execute", LIBRARY, "驱动 DLL 封装（设备）"),
    ("win_timer", HARDWARE, "hardware_gate_and_execute", LIBRARY, "高精度计时（设备）"),
    ("timing_case_runner", HARDWARE, "hardware_gate_and_execute", LIBRARY, "时序用例执行（设备）"),
    ("lin_tp", HARDWARE, "hardware_gate_and_execute", LIBRARY, "LIN-TP 组帧与重组"),
    ("lin_pci", HARDWARE, "hardware_gate_and_execute", LIBRARY, "LIN PCI 编解码"),
    ("flow_contract", HARDWARE, "hardware_gate_and_execute", LIBRARY, "流程契约词汇"),
    ("partition_model", HARDWARE, "hardware_gate_and_execute", LIBRARY, "分区模型"),
    ("session_flow", HARDWARE, "hardware_gate_and_execute", LIBRARY, "会话流程"),
    ("session_keepalive", HARDWARE, "hardware_gate_and_execute", LIBRARY, "会话保活"),
    ("swdl_flow", HARDWARE, "hardware_gate_and_execute", LIBRARY, "SWDL 主流程"),
    ("swdl_architecture", HARDWARE, "hardware_gate_and_execute", LIBRARY, "SWDL 架构模型"),

    # ---------------- 自检（不进入工具面）----------------
    ("run_tests", EXCLUDED, "", CLI, "包内回归自检"),
)

TOOL_REGISTRY: tuple[ToolSpec, ...] = tuple(ToolSpec(*row) for row in _T)


def _scan_scripts(root: str) -> dict[str, list[str]]:
    """返回 {basename: [相对路径, ...]}，跳过测试与缓存。"""
    found: dict[str, list[str]] = {}
    for sub in SCRIPT_DIRS:
        base = os.path.join(root, *sub.split("/"))
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            if not name.endswith(".py"):
                continue
            if name.startswith("test_") or name == "testsupport.py" or name == "__init__.py":
                continue
            rel = os.path.join(sub, name).replace(os.sep, "/")
            found.setdefault(name[:-3], []).append(rel)
    return found


def has_main_entry(path: str) -> bool:
    """脚本是否有 `__main__` 入口。没有入口却按 CLI 调用，只会得到空输出。"""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return bool(_MAIN_RX.search(fh.read()))
    except OSError:
        return False


_has_main_entry = has_main_entry      # 兼容内部旧引用


def verify_registry(root: str) -> list[str]:
    """校验注册表与磁盘事实是否一致。返回问题清单（空 = 一致）。

    三类检查：
      * 每个注册项的脚本必须存在，且 basename 唯一；
      * `cli` 声明的脚本**必须有 `__main__` 入口**（否则按 CLI 调会静默返回空输出）；
      * `library` 声明的脚本**不应有 `__main__` 入口**（有则说明它其实是 CLI，声明过窄）。
    """
    problems: list[str] = []
    on_disk = _scan_scripts(root)

    seen: set[str] = set()
    for spec in TOOL_REGISTRY:
        if spec.name in seen:
            problems.append(f"注册表内重复条目：{spec.name}")
        seen.add(spec.name)
        hits = on_disk.get(spec.name, [])
        if not hits:
            problems.append(f"脚本不存在：{spec.name}.py")
            continue
        if len(hits) > 1:
            problems.append(f"同名脚本出现在多处，无法唯一定位：{spec.name} -> {hits}")
            continue
        path = os.path.join(root, *hits[0].split("/"))
        has_main = _has_main_entry(path)
        if spec.kind == CLI and not has_main:
            problems.append(
                f"声明为 cli 但没有 __main__ 入口（按 CLI 调用会静默返回空输出）：{hits[0]}")
        if spec.kind == LIBRARY and has_main:
            problems.append(f"声明为 library 但其实有 __main__ 入口：{hits[0]}")

    known = {s.name for s in TOOL_REGISTRY}
    for name, hits in sorted(on_disk.items()):
        if name not in known:
            problems.append(f"磁盘上的脚本未登记（未分类）：{hits[0]}")
    return problems


def classify_on_disk(root: str) -> dict[str, str]:
    """磁盘事实分类：{相对路径: 'cli' | 'library'}。"""
    out: dict[str, str] = {}
    for _name, hits in _scan_scripts(root).items():
        for rel in hits:
            path = os.path.join(root, *rel.split("/"))
            out[rel] = CLI if _has_main_entry(path) else LIBRARY
    return out


def _spec(name: str) -> ToolSpec | None:
    for s in TOOL_REGISTRY:
        if s.name == name:
            return s
    return None


def find_tool(name: str) -> ToolSpec | None:
    """按脚本 basename 查注册项；未登记返回 None（不猜）。"""
    return _spec(name)


def cli_tools() -> tuple[ToolSpec, ...]:
    """注册表中 kind=cli 的全部条目。"""
    return tuple(s for s in TOOL_REGISTRY if s.kind == CLI)


def library_tools() -> tuple[ToolSpec, ...]:
    """注册表中 kind=library 的全部条目。"""
    return tuple(s for s in TOOL_REGISTRY if s.kind == LIBRARY)


def tools_for_node(node: str) -> tuple[ToolSpec, ...]:
    """某图节点可用的工具（按 node 归属过滤）。"""
    return tuple(s for s in TOOL_REGISTRY if s.node == node)


def tools_in_group(group: str) -> tuple[ToolSpec, ...]:
    """某能力面分组（plan/evidence/hardware）的全部条目。"""
    return tuple(s for s in TOOL_REGISTRY if s.group == group)


def web_surface() -> tuple[ToolSpec, ...]:
    """可下发到 Web 层的工具：PLAN / EVIDENCE（只读）。

    **`hardware` 组永远不在这里** —— 这是红线，用结构而不是纪律来保证。
    """
    return tuple(s for s in TOOL_REGISTRY if s.web_exposed)
