# runtime/orchestrator —— 受控编排层

T1.4 起建立。本目录承载**唯一状态机**、**条件边语义**、**目录 ACL**、**哈希链**、
**审批令牌**与**五主节点图内核**。当前生产执行器是 `GraphRunner`；
`langgraph_adapter.py` 只把同一份节点/边语义编译为可选 LangGraph 图，不能反过来成为另一套状态机。

当前工具面：79 个脚本已分类，plan/evidence 目录有 56 个能力，其中 MCP `allowedTools`
只含 15 个可直接调用项（1 个无文件副作用 CLI、14 个纯库模块）；其余 41 个列入
`web.pending`，由受控运行流程处理文件输入与输出。下文 T5.x 数字保留为阶段历史。

当前内容：

| 文件 | 作用 |
|---|---|
| `state.py` | 运行时词汇表唯一真源 + 状态迁移表 + 条件边语义 + run 级结论推导 |
| `acl.py` | 运行目录 ACL 与单写者矩阵；`NodeResult` 四字段自洽强校验 |
| `artifact_paths.py` | 产物根解析：run 树与交付物根一律外置到专家包之外（默认 `%LOCALAPPDATA%\AETEX`），run 终态把 `05_final/` 链接发布到扁平交付目录 |
| `hashchain.py` | 工件哈希链：摘要引用、链根、拓扑序、篡改与伪造检测 |
| `approval.py` | 审批令牌：签发、四要素校验、与 `ApprovedOrder` 联动 |
| `graph.py` | **生产 GraphRunner**：五主节点、条件边、审计落盘、检查点与恢复 |
| `langgraph_adapter.py` | 可选 LangGraph 编译器；只映射 `graph.py` 的既有语义 |
| `runtime_cli.py` | 唯一生产注入边界：构造 ModelInvoker、运行/恢复 GraphRunner；Web 只提交命令、读事件与审批 |
| `production_nodes.py` | 资料路由、确定性输入体检、受限测试设计草案与静态审查门 |
| `tools.py` | 既有 CLI 适配：`reference_router` / `case_lint` / `script_review` 等 |

---

## 1 为什么状态机先于图存在

图执行器（当前是 GraphRunner；可选编译为 LangGraph）只是把状态机"跑起来"的载体。如果先搭图再补语义，就会出现
「图里能走通、但业务上不该走」的路径，而且没法在代码层拦住。
所以顺序是：**先冻结词汇表与迁移表，再让图去驱动它**。

---

## 2 状态主链

```
NEW → INSPECTED → DESIGNED → STATIC_PASSED → RUNNING → CAPTURED → ASSESSED → CLOSED
```

每一步的进入条件、事件提交者、状态写入者都固化在 `TRANSITIONS` 里。
非法迁移（跳步、反向、自环）由 `assert_transition()` 抛 `IllegalTransition`。

回退只允许白名单内的两种，用于「证据不足退回重做」：

| 当前位置 | 允许回退到 | 场景 |
|---|---|---|
| `CAPTURED` | `DESIGNED` | 执行完成但发现用例设计有误 |
| `ASSESSED` | `DESIGNED` / `CAPTURED` | 判定阶段发现证据或设计问题 |

---

## 3 三条铁律的代码位置

| 铁律 | 落在哪 |
|---|---|
| R1 只有 Terra 能写状态 | 每条 `TransitionRule.writer` 恒为 `AgentRole.TERRA`；`test_only_terra_writes_state` 逐个断言 |
| R4 条件边只读代码枚举 | `GateStatus` + `EXECUTION_BLOCKING_GATES`；`may_enter_execution()` 是唯一判定入口 |
| R5 证据不足只能 INCONCLUSIVE | `derive_final_verdict()`；`test_incomplete_evidence_never_pass` 覆盖 |

---

## 4 条件边语义

```python
from runtime.orchestrator import state

state.may_enter_execution("PASS")             # True
state.may_enter_execution("REVIEW_REQUIRED")  # False
state.requires_human("BLOCKED")               # True
```

| 集合 | 取值 | 含义 |
|---|---|---|
| `EXECUTION_BLOCKING_GATES` | PASS 之外的**全部** | 不进硬件执行子图 |
| `HUMAN_INTERVENTION_GATES` | `REVIEW_REQUIRED` / `BLOCKED` | 需人工介入 |
| `ABORTING_GATES` | `ABORTED` | 本轮不再推进 |

`EXECUTION_ENTRY_STATES` 只有 `STATIC_PASSED` 一个：**没走完静态门禁，图里根本不存在通往执行的边。**

---

## 5 run 级结论推导（红线 R5 的代码化）

```python
state.derive_final_verdict(["PASS"], evidence_complete=True)    # -> PASS
state.derive_final_verdict(["PASS"], evidence_complete=False)   # -> INCONCLUSIVE
state.derive_final_verdict(["PASS", "BLOCKED"], ...)            # -> None（不结案）
state.derive_final_verdict(["PASS"], ..., aborted=True)         # -> None
```

返回 `None` 表示**本轮不产生结论**，状态应停在原地，而不是硬给一个三态值。

| 情形 | 结果 |
|---|---|
| `aborted=True` | `None` |
| 存在用例 `BLOCKED` | `None`（前置受限、从未执行完） |
| 用例列表为空 | `None` |
| 证据不完整 / 存在未解释现象 | `INCONCLUSIVE` |
| 有 `FAIL` | `FAIL` |
| 无 `FAIL` 且有 `PASS` | `PASS` |
| 全是 `NA` / `SKIP` | `INCONCLUSIVE` |

> `BLOCKED`（从未执行）与 `INCONCLUSIVE`（已执行但证据不足）必须区分，
> 不得互相顶替，更不得降级为 PASS。

---

## 6 词汇表真源

10 个运行时词汇表定义在本模块的 Enum 里，`runtime/contracts/enums.json`
的 `source_of_truth` 指向它们，校验器逐条比对，不一致即 ERROR。

| 词汇表 | Enum |
|---|---|
| `task_state` | `TaskState` |
| `gate_status` | `GateStatus` |
| `node_status` | `NodeStatus` |
| `run_final_verdict` | `RunFinalVerdict` |
| `risk_level` | `RiskLevel` |
| `evidence_kind` | `EvidenceKind` |
| `memory_kind` | `MemoryKind` |
| `approval_status` | `ApprovalStatus` |
| `agent_role` | `AgentRole` |
| `graph_node` | `GraphNode` |

**规则：任何运行时词汇表都必须先有代码真源，再登记到 `enums.json`。
不允许存在只在 JSON 里写、没有代码真源的词汇表。**

---

## 7 目录 ACL 与单写者矩阵（T1.6）

运行目录布局（相对 `runs/<run_id>/`）：

| 目录 | 内容 | 唯一写入者 |
|---|---|---|
| `01_command/` | 请求、输入体检结论、路由挂载清单 | Terra |
| `02_plan/` | 用例草案、脚本、静态门禁记录 | 计划 worker |
| `03_execution/` | RunManifest、ASC、原始响应 | 执行 worker |
| `04_evidence/` | EvidenceIndex、VerdictDraft | 证据 worker |
| `05_final/` | 最终结论、报告、发布说明 | Terra |

人工审批人**不写运行目录**：只签令牌，令牌不落运行目录。

```python
from runtime.orchestrator import acl

acl.assert_write("plan_worker", "02_plan/draft_plan.json")   # OK
acl.assert_write("plan_worker", "03_execution/x.json")       # AclViolation
acl.can_write("terra", "05_final/final_verdict.json")        # True
```

三重防护：

1. **路径安全检查**：绝对路径、盘符、反斜杠、`.`、`..`、空段一律拒绝，
   防借路径规范化绕过目录限制。
2. **节点与目录强绑定**：`NODE_DIRS` 决定哪个节点只能写哪些目录，
   `route_and_mount_reference` 写不到 03，`hardware_gate_and_execute` 只能写 03/04。
3. **`NodeResult` 四字段自洽**：`node / produced_by / writes_to / artifact_path`
   必须互相一致，且 `artifact_path` 首段等于 `writes_to`：

```python
errors = acl.validate_node_result(node_result_payload)   # [] 表示通过
```

---

## 8 工件哈希链（T1.7）

```
DraftPlan --sha--> GateRecord --sha--> RunManifest --sha--> EvidenceIndex --sha--> FinalVerdict
```

```python
from runtime.orchestrator import hashchain as H

plan = H.record_for(run_dir, "02_plan/draft_plan.json", kind="draft_plan")
gate = H.record_for(run_dir, "02_plan/static_gate.record.json",
                    inputs=[plan.sha256], kind="gate")
H.assert_chain([plan, gate], run_dir=run_dir)   # 失败抛 ChainBroken
```

四条设计原则：

| 原则 | 理由 |
|---|---|
| 引用用**摘要**不用路径 | 路径会变、会被覆盖；摘要不会 |
| 上游必须**可达** | `inputs` 里每个摘要都要能在本 run 解析到，否则就是"引用不存在的证据" |
| 必须**无环** | 成环说明有人用后置工件反推前置工件 |
| 支持**磁盘核对** | 带 `run_dir` 时逐文件重算，防「记录没改、文件被改」 |

`verify()` 能报出的具体错误：文件被篡改、引用悬空、链成环、同路径两个摘要（被覆盖）、
文件缺失、摘要格式非法、字节数不一致。

---

## 9 审批令牌（T1.8）

红线 R6 的代码化：

```python
from runtime.orchestrator import approval as A

tok = A.issue(token_id="TOK-1", order_id="ORD-1", run_id="RUN-1",
              actions=["0x10", "0x27", "0x34"],
              valid_from=..., valid_until=...,
              approved_by="human_approver",          # 只能是人工
              credential_ref="credential://aetex/bbs-p519/swdl-sbl")

A.verify(tok, run_id="RUN-1", action="0x27")          # 通过
A.check(tok, run_id="RUN-2", action="0x27")           # (False, "RUN_MISMATCH")
A.check(tok, run_id="RUN-1", action="0x34")           # (False, "ACTION_NOT_GRANTED")
```

| 性质 | 落地方式 |
|---|---|
| **人工签发** | `issue()` 里 `approved_by` 非 `HUMAN_APPROVER` 直接抛 `NOT_HUMAN_APPROVER` |
| **四要素绑定** | run_id / 动作 / 有效期必须同时匹配，不接受模糊匹配或就近有效期 |
| **只存引用** | `credential_ref` 只接受 `credential://` 形式；命中私钥或长十六进制/base64 即抛 `SECRET_IN_TOKEN` |

原因码全集：`NO_TOKEN` / `RUN_MISMATCH` / `ACTION_NOT_GRANTED` / `NOT_YET_VALID` /
`EXPIRED` / `REVOKED` / `REJECTED` / `NOT_APPROVED`。

`validate_approved_order(order, token)` 把订单与令牌串起来校验：
run 一致、引用一致、令牌已批准、**风险 HIGH/CRITICAL 或 `reversible=false` 必须人工签发**、
订单里的每个服务都在令牌授权范围内。

---

## 10 五主节点图内核（T2.1–T2.3 / T2.5）

### 生产执行器与 LangGraph 的边界

`GraphRunner` 是当前唯一生产执行器与检查点格式的真源。真正要证明的是**语义**：静态失败不能进执行子图、
执行必须持令牌、每步留审计、中断能恢复。这些语义与框架无关；`langgraph_adapter.py` 仅在已安装依赖时
把同一张图编译给 LangGraph 验证或未来替换试验，不能被 Web 或生产 CLI 直接当作另一条流程。

### 节点与状态迁移

| 节点 | 入口状态 | 出口状态 |
|---|---|---|
| `route_and_mount_reference` | NEW | （不变，只挂资料） |
| `inspect_inputs` | NEW | INSPECTED |
| `generate_or_design` | INSPECTED | DESIGNED |
| `static_gate` | DESIGNED | STATIC_PASSED |
| `hardware_gate_and_execute` | STATIC_PASSED | RUNNING → CAPTURED |

**节点不碰状态**：所有迁移由 Runner 以 Terra 身份完成（红线 R1），节点只提交事实与门禁值。
执行子图通过 `entry_via=(RUNNING,)` 在令牌校验通过后、节点体执行前进入 RUNNING。

### 条件边

```python
from runtime.orchestrator import graph as G

G.next_node(GraphNode.STATIC_GATE, "PASS")             # hardware_gate_and_execute
G.next_node(GraphNode.STATIC_GATE, "REVIEW_REQUIRED")  # None —— 边不存在
G.next_node(GraphNode.STATIC_GATE, None)               # None —— 不给结论就停下
```

三条硬规则：

1. 目标含执行子图时，**只有 PASS 才存在这条边**；
2. 门禁节点（`produces_gate=True`）没给结论一律停下，**不靠默认放行**；
3. 任何非 PASS 结论都停下。

非门禁节点（挂资料、生成草案）本来就不出结论，按默认路径推进。

### 运行

```python
ctx = G.RunContext(run_id="RUN-1", flow="basic_uds", run_dir=runs_dir, token=tok)
G.GraphRunner(nodes).run(ctx)
```

每步落三样东西：`NodeResult`（过 ACL 四字段校验 + 契约 schema）、`GateRecord`（门禁结论）、
检查点。工件自动进哈希链，`inputs` 存**上游摘要**；引用不存在的前置证据直接判错。

### 中断恢复

```python
ctx = G.load_checkpoint(runs_dir)
ctx.run_dir = runs_dir
G.GraphRunner(nodes).run(ctx)      # 失败节点会被重试，而不是被跳过
```

`resolve_entry()` 的三条规则：无记录从头；上次失败**重试同一节点**；上次成功按条件边取下一节点。

### LangGraph 适配

```python
from runtime.orchestrator import langgraph_adapter as LG

LG.available()          # 当前环境为 False
LG.describe_edges()     # 导出 (源节点, 门禁结论, 目标节点|END)，与内核判定逐条比对
LG.build_graph(nodes)   # 编译 GraphRunner 已定义的节点/边；未安装时抛 LangGraphUnavailable
```

适配层不自行安装依赖。要启用需把 `langgraph` 加进 `skills/uds-diagnostic-test/requirements.txt`。

---

## 11 既有 CLI 适配（T2.4 / T2.6）

| 节点 | 调用的既有 CLI |
|---|---|
| `route_and_mount_reference` | `reference_router.py` |
| `static_gate` | `case_lint.py`、`script_review.py`、`review_truth.py`、`project_artifact_binding.py` |

**不重写任何一条既有逻辑**：全部以子进程方式调用原脚本。

### 出口码映射只认「明确通过」

| 退出码 | 含义 | 映射 |
|---|---|---|
| 0 | 全部规则通过 | `PASS` |
| 2 | 存在规则 FAIL，阻断交付 | `REVIEW_REQUIRED` |
| 1 | 输入或项目配置错误 | `ERROR` |
| 其它 / 超时 / 输出无法解析 | 工具异常 | `ERROR` |

**不存在把未知当 PASS 的分支** —— 有专门的测试逐个验证 3/4/127/255/-1/-9/99 全部映射为 ERROR，
且遍历 -2..9 确认只有 0 是 PASS。这正对应本项目历史上「误判 FAIL/PASS」的根因。

```python
from runtime.orchestrator import tools as T

payload, raw = T.reference_router("UDS-over-LIN 使用 F1L1 诊断 NAD 0x3C")
gate, raw = T.case_lint("cases.json")
T.available_tools()      # 预检：适配层引用的 CLI 是否都在
```

`resolve_script()` 只接受包内相对路径，拒绝绝对路径与 `..`，防止适配层变成任意命令执行入口。

---

## 12 验证

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
"$PY" runtime/tools/validate_contracts.py          # 词汇表漂移（含本模块真源比对）
"$PY" -m unittest discover -s runtime/tests        # 状态机 / ACL / 哈希链 / 审批 / 图 / CLI 适配
"$PY" runtime/tools/run_all_tests.py                # 完整门禁（含能力层 49 项回归）
```

测试分布：`test_contracts` 7 · `test_models` 17 · `test_state` 28 · `test_acl` 23 ·
`test_hashchain` 20 · `test_approval` 28 · `test_graph` 34 · `test_tools` 17，共 **174** 项。

## T2.7 / T2.8 工具注册表与可调用性硬化（registry.py）

### 它修掉了一个已经发生的静默假通过

实测（2026-09-15）：`review_truth.py`（400 行）与 `project_artifact_binding.py`（174 行）
**没有 `__main__` 入口**，以 CLI 方式调用得到「退出码 0 + stdout 为空」，
而 `static_gate_from_exit(0)` 把它映射成 **PASS**。

结论：**静态门禁的这两条规则从未真正执行过，却每次返回通过。**
这和本项目历史上误判 FAIL/PASS 是同一类根因 —— 空输出被当成了通过。

根因是 `available_tools()` 只查**文件是否存在**就宣称工具可用。

### 修法：把「能怎么调」变成显式声明 + 硬断言

| 层次 | 做法 |
|---|---|
| 声明 | 注册表为每个脚本声明 `kind`：`cli`（有 `__main__` 入口）或 `library`（只能 import） |
| 断言 | `run_cli` 调用前检查可调用性，不满足即抛 `CliToolError`，**不返回空输出** |
| 语义 | `available_tools()` 从「文件存在」改为「可 CLI 调用」，库模块返回 `False` |
| 棘轮 | `check_tool_coverage.py` 要求磁盘上每个非测试脚本都已登记，新增不登记就红 |

**没有给那两个脚本补 `__main__`** —— 那会改动能力层，违反只增不改。
正确做法是让适配层承认「它是库」，并拒绝按 CLI 调。

### 注册表口径（实测计数）

```
skills/ 下非测试 .py        79
  有 __main__ 入口（cli）   48
  无入口（library）         31
```

| 能力面分组 | 含义 | 数量 | 可下发 Web 层 |
|---|---|---|---|
| `plan` | 解析 / 设计 / 静态门禁（只读） | 46 | 是 |
| `evidence` | 证据解析与报告（只读） | 10 | 是 |
| `hardware` | 接触设备或只服务硬件执行流程 | 22 | **否** |
| `excluded` | 自检与测试 | 1 | 否 |

Web 层能力目录共 **56** 项，实际 `allowedTools` 为 **15** 项；`hardware` 组零混入。

### 按图节点分布

| 节点 | 工具数 |
|---|---|
| `route_and_mount_reference` | 1 |
| `inspect_inputs` | 14 |
| `generate_or_design` | 17 |
| `static_gate` | 24 |
| `hardware_gate_and_execute` | 22 |

> 与 T2 初期只注册 5 个工具相比，工具面从 5 扩到 79，并且每个都有归属与可调用方式。

### 验证

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
"$PY" runtime/tools/check_tool_coverage.py --report baseline/evidence/tool_coverage_2026-09-15.txt
```

门禁输出：`注册项 79 ｜ 可 CLI 48 ｜ 仅库 31 ｜ Web 可直接调用 15`，问题数 0。
该检查已并入 `run_all_tests.py` 作为第 4 阶段，不再是可选脚本。

## T5.5 MCP 工具面三组拆分（mcp_surface.py）

把注册表切成三个**可下发的工具面**，让「硬件不下发」从纪律变成结构。

| 工具面 | 工具数 | 下发 Web 层 | 内容 |
|---|---|---|---|
| `plan-tools` | 46 | **是**（只读） | 解析、输入体检、用例设计、静态门禁 |
| `evidence-tools` | 10 | **是**（只读） | 证据解析、报告生成 |
| `hardware-tools` | 22 | **否** | 通道、设备、执行器 |

### T5.5 阶段的 Web 工具面（历史记录）

```
allowedTools          37   # 可直接喂给 CodeBuddy SDK
web.pending           19   # 库模块，需先写 import 包装
excluded_groups       hardware-tools
```

为什么 `allowedTools` 只有 37 而不是 56：**能下发 ≠ 现在就能调用**。
注册表把 31 个脚本标为 `library`（无 `__main__` 入口），它们没有 import 包装，
所以只出现在清单里、**不进 `allowedTools`**，并逐条列进 `web.pending` 作为 P5 待办。
这样不会出现「工具列表里有它、点了却调不通」的假可用 —— 与 T2.8 修掉的
「空输出当通过」是同一类问题的预防。

### 五条不变量（`check_surface()` 逐条检查）

1. `hardware-tools` 组必须 `expose_to_web=false`；
2. 该组内任何条目都不得 `expose_to_web=true`；
3. `allowedTools` 不得出现任何硬件工具 id；
4. `allowedTools` 里的每个 id 都必须在组内存在且 `serviceable=true`；
5. `excluded` 组的脚本不得出现在任何工具面里。

### ⚠️ 一次「不会失败的检查」（值得记住）

初版清单校验这样写：比对「文件里存的指纹」与「新构建的指纹」。
我把 `hardware__can_init` 注入清单的 `allowedTools` 后跑门禁 —— **竟然 PASS**。
两个缺陷叠加：

| 缺陷 | 后果 |
|---|---|
| 指纹字段存在文件里，改其它字段不会让它失效 | 内容被改也查不出 |
| 不变量跑在**新构建**的清单上，不是磁盘那份 | 被改过的清单绕过不变量 |

修法（`verify_manifest()` 三项缺一不可）：

1. 按**内容重算**指纹（排除 `fingerprint` 字段本身）与存储值比对；
2. **对磁盘内容**跑 `check_surface()`；
3. 内容指纹与当前 `build_surface()` 比对，检出过期。

修完后同一注入被 **3 条独立检查**同时报出：

```
工具面清单内容与自身指纹不符（文件被改动过）
Web 层 allowedTools 混入硬件工具（红线）：['hardware__can_init']
工具面清单已过期：与当前注册表不一致，请重新生成
```

> 教训：**隔离检查必须有负向测试**。只测 happy path 的检查会变成装饰。

### 生成与校验

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
"$PY" runtime/orchestrator/mcp_surface.py --out runtime/dist/web_tool_surface.json
"$PY" runtime/orchestrator/mcp_surface.py --check          # 只校验
```

清单是**生成物**，已并入覆盖度门禁：内容被改动、过期、或混入硬件工具都会让门禁红。
清单指纹：`dac1092913b57fd2…`

---

## T5.6 库模块受控分发（library_dispatch）

**问题**：31 个库模块没有 `__main__` 入口，以 CLI 调用会得到「退出码 0 + 空输出」
从而假通过（T2.7 修掉的缺陷根源）；但它们的能力又不应永远对 Web 层不可见。

**方案**：清单驱动的受控分发，不逐个写 import 包装——

| 件 | 作用 |
|---|---|
| `runtime/tools/gen_library_surface.py` | AST 提取模块级公开函数/字面量常量，生成 `runtime/contracts/library_surface.json`（`--check` 做漂移门禁） |
| `runtime/contracts/library_surface.json` | 白名单：19 个 plan/evidence 库模块、50 个函数、若干常量；hardware 组 12 个库模块（f1l1_uds / xcdev_wrapper 等）**永不进入** |
| `runtime/orchestrator/library_dispatch.py` | 唯一调用入口：清单校验 → 注册表复核（kind/组）→ `inspect.signature` 绑定 → JSON 安全转换 → 256KB 输出上限 |

**安全边界**（硬编码在行为里）：
1. 只放行清单声明的 (模块, 函数/常量)；
2. `MODULE_FORBIDDEN`：hardware/excluded 组、注册表外模块（含 `os` 等标准库）直接拒绝；
3. 参数不匹配报 `BIND_ERROR`，不静默；执行异常报 `CALL_FAILED` 并带原因码；
4. 分发器不提供任何文件写入原语——写入能力仍归执行器层。

**T5.6 阶段的工具面变化（历史记录）**：`allowedTools` 37 → **56**（+19 库模块），`pending` 归零；
每个条目带 `call_via`（CLI 或 `{dispatcher: library_dispatch, functions, constants}`）。

**门禁**：新增第 6 阶段「库模块清单漂移」——能力层 API 变了而清单没再生成就红。
