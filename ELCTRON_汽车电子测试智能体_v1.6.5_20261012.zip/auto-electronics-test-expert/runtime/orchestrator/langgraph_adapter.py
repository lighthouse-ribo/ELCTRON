#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T2.1 LangGraph 适配层（可选）。

定位：**薄适配**，不是语义来源。
图的节点集合、推进规则与条件边判定一律来自 `graph.py`；本模块只负责把同一份
规格编译成 LangGraph 的 `StateGraph`，让「换框架不动语义」成立。

LangGraph 未安装时：
  * `available()` 返回 False；
  * `build_graph()` 抛 `LangGraphUnavailable` 并给出安装指引，
    **不会静默退化成另一套实现**（那样会掩盖依赖缺失）。

安装：把 `langgraph` 加进 `skills/uds-diagnostic-test/requirements.txt` 后再装。
本层不自行安装依赖。
"""
from __future__ import annotations

from typing import Any

from .graph import GRAPH_NODES, NEXT_NODE, NodeFn, next_node
from .state import GraphNode

__all__ = ["LangGraphUnavailable", "available", "build_graph", "describe_edges", "version"]


class LangGraphUnavailable(RuntimeError):
    """未安装 langgraph。"""


def _import_langgraph():
    try:
        from langgraph.graph import END, StateGraph  # type: ignore
    except Exception:  # pragma: no cover - 取决于环境
        return None
    return StateGraph, END


def available() -> bool:
    """langgraph 是否已安装。"""
    return _import_langgraph() is not None


def version() -> str:
    """已安装的 langgraph 版本；未装返回 None。"""
    try:
        from importlib.metadata import version as _v  # type: ignore
        return _v("langgraph")
    except Exception:
        return ""


def describe_edges() -> list[tuple[str, str, str]]:
    """导出条件边规格：(来源节点, 门禁结论, 目标节点|END)。便于跨框架比对。"""
    edges: list[tuple[str, str, str]] = []
    for spec in GRAPH_NODES:
        for gate in ("PASS", "REVIEW_REQUIRED", "ERROR", "BLOCKED", "ABORTED", "INCONCLUSIVE"):
            target = next_node(spec.node, gate)
            edges.append((spec.node.value, gate, target.value if target else "END"))
    return edges


def build_graph(nodes: dict[GraphNode, NodeFn], *, state_schema: Any = None):
    """把 `graph.py` 的规格编译成 LangGraph StateGraph。

    `nodes` 是同一批节点实现，签名与 `graph.py` 的 `NodeFn` 一致；
    条件边通过 `next_node()` 判定，保证两套执行路径的语义完全一致。
    """
    imported = _import_langgraph()
    if imported is None:
        raise LangGraphUnavailable(
            "未检测到 langgraph。请先把它加入 "
            "skills/uds-diagnostic-test/requirements.txt 并安装；"
            "本适配层不自行安装依赖，以免在测试机上引入隐性依赖。"
        )
    StateGraph, END = imported

    schema = state_schema or dict
    builder = StateGraph(schema)

    for spec in GRAPH_NODES:
        fn = nodes.get(spec.node)
        if fn is None:
            raise LangGraphUnavailable(f"节点 {spec.node.value} 没有实现，无法编译")
        builder.add_node(spec.node.value, fn)

    entry = GRAPH_NODES[0].node.value
    builder.set_entry_point(entry)

    def _router(state: dict):
        current = state.get("last_node")
        gate = state.get("last_gate")
        if current is None:
            return END
        target = next_node(GraphNode(current), gate)
        return target.value if target else END

    for spec in GRAPH_NODES:
        targets = {next_node(spec.node, g) for g in
                   ("PASS", "REVIEW_REQUIRED", "ERROR", "BLOCKED", "ABORTED", "INCONCLUSIVE")}
        mapping = {t.value: t.value for t in targets if t is not None}
        if mapping:
            builder.add_conditional_edges(spec.node.value, _router, {**mapping, END: END})
        else:
            builder.add_edge(spec.node.value, END)

    return builder.compile()
