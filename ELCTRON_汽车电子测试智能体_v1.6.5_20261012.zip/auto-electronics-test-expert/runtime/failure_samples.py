"""Approved, redacted failure-sample library; raw traces never enter this store."""
from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass
from pathlib import Path

_FAILURE_CLASSES = {"ECU_FAIL", "SCRIPT_ERROR", "INFRA_ERROR", "INPUT_INVALID", "RESULT_INVALID", "BLOCKED"}
_SECRET = re.compile(r"(?:bearer\s+|api[_ -]?key\s*[:=]|token\s*[:=]|secret\s*[:=])", re.I)
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


class FailureSampleError(ValueError):
    pass


@dataclass(frozen=True)
class FailureSample:
    sample_id: str
    failure_class: str
    source_run_id: str
    evidence_sha256: str
    summary: str
    approved_by: str
    rule_version: str

    def validate(self) -> None:
        if not self.sample_id or not self.source_run_id or not self.approved_by or not self.rule_version:
            raise FailureSampleError("sample_id, source_run_id, approved_by and rule_version are required")
        if self.failure_class not in _FAILURE_CLASSES:
            raise FailureSampleError(f"unsupported failure_class: {self.failure_class}")
        if not _SHA256.fullmatch(self.evidence_sha256):
            raise FailureSampleError("evidence_sha256 must be a lowercase SHA-256")
        if not self.summary.strip() or len(self.summary) > 1000 or _SECRET.search(self.summary):
            raise FailureSampleError("summary must be redacted, non-empty and at most 1000 characters")


class FailureSampleLibrary:
    """Append-only JSONL library. Admission is explicit approval, not model output."""

    def __init__(self, path: str | os.PathLike[str]):
        self.path = Path(path)

    def admit(self, sample: FailureSample, *, approved: bool) -> None:
        if not approved:
            raise FailureSampleError("failure sample requires explicit approval before admission")
        sample.validate()
        existing = {item.sample_id for item in self.list()}
        if sample.sample_id in existing:
            raise FailureSampleError(f"duplicate sample_id: {sample.sample_id}")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(asdict(sample), ensure_ascii=False, sort_keys=True) + "\n")

    def list(self, *, failure_class: str | None = None) -> list[FailureSample]:
        if failure_class is not None and failure_class not in _FAILURE_CLASSES:
            raise FailureSampleError(f"unsupported failure_class: {failure_class}")
        if not self.path.is_file():
            return []
        records: list[FailureSample] = []
        with open(self.path, encoding="utf-8") as handle:
            for number, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                try:
                    item = FailureSample(**json.loads(line))
                    item.validate()
                except (TypeError, ValueError, json.JSONDecodeError) as exc:
                    raise FailureSampleError(f"invalid sample at line {number}") from exc
                if failure_class is None or item.failure_class == failure_class:
                    records.append(item)
        return records


__all__ = ["FailureSample", "FailureSampleError", "FailureSampleLibrary"]
