"""真机只读 e2e 发布门槛。

该门槛不是设备执行器，而是执行前的 fail-closed 检查编排：
设备白名单、租约冲突、异常恢复、ASC 首帧和证据落盘完整性任一不通过，
都不得进入真实硬件流程。默认要求显式开启 ``AETEX_REAL_E2E=1``。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from typing import Any, Iterable

from .asc_session import AscSession
from .lease import ChannelBusy, ChannelLeaseManager


@dataclass(frozen=True)
class DeviceTarget:
    adapter: str
    channel: str
    serial: str = ""

    def key(self) -> tuple[str, str, str]:
        return (self.adapter, self.channel, self.serial)


@dataclass(frozen=True)
class ReleaseGateReport:
    passed: bool
    checks: dict[str, bool]
    details: dict[str, str]

    def to_dict(self) -> dict[str, Any]:
        return {"passed": self.passed, "checks": dict(self.checks), "details": dict(self.details)}


_SCRATCH_DIR_ENV = "AETEX_TMPDIR"


def _scratch_root() -> str | None:
    """返回优先使用的临时根目录；均不可用时返回 None（退回系统默认临时目录）。

    受限令牌 / 只读沙盒下 `%TEMP%` 可能不可写，`tempfile.mkdtemp()` 会直接抛
    PermissionError 让门槛无法执行。优先级：``AETEX_TMPDIR`` 显式指定 →
    包内 ``.aetex-tmp``。这里只建目录不做写入探测：本机 safe-delete 钳制会让
    探测性删除直接终止进程，因此"能否落盘"交给调用点的 mkdtemp 判定并回退。
    """
    package_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    explicit = os.environ.get(_SCRATCH_DIR_ENV, "").strip()
    candidates = ([explicit] if explicit else []) + [os.path.join(package_root, ".aetex-tmp")]
    for candidate in candidates:
        try:
            os.makedirs(candidate, exist_ok=True)
        except OSError:
            continue
        return candidate
    return None


def _make_scratch_dir() -> str:
    """在首选目录下建临时运行根；首选不可写时回退系统临时目录（不抛异常）。"""
    preferred = _scratch_root()
    if preferred:
        try:
            return tempfile.mkdtemp(prefix="aetex-release-gate-", dir=preferred)
        except OSError:
            pass
    return tempfile.mkdtemp(prefix="aetex-release-gate-")


def _normalise_allowlist(items: Iterable[dict[str, Any]]) -> set[tuple[str, str, str]]:
    return {
        (str(item.get("adapter", "")), str(item.get("channel", "")), str(item.get("serial", "")))
        for item in items
        if isinstance(item, dict)
    }


def _check_lease_conflict(root: str, channel: str) -> tuple[bool, str]:
    manager = ChannelLeaseManager(os.path.join(root, "leases"), ttl_seconds=60)
    first = manager.acquire(channel, holder="release-gate-1")
    try:
        try:
            manager.acquire(channel, holder="release-gate-2")
        except ChannelBusy:
            return True, "第二个持有者被拒绝"
        return False, "同一通道允许并发租约"
    finally:
        manager.release(first)


def _check_crash_recovery(root: str, channel: str) -> tuple[bool, str]:
    manager = ChannelLeaseManager(os.path.join(root, "crash-leases"), ttl_seconds=60)
    lease = manager.acquire(channel, holder="crashed-run")
    path = manager.path_for(channel)
    with open(path, encoding="utf-8") as fh:
        payload = json.load(fh)
    payload["expires_at"] = "2000-01-01T00:00:00Z"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, sort_keys=True)
    reclaimed = manager.reclaim_stale()
    recovered = channel in reclaimed and manager.current(channel) is None and bool(lease.lease_id)
    return recovered, "崩溃后过期租约可回收"


def _check_asc_integrity(root: str, run_id: str, channel: str) -> tuple[bool, str]:
    session = AscSession(root, run_id=run_id, channel=channel, case_id="release-gate")
    session.open()
    session.record(0.001, "rx", 0x123, [0x01, 0x02, 0x03])
    sealed = session.seal()
    captures = sealed.get("captures", [])
    if not captures or int(sealed.get("frames", 0)) < 1:
        return False, "ASC 未产生首帧"
    for capture in captures:
        path = os.path.join(root, str(capture.get("path", "")))
        if not os.path.isfile(path):
            return False, f"ASC 分片不存在：{path}"
        with open(path, "rb") as fh:
            data = fh.read()
        if not data or hashlib.sha256(data).hexdigest() != str(capture.get("sha256", "")):
            return False, f"ASC 分片哈希不匹配：{path}"
        if int(capture.get("frame_count", 0)) < 1:
            return False, "ASC 首帧未计入分片元数据"
    return True, "ASC 首帧、分片、字节数和哈希均完整"


def run_release_gate(*, target: DeviceTarget, allowlist: Iterable[dict[str, Any]],
                     allow_real_e2e: bool, root: str | None = None) -> ReleaseGateReport:
    checks: dict[str, bool] = {}
    details: dict[str, str] = {}
    checks["real_e2e_explicitly_enabled"] = bool(allow_real_e2e)
    details["real_e2e_explicitly_enabled"] = "AETEX_REAL_E2E=1" if allow_real_e2e else "未显式开启真实 e2e"
    checks["device_whitelist"] = target.key() in _normalise_allowlist(allowlist)
    details["device_whitelist"] = "设备命中白名单" if checks["device_whitelist"] else "设备不在白名单"
    if not all(checks.values()):
        return ReleaseGateReport(False, checks, details)

    temp_root = root or _make_scratch_dir()
    try:
        checks["lease_conflict"] , details["lease_conflict"] = _check_lease_conflict(temp_root, target.channel)
        checks["crash_recovery"] , details["crash_recovery"] = _check_crash_recovery(temp_root, target.channel)
        checks["asc_first_frame_and_persistence"], details["asc_first_frame_and_persistence"] = _check_asc_integrity(temp_root, "release-gate", target.channel)
    finally:
        if root is None:
            import shutil
            shutil.rmtree(temp_root, ignore_errors=True)
    return ReleaseGateReport(all(checks.values()), checks, details)


def _load_allowlist(value: str) -> list[dict[str, Any]]:
    try:
        data = json.loads(value)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"AETEX_DEVICE_ALLOWLIST 不是合法 JSON：{exc}") from exc
    if not isinstance(data, list):
        raise SystemExit("AETEX_DEVICE_ALLOWLIST 必须是 JSON 数组")
    return [item for item in data if isinstance(item, dict)]


def main() -> int:
    parser = argparse.ArgumentParser(description="运行真机只读 e2e 发布门槛")
    parser.add_argument("--adapter", required=True)
    parser.add_argument("--channel", required=True)
    parser.add_argument("--serial", default="")
    args = parser.parse_args()
    allowlist = _load_allowlist(os.environ.get("AETEX_DEVICE_ALLOWLIST", "[]"))
    report = run_release_gate(
        target=DeviceTarget(args.adapter, args.channel, args.serial),
        allowlist=allowlist,
        allow_real_e2e=os.environ.get("AETEX_REAL_E2E") == "1",
    )
    print(json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True))
    return 0 if report.passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
