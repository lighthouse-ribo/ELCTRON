#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T3.3 ASC 实时会话。

**不重造记录器**：直接复用既有 `skills/uds-diagnostic-test/scripts/asc_evidence.py`
的 `LiveAscRecorder`（纯标准库实现，可独立导入）。本模块只补三层语义：

1. **只接受驱动给的真实事件**。时间戳为 None、字段不足一律拒绝 ——
   记录器本身不制造时间戳，这一层再加一道，杜绝"模型补一个时间戳"。
2. **异常封存**。任何中断路径都要能封存已落盘的分片，保证 ABORTED 也留证。
3. **产出可直接进 RunManifest** 的 captures 结构（含分片摘要与帧数）。
"""
from __future__ import annotations

import os
import sys
from typing import Any, Iterable

from ..orchestrator import hashchain as H

DEFAULT_BRVAL = 19200
DEFAULT_PART_MAX_BYTES = 100 * 1024 * 1024

_SCRIPTS_REL = os.path.join("skills", "uds-diagnostic-test", "scripts")


class AscSessionError(RuntimeError):
    """ASC 会话错误。"""


def _package_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def load_recorder():
    """按路径加载既有 `LiveAscRecorder`。

    找不到时抛明确错误，**不在此处另写一个记录器** —— 那会造成两份实现不一致。
    """
    scripts = os.path.join(_package_root(), _SCRIPTS_REL)
    if not os.path.isdir(scripts):
        raise AscSessionError(f"找不到技能脚本目录：{scripts}")
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    try:
        import asc_evidence  # noqa: WPS433
    except ImportError as exc:
        raise AscSessionError(f"无法导入既有 ASC 记录器 asc_evidence：{exc}") from exc
    if not hasattr(asc_evidence, "LiveAscRecorder"):
        raise AscSessionError("asc_evidence 中缺少 LiveAscRecorder，拒绝用替代实现顶上")
    return asc_evidence.LiveAscRecorder


def _count_data_frames(path: str) -> int:
    """数 ASC 分片里的数据行（行首为数字的行），与头部行区分开。"""
    n = 0
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                # ASC 数据行形如 " 0.000000 Li 3c  Tx  3 ..."：行首有空格，
                # 头部行以 date/base/no/// 开头。两者都要区分开。
                stripped = line.strip()
                if stripped[:1].isdigit() and " Li " in line:
                    n += 1
    except OSError:
        return 0
    return n


class AscSession:
    """一次运行的 ASC 实时会话。"""

    def __init__(self, run_dir: str, *, run_id: str, channel: str,
                 case_id: str = "", brval: int = DEFAULT_BRVAL,
                 part_max_bytes: int = DEFAULT_PART_MAX_BYTES,
                 session_id: str | None = None):
        self.run_dir = run_dir
        self.run_id = run_id
        self.channel = channel
        self.case_id = case_id or run_id
        self.brval = brval
        self.part_max_bytes = part_max_bytes
        self._session_id = session_id
        self._recorder = None
        self._opened = False
        self._sealed = False
        self._seal_result: dict[str, Any] | None = None
        self.abort_reason = ""

    # ---------- 生命周期 ----------
    def open(self) -> None:
        if self._opened:
            return
        recorder_cls = load_recorder()
        out_dir = os.path.join(self.run_dir, "03_execution")
        os.makedirs(out_dir, exist_ok=True)
        self._recorder = recorder_cls(
            self.case_id, out_dir=out_dir, brval=self.brval, channel=self.channel,
            session_id=self._session_id, part_max_bytes=self.part_max_bytes)
        self._opened = True

    def record(self, ts: Any, direction: str, frame_id: int, data: Iterable[int]) -> None:
        """写入一帧真实事件。**时间戳必须由驱动提供。**"""
        if not self._opened:
            raise AscSessionError("ASC 会话尚未 open()")
        if self._sealed:
            raise AscSessionError("ASC 会话已封存，不能再写入")
        if ts is None:
            raise AscSessionError("拒绝写入：缺少硬件时间戳（不允许补造时间戳）")
        if direction not in ("tx", "rx"):
            raise AscSessionError(f"拒绝写入：方向非法 {direction!r}")
        try:
            self._recorder.record((ts, direction, int(frame_id), list(data)))
        except ValueError as exc:
            raise AscSessionError(f"事件不合法：{exc}") from exc

    # ---------- 封存 ----------
    def seal(self, *, result_file: str | None = None) -> dict[str, Any]:
        """正常结束封存，返回 captures 结构。"""
        return self._seal(reason="", result_file=result_file)

    def abort(self, reason: str, *, result_file: str | None = None) -> dict[str, Any]:
        """异常封存：已落盘的分片必须保留，ABORTED 也要留证。"""
        self.abort_reason = str(reason or "ABORTED")
        return self._seal(reason=self.abort_reason, result_file=result_file)

    def _seal(self, *, reason: str, result_file: str | None) -> dict[str, Any]:
        if self._seal_result is not None:
            return self._seal_result
        if not self._opened:
            self._seal_result = {"captures": [], "frames": 0, "reason": reason,
                                 "note": "会话从未开启，无证据可封存"}
            self._sealed = True
            return self._seal_result

        status = self._recorder.status()
        if self._recorder.frames:
            if reason:
                logger = getattr(self._recorder, "_log", None)
                if callable(logger):                          # 既有记录器自带的运行日志
                    logger("ABORT", reason)
            self._recorder.close(result_file=result_file)
        status = self._recorder.status()

        captures: list[dict[str, Any]] = []
        for index, part in enumerate(status.get("parts", [])):
            rel = os.path.relpath(part, self.run_dir).replace(os.sep, "/")
            if not rel.startswith("03_execution/"):
                continue
            captures.append({
                "kind": "asc",
                "path": rel,
                "sha256": H.digest_file(part),
                "bytes": os.path.getsize(part),
                "segment_index": index,
                "frame_count": _count_data_frames(part),
            })

        self._sealed = True
        self._seal_result = {
            "captures": captures,
            "frames": int(status.get("frames", 0)),
            "directory": status.get("directory", ""),
            "runlog": status.get("runlog", ""),
            "reason": reason,
            "aborted": bool(reason),
        }
        return self._seal_result

    @property
    def sealed(self) -> bool:
        return self._sealed

    @property
    def frames(self) -> int:
        return int(self._recorder.frames) if self._opened else 0

    def status(self) -> dict[str, Any]:
        out = {"opened": self._opened, "sealed": self._sealed, "channel": self.channel,
               "case_id": self.case_id, "abort_reason": self.abort_reason}
        if self._opened:
            out.update({"recorder": self._recorder.status(), "frames": self.frames})
        if self._seal_result is not None:
            out["captures"] = self._seal_result["captures"]
        return out


__all__ = [
    "AscSession",
    "AscSessionError",
    "DEFAULT_BRVAL",
    "DEFAULT_PART_MAX_BYTES",
    "load_recorder",
]
