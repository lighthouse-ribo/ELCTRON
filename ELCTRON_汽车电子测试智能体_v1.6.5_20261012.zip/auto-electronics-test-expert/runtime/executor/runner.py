#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T3.5 / T3.6 / T3.7 受控执行编排。

把 T3.1–T3.4 的件串成一次「可审计、可阻断、可封存」的硬件运行：

    取租约 → 预检 → 令牌校验 → 开 ASC 会话 → 最小复测 → 全量执行 → 封存 → 出 RunManifest

三条硬约束
----------
1. **通道必须先拿到租约**。拿不到就 BLOCKED，不走后面的任何一步。
2. **最小复测非 PASS 一律阻断全量执行**（T3.5）。这是防止"一条链路有问题还跑几百条"。
3. **任何异常都要封存**（T3.7）。ABORTED 也必须留下已落盘的 ASC 分片与原因。

设备 I/O 由外部注入（`device_runner`）。本模块**不直接打开任何硬件句柄** ——
真实收发仍在既有 `f1l1_uds.py` / `uds_runner.py` 里，本层只做编排与留证。
"""
from __future__ import annotations

import os
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol, Sequence

from ..orchestrator import approval as approval_mod
from ..orchestrator import hashchain as H
from .lease import ChannelBusy, ChannelLease, ChannelLeaseManager
from ..orchestrator.state import GateStatus, RunFinalVerdict, derive_final_verdict
from .asc_session import AscSession, AscSessionError
from .manifest import build_run_manifest, write_manifest
from .preflight import Preflight, PreflightReport

MINIMAL_RETEST_BLOCKING_VERDICTS = frozenset({"FAIL", "BLOCKED", "NA", "SKIP"})


def _now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class CaseResult:
    case_id: str
    verdict: str
    failure_class: str = "NONE"
    note: str = ""

    def to_dict(self) -> dict[str, str]:
        return {"case_id": self.case_id, "verdict": self.verdict,
                "failure_class": self.failure_class, "note": self.note}


class DeviceRunner(Protocol):
    """真实收发由外部提供；本层不持句柄。"""

    def __call__(self, case_id: str, session: AscSession) -> CaseResult: ...


@dataclass
class ExecutionRequest:
    run_id: str
    flow: str
    channel: str
    order: dict[str, Any]
    cases: tuple[str, ...]
    device: dict[str, Any]
    token: approval_mod.ApprovalToken | None = None
    minimal_case: str | None = None
    adapter: str = "xcdevlay"
    brval: int = 19200
    required_actions: tuple[str, ...] = ("execute",)


@dataclass
class ExecutionOutcome:
    gate_status: GateStatus
    run_final_verdict: RunFinalVerdict | None
    case_results: list[CaseResult] = field(default_factory=list)
    manifest: dict[str, Any] | None = None
    manifest_path: str = ""
    lease_id: str = ""
    preflight: PreflightReport | None = None
    blocked_reason: str = ""
    aborted: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "gate_status": self.gate_status.value,
            "run_final_verdict": self.run_final_verdict.value if self.run_final_verdict else None,
            "case_results": [c.to_dict() for c in self.case_results],
            "manifest_path": self.manifest_path,
            "lease_id": self.lease_id,
            "blocked_reason": self.blocked_reason,
            "aborted": self.aborted,
            "preflight": self.preflight.to_dict() if self.preflight else None,
        }


class ControlledExecutor:
    def __init__(self, *, run_dir: str, lease_manager: ChannelLeaseManager,
                 preflight: Preflight, device_runner: DeviceRunner,
                 clock=_now, brval: int = 19200):
        self.run_dir = run_dir
        self.lease_manager = lease_manager
        self.preflight = preflight
        self.device_runner = device_runner
        self.clock = clock
        self.brval = brval

    # ---------- 主流程 ----------
    def execute(self, req: ExecutionRequest) -> ExecutionOutcome:
        os.makedirs(self.run_dir, exist_ok=True)
        started = self.clock()

        # 1) 通道租约：拿不到就地停下
        try:
            lease = self.lease_manager.acquire(
                req.channel, holder=f"{req.run_id}#{os.getpid()}", executor_id=req.run_id)
        except ChannelBusy as exc:
            return ExecutionOutcome(GateStatus.BLOCKED, None,
                                    blocked_reason=f"通道被占用：{exc}")
        except Exception as exc:                       # 租约文件损坏等
            return ExecutionOutcome(GateStatus.ERROR, None,
                                    blocked_reason=f"租约获取失败：{exc}")

        session: AscSession | None = None
        try:
            # 2) 预检
            report = self.preflight.run(self.run_dir, req.channel)
            if not report.passed:
                names = [c.name for c in report.failures]
                return ExecutionOutcome(report.status, None, lease_id=lease.lease_id,
                                        preflight=report,
                                        blocked_reason=f"预检未通过：{names}")

            # 3) 令牌校验（含范围与人工授权要求）
            order_errors = approval_mod.validate_approved_order(req.order, req.token)
            if order_errors:
                return ExecutionOutcome(GateStatus.BLOCKED, None, lease_id=lease.lease_id,
                                        preflight=report,
                                        blocked_reason=f"审批校验未通过：{order_errors[:2]}")
            for action in req.required_actions:
                approval_mod.verify(req.token, run_id=req.run_id, action=action, at=self.clock())

            # 4) 开 ASC 会话
            session = AscSession(self.run_dir, run_id=req.run_id, channel=req.channel,
                                 case_id=req.minimal_case or req.run_id, brval=req.brval)
            session.open()

            # 5) 最小复测：非 PASS 一律阻断全量
            minimal_result: dict[str, Any] | None = None
            if req.minimal_case:
                outcome = self.device_runner(req.minimal_case, session)
                minimal_result = {"required": True, "case_id": outcome.case_id,
                                  "verdict": outcome.verdict}
                if outcome.verdict in MINIMAL_RETEST_BLOCKING_VERDICTS:
                    sealed = session.abort(f"最小复测未通过：{outcome.case_id}={outcome.verdict}")
                    minimal_result["evidence_ref"] = sealed["captures"][0]["path"] \
                        if sealed["captures"] else ""
                    return self._finish_blocked(req, started, lease, report, session,
                                                sealed, [outcome], minimal_result,
                                                GateStatus.REVIEW_REQUIRED,
                                                f"最小复测未通过（{outcome.verdict}），阻断全量执行")

            # 6) 全量执行
            results: list[CaseResult] = []
            try:
                for case_id in req.cases:
                    results.append(self.device_runner(case_id, session))
            except Exception as exc:                   # T3.7 异常封存
                sealed = session.abort(f"执行异常：{type(exc).__name__}: {exc}")
                return self._finish_blocked(
                    req, started, lease, report, session, sealed, results, minimal_result,
                    GateStatus.ABORTED,
                    f"执行异常已封存：{type(exc).__name__}: {exc}\n{traceback.format_exc()[-500:]}")

            # 7) 正常封存
            sealed = session.seal()
            captures = sealed["captures"]
            manifest = build_run_manifest(
                run_id=req.run_id, flow=req.flow, device=dict(req.device),
                started_at=started, ended_at=self.clock(), status="CAPTURED",
                order_refs=[{"order_id": str(req.order.get("order_id", "")),
                             "plan_sha256": str(req.order.get("plan_sha256", ""))}],
                captures=captures, lease=lease,
                config_sha256=str(req.order.get("plan_sha256", "")),
                minimal_retest=minimal_result,
                checked_processes=[c.name for c in report.checks])
            manifest_path = write_manifest(self.run_dir, manifest)

            evidence_complete = bool(captures) and sealed.get("frames", 0) > 0
            final = derive_final_verdict([r.verdict for r in results],
                                         evidence_complete=evidence_complete)
            # 门禁结论看的是"执行与证据是否站得住"，不是业务结论本身：
            #   final=FAIL         -> 执行门禁是 PASS（跑完了、证据齐），业务结论才是 FAIL
            #   final=INCONCLUSIVE -> 证据不足，门禁也是 INCONCLUSIVE
            #   final=None         -> 不该出现；保守按 INCONCLUSIVE
            gate = (GateStatus.INCONCLUSIVE
                    if final in (None, RunFinalVerdict.INCONCLUSIVE) else GateStatus.PASS)
            return ExecutionOutcome(
                gate, final, case_results=results, manifest=manifest,
                manifest_path=manifest_path, lease_id=lease.lease_id, preflight=report)
        finally:
            # 无论成功失败，租约一定要还；否则通道被自己占死
            try:
                self.lease_manager.release(lease)
            except Exception:
                pass

    # ---------- 中止路径 ----------
    def _finish_blocked(self, req: ExecutionRequest, started: datetime, lease: ChannelLease,
                        report: PreflightReport, session: AscSession, sealed: dict[str, Any],
                        results: Sequence[CaseResult], minimal_result: dict[str, Any] | None,
                        status: GateStatus, reason: str) -> ExecutionOutcome:
        """中止也要出 RunManifest：ABORTED 必须留证。"""
        captures = sealed.get("captures", [])
        try:
            manifest = build_run_manifest(
                run_id=req.run_id, flow=req.flow, device=dict(req.device),
                started_at=started, ended_at=self.clock(), status="ABORTED",
                order_refs=[{"order_id": str(req.order.get("order_id", "")),
                             "plan_sha256": str(req.order.get("plan_sha256", ""))}],
                captures=captures, lease=lease,
                config_sha256=str(req.order.get("plan_sha256", "")),
                minimal_retest=minimal_result, abort_reason=reason,
                checked_processes=[c.name for c in report.checks])
            manifest_path = write_manifest(self.run_dir, manifest)
        except Exception:
            manifest, manifest_path = None, ""
        return ExecutionOutcome(status, None, case_results=list(results), manifest=manifest,
                                manifest_path=manifest_path, lease_id=lease.lease_id,
                                preflight=report, blocked_reason=reason, aborted=True)

    # ---------- 链校验 ----------
    def verify_evidence_chain(self, manifest: dict[str, Any]) -> list[str]:
        """校验 manifest 里 captures 的哈希链（文件级）。"""
        records = []
        for cap in manifest.get("captures", []):
            records.append(H.ArtifactRecord(
                path=cap["path"], sha256=cap["sha256"], size=int(cap.get("bytes", 0)),
                kind=cap.get("kind", "")))
        return H.verify(records, run_dir=self.run_dir)


__all__ = [
    "CaseResult",
    "ControlledExecutor",
    "DeviceRunner",
    "ExecutionOutcome",
    "ExecutionRequest",
    "MINIMAL_RETEST_BLOCKING_VERDICTS",
]
