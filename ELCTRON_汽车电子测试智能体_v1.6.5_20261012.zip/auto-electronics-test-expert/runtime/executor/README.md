# runtime/executor —— 本地执行器（硬件安全层）

T3 起建立。本目录是**唯一可以接触硬件通道的地方**。模型与 Web 层不持句柄，
执行子图通过本层提交受 Schema 校验的请求，本层负责租约、预检、留证与封存。

当前内容：

| 文件 | 作用 |
|---|---|
| `lease.py` | T3.1 通道租约：文件系统原子独占、有效期、身份校验、过期回收 |
| `preflight.py` | T3.2 硬件预检：进程占用、设备在位、磁盘、配置哈希；未知即失败 |
| `asc_session.py` | T3.3 ASC 实时会话：复用既有 `LiveAscRecorder`，异常封存 |
| `manifest.py` | T3.4 RunManifest 生成与校验 |
| `runner.py` | T3.5–T3.7 受控执行编排：最小复测强制位、令牌校验、异常封存 |

**本层不直接打开任何硬件句柄。** 真实收发仍由外部注入（`DeviceRunner`），
生产环境里由既有 `f1l1_uds.py` / `uds_runner.py` 承担。

---

## 1 一次受控执行的完整路径（T3.5–T3.7）

```
取通道租约 → 预检 → 令牌校验 → 开 ASC 会话 → 最小复测 → 全量执行 → 封存 → RunManifest → 还租约
```

任何一步失败都**就地停下并留证**，绝不"带着问题往下走"。

| 失败点 | 门禁结论 | 是否出 Manifest |
|---|---|---|
| 通道被占用 | `BLOCKED` | 否（未进入执行） |
| 预检未通过 | `BLOCKED` / `ERROR` | 否 |
| 审批校验未通过 | `BLOCKED` | 否 |
| **最小复测非 PASS** | `REVIEW_REQUIRED` | **是**，`status=ABORTED` |
| 执行中抛异常 | `ABORTED` | **是**，含 `abort_reason` |
| 执行完成但没抓到帧 | `INCONCLUSIVE` | 是，`status=CAPTURED` |
| 正常完成 | `PASS` | 是，`status=CAPTURED` |

**租约在任何路径下都会归还**（`try/finally`）——否则通道会被自己占死。

---

## 2 通道租约（T3.1）

```python
mgr = ChannelLeaseManager(lease_dir, ttl_seconds=1800)
lease = mgr.acquire("LIN1", holder="RUN-1#1234")   # 已被占用则抛 ChannelBusy
mgr.renew(lease)                                   # 只有本人能续
mgr.release(lease)                                 # 只有本人能放
mgr.reclaim_stale()                                # 回收已过期租约
mgr.snapshot()                                     # 当前所有租约（含已过期）
```

四条设计：

1. **原子独占**：`os.open(..., O_CREAT|O_EXCL)`，不靠"先读再写"（那有竞态）。
2. **有效期**：持有者崩溃不会永久占住通道，过期后可回收。
3. **回收防误删**：回收前比对 `lease_id`，避免删掉并发新建的新鲜租约。
4. **身份校验**：非本人不得续租、不得释放。

通道名限制为 `[A-Za-z0-9][A-Za-z0-9._-]{0,31}`，杜绝用通道名做路径穿越。

---

## 3 预检（T3.2）

**未知或冲突一律不可绕过。** 探针异常、设备探测结果未知、通道不在白名单，全部按失败处理。

```python
config = PreflightConfig(adapter="xcdevlay", channels=("LIN1",))
report = Preflight(config, probes).run(run_dir, "LIN1")
report.status    # PASS / BLOCKED / ERROR
report.passed    # bool
```

| 检查 | 失败分级 | 说明 |
|---|---|---|
| `channel_whitelisted` | `ERROR` | 通道不在白名单 |
| `adapter_whitelisted` | `ERROR` | 未指定驱动适配器 |
| `no_occupying_process` | `BLOCKED` | 检测到 VickCAN / CANoe 等占用进程 |
| `device_present` | `BLOCKED` | 设备不在位**或探测结果未知** |
| `disk_space` | `BLOCKED` | 可用空间低于阈值 |
| `config_hash` | `ERROR` | 配置哈希不符 |

判定优先级：**任一 `ERROR` > 任一 `BLOCKED` > 全通过才是 `PASS`**。

### 探针可注入

| 探针 | 说明 |
|---|---|
| `SystemProbes` | 真实探针（只读）。设备探测复用既有 `can_init.list_channels()`，不重造 |
| `SimulatedProbes` | 离线模拟。`describe()` 返回带 `simulated` 的字符串，并写进预检报告，**使模拟结果不可能被当成真实硬件预检证据** |

`config_hash` 检查在未指定期望哈希时**只跳过、不算通过**，报告里明确写"未校验"。

---

## 4 ASC 实时会话（T3.3）

**不重造记录器** —— 直接复用 `skills/uds-diagnostic-test/scripts/asc_evidence.py`
的 `LiveAscRecorder`（纯标准库、可独立导入）。本层只补三点：

1. **拒绝补造时间戳**：`ts is None` 直接抛错。记录器自己不制造时间戳，这一层再加一道。
2. **异常封存**：`abort(reason)` 保留已落盘分片，ABORTED 也留证。
3. **产出 captures**：每个分片的 `sha256` / `bytes` / `segment_index` / `frame_count`。

```python
s = AscSession(run_dir, run_id="RUN-1", channel="LIN1"); s.open()
s.record(ts=1234.5, direction="tx", frame_id=0x3C, data=[0x22, 0xA0, 0x01])
sealed = s.seal()      # 或 s.abort("链路中断")
sealed["captures"]     # 可直接进 RunManifest
```

---

## 5 RunManifest（T3.4）

```python
manifest = build_run_manifest(run_id=..., flow=..., device=..., started_at=...,
                              status="CAPTURED", order_refs=[...], captures=[...],
                              lease=lease, minimal_retest={...})
write_manifest(run_dir, manifest)     # -> 03_execution/run_manifest.json
```

**不合规不许落盘**：构造与写盘都会过 `run-manifest/v0.1` 契约校验，不过就抛 `ManifestInvalid`。
Manifest 里不含任何密钥或凭据值（有测试断言）。

---

## 6 最小复测强制位（T3.5）

`MINIMAL_RETEST_BLOCKING_VERDICTS = {FAIL, BLOCKED, NA, SKIP}` —— 只要不是 `PASS`，**全量一条都不许跑**。
这是防止"一条链路有问题还跑几百条"的最后一道闸。

测试断言：最小复测 FAIL 时 `device.calls == ["TC-1"]`，全量用例一条都没进设备。

> 最小复测与全量是两次独立执行：最小复测证明链路可用，全量是完整证据集，
> 所以最小复测用例在全量里会再跑一次，属预期行为。

---

## 7 run 级结论（红线 R5 的落点）

```python
evidence_complete = bool(captures) and frames > 0
final = derive_final_verdict([r.verdict for r in results], evidence_complete=evidence_complete)
```

**一条帧都没抓到 → 证据不完整 → 绝不可能是 PASS**，只能 `INCONCLUSIVE`。

门禁结论与业务结论分开：`final=FAIL` 时执行门禁仍是 `PASS`（跑完了、证据齐），
业务结论才是 `FAIL`。

---

## 8 验证

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
"$PY" -m unittest runtime.tests.test_executor    # 50 项
"$PY" runtime/tools/run_all_tests.py             # 完整门禁
```

测试不碰真硬件：设备 I/O 与探针全部注入，被测的是**编排与留证**。
