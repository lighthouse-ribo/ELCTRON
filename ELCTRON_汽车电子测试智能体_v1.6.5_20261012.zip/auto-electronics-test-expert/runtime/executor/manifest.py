#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T3.4 RunManifest 生成。

产出必须直接通过 `run-manifest/v0.1` 契约校验，否则不许落盘 ——
manifest 是运行后唯一的封存记录，格式不合规等于证据不可用。
"""
from __future__ import annotations

import json
import os
import platform
import sys
from datetime import datetime, timezone
from typing import Any, Sequence

from ..contracts import validation
from .lease import ChannelLease

MANIFEST_NAME = "run_manifest.json"


def _iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def environment_snapshot(*, checked_processes: Sequence[str] = ()) -> dict[str, Any]:
    """运行环境快照。不含密钥、不含凭据值。"""
    return {
        "python_version": platform.python_version() if not sys.version_info else
                          f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "os": platform.system() or "unknown",
        "occupying_processes_checked": sorted(set(checked_processes)),
    }


def build_run_manifest(*, run_id: str, flow: str, device: dict[str, Any],
                       started_at: datetime, status: str, order_refs: Sequence[dict[str, str]],
                       captures: Sequence[dict[str, Any]], ended_at: datetime | None = None,
                       config_sha256: str = "", lease: ChannelLease | None = None,
                       minimal_retest: dict[str, Any] | None = None,
                       abort_reason: str = "",
                       checked_processes: Sequence[str] = ()) -> dict[str, Any]:
    """构造 RunManifest。返回已通过契约校验的字典。"""
    manifest: dict[str, Any] = {
        "schema_version": "run-manifest/v0.1",
        "run_id": run_id,
        "flow": flow,
        "device": dict(device),
        "started_at": _iso(started_at),
        "status": status,
        "order_refs": [dict(o) for o in order_refs],
        "captures": [dict(c) for c in captures],
        "environment": environment_snapshot(checked_processes=checked_processes),
    }
    if ended_at is not None:
        manifest["ended_at"] = _iso(ended_at)
    if config_sha256:
        manifest["config_sha256"] = config_sha256
    if lease is not None:
        manifest["channel_lease"] = {
            "lease_id": lease.lease_id,
            "holder": lease.holder,
            "acquired_at": _iso(lease.acquired_at),
            "expires_at": _iso(lease.expires_at),
        }
    if minimal_retest is not None:
        manifest["minimal_retest"] = dict(minimal_retest)
    if abort_reason:
        manifest["abort_reason"] = abort_reason

    errors = validation.report("run-manifest/v0.1", manifest)
    if errors:
        raise ManifestInvalid(errors)
    return manifest


class ManifestInvalid(ValueError):
    """RunManifest 不符合契约。"""

    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__("RunManifest 不合规（%d 项）：%s" % (len(errors), "；".join(errors[:5])))


def write_manifest(run_dir: str, manifest: dict[str, Any]) -> str:
    """写盘到 `03_execution/run_manifest.json`，返回相对路径。"""
    errors = validation.report("run-manifest/v0.1", manifest)
    if errors:
        raise ManifestInvalid(errors)
    rel = f"03_execution/{MANIFEST_NAME}"
    full = os.path.join(run_dir, *rel.split("/"))
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2, sort_keys=True)
    return rel


def read_manifest(run_dir: str) -> dict[str, Any]:
    """读并校验 run manifest；不合规直接抛错，不返回半成品。"""
    full = os.path.join(run_dir, "03_execution", MANIFEST_NAME)
    if not os.path.isfile(full):
        raise FileNotFoundError(f"运行目录里没有 RunManifest：{full}")
    with open(full, encoding="utf-8") as fh:
        return json.load(fh)


__all__ = [
    "MANIFEST_NAME",
    "ManifestInvalid",
    "build_run_manifest",
    "environment_snapshot",
    "read_manifest",
    "write_manifest",
]
