"""Fail-closed VICKCAN integration boundary.

Vendor CLI/API syntax is intentionally not guessed.  This adapter validates a
named, allow-listed target and records that an explicit vendor binding is still
required before it can ever open a channel.  It cannot transmit or launch a
process, so enabling this module alone has no hardware side effect.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


class VickCanNotReady(RuntimeError):
    pass


@dataclass(frozen=True)
class VickCanTarget:
    channel: str
    serial: str


class VickCanReadOnlyAdapter:
    adapter_name = "vickcan"

    def __init__(self, allowlist: Iterable[VickCanTarget]):
        self._allowlist = frozenset(allowlist)

    def readiness(self, target: VickCanTarget) -> dict[str, object]:
        allowed = target in self._allowlist
        return {
            "adapter": self.adapter_name,
            "channel": target.channel,
            "serial": target.serial,
            "allowlisted": allowed,
            "read_only": True,
            "vendor_binding_configured": False,
            "ready": False,
        }

    def open_capture(self, target: VickCanTarget) -> None:
        if target not in self._allowlist:
            raise VickCanNotReady("VICKCAN target is not allow-listed")
        raise VickCanNotReady("VICKCAN vendor binding is not configured; refusing to guess device commands")


__all__ = ["VickCanNotReady", "VickCanReadOnlyAdapter", "VickCanTarget"]
