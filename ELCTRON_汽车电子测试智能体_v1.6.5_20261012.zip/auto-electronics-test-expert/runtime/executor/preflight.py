#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T3.2 硬件预检。

原则：**未知或冲突一律不可绕过**。
探针失败、设备探测结果未知、通道名不在白名单内，全部按失败处理，
不存在「查不到就当没问题」的路径。

探针是可注入的：
  * `SystemProbes` —— 真实探针，设备探测复用既有 `can_init.list_channels()`；
  * `SimulatedProbes` —— 离线模拟，`describe()` 明确标注 `simulated`，
    防止模拟结果被误当成真实预检证据。

失败分级（对应 `GateStatus`）：
  * `BLOCKED` —— 前置条件未满足（进程占用、设备不在、磁盘不足），从未执行；
  * `ERROR`   —— 配置或工具层面的问题（配置哈希不符、配置缺失、探针异常）。
"""
from __future__ import annotations

import hashlib
import os
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol

from ..orchestrator.state import GateStatus

#: 可能占用 Vector / LIN 通道的进程（与既有 can_init.check_process_occupancy 一致）
OCCUPYING_PROCESSES: tuple[str, ...] = (
    "VickCAN", "CANoe64", "CANoe32", "CANalyzer", "CANape", "zS_Gen3",
)

DEFAULT_MIN_FREE_BYTES = 200 * 1024 * 1024


class PreflightError(RuntimeError):
    """预检自身无法进行（不是被检对象的业务结论）。"""


@dataclass(frozen=True)
class CheckResult:
    name: str
    ok: bool
    detail: str
    on_fail: GateStatus = GateStatus.BLOCKED
    blocking: bool = True

    def to_dict(self) -> dict:
        return {"name": self.name, "ok": self.ok, "detail": self.detail,
                "on_fail": self.on_fail.value, "blocking": self.blocking}


@dataclass
class PreflightReport:
    channel: str
    adapter: str
    at: datetime
    probe_provenance: str
    checks: list[CheckResult] = field(default_factory=list)

    @property
    def failures(self) -> list[CheckResult]:
        return [c for c in self.checks if not c.ok and c.blocking]

    @property
    def warnings(self) -> list[CheckResult]:
        return [c for c in self.checks if not c.ok and not c.blocking]

    @property
    def passed(self) -> bool:
        return not self.failures

    @property
    def status(self) -> GateStatus:
        """任一 ERROR 优先；否则任一 BLOCKED；全通过才是 PASS。"""
        fails = self.failures
        if any(c.on_fail is GateStatus.ERROR for c in fails):
            return GateStatus.ERROR
        if fails:
            return GateStatus.BLOCKED
        return GateStatus.PASS

    def to_dict(self) -> dict:
        return {
            "channel": self.channel, "adapter": self.adapter,
            "at": self.at.isoformat(), "probe_provenance": self.probe_provenance,
            "status": self.status.value, "passed": self.passed,
            "checks": [c.to_dict() for c in self.checks],
            "failures": [c.name for c in self.failures],
            "warnings": [c.name for c in self.warnings],
        }


# --------------------------------------------------------------------------- #
# 探针
# --------------------------------------------------------------------------- #
class Probes(Protocol):
    def describe(self) -> str: ...
    def occupied_processes(self) -> list[str]: ...
    def device_present(self, channel: str) -> bool | None: ...
    def disk_free(self, path: str) -> int: ...
    def config_sha256(self) -> str: ...


class SystemProbes:
    """真实探针（只读）。设备探测复用既有 `can_init.list_channels()`，不重造。"""

    def describe(self) -> str:
        return "system"

    def occupied_processes(self) -> list[str]:
        try:
            out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True,
                                 text=True, encoding="utf-8", errors="ignore").stdout
        except OSError as exc:
            raise PreflightError(f"进程占用检测失败：{exc}") from exc
        running: list[str] = []
        for line in (out or "").splitlines():
            name = line.split(",")[0].strip().strip('"') if line else ""
            for suspect in OCCUPYING_PROCESSES:
                if name.lower().startswith(suspect.lower()) and suspect not in running:
                    running.append(suspect)
        return running

    def device_present(self, channel: str) -> bool | None:
        """返回 True / False / None（未知）。

        复用既有 `can_init.list_channels()`；无法导入或枚举失败时返回 None，
        由判定层按"未知即失败"处理。
        """
        import sys

        scripts = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__)))), "skills", "uds-diagnostic-test", "scripts")
        try:
            if scripts not in sys.path:
                sys.path.insert(0, scripts)
            import can_init  # noqa: WPS433
            channels = can_init.list_channels() or []
        except Exception:
            return None
        if not channels:
            return False
        return any(str(channel).lower() in str(c).lower() for c in channels)

    def disk_free(self, path: str) -> int:
        import shutil

        target = path
        while target and not os.path.isdir(target):
            parent = os.path.dirname(target)
            if parent == target:
                break
            target = parent
        usage = shutil.disk_usage(target or ".")
        return int(usage.free)

    def config_sha256(self) -> str:
        """本机执行配置的哈希。

        P3 阶段不绑定具体配置文件（P4/T6.2 才落地 config.local.json），
        返回空串表示"无期望哈希可比对"，判定层据此跳过该检查而不是假装通过。
        """
        return ""


class SimulatedProbes:
    """离线模拟探针。

    `describe()` 返回带 `simulated` 的字符串，且判定层会把它写进预检报告，
    使模拟结果不可能被当成真实设备预检证据。
    """

    def __init__(self, *, processes: tuple[str, ...] = (), device: bool | None = True,
                 free_bytes: int = DEFAULT_MIN_FREE_BYTES * 4, config_sha256: str = ""):
        self._processes = tuple(processes)
        self._device = device
        self._free = int(free_bytes)
        self._sha = config_sha256

    def describe(self) -> str:
        return "simulated (offline dry-run; 不得作为真实硬件预检证据)"

    def occupied_processes(self) -> list[str]:
        return list(self._processes)

    def device_present(self, channel: str) -> bool | None:
        return self._device

    def disk_free(self, path: str) -> int:
        return self._free

    def config_sha256(self) -> str:
        return self._sha


# --------------------------------------------------------------------------- #
# 配置与预检
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class PreflightConfig:
    adapter: str
    channels: tuple[str, ...]
    min_free_bytes: int = DEFAULT_MIN_FREE_BYTES
    expected_config_sha256: str = ""
    require_device: bool = True
    abort_on_occupying_process: bool = True


class Preflight:
    def __init__(self, config: PreflightConfig, probes: Probes, *, clock=None):
        self.config = config
        self.probes = probes
        self.clock = clock or (lambda: datetime.now().astimezone())

    def run(self, run_dir: str, channel: str) -> PreflightReport:
        report = PreflightReport(channel=channel, adapter=self.config.adapter,
                                 at=self.clock(), probe_provenance=self.probes.describe())
        cfg = self.config

        report.checks.append(CheckResult(
            "channel_whitelisted", channel in cfg.channels,
            f"通道 {channel!r} 在白名单内" if channel in cfg.channels
            else f"通道 {channel!r} 不在白名单 {list(cfg.channels)}",
            on_fail=GateStatus.ERROR))

        report.checks.append(CheckResult(
            "adapter_whitelisted", bool(cfg.adapter),
            f"适配器 {cfg.adapter!r}" if cfg.adapter else "未指定驱动适配器",
            on_fail=GateStatus.ERROR))

        # 进程占用：探测失败按 ERROR，探测到占用按 BLOCKED
        try:
            running = self.probes.occupied_processes()
            detail = ("未检测到占用进程" if not running
                      else f"检测到可能占用总线的进程：{', '.join(running)}")
            report.checks.append(CheckResult(
                "no_occupying_process", not running, detail,
                on_fail=GateStatus.BLOCKED, blocking=cfg.abort_on_occupying_process))
        except Exception as exc:
            report.checks.append(CheckResult(
                "no_occupying_process", False, f"进程占用探测失败：{exc}",
                on_fail=GateStatus.ERROR))

        # 设备在位：None（未知）一律失败，不放过
        try:
            present = self.probes.device_present(channel)
        except Exception as exc:
            present = None
            device_detail = f"设备探测异常：{exc}"
        else:
            device_detail = {True: "设备在位", False: "未发现该通道对应的设备",
                             None: "设备探测结果未知"}[present]
        report.checks.append(CheckResult(
            "device_present", present is True, device_detail,
            on_fail=GateStatus.BLOCKED, blocking=cfg.require_device))

        # 磁盘空间
        try:
            free = self.probes.disk_free(run_dir)
            ok = free >= cfg.min_free_bytes
            report.checks.append(CheckResult(
                "disk_space", ok,
                f"可用 {free / 1024 / 1024:.1f} MB（要求 ≥ {cfg.min_free_bytes / 1024 / 1024:.1f} MB）",
                on_fail=GateStatus.BLOCKED))
        except Exception as exc:
            report.checks.append(CheckResult(
                "disk_space", False, f"磁盘空间探测失败：{exc}", on_fail=GateStatus.ERROR))

        # 配置哈希：无期望值则跳过（记为 WARNING，不算通过也不算失败）
        if cfg.expected_config_sha256:
            try:
                actual = self.probes.config_sha256()
            except Exception as exc:
                actual = ""
                detail = f"配置哈希探测失败：{exc}"
                on_fail = GateStatus.ERROR
            else:
                detail = f"配置哈希 {actual[:12]}…" if actual == cfg.expected_config_sha256 \
                    else f"配置哈希不符：期望 {cfg.expected_config_sha256[:12]}… 实际 {actual[:12] or '<空>'}…"
                on_fail = GateStatus.ERROR
            report.checks.append(CheckResult(
                "config_hash", actual == cfg.expected_config_sha256, detail, on_fail=on_fail))
        else:
            report.checks.append(CheckResult(
                "config_hash", True, "未指定期望配置哈希，跳过比对（非通过，仅未校验）",
                blocking=False))

        return report


def sha256_file(path: str) -> str:
    """文件 SHA-256（预检配置哈希与工件摘要共用）。"""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


__all__ = [
    "CheckResult",
    "DEFAULT_MIN_FREE_BYTES",
    "OCCUPYING_PROCESSES",
    "Preflight",
    "PreflightConfig",
    "PreflightError",
    "PreflightReport",
    "Probes",
    "SimulatedProbes",
    "SystemProbes",
    "sha256_file",
]
