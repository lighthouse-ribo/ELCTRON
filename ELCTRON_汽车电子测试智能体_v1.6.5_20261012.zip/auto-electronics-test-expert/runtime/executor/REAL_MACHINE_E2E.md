# 真机只读 e2e 发布门槛

真机联调前必须先通过 `runtime.executor.release_gate`。该命令默认 fail-closed：没有
显式启用、设备不在白名单，或任一安全演练失败时，退出码为 `2`，不得进入真机流程。

门槛覆盖：

1. `AETEX_REAL_E2E=1` 的显式人工开启；
2. 适配器、通道、序列号三元组的设备白名单；
3. 同通道第二持有者必须被租约拒绝；
4. 模拟进程崩溃后的过期租约必须可回收；
5. ASC 首帧、分片存在性、帧计数和 SHA-256 落盘完整性。

```powershell
$env:AETEX_REAL_E2E = "1"
$env:AETEX_DEVICE_ALLOWLIST = '[{"adapter":"xcdevlay","channel":"LIN1","serial":""}]'
python -m runtime.executor.release_gate --adapter xcdevlay --channel LIN1
```

命令通过只表示“可申请进入只读真机 e2e”；它不会自行发送硬件报文。真实执行仍必须经过
runtime 的审批令牌、预检、通道租约和生产节点接线。
