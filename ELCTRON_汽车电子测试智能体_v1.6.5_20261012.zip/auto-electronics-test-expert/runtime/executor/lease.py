#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T3.1 通道租约：硬件通道独占的唯一凭据。

规则
----
1. **同一通道同一时刻只允许一个持有者**。靠文件系统 `O_CREAT|O_EXCL` 原子创建，
   不靠"先读再写"这种有竞态的判断。
2. **租约有有效期**。持有者崩溃不会永久占住通道；过期后可由下一个任务回收。
3. **回收有防误删**。回收前比对 `lease_id`，避免把并发新建的新鲜租约误删。
4. **续租与释放都要验身份**。不是持有者本人，不许续租、不许释放。

租约文件：`<lease_dir>/<channel>.lease.json`，内容是租约本身，便于事后审计。
"""
from __future__ import annotations

import json
import os
import re
import socket
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Callable

DEFAULT_TTL_SECONDS = 1800
_CHANNEL_RX = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$")


class LeaseError(RuntimeError):
    """租约操作错误。"""


class ChannelBusy(LeaseError):
    """通道已被他人持有且租约未过期。"""

    def __init__(self, channel: str, holder: str, expires_at: str):
        self.channel, self.holder, self.expires_at = channel, holder, expires_at
        super().__init__(f"通道 {channel} 已被 {holder} 持有，租约至 {expires_at}")


def now_utc() -> datetime:
    """当前 UTC 时刻（租约时间戳的统一时钟）。"""
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


@dataclass(frozen=True)
class ChannelLease:
    lease_id: str
    channel: str
    holder: str
    executor_id: str
    pid: int
    host: str
    acquired_at: datetime
    expires_at: datetime

    def to_dict(self) -> dict:
        return {
            "lease_id": self.lease_id, "channel": self.channel, "holder": self.holder,
            "executor_id": self.executor_id, "pid": self.pid, "host": self.host,
            "acquired_at": _iso(self.acquired_at), "expires_at": _iso(self.expires_at),
        }

    @staticmethod
    def from_dict(data: dict) -> "ChannelLease":
        return ChannelLease(
            lease_id=str(data["lease_id"]), channel=str(data["channel"]),
            holder=str(data["holder"]), executor_id=str(data.get("executor_id", "")),
            pid=int(data.get("pid", 0)), host=str(data.get("host", "")),
            acquired_at=_parse(data["acquired_at"]), expires_at=_parse(data["expires_at"]),
        )

    def is_expired(self, at: datetime | None = None) -> bool:
        return (at or now_utc()) > self.expires_at


class ChannelLeaseManager:
    """文件系统租约管理器。每个通道一个租约文件。"""

    def __init__(self, lease_dir: str, *, ttl_seconds: int = DEFAULT_TTL_SECONDS,
                 clock: Callable[[], datetime] = now_utc, host: str | None = None):
        if ttl_seconds < 30:
            raise LeaseError("ttl_seconds 不得少于 30 秒")
        self.lease_dir = lease_dir
        self.ttl_seconds = int(ttl_seconds)
        self.clock = clock
        self.host = host or socket.gethostname()
        os.makedirs(self.lease_dir, exist_ok=True)

    # ---------- 路径 ----------
    def path_for(self, channel: str) -> str:
        if not _CHANNEL_RX.match(str(channel or "")):
            raise LeaseError(f"非法通道名 {channel!r}；只允许字母数字与 . _ -，长度 1..32")
        return os.path.join(self.lease_dir, f"{channel}.lease.json")

    # ---------- 读 ----------
    def current(self, channel: str) -> ChannelLease | None:
        path = self.path_for(channel)
        if not os.path.isfile(path):
            return None
        try:
            with open(path, encoding="utf-8") as fh:
                return ChannelLease.from_dict(json.load(fh))
        except (OSError, ValueError, KeyError):
            # 租约文件损坏：视为不可信，交由 acquire 的回收路径处理
            return None

    # ---------- 取 ----------
    def acquire(self, channel: str, *, holder: str, executor_id: str = "") -> ChannelLease:
        path = self.path_for(channel)
        lease = self._make(channel, holder, executor_id)

        for attempt in (1, 2):
            try:
                fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
            except FileExistsError:
                existing = self.current(channel)
                if existing is None:
                    # 文件存在但读不出内容：只在第二次尝试时按损坏处理
                    if attempt == 2:
                        self._unlink_if_matches(path, None)
                        continue
                    raise LeaseError(f"通道 {channel} 的租约文件存在但无法解析：{path}")
                if existing.is_expired(self.clock()):
                    self._unlink_if_matches(path, existing.lease_id)
                    continue
                raise ChannelBusy(channel, existing.holder, _iso(existing.expires_at))
            else:
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    json.dump(lease.to_dict(), fh, ensure_ascii=False, indent=2, sort_keys=True)
                return lease
        raise ChannelBusy(channel, "unknown", "unknown")

    def _make(self, channel: str, holder: str, executor_id: str) -> ChannelLease:
        started = self.clock()
        return ChannelLease(
            lease_id=uuid.uuid4().hex, channel=channel, holder=holder,
            executor_id=executor_id or f"exec-{os.getpid()}",
            pid=os.getpid(), host=self.host,
            acquired_at=started, expires_at=started + timedelta(seconds=self.ttl_seconds),
        )

    def _unlink_if_matches(self, path: str, expected_lease_id: str | None) -> bool:
        """只在租约仍是"我们看到的那一个"时才删除，避免误删并发新建的新鲜租约。"""
        try:
            if expected_lease_id is not None:
                with open(path, encoding="utf-8") as fh:
                    live = json.load(fh)
                if str(live.get("lease_id")) != expected_lease_id:
                    return False
            os.unlink(path)
            return True
        except FileNotFoundError:
            return True
        except OSError:
            return False

    # ---------- 续 / 放 ----------
    def renew(self, lease: ChannelLease) -> ChannelLease:
        """续租。必须仍是本人持有，否则抛错（被别人接管了就不能再续）。"""
        path = self.path_for(lease.channel)
        live = self.current(lease.channel)
        if live is None or live.lease_id != lease.lease_id:
            raise LeaseError(f"续租失败：通道 {lease.channel} 的租约已不属于 {lease.lease_id[:8]}…")
        renewed = ChannelLease(
            lease_id=lease.lease_id, channel=lease.channel, holder=lease.holder,
            executor_id=lease.executor_id, pid=lease.pid, host=lease.host,
            acquired_at=lease.acquired_at,
            expires_at=self.clock() + timedelta(seconds=self.ttl_seconds),
        )
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(renewed.to_dict(), fh, ensure_ascii=False, indent=2, sort_keys=True)
        return renewed

    def release(self, lease: ChannelLease) -> bool:
        """释放。只有本人能释放；释放别人的租约一律失败。"""
        path = self.path_for(lease.channel)
        return self._unlink_if_matches(path, lease.lease_id)

    # ---------- 回收 ----------
    def reclaim_stale(self) -> list[str]:
        """回收所有已过期的租约，返回被回收的通道名。"""
        reclaimed: list[str] = []
        if not os.path.isdir(self.lease_dir):
            return reclaimed
        for name in sorted(os.listdir(self.lease_dir)):
            if not name.endswith(".lease.json"):
                continue
            channel = name[: -len(".lease.json")]
            lease = self.current(channel)
            if lease is not None and lease.is_expired(self.clock()):
                if self._unlink_if_matches(self.path_for(channel), lease.lease_id):
                    reclaimed.append(channel)
        return reclaimed

    def snapshot(self) -> list[dict]:
        """当前所有租约（含已过期），供预检与审计展示。"""
        out: list[dict] = []
        if not os.path.isdir(self.lease_dir):
            return out
        for name in sorted(os.listdir(self.lease_dir)):
            if not name.endswith(".lease.json"):
                continue
            channel = name[: -len(".lease.json")]
            lease = self.current(channel)
            if lease is None:
                out.append({"channel": channel, "status": "corrupt"})
            else:
                item = lease.to_dict()
                item["status"] = "expired" if lease.is_expired(self.clock()) else "active"
                out.append(item)
        return out


__all__ = [
    "ChannelBusy",
    "ChannelLease",
    "ChannelLeaseManager",
    "DEFAULT_TTL_SECONDS",
    "LeaseError",
    "now_utc",
]
