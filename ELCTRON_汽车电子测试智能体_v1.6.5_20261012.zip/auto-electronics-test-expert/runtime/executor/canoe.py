"""Fail-closed CANoe control-plane adapter.

CAPL is the data plane.  This module only probes an already-running CANoe and
constructs a managed-run plan.  It does not launch CANoe, open a configuration,
compile CAPL, start measurement, or issue diagnostic traffic.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import PureWindowsPath
from typing import Any


class CanoeAdapterError(RuntimeError):
    """Raised when an explicit CANoe binding has not been supplied."""


@dataclass(frozen=True)
class CanoeConnectionProbe:
    attached: bool
    reason: str
    version: str = ""


class CanoeControlPlane:
    """Read-only probe plus declarative plan builder; no hidden COM side effects."""

    prog_id = "CANoe.Application"

    def probe_active(self) -> CanoeConnectionProbe:
        try:
            import win32com.client  # pywin32 is already a package dependency
            app = win32com.client.GetActiveObject(self.prog_id)
            version = str(getattr(app, "Version", "") or "")
            return CanoeConnectionProbe(True, "ACTIVE_OBJECT_ATTACHED", version)
        except Exception as exc:  # COM errors must stay fail-closed and serializable
            return CanoeConnectionProbe(False, "ACTIVE_OBJECT_UNAVAILABLE", type(exc).__name__)

    def managed_run_plan(self, *, configuration: str, target_qualifier: str,
                         generated_capl: str, report_directory: str, run_id: str) -> dict[str, Any]:
        values = {"configuration": configuration, "target_qualifier": target_qualifier,
                  "generated_capl": generated_capl, "report_directory": report_directory, "run_id": run_id}
        if any(not str(value or "").strip() for value in values.values()):
            raise CanoeAdapterError("CANOE_MANAGED_BINDING_REQUIRED")
        config_path, capl_path, report_path = (PureWindowsPath(str(values[key])) for key in
                                               ("configuration", "generated_capl", "report_directory"))
        if config_path.suffix.lower() not in {".cfg", ".can"} or capl_path.suffix.lower() != ".can":
            raise CanoeAdapterError("CANOE_CONFIGURATION_OR_CAPL_PATH_INVALID")
        return {"schema_version": "canoe-managed-run-plan/v0.1", "adapter": "canoe-com",
                "run_id": str(run_id), "configuration": str(config_path),
                "target_qualifier": str(target_qualifier), "generated_capl": str(capl_path),
                "report_directory": str(report_path), "actions": ["bind_explicit_test_setup", "compile_capl", "start_measurement"],
                "execution_authorized": False}

    def start_managed_run(self, plan: dict[str, Any]) -> None:
        del plan
        raise CanoeAdapterError("CANOE_TEST_SETUP_BINDING_REQUIRED")


__all__ = ["CanoeAdapterError", "CanoeConnectionProbe", "CanoeControlPlane"]
