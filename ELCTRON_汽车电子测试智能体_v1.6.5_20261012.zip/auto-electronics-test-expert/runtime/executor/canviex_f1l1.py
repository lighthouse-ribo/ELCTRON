"""CANviex F1L1 UDS-over-LIN adapter backed by the supplied xcdevlay SDK.

Loading the module has no device side effect.  ``probe`` only asks the SDK for
its version/device availability; ``tester_present`` is deliberately invoked
only by an execution node that has already passed GraphRunner's token guard.
"""
from __future__ import annotations

import importlib
import os
import sys
from ctypes import byref, c_uint
from dataclasses import dataclass
from typing import Any, Callable

from .asc_session import AscSession


class CanviexF1L1Error(RuntimeError):
    pass


@dataclass(frozen=True)
class F1L1Probe:
    dll_version: str
    device_count: int
    available_bitmap: int

    @property
    def available(self) -> bool:
        return self.device_count > 0 and bool(self.available_bitmap & 1)


def _scripts_dir() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                        "skills", "uds-diagnostic-test", "scripts")


def _load_module(name: str):
    scripts = _scripts_dir()
    if not os.path.isfile(os.path.join(scripts, f"{name}.py")):
        raise CanviexF1L1Error(f"F1L1 skill module is missing: {name}")
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise CanviexF1L1Error(f"F1L1 SDK binding unavailable: {type(exc).__name__}") from exc


def probe_f1l1() -> F1L1Probe:
    """Read SDK version and F1L1 availability without opening a channel."""
    wrapper = _load_module("xcdev_wrapper")
    available = c_uint(0)
    count = int(wrapper.dll.xcdev_detect_ex(wrapper.XC_HARDTYPE_CANVIEX_F1L1, byref(available)))
    return F1L1Probe(str(wrapper.version()), count, int(available.value))


class CanviexF1L1Executor:
    """Minimal UDS executor that turns verified driver traces into ASC evidence."""

    def __init__(self, *, client_factory: Callable[[], Any] | None = None,
                 asc_factory: Callable[..., Any] = AscSession, lin_output_voltage: int | None = None):
        self._lin_output_voltage = lin_output_voltage
        self._client_factory = client_factory
        self._asc_factory = asc_factory

    def _client(self) -> Any:
        if self._client_factory is not None:
            return self._client_factory()
        if self._lin_output_voltage not in (0, 1):
            raise CanviexF1L1Error("LIN 供电未确认：请明确适配器内置 12V 输出为关闭(0)或开启(1)")
        return _load_module("f1l1_uds").F1L1UDS(output_voltage=self._lin_output_voltage)

    def tester_present(self, *, run_dir: str, run_id: str, channel: str = "LIN1",
                       case_id: str = "UDS-TESTER-PRESENT", nad: int = 0x51,
                       timeout: float = 1.2) -> dict[str, object]:
        """Send UDS 0x3E 00 and seal only actual SDK timestamped frames."""
        client = self._client()
        session = self._asc_factory(run_dir, run_id=run_id, channel=channel, case_id=case_id)
        sealed: dict[str, object] | None = None
        try:
            client.open(retries=1, retry_interval=0.1)
            session.open()
            response, trace, _started, _ended = client.request_with_trace(
                nad, [0x3E, 0x00], timeout=timeout, retry=0, transaction_id=f"{run_id}:{case_id}")
            if not trace:
                raise CanviexF1L1Error("F1L1 returned no timestamped TX/RX evidence")
            for event in trace:
                if not isinstance(event, tuple) or len(event) < 4:
                    raise CanviexF1L1Error("F1L1 trace event is malformed")
                timestamp, direction, frame_id, data = event[:4]
                session.record(timestamp, str(direction).lower(), int(frame_id), data)
            sealed = session.seal()
            return {"request": [0x3E, 0x00], "nad": nad, "response": response,
                    "response_positive": response == [0x7E, 0x00], "evidence": sealed}
        except Exception as exc:
            if sealed is None:
                try:
                    session.abort(f"{type(exc).__name__}:{exc}")
                except Exception:
                    pass
            if isinstance(exc, CanviexF1L1Error):
                raise
            raise CanviexF1L1Error(f"F1L1 execution failed: {type(exc).__name__}") from exc
        finally:
            try:
                client.close()
            except Exception:
                pass


__all__ = ["CanviexF1L1Error", "CanviexF1L1Executor", "F1L1Probe", "probe_f1l1"]
