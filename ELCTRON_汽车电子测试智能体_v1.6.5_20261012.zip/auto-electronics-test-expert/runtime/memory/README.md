# P6 记忆适配层（本地 PoC）

该目录实现的是**受治理的只读辅助记忆**，不是第二状态机：`runtime/orchestrator/` 仍是 run 状态、审批、设备租约和证据链的唯一事实源。

## 当前能力

- `LocalSQLiteMemoryStore`：零新增依赖的本地 SQLite；canonical records 追加写入、撤回 tombstone，派生 FTS5/BM25 与本地向量索引均可安全重建；
- `MemoryService`：只有已审批的 `MemoryCandidate` 且带 `source_run_id`、证据 SHA-256、规则版本和适用条件才能提升；
- `Mem0Adapter`：可选镜像，默认关闭且不在包内引入 `mem0ai`；本地 SQLite 永远为事实源。

## 永不写入

- `run_state.json`、运行时状态、设备租约、GateRecord；
- ApprovalToken、`credential://` 引用、API Key、密码、私钥；
- 原始 ASC/XCT 内容、设备绝对路径。

## 接入边界

运行完成后由独立 outbox/人工审批流程调用 `MemoryService.promote()`；推理节点只能调用 `retrieve()` 取得带 `source_run_id` 和 `evidence_sha256` 的建议。检索在项目 namespace 内先执行 FTS5/BM25（含确定性 CJK 子串补足），再与本地向量召回用 RRF 融合，最后以 MMR 去重；`retrieve_ranked()` 额外返回两路 rank 与 RRF 分数，便于审计。记忆不得改变状态迁移、审批或硬件执行决定。

## P6.2b 本地向量边界

默认 `HashEmbeddingProvider` 是零依赖、确定性的本地哈希向量，用于在不下载模型、不向外部发送项目资料的前提下验证索引、RRF 和 MMR 链路。它**不是语义 embedding 模型**，不能宣称同义词语义召回能力。后续仅可通过同一 `EmbeddingProvider` 接口接入经审核、明确本机路径的 BGE 类本地模型；模型文件、向量索引和召回结果仍必须受项目 scope、撤回和过期过滤约束。外部 embedding 服务、RRF 参数调优和 MMR 质量评估不得在本阶段默认启用。

## 验证

```powershell
python runtime/tests/test_memory.py
```

Mem0 的验证必须在隔离 PoC 环境安装 `mem0ai` 后进行；不得把云端凭据或原始证据带入该环境。
