"""Local append-only memory store plus a durable, revocable mirror outbox."""
from __future__ import annotations
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Protocol
import hashlib
import json
import math
import re
import sqlite3

from .governance import ApprovedMemoryCandidate


_SEARCH_TOKEN = re.compile(r"[0-9A-Za-z_]+|[\u4e00-\u9fff]+")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True)
class MemoryRecord:
    memory_id: str
    namespace: str
    project_id: str
    kind: str
    content: str
    source_run_id: str
    evidence_sha256: str
    rule_version: str
    created_at: str
    expires_at: str | None
    supersedes: str | None
    status: str = "active"

    def public_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class MirrorOutboxItem:
    memory_id: str
    status: str
    attempts: int
    last_error: str | None
    created_at: str
    updated_at: str
    record: MemoryRecord


class EmbeddingProvider(Protocol):
    """A local-only vector provider. Implementations must never make network calls."""

    provider_id: str
    allow_vector_only_recall: bool

    def embed(self, text: str) -> tuple[float, ...]: ...


@dataclass(frozen=True)
class HashEmbeddingProvider:
    """Deterministic local vector baseline, intentionally not a semantic model.

    It is useful for proving the vector/RRF/MMR pipeline without downloading a
    model or disclosing project material. A reviewed local embedding model can
    replace this provider without changing store or retrieval ownership.
    """

    dimensions: int = 192
    provider_id: str = "local-hash/v1"
    # Hash collisions are not semantic evidence; they may rerank lexical hits
    # but must never introduce an otherwise unmatched record.
    allow_vector_only_recall: bool = False

    def embed(self, text: str) -> tuple[float, ...]:
        values = [0.0] * self.dimensions
        tokens = [item.casefold() for item in _SEARCH_TOKEN.findall(text)]
        features = tokens + [f"{left}|{right}" for left, right in zip(tokens, tokens[1:])]
        for feature in features:
            digest = hashlib.blake2b(feature.encode("utf-8"), digest_size=8).digest()
            bucket = int.from_bytes(digest[:4], "big") % self.dimensions
            values[bucket] += 1.0 if digest[4] & 1 else -1.0
        length = math.sqrt(sum(value * value for value in values))
        return tuple(value / length for value in values) if length else tuple(values)


@dataclass(frozen=True)
class MemorySearchHit:
    """Read-only ranking metadata; canonical records remain in SQLite."""

    record: MemoryRecord
    lexical_rank: int | None
    vector_rank: int | None
    rrf_score: float


class LocalSQLiteMemoryStore:
    """Append-only memory truth. Remote mirrors are best-effort copies, never truth."""

    def __init__(self, database_path: str | Path, *, embedding_provider: EmbeddingProvider | None = None):
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.embedding_provider = embedding_provider or HashEmbeddingProvider()
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path)
        connection.row_factory = sqlite3.Row
        return connection

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        database = self._connect()
        try:
            yield database
            database.commit()
        except BaseException:
            database.rollback()
            raise
        finally:
            database.close()

    def _init_schema(self) -> None:
        with self._connection() as database:
            database.executescript("""
                CREATE TABLE IF NOT EXISTS memory_records (
                    memory_id TEXT PRIMARY KEY, namespace TEXT NOT NULL, project_id TEXT NOT NULL,
                    kind TEXT NOT NULL, content TEXT NOT NULL, source_run_id TEXT NOT NULL,
                    evidence_sha256 TEXT NOT NULL, rule_version TEXT NOT NULL, created_at TEXT NOT NULL,
                    expires_at TEXT, supersedes TEXT, status TEXT NOT NULL CHECK(status IN ('active', 'revoked'))
                );
                CREATE INDEX IF NOT EXISTS idx_memory_scope
                    ON memory_records(namespace, project_id, status, expires_at);
                CREATE TABLE IF NOT EXISTS memory_mirror_outbox (
                    memory_id TEXT PRIMARY KEY,
                    status TEXT NOT NULL CHECK(status IN ('pending', 'mirrored', 'revoked')),
                    attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
                    last_error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (memory_id) REFERENCES memory_records(memory_id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_memory_outbox_pending
                    ON memory_mirror_outbox(status, updated_at);
                CREATE TABLE IF NOT EXISTS memory_vectors (
                    memory_id TEXT PRIMARY KEY,
                    provider_id TEXT NOT NULL,
                    vector_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (memory_id) REFERENCES memory_records(memory_id) ON DELETE CASCADE
                );
                CREATE VIRTUAL TABLE IF NOT EXISTS memory_records_fts
                    USING fts5(memory_id UNINDEXED, content, tokenize = 'unicode61 remove_diacritics 2');
            """)
            # FTS is a derived, rebuildable index. Backfill keeps existing local
            # truth intact while making the migration additive and idempotent.
            database.execute("""
                INSERT INTO memory_records_fts(memory_id, content)
                SELECT memory_id, content FROM memory_records
                WHERE memory_id NOT IN (SELECT memory_id FROM memory_records_fts)
            """)
            # Vectors are a derived local index. Backfill is additive and makes
            # provider replacement explicit through provider_id.
            rows = database.execute("""
                SELECT r.memory_id, r.content FROM memory_records r
                LEFT JOIN memory_vectors v ON v.memory_id = r.memory_id AND v.provider_id = ?
                WHERE r.status = 'active' AND v.memory_id IS NULL
            """, (self.embedding_provider.provider_id,)).fetchall()
            for row in rows:
                self._write_vector(database, row["memory_id"], row["content"])

    def _write_vector(self, database: sqlite3.Connection, memory_id: str, content: str) -> None:
        vector = self.embedding_provider.embed(content)
        if not vector:
            raise ValueError("embedding provider returned an empty vector")
        database.execute("""
            INSERT INTO memory_vectors(memory_id, provider_id, vector_json, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(memory_id) DO UPDATE SET provider_id = excluded.provider_id,
                vector_json = excluded.vector_json, updated_at = excluded.updated_at
        """, (memory_id, self.embedding_provider.provider_id, json.dumps(vector), _utc_now()))

    def promote(self, candidate: ApprovedMemoryCandidate) -> MemoryRecord:
        record = MemoryRecord(
            candidate.candidate_id, candidate.namespace, candidate.project_id, candidate.kind,
            candidate.content, candidate.source_run_id, candidate.evidence_sha256,
            candidate.rule_version, _utc_now(), candidate.expires_at, candidate.supersedes,
        )
        with self._connection() as database:
            database.execute(
                """INSERT INTO memory_records VALUES
                (:memory_id, :namespace, :project_id, :kind, :content, :source_run_id, :evidence_sha256,
                 :rule_version, :created_at, :expires_at, :supersedes, :status)""",
                record.public_dict(),
            )
            database.execute(
                "INSERT INTO memory_records_fts(memory_id, content) VALUES (?, ?)",
                (record.memory_id, record.content),
            )
            self._write_vector(database, record.memory_id, record.content)
        return record

    def queue_mirror(self, record: MemoryRecord) -> None:
        if record.status != "active":
            raise ValueError("only active approved memory may enter the mirror outbox")
        now = _utc_now()
        with self._connection() as database:
            database.execute(
                """INSERT INTO memory_mirror_outbox (memory_id, status, attempts, last_error, created_at, updated_at)
                VALUES (?, 'pending', 0, NULL, ?, ?)
                ON CONFLICT(memory_id) DO NOTHING""",
                (record.memory_id, now, now),
            )

    def _outbox_item(self, row: sqlite3.Row) -> MirrorOutboxItem:
        record = MemoryRecord(
            memory_id=row["memory_id"], namespace=row["namespace"], project_id=row["project_id"],
            kind=row["kind"], content=row["content"], source_run_id=row["source_run_id"],
            evidence_sha256=row["evidence_sha256"], rule_version=row["rule_version"],
            created_at=row["record_created_at"], expires_at=row["expires_at"],
            supersedes=row["supersedes"], status=row["record_status"],
        )
        return MirrorOutboxItem(
            memory_id=row["memory_id"], status=row["outbox_status"], attempts=row["attempts"],
            last_error=row["last_error"], created_at=row["outbox_created_at"], updated_at=row["outbox_updated_at"],
            record=record,
        )

    def get_outbox_item(self, memory_id: str) -> MirrorOutboxItem | None:
        with self._connection() as database:
            row = database.execute("""
                SELECT o.memory_id, o.status AS outbox_status, o.attempts, o.last_error,
                       o.created_at AS outbox_created_at, o.updated_at AS outbox_updated_at,
                       r.namespace, r.project_id, r.kind, r.content, r.source_run_id, r.evidence_sha256,
                       r.rule_version, r.created_at AS record_created_at, r.expires_at, r.supersedes,
                       r.status AS record_status
                FROM memory_mirror_outbox o JOIN memory_records r ON r.memory_id = o.memory_id
                WHERE o.memory_id = ?
            """, (memory_id,)).fetchone()
        return self._outbox_item(row) if row else None

    def pending_mirrors(self, limit: int = 25) -> list[MirrorOutboxItem]:
        if limit < 1 or limit > 100:
            raise ValueError("limit must be in 1..100")
        with self._connection() as database:
            rows = database.execute("""
                SELECT o.memory_id, o.status AS outbox_status, o.attempts, o.last_error,
                       o.created_at AS outbox_created_at, o.updated_at AS outbox_updated_at,
                       r.namespace, r.project_id, r.kind, r.content, r.source_run_id, r.evidence_sha256,
                       r.rule_version, r.created_at AS record_created_at, r.expires_at, r.supersedes,
                       r.status AS record_status
                FROM memory_mirror_outbox o JOIN memory_records r ON r.memory_id = o.memory_id
                WHERE o.status = 'pending' AND r.status = 'active'
                ORDER BY o.updated_at ASC LIMIT ?
            """, (limit,)).fetchall()
        return [self._outbox_item(row) for row in rows]

    def mark_mirror_succeeded(self, memory_id: str) -> bool:
        with self._connection() as database:
            result = database.execute(
                "UPDATE memory_mirror_outbox SET status = 'mirrored', last_error = NULL, updated_at = ? "
                "WHERE memory_id = ? AND status = 'pending'", (_utc_now(), memory_id),
            )
        return result.rowcount == 1

    def mark_mirror_failed(self, memory_id: str, error: str) -> bool:
        with self._connection() as database:
            result = database.execute(
                "UPDATE memory_mirror_outbox SET attempts = attempts + 1, last_error = ?, updated_at = ? "
                "WHERE memory_id = ? AND status = 'pending'",
                (error[:500], _utc_now(), memory_id),
            )
        return result.rowcount == 1

    def revoke(self, memory_id: str) -> bool:
        with self._connection() as database:
            result = database.execute(
                "UPDATE memory_records SET status = 'revoked' WHERE memory_id = ? AND status = 'active'", (memory_id,),
            )
            if result.rowcount == 1:
                # The canonical record remains a tombstone for auditability, but
                # a revoked lesson must never remain in the derived recall index.
                database.execute("DELETE FROM memory_records_fts WHERE memory_id = ?", (memory_id,))
                database.execute("DELETE FROM memory_vectors WHERE memory_id = ?", (memory_id,))
                database.execute(
                    "UPDATE memory_mirror_outbox SET status = 'revoked', updated_at = ? "
                    "WHERE memory_id = ? AND status = 'pending'", (_utc_now(), memory_id),
                )
        return result.rowcount == 1

    @staticmethod
    def _cosine(left: tuple[float, ...], right: tuple[float, ...]) -> float:
        if len(left) != len(right) or not left or not right:
            return 0.0
        return sum(a * b for a, b in zip(left, right))

    def search_ranked(self, *, project_id: str, query: str, include_generic: bool = True,
                      limit: int = 5, rrf_k: int = 60, mmr_lambda: float = 0.7) -> list[MemorySearchHit]:
        """Fuse local BM25 and local vectors with RRF, then diversify with MMR."""
        if not isinstance(query, str) or len(query) > 512:
            raise ValueError("query must be a string of at most 512 characters")
        terms = [term.casefold() for term in _SEARCH_TOKEN.findall(query)]
        if not terms:
            return []
        if limit < 1 or limit > 20:
            raise ValueError("limit must be in 1..20")
        if rrf_k < 1:
            raise ValueError("rrf_k must be positive")
        if not 0.0 <= mmr_lambda <= 1.0:
            raise ValueError("mmr_lambda must be in 0..1")
        namespaces = (f"project:{project_id}", "generic") if include_generic else (f"project:{project_id}",)
        marks = ",".join("?" for _ in namespaces)
        with self._connection() as database:
            # FTS5/BM25 is the primary local lexical recall path. Scope and
            # validity filtering stays in the same query, never in the prompt.
            fts_query = " OR ".join(f'"{term}"' for term in terms[:24])
            ranked = database.execute(
                f"""SELECT r.*, bm25(memory_records_fts) AS bm25_score
                    FROM memory_records_fts JOIN memory_records r
                      ON r.memory_id = memory_records_fts.memory_id
                    WHERE memory_records_fts MATCH ?
                      AND r.project_id = ? AND r.namespace IN ({marks})
                      AND r.status = 'active' AND (r.expires_at IS NULL OR r.expires_at > ?)
                    ORDER BY bm25_score ASC, r.created_at DESC LIMIT 100""",
                (fts_query, project_id, *namespaces, _utc_now()),
            ).fetchall()
            rows = database.execute(
                f"SELECT * FROM memory_records WHERE project_id = ? AND namespace IN ({marks}) "
                "AND status = 'active' AND (expires_at IS NULL OR expires_at > ?)",
                (project_id, *namespaces, _utc_now()),
            ).fetchall()
        # Unicode61 does not segment all CJK automotive compounds. Keep a
        # deterministic substring fallback until optional semantic retrieval is added.
        records = {row["memory_id"]: MemoryRecord(**dict(row)) for row in rows}
        lexical_rank: dict[str, int] = {}
        for position, row in enumerate(ranked, start=1):
            payload = dict(row)
            payload.pop("bm25_score", None)  # ranking metadata is not canonical memory data
            records[row["memory_id"]] = MemoryRecord(**payload)
            lexical_rank[row["memory_id"]] = position
        # FTS does not split every automotive CJK phrase. Preserve a deterministic
        # substring fallback, but do not let it overwrite a BM25 ranking.
        fallback_rank: list[tuple[float, str, str]] = []
        for row in rows:
            score = sum(row["content"].casefold().count(term) for term in terms)
            if score and row["memory_id"] not in lexical_rank:
                fallback_rank.append((float(score), row["created_at"], row["memory_id"]))
        for position, (_, _, memory_id) in enumerate(sorted(fallback_rank, reverse=True), start=len(lexical_rank) + 1):
            lexical_rank[memory_id] = position

        with self._connection() as database:
            vector_rows = database.execute("""
                SELECT memory_id, vector_json FROM memory_vectors
                WHERE provider_id = ?
            """, (self.embedding_provider.provider_id,)).fetchall()
        query_vector = self.embedding_provider.embed(query)
        vectors = {
            row["memory_id"]: tuple(float(value) for value in json.loads(row["vector_json"]))
            for row in vector_rows if row["memory_id"] in records
        }
        vector_rank = {
            memory_id: position for position, (memory_id, _) in enumerate(
                sorted(((memory_id, self._cosine(query_vector, vector)) for memory_id, vector in vectors.items()),
                       key=lambda item: (item[1], records[item[0]].created_at), reverse=True), start=1
            )
        }
        candidate_ids = set(lexical_rank)
        if getattr(self.embedding_provider, "allow_vector_only_recall", False):
            candidate_ids |= set(vector_rank)
        hits = [MemorySearchHit(
            record=records[memory_id], lexical_rank=lexical_rank.get(memory_id), vector_rank=vector_rank.get(memory_id),
            rrf_score=sum(1.0 / (rrf_k + rank) for rank in (lexical_rank.get(memory_id), vector_rank.get(memory_id)) if rank),
        ) for memory_id in candidate_ids]
        hits.sort(key=lambda hit: (hit.rrf_score, hit.record.created_at, hit.record.memory_id), reverse=True)
        # MMR is applied only to the fused shortlist: selected memories remain
        # explainable by their BM25/vector ranks and never escape scope filters.
        shortlist = hits[:max(50, limit * 8)]
        selected: list[MemorySearchHit] = []
        while shortlist and len(selected) < limit:
            maximum = shortlist[0].rrf_score or 1.0
            def mmr_score(hit: MemorySearchHit) -> tuple[float, float, str]:
                diversity_penalty = max((self._cosine(vectors.get(hit.record.memory_id, ()),
                                                       vectors.get(chosen.record.memory_id, ()))
                                         for chosen in selected), default=0.0)
                return (mmr_lambda * (hit.rrf_score / maximum) - (1.0 - mmr_lambda) * diversity_penalty,
                        hit.rrf_score, hit.record.memory_id)
            best = max(shortlist, key=mmr_score)
            selected.append(best)
            shortlist.remove(best)
        return selected

    def search(self, *, project_id: str, query: str, include_generic: bool = True, limit: int = 5) -> list[MemoryRecord]:
        return [hit.record for hit in self.search_ranked(
            project_id=project_id, query=query, include_generic=include_generic, limit=limit,
        )]
