"""P6 memory governance boundary.

Memory is a read-only advisory subsystem. It never owns runtime state,
approvals, device leases, or evidence files.
"""

from .governance import MemoryGovernanceError, validate_candidate
from .local import HashEmbeddingProvider, LocalSQLiteMemoryStore, MemoryRecord, MemorySearchHit
from .service import MemoryService

__all__ = ["HashEmbeddingProvider", "LocalSQLiteMemoryStore", "MemoryGovernanceError", "MemoryRecord",
           "MemorySearchHit", "MemoryService", "validate_candidate"]
