"""Optional Mem0 mirror. It is never enabled implicitly and never owns truth."""
from __future__ import annotations

from .local import MemoryRecord


class Mem0Unavailable(RuntimeError):
    pass


class Mem0Adapter:
    def __init__(self, *, config: dict | None = None):
        self.config = config or {}
        self._client = None

    def _load(self):
        if self._client is not None:
            return self._client
        try:
            from mem0 import Memory  # type: ignore[import-not-found]
        except ImportError as exc:
            raise Mem0Unavailable("Mem0 is optional; install mem0ai only in the isolated POC environment") from exc
        self._client = Memory(config=self.config) if self.config else Memory()
        return self._client

    def mirror(self, record: MemoryRecord) -> object:
        return self._load().add(
            [{"role": "system", "content": record.content}], user_id=record.project_id,
            metadata={"memory_id": record.memory_id, "namespace": record.namespace,
                      "source_run_id": record.source_run_id, "evidence_sha256": record.evidence_sha256,
                      "rule_version": record.rule_version},
        )
