"""Fail-closed admission rules for long-term agent memory."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import re

from pydantic import ValidationError

from ..contracts.generated.models import MemoryCandidate


class MemoryGovernanceError(ValueError):
    """A candidate is not safe or not sufficiently attributable to retain."""


_UNSAFE = re.compile(
    r"\bapi[_ -]?key\b|\bauthorization\b|\bauth[_ -]?token\b|"
    r"\bapproval[_ -]?token\b|\bapprovaltoken\b|\bcredential://|"
    r"\b(?:secret|password|private key)\b|-----BEGIN [A-Z ]+PRIVATE KEY-----|"
    r"\brun_state\.json\b|%TSD-Header|\.(?:asc|xct)\b|(?<![A-Za-z])[A-Za-z]:\\",
    re.IGNORECASE,
)
_KINDS = frozenset({"rule", "template", "runbook", "compat"})
_SCOPES = frozenset({"generic", "project"})


@dataclass(frozen=True)
class ApprovedMemoryCandidate:
    candidate_id: str
    kind: str
    source_run_id: str
    content: str
    project_id: str
    namespace: str
    evidence_sha256: str
    rule_version: str
    expires_at: str | None
    supersedes: str | None


def _require_text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise MemoryGovernanceError(f"{label} must be a non-empty string")
    return value.strip()


def _contract_candidate(candidate: Mapping[str, object]) -> dict[str, object]:
    """Use the generated Pydantic model as the only admission contract."""
    try:
        return MemoryCandidate.model_validate(dict(candidate)).model_dump(mode="json")
    except ValidationError as error:
        issue = error.errors(include_url=False)[0]
        raise MemoryGovernanceError(
            f"memory-candidate/v0.1 contract violation: {issue['loc']}: {issue['msg']}"
        ) from None


def validate_candidate(candidate: Mapping[str, object], *, project_id: str, evidence_sha256: str,
                       rule_version: str, expires_at: str | None = None) -> ApprovedMemoryCandidate:
    """Validate before promotion without reading or writing a runtime run directory."""
    candidate = _contract_candidate(candidate)
    candidate_id = _require_text(candidate.get("candidate_id"), "candidate_id")
    source_run_id = _require_text(candidate.get("source_run_id"), "source_run_id")
    content = _require_text(candidate.get("content"), "content")
    if len(content) > 8000:
        raise MemoryGovernanceError("content exceeds 8000 characters")
    if match := _UNSAFE.search(content):
        raise MemoryGovernanceError(f"content contains forbidden material: {match.group(0)!r}")

    kind = _require_text(candidate.get("kind"), "kind")
    if kind not in _KINDS:
        raise MemoryGovernanceError(f"unsupported memory kind: {kind}")
    if candidate.get("contains_secret_material") is not False:
        raise MemoryGovernanceError("contains_secret_material must be explicitly false")

    approval = candidate.get("approval")
    if not isinstance(approval, Mapping) or approval.get("status") != "approved":
        raise MemoryGovernanceError("only approved candidates may be promoted")
    if approval.get("approved_by") not in {"terra", "human_approver"}:
        raise MemoryGovernanceError("approved candidates require a Terra or human approver")
    if not isinstance(approval.get("approved_at"), str) or not approval.get("approved_at"):
        raise MemoryGovernanceError("approved candidates require approved_at")
    version = approval.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        raise MemoryGovernanceError("approved candidates require approval.version >= 1")

    applicability = candidate.get("applicability")
    if not isinstance(applicability, Mapping):
        raise MemoryGovernanceError("applicability is required")
    conditions = applicability.get("conditions")
    if not isinstance(conditions, list) or not conditions or not all(isinstance(item, str) and item.strip() for item in conditions):
        raise MemoryGovernanceError("applicability.conditions must contain at least one condition")
    scope = applicability.get("scope", "generic")
    if scope not in _SCOPES:
        raise MemoryGovernanceError(f"unsupported applicability scope: {scope}")

    safe_project_id = _require_text(project_id, "project_id")
    candidate_project_id = applicability.get("project_id")
    if scope == "project" and candidate_project_id not in (None, safe_project_id):
        raise MemoryGovernanceError("applicability.project_id must match the promotion project")
    safe_evidence = _require_text(evidence_sha256, "evidence_sha256")
    if not re.fullmatch(r"[0-9a-f]{64}", safe_evidence):
        raise MemoryGovernanceError("evidence_sha256 must be lowercase SHA-256")
    safe_version = _require_text(rule_version, "rule_version")

    return ApprovedMemoryCandidate(
        candidate_id=candidate_id, kind=kind, source_run_id=source_run_id, content=content,
        project_id=safe_project_id, namespace=f"project:{safe_project_id}" if scope == "project" else "generic",
        evidence_sha256=safe_evidence, rule_version=safe_version, expires_at=expires_at,
        supersedes=candidate.get("supersedes") if isinstance(candidate.get("supersedes"), str) else None,
    )