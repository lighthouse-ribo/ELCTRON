"""Governed promotion and retryable mirror delivery. This service never owns runtime state."""
from __future__ import annotations
from collections.abc import Mapping

from .governance import validate_candidate
from .local import LocalSQLiteMemoryStore, MemoryRecord, MemorySearchHit
from .mem0_adapter import Mem0Adapter


class MemoryService:
    def __init__(self, store: LocalSQLiteMemoryStore, *, mem0: Mem0Adapter | None = None):
        self.store = store
        self.mem0 = mem0

    def promote(self, candidate: Mapping[str, object], *, project_id: str, evidence_sha256: str,
                rule_version: str, expires_at: str | None = None, mirror_to_mem0: bool = False) -> MemoryRecord:
        """Admit only an already-approved candidate, then durably queue its optional mirror."""
        if mirror_to_mem0 and self.mem0 is None:
            raise ValueError("Mem0 mirror was not configured")
        approved = validate_candidate(candidate, project_id=project_id, evidence_sha256=evidence_sha256,
                                      rule_version=rule_version, expires_at=expires_at)
        record = self.store.promote(approved)
        if mirror_to_mem0:
            self.store.queue_mirror(record)
            self.flush_mirror_outbox(limit=1)
        return record

    def flush_mirror_outbox(self, *, limit: int = 25) -> list[str]:
        """Retry queued mirrors. A failure remains pending and is never allowed to remove local truth."""
        if self.mem0 is None:
            raise ValueError("Mem0 mirror was not configured")
        outcomes: list[str] = []
        for item in self.store.pending_mirrors(limit=limit):
            try:
                self.mem0.mirror(item.record)
            except Exception as exc:  # remote failures are compensated by a durable retry record
                self.store.mark_mirror_failed(item.memory_id, str(exc))
                outcomes.append(f"failed:{item.memory_id}")
            else:
                self.store.mark_mirror_succeeded(item.memory_id)
                outcomes.append(f"mirrored:{item.memory_id}")
        return outcomes

    def revoke(self, memory_id: str) -> bool:
        """Tombstone local memory and cancel any unsent mirror atomically."""
        return self.store.revoke(memory_id)

    def retrieve(self, *, project_id: str, query: str, limit: int = 5) -> list[MemoryRecord]:
        return self.store.search(project_id=project_id, query=query, limit=limit)

    def retrieve_ranked(self, *, project_id: str, query: str, limit: int = 5) -> list[MemorySearchHit]:
        """Expose explainable local ranks without granting state-write authority."""
        return self.store.search_ranked(project_id=project_id, query=query, limit=limit)
