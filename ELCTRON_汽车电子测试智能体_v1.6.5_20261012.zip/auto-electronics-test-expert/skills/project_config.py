# -*- coding: utf-8 -*-
"""Shared project configuration for UDS design, lint and generation.
The scripts in this plugin are intentionally executable as stand-alone files,
so this module contains only standard-library code and accepts either a JSON
file path or an already loaded mapping.

配置分两层，互不掺杂：

1. ``DEFAULT_PROJECT_CONFIG``——**结构性默认值**：会话集合、安全等级映射、
   NRC 策略、lint 开关、生成维度。与具体项目无关，任何项目都继承。
2. ``REFERENCE_PROJECT_PROFILE``——**参考项目档**：项目身份（project /
   展示名 / run_id 前缀 / 源工作簿名 / 版本前缀）。**独立成段**，
   *仅在未移植项目时读取*，即调用方既没传 ``--project-config``、输入包里
   也没有 ``project_config.json`` 时的兜底。移植到新项目时，项目配置里的
   同名字段会整体覆盖本段，**无需改动本模块代码**。

由此，技能代码里不再出现任何项目字面量：各脚本统一
``load_project_config(...)`` 取用，项目数据只活在「参考项目档」或外部
``project_config.json`` 里。
"""
from __future__ import annotations
import copy
import json
import os
import re
from collections.abc import Mapping, Sequence
from typing import Any
PROJECT_CONFIG_SCHEMA = "auto-electronics-test-expert.project.v1"

# ===========================================================================
# 参考项目档（REFERENCE PROJECT PROFILE）—— 独立成段
# ---------------------------------------------------------------------------
# 只在「未移植项目」时读取：调用方未传 --project-config、输入包里也没有
# project_config.json 时，用本段兜底，保证既有行为不变。
# 移植新项目时：外部 project_config.json 覆盖本段全部同名字段（identity 按
# 「整段替换」处理，不会残留参考项目的展示名），改项目不改代码。
# ===========================================================================
REFERENCE_PROJECT_PROFILE: dict[str, Any] = {
    "project": "BBS_P519_V436",
    "identity": {
        # 报告标题 / 时间轴抬头显示名
        "display_name": "BBS P519 V436",
        # run_id 前缀（SWDL 计划、错误日志等产物命名）
        "run_id_prefix": "BBS",
        # 只读来源工作簿名称（网络安全选择性覆盖分析用）
        "source_workbook": "BBS_P519_V436-系统合格性测试用例System qualification test.xlsx",
        # 展示短版本号时需要剥离的前缀
        "version_prefixes": ["BBS_"],
    },
}

DEFAULT_PROJECT_CONFIG: dict[str, Any] = {
    "schema_version": PROJECT_CONFIG_SCHEMA,
    "project": "legacy-default",
    "identity": {
        "display_name": "",
        "run_id_prefix": "",
        "source_workbook": "",
        "version_prefixes": [],
    },
    "transport": {
        "physical_nad": 0x51,
        # Historical LIN functional addressing used by the existing test
        # corpus. Projects with another functional NAD override this value.
        "functional_nad": 0x7E,
    },
    "sessions": {
        "supported": [0x01, 0x02, 0x03],
        "names": {
            "0x01": "默认会话",
            "0x02": "编程会话",
            "0x03": "扩展会话",
        },
        "allowed_transitions": {
            "0x01": [0x01, 0x02, 0x03],
            "0x02": [0x01, 0x02],
            "0x03": [0x01, 0x02, 0x03],
        },
        "enforce_transition_matrix": True,
        "default": 0x01,
        "transition_nrc": 0x22,
        "s3_required": [0x02, 0x03],
    },
    "security": {
        "level_to_sessions": {
            "0x01": [0x02],
            "0x02": [0x02],
            "0x05": [0x03],
            "0x06": [0x03],
        },
        "default_level_sessions": [0x03],
        "unlock_required_services": [
            "0x14", "0x2E", "0x31", "0x2F", "0x34", "0x36", "0x37",
        ],
    },
    "nrc": {
        "illegal_subfunction": {
            "0x10": 0x12,
            "0x11": 0x12,
            "0x27": 0x12,
            "0x3E": 0x12,
        },
    },
    "lint": {
        "read_only_dids": [],
        "negative_keywords": ["负向", "负例", "负响应", "拒绝", "被拒", "非法", "不支持", "未解锁"],
        "require_nrc_for_negative": True,
        "require_session_for_security": True,
    },
    "generation": {
        # Keep the previous full-matrix expansion as the no-config default.
        "session_targets": [0x01, 0x02, 0x03],
        "session_sources": [0x01, 0x02, 0x03],
        "read_sessions": [0x01, 0x03],
        "security_sessions": [0x01, 0x03],
        "tester_present_sessions": [0x01, 0x02, 0x03],
        "reset_sessions": [0x01, 0x03],
        "security_access_subfunctions": [0x05, 0x06],
        "session_probe_did": "F186",
        "reset_probe_did": "F186",
        # ``None`` lets the matrix generator choose an unused DID for the
        # unsupported-DID negative case instead of inheriting a project DID.
        "unsupported_did": None,
        "security_constant_dids": {
            "0x0506": "F10A",
            "0x0102": "F103",
        },
        "representative_write_did": "F12E",
        # None means all DIDs.  The legacy default intentionally remains 10.
        "max_write_dids": 10,
        "s3_boundary_before_ms": 100,
        "s3_boundary_after_ms": 100,
    },
}
def parse_int(value: Any, default: int | None = None) -> int | None:
    """Parse decimal/hex values used by JSON configuration."""
    if isinstance(value, bool):
        return default
    if isinstance(value, int):
        return value
    raw = str(value or "").strip()
    if not raw:
        return default
    try:
        return int(raw, 0)
    except ValueError:
        try:
            return int(raw, 16)
        except ValueError:
            return default
def canonical_service(value: Any) -> str:
    number = parse_int(value)
    if number is not None:
        return f"0x{number & 0xFF:02X}"
    raw = str(value or "").strip().upper()
    match = re.search(r"(?:0X)?([0-9A-F]{2})", raw)
    return f"0x{match.group(1)}" if match else raw.lower()
def canonical_did(value: Any) -> str:
    raw = str(value or "").strip().upper()
    raw = raw[2:] if raw.startswith("0X") else raw
    return raw if re.fullmatch(r"[0-9A-F]{4}", raw) else ""


def canonical_hex_bytes(value: Any) -> str:
    """Normalize a hexadecimal byte sequence used as a configuration key.

    SecurityAccess mappings use keys such as ``0x0506`` to represent the
    sub-function byte pair ``05 06``.  Remove the prefix before filtering
    separators; otherwise the zero in ``0x`` becomes part of the payload and
    shifts every byte (``0x0708`` -> ``00708``).
    """
    if isinstance(value, bool) or value is None:
        return ""
    if isinstance(value, int):
        if value < 0:
            return ""
        raw = f"{value:X}"
    else:
        raw = str(value).strip().upper().replace("0X", "")
    raw = re.sub(r"[^0-9A-F]", "", raw)
    if not raw:
        return ""
    if len(raw) % 2:
        raw = "0" + raw
    return raw
def _deep_merge(base: Mapping[str, Any], override: Mapping[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(dict(base))
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(result.get(key), Mapping):
            # 显式空对象表示“清空默认配置”（例如不使用安全常量 DID），
            # 而不是继续继承兼容默认值；非空对象仍支持局部覆盖。
            result[key] = {} if not value else _deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result
def _values(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, str) or not isinstance(value, Sequence):
        return [value]
    return list(value)
def _int_list(value: Any, *, allowed: set[int] | None = None) -> list[int]:
    result = []
    for item in _values(value):
        number = parse_int(item)
        if number is None:
            continue
        if allowed is not None and number not in allowed:
            continue
        if number not in result:
            result.append(number)
    return result
def _session_map(value: Any, supported: set[int]) -> dict[int, list[int]]:
    result: dict[int, list[int]] = {}
    if not isinstance(value, Mapping):
        return result
    for source, targets in value.items():
        source_id = parse_int(source)
        if source_id is None or source_id not in supported:
            continue
        result[source_id] = _int_list(targets, allowed=supported)
    return result


def _validate_byte(value: Any, path: str) -> None:
    number = parse_int(value)
    if number is None or not 0 <= number <= 0xFF:
        raise ValueError(f"项目配置 {path} 必须是 0x00~0xFF 的字节值: {value!r}")


def _validate_session_id(value: Any, path: str) -> None:
    """Validate a session sub-function without the 0x80 suppress bit."""
    number = parse_int(value)
    if number is None or not 0 <= number <= 0x7F:
        raise ValueError(
            f"项目配置 {path} 必须是 0x00~0x7F 的会话子功能值: {value!r}"
        )


def _validate_nonnegative_int(value: Any, path: str) -> None:
    number = parse_int(value)
    if number is None or number < 0:
        raise ValueError(f"项目配置 {path} 必须是非负整数: {value!r}")


def _validate_custom_config(raw: Mapping[str, Any]) -> None:
    """Fail fast on values whose silent fallback can change test meaning."""
    transport = raw.get("transport")
    if isinstance(transport, Mapping):
        for key in ("physical_nad", "functional_nad"):
            if key in transport:
                _validate_byte(transport[key], f"transport.{key}")

    sessions = raw.get("sessions")
    if isinstance(sessions, Mapping):
        for key in ("supported", "s3_required"):
            if key in sessions:
                for index, value in enumerate(_values(sessions[key])):
                    _validate_session_id(value, f"sessions.{key}[{index}]")
        if "default" in sessions:
            _validate_session_id(sessions["default"], "sessions.default")
        if "transition_nrc" in sessions:
            _validate_byte(sessions["transition_nrc"], "sessions.transition_nrc")
        transitions = sessions.get("allowed_transitions")
        if isinstance(transitions, Mapping):
            for source, targets in transitions.items():
                _validate_session_id(source, "sessions.allowed_transitions key")
                for index, target in enumerate(_values(targets)):
                    _validate_session_id(target, f"sessions.allowed_transitions[{source!r}][{index}]")

    security = raw.get("security")
    if isinstance(security, Mapping):
        levels = security.get("level_to_sessions")
        if isinstance(levels, Mapping):
            for level, allowed_sessions in levels.items():
                _validate_byte(level, "security.level_to_sessions key")
                for index, session in enumerate(_values(allowed_sessions)):
                    _validate_session_id(session, f"security.level_to_sessions[{level!r}][{index}]")
        if "default_level_sessions" in security:
            for index, session in enumerate(_values(security["default_level_sessions"])):
                _validate_session_id(session, f"security.default_level_sessions[{index}]")

    nrc = raw.get("nrc")
    if isinstance(nrc, Mapping) and isinstance(nrc.get("illegal_subfunction"), Mapping):
        for service, code in nrc["illegal_subfunction"].items():
            _validate_byte(service, "nrc.illegal_subfunction service")
            _validate_byte(code, f"nrc.illegal_subfunction[{service!r}]")

    lint = raw.get("lint")
    if isinstance(lint, Mapping) and "enabled_rules" in lint:
        rules = lint["enabled_rules"]
        if not isinstance(rules, Sequence) or isinstance(rules, (str, bytes)):
            raise ValueError("项目配置 lint.enabled_rules 必须是数组")
        unknown = {
            str(rule).strip().upper() for rule in rules
            if str(rule).strip().upper() not in {"R1", "R2", "R3", "R4", "R5"}
        }
        if unknown:
            raise ValueError("项目配置 lint.enabled_rules 含未知规则: " + ", ".join(sorted(unknown)))

    generation = raw.get("generation")
    if isinstance(generation, Mapping):
        for key in (
            "session_targets", "session_sources", "read_sessions", "security_sessions",
            "tester_present_sessions", "reset_sessions", "security_access_subfunctions",
        ):
            if key in generation:
                for index, value in enumerate(_values(generation[key])):
                    if key in {"session_targets", "session_sources", "read_sessions",
                               "security_sessions", "tester_present_sessions", "reset_sessions"}:
                        _validate_session_id(value, f"generation.{key}[{index}]")
                    else:
                        _validate_byte(value, f"generation.{key}[{index}]")
        if "sessions" in generation:
            for index, value in enumerate(_values(generation["sessions"])):
                _validate_session_id(value, f"generation.sessions[{index}]")
        for key in ("s3_boundary_before_ms", "s3_boundary_after_ms"):
            if key in generation:
                _validate_nonnegative_int(generation[key], f"generation.{key}")
        if "max_write_dids" in generation:
            value = generation["max_write_dids"]
            if value is not None and str(value).strip().lower() not in {"", "none", "null", "all"}:
                _validate_nonnegative_int(value, "generation.max_write_dids")
        constants = generation.get("security_constant_dids")
        if isinstance(constants, Mapping):
            for levels, did in constants.items():
                if not canonical_hex_bytes(levels) or len(canonical_hex_bytes(levels)) % 2:
                    raise ValueError(f"项目配置 generation.security_constant_dids 键不是偶数个十六进制字节: {levels!r}")
                if not canonical_did(did):
                    raise ValueError(f"项目配置 generation.security_constant_dids DID 无效: {did!r}")


def _normalize(raw: Mapping[str, Any], *, custom: Mapping[str, Any] | None = None) -> dict[str, Any]:
    custom = custom or {}
    result = _deep_merge(DEFAULT_PROJECT_CONFIG, raw)
    transport = result.setdefault("transport", {})
    for key in ("physical_nad", "functional_nad"):
        transport[key] = parse_int(transport.get(key), DEFAULT_PROJECT_CONFIG["transport"][key])
    custom_sessions = custom.get("sessions") if isinstance(custom.get("sessions"), Mapping) else {}
    sessions = result.setdefault("sessions", {})
    supported = _int_list(sessions.get("supported"))
    if not supported:
        supported = list(DEFAULT_PROJECT_CONFIG["sessions"]["supported"])
    supported_set = set(supported)
    sessions["supported"] = supported
    names: dict[int, str] = {}
    if isinstance(sessions.get("names"), Mapping):
        for key, value in sessions["names"].items():
            session_id = parse_int(key)
            if session_id in supported_set and str(value).strip():
                names[session_id] = str(value).strip()
    for session_id in supported:
        names.setdefault(session_id, f"会话 0x{session_id:02X}")
    sessions["names"] = names
    if "supported" in custom_sessions and "allowed_transitions" not in custom_sessions:
        allowed = {session_id: list(supported) for session_id in supported}
    else:
        allowed = _session_map(sessions.get("allowed_transitions"), supported_set)
        if not allowed:
            allowed = {session_id: list(supported) for session_id in supported}
    sessions["allowed_transitions"] = allowed
    sessions["enforce_transition_matrix"] = bool(
        sessions.get("enforce_transition_matrix", True)
    )
    sessions["default"] = parse_int(sessions.get("default"), supported[0])
    if sessions["default"] not in supported_set:
        sessions["default"] = supported[0]
    sessions["transition_nrc"] = parse_int(sessions.get("transition_nrc"), 0x22)
    if "s3_required" in custom_sessions:
        s3_required = _int_list(sessions.get("s3_required"), allowed=supported_set)
    else:
        s3_required = [session_id for session_id in supported if session_id != sessions["default"]]
    sessions["s3_required"] = s3_required
    security = result.setdefault("security", {})
    level_map = {}
    if isinstance(security.get("level_to_sessions"), Mapping):
        for level, allowed_sessions in security["level_to_sessions"].items():
            level_id = parse_int(level)
            if level_id is not None:
                level_map[level_id] = _int_list(allowed_sessions, allowed=supported_set)
    security["level_to_sessions"] = level_map
    security["default_level_sessions"] = _int_list(
        security.get("default_level_sessions"), allowed=supported_set
    ) or [sessions["default"]]
    security["unlock_required_services"] = sorted({
        canonical_service(value)
        for value in _values(security.get("unlock_required_services"))
        if canonical_service(value)
    })
    nrc = result.setdefault("nrc", {})
    illegal = {}
    if isinstance(nrc.get("illegal_subfunction"), Mapping):
        for service, code in nrc["illegal_subfunction"].items():
            number = parse_int(code)
            if number is not None:
                illegal[canonical_service(service)] = number & 0xFF
    nrc["illegal_subfunction"] = illegal
    lint = result.setdefault("lint", {})
    lint["read_only_dids"] = sorted({
        did for did in (canonical_did(value) for value in _values(lint.get("read_only_dids"))) if did
    })
    lint["negative_keywords"] = [str(value) for value in _values(lint.get("negative_keywords")) if str(value)]
    lint["require_nrc_for_negative"] = bool(lint.get("require_nrc_for_negative", True))
    lint["require_session_for_security"] = bool(lint.get("require_session_for_security", True))
    if "enabled_rules" in lint:
        lint["enabled_rules"] = sorted({
            str(value).strip().upper() for value in _values(lint.get("enabled_rules"))
            if str(value).strip()
        })
    custom_generation = custom.get("generation") if isinstance(custom.get("generation"), Mapping) else {}
    generation = result.setdefault("generation", {})
    if "supported" in custom_sessions:
        # Changing the project's session set should be sufficient for the
        # common case. Only an explicitly supplied generation dimension keeps
        # its narrower selection; otherwise all session-based expansions use
        # the newly configured session set instead of filtered legacy IDs.
        for key in (
            "session_targets", "session_sources", "read_sessions", "security_sessions",
            "tester_present_sessions", "reset_sessions",
        ):
            if key not in custom_generation:
                generation[key] = list(supported)
    # ``generation.sessions`` is a convenient project-wide alias.
    if "sessions" in custom_generation:
        for key in (
            "session_targets", "session_sources", "read_sessions", "security_sessions",
            "tester_present_sessions", "reset_sessions",
        ):
            if key not in custom_generation:
                generation[key] = copy.deepcopy(custom_generation["sessions"])
    for key in (
        "session_targets", "session_sources", "read_sessions", "security_sessions",
        "tester_present_sessions", "reset_sessions", "security_access_subfunctions",
    ):
        generation[key] = _int_list(generation.get(key), allowed=supported_set if "session" in key and key != "security_access_subfunctions" else None)
    generation["session_probe_did"] = canonical_did(generation.get("session_probe_did")) or None
    generation["reset_probe_did"] = canonical_did(generation.get("reset_probe_did")) or None
    generation["unsupported_did"] = canonical_did(generation.get("unsupported_did")) or None
    generation["representative_write_did"] = canonical_did(generation.get("representative_write_did")) or None
    max_write = generation.get("max_write_dids")
    generation["max_write_dids"] = None if max_write is None or str(max_write).strip().lower() in {"", "none", "null", "all"} else parse_int(max_write)
    if generation["max_write_dids"] is not None and generation["max_write_dids"] < 0:
        generation["max_write_dids"] = None
    for key, default in (("s3_boundary_before_ms", 100), ("s3_boundary_after_ms", 100)):
        generation[key] = parse_int(generation.get(key), default)
    constants = {}
    if isinstance(generation.get("security_constant_dids"), Mapping):
        for levels, did in generation["security_constant_dids"].items():
            did_value = canonical_did(did)
            if did_value:
                levels_text = canonical_hex_bytes(levels)
                if levels_text:
                    constants[levels_text] = did_value
    generation["security_constant_dids"] = constants
    identity = result.setdefault("identity", {})
    identity["display_name"] = str(identity.get("display_name") or "").strip()
    identity["run_id_prefix"] = str(identity.get("run_id_prefix") or "").strip()
    identity["source_workbook"] = str(identity.get("source_workbook") or "").strip()
    identity["version_prefixes"] = [
        str(value) for value in _values(identity.get("version_prefixes")) if str(value).strip()
    ]
    result["schema_version"] = str(result.get("schema_version") or PROJECT_CONFIG_SCHEMA)
    return result
def load_project_config(source: str | os.PathLike[str] | Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Load and normalize a project configuration.
    ``source`` may be a JSON path, a mapping, or ``None``.  ``None`` 表示
    *未移植项目*，此时结构性默认值叠加「参考项目档」兜底；一旦提供了项目
    配置（路径或映射），**不再继承参考项目档**，项目身份完全以外部配置为准。
    Invalid files and malformed top-level values raise ``ValueError`` so CLI
    callers can report a useful parameter error instead of silently reverting
    to a different project.
    """
    if source is None or source == "":
        # 参考项目档独立成段、仅在未移植项目时读取（见文件头说明）。
        return _normalize(REFERENCE_PROJECT_PROFILE, custom={})
    if isinstance(source, Mapping):
        raw = dict(source)
        _validate_custom_config(raw)
        return _normalize(raw, custom=raw)
    path = os.fspath(source)
    if not os.path.isfile(path):
        raise ValueError(f"项目配置文件不存在: {path}")
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            raw = json.load(handle)
    except (OSError, ValueError) as exc:
        raise ValueError(f"项目配置文件读取失败: {path}: {exc}") from exc
    if not isinstance(raw, Mapping):
        raise ValueError("项目配置顶层必须是 JSON 对象")
    _validate_custom_config(raw)
    return _normalize(raw, custom=raw)


def project_identity(config: Mapping[str, Any] | str | None = None) -> dict[str, Any]:
    """统一取用项目身份，避免任何脚本再写项目字面量。

    返回 ``project`` / ``display_name`` / ``run_id_prefix`` /
    ``source_workbook`` / ``version_prefixes``。未配置的字段回退到中性值：
    展示名回退项目号，run_id 前缀回退 ``"UDS"``，版本前缀回退为空。
    """
    cfg = load_project_config(config)
    identity = cfg.get("identity")
    identity = identity if isinstance(identity, Mapping) else {}
    project = str(cfg.get("project") or "").strip()
    return {
        "project": project,
        "display_name": str(identity.get("display_name") or "").strip() or project,
        "run_id_prefix": str(identity.get("run_id_prefix") or "").strip() or "UDS",
        "source_workbook": str(identity.get("source_workbook") or "").strip(),
        "version_prefixes": [str(value) for value in _values(identity.get("version_prefixes")) if str(value).strip()],
    }


def short_version(value: Any, config: Mapping[str, Any] | str | None = None) -> str:
    """项目无关的短版本号：优先取 ``V<数字>`` 版本令牌，否则剥离项目前缀。"""
    text = str(value or "").strip()
    match = re.search(r"\bV\d+[\w.-]*\b", text, re.IGNORECASE)
    if match:
        return match.group(0)
    for prefix in project_identity(config)["version_prefixes"]:
        if prefix and text.startswith(prefix):
            return text[len(prefix):]
    return text
def session_ids(config: Mapping[str, Any] | None, key: str = "supported") -> list[int]:
    cfg = load_project_config(config)
    return list(cfg["sessions"].get(key) or cfg["sessions"]["supported"])
def session_name_map(config: Mapping[str, Any] | None) -> dict[int, str]:
    cfg = load_project_config(config)
    return dict(cfg["sessions"]["names"])
__all__ = [
    "DEFAULT_PROJECT_CONFIG",
    "PROJECT_CONFIG_SCHEMA",
    "REFERENCE_PROJECT_PROFILE",
    "canonical_did",
    "canonical_hex_bytes",
    "canonical_service",
    "load_project_config",
    "parse_int",
    "project_identity",
    "session_ids",
    "session_name_map",
    "short_version",
]
