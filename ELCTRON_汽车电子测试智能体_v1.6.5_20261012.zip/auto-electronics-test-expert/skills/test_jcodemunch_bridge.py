#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""jcodemunch_bridge 纯函数单元测试（不依赖守护进程 / jcodemunch 安装）。"""
from __future__ import annotations

import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from jcodemunch_bridge import (                                 # noqa: E402
    ALLOWED_TOOLS, BridgeError, parse_args, validate_request,
)


class TestParseArgs(unittest.TestCase):
    def test_tool_only(self):
        opts = parse_args(["menu"])
        self.assertEqual(opts["tool"], "menu")
        self.assertEqual(opts["arguments"], {})
        self.assertFalse(opts["daemon"])
        self.assertFalse(opts["stop"])

    def test_json_args(self):
        opts = parse_args(["order", "--json", '{"action":"list_repos"}'])
        self.assertEqual(opts["arguments"], {"action": "list_repos"})

    def test_json_invalid(self):
        with self.assertRaises(BridgeError):
            parse_args(["order", "--json", "{bad"])

    def test_json_not_object(self):
        with self.assertRaises(BridgeError):
            parse_args(["order", "--json", "[1,2]"])

    def test_kv_json_value(self):
        opts = parse_args(["order", "--arg", "count=3", "--arg", "name=abc"])
        self.assertEqual(opts["arguments"], {"count": 3, "name": "abc"})

    def test_kv_missing_equal(self):
        with self.assertRaises(BridgeError):
            parse_args(["menu", "--arg", "nokey"])

    def test_missing_tool_returns_empty(self):
        # tool 是可选位置参数：缺省时解析为空串，由 main() 报用法错误（退出码 1）
        opts = parse_args(["--json", "{}"])
        self.assertEqual(opts["tool"], "")


class TestValidateRequest(unittest.TestCase):
    def test_allowed_passthrough(self):
        for tool in sorted(ALLOWED_TOOLS):
            out = validate_request(tool, {})
            self.assertEqual(out["tool"], tool)

    def test_reject_unknown_tool(self):
        with self.assertRaises(BridgeError) as ctx:
            validate_request("invalidate_cache", {})
        self.assertIn("TOOL_NOT_WHITELISTED", str(ctx.exception))

    def test_reject_state_changing_tools(self):
        for tool in ("set_tool_tier", "index_repo", "delete-index"):
            with self.assertRaises(BridgeError):
                validate_request(tool, {})

    def test_reject_non_object_arguments(self):
        with self.assertRaises(BridgeError):
            validate_request("menu", ["not", "an", "object"])  # type: ignore[arg-type]

    def test_reject_oversized_arguments(self):
        with self.assertRaises(BridgeError):
            validate_request("order", {"blob": "x" * 25_000})

    def test_reject_secret_fields(self):
        with self.assertRaises(BridgeError):
            validate_request("order", {"authorization": "Bearer xyz"})


if __name__ == "__main__":
    unittest.main()
