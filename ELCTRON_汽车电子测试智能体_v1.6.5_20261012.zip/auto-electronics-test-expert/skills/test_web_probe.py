"""web_probe 单元测试（不启动浏览器，仅覆盖治理约束与参数解析）。"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import web_probe


class ValidateUrlTest(unittest.TestCase):
    def test_http_allowed(self):
        self.assertEqual(web_probe.validate_url("http://127.0.0.1:5173/"),
                         "http://127.0.0.1:5173/")

    def test_https_allowed(self):
        self.assertEqual(web_probe.validate_url("https://example.com/x"),
                         "https://example.com/x")

    def test_file_scheme_rejected(self):
        with self.assertRaises(ValueError):
            web_probe.validate_url("file:///C:/Windows/win.ini")

    def test_data_scheme_rejected(self):
        with self.assertRaises(ValueError):
            web_probe.validate_url("data:text/html,<h1>hi</h1>")

    def test_ftp_scheme_rejected(self):
        with self.assertRaises(ValueError):
            web_probe.validate_url("ftp://127.0.0.1/pub")

    def test_missing_host_rejected(self):
        with self.assertRaises(ValueError):
            web_probe.validate_url("http:///path/only")


class ParseArgsTest(unittest.TestCase):
    def test_screenshot_required_args(self):
        args = web_probe.parse_args(
            ["screenshot", "--url", "http://127.0.0.1:5173/", "--out", "a.png"])
        self.assertEqual(args.command, "screenshot")
        self.assertEqual(args.width, 1440)
        self.assertFalse(args.full_page)

    def test_text_defaults(self):
        args = web_probe.parse_args(["text", "--url", "http://127.0.0.1:3000/api/health"])
        self.assertEqual(args.command, "text")
        self.assertEqual(args.max_chars, 4000)

    def test_missing_subcommand_exits(self):
        with self.assertRaises(SystemExit):
            web_probe.parse_args([])


if __name__ == "__main__":
    unittest.main()
