# LIN 网络测试流程 v0.1

## 1. 目的

验证 LIN 总线上的网络通信、帧、信号、调度和节点行为。本文不定义 UDS 服务测试，不使用 UDS 请求/响应/NRC 作为 LIN 网络测试的默认断言。

## 2. 流程

```text
确认测试范围
  → 收集 LDF/LIN Matrix
  → 解析并生成 LIN 网络模型（lin_db.json）
  → 绑定 frame/signal/schedule
  → 调用 lin_case_matrix.py 生成 LIN 用例矩阵
  → 静态校验 LIN 范围
  → 确认硬件和注入能力
  → 执行并采集原始 LIN trace
  → 判定 PID/Checksum/Signal/Timing
  → 生成 LIN 专项报告
```

## 3. 用例分组

| 组别 | 验证内容 | 典型证据 |
|---|---|---|
| Frame | ID、PID、DLC、发布节点、响应存在性 | 原始帧、PID 计算结果 |
| Signal | 位偏移、长度、编码、初始值、范围 | 解码值、LDF 哈希 |
| Schedule | 周期、时隙、frame gap、jitter | 时间戳 trace、统计值 |
| Network management | 唤醒、休眠、节点上线/离线 | 总线状态、唤醒响应 |
| Node conformance | 节点属性、配置参数、主从关系 | LDF 对比结果 |
| Error injection | PID、Checksum、Break/Sync、丢帧、延迟 | 注入配置、实际 trace、结果 |

## 4. 与 UDS 的分流规则

- 只看到 LIN frame/signal/schedule/node/wakeup/sleep：走 LIN 网络测试。
- 出现诊断服务 SID、NRC、会话、SeedKey、DID/RID：转 UDS 测试。
- 出现 RequestDownload、TransferData、CheckMemory、镜像或刷写流程：转 SWDL 测试。
- 0x3C/0x3D 诊断帧只作为 LIN 传输承载观察对象；若要验证其中的 UDS 内容，必须转 UDS 测试。

## 5. 结果状态

- `PASS`：帧、信号、调度和证据均满足要求；
- `FAIL`：已执行且实际网络行为不满足要求；
- `BLOCKED`：缺 LDF、通道或必要配置，未执行；
- `NOT_SUPPORTED`：测试工具或硬件不支持目标错误注入；
- `NOT_EXECUTED`：已设计但尚未执行。
