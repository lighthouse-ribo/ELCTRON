# -*- coding: utf-8 -*-
"""LIN 用例矩阵生成器行为测试。"""

import unittest

from lin_case_matrix import build_lin_case_matrix


class TestLinCaseMatrix(unittest.TestCase):
    def setUp(self):
        self.lin_db = {
            "lin_protocol_version": "2.2A",
            "lin_speed_bps": 19200,
            "master": {"name": "Master", "time_base_ms": 5},
            "slaves": ["BBS"],
            "frames": [
                {
                    "name": "BbsStatus",
                    "frame_id": 0x10,
                    "frame_id_hex": "0x10",
                    "pid": 0x50,
                    "pid_hex": "0x50",
                    "frame_type": "unconditional",
                    "length": 4,
                    "publisher": "BBS",
                    "signals": [
                        {"name": "BuzzerState", "offset": 0},
                    ],
                },
                {
                    "name": "DiagRequest",
                    "frame_id": 0x3C,
                    "frame_id_hex": "0x3C",
                    "pid": 0x7D,
                    "pid_hex": "0x7D",
                    "frame_type": "diagnostic",
                    "length": 8,
                    "publisher": "Master",
                    "signals": [],
                },
            ],
            "signals": [
                {
                    "name": "BuzzerState",
                    "size": 2,
                    "initial_value": 0,
                    "publisher": "BBS",
                    "subscribers": ["Master"],
                }
            ],
            "schedule_tables": {
                "NormalTable": [
                    {"frame": "BbsStatus", "delay_ms": 10.0},
                    {"frame": "DiagRequest", "delay_ms": 20.0},
                ]
            },
        }

    def test_generates_frame_signal_and_schedule_cases(self):
        result = build_lin_case_matrix(self.lin_db)
        self.assertEqual(result["status"], "READY")
        self.assertEqual(result["summary"], {"frame": 1, "signal": 1, "schedule": 1})
        ids = [case["case_id"] for case in result["cases"]]
        self.assertTrue(any(case_id.startswith("LIN-FRAME-") for case_id in ids))
        self.assertTrue(any(case_id.startswith("LIN-SIGNAL-") for case_id in ids))
        self.assertTrue(any(case_id.startswith("LIN-SCHEDULE-") for case_id in ids))
        self.assertFalse(any("UDS" in str(case) or "NRC" in str(case) for case in result["cases"]))
        signal_case = next(case for case in result["cases"] if case["category"] == "signal")
        self.assertEqual(signal_case["source"]["signal_size"], 2)
        self.assertEqual(signal_case["source"]["subscribers"], ["Master"])

    def test_diagnostic_frames_are_excluded_and_reported(self):
        result = build_lin_case_matrix(self.lin_db)
        self.assertTrue(any("诊断帧" in warning for warning in result["warnings"]))
        self.assertFalse(any("DiagRequest" in case["title"] for case in result["cases"]))

    def test_missing_database_is_blocked_without_fake_cases(self):
        result = build_lin_case_matrix(None)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(result["cases"], [])
        self.assertTrue(any("lin_db" in warning for warning in result["warnings"]))

    def test_missing_schedule_is_degraded_not_fabricated(self):
        lin_db = dict(self.lin_db)
        lin_db["schedule_tables"] = {}
        result = build_lin_case_matrix(lin_db)
        self.assertEqual(result["status"], "DEGRADED")
        self.assertEqual(result["summary"]["schedule"], 0)
        self.assertTrue(any("调度" in warning for warning in result["warnings"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
