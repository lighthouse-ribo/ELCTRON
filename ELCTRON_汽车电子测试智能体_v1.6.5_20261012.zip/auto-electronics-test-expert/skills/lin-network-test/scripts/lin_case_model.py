# -*- coding: utf-8 -*-
"""LIN 网络测试用例模型；独立于 UDS/SWDL。"""

from __future__ import annotations

from typing import Any, Mapping, Sequence


LIN_CASE_PREFIXES = ("LIN-FRAME-", "LIN-SIGNAL-", "LIN-SCHEDULE-", "LIN-NM-", "LIN-FAULT-")
UDS_PREFIXES = ("UDS_", "SWDL-")


class LinCaseError(ValueError):
    """LIN 网络用例契约错误。"""


def build_lin_case_skeleton(category: str = "frame_signal_schedule") -> dict[str, Any]:
    """Build a fillable LIN network case without UDS service fields."""
    category = str(category or "frame_signal_schedule").strip().lower()
    prefix = {
        "frame_signal_schedule": "LIN-FRAME-BASE-001",
        "error_injection": "LIN-FAULT-BASE-001",
        "network_management": "LIN-NM-BASE-001",
    }.get(category, "LIN-FRAME-BASE-001")
    return {
        "schema_version": "lin-case/v0.1",
        "case_id": prefix,
        "title": "LIN network baseline test",
        "status": "PLANNED",
        "category": category,
        "bus": "LIN",
        "source": {"ldf_frame": None, "ldf_signal": None, "requirement_ids": []},
        "steps": [],
        "evidence_required": [
            "ldf_hash",
            "raw_lin_trace",
            "pid_and_checksum_result",
            "schedule_timing_metrics",
        ],
        "execution": {"verdict": "NOT_EXECUTED", "hardware": "PENDING"},
    }


def validate_lin_case(case: Mapping[str, Any] | None) -> dict[str, Any]:
    """Validate LIN scope and required evidence without parsing UDS payloads."""
    data = dict(case or {})
    errors: list[str] = []
    warnings: list[str] = []
    case_id = str(data.get("case_id") or "")
    if not case_id.startswith(LIN_CASE_PREFIXES):
        errors.append("case_id 必须使用 LIN- 前缀")
    if case_id.startswith(UDS_PREFIXES):
        errors.append("LIN 网络用例不得使用 UDS_ 或 SWDL- 前缀")
    if str(data.get("bus") or "").upper() != "LIN":
        errors.append("bus 必须为 LIN")
    if not data.get("schema_version"):
        errors.append("缺少 schema_version")
    source = data.get("source") if isinstance(data.get("source"), Mapping) else {}
    if not source.get("ldf_frame") and not source.get("ldf_signal"):
        warnings.append("尚未绑定 LDF frame/signal，当前只能作为架构骨架")
    evidence = data.get("evidence_required")
    required = {"ldf_hash", "raw_lin_trace", "pid_and_checksum_result"}
    if not isinstance(evidence, list) or not required.issubset(set(evidence)):
        errors.append("缺少 LIN 原始 trace、LDF 哈希或 PID/Checksum 证据要求")
    steps = data.get("steps")
    if isinstance(steps, list):
        for step in steps:
            if not isinstance(step, Mapping):
                errors.append("steps 中存在非对象元素")
                continue
            text = str(step)
            if any(token in text for token in ("0x10", "0x22", "0x27", "0x34", "NRC", "UDS")):
                errors.append("LIN 网络用例不得混入 UDS 服务/NRC 断言")
    else:
        errors.append("steps 必须为数组")
    execution = data.get("execution") if isinstance(data.get("execution"), Mapping) else {}
    if str(execution.get("verdict") or "").upper() == "PASS" and str(data.get("status") or "").upper() != "EXECUTED":
        errors.append("未执行 LIN 用例不能标记 PASS")
    return {
        "schema_version": "lin-case-review/v0.1",
        "valid": not errors,
        "status": "PASS" if not errors else "BLOCKED",
        "errors": errors,
        "warnings": warnings,
    }
