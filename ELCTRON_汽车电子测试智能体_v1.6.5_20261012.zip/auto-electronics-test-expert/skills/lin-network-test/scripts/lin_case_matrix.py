# -*- coding: utf-8 -*-
"""基于标准化 lin_db.json 生成 LIN 网络测试用例矩阵。

本模块只生成 LIN 网络层用例，不推导 UDS SID、NRC、DID、SeedKey 或刷写步骤。
输入来自既有 LDF 解析器的标准化输出；未提供完整网络模型时只返回 BLOCKED/DEGRADED，
不凭空生成具体帧、信号或调度断言。
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping


_DIAGNOSTIC_FRAME_TYPES = {"diagnostic", "diagnostic_master", "diagnostic_slave"}


def _stable_key(value: Any) -> str:
    """将输入对象转为稳定短键，避免用例 ID 因字典顺序漂移。"""
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha1(encoded).hexdigest()[:8].upper()


def _text(value: Any) -> str:
    return str(value or "").strip()


def _is_diagnostic(frame: Mapping[str, Any]) -> bool:
    frame_type = _text(frame.get("frame_type")).lower()
    name = _text(frame.get("name")).lower()
    return frame_type in _DIAGNOSTIC_FRAME_TYPES or name in {"diagnostic", "diagrequest", "diagresponse"}


def _base_case(case_id: str, title: str, category: str, source: Mapping[str, Any], steps: list[dict[str, Any]], evidence: list[str]) -> dict[str, Any]:
    return {
        "schema_version": "lin-case/v0.1",
        "case_id": case_id,
        "title": title,
        "status": "PLANNED",
        "category": category,
        "bus": "LIN",
        "source": dict(source),
        "steps": steps,
        "evidence_required": evidence,
        "execution": {"verdict": "NOT_EXECUTED", "hardware": "PENDING"},
    }


def _frame_case(frame: Mapping[str, Any]) -> dict[str, Any]:
    name = _text(frame.get("name")) or "unnamed_frame"
    frame_id = frame.get("frame_id")
    pid_hex = _text(frame.get("pid_hex")) or "PENDING"
    key = _stable_key({"name": name, "frame_id": frame_id, "pid": pid_hex})
    source = {
        "ldf_frame": name,
        "ldf_signal": None,
        "frame_id": frame_id,
        "frame_id_hex": _text(frame.get("frame_id_hex")),
        "pid_hex": pid_hex,
        "publisher": _text(frame.get("publisher")),
        "length": frame.get("length"),
        "frame_type": _text(frame.get("frame_type")),
        "requirement_ids": [],
    }
    return _base_case(
        f"LIN-FRAME-{key}",
        f"Validate LIN frame {name} PID, length and response",
        "frame",
        source,
        [
            {"step_id": "header-send", "operation": "send_header", "frame": name, "expected": "valid_pid"},
            {"step_id": "response-capture", "operation": "capture_response", "frame": name, "expected": "response_within_slot"},
            {"step_id": "checksum-check", "operation": "check_checksum", "frame": name, "expected": "checksum_valid"},
        ],
        ["ldf_hash", "raw_lin_trace", "pid_and_checksum_result"],
    )


def _signal_case(frame: Mapping[str, Any], signal: Mapping[str, Any], signal_model: Mapping[str, Any] | None = None) -> dict[str, Any]:
    frame_name = _text(frame.get("name")) or "unnamed_frame"
    signal_name = _text(signal.get("name")) or "unnamed_signal"
    model = signal_model if isinstance(signal_model, Mapping) else {}
    key = _stable_key({"frame": frame_name, "signal": signal_name, "offset": signal.get("offset")})
    source = {
        "ldf_frame": frame_name,
        "ldf_signal": signal_name,
        "frame_id": frame.get("frame_id"),
        "signal_offset": signal.get("offset"),
        "signal_size": model.get("size", signal.get("size")),
        "initial_value": model.get("initial_value", signal.get("initial_value")),
        "publisher": model.get("publisher") or signal.get("publisher") or frame.get("publisher"),
        "subscribers": model.get("subscribers", signal.get("subscribers", [])),
        "requirement_ids": [],
    }
    return _base_case(
        f"LIN-SIGNAL-{key}",
        f"Validate LIN signal {signal_name} in {frame_name}",
        "signal",
        source,
        [
            {"step_id": "frame-capture", "operation": "capture_response", "frame": frame_name, "expected": "response_present"},
            {"step_id": "signal-decode", "operation": "decode_signal", "frame": frame_name, "signal": signal_name, "expected": "value_matches_model"},
            {"step_id": "signal-routing", "operation": "check_publisher_subscriber", "signal": signal_name, "expected": "routing_matches_ldf"},
        ],
        ["ldf_hash", "raw_lin_trace", "decoded_signal_values"],
    )


def _schedule_case(table_name: str, entries: list[Any]) -> dict[str, Any]:
    normalized_entries = [entry for entry in entries if isinstance(entry, Mapping)]
    key = _stable_key({"table": table_name, "entries": normalized_entries})
    source = {
        "ldf_schedule": table_name,
        "schedule_entries": normalized_entries,
        "requirement_ids": [],
    }
    return _base_case(
        f"LIN-SCHEDULE-{key}",
        f"Validate LIN schedule {table_name} timing",
        "schedule",
        source,
        [
            {"step_id": "schedule-start", "operation": "start_schedule", "schedule": table_name, "expected": "schedule_active"},
            {"step_id": "slot-capture", "operation": "capture_schedule_trace", "schedule": table_name, "expected": "all_slots_observed"},
            {"step_id": "timing-check", "operation": "check_timing", "schedule": table_name, "expected": "period_and_jitter_within_limit"},
        ],
        ["ldf_hash", "raw_lin_trace", "schedule_timing_metrics"],
    )


def build_lin_case_matrix(lin_db: Mapping[str, Any] | None) -> dict[str, Any]:
    """从 lin_db.json 生成 LIN 帧/信号/调度用例矩阵。

    诊断帧会被明确排除并记录警告；这只表示它不属于本矩阵，
    不代表诊断功能不支持。诊断内容应由 UDS 技能接管。
    """
    if not isinstance(lin_db, Mapping):
        return {
            "schema_version": "lin-case-matrix/v0.1",
            "status": "BLOCKED",
            "cases": [],
            "summary": {"frame": 0, "signal": 0, "schedule": 0},
            "warnings": ["缺少 lin_db：请先上传 LDF，由 LDF 解析器生成标准化 lin_db.json"],
        }

    cases: list[dict[str, Any]] = []
    warnings: list[str] = []
    frames = lin_db.get("frames") if isinstance(lin_db.get("frames"), list) else []
    signal_models = {
        _text(signal.get("name")): signal
        for signal in (lin_db.get("signals") if isinstance(lin_db.get("signals"), list) else [])
        if isinstance(signal, Mapping) and _text(signal.get("name"))
    }
    normal_frames = []
    for frame in frames:
        if not isinstance(frame, Mapping):
            warnings.append("frames 中存在非对象元素，已跳过")
            continue
        if _is_diagnostic(frame):
            warnings.append(f"已排除诊断帧 {_text(frame.get('name')) or frame.get('frame_id_hex') or '?'}：UDS 内容转交 uds-diagnostic-test")
            continue
        normal_frames.append(frame)
        cases.append(_frame_case(frame))
        signals = frame.get("signals") if isinstance(frame.get("signals"), list) else []
        for signal in signals:
            if isinstance(signal, Mapping):
                cases.append(_signal_case(frame, signal, signal_models.get(_text(signal.get("name")))))
            else:
                warnings.append(f"帧 {_text(frame.get('name')) or '?'} 存在非对象信号，已跳过")

    schedules = lin_db.get("schedule_tables") if isinstance(lin_db.get("schedule_tables"), Mapping) else {}
    for table_name, entries in schedules.items():
        if isinstance(entries, list) and entries:
            cases.append(_schedule_case(str(table_name), entries))
        else:
            warnings.append(f"调度表 {table_name} 没有有效 slot，未生成虚假调度用例")

    if not normal_frames:
        warnings.append("未发现可用于 LIN 网络测试的非诊断帧")
    if not schedules:
        warnings.append("缺少调度表：帧/信号用例可生成，但调度测试保持待补")

    summary = {
        "frame": sum(1 for case in cases if case["category"] == "frame"),
        "signal": sum(1 for case in cases if case["category"] == "signal"),
        "schedule": sum(1 for case in cases if case["category"] == "schedule"),
    }
    status = "READY"
    if not normal_frames:
        status = "BLOCKED"
    elif not schedules:
        status = "DEGRADED"
    return {
        "schema_version": "lin-case-matrix/v0.1",
        "status": status,
        "cases": cases,
        "summary": summary,
        "warnings": warnings,
        "source": {
            "lin_protocol_version": lin_db.get("lin_protocol_version"),
            "lin_speed_bps": lin_db.get("lin_speed_bps"),
            "master": lin_db.get("master"),
            "slaves": lin_db.get("slaves", []),
        },
    }
