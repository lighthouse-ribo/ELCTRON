# -*- coding: utf-8 -*-
"""LIN 网络测试架构回归。"""

import unittest

from lin_case_model import build_lin_case_skeleton, validate_lin_case


class TestLinCaseModel(unittest.TestCase):
    def test_baseline_case_is_lin_only(self):
        case = build_lin_case_skeleton()
        result = validate_lin_case(case)
        self.assertTrue(result["valid"])
        self.assertEqual(case["bus"], "LIN")
        self.assertTrue(case["case_id"].startswith("LIN-"))
        self.assertFalse(any("UDS" in str(step) for step in case["steps"]))

    def test_uds_prefix_is_rejected(self):
        case = build_lin_case_skeleton()
        case["case_id"] = "UDS_0x22_TC_0001"
        result = validate_lin_case(case)
        self.assertFalse(result["valid"])
        self.assertTrue(any("LIN" in error for error in result["errors"]))

    def test_uds_service_or_nrc_in_lin_step_is_rejected(self):
        case = build_lin_case_skeleton()
        case["steps"] = [{"operation": "send", "service": "0x22", "expected": "NRC=0x31"}]
        result = validate_lin_case(case)
        self.assertFalse(result["valid"])
        self.assertTrue(any("UDS" in error for error in result["errors"]))

    def test_missing_ldf_is_warning_not_fake_ready_model(self):
        case = build_lin_case_skeleton("error_injection")
        result = validate_lin_case(case)
        self.assertTrue(result["valid"])
        self.assertTrue(result["warnings"])
        self.assertEqual(result["status"], "PASS")


if __name__ == "__main__":
    unittest.main(verbosity=2)
