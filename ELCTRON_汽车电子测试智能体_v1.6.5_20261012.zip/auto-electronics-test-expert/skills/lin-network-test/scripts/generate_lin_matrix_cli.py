# -*- coding: utf-8 -*-
"""解析 LDF 并生成 LIN 网络测试用例矩阵。"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
LDF_SCRIPT = HERE.parents[1] / "uds-diagnostic-test" / "scripts"
if str(LDF_SCRIPT) not in sys.path:
    sys.path.insert(0, str(LDF_SCRIPT))

from ldf_parser import parse_ldf  # noqa: E402
from lin_case_matrix import build_lin_case_matrix  # noqa: E402


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def generate_from_ldf(ldf_path: str | Path) -> dict[str, Any]:
    """解析一份 LDF 并生成带来源哈希的 LIN 用例矩阵。"""
    path = Path(ldf_path)
    if not path.is_file():
        raise FileNotFoundError(str(path))
    lin_db = parse_ldf(str(path))
    matrix = build_lin_case_matrix(lin_db)
    matrix["source"] = {
        **(matrix.get("source") or {}),
        "ldf_path": str(path),
        "ldf_sha256": _sha256(path),
        "lin_db_source_file": lin_db.get("source_file"),
    }
    matrix["ldf_warnings"] = lin_db.get("warnings", [])
    return matrix


def main() -> int:
    parser = argparse.ArgumentParser(description="LDF -> LIN network test case matrix")
    parser.add_argument("--ldf", action="append", required=True, help="LDF path; repeat for multiple independent clusters")
    parser.add_argument("--output", required=True, help="JSON output path")
    args = parser.parse_args()

    bundles = []
    for ldf in args.ldf:
        try:
            bundles.append(generate_from_ldf(ldf))
        except Exception as exc:
            parser.error(f"解析或生成失败: {ldf}: {exc}")

    output: dict[str, Any]
    if len(bundles) == 1:
        output = bundles[0]
    else:
        output = {
            "schema_version": "lin-case-matrix-bundle/v0.1",
            "status": "READY" if all(item["status"] == "READY" for item in bundles) else "DEGRADED",
            "bundles": bundles,
            "summary": {
                category: sum(item["summary"].get(category, 0) for item in bundles)
                for category in ("frame", "signal", "schedule")
            },
        }
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": output["status"], "output": str(output_path), "summary": output.get("summary")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
