---
name: lin-network-test
version: "0.1.0"
description: "独立 LIN 网络测试框架：基于 LDF 验证帧、信号、PID、校验和、调度、网络管理、节点一致性和错误注入；不把 UDS 服务测试混入默认流程。"
argument-hint: "提供 LDF、LIN Matrix 或描述需要验证的 LIN 网络行为"
---

# LIN 网络测试技能

## 定位

本技能只负责 **LIN 网络层和信号通信测试**，不负责 UDS 诊断服务测试、刷写测试或 0x27 安全访问测试。

### 与 UDS 的硬边界

| LIN 网络测试 | UDS / SWDL 测试 |
|---|---|
| LDF、帧 ID、PID、信号、校验和 | 0x10/0x11/0x22/0x27/0x34/0x36/0x37 |
| Master 调度表和时隙 | 诊断会话和服务响应 |
| Slave 响应、发布者/订阅者 | NRC、SeedKey、诊断负响应 |
| 网络管理、唤醒、休眠 | 软件刷写和 CheckMemory |
| Break/Sync/PID/Checksum 错误 | 诊断业务流程 |
| 信号编码、初始值、更新策略 | UDS-over-LIN 传输层 |

如果用户明确要求诊断帧 0x3C/0x3D、UDS 服务或刷写，必须转交 `uds-diagnostic-test`，不能由本技能自动扩展测试范围。

## 标准流程

```text
输入体检
  → LDF 解析
  → 网络模型确认
  → LIN 用例矩阵生成
  → 用例静态校验
  → 链路/硬件预检
  → LIN 帧执行与 trace 采集
  → 信号/时序/错误判定
  → LIN 专项报告
```

### 当前可直接生成的逻辑

后续上传 LDF 后，先调用既有 LDF 解析器生成标准化 `lin_db.json`，再由
`scripts/lin_case_matrix.py:build_lin_case_matrix(lin_db)` 生成独立矩阵：

- `LIN-FRAME-*`：帧 ID、PID、DLC、响应存在性、校验和；
- `LIN-SIGNAL-*`：信号位偏移、长度、初始值、发布/订阅和解码；
- `LIN-SCHEDULE-*`：调度表 slot、帧间隔和周期/抖动统计入口。

诊断帧会被排除并给出分流警告，不会被误生成成 UDS 网络用例。缺少 `lin_db` 时返回
`BLOCKED`；缺少调度表时返回 `DEGRADED`，不编造具体时序限值。当前生成入口不生成
UDS SID、NRC、DID、RID、SeedKey 或刷写步骤。

### 一键生成入口（CLI，LDF → 用例矩阵）

`scripts/generate_lin_matrix_cli.py` 是「LDF 直接出矩阵」的唯一命令行入口：
它串联 `ldf_parser.parse_ldf` 与 `lin_case_matrix.build_lin_case_matrix`，
并把 LDF 路径与 `sha256` 写进产物 `source`，保证用例可追溯到确切那一份 LDF。

```bash
# 单集群
python scripts/generate_lin_matrix_cli.py --ldf <cluster.ldf> --output lin_matrix.json
# 多集群（独立 LDF，产物为 bundle，status 取各集群最差值）
python scripts/generate_lin_matrix_cli.py --ldf a.ldf --ldf b.ldf --output lin_matrix.json
```

产物顶层：`schema_version / status / cases / summary / warnings / source / ldf_warnings`。

- `status`：`READY`（模型完整）／`DEGRADED`（缺调度表等，不编造时序）／`BLOCKED`（缺 `lin_db`）。
- `summary`：`frame` / `signal` / `schedule` 三类用例数。
- `warnings`：分流提示（如诊断帧 `MasterReq`/`SlaveResp` 已排除，UDS 内容交 uds-diagnostic-test），**不是错误**。
- `ldf_warnings`：LDF 本体解析告警；为空表示 LDF 干净解析。

**实测样例（BBS P519 V436 `GPAsystem_MAIN_694` / `BBS1LIN` / SPA3，2026-09-14）**：

```text
status=READY  summary={frame:10, signal:61, schedule:5}  ldf_warnings=[]
source: LIN 2.2 / 19200 bps / master=ZCLB(5ms 时基) / slaves=[BBS]
warnings: 已排除诊断帧 MasterReq、SlaveResp
```

即：一份 LDF 出 76 条用例（10 帧级 + 61 信号级 + 5 调度级），诊断帧自动分流不重复生成。

## 测试范围

1. **帧级**：Frame ID、PID 奇偶、DLC、发布节点、订阅节点、初始值。
2. **信号级**：位偏移、长度、编码、范围、初始值、更新周期、发布/订阅关系。
3. **调度级**：slot 周期、frame gap、jitter、sporadic/event-triggered frame 行为。
4. **网络管理**：唤醒、休眠、无活动恢复、节点上线/离线。
5. **节点一致性**：节点属性、NAD/配置参数（仅 LIN 网络定义，不执行 UDS 服务）。
6. **错误注入**：PID 奇偶、Classic/Enhanced checksum、Break/Sync、丢帧、延迟、调度扰动。硬件不支持注入时标记 `NOT_SUPPORTED`，不伪造 PASS。

## 输入资料

- P0：LDF 或 LIN Matrix；
- P1：测试对象版本、节点接线、波特率、硬件适配器；
- P2：时序要求、唤醒/休眠要求、错误注入能力；
- 可选：实测 trace、项目网络需求、节点一致性规范。

缺少 LDF/LIN Matrix 时，允许输出资料缺口报告，但禁止生成具体帧和信号断言。

## 输出物

- LIN 网络用例 JSON/Excel；
- 每条用例与 LDF frame/signal 的追溯；
- LIN 原始 trace 和时序统计；
- LIN 专项 HTML 报告；
- PASS / FAIL / BLOCKED / NOT_SUPPORTED / NOT_EXECUTED 状态；
- 与 UDS 报告分模块展示，但不共享 UDS 用例 ID。

## 复用边界

允许复用：`ldf_parser.py`、`lin_tp.py` 的底层计算、`timing_trace.py` 的采集结构、硬件预检、统一报告渲染器。

本技能对外入口：`scripts/generate_lin_matrix_cli.py`（LDF → LIN 用例矩阵一键生成，见「标准流程」）。

禁止复用为默认业务：`gen_case_scripts.py` 的 UDS 服务推导、`swdl_flow.py`、`seedkey_gen2.py`、UDS SID/NRC 期望生成。LIN 网络用例必须由本技能的 `lin_case_model.py` 生成。
