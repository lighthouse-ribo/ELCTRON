#!/usr/bin/env python3
"""web_probe — 只读网页探测工具（Playwright headless Chromium）。

用途：agent 对 aetex-web 等前端产物做自测闭环（截图/提取可见文本），
不再依赖人工截图反馈。

只读治理约束：
- 仅允许 http/https（拒绝 file://、data:、ftp: 等本地/伪协议）；
- 仅导航 + 截图 + 读文本，不填表单、不点击、不注入脚本。

子命令：
  screenshot --url URL --out PATH [--width W] [--height H] [--full-page] [--timeout-ms MS]
  text       --url URL [--max-chars N] [--timeout-ms MS]

退出码：0 成功；2 URL 不合法；3 导航/浏览器失败。
"""
from __future__ import annotations

import argparse
import json
import sys
from urllib.parse import urlparse

ALLOWED_SCHEMES = ("http", "https")


def validate_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in ALLOWED_SCHEMES:
        raise ValueError(f"仅允许 http/https，拒绝 {parsed.scheme or '(空)'}://")
    if not parsed.hostname:
        raise ValueError("URL 缺少主机名")
    return url


def _render(url: str, timeout_ms: int, width: int, height: int):
    """启动 headless Chromium 加载页面，返回 (browser, page)。调用方负责 close。"""
    from playwright.sync_api import sync_playwright

    pw = sync_playwright().start()
    browser = pw.chromium.launch(headless=True)
    page = browser.new_page(viewport={"width": width, "height": height})
    page.goto(url, timeout=timeout_ms, wait_until="load")
    page.wait_for_timeout(500)  # 等待首帧渲染稳定
    return pw, browser, page


def cmd_screenshot(url: str, out: str, width: int, height: int,
                   full_page: bool, timeout_ms: int) -> str:
    pw, browser, page = _render(url, timeout_ms, width, height)
    try:
        page.screenshot(path=out, full_page=full_page)
        title = page.title()
    finally:
        browser.close()
        pw.stop()
    return json.dumps({"url": url, "screenshot": out, "title": title}, ensure_ascii=False)


def cmd_text(url: str, max_chars: int, timeout_ms: int) -> str:
    pw, browser, page = _render(url, timeout_ms, 1440, 900)
    try:
        title = page.title()
        text = page.evaluate("() => document.body ? document.body.innerText : ''")
    finally:
        browser.close()
        pw.stop()
    return json.dumps({"url": url, "title": title,
                       "text": (text or "")[:max_chars]}, ensure_ascii=False)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="web_probe", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    shot = sub.add_parser("screenshot", help="页面截图（PNG）")
    shot.add_argument("--url", required=True)
    shot.add_argument("--out", required=True)
    shot.add_argument("--width", type=int, default=1440)
    shot.add_argument("--height", type=int, default=900)
    shot.add_argument("--full-page", action="store_true")
    shot.add_argument("--timeout-ms", type=int, default=30000)

    txt = sub.add_parser("text", help="提取页面可见文本")
    txt.add_argument("--url", required=True)
    txt.add_argument("--max-chars", type=int, default=4000)
    txt.add_argument("--timeout-ms", type=int, default=30000)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        url = validate_url(args.url)
    except ValueError as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    try:
        if args.command == "screenshot":
            print(cmd_screenshot(url, args.out, args.width, args.height,
                                 args.full_page, args.timeout_ms))
        else:
            print(cmd_text(url, args.max_chars, args.timeout_ms))
    except Exception as exc:  # playwright 导航失败等
        print(json.dumps({"error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False),
              file=sys.stderr)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
