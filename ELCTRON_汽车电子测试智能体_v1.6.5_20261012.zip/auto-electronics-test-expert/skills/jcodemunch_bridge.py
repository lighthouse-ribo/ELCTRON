#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""jCodeMunch 检索桥（只读工具面）。

为什么需要它
------------
ELCTRON runtime 的工具网关只放行注册表内的内部工具，没有外部 MCP 客户端；
而 jCodeMunch 的检索能力（order / route / menu / guide）只通过 MCP stdio
服务器暴露。本脚本是唯一的桥：把白名单内的 jCodeMunch 工具包装成
runtime 可调用的内部 CLI，不引入任何 MCP 客户端依赖（纯 stdlib）。

冷启动实测 19.2s（嵌入模型加载），逐调用 spawn 会拖垮交互 —— 因此用
「本机守护进程 + 短连接客户端」模式：

* 首次调用时自动 spawn 守护进程（--daemon），持有长活的 MCP 子进程；
* 后续调用毫秒级往返；MCP 子进程死亡时守护进程自动重建；
* 守护进程只绑 127.0.0.1，随机端口 + 随机 token（%TEMP%/aetex_jcm_bridge.json）。

安全边界
--------
* 工具白名单：announce_model / jcodemunch_guide / menu / route / order。
  order 允许索引动作——它只写 jCodeMunch 自身的缓存索引，不触碰用户产物；
* 不接受任意路径输出，不经过 shell，参数一律 JSON 数组传递；
* 超出白名单、token 不符、超时一律报错，不降级、不猜测。

用法
----
    python skills/jcodemunch_bridge.py menu
    python skills/jcodemunch_bridge.py order --json '{"action":"resolve_repo"}'
    python skills/jcodemunch_bridge.py route --arg task=查找 DID 读取实现
    python skills/jcodemunch_bridge.py --stop          # 停掉守护进程

退出码：0 成功；1 用法/校验错误；2 上游工具错误；3 传输层不可达。
"""
from __future__ import annotations

import argparse
import json
import os
import queue
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time

__all__ = [
    "ALLOWED_TOOLS", "DEFAULT_EXE", "STATE_FILE",
    "BridgeError", "McpSession", "parse_args", "validate_request",
    "client_request", "run_daemon",
]

#: 只放行的 jCodeMunch 工具。set_tool_tier 属表面治理配置，不对 agent 开放。
ALLOWED_TOOLS = frozenset({
    "announce_model", "jcodemunch_guide", "menu", "route", "order",
})

DEFAULT_EXE = os.environ.get("JCODEMUNCH_MCP_EXE") or os.path.join(
    os.path.expanduser("~"), ".workbuddy", "binaries", "python", "envs",
    "default", "Scripts", "jcodemunch-mcp.exe")

#: 守护进程状态文件（用户级，跨包重装稳定）
STATE_FILE = os.path.join(tempfile.gettempdir(), "aetex_jcm_bridge.json")

#: 守护进程冷启动上限（实测握手 19.2s，留余量）
DAEMON_BOOT_TIMEOUT = 75.0
CALL_TIMEOUT_DEFAULT = 120.0


class BridgeError(RuntimeError):
    """桥自身错误（白名单、状态文件、传输层）。"""


# --------------------------------------------------------------------------- #
# 参数解析与请求校验（纯函数，可单测）
# --------------------------------------------------------------------------- #
def parse_args(argv: list[str]) -> dict:
    """解析 CLI 参数 -> {tool, arguments, timeout, action, daemon, stop}。

    `--json` 接受完整 JSON 对象；`--arg k=v` 可重复，值尽量 JSON 解析。
    """
    ap = argparse.ArgumentParser(description="jCodeMunch 只读检索桥")
    ap.add_argument("tool", nargs="?", default="", help=("|".join(sorted(ALLOWED_TOOLS))))
    ap.add_argument("--json", dest="json_args", default="",
                    help="完整 JSON 对象字符串，作为工具参数")
    ap.add_argument("--arg", dest="kv", action="append", default=[],
                    help="key=value 形式的工具参数，可重复")
    ap.add_argument("--timeout", type=float, default=CALL_TIMEOUT_DEFAULT)
    ap.add_argument("--daemon", action="store_true", help="以守护进程模式运行")
    ap.add_argument("--stop", action="store_true", help="停掉正在运行的守护进程")
    ns = ap.parse_args(argv)

    arguments: dict = {}
    if ns.json_args.strip():
        try:
            loaded = json.loads(ns.json_args)
        except json.JSONDecodeError as exc:
            raise BridgeError(f"--json 不是合法 JSON：{exc}") from exc
        if not isinstance(loaded, dict):
            raise BridgeError("--json 必须是 JSON 对象")
        arguments.update(loaded)
    for pair in ns.kv:
        if "=" not in pair:
            raise BridgeError(f"--arg 需要 key=value 形式：{pair!r}")
        key, _, raw = pair.partition("=")
        try:
            arguments[key] = json.loads(raw)
        except json.JSONDecodeError:
            arguments[key] = raw

    return {"tool": ns.tool, "arguments": arguments, "timeout": ns.timeout,
            "daemon": ns.daemon, "stop": ns.stop}


def validate_request(tool: str, arguments: dict) -> dict:
    """校验工具名与参数形态。返回规范化后的 (tool, arguments) 数据。"""
    if tool not in ALLOWED_TOOLS:
        raise BridgeError(
            f"TOOL_NOT_WHITELISTED: {tool!r}；允许：{sorted(ALLOWED_TOOLS)}")
    if not isinstance(arguments, dict):
        raise BridgeError("arguments 必须是对象")
    encoded = json.dumps(arguments, ensure_ascii=False)
    if len(encoded) > 24_000:
        raise BridgeError("arguments 超过 24KB 上限")
    if any(k in encoded.lower() for k in ("authorization", "api_key", "apikey")):
        raise BridgeError("arguments 含敏感字段，拒绝转发")
    return {"tool": tool, "arguments": arguments}


# --------------------------------------------------------------------------- #
# MCP stdio 会话（守护进程内持有）
# --------------------------------------------------------------------------- #
class McpSession:
    """单个 jcodemunch-mcp 子进程的 stdio 会话；死亡自动重建。"""

    def __init__(self, exe: str = DEFAULT_EXE):
        self._exe = exe
        self._proc: subprocess.Popen | None = None
        self._lines: "queue.Queue[str]" = queue.Queue()
        self._id = 0
        self._lock = threading.Lock()

    def _start(self) -> None:
        if not os.path.isfile(self._exe):
            raise BridgeError(f"jcodemunch-mcp 可执行文件不存在：{self._exe}")
        self._proc = subprocess.Popen(
            [self._exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, encoding="utf-8", bufsize=1)
        self._lines = queue.Queue()
        threading.Thread(target=self._reader, daemon=True).start()
        self._id = 0
        self._rpc("initialize", {"protocolVersion": "2024-11-05", "capabilities": {},
                                 "clientInfo": {"name": "aetex-jcm-bridge", "version": "0"}},
                  timeout=DAEMON_BOOT_TIMEOUT)
        self._notify("notifications/initialized")

    def _reader(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        for line in self._proc.stdout:
            self._lines.put(line)
        self._lines.put("")                        # EOF 哨兵

    def _send(self, obj: dict) -> None:
        assert self._proc is not None and self._proc.stdin is not None
        try:
            self._proc.stdin.write(json.dumps(obj) + "\n")
            self._proc.stdin.flush()
        except (OSError, ValueError) as exc:
            raise BridgeError(f"MCP 进程写入失败：{exc}") from exc

    def _notify(self, method: str) -> None:
        self._send({"jsonrpc": "2.0", "method": method})

    def _rpc(self, method: str, params: dict, *, timeout: float) -> dict:
        self._id += 1
        rpc_id = self._id
        self._send({"jsonrpc": "2.0", "id": rpc_id, "method": method, "params": params})
        deadline = time.time() + timeout
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                raise BridgeError(f"MCP 响应超时（{timeout}s）：{method}")
            try:
                line = self._lines.get(timeout=remaining)
            except queue.Empty:
                continue
            if line == "":
                raise BridgeError("MCP 进程意外退出")
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue                           # 非JSON行（日志噪声）忽略
            if msg.get("id") == rpc_id:
                if "error" in msg:
                    raise BridgeError(f"MCP 错误：{msg['error']}")
                return msg.get("result", {})

    def alive(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def call(self, tool: str, arguments: dict, *, timeout: float) -> dict:
        with self._lock:
            if not self.alive():
                self._start()
            return self._rpc("tools/call",
                             {"name": tool, "arguments": arguments}, timeout=timeout)

    def close(self) -> None:
        if self._proc is not None and self._proc.poll() is None:
            try:
                self._proc.terminate()
            except OSError:
                pass
        self._proc = None


# --------------------------------------------------------------------------- #
# 守护进程
# --------------------------------------------------------------------------- #
def _spawn_daemon() -> None:
    """分离式启动本脚本的守护进程模式。"""
    flags = 0
    if os.name == "nt":
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(
            subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    log = open(os.path.join(tempfile.gettempdir(), "aetex_jcm_bridge.log"),
               "ab", buffering=0)
    subprocess.Popen([sys.executable, "-B", os.path.abspath(__file__), "--daemon"],
                     stdout=log, stderr=log, stdin=subprocess.DEVNULL,
                     creationflags=flags, close_fds=True)


def _read_state() -> dict | None:
    try:
        with open(STATE_FILE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None


def _state_is_live(state: dict | None) -> bool:
    """端口/token 完整且 TCP 可连通才算活（跨平台统一用探测连接验证）。"""
    if not state or not all(k in state for k in ("port", "token", "pid")):
        return False
    try:
        probe = socket.create_connection(("127.0.0.1", int(state["port"])), timeout=0.5)
        probe.close()
        return True
    except OSError:
        return False


def run_daemon(exe: str = DEFAULT_EXE) -> None:   # pragma: no cover - 网络循环
    """守护进程主循环：随机端口 + token，逐连接处理单个请求。"""
    session = McpSession(exe)
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(4)
    token = secrets.token_hex(16)
    state = {"port": srv.getsockname()[1], "token": token,
             "pid": os.getpid(), "started_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
    with open(STATE_FILE, "w", encoding="utf-8") as fh:
        json.dump(state, fh)

    def handle(conn: socket.socket) -> None:
        try:
            conn.settimeout(CALL_TIMEOUT_DEFAULT + 30)
            buf = b""
            while b"\n" not in buf:
                chunk = conn.recv(65536)
                if not chunk:
                    return
                buf += chunk
            req = json.loads(buf.decode("utf-8"))
            if req.get("token") != token:
                resp = {"ok": False, "error": "TOKEN_MISMATCH"}
            else:
                try:
                    checked = validate_request(req.get("tool", ""),
                                               req.get("arguments") or {})
                    result = session.call(checked["tool"], checked["arguments"],
                                          timeout=CALL_TIMEOUT_DEFAULT)
                    resp = {"ok": True, "tool": checked["tool"], "result": result}
                except BridgeError as exc:
                    resp = {"ok": False, "error": str(exc)}
                except Exception as exc:            # noqa: BLE001 - 守护进程不能死
                    resp = {"ok": False, "error": f"BRIDGE_INTERNAL: {exc}"}
            conn.sendall(json.dumps(resp, ensure_ascii=False).encode("utf-8") + b"\n")
        except (OSError, json.JSONDecodeError):
            pass
        finally:
            conn.close()

    try:
        while True:
            conn, _ = srv.accept()
            threading.Thread(target=handle, args=(conn,), daemon=True).start()
    finally:
        session.close()


def _stop_daemon() -> int:
    state = _read_state()
    if not state:
        return 0
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(state.get("pid")), "/F", "/T"],
                       capture_output=True)
    else:
        try:
            os.kill(state["pid"], 15)
        except OSError:
            pass
    try:
        os.remove(STATE_FILE)
    except OSError:
        pass
    return 0


# --------------------------------------------------------------------------- #
# 客户端
# --------------------------------------------------------------------------- #
def _talk_once(tool: str, arguments: dict, timeout: float) -> dict:
    state = _read_state()
    if not state:
        raise BridgeError("NO_DAEMON_STATE")
    sock = socket.create_connection(("127.0.0.1", int(state["port"])),
                                    timeout=timeout)
    try:
        payload = json.dumps({"token": state["token"], "tool": tool,
                              "arguments": arguments}, ensure_ascii=False)
        sock.sendall(payload.encode("utf-8") + b"\n")
        sock.settimeout(timeout)
        buf = b""
        while b"\n" not in buf:
            chunk = sock.recv(65536)
            if not chunk:
                raise BridgeError("DAEMON_CLOSED")
            buf += chunk
        return json.loads(buf.decode("utf-8"))
    finally:
        sock.close()


def client_request(tool: str, arguments: dict, *, timeout: float = CALL_TIMEOUT_DEFAULT,
                   exe: str = DEFAULT_EXE) -> dict:
    """客户端入口：确保守护进程存活后发起一次请求，返回响应 dict。"""
    validate_request(tool, arguments)
    deadline = time.time() + timeout
    last_err = ""
    while time.time() < deadline:
        try:
            return _talk_once(tool, arguments, timeout)
        except (OSError, json.JSONDecodeError, BridgeError) as exc:
            last_err = str(exc)
            time.sleep(0.3)
            if not _state_is_live(_read_state()):
                _spawn_daemon()
                boot_deadline = time.time() + DAEMON_BOOT_TIMEOUT
                while time.time() < boot_deadline:
                    if _state_is_live(_read_state()):
                        break
                    time.sleep(0.5)
                    # 连不上也可能是旧状态文件失效，直接重试整条链路
                    try:
                        return _talk_once(tool, arguments, timeout)
                    except (OSError, json.JSONDecodeError, BridgeError):
                        pass
                else:
                    raise BridgeError(
                        f"守护进程 {DAEMON_BOOT_TIMEOUT}s 内未就绪（冷启动约 20s）")
    raise BridgeError(f"请求失败（{timeout}s 内）：{last_err or 'unknown'}")


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main(argv: list[str]) -> int:
    opts = parse_args(argv)
    if opts["stop"]:
        return _stop_daemon()
    if opts["daemon"]:
        run_daemon()
        return 0
    if not opts["tool"]:
        print("缺少工具名。允许：" + ", ".join(sorted(ALLOWED_TOOLS)), file=sys.stderr)
        return 1
    try:
        resp = client_request(opts["tool"], opts["arguments"], timeout=opts["timeout"])
    except BridgeError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        return 3
    print(json.dumps(resp, ensure_ascii=False, indent=2))
    return 0 if resp.get("ok") else 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
