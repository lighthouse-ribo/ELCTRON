#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""设计期 ISO 14229 期望校验器。

该检查器只验证用例设计语义，不连接 ECU。它把最容易泄漏到实机阶段的
错误前移：抑制正响应位、S3 测量会话、0x10 会话跳转和负例 NRC。检查结果
以 JSON 保存，供 ``uds_runner project`` 作为生成前门禁使用。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable, Mapping

from gen_case_scripts import hex_tokens, request_payload, session_from_precondition
from project_config import load_project_config
from session_flow import allowed_transition, normalize_session, parse_session_target


def _load_cases(path: str | Path) -> list[dict[str, Any]]:
    with open(path, encoding="utf-8", errors="replace") as handle:
        data = json.load(handle)
    raw = data.get("cases", []) if isinstance(data, Mapping) else data
    return [dict(item) for item in (raw or []) if isinstance(item, Mapping)]


def _issue(case: Mapping[str, Any], rule: str, severity: str, message: str, source: str) -> dict:
    return {
        "case_id": str(case.get("case_id") or "?"),
        "rule": rule,
        "severity": severity,
        "message": message,
        "source": source,
    }


def _text(case: Mapping[str, Any], *fields: str) -> str:
    return " ".join(str(case.get(field) or "") for field in fields)


def _is_negative(case: Mapping[str, Any]) -> bool:
    text = _text(case, "test_point", "expected").lower()
    return "负" in text or "nrc" in text or "negative" in text


def _expected_nrcs(expected: Any) -> set[int]:
    text = str(expected or "")
    values = {int(value, 16) for value in re.findall(r"NRC\s*(?:=|:)?\s*0?x?([0-9A-Fa-f]{2})", text, re.I)}
    for line in text.splitlines():
        tokens = hex_tokens(line) or []
        for index in range(len(tokens) - 2):
            if tokens[index] == 0x7F:
                values.add(tokens[index + 2])
    return values


def _mentions_suppress(case: Mapping[str, Any]) -> bool:
    text = _text(case, "test_point", "expected", "procedure").lower()
    return any(token in text for token in (
        "抑制正响应", "suppressposrsp", "suppress positive", "suppress response",
        "不发送正响应", "no positive response",
    ))


def _mentions_no_response(case: Mapping[str, Any]) -> bool:
    text = _text(case, "test_point", "expected").lower()
    return any(token in text for token in ("不应答", "无应答", "no response"))


def _mentions_s3(case: Mapping[str, Any]) -> bool:
    text = _text(case, "test_point", "expected", "procedure").lower()
    return bool(re.search(r"\bs3(?:server)?\b|s3超时|s3 边界|s3 回退|s3 timeout", text))


def _check_case(case: Mapping[str, Any], bus: str, nad: int,
                project_config: Mapping[str, Any] | str | None = None) -> list[dict]:
    config = load_project_config(project_config)
    case_id = str(case.get("case_id") or "?")
    issues: list[dict] = []
    payload, status, reason = request_payload(case.get("procedure", ""), bus, nad, service_hint=None)
    if payload is None:
        issues.append(_issue(case, "ISO-PAYLOAD-001", "WARN", f"无法解析请求 payload：{reason}", "procedure"))
        return issues

    sid = int(payload[0]) if payload else None
    sub = int(payload[1]) if len(payload) >= 2 else None
    expected = str(case.get("expected") or "")

    # ISO 14229 suppressPosRspMsgIndicationBit：只能出现在支持子功能的请求，
    # 且设计期望必须明确“不等待肯定响应/验证其它证据”。
    # 仅对真正带 sub-function 参数的服务检查 bit7。0x22/0x2E/0x2F
    # 的第一个参数是 DID 高字节，不能把 F1xx 误识别为 suppress 位；
    # 0x14 的第一个参数也是 groupOfDTC，不是 sub-function。
    subfunction_services = {
        0x10, 0x11, 0x19, 0x27, 0x28, 0x2A, 0x2C, 0x31, 0x3E,
        0x83, 0x85, 0x86, 0x87,
    }
    if sub is not None and sub & 0x80 and sid in subfunction_services:
        if not (_mentions_suppress(case) or _mentions_no_response(case)):
            issues.append(_issue(case, "ISO-SUPPRESS-001", "ERROR",
                                 "请求设置 suppressPosRspMsgIndicationBit=1，但 expected 未声明抑制正响应语义",
                                 "procedure/expected"))
    if _mentions_suppress(case) and not (sub is not None and sub & 0x80):
        issues.append(_issue(case, "ISO-SUPPRESS-002", "ERROR",
                             "expected 声明抑制正响应，但请求子功能未设置 bit7=1",
                             "procedure/expected"))

    # S3 是扩展/编程会话的会话保持定时器。默认会话中的 S3 测量通常是
    # 设计误写，必须在实机前打回；若有项目特例应在用例中显式改写规则。
    if _mentions_s3(case):
        session = session_from_precondition(case.get("precondition"), config)
        session_id = normalize_session(session, config)
        if session_id not in set(config["sessions"].get("s3_required", ())):
            issues.append(_issue(case, "ISO-S3-001", "ERROR",
                                 "S3 测量/边界用例未处于项目配置的 S3 会话；"
                                 "请明确配置允许的 S3 会话和进入路径",
                                 "precondition/test_point/expected"))

    # 负例必须有可执行的 NRC 断言，避免实机只记录“负响应”而无法判定。
    if _is_negative(case) and not _expected_nrcs(expected):
        issues.append(_issue(case, "ISO-NRC-001", "ERROR",
                             "负向用例未声明具体 NRC（例如 NRC=0x12/0x13/0x22）",
                             "expected"))

    # 0x10 的源→目标跳转必须遵循项目会话模型；当前项目模型禁止编程→扩展。
    if sid == 0x10 and len(payload) >= 2:
        source = normalize_session(
            session_from_precondition(case.get("precondition"), config), config
        )
        target = parse_session_target(payload, config)
        if source is not None and target is not None:
            permitted = allowed_transition(source, target, config)
            transition_nrc = int(config["sessions"]["transition_nrc"])
            if permitted is False:
                if not _is_negative(case) or transition_nrc not in _expected_nrcs(expected):
                    issues.append(_issue(case, "ISO-SESSION-001", "ERROR",
                                         "禁止的 0x10 会话跳转必须设计为负例并期望"
                                         f" NRC=0x{transition_nrc:02X}",
                                         "precondition/procedure/expected"))
            elif _is_negative(case) and transition_nrc in _expected_nrcs(expected):
                issues.append(_issue(case, "ISO-SESSION-002", "ERROR",
                                     "允许的 0x10 会话跳转不应期望"
                                     f" NRC=0x{transition_nrc:02X}",
                                     "precondition/procedure/expected"))

    return issues


def check_cases(cases: Iterable[Mapping[str, Any]], bus: str = "lin", nad: int = 0x51,
                project_config: Mapping[str, Any] | str | None = None) -> dict:
    """校验 cases 并返回稳定的机器可读结果。"""
    issues: list[dict] = []
    count = 0
    for case in cases:
        count += 1
        issues.extend(_check_case(case, bus, nad, project_config))
    errors = [item for item in issues if item["severity"] == "ERROR"]
    warnings = [item for item in issues if item["severity"] == "WARN"]
    return {
        "schema_version": 1,
        "status": "FAIL" if errors else "PASS",
        "case_count": count,
        "error_count": len(errors),
        "warning_count": len(warnings),
        "issues": issues,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ISO 14229 设计期望校验器")
    parser.add_argument("--cases", "-c", required=True, help="case-schema JSON")
    parser.add_argument("--bus", choices=("lin", "can"), default="lin")
    parser.add_argument("--nad", type=lambda value: int(value, 0), default=0x51)
    parser.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    parser.add_argument("--out", "-o", default="", help="校验 JSON 输出路径")
    args = parser.parse_args(argv)
    try:
        report = check_cases(
            _load_cases(args.cases), args.bus, args.nad,
            args.project_config or None,
        )
    except (OSError, ValueError, TypeError) as exc:
        print(f"[ERROR] 项目配置读取失败: {exc}")
        return 2
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(rendered + "\n", encoding="utf-8")
    print(f"[{'OK' if report['status'] == 'PASS' else 'ERROR'}] ISO 14229 期望校验: "
          f"cases={report['case_count']} errors={report['error_count']} warnings={report['warning_count']}")
    if args.out:
        print(f"[INFO] 校验报告: {args.out}")
    for item in report["issues"]:
        print(f"[{item['severity']}] {item['case_id']} {item['rule']}: {item['message']}")
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())
