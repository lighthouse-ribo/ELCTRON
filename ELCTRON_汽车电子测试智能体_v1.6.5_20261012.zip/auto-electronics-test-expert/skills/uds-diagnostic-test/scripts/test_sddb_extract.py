#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SDDB 前置矩阵抽取回归测试。"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))

from sddb_extract import build_service_prereq, extract_control_routines


class TestSddbExtract(unittest.TestCase):
    def test_extracts_two_step_routine_and_explicit_payload(self):
        rows = [
            ["RID", "Control Type", "Request", "Condition", "Security Level", "Name"],
            ["0206", "01 StartRoutine", "Request: 4 bytes", "Extended Session", "Level1", "Check"],
            ["", "03 RequestResult", "", "Extended Session", "Level1", ""],
        ]
        routines = extract_control_routines(rows, "survey.xlsx")
        self.assertEqual(routines["0206"]["control_types"], ["01", "03"])
        self.assertTrue(routines["0206"]["two_step"])
        self.assertEqual(routines["0206"]["request_parameter_length"], 4)
        self.assertTrue(routines["0206"]["requires_start_data"])
        self.assertIsNone(routines["0206"]["start_payload"])

    def test_matrix_contains_lin_pci_rules_and_service_objects(self):
        result = build_service_prereq({"dids": [], "io_controls": []}, {"0206": {"two_step": True}})
        self.assertEqual(result["schema_version"], 1)
        self.assertIn("pci_rules", result)
        self.assertIn("0x31", result["services"])
        self.assertIn("0206", result["services"]["0x31"]["objects"])


if __name__ == "__main__":
    unittest.main()
