#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""高实时时序采集与分析（采集-后处理模式）
=========================================================================
背景：通过上位机/COM 逐条「请求-等待-测量」会混入 PC 侧往返延迟，P2=50ms
这类高实时指标测不准。本脚本改为：一次性连续采集总线帧轨迹（含单调时间戳），
再离线分析帧隙 / P2 / P2*（含 0x78 pending）/ 0x37 延迟。

用法:
  # LIN（F1L1，需 F1L1_XCWRAPPER_DIR 指向 xcdev_wrapper.py）
  python timing_trace.py --bus lin --duration 10 --out timing_report.md
  # CAN（Vector）
  python timing_trace.py --bus can --channel 0 --tx-id 0x7E0 --rx-id 0x7E8 --bitrate 19200 --duration 10 [--serial X]

计时：time.perf_counter + timeBeginPeriod(1)（毫秒级，采集期间不要开上位机/COM）
"""

import argparse
import json
import os
import sys
import time

from win_timer import set_timer_resolution as _set_timer_resolution


def capture_can(channel, tx_id, rx_id, bitrate, serial, duration):
    """Vector 路线：连续采集 CAN 帧（含 perf_counter 时间戳）"""
    import can
    channel_num = int(channel) if str(channel).lstrip("-").isdigit() else channel
    kwargs = dict(interface="vector", channel=channel_num, bitrate=bitrate,
                  app_name="UDS-Timing-Trace", receive_own_messages=True)
    if serial:
        kwargs["serial"] = serial
    bus = can.interface.Bus(**kwargs)
    trace = []
    deadline = time.perf_counter() + duration
    while time.perf_counter() < deadline:
        msg = bus.recv(timeout=max(0.05, deadline - time.perf_counter()))
        t = time.perf_counter()
        if msg is not None:
            direction = "TX" if not msg.is_rx else "RX"
            trace.append((t, direction, msg.arbitration_id, list(msg.data)))
    bus.shutdown()
    return trace


def analyze_can(trace, tx_id, rx_id, window_ms=500):
    """CAN 轨迹分析：帧隙（TX 报文间隔）+ P2（请求→首个应答）"""
    tx = [e for e in trace if e[1] == "TX" and e[2] == tx_id]
    rx = [e for e in trace if e[1] == "RX" and e[2] == rx_id]
    slot = [round((tx[i][0] - tx[i - 1][0]) * 1000, 3) for i in range(1, len(tx))]
    p2 = []
    for i, (t, _d, _i, data) in enumerate(tx):
        if not data or (data[0] & 0xF0) != 0x00:  # 只看单帧请求（含 0x3E/0x22 等）
            continue
        next_t = tx[i + 1][0] if i + 1 < len(tx) else t + window_ms / 1000.0
        hits = [rt for rt, _d2, _i2, _r in rx if t <= rt < next_t]
        if hits:
            p2.append(round((hits[0] - t) * 1000, 3))
    stats = {
        "bus": "can",
        "duration_s": round(trace[-1][0] - trace[0][0], 3) if len(trace) >= 2 else 0.0,
        "total_frames": len(trace),
        "frame_slot_ms": {"min": min(slot), "avg": round(sum(slot) / len(slot), 3), "max": max(slot)} if slot else None,
        "p2_ms": p2,
        "warnings": [],
    }
    if slot and max(slot) - min(slot) > 5:
        stats["warnings"].append(f"帧隙抖动 >5ms（{min(slot)}~{max(slot)}ms）")
    return stats


def render_md(stats, out_path):
    L = ["# 高实时时序测量报告（采集-后处理）\n"]
    L.append(f"- 总线: {stats.get('bus', 'lin')} ｜ 采集时长: {stats['duration_s']}s ｜ 帧数: {stats['total_frames']}")
    L.append("")
    fs = stats.get("frame_slot_ms")
    L.append("## 帧隙")
    L.append(f"- min={fs['min']}ms ｜ avg={fs['avg']}ms ｜ max={fs['max']}ms" if fs else "- 无周期性主帧")
    L.append("")
    p2 = stats.get("p2_ms", [])
    L.append("## P2（请求 → 首个应答）")
    L.append(f"- 样本 {len(p2)} 个: min={min(p2) if p2 else '-'}ms ｜ avg={round(sum(p2)/len(p2),3) if p2 else '-'}ms ｜ max={max(p2) if p2 else '-'}ms")
    if "p2_star_ms" in stats:
        L.append(f"- P2*（含 0x78 pending）: {stats['p2_star_ms'][:10]}（pending {stats.get('pending_count', 0)} 次）")
    if stats.get("nrc37_gaps_ms"):
        L.append(f"- 0x37 延迟样本: {stats['nrc37_gaps_ms']}")
    if stats.get("warnings"):
        L.append("\n## 告警")
        for w in stats["warnings"]:
            L.append(f"- ⚠️ {w}")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


def main():
    ap = argparse.ArgumentParser(description="高实时时序采集与分析（采集-后处理）")
    ap.add_argument("--bus", choices=["lin", "can"], default="lin")
    ap.add_argument("--duration", type=float, default=10.0, help="采集时长（秒）")
    ap.add_argument("--out", "-o", help="Markdown 报告输出路径（可选）")
    ap.add_argument("--json", help="原始统计数据 JSON 输出路径（可选）")
    # LIN
    ap.add_argument("--nad", type=lambda s: int(s, 0), default=0x51)
    ap.add_argument("--brval", type=int, default=19200)
    ap.add_argument("--no-probe", action="store_true",
                    help="禁用主动请求注入（默认启用：周期发 0x3C 诊断帧并记录 0x3D 响应，离线算 P2/P2*/S3）")
    ap.add_argument("--probe-payloads", default="3E 00|22 F1 86",
                    help="注入的诊断请求 payload 列表，| 分隔（默认 '3E 00|22 F1 86'）")
    ap.add_argument("--probe-interval", type=float, default=1.0, help="注入间隔（秒，默认 1.0）")
    # CAN
    ap.add_argument("--channel", default="0")
    ap.add_argument("--tx-id", type=lambda s: int(s, 0), default=0x7E0)
    ap.add_argument("--rx-id", type=lambda s: int(s, 0), default=0x7E8)
    ap.add_argument("--bitrate", type=int, default=19200)
    ap.add_argument("--serial", default="")
    args = ap.parse_args()

    _set_timer_resolution(1)
    print(f"[INFO] 开始采集 {args.duration}s（{args.bus}），期间请勿打开上位机/COM 以免污染测量...")
    if args.bus == "lin":
        scripts_dir = os.path.dirname(os.path.abspath(__file__))
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        from f1l1_uds import F1L1UDS, analyze_trace, format_trace_report
        # 主动请求注入：周期发 0x3C 诊断帧（3E 00 / 22 F1 86）并记录 0x3D 响应，
        # 否则纯被动监听采不到"请求→响应"对，P2/P2*/S3 永远无数据（时序未执行根因）。
        probe_payloads = None
        if not args.no_probe:
            probe_payloads = [[int(b, 16) for b in seg.split()]
                              for seg in args.probe_payloads.split("|") if seg.strip()]
        uds = F1L1UDS(brval=args.brval)
        uds.open()
        try:
            trace = uds.capture_trace(duration=args.duration, nad=args.nad,
                                      probe_payloads=probe_payloads,
                                      probe_interval=args.probe_interval)
        finally:
            uds.close()
        stats = analyze_trace(trace, nad=args.nad)
        report = format_trace_report(stats)
    else:
        trace = capture_can(args.channel, args.tx_id, args.rx_id, args.bitrate, args.serial, args.duration)
        stats = analyze_can(trace, args.tx_id, args.rx_id)
        report = None

    print(f"[INFO] 采集完成：{len(trace)} 帧")
    print(json.dumps(stats, ensure_ascii=False, indent=2))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
    if args.out:
        if report is None:
            render_md(stats, args.out)
        else:
            with open(args.out, "w", encoding="utf-8") as f:
                f.write(report + "\n")
        print(f"[INFO] 报告: {args.out}")


if __name__ == "__main__":
    main()
