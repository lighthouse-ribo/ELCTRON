# -*- coding: utf-8 -*-
"""执行结果契约：保留 verdict，补充可审计的失败根因分类。"""

VALID_VERDICTS = frozenset({"PASS", "FAIL", "BLOCKED", "NA", "SKIP"})
FAILURE_CLASSES = frozenset({
    "NONE",
    "ECU_FAIL",
    "SCRIPT_ERROR",
    "INFRA_ERROR",
    "INPUT_INVALID",
    "RESULT_INVALID",
    "BLOCKED",
})


def infer_failure_class(verdict, explicit="", context="", fallback=""):
    """根据显式字段、执行上下文和旧结果推断统一根因分类。"""
    explicit = str(explicit or "").upper()
    if explicit:
        return explicit if explicit in FAILURE_CLASSES else "RESULT_INVALID"

    fallback = str(fallback or "").upper()
    if fallback in FAILURE_CLASSES:
        return fallback

    verdict = str(verdict or "").upper()
    if verdict in {"PASS", "NA", "SKIP"}:
        return "NONE"
    if verdict == "BLOCKED":
        return "BLOCKED"

    text = str(context or "")
    if any(token in text for token in ("脚本异常", "脚本崩溃", "导入失败")):
        return "SCRIPT_ERROR"
    if any(token in text for token in ("结果 JSON", "结果文件", "非法/历史", "结果状态")):
        return "RESULT_INVALID"
    if any(token in text for token in ("输入无效", "调查表解析", "LDF 解析", "SDDB")):
        return "INPUT_INVALID"
    if any(token in text for token in ("硬件", "Vector", "CAN 通道", "LIN 通道", "运行环境", "超时")):
        return "INFRA_ERROR"
    if verdict == "FAIL":
        return "ECU_FAIL"
    return "RESULT_INVALID"


def normalize_result(item, *, fallback_failure_class=""):
    """标准化一条结果，非法 verdict 不再伪装成 ECU_FAIL。"""
    result = dict(item or {})
    verdict = str(result.get("verdict") or "").upper()
    context = "%s %s" % (result.get("actual") or "", result.get("note") or "")
    if verdict not in VALID_VERDICTS:
        result["verdict"] = "FAIL"
        result["failure_class"] = "RESULT_INVALID"
        result["note"] = (str(result.get("note") or "")
                           + "；非法/历史结果状态已归一为 FAIL").strip("；")
    else:
        result["verdict"] = verdict
        result["failure_class"] = infer_failure_class(
            verdict,
            result.get("failure_class"),
            context,
            fallback_failure_class,
        )
    return result
