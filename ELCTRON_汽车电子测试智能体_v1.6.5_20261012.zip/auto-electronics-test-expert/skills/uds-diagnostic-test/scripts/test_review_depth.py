#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""review_depth.py（深度完备性核对）的离线回归测试。

与 script_review 的一致性审查正交：本模块回答"该写的深场景写了没有"，
补上"浅而一致全绿"的审查盲区（META_REVIEW 2026-09-02 反馈 P0-1）。

规则 v1（宁缺勿滥，避免对部分覆盖的交付误报）：
  R1  DID 正反成对：0x22/0x2E 出现正例的 DID 必须同时有负例；
  R2  0x31 例程：结果读取(03)正例必须有启动(01)来源（本 RID 的 01 用例
      或其它用例 PRE_ACTIONS 中的"先启动 RID XXXX"）；
  R3  0x10 会话矩阵：仅默认目标 / 单一非默认目标且无恢复(01) 时提示。
"""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import review_depth as rd  # noqa: E402


def _rec(case_id, payload, expect="pos", status=None, service=None, pre_actions=None):
    """构造一条审查记录（与 script_review 传给 coverage_gaps 的字段一致）。"""
    return {
        "case_id": case_id,
        "service": service,
        "expect": expect,
        "payload": payload,
        "status": status,
        "pre_actions": pre_actions or [],
    }


def _gap_texts(result):
    return [g["gap"] for g in result["gaps"]]


class TestDidPositiveNegativePairing(unittest.TestCase):
    """R1：DID 有正例必须有负例（防"每 DID 无负例"浅集全绿）"""

    def test_pos_without_neg_is_gap(self):
        records = [
            _rec("UDS_0x22_TC_POS", [0x22, 0xF1, 0x90], "pos", service="0x22"),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertTrue(any("F190" in t and "负例" in t for t in _gap_texts(gaps)), gaps)

    def test_pos_neg_pair_passes(self):
        records = [
            _rec("UDS_0x22_TC_POS", [0x22, 0xF1, 0x90], "pos", service="0x22"),
            _rec("UDS_0x22_TC_NEG", [0x22, 0xF1, 0x90], "neg", service="0x22"),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertFalse(any("负例" in t for t in _gap_texts(gaps)), gaps)

    def test_write_did_pair_checked_under_0x2E(self):
        records = [
            _rec("UDS_0x2E_TC_POS", [0x2E, 0xF1, 0x0A, 0x01], "pos", service="0x2E"),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertTrue(any("F10A" in t for t in _gap_texts(gaps)), gaps)

    def test_different_did_negative_does_not_satisfy_pair(self):
        records = [
            _rec("UDS_0x22_TC_POS", [0x22, 0xF1, 0x90], "pos", service="0x22"),
            # 负例打在另一个 DID 上，F190 仍然"有正无负"
            _rec("UDS_0x22_TC_NEG", [0x22, 0xF1, 0x91], "neg", service="0x22"),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertTrue(any("F190" in t for t in _gap_texts(gaps)), gaps)


class TestRoutineStartSource(unittest.TestCase):
    """R2：0x31 结果读取必须有启动来源（本 RID 01 用例或 PRE_ACTIONS）"""

    def test_result_without_start_is_gap(self):
        records = [
            _rec("UDS_0x31_TC_RESULT", [0x31, 0x03, 0x02, 0x06], "pos", service="0x31"),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertTrue(any("0206" in t and "启动" in t for t in _gap_texts(gaps)), gaps)

    def test_explicit_start_case_satisfies(self):
        records = [
            _rec("UDS_0x31_TC_START", [0x31, 0x01, 0x02, 0x06], "pos", service="0x31"),
            _rec("UDS_0x31_TC_RESULT", [0x31, 0x03, 0x02, 0x06], "pos", service="0x31"),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertFalse(any("0206" in t for t in _gap_texts(gaps)), gaps)

    def test_pre_action_start_satisfies(self):
        # "1. 先启动 RID 0206；2. 请求例程结果" → 生成器把启动写进 PRE_ACTIONS
        records = [
            _rec("UDS_0x31_TC_RESULT", [0x31, 0x03, 0x02, 0x06], "pos", service="0x31",
                 pre_actions=[[0x31, 0x01, 0x02, 0x06]]),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertFalse(any("0206" in t for t in _gap_texts(gaps)), gaps)

    def test_result_read_only_rid_with_own_stop_no_start_still_gap(self):
        records = [
            _rec("UDS_0x31_TC_STOP", [0x31, 0x02, 0x02, 0x06], "pos", service="0x31"),
            _rec("UDS_0x31_TC_RESULT", [0x31, 0x03, 0x02, 0x06], "pos", service="0x31"),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertTrue(any("0206" in t for t in _gap_texts(gaps)), gaps)


class TestSessionMatrix(unittest.TestCase):
    """R3：0x10 会话跳转不应只覆盖单一目标（缺恢复/来源×目标矩阵）"""

    def test_default_only_is_gap(self):
        records = [_rec("UDS_0x10_TC_01", [0x10, 0x01], "pos", service="0x10")]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertTrue(any("0x10" in t for t in _gap_texts(gaps)), gaps)

    def test_single_non_default_without_recovery_is_gap(self):
        records = [_rec("UDS_0x10_TC_03", [0x10, 0x03], "pos", service="0x10")]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertTrue(any("0x10" in t and "0x01" in t for t in _gap_texts(gaps)), gaps)

    def test_default_and_extended_passes(self):
        records = [
            _rec("UDS_0x10_TC_01", [0x10, 0x01], "pos", service="0x10"),
            _rec("UDS_0x10_TC_03", [0x10, 0x03], "pos", service="0x10"),
        ]
        result = rd.coverage_gaps(records)
        gaps = result
        self.assertFalse(any("0x10" in t for t in _gap_texts(gaps)), gaps)


class TestProfile(unittest.TestCase):
    """核对表：各服务已观测维度（供报告/前端展示，不进判定）"""

    def test_profile_lists_observed_dimensions(self):
        records = [
            _rec("UDS_0x22_TC_POS", [0x22, 0xF1, 0x90], "pos", service="0x22"),
            _rec("UDS_0x22_TC_NEG", [0x22, 0xF1, 0x90], "neg", service="0x22"),
            _rec("UDS_0x10_TC_03", [0x10, 0x03], "pos", service="0x10"),
        ]
        result = rd.coverage_gaps(records)
        profile = {p["service"]: p for p in result["profile"]}
        self.assertEqual(profile["0x22"]["objects"], ["F190"])
        self.assertEqual(profile["0x22"]["expect"], {"pos": 1, "neg": 1})
        self.assertIn("extended(03)", profile["0x10"]["target_sessions"])

    def test_empty_records_no_gaps(self):
        result = rd.coverage_gaps([])
        self.assertEqual(result["gaps"], [])
        self.assertEqual(result["profile"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
