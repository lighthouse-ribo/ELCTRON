"""流程契约离线测试；不连接 VickCAN，也不启动任何硬件。"""

import os
import sys
import unittest


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from flow_contract import (  # noqa: E402
    FLOW_REGISTRY,
    FlowKind,
    build_flow_context,
    get_flow_definition,
    normalize_flow,
    service_allowed,
)


class TestFlowContract(unittest.TestCase):
    def test_default_flow_keeps_existing_basic_uds(self):
        self.assertEqual(normalize_flow(None), FlowKind.BASIC_UDS)
        self.assertTrue(get_flow_definition(None).implemented)
        self.assertTrue(service_allowed(FlowKind.BASIC_UDS, 0x14))
        self.assertTrue(service_allowed(FlowKind.BASIC_UDS, 0x2F))

    def test_combined_flows_are_rejected(self):
        with self.assertRaises(ValueError):
            normalize_flow("basic_uds,swdl")

    def test_swdl_is_executable_only_after_runtime_gates(self):
        definition = FLOW_REGISTRY[FlowKind.SWDL]
        self.assertTrue(definition.implemented)
        self.assertTrue(definition.approval_required)
        self.assertIn("0x34", definition.allowed_services)
        self.assertIn("0x37", definition.allowed_services)
        self.assertNotIn("0x35", definition.allowed_services)
        self.assertTrue(service_allowed(FlowKind.SWDL, 0x36))

    def test_context_contains_single_flow_boundary(self):
        context = build_flow_context(
            FlowKind.SWDL,
            run_id="run-001",
            output_dir="out",
            project_id="BBS_P519_V436",
        )
        self.assertEqual(context["flow"], "swdl")
        self.assertTrue(context["implemented"])
        self.assertTrue(context["approval_required"])
        self.assertEqual(context["run_id"], "run-001")


if __name__ == "__main__":
    unittest.main()
