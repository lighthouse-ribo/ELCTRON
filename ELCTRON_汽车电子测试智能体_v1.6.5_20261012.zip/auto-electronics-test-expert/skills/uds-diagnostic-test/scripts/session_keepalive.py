# -*- coding: utf-8 -*-
"""UDS 会话保活辅助组件。

项目配置中列入 ``sessions.s3_required`` 的 0x10 会话会启动 ECU 的 S3 定时器。
单条用例如果在会话切换后还要做前置例程、数据处理或结果核验，必须使用
0x3E 80 维持会话。0x80 抑制 TesterPresent 正响应，因而无响应是预期结果。
该模块只负责保活策略和线程安全，不直接依赖任何总线
或硬件驱动；调用方通过 ``send_request(payload, timeout)`` 注入实际收发。
"""

from __future__ import annotations

import sys
import threading
from pathlib import Path
from typing import Callable, Optional

_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))

from project_config import load_project_config
from session_flow import (
    allowed_transition,
    normalize_session,
    parse_session_target,
    requires_s3,
)


SID_DIAGNOSTIC_SESSION_CONTROL = 0x10
SID_TESTER_PRESENT = 0x3E
KEEP_ALIVE_SUBFUNCTION = 0x80
SESSION_PROGRAMMING = 0x02
SESSION_EXTENDED = 0x03
# Compatibility constants only; keepalive decisions use project_config.
DEFAULT_INTERVAL_SECONDS = 2.0
DEFAULT_TIMEOUT_SECONDS = 3.0


def is_session_entry(payload, project_config=None) -> bool:
    """判断 payload 是否为进入项目配置的 S3 会话的 0x10 请求。"""
    target = parse_session_target(payload, project_config)
    return target is not None and requires_s3(target, project_config)


def is_positive_session_response(response, session: int) -> bool:
    """判断 0x50 <session> 正响应。"""
    try:
        return len(response) >= 2 and int(response[0]) == 0x50 and int(response[1]) == int(session)
    except (TypeError, ValueError, IndexError):
        return False


def is_positive_tester_present_response(response) -> bool:
    """兼容判断未抑制的 0x7E 00 正响应。"""
    try:
        return len(response) >= 2 and int(response[0]) == 0x7E and int(response[1]) == 0x00
    except (TypeError, ValueError, IndexError):
        return False


def is_suppressed_tester_present_result(response) -> bool:
    """判断 0x3E 80 的预期结果。

    发送抑制正响应子功能后，ECU 不应返回 0x7E；None 表示事务完成且无响应，
    是保活成功。收到任何报文都保留为异常，避免把错误响应吞掉。
    """
    return response is None


def should_keep_session_alive(
    session=None,
    payload=None,
    request_nad=None,
    physical_nad=None,
    project_config=None,
) -> bool:
    """决定本条用例是否需要 0x3E 保活。

    - 用例前置处于项目配置的 S3 会话：后续任何物理请求都要保持会话；
    - 当前主请求本身进入需要 S3 的会话：仅物理寻址下需要接着保活；
    - 功能寻址的会话切换不把额外 0x3E 注入用例，避免改变功能寻址语义。
    """
    config = load_project_config(project_config)
    if physical_nad is None:
        physical_nad = config["transport"]["physical_nad"]
    source = normalize_session(session, config)
    target = parse_session_target(payload, config)
    if target is not None:
        # 会话切换请求的寻址属性优先于生成器推导出的目标会话：功能寻址
        # 的会话切换不能被额外注入物理 3E 80 保活。
        if request_nad not in (None, ""):
            try:
                if int(request_nad) != int(physical_nad):
                    return False
            except (TypeError, ValueError):
                return False
        if source is not None and allowed_transition(source, target, config) is False:
            # 被 DCM 明确禁止的主请求不会进入目标会话，不能因为请求字节
            # 长得像会话切换就额外注入 0x3E，避免污染负例时序。
            return False
        return requires_s3(target, config)
    return requires_s3(session, config)


class SessionKeepAlive:
    """以固定周期发送 0x3E 80 的可停止保活器。

    ``lock`` 必须与业务请求共用，避免后台线程和主请求同时访问同一个
    F1L1/VickCAN 或 Vector 客户端。若业务请求长时间占用锁，保活器会在
    下一个周期继续尝试，不会并发插入另一笔 UDS 事务。
    """

    def __init__(
        self,
        send_request: Callable[[list, float], object],
        *,
        lock: Optional[threading.RLock] = None,
        interval: float = DEFAULT_INTERVAL_SECONDS,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ):
        self._send_request = send_request
        self._lock = lock
        self.interval = max(0.1, float(interval))
        self.timeout = max(0.1, float(timeout))
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_response = None
        self._last_error = ""

    @property
    def last_response(self):
        return self._last_response

    @property
    def last_error(self) -> str:
        return self._last_error

    def _call(self):
        if self._lock is None:
            return self._send_request([SID_TESTER_PRESENT, KEEP_ALIVE_SUBFUNCTION], self.timeout)
        with self._lock:
            return self._send_request([SID_TESTER_PRESENT, KEEP_ALIVE_SUBFUNCTION], self.timeout)

    def send_once(self):
        """同步发送一次保活并返回响应；失败原因保留在 ``last_error``。"""
        try:
            response = self._call()
        except Exception as exc:  # pragma: no cover - 由硬件适配器决定具体异常
            self._last_error = f"{type(exc).__name__}: {exc}"
            return None
        self._last_response = response
        if not is_suppressed_tester_present_result(response):
            self._last_error = "0x3E 80 收到非预期响应：应无响应"
        else:
            self._last_error = ""
        return response

    def start(self):
        """启动周期保活；调用方可先用 ``send_once`` 验证会话已建立。"""
        if self._thread is not None and self._thread.is_alive():
            return self
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="uds-3e-keepalive", daemon=True)
        self._thread.start()
        return self

    def _run(self):
        while not self._stop.wait(self.interval):
            self.send_once()

    def stop(self):
        """停止保活线程并返回最后一次错误文本（无错误返回空串）。"""
        self._stop.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=self.timeout + 0.5)
        return self._last_error


__all__ = [
    "DEFAULT_INTERVAL_SECONDS",
    "DEFAULT_TIMEOUT_SECONDS",
    "KEEP_ALIVE_SUBFUNCTION",
    "SessionKeepAlive",
    "is_positive_session_response",
    "is_positive_tester_present_response",
    "is_suppressed_tester_present_result",
    "is_session_entry",
    "should_keep_session_alive",
]
