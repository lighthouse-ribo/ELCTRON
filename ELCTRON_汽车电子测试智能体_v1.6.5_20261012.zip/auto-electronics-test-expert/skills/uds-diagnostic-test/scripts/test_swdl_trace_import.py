"""Offline regression tests for ASC/XCT SWDL trace import; no hardware required."""

import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from swdl_trace_import import TraceImportError, import_swdl_trace, parse_xct  # noqa: E402
from testsupport import WorkspaceTempDir  # noqa: E402


class TestSwdlTraceImport(unittest.TestCase):
    def setUp(self):
        self.workspace = WorkspaceTempDir("trace-import")

    def tearDown(self):
        self.workspace.cleanup()

    def _write(self, name, content, binary=False):
        path = os.path.join(self.workspace.name, name)
        mode = "wb" if binary else "w"
        with open(path, mode, encoding=None if binary else "utf-8") as handle:
            handle.write(content)
        return path

    def test_asc_reassembles_observed_swdl_sequence_without_claiming_pass(self):
        asc = """date Mon Sep 14 16:04:13.050 pm 2026
base hex  timestamps absolute
    0.000000 Li 3c Tx 8 51 02 10 02 ff ff ff ff checksum = 9e
    0.010000 Li 3d Rx 8 51 06 50 02 00 19 01 f4 checksum = 48
    0.020000 Li 3c Tx 8 51 02 27 01 ff ff ff ff checksum = 00
    0.030000 Li 3d Rx 8 51 03 67 01 00 ff ff ff checksum = 00
    0.040000 Li 3c Tx 8 51 06 34 00 44 00 00 10 00 checksum = 00
    0.050000 Li 3d Rx 8 51 04 74 20 00 10 ff ff ff checksum = 00
    0.060000 Li 3c Tx 8 51 03 36 01 aa ff ff ff checksum = 00
    0.070000 Li 3d Rx 8 51 02 76 01 ff ff ff ff checksum = 00
    0.080000 Li 3c Tx 8 51 01 37 ff ff ff ff ff checksum = 00
    0.090000 Li 3d Rx 8 51 01 77 ff ff ff ff ff checksum = 00
"""
        evidence = import_swdl_trace(self._write("run.asc", asc))
        self.assertEqual(evidence["frame_count"], 10)
        self.assertTrue(evidence["swdl"]["required_sequence_observed"])
        self.assertEqual(evidence["swdl"]["verdict"], "OBSERVED_ONLY")
        self.assertEqual(evidence["transactions"][2]["request"][:1], [0x34])

    def test_text_xct_columns_are_imported(self):
        xct = """0.000000,Tx,3C,8,51 02 10 02 FF FF FF FF
0.010000,Rx,3D,8,51 06 50 02 00 19 01 F4
"""
        frames = parse_xct(self._write("export.xct", xct))
        self.assertEqual([(frame.direction, frame.frame_id) for frame in frames], [("TX", 0x3C), ("RX", 0x3D)])

    def test_utf16_text_xct_is_not_mistaken_for_binary(self):
        xct = "0.000000\tTx\t3C\t8\t51 02 10 02 FF FF FF FF\n"
        path = self._write("export-utf16.xct", xct.encode("utf-16"), binary=True)
        frames = parse_xct(path)
        self.assertEqual(len(frames), 1)
        self.assertEqual(frames[0].data[:4], (0x51, 0x02, 0x10, 0x02))

    def test_binary_xct_fails_closed(self):
        path = self._write("raw.xct", b"\x00\x01\x02", binary=True)
        with self.assertRaisesRegex(TraceImportError, "二进制专有"):
            parse_xct(path)


if __name__ == "__main__":
    unittest.main()
