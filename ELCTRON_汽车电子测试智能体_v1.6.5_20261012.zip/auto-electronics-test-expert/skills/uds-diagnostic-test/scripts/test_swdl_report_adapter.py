# -*- coding: utf-8 -*-
"""SWDL 报告适配器回归。"""

import unittest

from swdl_report_adapter import swdl_report_to_results


class TestSwdlReportAdapter(unittest.TestCase):
    def test_blocked_plan_becomes_blocked_report_row(self):
        result = swdl_report_to_results({
            "flow": "swdl",
            "overall": "BLOCKED",
            "target_partition": "SBL",
            "steps": [],
            "blocked_reasons": ["缺少 0x27 可执行密钥材料"],
        })
        self.assertEqual(result["results"][0]["verdict"], "BLOCKED")
        self.assertIn("0x27", result["results"][0]["note"])
        self.assertEqual(result["extra"]["modules"][0]["id"], "swdl")
        self.assertEqual(result["extra"]["modules"][0]["status"], "blocked")

    def test_stage_status_and_evidence_are_preserved(self):
        result = swdl_report_to_results({
            "overall": "FAIL",
            "steps": [{
                "step_id": "check-memory",
                "service": "0x31/0x0212",
                "status": "FAIL",
                "reason": "NRC=0x72",
                "elapsed_ms": 21.5,
                "evidence": "trace.json",
            }],
        })
        row = result["results"][0]
        self.assertEqual(row["verdict"], "FAIL")
        self.assertEqual(row["evidence"], "trace.json")
        self.assertEqual(row["metrics"]["elapsed_ms"], 21.5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
