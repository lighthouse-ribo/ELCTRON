"""VickCAN/F1L1 UDS-over-LIN SWDL 下载流程。

该模块只实现软件下载（0x10/0x27/0x34/0x36/0x37/0x31/0x11）编排，
不把刷写步骤混入 Basic UDS。它支持 raw binary + manifest 的明确输入契约；
VBF/VSF 原文件必须先由受控工具解析成带地址的 segment，不能把文件头直接当
作 ECU 数据发送。

安全边界：
* 缺少镜像、地址、认证校验或 Gen2 真实密钥时，返回 BLOCKED；
* 未显式批准高风险写入时，只生成 BLOCKED 计划，不打开 VickCAN；
* 0x34 被 0x27 解锁保护，0x36/0x37 依赖活动下载，因此三者按依赖链一起阻断；
* 所有真实收发通过现有 F1L1UDS，不调用 COM/CANoe。
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


SCRIPT_DIR = Path(__file__).resolve().parent
_TRUSTED_RG_CANDIDATES = (
    Path(os.environ.get("CODEX_RG", "")),
    Path(r"C:\Users\80026384\AppData\Local\OpenAI\Codex\bin\9758fc89b2be71d3\rg.exe"),
    Path(r"C:\Users\80026384\AppData\Local\OpenAI\Codex\bin\53c73f34a40c42be\rg.exe"),
)


class SwdlBlocked(RuntimeError):
    """运行时硬件状态不满足 SWDL 前置，但不是通信/协议失败。"""


def _trusted_rg() -> str | None:
    configured = os.environ.get("CODEX_RG", "").strip()
    if configured and Path(configured).is_file():
        return configured
    found = shutil.which("rg")
    if found:
        return found
    for candidate in _TRUSTED_RG_CANDIDATES:
        if str(candidate) and candidate.is_file():
            return str(candidate)
    return None


def _read_bytes(path: str | os.PathLike[str]) -> bytes:
    """读取普通或 DLP 透明加密文件；DLP 文件走受信任 rg 明文视图。"""

    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(str(source))
    try:
        data = source.read_bytes()
        if data and not data.startswith(b"%TSD-Header"):
            return data
    except OSError:
        pass
    rg = _trusted_rg()
    if not rg:
        raise RuntimeError("普通进程无法读取文件，且未找到受信任 rg 明文通道")
    proc = subprocess.run(
        [rg, "-a", "--passthru", ".", str(source)],
        capture_output=True,
        check=False,
    )
    if proc.returncode not in (0, 1) or not proc.stdout:
        detail = proc.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"rg 明文读取失败: {source} {detail}")
    return proc.stdout


def _read_json(path: str | os.PathLike[str]) -> dict[str, Any]:
    raw = _read_bytes(path)
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"JSON 解析失败: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"JSON 根节点必须是对象: {path}")
    return value


def parse_int(value: Any, *, name: str, default: int | None = None) -> int | None:
    if value is None or str(value).strip() == "":
        return default
    if isinstance(value, bool):
        raise ValueError(f"{name} 不能是布尔值")
    try:
        return int(str(value).strip(), 0)
    except ValueError as exc:
        raise ValueError(f"{name} 不是合法整数: {value!r}") from exc


def _hex_key_bytes(value: Any, *, field_name: str) -> bytes:
    if isinstance(value, (list, tuple)):
        try:
            data = bytes(int(item, 16) if isinstance(item, str) else int(item) for item in value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{field_name} 不是合法字节数组") from exc
    else:
        text = str(value or "").replace("0x", "").replace("0X", "")
        text = "".join(text.split()).replace(",", "")
        try:
            data = bytes.fromhex(text)
        except ValueError as exc:
            raise ValueError(f"{field_name} 不是合法 hex") from exc
    if len(data) != 16:
        raise ValueError(f"{field_name} 必须是 16 字节，实际 {len(data)} 字节")
    return data


def security_key_status(key_file: str | os.PathLike[str] | None) -> tuple[bool, str]:
    """检查 Gen2 01/02 密钥是否真实可用，不输出密钥内容。"""

    if not key_file:
        return False, "未提供 0x27 Gen2 密钥 JSON"
    try:
        data = {str(k).lower(): v for k, v in _read_json(key_file).items()}
    except (OSError, ValueError, RuntimeError) as exc:
        return False, f"0x27 密钥文件不可用: {exc}"
    aliases = {
        "aes_cmac_key_0102": ("aes_cmac_key_0102", "cmac_0102", "key_cmac_0102"),
        "aes_ctr_key_0102": ("aes_ctr_key_0102", "ctr_0102", "key_ctr_0102"),
    }
    keys: dict[str, bytes] = {}
    for canonical, candidates in aliases.items():
        raw = next((data.get(candidate) for candidate in candidates if data.get(candidate)), None)
        if raw is None:
            return False, f"缺少等级 01/02 密钥字段: {canonical}"
        try:
            keys[canonical] = _hex_key_bytes(raw, field_name=canonical)
        except ValueError as exc:
            return False, str(exc)
    placeholders = [name for name, value in keys.items() if value == b"\xff" * 16]
    if placeholders:
        return False, f"密钥含全 0xFF 占位: {', '.join(placeholders)}"
    return True, "等级 01/02 Gen2 密钥已就绪"


@dataclass(frozen=True)
class SwdlSegment:
    path: str
    address: int
    data: bytes
    offset: int = 0

    @property
    def length(self) -> int:
        return len(self.data)

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.data).hexdigest()

    def manifest_view(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "address": f"0x{self.address:08X}",
            "length": self.length,
            "offset": self.offset,
            "sha256": self.sha256,
        }


@dataclass(frozen=True)
class SwdlEraseSegment:
    """一次 Flash Erase 的完整逻辑块范围。"""

    address: int
    length: int

    def manifest_view(self) -> dict[str, Any]:
        return {
            "address": f"0x{self.address:08X}",
            "length": self.length,
            "end_address": f"0x{self.address + self.length:08X}",
        }


@dataclass
class SwdlPlan:
    target_partition: str
    nad: int
    data_format_identifier: int
    address_length_format_identifier: int
    segments: list[SwdlSegment] = field(default_factory=list)
    image_path: str = ""
    manifest_path: str = ""
    key_file: str = ""
    key_ready: bool = False
    key_reason: str = ""
    authentication_ready: bool = False
    authentication_reason: str = ""
    signature_path: str = ""
    public_key_path: str = ""
    signature_ready: bool = False
    logical_block: str = ""
    erase_segments: list[SwdlEraseSegment] = field(default_factory=list)
    check_memory_payload: bytes = b""
    check_memory_attempts: int = 2
    activate_sbl: bool = False
    sbl_start_address: int | None = None
    blocked_reasons: list[str] = field(default_factory=list)

    @property
    def total_bytes(self) -> int:
        return sum(segment.length for segment in self.segments)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["segments"] = [segment.manifest_view() for segment in self.segments]
        data["erase_segments"] = [segment.manifest_view() for segment in self.erase_segments]
        data["check_memory_payload"] = [f"{item:02X}" for item in self.check_memory_payload]
        data["nad"] = f"0x{self.nad:02X}"
        data["data_format_identifier"] = f"0x{self.data_format_identifier:02X}"
        data["address_length_format_identifier"] = f"0x{self.address_length_format_identifier:02X}"
        data["total_bytes"] = self.total_bytes
        data["payload_sha256"] = hashlib.sha256(
            b"".join(segment.data for segment in self.segments)
        ).hexdigest() if self.segments else ""
        return data


def _resolve_segment_path(raw: Any, *, manifest_path: str) -> str:
    if not raw:
        return ""
    path = Path(str(raw))
    if not path.is_absolute() and manifest_path:
        path = Path(manifest_path).resolve().parent / path
    return str(path)


def _coerce_bytes(value: Any, *, field_name: str, manifest_path: str = "") -> bytes:
    """解析 manifest 中的 hex/list/file/base64 字节输入，不猜测业务数据。"""

    if isinstance(value, Mapping):
        if value.get("file") or value.get("path"):
            source = _resolve_segment_path(
                value.get("file", value.get("path")), manifest_path=manifest_path
            )
            return _read_bytes(source)
        if value.get("hex") is not None:
            value = value["hex"]
        elif value.get("base64") is not None:
            value = base64.b64decode(str(value["base64"]), validate=True)
        else:
            raise ValueError(f"{field_name} 缺少 file/path、hex 或 base64")
    if isinstance(value, bytes):
        return value
    if isinstance(value, (list, tuple)):
        try:
            return bytes(int(item, 16) if isinstance(item, str) else int(item) for item in value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{field_name} 不是合法字节数组") from exc
    text = str(value or "").strip()
    if not text:
        return b""
    compact = text.replace("0x", "").replace("0X", "")
    compact = "".join(compact.split()).replace(",", "")
    try:
        return bytes.fromhex(compact)
    except ValueError as exc:
        raise ValueError(f"{field_name} 不是合法 hex 字节串") from exc


def _read_signature(auth: Mapping[str, Any], *, manifest_path: str) -> tuple[bytes, str]:
    raw = auth.get("signature_file", auth.get("signature_path"))
    if raw:
        source = _resolve_segment_path(raw, manifest_path=manifest_path)
        signature = _read_bytes(source)
        return signature, source
    inline = auth.get("signature")
    if inline is None:
        return b"", ""
    encoding = str(auth.get("signature_encoding", "hex")).strip().lower()
    if encoding == "base64":
        try:
            return base64.b64decode(str(inline), validate=True), "<inline>"
        except (ValueError, base64.binascii.Error) as exc:
            raise ValueError("authentication.signature 不是合法 base64") from exc
    return _coerce_bytes(inline, field_name="authentication.signature"), "<inline>"


def _verify_rsa_pss(
    *,
    signed_payload: bytes,
    signature: bytes,
    public_key_data: bytes,
    salt_length: int | None = None,
) -> tuple[bool, str]:
    """执行 SWRS 要求的 RSA-4096/RSASSA-PSS/SHA-256 验签。"""

    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
    except ImportError as exc:
        return False, f"缺少 cryptography，无法执行 RSA-PSS 验签: {exc}"
    try:
        if b"BEGIN" in public_key_data:
            public_key = serialization.load_pem_public_key(public_key_data)
        else:
            public_key = serialization.load_der_public_key(public_key_data)
        key_size = getattr(public_key, "key_size", None)
        if key_size != 4096:
            return False, f"认证公钥必须是 RSA-4096，实际 key_size={key_size}"
        chosen_salt = hashes.SHA256().digest_size if salt_length is None else int(salt_length)
        public_key.verify(
            signature,
            signed_payload,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=chosen_salt,
            ),
            hashes.SHA256(),
        )
    except Exception as exc:
        return False, f"RSA-PSS/SHA-256 验签失败: {type(exc).__name__}"
    return True, "RSA-4096/RSASSA-PSS/SHA-256 验签通过"


def _manifest_authentication(manifest: Mapping[str, Any], segments: Sequence[SwdlSegment]) -> tuple[bool, str]:
    auth = manifest.get("authentication")
    if not isinstance(auth, Mapping):
        return False, "manifest 缺少 authentication（必须包含哈希、签名和 RSA-4096 公钥）"
    status = str(auth.get("status", "")).strip().upper()
    expected = str(auth.get("payload_sha256", manifest.get("payload_sha256", ""))).strip().lower()
    actual = hashlib.sha256(b"".join(segment.data for segment in segments)).hexdigest()
    if status != "PASS":
        return False, "manifest 认证状态不是 PASS（不能把未验签镜像发送到 ECU）"
    if not expected:
        return False, "manifest 缺少 payload_sha256"
    if expected != actual:
        return False, f"manifest payload_sha256 不匹配（期望 {expected[:12]}…，实际 {actual[:12]}…）"
    algorithm = str(auth.get("algorithm", "")).upper().replace("-", "_").replace("/", "_")
    if algorithm not in {
        "RSASSA_PSS_SHA256",
        "RSASSA_PSS_SHA_256",
        "SHA256_RSA4096",
        "SHA256_RSA4096_SW_PART_BASED",
    }:
        return False, f"未确认的认证算法: {algorithm or '<empty>'}"
    try:
        signature, _signature_path = _read_signature(auth, manifest_path=str(manifest.get("_path", "")))
    except (OSError, ValueError, RuntimeError) as exc:
        return False, f"读取签名失败: {exc}"
    public_key_raw = auth.get("public_key_file", auth.get("public_key_path"))
    if not public_key_raw:
        return False, "manifest 缺少 authentication.public_key_file（RSA-4096）"
    public_key_path = _resolve_segment_path(
        public_key_raw, manifest_path=str(manifest.get("_path", ""))
    )
    try:
        public_key_data = _read_bytes(public_key_path)
    except (OSError, RuntimeError) as exc:
        return False, f"读取 RSA 公钥失败: {exc}"
    if not signature:
        return False, "manifest 缺少 authentication.signature_file/signature"
    try:
        salt_length = parse_int(
            auth.get("pss_salt_length"), name="pss_salt_length", default=None
        )
    except ValueError as exc:
        return False, str(exc)
    return _verify_rsa_pss(
        signed_payload=b"".join(segment.data for segment in segments),
        signature=signature,
        public_key_data=public_key_data,
        salt_length=salt_length,
    )


def _parse_erase_segments(
    manifest: Mapping[str, Any], *, manifest_path: str, blockers: list[str]
) -> list[SwdlEraseSegment]:
    raw_segments = manifest.get("erase_segments", manifest.get("erase"))
    if raw_segments is None:
        blockers.append("manifest 缺少 erase_segments；禁止跳过完整逻辑块擦除")
        return []
    if isinstance(raw_segments, Mapping):
        raw_segments = [raw_segments]
    if not isinstance(raw_segments, list) or not raw_segments:
        blockers.append("manifest erase_segments 必须是非空数组")
        return []
    parsed: list[SwdlEraseSegment] = []
    for index, raw in enumerate(raw_segments, 1):
        if not isinstance(raw, Mapping):
            blockers.append(f"manifest erase_segments[{index}] 必须是对象")
            continue
        try:
            addr = parse_int(raw.get("address", raw.get("start_address")),
                             name=f"erase_segments[{index}].address", default=None)
            length = parse_int(raw.get("length"),
                               name=f"erase_segments[{index}].length", default=None)
            if addr is None or length is None:
                raise ValueError("必须提供 address 和 length")
            if not 0 <= addr <= 0xFFFFFFFF:
                raise ValueError("address 不在 4 字节范围")
            if not 0 < length <= 0xFFFFFFFF or addr + length > 0x100000000:
                raise ValueError("length 超出合法 4 字节地址范围")
            parsed.append(SwdlEraseSegment(addr, length))
        except (TypeError, ValueError) as exc:
            blockers.append(f"erase_segments[{index}] 无效: {exc}")
    parsed.sort(key=lambda item: item.address)
    for previous, current in zip(parsed, parsed[1:]):
        if previous.address + previous.length > current.address:
            blockers.append("erase_segments 存在重叠范围；禁止擦除范围歧义")
            break
    return parsed


def _parse_check_memory_payload(
    manifest: Mapping[str, Any], *, manifest_path: str, blockers: list[str]
) -> bytes:
    check_memory = manifest.get("check_memory")
    raw = manifest.get("check_memory_payload")
    if raw is None and isinstance(check_memory, Mapping):
        if "payload" in check_memory:
            raw = check_memory["payload"]
        elif any(key in check_memory for key in ("file", "path", "hex", "base64")):
            # 保留 mapping 形态，交给 _coerce_bytes 区分文件、hex 和 base64；
            # 不能把 file 字符串误当成 hex 数据。
            raw = check_memory
    if raw is None:
        blockers.append("manifest 缺少 CheckMemory payload；按调查表要求必须提供 512 字节参数")
        return b""
    try:
        payload = _coerce_bytes(
            raw,
            field_name="check_memory_payload",
            manifest_path=manifest_path,
        )
    except (OSError, ValueError, RuntimeError) as exc:
        blockers.append(f"CheckMemory payload 无效: {exc}")
        return b""
    if len(payload) != 512:
        blockers.append(
            f"CheckMemory payload 必须是调查表规定的 512 字节（实际 {len(payload)} 字节）"
        )
    return payload


def build_swdl_plan(
    *,
    image_path: str = "",
    manifest_path: str = "",
    target_partition: str = "SBL",
    address: Any = None,
    nad: Any = 0x51,
    key_file: str = "",
) -> SwdlPlan:
    """构建 SWDL 计划；只读取输入，不连接硬件。"""

    blockers: list[str] = []
    target = str(target_partition or "").strip().upper()
    try:
        nad_value = parse_int(nad, name="NAD", default=0x51)
    except ValueError as exc:
        nad_value = 0x51
        blockers.append(str(exc))
    if target not in {"PBL", "SBL"}:
        blockers.append("SWDL 目标分区只能是 PBL 或 SBL；APP 不支持 0x34/0x36/0x37")

    manifest: dict[str, Any] = {}
    if manifest_path:
        try:
            manifest = _read_json(manifest_path)
            manifest["_path"] = str(Path(manifest_path).resolve())
            if not image_path and manifest.get("image"):
                image_path = _resolve_segment_path(manifest.get("image"), manifest_path=manifest_path)
        except (OSError, ValueError, RuntimeError) as exc:
            blockers.append(str(exc))

    segments: list[SwdlSegment] = []
    raw_segments = manifest.get("segments") if isinstance(manifest.get("segments"), list) else []
    if raw_segments:
        for index, raw in enumerate(raw_segments, 1):
            if not isinstance(raw, Mapping):
                blockers.append(f"manifest segments[{index}] 必须是对象")
                continue
            source = _resolve_segment_path(raw.get("file", raw.get("path", image_path)), manifest_path=manifest_path)
            if not source:
                blockers.append(f"manifest segments[{index}] 缺少 file/path")
                continue
            try:
                data = _read_bytes(source)
                offset = parse_int(raw.get("offset"), name=f"segments[{index}].offset", default=0) or 0
                length = parse_int(raw.get("length"), name=f"segments[{index}].length", default=None)
                if offset < 0 or offset > len(data):
                    raise ValueError(f"offset={offset} 超出文件长度 {len(data)}")
                if length is None:
                    payload = data[offset:]
                else:
                    if length <= 0 or offset + length > len(data):
                        raise ValueError(f"length={length} 超出文件范围")
                    payload = data[offset:offset + length]
                addr = parse_int(raw.get("address"), name=f"segments[{index}].address", default=None)
                if addr is None:
                    raise ValueError("缺少 4 字节 memory address")
                if not 0 <= addr <= 0xFFFFFFFF:
                    raise ValueError(f"address 不在 4 字节范围: {addr}")
                if not payload:
                    raise ValueError("segment 为空")
                segments.append(SwdlSegment(source, addr, payload, offset))
            except (OSError, ValueError, RuntimeError) as exc:
                blockers.append(f"segments[{index}] 无效: {exc}")
    elif image_path:
        try:
            data = _read_bytes(image_path)
            addr = parse_int(
                manifest.get("address", address),
                name="address",
                default=None,
            )
            if addr is None:
                blockers.append("raw image 缺少 4 字节起始 address（请用 --address 或 manifest）")
            elif not 0 <= addr <= 0xFFFFFFFF:
                blockers.append("address 超出 4 字节范围")
            elif not data:
                blockers.append("刷写镜像为空")
            else:
                segments.append(SwdlSegment(str(image_path), addr, data))
        except (OSError, RuntimeError) as exc:
            blockers.append(f"刷写镜像读取失败: {exc}")
    else:
        blockers.append("未提供刷写镜像；SWDL 不能只凭诊断数据库执行")

    try:
        dfi = parse_int(manifest.get("data_format_identifier", 0x00),
                        name="data_format_identifier", default=0x00)
    except ValueError as exc:
        dfi = 0x00
        blockers.append(str(exc))
    try:
        alfid = parse_int(manifest.get("address_length_format_identifier", 0x44),
                          name="address_length_format_identifier", default=0x44)
    except ValueError as exc:
        alfid = 0x44
        blockers.append(str(exc))
    erase_segments = _parse_erase_segments(
        manifest, manifest_path=manifest_path, blockers=blockers
    ) if segments else []
    check_memory_payload = _parse_check_memory_payload(
        manifest, manifest_path=manifest_path, blockers=blockers
    ) if segments else b""
    logical_block = str(
        manifest.get("logical_block", manifest.get("logical_block_name", ""))
    ).strip()
    if segments and not logical_block:
        blockers.append("manifest 缺少 logical_block；不能把 segment 名称当作逻辑块证明")
    activation = manifest.get("activation")
    activate_sbl = bool(
        manifest.get("activate_sbl", False)
        or (isinstance(activation, Mapping) and activation.get("enabled", False))
    )
    raw_sbl_address = manifest.get("sbl_start_address")
    if raw_sbl_address is None and isinstance(activation, Mapping):
        raw_sbl_address = activation.get("sbl_start_address", activation.get("address"))
    try:
        sbl_start_address = parse_int(
            raw_sbl_address, name="sbl_start_address", default=None
        )
    except ValueError as exc:
        sbl_start_address = None
        blockers.append(str(exc))
    if activate_sbl and target == "SBL":
        if sbl_start_address is None:
            blockers.append("启用 SBL 激活时必须提供经 Memory Map 确认的 sbl_start_address")
        elif not 0 <= sbl_start_address <= 0xFFFFFFFF:
            blockers.append("sbl_start_address 不在 4 字节范围")
    if activate_sbl and target != "SBL":
        blockers.append("activate_sbl 只允许用于 SBL 目标分区")
    if segments and erase_segments:
        for index, segment in enumerate(segments, 1):
            covered = any(
                erase.address <= segment.address
                and segment.address + segment.length <= erase.address + erase.length
                for erase in erase_segments
            )
            if not covered:
                blockers.append(
                    f"segment[{index}] 不在任何完整 erase_segments 范围内；"
                    "禁止访问未定义/受保护区域"
                )
        if len(erase_segments) not in {1, len(segments)}:
            blockers.append(
                "erase_segments 必须提供一个完整逻辑块范围，或与下载 segment 一一对应"
            )
    if dfi != 0x00:
        blockers.append(f"当前流程只允许未压缩/未加密 DFI=0x00，实际 0x{dfi:02X}")
    if alfid != 0x44:
        blockers.append(f"BBS LIN SWDL 只允许 ALFID=0x44，实际 0x{alfid:02X}")

    key_ready, key_reason = security_key_status(key_file)
    if not key_ready:
        blockers.append("0x27/0x34/0x36/0x37 前置被阻断: " + key_reason)
    auth_ready, auth_reason = _manifest_authentication(manifest, segments) if segments else (
        False,
        "没有可校验的刷写 segment",
    )
    if not auth_ready:
        blockers.append("刷写镜像认证前置被阻断: " + auth_reason)

    return SwdlPlan(
        target_partition=target,
        nad=nad_value or 0x51,
        data_format_identifier=dfi or 0,
        address_length_format_identifier=alfid or 0x44,
        segments=segments,
        image_path=str(image_path or ""),
        manifest_path=str(manifest_path or ""),
        key_file=str(key_file or ""),
        key_ready=key_ready,
        key_reason=key_reason,
        authentication_ready=auth_ready,
        authentication_reason=auth_reason,
        signature_path=str(
            manifest.get("authentication", {}).get("signature_file", "")
            if isinstance(manifest.get("authentication"), Mapping) else ""
        ),
        public_key_path=str(
            manifest.get("authentication", {}).get("public_key_file", "")
            if isinstance(manifest.get("authentication"), Mapping) else ""
        ),
        signature_ready=auth_ready,
        logical_block=logical_block,
        erase_segments=erase_segments,
        check_memory_payload=check_memory_payload,
        check_memory_attempts=2,
        activate_sbl=activate_sbl,
        sbl_start_address=sbl_start_address,
        blocked_reasons=blockers,
    )


def build_request_download(segment: SwdlSegment, *, data_format_identifier: int = 0x00) -> list[int]:
    if not 0 <= segment.address <= 0xFFFFFFFF:
        raise ValueError("segment address 必须是 4 字节")
    if not 0 < segment.length <= 0xFFFFFFFF:
        raise ValueError("segment length 必须是 1..0xFFFFFFFF")
    return [
        0x34,
        data_format_identifier & 0xFF,
        0x44,
        *segment.address.to_bytes(4, "big"),
        *segment.length.to_bytes(4, "big"),
    ]


def build_flash_erase_request(erase_segment: SwdlEraseSegment) -> list[int]:
    """构造 BBS RID FF00：0x31 01 FF 00 + 4B 地址 + 4B 长度。"""

    if not 0 <= erase_segment.address <= 0xFFFFFFFF:
        raise ValueError("erase address 必须是 4 字节")
    if not 0 < erase_segment.length <= 0xFFFFFFFF:
        raise ValueError("erase length 必须是 1..0xFFFFFFFF")
    if erase_segment.address + erase_segment.length > 0x100000000:
        raise ValueError("erase 范围超出 4 字节地址空间")
    return [
        0x31,
        0x01,
        0xFF,
        0x00,
        *erase_segment.address.to_bytes(4, "big"),
        *erase_segment.length.to_bytes(4, "big"),
    ]


def build_check_memory_request(payload: bytes) -> list[int]:
    """构造 RID 0212 请求；调查表规定 RID 后参数为 512 字节。"""

    if len(payload) != 512:
        raise ValueError(f"CheckMemory payload 必须是 512 字节，实际 {len(payload)} 字节")
    return [0x31, 0x01, 0x02, 0x12, *payload]


def build_activate_sbl_request(address: int) -> list[int]:
    """构造 RID 0301：0x31 01 03 01 + 4B SBL 起始地址。"""

    if not 0 <= address <= 0xFFFFFFFF:
        raise ValueError("SBL 起始地址必须是 4 字节")
    return [0x31, 0x01, 0x03, 0x01, *address.to_bytes(4, "big")]


def _response_values(response: Sequence[int] | None) -> list[int]:
    return [int(item) & 0xFF for item in (response or ())]


def validate_session_response(
    response: Sequence[int] | None, expected_subfunction: int = 0x02
) -> tuple[bool, str]:
    ok, reason = validate_positive(response, 0x50)
    if not ok:
        return False, reason
    values = _response_values(response)
    if len(values) < 2 or values[1] != (expected_subfunction & 0x7F):
        actual = f"0x{values[1]:02X}" if len(values) >= 2 else "缺失"
        return False, f"0x10 正响应子功能={actual}，期望 0x{expected_subfunction & 0x7F:02X}"
    return True, "0x10 编程会话正响应结构正确"


def validate_security_response(
    response: Sequence[int] | None,
    expected_level: int,
    *,
    seed: bool = False,
) -> tuple[bool, str]:
    ok, reason = validate_positive(response, 0x67)
    if not ok:
        return False, reason
    values = _response_values(response)
    if len(values) < 2 or values[1] != (expected_level & 0xFF):
        actual = f"0x{values[1]:02X}" if len(values) >= 2 else "缺失"
        return False, f"0x27 正响应等级={actual}，期望 0x{expected_level & 0xFF:02X}"
    if seed:
        # Gen2 seed: 67 level 00 02 + IV16 + encrypted random/proof32 + CMAC16。
        if len(values) < 68:
            return False, f"Gen2 seed 响应长度不足：{len(values)}，期望至少 68 字节"
        if values[2:4] != [0x00, 0x02]:
            return False, f"Gen2 seed 版本头错误：{values[2:4]}，期望 [00, 02]"
    return True, "0x27 正响应结构正确"


def validate_transfer_data_response(
    response: Sequence[int] | None, expected_block_sequence: int
) -> tuple[bool, str]:
    ok, reason = validate_positive(response, 0x76)
    if not ok:
        return False, reason
    values = _response_values(response)
    expected = expected_block_sequence & 0xFF
    if len(values) < 2 or values[1] != expected:
        actual = f"0x{values[1]:02X}" if len(values) >= 2 else "缺失"
        return False, f"0x36 返回 BSC={actual}，期望 0x{expected:02X}"
    return True, "0x36 正响应和 BSC 正确"


def validate_transfer_exit_response(
    response: Sequence[int] | None, expected_record: Sequence[int] = ()
) -> tuple[bool, str]:
    ok, reason = validate_positive(response, 0x77)
    if not ok:
        return False, reason
    values = _response_values(response)
    expected = [int(item) & 0xFF for item in expected_record]
    if expected and values[1:1 + len(expected)] != expected:
        return False, f"0x37 responseParameterRecord={values[1:]}，期望前缀={expected}"
    return True, "0x37 正响应结构正确"


def validate_routine_response(
    response: Sequence[int] | None,
    expected_rid: int,
    *,
    expected_subfunction: int = 0x01,
    expected_result: int | None = None,
    require_result: bool = False,
) -> tuple[bool, str]:
    ok, reason = validate_positive(response, 0x71)
    if not ok:
        return False, reason
    values = _response_values(response)
    if len(values) < 4:
        return False, f"0x31 正响应长度不足：{len(values)}，缺少 RID"
    if values[1] != (expected_subfunction & 0x7F):
        return False, (
            f"0x31 正响应子功能=0x{values[1]:02X}，"
            f"期望 0x{expected_subfunction & 0x7F:02X}"
        )
    actual_rid = (values[2] << 8) | values[3]
    if actual_rid != (expected_rid & 0xFFFF):
        return False, f"0x31 返回 RID=0x{actual_rid:04X}，期望 0x{expected_rid & 0xFFFF:04X}"
    if require_result:
        if len(values) < 6:
            return False, "0x31 Routine Status/Result Value 缺失"
        actual_result = values[-1]
        if expected_result is not None and actual_result != (expected_result & 0xFF):
            return False, (
                f"0x31 Result Value=0x{actual_result:02X}，"
                f"期望 0x{expected_result & 0xFF:02X}"
            )
    return True, "0x31 正响应结构正确"


def validate_reset_response(
    response: Sequence[int] | None, expected_subfunction: int = 0x01
) -> tuple[bool, str]:
    ok, reason = validate_positive(response, 0x51)
    if not ok:
        return False, reason
    values = _response_values(response)
    if len(values) < 2 or values[1] != (expected_subfunction & 0x7F):
        actual = f"0x{values[1]:02X}" if len(values) >= 2 else "缺失"
        return False, f"0x11 正响应子功能={actual}，期望 0x{expected_subfunction & 0x7F:02X}"
    return True, "0x11 复位正响应结构正确"


def build_transfer_data_requests(data: bytes, max_number_of_block_length: int) -> list[list[int]]:
    """按 ECU 0x34 正响应给出的最大 UDS payload 长度切分 0x36。"""

    if max_number_of_block_length <= 2:
        raise ValueError("maxNumberOfBlockLength 必须大于 SID+BSC 的 2 字节")
    chunk_size = max_number_of_block_length - 2
    requests: list[list[int]] = []
    block_sequence = 1
    for offset in range(0, len(data), chunk_size):
        requests.append([0x36, block_sequence, *data[offset:offset + chunk_size]])
        block_sequence = (block_sequence + 1) & 0xFF
    return requests


def validate_positive(response: Sequence[int] | None, expected_sid: int) -> tuple[bool, str]:
    if not response:
        return False, "无响应"
    values = [int(item) & 0xFF for item in response]
    if values[0] == 0x7F:
        nrc = f"0x{values[2]:02X}" if len(values) >= 3 else "未知"
        return False, f"NRC={nrc}"
    if values[0] != expected_sid:
        return False, f"正响应 SID=0x{values[0]:02X}，期望 0x{expected_sid:02X}"
    return True, "正响应"


def parse_request_download_response(response: Sequence[int] | None) -> tuple[bool, int | None, str]:
    ok, reason = validate_positive(response, 0x74)
    if not ok:
        return False, None, reason
    values = [int(item) & 0xFF for item in response or ()]
    if len(values) < 4 or values[1] != 0x20:
        return False, None, "0x34 正响应不是 BBS 规定的 74 20 xx xx 结构"
    max_length = (values[2] << 8) | values[3]
    if max_length <= 2:
        return False, None, f"maxNumberOfBlockLength 无效: {max_length}"
    return True, max_length, "maxNumberOfBlockLength 已解析"


def _make_seed_key_generator(key_file: str):
    """从普通/DLP JSON 构造 SeedKeyGen2，避免把透明加密文件复制成明文。"""

    if str(SCRIPT_DIR) not in sys.path:
        sys.path.insert(0, str(SCRIPT_DIR))
    from seedkey_gen2 import SeedKeyGen2, _to_key_bytes

    data = {str(k).lower(): v for k, v in _read_json(key_file).items()}
    aliases = {
        "aes_cmac_key_0102": ("aes_cmac_key_0102", "cmac_0102", "key_cmac_0102"),
        "aes_ctr_key_0102": ("aes_ctr_key_0102", "ctr_0102", "key_ctr_0102"),
    }
    generator = SeedKeyGen2(key_file)
    generator.keys = {}
    for canonical, candidates in aliases.items():
        raw = next((data.get(candidate) for candidate in candidates if data.get(candidate)), None)
        if raw is None:
            raise ValueError(f"缺少密钥字段 {canonical}")
        generator.keys[canonical] = _to_key_bytes(raw)
    if any(value == b"\xff" * 16 for value in generator.keys.values()):
        raise ValueError("密钥含全 0xFF 占位")
    generator.ready = True
    generator.reason = ""
    return generator


@dataclass
class SwdlFlow:
    plan: SwdlPlan
    output_dir: str
    approved: bool = False
    brval: int = 19200
    check_memory: bool = True
    client_factory: Callable[[], Any] | None = None

    def _request(self, client: Any, step_id: str, payload: Sequence[int], timeout: float) -> tuple[list[int] | None, list[Any], float, float]:
        if hasattr(client, "request_with_trace"):
            try:
                response, trace, started, ended = client.request_with_trace(
                    self.plan.nad,
                    list(payload),
                    timeout=timeout,
                    retry=0,
                    transaction_id=step_id,
                )
            except TypeError as exc:
                # 现有 F1L1UDS 的稳定接口没有 transaction_id；不能因审计字段
                # 把真实 VickCAN 请求误判成 COM/通信失败。
                if "transaction_id" not in str(exc):
                    raise
                response, trace, started, ended = client.request_with_trace(
                    self.plan.nad,
                    list(payload),
                    timeout=timeout,
                    retry=0,
                )
            return response, list(trace or []), float(started), float(ended)
        started = time.monotonic()
        response = client.request(self.plan.nad, list(payload), timeout=timeout, retry=0)
        ended = time.monotonic()
        return response, [], started, ended

    @staticmethod
    def _step(step_id: str, service: int, request: Sequence[int], response: Sequence[int] | None,
              status: str, reason: str, trace_count: int, started: float, ended: float) -> dict[str, Any]:
        return {
            "step_id": step_id,
            "service": f"0x{service:02X}",
            "request": [f"{int(x) & 0xFF:02X}" for x in request],
            "response": [f"{int(x) & 0xFF:02X}" for x in (response or [])],
            "status": status,
            "reason": reason,
            "trace_count": trace_count,
            "elapsed_ms": round(max(0.0, ended - started) * 1000.0, 3),
        }

    def _write_artifacts(self, report: Mapping[str, Any], traces: Sequence[Any]) -> None:
        out = Path(self.output_dir)
        out.mkdir(parents=True, exist_ok=True)
        (out / "swdl_plan.json").write_text(
            json.dumps(self.plan.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (out / "swdl_report.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        if traces:
            (out / "swdl_trace.json").write_text(
                json.dumps(traces, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
            )

    def _blocked_report(self, reasons: Sequence[str]) -> dict[str, Any]:
        dependency = {
            "0x27": "BLOCKED" if not self.plan.key_ready else "READY",
            "0x34": "BLOCKED",
            "0x36": "BLOCKED",
            "0x37": "BLOCKED",
        }
        report = {
            "flow": "swdl",
            "overall": "BLOCKED",
            "target_partition": self.plan.target_partition,
            "hardware": "VickCAN/F1L1",
            "steps": [],
            "dependency_status": dependency,
            "blocked_reasons": list(reasons),
        }
        self._write_artifacts(report, [])
        return report

    @staticmethod
    def _dependency_status(steps: Sequence[Mapping[str, Any]]) -> dict[str, str]:
        """按已执行步骤计算依赖状态，避免未执行步骤被误报成 FAIL。"""

        status_by_service: dict[str, list[str]] = {}
        for step in steps:
            status_by_service.setdefault(str(step.get("service", "")), []).append(
                str(step.get("status", ""))
            )
        result: dict[str, str] = {}
        for service in ("0x27", "0x34", "0x36", "0x37"):
            values = status_by_service.get(service, [])
            if "FAIL" in values:
                result[service] = "FAIL"
            elif values and all(value == "PASS" for value in values):
                result[service] = "PASS"
            else:
                result[service] = "BLOCKED"
        return result

    def execute(self) -> dict[str, Any]:
        blockers = list(self.plan.blocked_reasons)
        if not self.plan.segments:
            blockers.append("没有可执行的刷写 segment")
        if not self.plan.key_ready:
            blockers.append("0x27 前置未就绪: " + (self.plan.key_reason or "密钥未验证"))
        if not self.plan.authentication_ready:
            blockers.append(
                "刷写镜像认证前置未就绪: "
                + (self.plan.authentication_reason or "RSA-PSS 验签未通过")
            )
        if not self.plan.erase_segments:
            blockers.append("没有完整逻辑块 erase_segments；禁止跳过 0xFF00")
        elif len(self.plan.erase_segments) not in {1, len(self.plan.segments)}:
            blockers.append("erase_segments 必须是一个完整范围或与 segment 一一对应")
        if self.check_memory and len(self.plan.check_memory_payload) != 512:
            blockers.append(
                "CheckMemory payload 未提供或长度不是 512 字节；禁止发送不完整 0x0212 请求"
            )
        if self.plan.activate_sbl and self.plan.sbl_start_address is None:
            blockers.append("启用 SBL 激活但缺少经确认的 sbl_start_address")
        if not self.approved:
            blockers.append("未提供 --approve-swdl；高风险刷写默认只允许生成 BLOCKED 计划")
        if blockers:
            return self._blocked_report(blockers)

        if str(SCRIPT_DIR) not in sys.path:
            sys.path.insert(0, str(SCRIPT_DIR))
        from f1l1_uds import F1L1UDS, is_positive

        client = self.client_factory() if self.client_factory else F1L1UDS(brval=self.brval)
        steps: list[dict[str, Any]] = []
        traces: list[Any] = []

        def do_step(
            step_id: str,
            payload: Sequence[int],
            expected_sid: int,
            timeout: float = 3.0,
            validator: Callable[[Sequence[int] | None], tuple[bool, str]] | None = None,
            raise_on_fail: bool = True,
        ) -> list[int] | None:
            response, trace, started, ended = self._request(client, step_id, payload, timeout)
            traces.extend(trace)
            ok, reason = validator(response) if validator else validate_positive(response, expected_sid)
            steps.append(self._step(
                step_id, payload[0], payload, response, "PASS" if ok else "FAIL", reason,
                len(trace), started, ended,
            ))
            if not ok and raise_on_fail:
                raise RuntimeError(f"{step_id}: {reason}")
            return list(response or [])

        try:
            client.open()
            if hasattr(client, "current_partition"):
                current_partition = client.current_partition(self.plan.nad, timeout=3.0)
                allowed_source_for_sbl = (
                    self.plan.target_partition == "SBL"
                    and current_partition == "PBL"
                    and self.plan.activate_sbl
                )
                if current_partition != self.plan.target_partition and not allowed_source_for_sbl:
                    steps.append({
                        "step_id": "partition-check",
                        "service": "partition",
                        "request": [],
                        "response": [],
                        "status": "BLOCKED",
                        "reason": (
                            f"当前 ECU 分区={current_partition or 'UNKNOWN'}，目标分区="
                            f"{self.plan.target_partition}；未提供受控分区前置，禁止跨分区刷写"
                        ),
                        "trace_count": 0,
                        "elapsed_ms": 0,
                    })
                    raise SwdlBlocked(steps[-1]["reason"])
            do_step(
                "session-programming",
                [0x10, 0x02],
                0x50,
                timeout=3.0,
                validator=lambda response: validate_session_response(response, 0x02),
            )

            generator = _make_seed_key_generator(self.plan.key_file)
            seed_request, client_random, client_iv = generator.build_seed_request(0x01)
            seed_response = do_step(
                "security-seed-level-01",
                seed_request,
                0x67,
                timeout=10.0,
                validator=lambda response: validate_security_response(response, 0x01, seed=True),
            )
            server_random, _server_proof, proof_ok = generator.parse_seed_response(
                seed_response, client_random, client_iv, 0x01
            )
            if not proof_ok:
                raise RuntimeError("security-seed-level-01: server proof 校验失败")
            key_request = generator.build_key_request(0x01, client_random, server_random)
            do_step(
                "security-key-level-01",
                key_request,
                0x67,
                timeout=10.0,
                validator=lambda response: validate_security_response(response, 0x01),
            )

            for index, segment in enumerate(self.plan.segments, 1):
                if len(self.plan.erase_segments) == 1:
                    erase_segment = self.plan.erase_segments[0]
                elif len(self.plan.erase_segments) == len(self.plan.segments):
                    erase_segment = self.plan.erase_segments[index - 1]
                else:
                    raise SwdlBlocked(
                        "erase_segments 必须提供一个完整逻辑块范围，或与下载 segment 一一对应"
                    )
                do_step(
                    f"segment-{index}-flash-erase",
                    build_flash_erase_request(erase_segment),
                    0x71,
                    timeout=60.0,
                    validator=lambda response: validate_routine_response(
                        response, 0xFF00
                    ),
                )
                download_request = build_request_download(
                    segment, data_format_identifier=self.plan.data_format_identifier
                )
                download_response = do_step(f"segment-{index}-request-download", download_request, 0x74, timeout=1.0)
                valid, max_length, reason = parse_request_download_response(download_response)
                if not valid or max_length is None:
                    raise RuntimeError(f"segment-{index}-request-download: {reason}")
                for block_index, transfer_request in enumerate(
                    build_transfer_data_requests(segment.data, max_length), 1
                ):
                    do_step(
                        f"segment-{index}-transfer-{block_index}",
                        transfer_request,
                        0x76,
                        timeout=5.0,
                        validator=lambda response, bsc=transfer_request[1]:
                            validate_transfer_data_response(response, bsc),
                    )
                do_step(
                    f"segment-{index}-transfer-exit",
                    [0x37],
                    0x77,
                    timeout=15.0,
                    validator=validate_transfer_exit_response,
                )

            if self.check_memory:
                check_request = build_check_memory_request(self.plan.check_memory_payload)
                attempts = max(1, min(2, int(self.plan.check_memory_attempts or 2)))
                check_passed = False
                for attempt in range(1, attempts + 1):
                    do_step(
                        f"check-memory-attempt-{attempt}",
                        check_request,
                        0x71,
                        timeout=2.0,
                        validator=lambda response: validate_routine_response(
                            response,
                            0x0212,
                            expected_result=0x00,
                            require_result=True,
                        ),
                        raise_on_fail=False,
                    )
                    if steps[-1]["status"] == "PASS":
                        check_passed = True
                        break
                    if attempt < attempts:
                        steps[-1]["status"] = "RETRY"
                        steps[-1]["reason"] += f"；将在允许的第 {attempt + 1} 次尝试重试"
                if not check_passed:
                    raise RuntimeError(
                        f"CheckMemory 连续 {attempts} 次未通过；第三次尝试被禁止"
                    )
            if self.plan.activate_sbl:
                if self.plan.sbl_start_address is None:
                    raise SwdlBlocked("启用 SBL 激活但缺少经确认的 sbl_start_address")
                do_step(
                    "activate-secondary-bootloader",
                    build_activate_sbl_request(self.plan.sbl_start_address),
                    0x71,
                    timeout=5.0,
                    validator=lambda response: validate_routine_response(
                        response, 0x0301
                    ),
                )
            do_step(
                "reset-after-download",
                [0x11, 0x01],
                0x51,
                timeout=3.0,
                validator=lambda response: validate_reset_response(response, 0x01),
            )
            report = {
                "flow": "swdl",
                "overall": "PASS",
                "target_partition": self.plan.target_partition,
                "hardware": "VickCAN/F1L1",
                "steps": steps,
                "dependency_status": {"0x27": "PASS", "0x34": "PASS", "0x36": "PASS", "0x37": "PASS"},
                "blocked_reasons": [],
            }
        except SwdlBlocked as exc:
            report = {
                "flow": "swdl",
                "overall": "BLOCKED",
                "target_partition": self.plan.target_partition,
                "hardware": "VickCAN/F1L1",
                "steps": steps,
                "dependency_status": self._dependency_status(steps),
                "blocked_reasons": [str(exc)],
            }
        except Exception as exc:
            report = {
                "flow": "swdl",
                "overall": "FAIL",
                "target_partition": self.plan.target_partition,
                "hardware": "VickCAN/F1L1",
                "steps": steps,
                "dependency_status": self._dependency_status(steps),
                "blocked_reasons": [],
                "error": f"{type(exc).__name__}: {exc}",
            }
        finally:
            try:
                client.close()
            except Exception:
                pass
        self._write_artifacts(report, traces)
        return report


__all__ = [
    "SwdlBlocked",
    "SwdlFlow",
    "SwdlPlan",
    "SwdlSegment",
    "SwdlEraseSegment",
    "build_activate_sbl_request",
    "build_check_memory_request",
    "build_flash_erase_request",
    "build_request_download",
    "build_swdl_plan",
    "build_transfer_data_requests",
    "parse_request_download_response",
    "security_key_status",
    "validate_reset_response",
    "validate_routine_response",
    "validate_security_response",
    "validate_session_response",
    "validate_transfer_data_response",
    "validate_transfer_exit_response",
    "validate_positive",
]
