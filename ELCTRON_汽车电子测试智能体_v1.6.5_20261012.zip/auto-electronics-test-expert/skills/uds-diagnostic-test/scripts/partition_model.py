#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UDS APP/PBL/SBL 分区模型。

本模块只负责把诊断库和 DID 检查矩阵转换成可审计的领域模型，不访问硬件，
也不决定是否发送请求。用例生成器可以先读取本模型，再在后续门禁阶段决定
该用例是可执行、负向、BLOCKED 还是资料不足。

设计原则：
* 分区必须显式表示；无法从用例或输入资料确定时保持 ``None``，不默认 APP。
* 矩阵中的 Y/实际数据、NRCxx、空白分别保留为不同状态，不能混为一个布尔值。
* DID 的调查表属性与分区矩阵同时保留，后续可以分别校验会话/读写属性和
  APP/PBL/SBL 的实际支持情况。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import re
from typing import Any, Mapping


PARTITIONS = ("APP", "PBL", "SBL")
# BBS diagnostic timing parameters confirmed from the three layer diagnostic
# exports: APP reports a 50 ms P2Server, while PBL/SBL report 25 ms.  Keep the
# values in the partition model so a timing case cannot silently reuse APP's
# limit for a bootloader target.
DEFAULT_TIMING_PARAMETERS = {
    "APP": {"p2_ms": 50.0, "source": "BBS APP diagnostic export"},
    "PBL": {"p2_ms": 25.0, "source": "BBS PBL diagnostic export"},
    "SBL": {"p2_ms": 25.0, "source": "BBS SBL diagnostic export"},
}
# The DID matrix describes the nominal response.  Some BBS DIDs also have a
# documented condition-dependent negative response.  Keep that fact in the
# model so generators do not turn a valid ECU condition into a test failure.
DEFAULT_CONDITIONAL_NRCS = {
    "D03A": {"APP": (0x22,)},
}
PARTITION_ALIASES = {
    "APP": {
        "app", "application", "applicationlayer", "application layer", "应用",
        "应用层", "应用程序", "应用模式", "app层",
    },
    "PBL": {
        "pbl", "primarybootloader", "primary bootloader", "primary boot loader",
        "主bootloader", "主引导加载程序", "主引导层",
    },
    "SBL": {
        "sbl", "secondarybootloader", "secondary bootloader", "secondary boot loader",
        "次bootloader", "次级引导加载程序", "次引导层",
    },
}

SESSION_ALIASES = {
    "default": {"default", "normal", "默认", "默认会话", "0x01", "01"},
    "programming": {"programming", "program", "编程", "编程会话", "0x02", "02"},
    "extended": {"extended", "扩展", "扩展会话", "0x03", "03"},
}

_NRC_RE = re.compile(r"(?:NRC\s*|7F\s+22\s+|0x)?([0-9A-Fa-f]{2})\b", re.I)
_PARTITION_RE = re.compile(r"(?<![A-Za-z0-9])(APP|PBL|SBL)(?![A-Za-z0-9])", re.I)


def normalize_partition(value: Any) -> str | None:
    """将分区名称规范化为 APP/PBL/SBL；未知值返回 None。"""

    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    compact = re.sub(r"[\s_\-/（）()]+", "", raw.lower())
    for canonical, aliases in PARTITION_ALIASES.items():
        if raw.lower() in aliases or compact in {re.sub(r"[\s_\-/（）()]+", "", a.lower()) for a in aliases}:
            return canonical
    match = _PARTITION_RE.search(raw)
    return match.group(1).upper() if match else None


def normalize_session(value: Any) -> str | None:
    """将会话名称规范化为 default/programming/extended。"""

    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    compact = re.sub(r"[\s_\-/（）()]+", "", raw.lower())
    for canonical, aliases in SESSION_ALIASES.items():
        if raw.lower() in aliases or compact in {re.sub(r"[\s_\-/（）()]+", "", a.lower()) for a in aliases}:
            return canonical
    return None


def normalize_did(value: Any) -> str | None:
    """规范化四位 DID，接受 ``F18C``、``0xF18C`` 和整数。"""

    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return f"{value:04X}" if 0 <= value <= 0xFFFF else None
    raw = str(value).strip().upper().replace("0X", "")
    match = re.search(r"(?<![0-9A-F])([0-9A-F]{4})(?![0-9A-F])", raw)
    return match.group(1) if match else None


def _clean_matrix_value(value: Any) -> str:
    return " ".join(str(value or "").replace("\n", " ").split())


def _extract_nrcs(raw: str) -> tuple[int, ...]:
    """提取 NRC 数值，仅识别明确的 NRC/7F 语义，避免把普通数据当 NRC。"""

    values: set[int] = set()
    for match in re.finditer(r"NRC\s*(?:=|:)?\s*0?x?([0-9A-Fa-f]{2})", raw, re.I):
        values.add(int(match.group(1), 16))
    for match in re.finditer(r"7F\s+[0-9A-Fa-f]{2}\s+([0-9A-Fa-f]{2})", raw, re.I):
        values.add(int(match.group(1), 16))
    # 诊断矩阵常直接写 NRC31/NRC22。
    for match in re.finditer(r"NRC\s*([0-9A-Fa-f]{2})", raw, re.I):
        values.add(int(match.group(1), 16))
    return tuple(sorted(values))


@dataclass(frozen=True)
class MatrixExpectation:
    """单个 DID 在一个分区矩阵单元中的语义。"""

    raw: str = ""
    defined: bool = False
    supported: bool = False
    kind: str = "undefined"  # positive / negative / undefined
    expected_nrc: tuple[int, ...] = ()
    expected_value: str | None = None
    conditional_nrc: tuple[int, ...] = ()

    @classmethod
    def from_value(cls, value: Any) -> "MatrixExpectation":
        raw = _clean_matrix_value(value)
        if not raw or raw in {"-", "/", "N/A", "NA", "NONE", "未定义", "不支持"}:
            return cls(raw=raw, defined=False, supported=False, kind="undefined")
        nrcs = _extract_nrcs(raw)
        if nrcs:
            return cls(raw=raw, defined=True, supported=False, kind="negative", expected_nrc=nrcs)
        if re.fullmatch(r"N(?:O)?", raw, re.I):
            return cls(raw=raw, defined=True, supported=False, kind="negative")
        return cls(
            raw=raw,
            defined=True,
            supported=True,
            kind="positive",
            expected_value=None if raw.upper() in {"Y", "YES", "是"} else raw,
        )

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["expected_nrc"] = list(self.expected_nrc)
        data["conditional_nrc"] = list(self.conditional_nrc)
        return data


@dataclass(frozen=True)
class PartitionSpec:
    """分区静态定义。"""

    name: str
    display_name: str
    aliases: tuple[str, ...]
    diagnostic_sources: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class DidSpec:
    """DID 的跨资料统一模型。"""

    did: str
    name: str = ""
    name_cn: str = ""
    rw_state: str = ""
    size_bytes: int | None = None
    read_sessions: Mapping[str, str] = field(default_factory=dict)
    write_sessions: Mapping[str, str] = field(default_factory=dict)
    read_security: Mapping[str, str] = field(default_factory=dict)
    write_security: Mapping[str, str] = field(default_factory=dict)
    matrix: Mapping[str, MatrixExpectation] = field(default_factory=dict)
    source_references: tuple[str, ...] = ()
    attributes_provisional: bool = False
    defaulted_fields: tuple[str, ...] = ()

    def for_partition(self, partition: Any) -> MatrixExpectation | None:
        name = normalize_partition(partition)
        return self.matrix.get(name) if name else None

    def session_allowed(self, session: Any, *, write: bool = False) -> bool | None:
        # 当前 BBS 导出的 DID 表没有会话/安全列时，解析器会填入默认
        # N/Y 占位值；Unknown DID 也明确表示调查表属性未补齐。此类值
        # 只能作为留痕，不能被当成真实拒绝条件。
        if self.attributes_provisional:
            return None
        normalized = normalize_session(session)
        if not normalized:
            return None
        key = {"default": "default_0x01", "programming": "programming_0x02", "extended": "extended_0x03"}[normalized]
        source = self.write_sessions if write else self.read_sessions
        if not source:
            return None
        value = str(source.get(key, "")).strip().upper()
        if value in {"Y", "YES", "TRUE", "是", "1"}:
            return True
        if value in {"N", "NO", "FALSE", "否", "0"}:
            return False
        return None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["matrix"] = {key: value.to_dict() for key, value in self.matrix.items()}
        return data


@dataclass(frozen=True)
class PartitionModel:
    """整个项目使用的分区知识库。"""

    schema_version: str = "uds-partition-model.v1"
    partitions: Mapping[str, PartitionSpec] = field(default_factory=dict)
    dids: Mapping[str, DidSpec] = field(default_factory=dict)
    source_files: tuple[str, ...] = ()
    matrix_loaded: bool = False
    timing_parameters: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)

    def lookup(self, did: Any, partition: Any = None) -> DidSpec | None:
        spec = self.dids.get(normalize_did(did) or "")
        if spec is None:
            return None
        if partition is not None and normalize_partition(partition) not in self.partitions:
            return None
        return spec

    def expectation(self, did: Any, partition: Any = None) -> MatrixExpectation | None:
        spec = self.lookup(did, partition)
        return spec.for_partition(partition) if spec and partition is not None else None

    def p2_limit(self, partition: Any = None, default: float = 50.0) -> float:
        """Return the P2Server limit for a target partition."""

        name = normalize_partition(partition)
        raw = self.timing_parameters.get(name or "", {})
        try:
            value = float(raw.get("p2_ms", default))
        except (TypeError, ValueError):
            return float(default)
        return value if value > 0 else float(default)

    def case_context(self, case: Mapping[str, Any], did: Any = None) -> dict[str, Any]:
        """返回可写入 manifest/结果的分区上下文，不执行强制门禁。"""

        target = infer_case_partition(case)
        did_value = normalize_did(did)
        # DID 是否存在与目标分区矩阵是否已解析是两个不同事实。目标分区
        # 未明确时也要保留 DID 的全局存在性，避免上下文把“分区未解析”误报
        # 成“DID 未定义”。
        spec = self.lookup(did_value) if did_value else None
        expectation = spec.for_partition(target) if spec and target else None
        context: dict[str, Any] = {
            "schema_version": self.schema_version,
            "target_partition": target,
            "partition_resolved": target is not None,
            "did": did_value,
            "did_defined": spec is not None,
            "source_files": list(self.source_files),
            "timing_parameters": {
                key: dict(value) for key, value in self.timing_parameters.items()
            },
        }
        if target and target in self.partitions:
            context["partition_source"] = list(self.partitions[target].diagnostic_sources)
        if expectation:
            context["matrix_expectation"] = expectation.to_dict()
        elif did_value and spec and target:
            context["matrix_expectation"] = MatrixExpectation().to_dict()
        return context

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "source_files": list(self.source_files),
            "matrix_loaded": self.matrix_loaded,
            "timing_parameters": {
                key: dict(value) for key, value in self.timing_parameters.items()
            },
            "partitions": {key: value.to_dict() for key, value in self.partitions.items()},
            "dids": {key: value.to_dict() for key, value in self.dids.items()},
        }


def infer_case_partition(case: Mapping[str, Any]) -> str | None:
    """从结构化字段或文本推断目标分区；多个分区提示时返回 None。"""

    for key in ("target_partition", "partition", "ecu_partition", "layer"):
        if key in case:
            value = normalize_partition(case.get(key))
            if value:
                return value
    hits: set[str] = set()
    for key in ("test_point", "procedure", "expected", "precondition", "description"):
        text = str(case.get(key, "") or "")
        hits.update(match.group(1).upper() for match in _PARTITION_RE.finditer(text))
    return next(iter(hits)) if len(hits) == 1 else None


def parse_did_matrix_file(path: str | None) -> dict[str, dict[str, str]]:
    """读取 DID 检查表 sheet 303 的 DID×APP/PBL/SBL 原始矩阵。

    这里故意返回兼容旧生成器的原始值映射；语义化工作由
    :func:`build_partition_model` 中的 :class:`MatrixExpectation` 完成。
    """

    if not path:
        return {}
    try:
        import openpyxl
    except ImportError:
        return {}
    try:
        workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception:
        return {}
    if "303" not in workbook.sheetnames:
        workbook.close()
        return {}
    result: dict[str, dict[str, str]] = {}
    worksheet = workbook["303"]
    for row in worksheet.iter_rows(values_only=True):
        did = normalize_did(row[4] if len(row) > 4 else None)
        if not did:
            continue
        result[did] = {
            "APP": _clean_matrix_value(row[5] if len(row) > 5 else ""),
            "PBL": _clean_matrix_value(row[6] if len(row) > 6 else ""),
            "SBL": _clean_matrix_value(row[7] if len(row) > 7 else ""),
        }
    workbook.close()
    return result


def _survey_did_specs(parsed: Mapping[str, Any] | None) -> dict[str, dict[str, Any]]:
    records: dict[str, dict[str, Any]] = {}
    for item in (parsed or {}).get("dids", []) if isinstance(parsed, Mapping) else []:
        if not isinstance(item, Mapping):
            continue
        did = normalize_did(item.get("did_number") or item.get("did"))
        if not did:
            continue
        # 多份调查表可能重复定义同一 DID；保留信息量较高的记录，且不要
        # 用 Unknown DID 覆盖已有的真实名称。
        old = records.get(did)
        if old is None or (str(old.get("did_name", "")).lower() == "unknown did" and
                           str(item.get("did_name", "")).lower() != "unknown did"):
            records[did] = dict(item)
    defaulted: dict[str, set[str]] = {}
    for item in (parsed or {}).get("defaults_used", []) if isinstance(parsed, Mapping) else []:
        if not isinstance(item, Mapping):
            continue
        did = normalize_did(item.get("did") or item.get("io_did"))
        if not did:
            continue
        fields = defaulted.setdefault(did, set())
        for entry in item.get("defaults", []) or []:
            if isinstance(entry, (list, tuple)) and entry:
                fields.add(str(entry[0]))
    for did, item in records.items():
        fields = defaulted.get(did, set())
        item["_defaulted_fields"] = tuple(sorted(fields))
    return records


def build_partition_model(
    *,
    did_matrix: Mapping[str, Mapping[str, Any]] | None = None,
    parsed: Mapping[str, Any] | None = None,
    source_files: tuple[str, ...] = (),
    diagnostic_sources: Mapping[str, tuple[str, ...]] | None = None,
    conditional_nrcs: Mapping[str, Mapping[str, Any]] | None = None,
    timing_parameters: Mapping[str, Mapping[str, Any]] | None = None,
) -> PartitionModel:
    """由 DID 检查矩阵和调查表 JSON 构造统一分区模型。

    ``did_matrix`` 保持兼容 ``gen_case_scripts.parse_did_matrix`` 的结构：
    ``{DID: {APP: value, PBL: value, SBL: value}}``。
    """

    raw_matrix: dict[str, Mapping[str, Any]] = {}
    for raw_did, values in (did_matrix or {}).items():
        normalized = normalize_did(raw_did)
        if normalized and isinstance(values, Mapping):
            raw_matrix[normalized] = values
    survey = _survey_did_specs(parsed)
    did_ids = {normalize_did(did) for did in raw_matrix}
    did_ids.update(survey)
    did_ids.discard(None)

    sources = diagnostic_sources or {}
    conditional_source = (
        conditional_nrcs if conditional_nrcs is not None else DEFAULT_CONDITIONAL_NRCS
    )

    def _nrc_value(value: Any) -> int | None:
        try:
            if isinstance(value, str):
                return int(value.strip(), 0)
            return int(value)
        except (TypeError, ValueError):
            return None

    conditional: dict[str, dict[str, tuple[int, ...]]] = {}
    for raw_did, partitions_for_did in conditional_source.items():
        did = normalize_did(raw_did)
        if not did or not isinstance(partitions_for_did, Mapping):
            continue
        partition_map: dict[str, tuple[int, ...]] = {}
        for raw_partition, values in partitions_for_did.items():
            partition = normalize_partition(raw_partition)
            if not partition:
                continue
            if isinstance(values, (str, bytes)):
                values = (values,)
            try:
                nrcs = tuple(sorted({nrc for nrc in (_nrc_value(value) for value in values) if nrc is not None}))
            except TypeError:
                nrcs = ()
            if nrcs:
                partition_map[partition] = nrcs
        if partition_map:
            conditional[did] = partition_map
    partitions: dict[str, PartitionSpec] = {}
    display = {"APP": "Application", "PBL": "Primary Boot Loader", "SBL": "Secondary Boot Loader"}
    aliases = {key: tuple(sorted(PARTITION_ALIASES[key])) for key in PARTITIONS}
    for name in PARTITIONS:
        partitions[name] = PartitionSpec(
            name=name,
            display_name=display[name],
            aliases=aliases[name],
            diagnostic_sources=tuple(sources.get(name, ())),
        )

    dids: dict[str, DidSpec] = {}
    for did in sorted(did_ids):
        survey_item = survey.get(did, {})
        matrix_item = raw_matrix.get(did, {})
        if not isinstance(matrix_item, Mapping):
            matrix_item = {}
        matrix = {
            partition: MatrixExpectation.from_value(matrix_item.get(partition, ""))
            for partition in PARTITIONS
        }
        for partition, expectation in matrix.items():
            allowed = conditional.get(did, {}).get(partition, ())
            if allowed and expectation.kind == "positive":
                matrix[partition] = MatrixExpectation(
                    raw=expectation.raw,
                    defined=expectation.defined,
                    supported=expectation.supported,
                    kind=expectation.kind,
                    expected_nrc=expectation.expected_nrc,
                    expected_value=expectation.expected_value,
                    conditional_nrc=tuple(sorted(set(allowed))),
                )
        dids[did] = DidSpec(
            did=did,
            name=str(survey_item.get("did_name", "") or ""),
            name_cn=str(survey_item.get("did_name_cn", "") or ""),
            rw_state=str(survey_item.get("rw_state", "") or ""),
            size_bytes=survey_item.get("size_bytes"),
            read_sessions=dict(survey_item.get("read_sessions") or {}),
            write_sessions=dict(survey_item.get("write_sessions") or {}),
            read_security=dict(survey_item.get("read_security") or {}),
            write_security=dict(survey_item.get("write_security") or {}),
            matrix=matrix,
            source_references=tuple(source_files),
            attributes_provisional=(
                str(survey_item.get("did_name", "") or "").strip().lower() == "unknown did"
                or bool(survey_item.get("_defaulted_fields"))
            ),
            defaulted_fields=tuple(survey_item.get("_defaulted_fields") or ()),
        )
    timing_source = timing_parameters if timing_parameters is not None else DEFAULT_TIMING_PARAMETERS
    return PartitionModel(
        partitions=partitions,
        dids=dids,
        source_files=tuple(source_files),
        # “矩阵已加载但该 DID 三个分区都为空”与“没有加载矩阵”必须
        # 区分，否则 F190 这类全分区未定义的 DID 会绕过分区门禁。
        matrix_loaded=bool(raw_matrix),
        timing_parameters=_normalize_timing_parameters(timing_source),
    )


def _normalize_timing_parameters(
    source: Mapping[str, Mapping[str, Any]] | None,
) -> dict[str, dict[str, Any]]:
    """Normalize timing values while preserving provenance strings."""

    normalized: dict[str, dict[str, Any]] = {}
    for raw_partition, values in (source or {}).items():
        partition = normalize_partition(raw_partition)
        if not partition or not isinstance(values, Mapping):
            continue
        output: dict[str, Any] = {}
        for key, value in values.items():
            if value is None:
                continue
            if str(key) == "source":
                output[str(key)] = str(value)
                continue
            try:
                output[str(key)] = float(value)
            except (TypeError, ValueError):
                continue
        normalized[partition] = output
    return normalized


__all__ = [
    "DidSpec",
    "MatrixExpectation",
    "PARTITIONS",
    "DEFAULT_CONDITIONAL_NRCS",
    "DEFAULT_TIMING_PARAMETERS",
    "PartitionModel",
    "PartitionSpec",
    "build_partition_model",
    "infer_case_partition",
    "normalize_did",
    "normalize_partition",
    "normalize_session",
    "parse_did_matrix_file",
]
