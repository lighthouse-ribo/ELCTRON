"""业务流程边界契约。

本模块只定义流程身份、服务边界和运行上下文，不执行硬件访问，也不实现
SWDL 业务逻辑。现有 Basic UDS 流程可以继续使用原有脚本；后续新增 SWDL
时，沿同一契约实现独立流程，避免把刷写步骤混入普通诊断流程。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any, Mapping


class FlowKind(str, Enum):
    """当前专家模块支持/预留的互斥业务流程。"""

    BASIC_UDS = "basic_uds"
    SWDL = "swdl"
    CYBERSECURITY = "cybersecurity"


@dataclass(frozen=True)
class FlowDefinition:
    """流程的静态边界；只描述，不执行。"""

    kind: FlowKind
    display_name: str
    implemented: bool
    allowed_services: tuple[str, ...]
    mutation_services: tuple[str, ...]
    approval_required: bool
    description: str


FLOW_REGISTRY: dict[FlowKind, FlowDefinition] = {
    FlowKind.BASIC_UDS: FlowDefinition(
        kind=FlowKind.BASIC_UDS,
        display_name="Basic UDS 基础诊断",
        implemented=True,
        allowed_services=("0x10", "0x11", "0x14", "0x22", "0x27", "0x2E", "0x2F", "0x31", "0x3E"),
        mutation_services=("0x11", "0x14", "0x2E", "0x2F", "0x31"),
        approval_required=False,
        description="现有需求解析、用例生成、VickCAN/F1L1执行和trace判定流程。",
    ),
    FlowKind.SWDL: FlowDefinition(
        kind=FlowKind.SWDL,
        display_name="SWDL 软件下载",
        implemented=True,
        # 当前仅实现下载；0x35 RequestUpload 保留到后续独立上传流程，
        # 不能在契约层宣称已经支持。
        allowed_services=("0x10", "0x11", "0x27", "0x31", "0x34", "0x36", "0x37", "0x3E"),
        mutation_services=("0x11", "0x31", "0x34", "0x36", "0x37"),
        approval_required=True,
        description="已实现 VickCAN/F1L1 下载编排；0x35 上传尚未实现。镜像、认证、密钥和显式审批缺一则 BLOCKED。",
    ),
    FlowKind.CYBERSECURITY: FlowDefinition(
        kind=FlowKind.CYBERSECURITY,
        display_name="车载网络安全",
        implemented=False,
        # 安全服务必须由安全需求/威胁模型和ECU支持矩阵确定，不能在此处臆测。
        allowed_services=(),
        mutation_services=(),
        approval_required=True,
        description="仅预留流程边界；需要独立安全需求和攻击测试授权。",
    ),
}


def normalize_flow(value: str | FlowKind | None) -> FlowKind:
    """将用户输入解析为单一流程；拒绝组合流程，保证一次只运行一个流程。"""

    if isinstance(value, FlowKind):
        return value
    raw = str(value or FlowKind.BASIC_UDS.value).strip().lower()
    if not raw:
        return FlowKind.BASIC_UDS
    if any(separator in raw for separator in (",", ";", "|")):
        raise ValueError("一次运行只能选择一个流程：basic_uds、swdl 或 cybersecurity")
    aliases = {
        "basic": FlowKind.BASIC_UDS,
        "uds": FlowKind.BASIC_UDS,
        "basic_uds": FlowKind.BASIC_UDS,
        "swdl": FlowKind.SWDL,
        "cyber": FlowKind.CYBERSECURITY,
        "cybersecurity": FlowKind.CYBERSECURITY,
    }
    try:
        return aliases[raw]
    except KeyError as exc:
        allowed = ", ".join(item.value for item in FlowKind)
        raise ValueError(f"未知流程 {value!r}；可选值：{allowed}") from exc


def get_flow_definition(value: str | FlowKind | None) -> FlowDefinition:
    return FLOW_REGISTRY[normalize_flow(value)]


def build_flow_context(
    value: str | FlowKind | None,
    *,
    run_id: str,
    output_dir: str,
    project_id: str = "",
    source_files: tuple[str, ...] = (),
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """生成可写入 manifest 的运行上下文，不触碰硬件。"""

    definition = get_flow_definition(value)
    context: dict[str, Any] = {
        "run_id": run_id,
        "flow": definition.kind.value,
        "display_name": definition.display_name,
        "implemented": definition.implemented,
        "allowed_services": list(definition.allowed_services),
        "mutation_services": list(definition.mutation_services),
        "approval_required": definition.approval_required,
        "project_id": project_id,
        "output_dir": output_dir,
        "source_files": list(source_files),
        "description": definition.description,
    }
    if extra:
        context["extra"] = dict(extra)
    return context


def service_allowed(value: str | FlowKind | None, service: str | int) -> bool:
    """检查服务是否在流程白名单内；未实现流程也只做静态检查。"""

    definition = get_flow_definition(value)
    if isinstance(service, int):
        normalized = f"0x{service:02X}"
    else:
        raw = str(service).strip().lower()
        normalized = raw if raw.startswith("0x") else f"0x{int(raw, 16):02x}"
        normalized = normalized.upper().replace("X", "x")
    return normalized.lower() in {item.lower() for item in definition.allowed_services}


__all__ = [
    "FLOW_REGISTRY",
    "FlowDefinition",
    "FlowKind",
    "build_flow_context",
    "get_flow_definition",
    "normalize_flow",
    "service_allowed",
]
