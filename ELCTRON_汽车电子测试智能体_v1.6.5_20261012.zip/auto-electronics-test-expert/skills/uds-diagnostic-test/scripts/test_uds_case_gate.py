#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统一 UDS 用例门禁离线测试；不连接 CAN/LIN 硬件。"""

import json
import os
import subprocess
import sys
import unittest

from partition_model import build_partition_model
from uds_case_gate import evaluate_case
from testsupport import WorkspaceTempDir


HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.path.join(HERE, "gen_case_scripts.py")


def _case(case_id="UDS_0x22_TC_GATE", *, point="正向读取", expected="正响应",
          precondition="默认会话", partition=None):
    case = {
        "case_id": case_id,
        "test_point": point,
        "procedure": "请求: 22 D0 9B",
        "expected": expected,
        "precondition": precondition,
    }
    if partition is not None:
        case["target_partition"] = partition
    return case


CUSTOM_CONFIG = {
    "sessions": {
        "supported": ["0x01", "0x04"],
        "names": {"0x01": "Normal", "0x04": "Diag"},
        "allowed_transitions": {"0x01": ["0x01"], "0x04": ["0x01", "0x04"]},
        "default": "0x01",
        "transition_nrc": "0x24",
    },
    "security": {
        "level_to_sessions": {"0x07": ["0x04"]},
        "default_level_sessions": ["0x04"],
        "unlock_required_services": ["0x31"],
    },
    "lint": {
        "negative_keywords": ["DENY"],
        "require_nrc_for_negative": True,
        "require_session_for_security": True,
    },
}


class TestUdsCaseGate(unittest.TestCase):
    def test_f190_is_not_defined_for_any_partition(self):
        model = build_partition_model(did_matrix={
            "F190": {"APP": "", "PBL": "", "SBL": ""},
        })
        decision = evaluate_case(
            _case(point="正向读取 F190", partition="APP"),
            payload=[0x22, 0xF1, 0x90], model=model,
            service="0x22", expectation="pos", session="default",
        )
        self.assertEqual(decision.decision, "REJECT")
        self.assertIn("PART-002", {item.code for item in decision.findings})

    def test_d09b_uses_the_target_partition_matrix_expectation(self):
        model = build_partition_model(did_matrix={
            "D09B": {
                "APP": "62 D0 9B 01",
            "PBL": "01 01 01",
                "SBL": "62 D0 9B 02",
            },
        })
        app = evaluate_case(
            _case(case_id="UDS_0x22_TC_APP", partition="APP"),
            payload=[0x22, 0xD0, 0x9B], model=model,
            service="0x22", expectation="pos", session="default",
        )
        self.assertEqual(app.decision, "GENERATE")

        pbl_positive = evaluate_case(
            _case(case_id="UDS_0x22_TC_PBL_POS", partition="PBL"),
            payload=[0x22, 0xD0, 0x9B], model=model,
            service="0x22", expectation="pos", session="default",
        )
        self.assertEqual(pbl_positive.decision, "GENERATE")

        pbl_negative = evaluate_case(
            _case(case_id="UDS_0x22_TC_PBL_NEG", point="负例：PBL 不支持读取",
                  expected="负响应 NRC=0x31", partition="PBL"),
            payload=[0x22, 0xD0, 0x9B], model=model,
            service="0x22", expectation="neg", expected_nrc=[0x31],
            session="default",
        )
        self.assertEqual(pbl_negative.decision, "REJECT")
        self.assertIn("MATRIX-NEG-001", {item.code for item in pbl_negative.findings})

    def test_d03a_app_allows_condition_dependent_nrc22(self):
        decision = evaluate_case(
            _case(case_id="UDS_0x22_TC_D03A_APP", point="正向读取 DID D03A", partition="APP"),
            payload=[0x22, 0xD0, 0x3A],
            model=build_partition_model(did_matrix={
                "D03A": {"APP": "Y", "PBL": "NRC31", "SBL": "NRC31"},
            }),
            service="0x22", expectation="pos", session="default",
        )
        self.assertEqual(decision.decision, "GENERATE")
        self.assertEqual(decision.allowed_nrc, (0x22,))
        self.assertIn("MATRIX-INFO-001", {item.code for item in decision.findings})

    def test_f190_positive_is_rejected_even_without_explicit_partition(self):
        decision = evaluate_case(
            _case(case_id="UDS_0x22_TC_F190", point="正向读取 DID F190"),
            payload=[0x22, 0xF1, 0x90],
            model=build_partition_model(did_matrix={
                "F190": {"APP": "", "PBL": "", "SBL": ""},
            }),
            service="0x22", expectation="pos", session="default",
        )
        self.assertEqual(decision.decision, "REJECT")
        self.assertIn("DID-003", {item.code for item in decision.findings})

    def test_positive_did_requires_an_explicit_target_partition(self):
        model = build_partition_model(did_matrix={
            "D09B": {"APP": "Y", "PBL": "NRC31", "SBL": "Y"},
        })
        decision = evaluate_case(
            _case(), payload=[0x22, 0xD0, 0x9B], model=model,
            service="0x22", expectation="pos", session="default",
        )
        self.assertEqual(decision.decision, "REVIEW_REQUIRED")
        self.assertIn("PART-001", {item.code for item in decision.findings})

    def test_read_only_did_cannot_be_written(self):
        model = build_partition_model(
            did_matrix={"F18C": {"APP": "Y", "PBL": "Y", "SBL": "Y"}},
            parsed={"dids": [{
                "did_number": "F18C",
                "did_name": "ECU Serial Number",
                "rw_state": "R",
            }]},
        )
        case = _case(case_id="UDS_0x2E_TC_READ_ONLY", point="正向写入只读 DID")
        case["procedure"] = "请求: 2E F1 8C 00"
        decision = evaluate_case(
            case, payload=[0x2E, 0xF1, 0x8C, 0x00], model=model,
            service="0x2E", expectation="pos", session="default",
            target_partition="APP",
        )
        self.assertEqual(decision.decision, "REJECT")
        self.assertIn("RW-002", {item.code for item in decision.findings})

    def test_missing_key_does_not_block_seed_request(self):
        case = {
            "case_id": "UDS_0x27_TC_SEED",
            "test_point": "请求 Seed",
            "procedure": "请求: 27 05",
            "expected": "正响应",
            "precondition": "扩展会话",
        }
        decision = evaluate_case(
            case, payload=[0x27, 0x05], model=build_partition_model(),
            service="0x27", expectation="pos", session="extended",
            key_ready=False,
        )
        self.assertEqual(decision.decision, "GENERATE")
        self.assertNotIn("SA-003", {item.code for item in decision.findings})

    def test_missing_key_blocks_key_request(self):
        case = {
            "case_id": "UDS_0x27_TC_KEY",
            "test_point": "发送正确 Key",
            "procedure": "请求: 27 06 + Key",
            "expected": "正响应",
            "precondition": "扩展会话",
        }
        decision = evaluate_case(
            case, payload=[0x27, 0x06], model=build_partition_model(),
            service="0x27", expectation="pos", session="extended",
            key_ready=False,
        )
        self.assertEqual(decision.decision, "BLOCKED")
        codes = [item.code for item in decision.findings]
        self.assertEqual(codes.count("SA-003"), 1)
        self.assertTrue(decision.blocking)

    def test_missing_key_blocks_explicitly_unlocked_write_service(self):
        case = {
            "case_id": "UDS_0x2E_TC_UNLOCKED_WRITE",
            "test_point": "需解锁后正向写入",
            "procedure": "请求: 2E F1 0A 00",
            "expected": "正响应",
            "precondition": "扩展会话，先完成 0x27 解锁",
        }
        decision = evaluate_case(
            case, payload=[0x2E, 0xF1, 0x0A, 0x00],
            model=build_partition_model(did_matrix={
                "F10A": {"APP": "Y", "PBL": "Y", "SBL": "Y"},
            }),
            service="0x2E", expectation="pos", session="extended",
            target_partition="APP", key_ready=False,
        )
        self.assertEqual(decision.decision, "BLOCKED")
        self.assertIn("SEC-001", {item.code for item in decision.findings})

    def test_all_security_dependent_services_block_positive_paths_without_key(self):
        protected = {
            "0x14": [0x14, 0xFF, 0xFF, 0xFF],
            "0x2E": [0x2E, 0xF1, 0x0A, 0x00],
            "0x31": [0x31, 0x01, 0xFF, 0x00],
            "0x2F": [0x2F, 0xF1, 0x90, 0x03],
            "0x34": [0x34, 0x00, 0x44, 0x00, 0x00, 0x00, 0x00],
            "0x36": [0x36, 0x01, 0x00],
            "0x37": [0x37],
        }
        for service, payload in protected.items():
            with self.subTest(service=service):
                decision = evaluate_case(
                    {
                        "case_id": f"UDS_{service}_TC_PROTECTED",
                        "test_point": f"{service} 正向请求",
                        "procedure": "请求：" + " ".join(f"{byte:02X}" for byte in payload),
                        "expected": "正响应",
                        "precondition": "编程会话，先完成 0x27 解锁",
                    },
                    payload=payload,
                    model=build_partition_model(),
                    service=service,
                    expectation="pos",
                    session="programming",
                    key_ready=False,
                )
                self.assertEqual(decision.decision, "BLOCKED")
                self.assertIn("SEC-001", {item.code for item in decision.findings})

    def test_locked_negative_path_can_verify_rejection(self):
        decision = evaluate_case(
            {
                "case_id": "UDS_0x2F_TC_LOCKED_NEG",
                "test_point": "0x2F 未解锁负例",
                "procedure": "请求：2F F1 90 03",
                "expected": "负响应 NRC=0x33",
                "precondition": "编程会话，未执行 0x27",
            },
            payload=[0x2F, 0xF1, 0x90, 0x03],
            model=build_partition_model(),
            service="0x2F",
            expectation="neg",
            expected_nrc=[0x33],
            session="programming",
            key_ready=False,
        )
        self.assertEqual(decision.decision, "NEGATIVE")
        self.assertIn("SEC-NEG-INFO", {item.code for item in decision.findings})

    def test_negative_nrc_must_match_the_partition_matrix(self):
        model = build_partition_model(did_matrix={
            "D09B": {"APP": "Y", "PBL": "NRC31", "SBL": "Y"},
        })
        decision = evaluate_case(
            _case(case_id="UDS_0x22_TC_NRC_MISMATCH", point="负例：PBL 不支持读取",
                  expected="负响应 NRC=0x22", partition="PBL"),
            payload=[0x22, 0xD0, 0x9B], model=model,
            service="0x22", expectation="neg", expected_nrc=[0x22],
            session="default",
        )
        self.assertEqual(decision.decision, "REJECT")
        self.assertIn("NRC-001", {item.code for item in decision.findings})

    def test_did_session_restriction_is_checked(self):
        model = build_partition_model(
            did_matrix={"D09B": {"APP": "Y", "PBL": "Y", "SBL": "Y"}},
            parsed={"dids": [{
                "did_number": "D09B",
                "did_name": "Software Version",
                "rw_state": "R",
                "read_sessions": {
                    "default_0x01": "N",
                    "programming_0x02": "N",
                    "extended_0x03": "Y",
                },
            }]},
        )
        decision = evaluate_case(
            _case(partition="APP"), payload=[0x22, 0xD0, 0x9B], model=model,
            service="0x22", expectation="pos", session="default",
        )
        self.assertEqual(decision.decision, "REJECT")
        self.assertIn("SESSION-001", {item.code for item in decision.findings})

    def test_default_to_programming_is_an_allowed_positive_transition(self):
        allowed = evaluate_case(
            _case(
                case_id="UDS_0x10_TC_DEFAULT_TO_PROGRAMMING",
                point="正向：默认会话直接切换到编程会话",
                expected="DUT正响应",
                precondition="默认会话",
            ),
            payload=[0x10, 0x02],
            model=build_partition_model(),
            service="0x10",
            expectation="pos",
            session="default",
        )
        self.assertEqual(allowed.decision, "GENERATE")
        self.assertNotIn("SESSION-TRANS-001", {item.code for item in allowed.findings})

    def test_programming_to_extended_is_forbidden_but_extended_to_programming_is_allowed(self):
        forbidden = evaluate_case(
            _case(
                case_id="UDS_0x10_TC_PROGRAMMING_TO_EXTENDED",
                point="负向：编程会话不能直接切换到扩展会话",
                expected="DUT负响应：NRC=0x22",
                precondition="编程会话",
            ),
            payload=[0x10, 0x03],
            model=build_partition_model(),
            service="0x10",
            expectation="neg",
            expected_nrc=[0x22],
            session="programming",
        )
        self.assertEqual(forbidden.decision, "NEGATIVE")

        allowed = evaluate_case(
            _case(
                case_id="UDS_0x10_TC_EXTENDED_TO_PROGRAMMING",
                point="扩展会话切换到编程会话",
                expected="正响应",
                precondition="扩展会话",
            ),
            payload=[0x10, 0x02],
            model=build_partition_model(),
            service="0x10",
            expectation="pos",
            session="extended",
        )
        self.assertEqual(allowed.decision, "GENERATE")

    def test_report_mode_records_gate_without_changing_case_status(self):
        # report 语义是只记录；enforce 才把门禁决策编译为 blocked。
        from openpyxl import Workbook

        with WorkspaceTempDir("gate-report") as td:
            cases_path = os.path.join(td, "cases.json")
            parsed_path = os.path.join(td, "parsed.json")
            matrix_path = os.path.join(td, "DID检查.xlsx")
            report_dir = os.path.join(td, "report")
            enforce_dir = os.path.join(td, "enforce")
            case = _case(case_id="UDS_0x22_TC_REPORT", partition="PBL")
            with open(cases_path, "w", encoding="utf-8") as handle:
                json.dump({"cases": [case]}, handle, ensure_ascii=False)
            with open(parsed_path, "w", encoding="utf-8") as handle:
                json.dump({}, handle)
            workbook = Workbook()
            worksheet = workbook.active
            worksheet.title = "303"
            worksheet.cell(row=1, column=5, value="D09B")
            worksheet.cell(row=1, column=6, value="Y")
            worksheet.cell(row=1, column=7, value="NRC31")
            worksheet.cell(row=1, column=8, value="Y")
            workbook.save(matrix_path)

            base = [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
                    "--did-check", matrix_path, "--target-partition", "PBL",
                    "--bus", "can", "--confirmed"]
            report = subprocess.run(base + ["--partition-gate", "report", "--out-dir", report_dir],
                                    capture_output=True, text=True, encoding="utf-8", errors="replace")
            self.assertEqual(report.returncode, 0, report.stderr)
            with open(os.path.join(report_dir, "manifest.json"), encoding="utf-8") as handle:
                report_manifest = json.load(handle)
            report_meta = report_manifest["cases"][case["case_id"]]
            self.assertEqual(report_meta["status"], "pos")
            self.assertEqual(report_meta["gate_decision"]["decision"], "REJECT")

            enforce = subprocess.run(base + ["--partition-gate", "enforce", "--out-dir", enforce_dir],
                                     capture_output=True, text=True, encoding="utf-8", errors="replace")
            self.assertEqual(enforce.returncode, 0, enforce.stderr)
            with open(os.path.join(enforce_dir, "manifest.json"), encoding="utf-8") as handle:
                enforce_manifest = json.load(handle)
            self.assertEqual(enforce_manifest["cases"][case["case_id"]]["status"], "blocked")

    def test_custom_transition_matrix_and_transition_nrc_are_runtime_sources(self):
        case = _case(
            case_id="UDS_0x10_TC_CUSTOM_NEG",
            point="DENY 会话跳转",
            expected="负响应 NRC=0x24",
            precondition="Normal",
        )
        decision = evaluate_case(
            case, payload=[0x10, 0x04], model=build_partition_model(),
            service="0x10", expectation="neg", expected_nrc=[0x24],
            session="0x01", project_config=CUSTOM_CONFIG,
        )
        self.assertEqual(decision.decision, "NEGATIVE")
        self.assertNotIn("SESSION-TRANS-001", {item.code for item in decision.findings})

        mismatch = evaluate_case(
            case, payload=[0x10, 0x04], model=build_partition_model(),
            service="0x10", expectation="neg", expected_nrc=[0x22],
            session="0x01", project_config=CUSTOM_CONFIG,
        )
        self.assertEqual(mismatch.decision, "REJECT")
        self.assertIn("0x24", mismatch.reason)

    def test_custom_security_mapping_and_protected_services_are_runtime_sources(self):
        allowed = evaluate_case(
            _case(case_id="UDS_0x27_TC_CUSTOM", point="安全访问 等级0x07 正向",
                  precondition="Diag"),
            payload=[0x27, 0x07], model=build_partition_model(),
            service="0x27", expectation="pos", session="0x04",
            key_ready=True, project_config=CUSTOM_CONFIG,
        )
        self.assertEqual(allowed.decision, "GENERATE")
        self.assertNotIn("SA-002", {item.code for item in allowed.findings})

        protected = evaluate_case(
            _case(case_id="UDS_0x31_TC_CUSTOM", point="0x31 正向",
                  precondition="Diag"),
            payload=[0x31, 0x01, 0xFF, 0x00], model=build_partition_model(),
            service="0x31", expectation="pos", session="0x04",
            key_ready=False, project_config=CUSTOM_CONFIG,
        )
        self.assertEqual(protected.decision, "BLOCKED")
        self.assertIn("SEC-001", {item.code for item in protected.findings})

        unprotected = evaluate_case(
            _case(case_id="UDS_0x2E_TC_CUSTOM", point="0x2E 正向",
                  precondition="Diag"),
            payload=[0x2E, 0xF1, 0x2E, 0x00], model=build_partition_model(),
            service="0x2E", expectation="pos", session="0x04",
            key_ready=False, project_config=CUSTOM_CONFIG,
        )
        self.assertEqual(unprotected.decision, "GENERATE")

        protected_write_config = dict(CUSTOM_CONFIG)
        protected_write_config["security"] = dict(
            CUSTOM_CONFIG["security"], unlock_required_services=["0x2E"]
        )
        missing_session = evaluate_case(
            _case(case_id="UDS_0x2E_TC_CUSTOM_NO_SESSION", point="0x2E 正向",
                  precondition="供电 12V"),
            payload=[0x2E, 0xF1, 0x2E, 0x00], model=build_partition_model(),
            service="0x2E", expectation="pos", session="0x04",
            key_ready=True, project_config=protected_write_config,
        )
        self.assertEqual(missing_session.decision, "REJECT")
        self.assertIn("SEC-002", {item.code for item in missing_session.findings})

    def test_unmapped_security_level_uses_configured_default_session_policy(self):
        case = _case(
            case_id="UDS_0x27_TC_CUSTOM_DEFAULT_LEVEL",
            point="安全访问 等级0x09 正向",
            precondition="Normal",
        )
        decision = evaluate_case(
            case, payload=[0x27, 0x09], model=build_partition_model(),
            service="0x27", expectation="pos", session="0x01",
            key_ready=True, project_config=CUSTOM_CONFIG,
        )
        self.assertEqual(decision.decision, "REJECT")
        self.assertIn("SA-002", {item.code for item in decision.findings})

    def test_custom_negative_keyword_and_optional_requirements(self):
        negative = evaluate_case(
            _case(case_id="UDS_0x22_TC_CUSTOM_NEG", point="DENY",
                  expected="负响应"),
            payload=[0x22, 0xD0, 0x9B], model=build_partition_model(),
            service="0x22", project_config=CUSTOM_CONFIG,
        )
        self.assertEqual(negative.decision, "REJECT")
        self.assertIn("NRC-003", {item.code for item in negative.findings})

        optional = dict(CUSTOM_CONFIG)
        optional["lint"] = dict(CUSTOM_CONFIG["lint"],
                                 require_nrc_for_negative=False,
                                 require_session_for_security=False)
        case = _case(case_id="UDS_0x27_TC_OPTIONAL", point="安全访问 等级0x07 正向",
                     expected="正响应", precondition="供电 12V")
        decision = evaluate_case(
            case, payload=[0x27, 0x07], model=build_partition_model(),
            service="0x27", expectation="pos", session=None,
            key_ready=True, project_config=optional,
        )
        self.assertEqual(decision.decision, "GENERATE")


if __name__ == "__main__":
    unittest.main(verbosity=2)
