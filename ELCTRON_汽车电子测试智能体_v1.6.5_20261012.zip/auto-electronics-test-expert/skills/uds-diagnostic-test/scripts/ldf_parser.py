#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LDF (LIN Description File) 解析器 —— LIN 网络权威输入（对应 CAN 的 DBC）
=========================================================================
读取 LDF → 输出 lin_db.json（帧/受保护ID PID/信号/调度表/节点属性/信号编码），
供用例报文级步骤生成与 LIN 通信测试使用。无需第三方依赖。

支持：无条件帧 / 偶发帧 / 事件触发帧 / 诊断帧（0x3C/0x3D）；
信号偏移按 LDF 位偏移（LSB0，与 DBC start bit 同约定）；
PID 奇偶位按 LIN 规范计算：P0 = ID0^ID1^ID2^ID4，P1 = ¬(ID1^ID3^ID4^ID5)。

用法:
  python ldf_parser.py --input cluster.ldf --output lin_db.json
  python ldf_parser.py --input cluster.ldf --output lin_db.json --frame 0x28 --signal BBSPartNoNr1
"""

__version__ = "1.0.0"

import argparse
import json
import os
import re
import sys

from lin_tp import compute_pid


def strip_comments(text):
    """去除 /* */ 块注释与 // 行注释"""
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"//[^\n]*", "", text)
    return text


def extract_block(text, name):
    """提取顶层块 `name { ... }` 的内部文本（支持嵌套花括号）"""
    m = re.search(r"\b" + re.escape(name) + r"\s*\{", text)
    if not m:
        return None
    i = m.end()
    depth = 1
    j = i
    while j < len(text) and depth:
        if text[j] == "{":
            depth += 1
        elif text[j] == "}":
            depth -= 1
        j += 1
    return text[i:j - 1] if depth == 0 else text[i:]


def parse_int(v):
    """兼容 0x28 / 60 / 0x3C 形式；诊断帧 ID 常为十进制（60=0x3C）"""
    s = str(v).strip()
    try:
        return int(s, 16) if s.lower().startswith("0x") else int(s, 10)
    except ValueError:
        return None


def parse_float(v):
    try:
        return float(str(v).strip().replace("ms", "").strip())
    except (TypeError, ValueError):
        return None


def parse_nodes(text):
    nodes = {"master": None, "slaves": []}
    for line in text.splitlines():
        line = line.strip()
        m = re.match(r"Master\s*:\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*([\d.]+)\s*ms\s*,\s*([\d.]+)\s*ms\s*;", line)
        if m:
            nodes["master"] = {
                "name": m.group(1),
                "time_base_ms": parse_float(m.group(2)),
                "jitter_ms": parse_float(m.group(3)),
            }
            continue
        m = re.match(r"Slaves\s*:\s*(.+?);", line)
        if m:
            nodes["slaves"] = [s.strip() for s in m.group(1).split(",") if s.strip()]
    return nodes


def parse_signal_entries(block_text, with_publisher=True):
    """解析 Signals / Diagnostic_signals 块
    Signals:  name: size, initial, publisher, subscriber...;
    Diagnostic: name: size, initial;
    """
    out = []
    for line in block_text.splitlines():
        line = line.strip().rstrip(";").strip()
        if not line:
            continue
        m = re.match(r"([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.+)", line)
        if not m:
            continue
        name, rest = m.group(1), m.group(2)
        parts = [p.strip() for p in rest.split(",")]
        entry = {"name": name, "size": parse_int(parts[0]) if parts else None,
                 "initial_value": parse_int(parts[1]) if len(parts) > 1 else None}
        if with_publisher and len(parts) >= 3:
            entry["publisher"] = parts[2]
            entry["subscribers"] = [p for p in parts[3:] if p]
        out.append(entry)
    return out


def parse_frames(block_text, frame_type="unconditional"):
    """解析帧定义块：
    name: 0x28, BBS, 7 {  signal, offset; ...  }
    name: 60 { ... }          # 诊断帧 ID 为十进制（60=0x3C）
    """
    frames = []
    pattern = re.compile(
        r"([A-Za-z_][A-Za-z0-9_]*)\s*:\s*([^,{]+?)\s*(?:,\s*([^,{]+?)\s*,\s*([^,{]+?))?\s*\{"
        r"(.*?)\n\s*\}", re.S)
    for m in pattern.finditer(block_text):
        name, id_str, pub, length_str, inner = m.group(1), m.group(2), m.group(3), m.group(4), m.group(5)
        fid = parse_int(id_str)
        if fid is None:
            continue
        sigs = []
        for sline in inner.splitlines():
            sline = sline.strip().rstrip(";").strip()
            sm = re.match(r"([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(\d+)\s*$", sline)
            if sm:
                sigs.append({"name": sm.group(1), "offset": int(sm.group(2))})
        frame = {
            "name": name,
            "frame_id": fid,
            "frame_id_hex": "0x{:02X}".format(fid),
            "pid": compute_pid(fid),
            "pid_hex": "0x{:02X}".format(compute_pid(fid)),
            "frame_type": frame_type,
            "length": parse_int(length_str) if length_str is not None else (8 if frame_type == "diagnostic" else 0),
            "publisher": pub.strip() if pub else "",
            "signals": sigs,
        }
        frames.append(frame)
    return frames


def parse_node_attributes(block_text):
    """解析 Node_attributes 块：节点名 { 属性; configurable_frames { ... } }"""
    nodes = {}
    pattern = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)\s*\{(.*?)\n\s*\}", re.S)
    for m in pattern.finditer(block_text):
        node_name, inner = m.group(1), m.group(2)
        attr = {}
        for kv in re.finditer(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([^;]+);", inner):
            key, val = kv.group(1), kv.group(2).strip().strip('"')
            if key in ("configured_NAD", "initial_NAD"):
                attr[key] = val
            elif key == "product_id":
                pid_parts = [p.strip() for p in val.split(",")]
                attr["product_id"] = {
                    "vendor_id": pid_parts[0] if len(pid_parts) > 0 else "",
                    "functional_id": pid_parts[1] if len(pid_parts) > 1 else "",
                    "variant": pid_parts[2] if len(pid_parts) > 2 else "",
                }
            elif key in ("P2_min", "ST_min"):
                attr[key] = val
            else:
                attr[key] = val
        m2 = re.search(r"configurable_frames\s*\{(.*?)\}", inner, re.S)
        if m2:
            attr["configurable_frames"] = [l.strip().rstrip(";").strip()
                                           for l in m2.group(1).splitlines() if l.strip()]
        # 单行无花括号属性（如 response_error = ErrRespBBS;）已由 kv 正则覆盖
        nodes[node_name] = attr
    return nodes


def parse_schedule_tables(block_text):
    """解析 Schedule_tables 块：表名 { 帧名 delay 10.000 ms; ... }"""
    tables = {}
    pattern = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)\s*\{(.*?)\n\s*\}", re.S)
    for m in pattern.finditer(block_text):
        table_name, inner = m.group(1), m.group(2)
        entries = []
        for em in re.finditer(r"([A-Za-z_][A-Za-z0-9_]*)\s+delay\s+([\d.]+)\s*ms\s*;", inner):
            entries.append({"frame": em.group(1), "delay_ms": parse_float(em.group(2))})
        if entries:
            tables[table_name] = entries
    return tables


def parse_encoding_types(block_text):
    """解析 Signal_encoding_types 块（logical_value / physical_value）"""
    enc = {}
    pattern = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)\s*\{(.*?)\n\s*\}", re.S)
    for m in pattern.finditer(block_text):
        enc_name, inner = m.group(1), m.group(2)
        entries = []
        for em in re.finditer(r"(logical_value|physical_value)\s*,\s*(.+?);", inner, re.S):
            vals = [v.strip().strip('"') for v in em.group(2).split(",")]
            entries.append({"type": em.group(1), "values": vals})
        if entries:
            enc[enc_name] = entries
    return enc


def parse_representation(block_text):
    """解析 Signal_representation 块：编码类型 : 信号1, 信号2;"""
    rep = {}
    for em in re.finditer(r"([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.+?);", block_text, re.S):
        rep[em.group(1)] = [s.strip() for s in em.group(2).split(",") if s.strip()]
    return rep


def validate_frames(frames):
    """校验：帧 ID ≤ 0x3F、信号位不越界、PID 非 0x00/0xFF"""
    warnings = []
    for f in frames:
        if f["frame_id"] > 0x3F:
            warnings.append(f"帧 {f['name']} ID 0x{f['frame_id']:X} 超出 0x00~0x3F")
        if f["pid"] in (0x00, 0xFF):
            warnings.append(f"帧 {f['name']} PID 0x{f['pid']:02X} 非法（全 0/全 1）")
        flen_bits = f["length"] * 8
        for s in f["signals"]:
            size = None
            if s["name"] in globals().get("_signal_sizes", {}):
                size = _signal_sizes[s["name"]]
            if size is not None and s["offset"] + size > flen_bits:
                warnings.append(
                    f"帧 {f['name']} 信号 {s['name']} 越界：offset={s['offset']} size={size} > 帧长 {flen_bits} bit")
    return warnings


def parse_ldf(filepath, frame_filter=None, signal_filter=None):
    """解析 LDF 文件，输出标准化 lin_db.json"""
    text = strip_comments(open(filepath, "r", encoding="utf-8-sig", errors="replace").read())

    def global_value(key):
        m = re.search(r"\b" + re.escape(key) + r"\s*=\s*([^;]+);", text)
        return m.group(1).strip().strip('"') if m else ""

    speed_raw = global_value("LIN_speed")
    speed_bps = 0
    m = re.search(r"([\d.]+)\s*(kbps|bps)", speed_raw, re.I)
    if m:
        speed_bps = int(float(m.group(1)) * 1000) if m.group(2).lower() == "kbps" else int(float(m.group(1)))

    nodes = parse_nodes(extract_block(text, "Nodes") or "")
    signals = parse_signal_entries(extract_block(text, "Signals") or "")
    diag_signals = parse_signal_entries(extract_block(text, "Diagnostic_signals") or "", with_publisher=False)

    # 汇总信号尺寸，供帧内越界校验
    global _signal_sizes
    _signal_sizes = {s["name"]: s["size"] for s in signals + diag_signals}

    frames = []
    frames += parse_frames(extract_block(text, "Frames") or "", frame_type="unconditional")
    frames += parse_frames(extract_block(text, "Diagnostic_frames") or "", frame_type="diagnostic")
    # 偶发帧/事件触发帧：结构不同，做兼容解析（帧 ID/发布者可能缺失）
    for section, ftype in (("Sporadic_frames", "sporadic"), ("Event_triggered_frames", "event_triggered")):
        blk = extract_block(text, section)
        if blk:
            for em in re.finditer(r"([A-Za-z_][A-Za-z0-9_]*)\s*:\s*([^,{]+?)(?:\s*,\s*([^,{]+?)\s*,\s*([^,{]+?))?\s*\{", blk):
                fid = parse_int(em.group(2))
                if fid is not None:
                    frames.append({
                        "name": em.group(1), "frame_id": fid, "frame_id_hex": "0x{:02X}".format(fid),
                        "pid": compute_pid(fid), "pid_hex": "0x{:02X}".format(compute_pid(fid)),
                        "frame_type": ftype,
                        "length": parse_int(em.group(4)) if em.group(4) else 0,
                        "publisher": em.group(3).strip() if em.group(3) else "",
                        "signals": [],
                    })

    if frame_filter is not None:
        frames = [f for f in frames if f["frame_id"] == frame_filter]
    if signal_filter:
        for f in frames:
            f["signals"] = [s for s in f["signals"] if s["name"] == signal_filter]

    warnings = validate_frames(frames)

    result = {
        "source_file": os.path.basename(filepath),
        "lin_protocol_version": global_value("LIN_protocol_version"),
        "lin_language_version": global_value("LIN_language_version"),
        "lin_speed_raw": speed_raw,
        "lin_speed_bps": speed_bps,
        "channel_name": global_value("Channel_name"),
        "master": nodes["master"],
        "slaves": nodes["slaves"],
        "nodes": parse_node_attributes(extract_block(text, "Node_attributes") or ""),
        "signals": signals,
        "diagnostic_signals": diag_signals,
        "frames": frames,
        "schedule_tables": parse_schedule_tables(extract_block(text, "Schedule_tables") or ""),
        "signal_encoding_types": parse_encoding_types(extract_block(text, "Signal_encoding_types") or ""),
        "signal_representation": parse_representation(extract_block(text, "Signal_representation") or ""),
        "warnings": warnings,
    }
    return result


def main():
    parser = argparse.ArgumentParser(description="LDF (LIN Description File) 解析器")
    parser.add_argument("--input", "-i", required=True, help="LDF 文件路径")
    parser.add_argument("--output", "-o", required=True, help="输出 lin_db.json 路径")
    parser.add_argument("--frame", type=lambda s: int(s, 0), default=None,
                        help="仅输出指定帧 ID（十六进制，如 0x28）")
    parser.add_argument("--signal", default=None, help="仅输出指定信号名")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"[ERROR] 文件不存在: {args.input}")
        sys.exit(1)

    print(f"[INFO] 解析 LDF: {args.input}")
    result = parse_ldf(args.input, frame_filter=args.frame, signal_filter=args.signal)

    diag_ids = [f for f in result["frames"] if f["frame_type"] == "diagnostic"]
    print(f"[INFO] 解析完成:")
    print(f"  - LIN 版本: {result['lin_protocol_version']} ｜ 速率: {result['lin_speed_raw']}（{result['lin_speed_bps']} bps）")
    print(f"  - 主节点: {result['master']['name'] if result['master'] else '?'}（时基 {result['master']['time_base_ms'] if result['master'] else '?'}ms） ｜ 从节点: {', '.join(result['slaves']) or '?'}")
    print(f"  - 信号: {len(result['signals'])} ｜ 诊断信号: {len(result['diagnostic_signals'])}")
    print(f"  - 帧: {len(result['frames'])}（诊断帧: {len(diag_ids)}）")
    print(f"  - 调度表: {len(result['schedule_tables'])}")
    if result["warnings"]:
        print("[WARN] 校验告警:")
        for w in result["warnings"]:
            print(f"  - {w}")

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n[INFO] 输出文件: {args.output}")
    print(f"[HINT] 下游可用 lin_db.json 生成 LIN 帧级步骤（PID/信号偏移见 frames[].pid_hex / signals[].offset）")


if __name__ == "__main__":
    main()
