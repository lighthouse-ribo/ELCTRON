#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline SWDL evidence importer for LIN ASC and text-exported XCT logs.

Import is read-only: it normalizes captured frames, reassembles LIN-TP UDS
messages, and records observed SWDL activity.  It never changes an execution
verdict to PASS.  Proprietary binary XCT is deliberately fail-closed because
the layout is vendor/version dependent; export it to text/ASC first.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

try:
    from lin_tp import assemble, parse_frame
except ImportError:  # pragma: no cover - makes the diagnostic explicit in copied use
    raise RuntimeError("swdl_trace_import.py must be run beside lin_tp.py")


class TraceImportError(ValueError):
    """Raised for a source whose frame representation cannot be verified."""


_HEX = re.compile(r"^[0-9a-fA-F]{1,2}$")
_ASC_LIN = re.compile(
    r"^\s*(?P<ts>\d+(?:\.\d+)?)\s+Li\s+(?P<id>[0-9a-fA-F]{1,3})\s+"
    r"(?P<direction>Tx|Rx)\s+(?P<dlc>\d+)\s+(?P<data>.*)$",
    re.IGNORECASE,
)
_ASC_CAN = re.compile(
    r"^\s*(?P<ts>\d+(?:\.\d+)?)\s+(?:\d+\s+)?(?P<id>[0-9a-fA-F]{1,8})(?:x)?\s+"
    r"(?P<direction>Tx|Rx)\s+(?:d\s+)?(?P<dlc>\d+)\s+(?P<data>.*)$",
    re.IGNORECASE,
)
_XCT_DELIMITED = re.compile(
    r"^\s*(?P<ts>\d+(?:\.\d+)?)\s*[,;\t]\s*(?P<direction>Tx|Rx)\s*[,;\t]\s*"
    r"(?:0x)?(?P<id>[0-9a-fA-F]{1,8})\s*[,;\t]\s*(?P<dlc>\d+)\s*[,;\t]\s*(?P<data>.*)$",
    re.IGNORECASE,
)
_XCT_COLUMNS = re.compile(
    r"^\s*(?P<ts>\d+(?:\.\d+)?)\s+(?P<direction>Tx|Rx)\s+(?:0x)?"
    r"(?P<id>[0-9a-fA-F]{1,8})\s+(?P<dlc>\d+)\s+(?P<data>.*)$",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class Frame:
    ts: float
    direction: str
    frame_id: int
    data: tuple[int, ...]
    source_line: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "ts": self.ts,
            "dir": self.direction,
            "id": self.frame_id,
            "data": list(self.data),
            "source_line": self.source_line,
        }


def _bytes_from_tail(text: str, dlc: int) -> tuple[int, ...] | None:
    """Extract only the declared data bytes; checksum/trailing fields are ignored."""
    values: list[int] = []
    for token in re.split(r"[\s,;|]+", text.strip()):
        if token.lower() in {"checksum", "=", "br", "csm"}:
            break
        if _HEX.fullmatch(token):
            values.append(int(token, 16))
            if len(values) == dlc:
                return tuple(values)
        elif values:
            break
    return tuple(values) if len(values) == dlc else None


def _frame_from_match(match: re.Match[str], line_no: int) -> Frame | None:
    dlc = int(match.group("dlc"))
    if not 0 <= dlc <= 64:
        return None
    data = _bytes_from_tail(match.group("data"), dlc)
    if data is None:
        return None
    return Frame(
        ts=float(match.group("ts")),
        direction=match.group("direction").upper(),
        frame_id=int(match.group("id"), 16),
        data=data,
        source_line=line_no,
    )


def _decode_text(path: Path) -> str:
    raw = path.read_bytes()
    # Some VickCAN/Windows exports are UTF-16 text. Detect it before the
    # binary guard because those valid logs necessarily contain NUL bytes.
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16")
    if b"\x00" in raw[:4096]:
        raise TraceImportError(
            "XCT 为二进制专有记录格式，无法在不验证厂商格式的情况下安全解析；"
            "请使用 VickCAN/CAN 工具导出 ASC 或文本 XCT 后重试。"
        )
    for encoding in ("utf-8-sig", "utf-16", "gb18030"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise TraceImportError("记录文件不是可验证的文本编码；请导出为 ASC 或文本 XCT")


def _parse_lines(lines: Iterable[str], patterns: Sequence[re.Pattern[str]]) -> list[Frame]:
    frames: list[Frame] = []
    for line_no, line in enumerate(lines, 1):
        for pattern in patterns:
            match = pattern.match(line)
            if match:
                frame = _frame_from_match(match, line_no)
                if frame is not None:
                    frames.append(frame)
                break
    if not frames:
        raise TraceImportError("未识别到可验证的时间戳、方向、ID、DLC 和数据字节帧")
    return sorted(frames, key=lambda item: (item.ts, item.source_line))


def parse_asc(path: str | Path) -> list[Frame]:
    """Parse common Vector/VickCAN LIN ASC and classic CAN ASC frame rows."""
    return _parse_lines(_decode_text(Path(path)).splitlines(), (_ASC_LIN, _ASC_CAN))


def parse_xct(path: str | Path) -> list[Frame]:
    """Parse text-exported XCT rows (CSV/TSV/semicolon or whitespace columns)."""
    return _parse_lines(_decode_text(Path(path)).splitlines(), (_XCT_DELIMITED, _XCT_COLUMNS, _ASC_LIN))


def parse_trace(path: str | Path) -> tuple[str, list[Frame]]:
    source = Path(path)
    suffix = source.suffix.lower()
    if suffix == ".asc":
        return "asc", parse_asc(source)
    if suffix == ".xct":
        return "xct-text", parse_xct(source)
    raise TraceImportError("仅支持 .asc 和 .xct 记录文件")


def _messages(frames: Sequence[Frame], *, master_id: int, slave_id: int) -> list[dict[str, Any]]:
    """Reassemble LIN-TP messages while retaining the original frame references."""
    active: dict[tuple[str, int], list[Frame]] = {}
    messages: list[dict[str, Any]] = []
    for frame in frames:
        if frame.frame_id not in {master_id, slave_id} or len(frame.data) < 2:
            continue
        key = (frame.direction, frame.frame_id)
        kind = parse_frame(frame.data)[0]
        if kind in {"sf", "ff"}:
            active[key] = [frame]
        elif kind == "cf" and key in active:
            active[key].append(frame)
        else:
            continue
        group = active[key]
        first = parse_frame(group[0].data)
        complete = first[0] == "sf"
        if first[0] == "ff":
            expected = int(first[4])
            received = len(first[3]) + sum(len(parse_frame(item.data)[3]) for item in group[1:])
            complete = received >= expected
        if not complete:
            continue
        payload = assemble([parse_frame(item.data) for item in group])
        if payload is None:
            continue
        messages.append({
            "ts": group[0].ts,
            "end_ts": group[-1].ts,
            "direction": group[0].direction,
            "frame_id": group[0].frame_id,
            "payload": list(payload),
            "frame_lines": [item.source_line for item in group],
        })
        active.pop(key, None)
    return messages


def _transactions(messages: Sequence[dict[str, Any]], master_id: int, slave_id: int) -> list[dict[str, Any]]:
    requests = [item for item in messages if item["direction"] == "TX" and item["frame_id"] == master_id]
    responses = [item for item in messages if item["direction"] == "RX" and item["frame_id"] == slave_id]
    result: list[dict[str, Any]] = []
    for index, request in enumerate(requests):
        end = requests[index + 1]["ts"] if index + 1 < len(requests) else float("inf")
        candidates = [item for item in responses if request["end_ts"] <= item["ts"] < end]
        non_pending = [item for item in candidates if item["payload"] != list(b"PENDING")]
        final = non_pending[-1] if non_pending else (candidates[-1] if candidates else None)
        payload = request["payload"]
        result.append({
            "request": payload,
            "response": final["payload"] if final else None,
            "request_ts": request["ts"],
            "response_ts": final["end_ts"] if final else None,
            "elapsed_ms": round((final["end_ts"] - request["ts"]) * 1000, 3) if final else None,
            "request_frame_lines": request["frame_lines"],
            "response_frame_lines": final["frame_lines"] if final else [],
        })
    return result


def assess_swdl_transactions(transactions: Sequence[dict[str, Any]]) -> dict[str, Any]:
    """Describe observed SWDL stages without asserting that a test passed."""
    observed: list[dict[str, Any]] = []
    counts: dict[str, int] = {}
    for item in transactions:
        request = item["request"]
        if not request:
            continue
        sid = request[0]
        if sid not in {0x10, 0x11, 0x27, 0x31, 0x34, 0x36, 0x37}:
            continue
        service = f"0x{sid:02X}"
        counts[service] = counts.get(service, 0) + 1
        label = {
            0x10: "session-control",
            0x11: "ecu-reset",
            0x27: "security-access",
            0x31: "routine-control",
            0x34: "request-download",
            0x36: "transfer-data",
            0x37: "transfer-exit",
        }[sid]
        observed.append({"stage": label, "service": service, "request": request, "response": item["response"]})
    required = ("0x10", "0x27", "0x34", "0x36", "0x37")
    return {
        "verdict": "OBSERVED_ONLY",
        "service_counts": counts,
        "required_sequence_observed": all(counts.get(service, 0) for service in required),
        "observed_stages": observed,
        "note": "历史记录仅证明报文被观察到；PASS/FAIL 仍以用例判据、镜像哈希、认证和实机结果为准。",
    }


def import_swdl_trace(path: str | Path, *, master_id: int = 0x3C, slave_id: int = 0x3D) -> dict[str, Any]:
    source = Path(path)
    source_format, frames = parse_trace(source)
    messages = _messages(frames, master_id=master_id, slave_id=slave_id)
    transactions = _transactions(messages, master_id, slave_id)
    return {
        "schema_version": "swdl-trace-import/v1",
        "provenance": {
            "source_path": str(source.resolve()),
            "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "source_format": source_format,
            "read_only": True,
            "parser": "swdl_trace_import.py",
        },
        "bus": {"type": "LIN", "master_id": master_id, "slave_id": slave_id},
        "frame_count": len(frames),
        "frames": [frame.as_dict() for frame in frames],
        "message_count": len(messages),
        "transactions": transactions,
        "swdl": assess_swdl_transactions(transactions),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="离线导入 ASC/文本 XCT，重组 LIN-TP 并提取 SWDL 观察证据")
    parser.add_argument("--input", required=True, help=".asc 或文本导出的 .xct")
    parser.add_argument("--out", required=True, help="输出 evidence JSON")
    parser.add_argument("--master-id", type=lambda value: int(value, 0), default=0x3C)
    parser.add_argument("--slave-id", type=lambda value: int(value, 0), default=0x3D)
    args = parser.parse_args()
    try:
        evidence = import_swdl_trace(args.input, master_id=args.master_id, slave_id=args.slave_id)
    except (OSError, TraceImportError) as exc:
        parser.error(str(exc))
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"out": str(out), "frames": evidence["frame_count"], "verdict": "OBSERVED_ONLY"}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
