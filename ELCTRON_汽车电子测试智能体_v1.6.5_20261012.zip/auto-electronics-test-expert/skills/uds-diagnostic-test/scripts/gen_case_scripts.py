#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""用例 ↔ 脚本 一一对应生成器（铁律：每用例唯一脚本，不漏不重）
=========================================================================
输入：设计用例 JSON（srs-uds-testcase-designer 的 case-schema，如 503 条）
      + 调查表解析 JSON（uds_parsed.json，提供 DID 属性/会话/安全约束）
输出：每条用例一个可执行脚本 case_<用例ID>.py
      + manifest.json（用例ID ↔ 脚本 双向映射 + 状态）
      + run_all.py（顺序执行全部脚本并汇总）

用例状态（脚本内自述，运行即写结果，不编造）：
  executable  - procedure 含具体请求 hex，可直接执行
  needs_data  - 请求含占位参数（"+ N字节数据"/"+ 参数"/待补），需补数据后执行
  timing      - TimeParm 时序测量类（每条用例独立采集、独立判定、独立留证）
  blocked     - 0x27/刷写/需授权/密钥未就绪，前置满足前标 BLOCKED
  skip        - 用户明确排除的用例；不连接 ECU，保留 SKIP 展示

执行筛选：用例 JSON 中 select=否 的条目在生成前即被过滤（不生成脚本、
不进 manifest、不会向 ECU 发送任何请求）；确需执行须在用例表改为"是"
后重新生成。select 是执行开关，不是建议性参考。

用法:
  python gen_case_scripts.py --cases cases.json --parsed uds_parsed.json \
      --bus lin --out-dir scripts/ [--nad 0x51] [--sa-key-file VolvoKey.json]
"""

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path

_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))

for _stream in (sys.stdout, sys.stderr):
    _reconfigure = getattr(_stream, "reconfigure", None)
    if _reconfigure:
        try:
            _reconfigure(encoding="utf-8", errors="replace")
        except (OSError, ValueError):
            pass

from timing_case_runner import build_timing_spec
from lin_pci import parse_lin_transport_frame, strip_lin_payload
from partition_model import (
    DEFAULT_TIMING_PARAMETERS,
    build_partition_model,
    parse_did_matrix_file,
)
from project_config import canonical_did, load_project_config
from project_artifact_binding import (
    ProjectArtifactBindingError,
    build_project_context_binding,
    validate_project_context_binding,
)
from session_flow import (
    allowed_transition,
    normalize_session,
    parse_session_target,
    requires_s3,
    session_name,
    session_runtime_name,
    setup_route,
)
from session_keepalive import DEFAULT_INTERVAL_SECONDS, KEEP_ALIVE_SUBFUNCTION
from uds_case_gate import evaluate_case
from result_contract import infer_failure_class


def parse_rid_request_len(survey):
    """解析诊断调查表 Control Routine 的 Request 字节长度 → {RID: N}
    兼容 *_diagnostic.xlsx（APP/PBL/SBL 目录）与单个 xlsx"""
    import glob as _glob
    import openpyxl
    files = []
    if os.path.isdir(survey):
        files = _glob.glob(os.path.join(survey, "*_diagnostic.xlsx"))
    elif os.path.isfile(survey) and survey.lower().endswith(".xlsx"):
        files = [survey]
    out = {}
    for f in files:
        try:
            wb = openpyxl.load_workbook(f, read_only=True, data_only=True)
        except Exception:
            continue
        if "Control Routine" not in wb.sheetnames:
            continue
        ws = wb["Control Routine"]
        rows = list(ws.iter_rows(values_only=True))
        hidx = None
        for i, row in enumerate(rows):
            joined = [str(v) if v is not None else "" for v in row]
            if any(("identifier" in j.lower()) or ("data identification" in j.lower()) for j in joined):
                hidx = i
                break
        if hidx is None:
            continue
        hdr = [str(v).lower() if v else "" for v in rows[hidx]]
        c_id = next((i for i, h in enumerate(hdr) if "identif" in h), None)
        if c_id is None:
            continue
        cur = None
        for row in rows[hidx + 1:]:
            rid = str(row[c_id]).strip().upper() if c_id < len(row) and row[c_id] is not None else ""
            if re.fullmatch(r"[0-9A-F]{4}", rid):
                cur = rid
            if not cur:
                continue
            lens = " | ".join(str(v) for v in row if v is not None)
            m = re.search(r"Request\s*:\s*(\d+)", lens, re.I)
            if m:
                n = int(m.group(1))
                if cur not in out or n > out[cur]:
                    out[cur] = n
            else:
                out.setdefault(cur, 0)  # 已知例程无 Request 参数 → 0 字节
    return out


def parse_did_matrix(path):
    """解析 DID检查表，保留旧接口并交给分区模型模块实现。"""
    return parse_did_matrix_file(path)


def hex_tokens(text):
    """提取文本中连续 hex 字节序列（如 '51 02 10 01 FF FF FF FF'）"""
    # 一行步骤可能先出现 ``RID 0206``，随后才出现完整 LIN 原始帧。
    # 只取第一个匹配会把 RID 当成请求，导致 0x31 用例发出截断报文。
    # 取最长的连续字节串，优先保留完整原始帧。
    matches = re.findall(
        r"(?<![0-9A-Fa-f])(?:[0-9A-Fa-f]{2}(?:\s+|(?=[^0-9A-Fa-f]|$)))+",
        text or "",
    )
    if not matches:
        return None
    raw = re.sub(r"[^0-9A-Fa-f]", "", max(matches, key=len))
    return [int(raw[i:i + 2], 16) for i in range(0, len(raw), 2)]


_0X_ANNOT = re.compile(r"0[xX][0-9A-Fa-f]+")


def _plausible_request_frame(toks, bus, nad, transport_nads=None):
    """含 0x 标注行提取结果的"疑似帧"判定。

    帧可信的四种形态：首字节是标准请求 SID / 供应商服务段、LIN 物理
    寻址 NAD、ISO-TP 单帧(PCI+SID)、LIN 完整 8 字节单帧。用于防止
    ``发送 0x22 读取 DID F190`` 这类"单服务字节 + 文本说明"被当帧
    （应留给文本解析恢复 [22 F1 90]）。
    """
    if not toks:
        return False
    sid = toks[0]
    # 帧至少要 SID+参数/子功能 2 字节；单服务字节（如 ``发送 0x22 读取
    # DID F190`` 的 [22]）留给文本解析恢复完整 DID，不在此放行。
    if len(toks) >= 2 and (0x10 <= sid <= 0x3E or 0x80 <= sid <= 0xBF):
        return True
    nads = {int(nad) & 0xFF}
    for value in transport_nads or ():
        try:
            nads.add(int(value) & 0xFF)
        except (TypeError, ValueError):
            continue
    if bus == "lin" and len(toks) >= 2 and sid in nads:
        return True
    if (sid >> 4) == 0x0 and len(toks) >= 2 and (0x10 <= toks[1] <= 0x3E):
        return True  # ISO-TP SF（PCI + SID）
    if bus == "lin" and len(toks) >= 8 and (toks[1] >> 4) in (0x0, 0x1):
        return True
    return False


def _line_frame_tokens(line, bus, nad, transport_nads=None):
    """返回该行最可信的请求帧字节序列。

    与审查层 review_truth.payload_candidates 的取证口径一致（2026-09-03）：
    0x 标注与帧同行时，原行与去 ``0x..`` 标注的清洗行都提取——救回
    ``请求: 22 F1 90（DID 0xF190 车架号）``、``在扩展会话(0x03)下请求:
    22 F1 90`` 这类旧版整行跳过/解析失败的混合行。含 0x 的行要求提取
    结果"疑似帧"，避免单服务字节说明被误当报文。
    """
    variants = [line]
    if _0X_ANNOT.search(line or ""):
        variants.append(_0X_ANNOT.sub(" ", line))
    best = None
    for variant in variants:
        toks = hex_tokens(variant)
        if not toks:
            continue
        if "0x" in (line or "").lower() and not _plausible_request_frame(
                toks, bus, nad, transport_nads):
            continue
        if best is None or len(toks) > len(best):
            best = toks
    return best


def _strip_lin(toks, nad):
    """LIN 帧字节 → UDS payload（按 PCI 精确截取，去 NAD+PCI+FF 填充）"""
    # 物理寻址 NAD 通常等于 ``nad``；功能寻址或不存在节点超时用例会使用
    # 其他 NAD（例如 0x7E/0x52）。完整单帧必须先去掉 NAD+PCI，不能将其
    # 误发成 UDS payload。
    # A direct UDS payload may itself be 8+ bytes long.  Do not mistake its
    # second byte for LIN PCI merely because it looks like a single-frame
    # length; only a non-UDS first byte can be the legacy no-NAD SF form.
    return strip_lin_payload(toks, nad)


def _transport_payload(toks, bus, nad, transport_nads=None):
    """去掉已识别的 LIN NAD/PCI 包装；兼容跨工具导出的 CAN 测试文本。"""
    nads = {int(nad) & 0xFF}
    for value in transport_nads or ():
        try:
            nads.add(int(value) & 0xFF)
        except (TypeError, ValueError):
            continue
    if bus == "lin":
        return _strip_lin(toks, toks[0] if toks and toks[0] in nads else nad)
    if toks and len(toks) >= 2 and toks[0] in nads:
        return _strip_lin(toks, toks[0])
    return toks


def request_payload(procedure, bus, nad, rid_len_map=None, service_hint=None, transport_nads=None):
    """从 procedure 提取 UDS 请求 payload；返回 (payload, status, reason)
    - '51 02 10 01 FF...'          → 按 PCI 去 NAD/填充 → [10 01]
    - '2E D0 3A + 32字节数据'      → 长度显式 → 自动填充 N×0x00（标注需确认）
    - '0x22 读取 DID F190'         → 文本 → 解析为 [22 F1 90]
    - '31 01 02 06 + 参数'         → 无长度 → needs_data（不硬造）
    """
    transport_nad_set = {int(nad) & 0xFF}
    for value in transport_nads or ():
        try:
            transport_nad_set.add(int(value) & 0xFF)
        except (TypeError, ValueError):
            continue
    # 一个场景通常既有“请求种子/进入会话”等文字步骤，也会在后续行给出
    # 可执行的原始 LIN 帧。不能命中第一条含“请求”的文字就停止，否则会把
    # `请求种子(0x27 05)` 前面的说明误当作 payload，而漏掉后面的
    # `51 02 27 05 ...`，使本可执行的用例被错误标成 BLOCKED。
    # 请求帧提取走 _line_frame_tokens：0x 标注/注释与帧同行的混合行也会
    # 通过清洗变体恢复帧（与审查层同口径，2026-09-03）。
    request_lines = []
    for raw_line in (procedure or "").splitlines():
        l = raw_line.strip()
        is_request_text = "请求" in l or ("发送" in l and "0x" in l.lower())
        # 有些调查表只写“写入/读取：51 ...”而不出现“请求”二字。
        # 至少 4 个字节才当作原始帧行；0x 行已由 _line_frame_tokens 清洗，
        # 不再整行跳过（避免把 RID 0206 等说明字段误选为报文）。
        raw = _line_frame_tokens(l, bus, nad, transport_nads)
        # procedure 也常直接写 ``发送 11 01`` 这类无 NAD 的 UDS 请求；
        # 两个字节已足够构成服务+子功能，不应因为长度小于完整 LIN 帧而丢弃。
        is_raw_frame = raw is not None and len(raw) >= 4
        if "发送" in l and raw is not None and len(raw) >= 2:
            is_raw_frame = True
        if is_request_text or is_raw_frame:
            request_lines.append(l)
    if not request_lines:
        return None, "needs_data", "procedure 无请求行"

    # 原始字节帧的可信度高于文字占位；优先选择字节数最多的一行，以覆盖
    # 同一 procedure 中“步骤说明 + 实际测试仪请求帧”的常见写法。
    # ``0x3C``/``0x3D`` 这类 LIN 帧标签也可能出现在原始帧行中，不能因为
    # 行内出现 ``0x`` 就丢弃整行；但 ``发送 0x22 读取 DID F190`` 只有一个
    # 服务字节，仍应留给下面的文本解析（_plausible_request_frame 已过滤）。
    raw_candidates = []
    for l in request_lines:
        toks = _line_frame_tokens(l, bus, nad, transport_nads)
        if not toks:
            continue
        raw_candidates.append((l, toks))
    def _candidate_sid(item):
        candidate_line, candidate_toks = item
        if bus == "lin" and len(candidate_toks) >= 3 and (
                candidate_toks[0] in transport_nad_set or
                (len(candidate_toks) >= 8 and (candidate_toks[1] >> 4) == 0x0)):
            return candidate_toks[2]
        return candidate_toks[0] if candidate_toks else None

    hinted_sid = None
    if service_hint:
        try:
            hinted_sid = int(str(service_hint), 0)
        except ValueError:
            hinted_sid = None
    matching = [item for item in raw_candidates if _candidate_sid(item) == hinted_sid]
    full_frame_candidates = [
        item for item in raw_candidates
        if bus == "lin" and len(item[1]) >= 8 and (
            item[1][0] in transport_nad_set or (item[1][1] >> 4) == 0x0
        )
    ]
    if matching:
        chosen = max(matching, key=lambda item: len(item[1]))
    elif full_frame_candidates:
        chosen = max(full_frame_candidates, key=lambda item: len(item[1]))
    else:
        # 多步骤 procedure 直接写 UDS payload 时，第一条“发送”通常是
        # 当前用例的主请求，后面的 22 F1 86 等只是复位/会话确认步骤。
        chosen = raw_candidates[0] if raw_candidates else (request_lines[-1], None)
    line, toks = chosen
    if toks is not None and ("+" not in line or "字节" in line):
        explicit_len = re.search(r"(?:\+\s*)?(\d+)\s*字节", line)
        if explicit_len and re.search(r"\.\.\.|…|省略|占位", line):
            n = int(explicit_len.group(1))
            if bus == "lin" and len(toks) >= 3 and toks[0] in transport_nad_set:
                # 此类调查表行常写作 ``51 24 2E F1 0A 00 00 ...（34字节）``。
                # PCI/填充并不完整，保留 SID+DID 前缀，再补数据区。
                prefix = (toks[2:5] if toks[2] in (0x2E, 0x22)
                          else _transport_payload(toks, bus, nad, transport_nads))
            else:
                prefix = _transport_payload(toks, bus, nad, transport_nads)
            if prefix:
                return prefix + [0] * n, "needs_data", f"长度自动填充 {n}×0x00，属推断数据：需用户确认业务值后才可执行"
        # 只有首字节是 NAD（或完整 8 字节单帧）时，才把第二字节解释为
        # LIN PCI。procedure 中常直接写 UDS payload（例如 ``11 01``），
        # 不能误把 0x11 当 NAD 后把请求判成 PCI 长度不完整。
        full_lin_frame = (
            bus == "lin" and len(toks) >= 2 and
            (toks[0] in transport_nad_set
             or (len(toks) >= 8 and (toks[1] >> 4) in (0x0, 0x1)))
        )
        if full_lin_frame:
            transport = parse_lin_transport_frame(toks, toks[0] if toks[0] in transport_nad_set else nad)
            if not transport["complete"]:
                declared = transport["declared_length"]
                available = transport["available_length"]
                return (None, "needs_data",
                        f"LIN PCI 声明 {declared} 字节但原始帧仅提供 {available} 字节，需补齐后执行")
        # 显式长度填充：'2E D0 3A + 32字节数据' → 前缀 + N×0x00
        m = re.search(r"\+\s*(\d+)\s*字节", line)
        if m:
            n = int(m.group(1))
            prefix = _transport_payload(toks, bus, nad, transport_nads)
            return prefix + [0] * n, "needs_data", f"长度自动填充 {n}×0x00，属推断数据：需用户确认业务值后才可执行"
        if toks is not None and "+" not in line and "待补" not in line and not re.search(r"\.\.\.|…|省略|占位", line):
            base = _transport_payload(toks, bus, nad, transport_nads)
            # 例程的请求参数长度以调查表为准。原始帧常用 FF 作填充，
            # 但 PCI 只覆盖已写出的字段；若调查表声明还需要参数，
            # 在不伪造业务值的前提下补 0x00，并明确标注待确认。
            if base and base[0] == 0x31 and len(base) >= 4 and rid_len_map:
                rid = "%02X%02X" % (base[2], base[3])
                n = rid_len_map.get(rid)
                existing = max(0, len(base) - 4)
                if n is not None and existing < n:
                    missing = n - existing
                    return (base + [0] * missing, "needs_data",
                            f"例程参数长度自动补齐 {missing}×0x00（调查表 {n} 字节），属推断数据：需用户确认后执行")
            return base, "executable", ""
    # 文本形式：'0x22 读取 DID F190' / '发送 0x22 ...'
    m = re.search(r"0x(22|2E|31|27|3E|10|11)\b[^0-9A-Fa-f]*([0-9A-Fa-f]{2,4})", line, re.I)
    if m:
        sid = int(m.group(1), 16)
        arg = m.group(2).upper()
        if len(arg) == 4:
            return [sid, int(arg[:2], 16), int(arg[2:], 16)], "executable", "文本请求解析"
        # 0x10/0x11/0x27/0x3E 的单字节子功能可直接由文本恢复；其他服务
        # 的两位参数不是完整 DID/RID，必须保持 needs_data，避免发出畸形请求。
        if sid in (0x10, 0x11, 0x27, 0x3E):
            return [sid, int(arg, 16)], "executable", "文本请求解析（子功能）"
        return None, "needs_data", "文本请求缺少完整 DID/RID"
    if "+" in line or "待补" in line or re.search(r"\.\.\.|…|省略|占位", line):
        # 0x31 例程：按调查表 Request 长度自动补全（如 0231→1B、0301→4B、0212→512B）
        if toks and len(toks) >= 4 and toks[0] == 0x31 and rid_len_map:
            rid = "%02X%02X" % (toks[2], toks[3])
            n = rid_len_map.get(rid)
            if n is not None:
                base = _transport_payload(toks, bus, nad, transport_nads)
                if n == 0:
                    return base, "executable", "例程无请求参数（调查表）"
                return base + [0] * n, "needs_data", f"例程参数长度自动填充（调查表 {n} 字节），属推断数据：需用户确认后执行"
        return None, "needs_data", "请求含占位参数（长度/参数值未提供，需按调查表补全）"
    return None, "needs_data", "请求为文本占位（无法解析 hex）"


def request_nad(procedure, bus, nad, transport_nads=None):
    """从完整原始帧恢复用例实际 NAD；缺失时沿用物理 NAD。

    CAN 用例通常不使用 NAD，但保留原始帧首字节可让审查器验证跨工具
    导出的 LIN/UDS 报文，不影响 CAN 运行时（CAN 不读取 REQUEST_NAD）。
    """
    candidates = []
    for line in (procedure or "").splitlines():
        if "请求" not in line and not ("发送" in line and "0x" in line):
            continue
        toks = _line_frame_tokens(line, bus, nad, transport_nads)
        if toks and len(toks) >= 8 and (toks[1] >> 4) == 0x0:
            candidates.append(toks)
    return max(candidates, key=len)[0] if candidates else nad


def routine_prerequisites(case, payload):
    """提取 0x31 查询结果/停止例程之前必须完成的启动动作。

    调查表写有“先启动 RID 0206”时，旧生成器只发送 0x31 03 或 0x31 02，
    使本应有状态依赖的用例稳定落入 NRC 0x31。仅恢复调查表中明示的
    启动例程，不猜测任何业务参数。
    """
    if not payload or len(payload) < 4 or payload[0] != 0x31 or payload[1] not in (0x02, 0x03):
        return []
    procedure = case.get("procedure", "") or ""
    match = re.search(r"(?:先启动|启动)\s*(?:RID\s*)?([0-9A-Fa-f]{4})", procedure, re.I)
    if not match:
        return []
    rid = match.group(1)
    return [[0x31, 0x01, int(rid[:2], 16), int(rid[2:], 16)]]


def routine_prerequisites_from_matrix(case, payload, matrix=None):
    """优先使用 SDDB 前置矩阵，兼容旧的文本回退规则。"""
    if not payload or len(payload) < 4 or payload[0] != 0x31 or payload[1] not in (0x02, 0x03):
        return []
    rid = "%02X%02X" % (payload[2], payload[3])
    item = (matrix or {}).get(rid) or (matrix or {}).get(rid.upper())
    if isinstance(item, dict):
        start_payload = item.get("start_payload")
        if isinstance(start_payload, list) and start_payload:
            return [[int(value) & 0xFF for value in start_payload]]
        if item.get("two_step") and item.get("requires_start_data"):
            # 参数值未知时不伪造启动动作；调用方会继续保留原用例，
            # 并由生成器的 needs_data/门禁结果阻止硬件执行。
            return []
    return routine_prerequisites(case, payload)


def _session_text(session_id, project_config):
    config = load_project_config(project_config)
    sid = int(session_id)
    return str(config["sessions"]["names"].get(sid, f"会话 0x{sid:02X}"))


def _session_aliases(session_id, project_config):
    """返回项目会话名及少量历史别名，便于兼容旧调查表文本。"""
    config = load_project_config(project_config)
    sid = int(session_id)
    aliases = {_session_text(sid, config), f"0x{sid:02X}", f"0x{sid:02x}"}
    aliases.update({f"{sid:02X}", f"{sid:02x}"})
    # 这些别名只用于解析历史输入；生成的文本始终使用项目配置名称。
    aliases.update({
        0x01: ("默认会话", "default"),
        0x02: ("编程会话", "programming"),
        0x03: ("扩展会话", "extended"),
    }.get(sid, ()))
    return {str(alias).strip() for alias in aliases if str(alias).strip()}


def _session_id_from_text(text, project_config, *, contextual=True):
    config = load_project_config(project_config)
    text = str(text or "")
    supported = [int(value) for value in config["sessions"]["supported"]]
    # 长名称优先，避免项目名称包含彼此子串时取错会话。
    for sid in sorted(supported, key=lambda value: len(_session_text(value, config)), reverse=True):
        for alias in sorted(_session_aliases(sid, config), key=len, reverse=True):
            if re.fullmatch(r"(?:0x)?[0-9A-Fa-f]{2}", alias):
                continue
            if alias.lower() in text.lower():
                return sid
    if contextual:
        hex_ids = "|".join(f"(?:0x)?{sid:02X}" for sid in supported)
        match = re.search(
            rf"(?:会话|session|进入|切换(?:至|到)?|保持|当前)[^\r\n0-9A-Fa-f]{{0,12}}({hex_ids})\b"
            rf"|\b({hex_ids})[^\r\n]*(?:会话|session)\b",
            text,
            re.I,
        )
        if match:
            token = next((value for value in match.groups() if value), "")
            return int(token.replace("0x", "").replace("0X", ""), 16)
    return None


def session_from_procedure(procedure, project_config=None):
    """恢复场景中显式进入的项目会话，优先于起始前置会话。"""
    sid = _session_id_from_text(procedure, project_config)
    return session_name(sid, project_config) if sid is not None else None


def session_from_payload(payload, project_config=None):
    """从原始 0x10 请求恢复配置中的目标会话。"""
    target = parse_session_target(payload, project_config)
    return session_name(target, project_config) if target is not None else None


def expected_session(expected, project_config=None):
    """提取项目会话探针的显式会话值；未配置探针时不增加隐式请求。"""
    config = load_project_config(project_config)
    probe_did = canonical_did(config.get("generation", {}).get("session_probe_did"))
    if not probe_did:
        return None
    text = str(expected or "")
    probe = re.escape(probe_did)
    for pattern in (
        rf"\b{probe}\b[^\r\n]*(?:=|返回|为|是)\s*(?:0x)?([0-9A-Fa-f]{{2}})",
        rf"(?:返回|读取|查询)[^\r\n]*\b{probe}\b[^\r\n]*(?:=|为|是)?\s*(?:0x)?([0-9A-Fa-f]{{2}})",
    ):
        match = re.search(pattern, text, re.I)
        if match:
            value = normalize_session(f"0x{match.group(1)}", config)
            if value is not None:
                return value
    if re.search(r"(?:保持|当前|会话|session)", text, re.I):
        sid = _session_id_from_text(text, config)
        if sid is not None:
            return sid
    return None


def session_from_precondition(pre, project_config=None):
    config = load_project_config(project_config)
    sid = _session_id_from_text(pre, config)
    if sid is None:
        sid = int(config["sessions"]["default"])
    return session_name(sid, config)


def should_keep_session_alive_for_case(session, payload, request_nad, physical_nad, project_config):
    """按项目会话集合计算 0x3E 保活需求，不依赖固定 02/03 会话。"""
    config = load_project_config(project_config)
    target = parse_session_target(payload, config)
    if target is not None:
        if request_nad not in (None, ""):
            try:
                if int(request_nad) != int(physical_nad):
                    return False
            except (TypeError, ValueError):
                return False
        source = normalize_session(session, config)
        if source is not None and allowed_transition(source, target, config) is False:
            return False
        return requires_s3(target, config)
    return requires_s3(session, config)


def expected_info(case, restricted_dids, project_config=None):
    """判定期望类型 pos/neg/na/blocked/timing，返回 (expect, expect_nrc, reason)"""
    cid = case.get("case_id", "")
    svc = cid.split("_")[1].lower() if len(cid.split("_")) > 1 else ""
    tp = case.get("test_point", "") or ""
    exp = case.get("expected", "") or ""
    pre = case.get("precondition", "") or ""
    proc = case.get("procedure", "") or ""
    config = load_project_config(project_config)
    negative_keywords = tuple(config.get("lint", {}).get("negative_keywords", ()))

    if cid.startswith("UDS_TimeParm") or "TimeParm" in cid:
        return "timing", None, "时序测量类（P2/P2*/S3/P4）"
    # 时序测量意图只认显式声明（test_point），不认 expected/procedure/precondition
    # 中的参数名或"响应时间"等措辞——普通功能用例常把 P2Server/S3Server 作为
    # 预期值参考写入 expected（例如"响应 ≤ P2Server_max=50ms"），全文子串匹配
    # 会误判 timing → run_all 中 SKIP，导致功能用例"未执行"（实测固化问题）。
    if any(token in tp for token in ("时序测量", "时序采集", "时序验证", "P2/P2*/S3", "高实时时序")):
        return "timing", None, "test_point 显式声明时序测量类（P2/P2*/S3/P4）"
    if svc in ("0x34", "0x36", "0x37"):
        return "blocked", None, "刷写服务需 0x27 密钥解锁 / 高风险需授权"
    if "需授权" in tp or "需授权" in pre or "需确认" in tp:
        return "blocked", None, "需用户授权（如 ECU 复位）"
    if "受限" in tp or "需解锁" in tp or "分区" in tp or "未配置" in tp or "只写" in tp:
        return "na", None, "条件受限（正确拒绝）"
    if any(token in exp for token in ("不应答", "无应答", "不发送正响应", "抑制正响应", "suppressPosRsp")):
        return "none", None, "预期无应答"
    if any(token and token in " ".join((tp, proc, exp)) for token in negative_keywords):
        # “NRC=0x31 或 0x72”是同一用例的允许集合，不能只取第一个
        # NRC 后把另一条合规路径判成 FAIL。
        nrcs = {int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", exp)}
        # 需求常直接写完整负响应帧（例如 ``7F 2E 7F``），不能只提取
        # ``0x13`` 这种文字形式，否则实际匹配 0x7F 会被误判为 FAIL。
        for line in exp.splitlines():
            toks = hex_tokens(line)
            if not toks:
                continue
            for i in range(len(toks) - 2):
                if toks[i] == 0x7F:
                    nrcs.add(toks[i + 2])
        nrcs = sorted(nrcs)
        return "neg", nrcs or None, (
            "期望 NRC=" + "/".join("0x%02X" % n for n in nrcs)
            if nrcs else "负例（NRC 未显式给出，按负响应记录）"
        )
    # 需求模板有时把“缺少密钥，本轮 BLOCKED”复制到 Seed/等级探针。
    # Seed 请求本身不发送 Key，不应因该说明被阻塞；真实 Key/解锁正例
    # 仍由 security_key_required() 在生成阶段标 BLOCKED。
    if svc == "0x27" and any(token in exp for token in ("本轮不执行真实解锁", "缺少客户授权密钥", "状态判定为 BLOCKED")):
        if re.search(r"(?:27\s+0?[13579BDF])|种子", proc + " " + tp, re.I):
            return "pos", None, "0x27 Seed/等级探针不发送 Key，可独立执行；原始 BLOCKED 说明仅针对真实解锁"
    if any(token in " ".join((exp, tp)) for token in (
            "正响应", "正向", "正常响应", "可正常响应", "全帧数据完整", "数据完整")):
        # DID 受限：调查表只读/需解锁且生成器误作正例 → 运行时按条件 NRC 判 NA
        didm = re.search(r"(?:DID|0x)?([0-9A-Fa-f]{4})", tp)
        if didm and didm.group(1).upper() in restricted_dids:
            return "na", None, "调查表属性受限（只读/需解锁/分区），正例按条件 NRC 判 NA"
        return "pos", None, "期望正响应"
    return "na", None, "无法判定期望类型（保守按条件受限）"


def expected_response_prefix(expected, bus, nad, transport_nads=None):
    """提取期望中的原始响应帧，供脚本校验响应数据而不只校验正响应 SID。

    返回 UDS payload 前缀；没有完整/可识别原始帧时返回空列表，脚本仍按
    SID/NRC 规则判定。这里仅把调查表已经明确写出的字节作为断言，绝不补造。
    """
    candidates = []
    for line in (expected or "").splitlines():
        if "响应" not in line:
            continue
        toks = hex_tokens(line)
        if not toks:
            continue
        # 单独的十进制限值（例如 ``P2Server_max=50ms``）不是响应字节。
        # 只有明确写成 0xNN，或至少两个连续裸字节时，才允许进入时序
        # 响应前缀；否则会把“50ms”误当成 0x50，导致真实 0x62 响应被
        # 错误判 FAIL。
        if len(toks) == 1 and not re.search(r"0x[0-9A-Fa-f]{2}", line, re.I):
            continue
        # 导出工具可能把 LIN NAD+PCI 一并写进期望响应，即使该用例
        # 后续走 CAN 审查；能识别完整单帧时统一去掉传输层包装。
        nads = {int(nad) & 0xFF, *(int(value) & 0xFF for value in (transport_nads or ())) }
        looks_like_lin_sf = len(toks) >= 3 and ((toks[0] in nads and (toks[1] >> 4) == 0x0) or
                                                  (len(toks) >= 8 and (toks[1] >> 4) == 0x0))
        payload = _strip_lin(toks, toks[0] if toks[0] in nads else nad) if bus == "lin" or looks_like_lin_sf else toks
        if payload and payload[0] in (0x7F,) + tuple(range(0x40, 0x80)):
            candidates.append(payload)
    return max(candidates, key=len) if candidates else []


def response_check_level(case, prefix):
    """决定正响应数据比对强度。

    只有调查表明确声明“固定值/版本号/精确匹配”时才做逐字节断言。
    DID 零件号、会话计时器和可变序列号是版本或状态相关数据；对它们仅
    校验正响应 SID/DID，让报告把差异呈现为数据观察，而非协议失败。
    """
    text = " ".join(str(case.get(k, "") or "") for k in ("test_point", "expected"))
    fixed = any(word in text for word in ("固定值", "精确匹配", "必须为", "应为固定", "Byte0=", "Byte1=", "Byte2="))
    if fixed and prefix:
        return "exact"
    return "protocol"


def security_key_required(case, payload, project_config=None):
    """判断用例是否需要真实 Key；Seed 请求和明确负例不依赖 Key。"""
    cid = str(case.get("case_id", ""))
    parts = cid.split("_")
    svc = parts[1].lower() if len(parts) > 1 else ""
    if svc != "0x27":
        config = load_project_config(project_config)
        protected_services = set(config.get("security", {}).get("unlock_required_services", ()))
        if svc not in protected_services:
            return False
        point = " ".join(str(case.get(k, "") or "") for k in ("test_point", "expected", "procedure"))
        keywords = config.get("lint", {}).get("negative_keywords", ())
        negative = any(str(word) in point for word in keywords)
        return not negative
    point = " ".join(str(case.get(k, "") or "") for k in ("test_point", "expected", "procedure"))
    config = load_project_config(project_config)
    keywords = config.get("lint", {}).get("negative_keywords", ())
    negative = any(str(word) in point for word in keywords)
    if negative:
        return False
    if payload and len(payload) >= 2:
        # 奇数子功能请求 Seed；偶数子功能发送 Key。
        return payload[1] % 2 == 0
    return any(word in point for word in ("正确 Key", "发送Key", "解锁", "密钥", "正向解锁"))


def key_file_ready(path, scripts_dir):
    """只判断纯 Python Gen2 密钥文件是否可用；不存在时不伪造解锁能力。"""
    if not path:
        return False
    try:
        sys.path.insert(0, scripts_dir)
        from seedkey_gen2 import SeedKeyGen2
        return bool(SeedKeyGen2(path).load())
    except Exception:
        return False


def build_restricted_dids(parsed, project_config=None):
    """从 uds_parsed.json 提取受限 DID：只读/需解锁/分区属性"""
    config = load_project_config(project_config)
    out = set(config.get("lint", {}).get("read_only_dids") or ())
    default_session = int(config["sessions"]["default"])

    def default_read_value(read_sessions):
        if not isinstance(read_sessions, dict):
            return "N"
        candidates = (
            f"default_0x{default_session:02X}",
            f"default_0x{default_session:02x}",
            f"default_{default_session:02X}",
            f"0x{default_session:02X}",
            f"{default_session:02X}",
        )
        for key in candidates:
            if key in read_sessions:
                return read_sessions[key]
        for key, value in read_sessions.items():
            if str(key).lower().endswith(f"0x{default_session:02x}"):
                return value
        return "N"

    for d in (parsed or {}).get("dids", []):
        did = str(d.get("did_number", "")).upper().lstrip("0X")
        # The supplied SPA2/SPA3 survey exports use ``Unknown DID`` and
        # default N/Y placeholders for most permission fields.  Those
        # defaults are provenance to retain in uds_parsed.json, not a real
        # restriction; treating them as locked would turn every 0x22 positive
        # case into NA before the layer matrix can be consulted.
        if str(d.get("did_name", "")).strip().lower() == "unknown did":
            continue
        rw = str(d.get("rw_state", "")).upper()
        locked = d.get("read_security", {}).get("level0_locked", "N")
        default_read = default_read_value(d.get("read_sessions"))
        if rw == "W" or locked == "Y" or "N" not in str(default_read).upper():
            # 保守：默认会话不可读或需解锁 → 条件受限
            if locked == "Y" or "Y" not in str(default_read):
                out.add(did)
    return out


SCRIPT_TPL = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# CASE: {case_id}
# 服务: {service} ｜ 会话: {session} ｜ 状态: {status} ｜ 期望: {expect}
# 说明: {reason}
import json, os, sys, time
import threading

RESULT = {result_path!r}
CASE = {case_id!r}
NAD = {nad}
REQUEST_NAD = {request_nad}
DEFAULT_SESSION_ID = {default_session_id}
SESSION_ID_BY_NAME = {session_id_by_name!r}
SESSION_NAMES = {session_names!r}
S3_SESSION_IDS = {s3_session_ids!r}
SESSION_PROBE_DID = {session_probe_did!r}
PAYLOAD = {payload!r}
PRE_ACTIONS = {pre_actions!r}
SESSION = {session!r}
SESSION_SETUP_ROUTE = {session_setup_route!r}
VERIFY_SESSION = {verify_session!r}
EXPECT = {expect!r}
EXPECT_NRC = {expect_nrc!r}
EXPECT_PREFIX = {expect_prefix!r}
RESPONSE_CHECK = {response_check!r}
STATUS = {status!r}
EXECUTABLE = {executable!r}
TRACE_REQUIRED = {trace_required!r}
REASON = {reason!r}
CASE_DID = {case_did!r}
DID_SUPPORT = {did_support!r}
DID_ALLOWED_NRC = {did_allowed_nrc!r}
PARTITION_CONTEXT = {partition_context!r}
GATE_DECISION = {gate_decision!r}
GATE_FINDINGS = {gate_findings!r}
KEEP_ALIVE_REQUIRED = {keep_alive_required!r}
KEEP_ALIVE_INTERVAL = {keep_alive_interval!r}
KEEP_ALIVE_SUBFUNCTION = {keep_alive_subfunction!r}
BUS = {bus!r}
CAN_RUNTIME = {can_runtime!r}
CAN_CHANNEL = {can_channel!r}
CAN_BITRATE = {can_bitrate!r}
CAN_TX_ID = {can_tx_id!r}
CAN_RX_ID = {can_rx_id!r}
CAN_SERIAL = {can_serial!r}
CAN_FD = {can_fd!r}
TIMING_TRACE = {timing_trace!r}
TIMING_SPEC = {timing_spec!r}

_SKILL_SCRIPTS = {scripts_dir!r}
if _SKILL_SCRIPTS not in sys.path:
    sys.path.insert(0, _SKILL_SCRIPTS)
from session_keepalive import (SessionKeepAlive,
                               is_positive_session_response,
                               is_suppressed_tester_present_result)
from result_contract import infer_failure_class

COMM_LOCK = threading.RLock()
KEEP_ALIVE = None
TRACE_RESULT = os.path.splitext(RESULT)[0] + ".trace.json"
TRACE_EVENTS = []
TRACE_TRANSACTION = 0

# 单条脚本退出码契约（run_all 与直接运行共用）：
#   exit 0 = PASS/NA/BLOCKED/SKIP（含时序非 FAIL）
#   exit 1 = FAIL 判定（含时序 FAIL）
#   exit 2 = 脚本异常/崩溃（__main__ 兜底）
_VERDICT = None


def _write_trace():
    """保存本条 LIN 用例的原始硬件时间戳帧轨迹。"""
    if not TRACE_REQUIRED:
        return ""
    os.makedirs(os.path.dirname(TRACE_RESULT), exist_ok=True)
    with open(TRACE_RESULT, "w", encoding="utf-8", errors="replace") as f:
        json.dump({{
            "schema": "uds-lin-trace.v1",
            "case_id": CASE,
            "bus": BUS,
            "nad": NAD,
            "request_frame_id": 0x3C,
            "response_frame_id": 0x3D,
            "hardware_timestamps": True,
            "events": TRACE_EVENTS,
        }}, f, ensure_ascii=False, indent=1)
    return TRACE_RESULT


def _write(verdict, actual, note, failure_class=""):
    global _VERDICT
    verdict = str(verdict or "FAIL").upper()
    if verdict not in ("PASS", "FAIL", "BLOCKED", "NA", "SKIP"):
        verdict = "FAIL"
    _VERDICT = verdict
    os.makedirs(os.path.dirname(RESULT), exist_ok=True)
    evidence = _write_trace()
    with open(RESULT, "w", encoding="utf-8", errors="replace") as f:
        json.dump({{
            "case_id": CASE, "service": "{service}", "desc": {desc!r},
            "session": SESSION, "session_setup_route": SESSION_SETUP_ROUTE,
            "payload": PAYLOAD, "expect": EXPECT,
            "partition_context": PARTITION_CONTEXT,
            "gate_decision": GATE_DECISION,
            "gate_findings": GATE_FINDINGS,
            "session_keep_alive": KEEP_ALIVE_REQUIRED,
            "keep_alive_interval": KEEP_ALIVE_INTERVAL,
            "keep_alive_subfunction": KEEP_ALIVE_SUBFUNCTION,
            "expect_nrc": EXPECT_NRC, "actual": actual, "verdict": verdict,
            "failure_class": infer_failure_class(verdict, failure_class,
                                                   "%s %s" % (actual, note or REASON)),
            "note": note or REASON,
            "evidence": evidence,
        }}, f, ensure_ascii=False, indent=1)
    print(f"[{{verdict}}] {{CASE}}: {{actual}}（{{note or REASON}}）")
    return verdict


def detect_layer(uds):
    """探测 ECU 当前层：读 F120(仅APP) / F122(仅SBL)，均不可读则 PBL"""
    for did, name in ((0xF120, "APP"), (0xF122, "SBL")):
        r = _physical_request([0x22, did >> 8, did & 0xFF], 3)
        if r and r[0] == 0x62:
            return name
    return "PBL"


def _hex(resp):
    return " ".join(f"{{b:02X}}" for b in (resp or [])) or "无应答"


def _session_id(name):
    if isinstance(name, int):
        return name
    text = str(name or "")
    if text in SESSION_ID_BY_NAME:
        return SESSION_ID_BY_NAME[text]
    try:
        return int(text, 0)
    except (TypeError, ValueError):
        raise ValueError("未知项目会话: %r" % name)


def _is_session_entry(payload):
    try:
        return (len(payload) >= 2 and int(payload[0]) == 0x10
                and (int(payload[1]) & 0x7F) in S3_SESSION_IDS)
    except (TypeError, ValueError, IndexError):
        return False


def _session_probe_request():
    if not SESSION_PROBE_DID:
        return None
    try:
        return [0x22, int(SESSION_PROBE_DID[:2], 16), int(SESSION_PROBE_DID[2:], 16)]
    except (TypeError, ValueError, IndexError):
        return None


def _verify_session(session_id):
    request = _session_probe_request()
    if request is None:
        return True, ""
    response = _physical_request(request, 3)
    expected = [0x62, request[1], request[2], int(session_id)]
    if response and response[:len(expected)] == expected:
        return True, "%s=%02X" % (SESSION_PROBE_DID, int(session_id))
    return False, "%s=%s，期望=%02X" % (SESSION_PROBE_DID, _hex(response), int(session_id))


def _is_session_response(resp, sub):
    return bool(resp and len(resp) >= 2 and resp[0] == 0x50 and resp[1] == sub)


def establish_session():
    """每条用例隔离会话，并为前置条件留下可审计证据。"""
    baseline = _physical_request([0x10, DEFAULT_SESSION_ID], 3)
    if not _is_session_response(baseline, DEFAULT_SESSION_ID):
        return False, "无法回默认会话：" + _hex(baseline)
    target = _session_id(SESSION)
    for setup_session in SESSION_SETUP_ROUTE:
        changed = _physical_request([0x10, setup_session], 3)
        if not _is_session_response(changed, setup_session):
            return False, "无法按合法路径进入会话 0x%02X：%s" % (setup_session, _hex(changed))
        if setup_session in S3_SESSION_IDS:
            # 3E 80 抑制正响应；None 是预期结果。进入中间扩展会话和
            # 最终编程会话都要分别刷新 S3，避免建立前置会话时超时。
            keep_alive = _physical_request([0x3E, KEEP_ALIVE_SUBFUNCTION], 3)
            if not is_suppressed_tester_present_result(keep_alive):
                return False, "进入 0x10 %02X 后 0x3E 80 保活返回异常：%s" % (setup_session, _hex(keep_alive))
    verified, note = _verify_session(target)
    if not verified:
        return False, "项目会话探针前置核验失败：" + note
    return True, ""


def _start_keep_alive():
    global KEEP_ALIVE
    if not KEEP_ALIVE_REQUIRED or KEEP_ALIVE is not None:
        return KEEP_ALIVE
    KEEP_ALIVE = SessionKeepAlive(
        _raw_physical_request,
        lock=COMM_LOCK,
        interval=KEEP_ALIVE_INTERVAL,
        timeout=3.0,
    )
    KEEP_ALIVE.start()
    return KEEP_ALIVE


def _stop_keep_alive():
    global KEEP_ALIVE
    if KEEP_ALIVE is None:
        return ""
    keep_error = KEEP_ALIVE.stop()
    KEEP_ALIVE = None
    return keep_error


def _keep_alive_after_session_entry(resp):
    """主请求切换会话时维护 0x3E 保活生命周期。"""
    global KEEP_ALIVE
    if REQUEST_NAD != NAD or len(PAYLOAD) < 2 or PAYLOAD[0] != 0x10:
        return True, ""
    target = PAYLOAD[1] & 0x7F
    if target != DEFAULT_SESSION_ID and not _is_session_entry(PAYLOAD):
        return True, ""
    response_ok = is_positive_session_response(resp, target)
    suppressed_positive = (
        resp is None and bool(PAYLOAD[1] & 0x80) and target in SESSION_NAMES
    )
    if not response_ok and not suppressed_positive:
        return True, ""
    if target == DEFAULT_SESSION_ID:
        # 从编程/扩展会话回默认会话后，立即停止保活器，避免在默认会话
        # 中额外注入 0x3E，污染 0x10 01 的测试语义。
        keep_error = _stop_keep_alive()
        if keep_error:
            return False, "离开 0x10 02/03 后停止 0x3E 保活失败：" + keep_error
        return True, ""
    if KEEP_ALIVE is None:
        KEEP_ALIVE = SessionKeepAlive(
            _raw_physical_request,
            lock=COMM_LOCK,
            interval=KEEP_ALIVE_INTERVAL,
            timeout=3.0,
        )
    keep_response = KEEP_ALIVE.send_once()
    if not is_suppressed_tester_present_result(keep_response):
        return False, "进入 0x10 %02X 后 0x3E 80 保活返回异常：%s" % (target, _hex(keep_response))
    KEEP_ALIVE.start()
    return True, ""


def main():
    global _VERDICT
    # timing 用例必须走采集-后处理，禁止落入普通 UDS 收发。
    if STATUS == "timing":
        from timing_case_runner import run_timing_case
        result = run_timing_case(
            TIMING_SPEC, RESULT, bus=BUS, can_runtime=CAN_RUNTIME,
            can_channel=CAN_CHANNEL, can_bitrate=CAN_BITRATE,
            can_tx_id=CAN_TX_ID, can_rx_id=CAN_RX_ID,
            can_serial=CAN_SERIAL, can_fd=CAN_FD,
        )
        # 时序 runner 直接写结果文件并返回判定；同步到本脚本的退出码契约，
        # 使"直接运行时序脚本"也能凭退出码发现 FAIL。
        _VERDICT = str((result or {{}}).get("verdict") or "FAIL").upper()
        return _VERDICT
    if STATUS not in ("timing", "skip", "blocked", "needs_data", "pos", "neg", "none"):
        # 兼容旧 manifest 或损坏脚本：任何未知状态都按执行错误 FAIL，
        # 不允许旧的排除/跳过状态进入结果。
        _write("FAIL", "脚本状态非法", "请重新生成脚本并确认 manifest 状态",
               failure_class="RESULT_INVALID")
        return
    # 非可执行用例：直接写结果，不连接硬件（不编造）
    if not EXECUTABLE:
        _write("SKIP" if STATUS == "skip" else "BLOCKED" if STATUS in ("blocked", "needs_data") else "NA",
               "未执行（" + REASON + "）", REASON)
        return
    global uds, NAD_PHYS, get_nrc, bus
    if BUS == "can":
        if not CAN_RUNTIME or not os.path.isfile(CAN_RUNTIME):
            _write("BLOCKED", "未执行", "CAN 运行时脚本未提供：请由 project 传入已生成的 uds_test.py")
            return
        import can
        import importlib.util
        spec = importlib.util.spec_from_file_location("uds_generated_runtime", CAN_RUNTIME)
        runtime = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(runtime)
        bus_kwargs = {{"interface": "vector", "channel": CAN_CHANNEL,
                      "bitrate": CAN_BITRATE, "fd": CAN_FD,
                      "receive_own_messages": False}}
        if CAN_SERIAL:
            bus_kwargs["serial"] = CAN_SERIAL
        bus = can.interface.Bus(**bus_kwargs)
        uds = runtime.UdsClient(bus, CAN_TX_ID, CAN_RX_ID)
        NAD_PHYS = None
        get_nrc = lambda resp: resp[2] if resp and len(resp) >= 3 and resp[0] == 0x7F else None
        opened = True
    else:
        from f1l1_uds import F1L1UDS, NAD_PHYS, get_nrc
        uds = F1L1UDS()
        opened = False
        for _ in range(5):
            try:
                uds.open(); opened = True; break
            except Exception as e:
                time.sleep(3)
    if not opened:
        _write("BLOCKED", "未执行", "F1L1 打开失败（重试 5 次，基础设施未就绪）")
        return
    try:
        ready, setup_note = establish_session()
        if not ready:
            _write("BLOCKED", "未执行", setup_note)
            return
        # 编程/扩展会话的 S3 计时从进入会话开始；业务前置和主请求之间
        # 可能出现等待，因此启用共享锁保护的周期 0x3E 80 保活。
        if _session_id(SESSION) in S3_SESSION_IDS:
            _start_keep_alive()
        for action in PRE_ACTIONS:
            pre = _physical_request(action, 6)
            if not pre or pre[0] != 0x71:
                _write("BLOCKED", "未执行", "前置例程未建立：" + _hex(pre))
                return
        resp = _request(PAYLOAD, 6)
        keep_ready, keep_note = _keep_alive_after_session_entry(resp)
        if not keep_ready:
            _write("FAIL", _hex(resp), keep_note)
            return
        if resp is None:
            if EXPECT == "none":
                if VERIFY_SESSION is not None:
                    verified, verify_note = _verify_session(VERIFY_SESSION)
                    if verified:
                        _write("PASS", "无应答；" + verify_note,
                               "无应答符合预期，项目会话探针确认：" + verify_note)
                    else:
                        _write("FAIL", "无应答；" + verify_note,
                               "项目会话探针确认失败")
                else:
                    _write("PASS", "无应答（抑制正响应/不应答符合预期）", "")
                return
            _write("FAIL", "无应答(超时)", "")
            return
        actual = _hex(resp)
        if resp[0] == 0x7F:
            nrc = get_nrc(resp)
            if EXPECT == "neg" and (EXPECT_NRC is None or nrc in EXPECT_NRC):
                _write("PASS", actual, "负例 NRC 匹配")
            elif EXPECT == "na" and nrc in (0x31, 0x22, 0x7E, 0x7F, 0x33):
                _write("NA", actual, "条件受限（正确拒绝）")
            elif EXPECT == "pos" and nrc in (0x31, 0x22, 0x7E, 0x7F, 0x33) and "受限" in REASON:
                _write("NA", actual, "条件受限（正确拒绝）")
            elif EXPECT == "pos" and nrc in DID_ALLOWED_NRC:
                _write("NA", actual, f"DID {{CASE_DID}} 当前分区允许条件性 NRC 0x{{nrc:02X}}，记录为 NA 而非 FAIL")
            elif EXPECT == "pos" and nrc in (0x31, 0x22) and DID_SUPPORT:
                layer = detect_layer(uds)
                lv = str(DID_SUPPORT.get(layer, "")).upper()
                if layer and lv in ("NRC31", "NRC22", ""):
                    _write("NA", actual, f"DID×层支持：{{CASE_DID}} 当前层 {{layer}} 不支持（{{lv}}），NRC 属正确拒绝")
                    return
                _write("FAIL", actual, f"NRC 0x{{nrc:02X}} 与期望不符（{{CASE_DID}} 在 {{layer}} 层矩阵={{lv}}）")
            else:
                _write("FAIL", actual, f"NRC 0x{{nrc:02X}} 与期望不符")
        else:
            sid = PAYLOAD[0] if PAYLOAD else None
            if EXPECT == "pos" and sid is not None and resp[0] == (sid & 0x3F) + 0x40:
                if RESPONSE_CHECK == "exact" and EXPECT_PREFIX and resp[:len(EXPECT_PREFIX)] != EXPECT_PREFIX:
                    want = " ".join(f"{{b:02X}}" for b in EXPECT_PREFIX)
                    _write("FAIL", actual, f"正响应数据与期望不符（期望前缀 {{want}}）")
                elif VERIFY_SESSION is not None and PAYLOAD != (_session_probe_request() or []):
                    verified, verify_note = _verify_session(VERIFY_SESSION)
                    if verified:
                        _write("PASS", actual + "；" + verify_note,
                               "正响应数据匹配，项目会话探针确认")
                    else:
                        _write("FAIL", actual + "；" + verify_note,
                               "项目会话探针确认失败")
                else:
                    _write("PASS", actual,
                           "正响应数据匹配" if RESPONSE_CHECK == "exact" else "协议正响应匹配（版本/状态相关数据已记录）")
            elif EXPECT == "na":
                _write("PASS", actual, "条件项实际可执行（正响应）")
            else:
                _write("FAIL", actual, "响应与期望不符")
    finally:
        keep_error = _stop_keep_alive()
        if keep_error:
            _write("FAIL", "0x3E 保活异常", "0x3E 周期保活失败：" + keep_error)
        if BUS == "can":
            bus.shutdown()
        else:
            uds.close()


def _request(payload, timeout):
    with COMM_LOCK:
        return _raw_request(payload, timeout)


def _raw_request(payload, timeout):
    if BUS == "can":
        return uds.send_request(payload, timeout_ms=int(timeout * 1000))
    return _request_with_trace(REQUEST_NAD, payload, timeout)


def _physical_request(payload, timeout):
    with COMM_LOCK:
        return _raw_physical_request(payload, timeout)


def _raw_physical_request(payload, timeout):
    if BUS == "can":
        return uds.send_request(payload, timeout_ms=int(timeout * 1000))
    return _request_with_trace(NAD_PHYS, payload, timeout)


def _request_with_trace(nad, payload, timeout):
    """执行普通 LIN 请求并把每次独立事务合并到本条用例证据。"""
    global TRACE_TRANSACTION
    if not TRACE_REQUIRED:
        return uds.request(nad, payload, timeout=timeout)
    TRACE_TRANSACTION += 1
    transaction_id = "%s-txn-%d" % (CASE, TRACE_TRANSACTION)
    response, trace, _, _ = uds.request_with_trace(
        nad, payload, timeout=timeout, retry=2,
        transaction_id=transaction_id,
    )
    TRACE_EVENTS.extend(trace or [])
    return response


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        # 单条脚本无论异常发生在硬件初始化、协议解析还是结果处理，
        # 都必须留下 FAIL 证据；退出码 2 表示异常/崩溃，与判定 FAIL(1) 区分。
        _write("FAIL", "脚本执行异常", f"{{type(exc).__name__}}: {{exc}}",
               failure_class="SCRIPT_ERROR")
        sys.exit(2)
    # 单条脚本退出码契约：FAIL（含时序 FAIL）返回 1，其余（PASS/NA/
    # BLOCKED/SKIP）返回 0。直接运行单脚本时退出码可信，不再依赖
    # run_all 兜底才能发现 FAIL。
    sys.exit(1 if _VERDICT == "FAIL" else 0)
'''


def sanitize(cid):
    return re.sub(r"[^0-9A-Za-z_]", "_", str(cid))


def sanitize_strong(cid):
    """文件系统安全的用例 ID：清洗非法字符并折叠连续下划线。

    A-B 与 A_B 简单清洗后会同名（脚本互相覆盖）；折叠后仍同名的组合
    由 main() 的显式查重拦截为生成错误，而不是静默覆盖。
    """
    collapsed = re.sub(r"_+", "_", sanitize(cid)).strip("_")
    return collapsed or "case"


_CASE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$")


def is_safe_case_id(cid):
    """case_id 会进入结果文件路径与生成脚本文本，必须限定字符集。

    拒绝 .. / 绝对路径 / 引号等：防越界写结果文件，也防 service 段
    注入生成源码。
    """
    return bool(_CASE_ID_RE.match(str(cid)))


def service_token(cid):
    """case_id 第二段作为服务标识；非白名单 token 一律置空，不进生成源码。"""
    parts = str(cid).split("_")
    token = parts[1] if len(parts) > 1 else ""
    if re.fullmatch(r"[0-9A-Za-z]{1,16}", token):
        return token
    return ""


def is_case_selected(case):
    """select=否 的用例不参与执行（不生成脚本、不进 manifest）。"""
    value = str(case.get("select") if case.get("select") is not None else "").strip()
    return value.lower() not in ("否", "no", "n", "false", "0")


_TEMPLATE_FIELD_RE = re.compile(r"(?<!{){([A-Za-z_][A-Za-z0-9_]*)(?:![A-Za-z])?}(?!})")


def template_fields():
    """提取 SCRIPT_TPL 中所有 .format 占位符名（排除 {{ }} 转义，支持 !r 转换）。

    生成前用它与实际传参集合比对：新增占位符后若 main() 漏填，会在生成
    第一个脚本前立即报错，而不是等到 .format KeyError 崩在生成中途。
    """
    return set(_TEMPLATE_FIELD_RE.findall(SCRIPT_TPL))


def case_fingerprint(case):
    """生成稳定指纹，供增量重建和结果追溯使用。"""
    payload = json.dumps(case, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def main():
    ap = argparse.ArgumentParser(description="用例 ↔ 脚本 一一对应生成器")
    ap.add_argument("--cases", "-c", required=True, help="设计用例 JSON（case-schema）")
    ap.add_argument("--parsed", "-p", help="uds_parsed.json（调查表解析，提供 DID 属性）")
    ap.add_argument("--bus", choices=["lin", "can"], default="lin")
    ap.add_argument("--nad", type=lambda s: int(s, 0), default=None,
                    help="LIN 物理 NAD；未传时使用项目配置 transport.physical_nad")
    ap.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    ap.add_argument("--out-dir", "-o", default="./case_scripts")
    ap.add_argument("--project-context", default="",
                    help="project_context.json；写入 manifest 绑定摘要并供 run_all 执行前校验")
    ap.add_argument("--sa-key-file", default="", help="0x27 密钥文件（占位 0xFF 时 0x27/刷写标 BLOCKED）")
    ap.add_argument("--survey", default="", help="诊断调查表目录或文件（解析 Control Routine 请求长度，自动补全例程参数）")
    ap.add_argument("--did-check", default="", help="DID检查表 xlsx（DID×APP/PBL/SBL 支持矩阵，用于 0x22 分层受限判定）")
    ap.add_argument("--target-partition", choices=["APP", "PBL", "SBL"], default="",
                    help="本批用例的显式目标分区；用例自身字段优先")
    ap.add_argument("--partition-gate", choices=["enforce", "report", "off"], default="enforce",
                    help="UDS分区/语义门禁：enforce=不允许问题用例生成，report=只记录，off=关闭")
    ap.add_argument("--can-runtime", default="", help="CAN 运行时脚本（通常由 uds_runner project 自动传入）")
    ap.add_argument("--channel", default="0")
    ap.add_argument("--bitrate", type=int, default=None)
    ap.add_argument("--tx-id", type=lambda s: int(s, 0), default=None)
    ap.add_argument("--rx-id", type=lambda s: int(s, 0), default=None)
    ap.add_argument("--serial", default="")
    ap.add_argument("--can-fd", action="store_true", default=False)
    ap.add_argument("--confirmed", action="store_true", default=False,
                    help="明确确认调查表缺失关键 CAN 参数时使用硬编码默认值")
    ap.add_argument("--only", nargs="+", default=[],
                    help="仅增量重建指定 case_id；已有 out-dir 中的其它 manifest 条目保留")
    ap.add_argument("--prereq", default="",
                    help="service_prereq.json（由 sddb_extract.py 生成，用于 0x31 两步流）")
    ap.add_argument("--exclude-service", action="append", default=[],
                    help="本轮明确排除的服务，可重复传入或用逗号分隔，例如 --exclude-service 0x27")
    args = ap.parse_args()

    try:
        project_config = load_project_config(args.project_config or None)
    except ValueError as exc:
        print(f"[ERROR] 项目配置读取失败: {exc}")
        sys.exit(1)
    project_config_source = (
        str(Path(args.project_config).expanduser().resolve())
        if args.project_config else "兼容默认配置"
    )
    transport = project_config.get("transport", {})
    physical_nad = int(transport.get("physical_nad", 0x51))
    functional_nad = int(transport.get("functional_nad", physical_nad))
    if args.nad is None:
        args.nad = physical_nad
    transport_nads = (physical_nad, functional_nad)
    default_session_id = int(project_config["sessions"]["default"])
    session_names = {
        int(session_id): str(name)
        for session_id, name in project_config["sessions"]["names"].items()
    }
    session_id_by_name = {name: session_id for session_id, name in session_names.items()}
    # Runtime scripts accept both configured display labels and stable
    # compatibility aliases, so renaming a legacy session does not break
    # generated scripts.
    for session_id, alias in ((0x01, "default"), (0x02, "programming"),
                              (0x03, "extended")):
        if session_id in session_names:
            session_id_by_name.setdefault(alias, session_id)
    s3_session_ids = [int(value) for value in project_config["sessions"].get("s3_required", [])]
    session_probe_did = canonical_did(
        project_config.get("generation", {}).get("session_probe_did")
    )

    if not os.path.exists(args.cases):
        print(f"[ERROR] 用例文件不存在: {args.cases}")
        sys.exit(1)
    with open(args.cases, encoding="utf-8", errors="replace") as f:
        data = json.load(f)
    cases = data.get("cases", data if isinstance(data, list) else [])
    total_before_filter = len(cases)
    cases = [c for c in cases if is_case_selected(c)]
    only_ids = {
        part.strip()
        for value in args.only
        for part in str(value).split(",")
        if part.strip()
    }
    if only_ids:
        cases = [c for c in cases if str(c.get("case_id") or "") in only_ids]
        if not cases:
            print("[ERROR] --only 未匹配到任何已选用例: " + ", ".join(sorted(only_ids)))
            sys.exit(1)
    skipped_by_select = total_before_filter - len(cases)
    if skipped_by_select:
        print(f"[INFO] select=否 过滤: {skipped_by_select} 条未选用例不生成脚本、不执行"
              f"（确需执行请在用例表改为 是 后重新生成）")

    parsed = {}
    if args.parsed and os.path.exists(args.parsed):
        with open(args.parsed, encoding="utf-8", errors="replace") as f:
            parsed = json.load(f)
    prereq_matrix = {}
    if args.prereq:
        if not os.path.isfile(args.prereq):
            print(f"[ERROR] 前置矩阵文件不存在: {args.prereq}")
            sys.exit(1)
        with open(args.prereq, encoding="utf-8", errors="replace") as f:
            prereq_data = json.load(f)
        prereq_matrix = (((prereq_data.get("services") or {}).get("0x31") or {}).get("objects") or {})
    parsed_can = parsed.get("can_config") or {}
    # 直接调用 gen-scripts 时也从同一份调查表配置取值；project 调用时
    # 会显式传入已解析的最终值，避免主脚本/用例脚本使用不同 CAN 参数。
    can_missing = []
    if args.bitrate is None and parsed_can.get("bitrate") is None:
        can_missing.append("bitrate")
    if args.tx_id is None and parsed_can.get("tx_id") is None:
        can_missing.append("tx_id")
    if args.rx_id is None and parsed_can.get("rx_id") is None:
        can_missing.append("rx_id")
    if args.bus == "can" and can_missing and not args.confirmed:
        print("[ERROR] CAN 用例脚本生成缺少关键参数: " + ", ".join(can_missing))
        print("[ERROR] 请补充调查表/CLI 参数，或传入 --confirmed 明确确认默认值。")
        sys.exit(1)
    if args.bitrate is None:
        args.bitrate = int(parsed_can.get("bitrate", 500000))
    if args.tx_id is None:
        args.tx_id = int(str(parsed_can.get("tx_id", "0x7E0")), 0)
    if args.rx_id is None:
        args.rx_id = int(str(parsed_can.get("rx_id", "0x7E8")), 0)
    if not args.can_fd and parsed_can.get("can_fd") is True:
        args.can_fd = True
    restricted = build_restricted_dids(parsed, project_config)
    rid_len_map = parse_rid_request_len(args.survey) if args.survey else {}
    did_matrix = parse_did_matrix(args.did_check) if args.did_check else {}
    source_files = tuple(
        str(value) for value in (parsed.get("source_file"), args.did_check)
        if value
    )
    partition_sources = {
        name: tuple(
            source for source in source_files
            if name in os.path.basename(source).upper() or source == args.did_check
        )
        for name in ("APP", "PBL", "SBL")
    }
    partition_model = build_partition_model(
        did_matrix=did_matrix,
        parsed=parsed,
        source_files=source_files,
        diagnostic_sources=partition_sources,
        timing_parameters=parsed.get("timing_parameters") or DEFAULT_TIMING_PARAMETERS,
    )
    excluded_services = {
        part.strip().lower()
        for value in args.exclude_service
        for part in str(value).split(",")
        if part.strip()
    }

    os.makedirs(args.out_dir, exist_ok=True)
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    manifest = {}
    previous_manifest = {}
    existing_manifest = os.path.join(args.out_dir, "manifest.json")
    if only_ids:
        if not os.path.isfile(existing_manifest):
            print(f"[ERROR] --only 需要已有 manifest.json 作为增量基线: {existing_manifest}")
            sys.exit(1)
        with open(existing_manifest, encoding="utf-8", errors="replace") as f:
            previous_manifest = json.load(f)
        manifest = dict(previous_manifest.get("cases") or {})
    project_context_binding = previous_manifest.get("project_context_binding")
    if args.project_context:
        try:
            if only_ids and not project_context_binding:
                raise ProjectArtifactBindingError(
                    "旧 manifest 未绑定 project_context，禁止用 --only 跨项目继承；请先全量生成"
                )
            new_binding = build_project_context_binding(args.project_context, args.out_dir)
            if project_context_binding:
                validate_project_context_binding(
                    project_context_binding,
                    args.out_dir,
                    expected_context_path=args.project_context,
                )
            project_context_binding = new_binding
        except (OSError, ProjectArtifactBindingError, ValueError) as exc:
            print(f"[ERROR] project_context 绑定失败: {exc}")
            sys.exit(1)
    safe_names = {sanitize_strong(cid): cid for cid in manifest}
    seen_input_ids = set()
    for c in cases:
        cid = c.get("case_id")
        if not cid:
            continue
        if not is_safe_case_id(cid):
            # case_id 直接进入结果文件路径与生成脚本文本；非法字符即拒绝，
            # 防 .. / 绝对路径越界写文件，也防引号注入生成源码。
            print("[ERROR] 用例 ID 含非法字符或超长（仅允许字母/数字/下划线/连字符，首字符为字母或数字，≤128 字符）: %r" % cid)
            sys.exit(1)
        safe_name = sanitize_strong(cid)
        if cid in seen_input_ids:
            print(f"[ERROR] 输入用例中存在重复用例 ID: {cid}")
            sys.exit(1)
        seen_input_ids.add(cid)
        # A-B 与 A_B 清洗后同名曾静默覆盖脚本；此处显式报错而非覆盖。
        if safe_name in safe_names and safe_names[safe_name] != cid:
            print(f"[ERROR] 清洗后同名用例 ID: {cid} 与 {safe_names[safe_name]}")
            sys.exit(1)
        safe_names[safe_name] = cid
        service = service_token(cid)
        payload, pstatus, preason = request_payload(
            c.get("procedure"), args.bus, args.nad, rid_len_map, service, transport_nads
        )
        case_did = ""
        did_support = {}
        if payload and len(payload) >= 3 and payload[0] in (0x22, 0x2E):
            case_did = "%02X%02X" % (payload[1], payload[2])
            did_support = did_matrix.get(case_did, {})
        pre_actions = routine_prerequisites_from_matrix(c, payload, prereq_matrix)
        routine_id = (
            "%02X%02X" % (payload[2], payload[3])
            if payload and len(payload) >= 4 and payload[0] == 0x31 else ""
        )
        routine_meta = prereq_matrix.get(routine_id, {}) if routine_id else {}
        if not isinstance(routine_meta, dict):
            routine_meta = {}
        req_nad = request_nad(c.get("procedure"), args.bus, args.nad, transport_nads)
        expect, expect_nrc, ereason = expected_info(c, restricted, project_config)
        expect_prefix = expected_response_prefix(
            c.get("expected"), args.bus, args.nad, transport_nads
        )
        response_check = response_check_level(c, expect_prefix)
        key_ready = key_file_ready(args.sa_key_file, scripts_dir)
        procedure_session = session_from_procedure(c.get("procedure"), project_config)
        payload_session = session_from_payload(payload, project_config)
        precondition_session = session_from_precondition(c.get("precondition"), project_config)
        if service == "0x10" and payload and payload[0] == 0x10:
            # 0x10 用例的主请求本身就是“源会话→目标会话”的被测动作。
            # SESSION 必须表示主请求发送前的源会话；否则默认→02/03 会
            # 在 establish_session() 中先执行一次目标切换，主请求再重复
            # 切换，实际测到的是重复切换而不是首次跳转。
            session = precondition_session
        else:
            session = procedure_session or payload_session or precondition_session
        session_id = normalize_session(session, project_config)
        runtime_session = session_runtime_name(session_id, project_config)
        session_setup_route = list(setup_route(default_session_id, session, project_config))
        keep_alive_required = should_keep_session_alive_for_case(
            session, payload, req_nad, args.nad, project_config
        )
        gate_case = dict(c)
        if args.target_partition and not any(
                c.get(key) for key in ("target_partition", "partition", "ecu_partition", "layer")):
            gate_case["target_partition"] = args.target_partition
        gate_decision = evaluate_case(
            gate_case,
            payload=payload,
            model=partition_model,
            service=service,
            expectation=expect,
            expected_nrc=expect_nrc,
            session=session,
            key_ready=key_ready,
            project_config=project_config,
        )
        gate_blocks = gate_decision.decision in {"REJECT", "REVIEW_REQUIRED", "BLOCKED"}
        if service.lower() in excluded_services:
            status = "skip"
            reason = "用户明确排除服务 %s，本轮不向 ECU 发送请求；解除排除后重新生成" % service
        elif args.partition_gate == "enforce" and gate_blocks:
            status = "blocked"
            reason = "UDS用例门禁未通过：" + (gate_decision.reason or gate_decision.decision)
        elif expect == "timing":
            status = "timing"
        elif expect == "blocked":
            status = "blocked"
        elif service.lower() == "0x27" and not key_ready and security_key_required(c, payload, project_config):
            # 只有真正发送 Key/执行解锁的正例依赖客户授权密钥；Seed、
            # 非法子功能、错误长度、延时/重试等负例不应被密钥缺失连带阻塞。
            status = "blocked"
        elif pstatus != "executable":
            status = pstatus
        elif routine_meta.get("two_step") and routine_meta.get("requires_start_data") and not pre_actions:
            status = "needs_data"
        elif security_key_required(c, payload, project_config) and not key_ready:
            status = "blocked"
        else:
            status = expect
        if status == "blocked" and service.lower() == "0x27" and not key_ready:
            reason = "缺少客户授权的真实 0x27 SeedKey/密钥材料；仅真实解锁/发送 Key 用例 BLOCKED，不向 ECU 发送请求"
        elif status == "blocked" and expect == "blocked":
            # The explicit authorization gate is more informative than a
            # secondary placeholder-data diagnostic for protected 0x2E/0x31.
            reason = ereason
        else:
            reason = (preason or ereason) if status != "executable" else ereason
        if (args.partition_gate == "enforce" and status == "blocked"
                and gate_decision.decision in {"REJECT", "REVIEW_REQUIRED", "BLOCKED"}):
            reason = "UDS用例门禁：" + (gate_decision.reason or gate_decision.decision)
        verify_session = expected_session(c.get("expected"), project_config)
        fname = "case_%s.py" % safe_name
        partition_context = partition_model.case_context(gate_case, case_did or None)
        gate_decision_dict = gate_decision.to_dict()
        timing_spec = build_timing_spec(
            cid, payload, session, req_nad, expect_prefix,
            c.get("procedure", ""), c.get("expected", ""),
            tx_frame_id=(args.tx_id if args.bus == "can" else None),
            rx_frame_id=(args.rx_id if args.bus == "can" else None),
            target_partition=gate_decision.target_partition,
            p2_limit=(partition_model.p2_limit(gate_decision.target_partition)
                      if gate_decision.target_partition else None),
            allowed_response_nrcs=gate_decision.allowed_nrc,
            bus=args.bus,
            default_session_id=default_session_id,
            session_id_by_name=session_id_by_name,
        ) if status == "timing" else {}
        executable = (pstatus == "executable" and status not in ("blocked", "needs_data", "timing", "skip"))
        trace_required = bool(args.bus == "lin" and executable)
        script_kwargs = dict(
            case_id=cid, service=service,
            session=runtime_session, session_setup_route=session_setup_route,
            status=status, expect=expect,

            reason=reason,  # 模板内 {reason!r} 已安全转义引号/反斜杠；勿再手动 replace（会造成双重转义）
            result_path=os.path.join(args.out_dir, "results", safe_name + ".json"),
            nad=args.nad, request_nad=req_nad, payload=payload or [], pre_actions=pre_actions,
            default_session_id=default_session_id,
            session_id_by_name=session_id_by_name,
            session_names=session_names,
            s3_session_ids=s3_session_ids,
            session_probe_did=session_probe_did,
            expect_nrc=expect_nrc, expect_prefix=expect_prefix, response_check=response_check, verify_session=verify_session,
            scripts_dir=scripts_dir, desc=(c.get("test_point") or "")[:80],
             case_did=case_did, did_support=did_support,
             did_allowed_nrc=gate_decision.allowed_nrc,
            partition_context=partition_context,
            gate_decision=gate_decision_dict,
            gate_findings=gate_decision_dict.get("findings", []),
            keep_alive_required=keep_alive_required,
            keep_alive_interval=DEFAULT_INTERVAL_SECONDS,
            keep_alive_subfunction=KEEP_ALIVE_SUBFUNCTION,
            bus=args.bus, can_runtime=args.can_runtime, can_channel=args.channel,
            can_bitrate=args.bitrate, can_tx_id=args.tx_id, can_rx_id=args.rx_id,
            can_serial=args.serial, can_fd=args.can_fd,
            timing_trace=os.path.join(scripts_dir, "timing_trace.py"),
            timing_spec=timing_spec,
            executable=executable,
            trace_required=trace_required,
        )
        # 生成前冒烟：实际传参必须覆盖模板全部占位符（防新增占位符漏填）。
        missing_fields = template_fields() - set(script_kwargs)
        if missing_fields:
            print("[ERROR] SCRIPT_TPL 缺少占位符参数: " + ", ".join(sorted(missing_fields)))
            sys.exit(1)
        script = SCRIPT_TPL.format(**script_kwargs)
        with open(os.path.join(args.out_dir, fname), "w", encoding="utf-8", errors="replace") as f:
            f.write(script)
        manifest[cid] = {
            "script": fname, "status": status, "reason": reason,
            "service": service,
            "session": runtime_session,
            "session_name": session,
            "default_session_id": default_session_id,
            "session_setup_route": session_setup_route,
            "session_keep_alive": keep_alive_required,
            "keep_alive_interval": DEFAULT_INTERVAL_SECONDS,
            "keep_alive_subfunction": KEEP_ALIVE_SUBFUNCTION,
            "partition_context": partition_context,
            "gate_decision": gate_decision_dict,
            # manifest 是执行阶段的设计基线；时序结果必须与生成时的
            # case_id/metric/payload/阈值完全一致，不能运行后被普通 P2
            # 结果或手工修改的 spec 冒充。
            "timing_spec": timing_spec if status == "timing" else None,
            "routine_two_step": bool(routine_meta.get("two_step") or pre_actions),
            "routine_id": routine_id,
            "prereq_matrix": args.prereq or "",
            "case_fingerprint": case_fingerprint(c),
            "project": project_config.get("project", "legacy-default"),
            "project_config": project_config_source,
            "session_probe_did": session_probe_did,
            "trace_required": trace_required,
        }

    # manifest + run_all
    with open(os.path.join(args.out_dir, "manifest.json"), "w", encoding="utf-8", errors="replace") as f:
        json.dump({
            "total": len(manifest),
            "project": project_config.get("project", "legacy-default"),
            "project_config": project_config_source,
            "project_context_binding": project_context_binding,
            "cases": manifest,
        }, f, ensure_ascii=False, indent=2)
    runner = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""run_all: 顺序执行全部用例脚本并汇总结果（用例 ↔ 脚本 一一对应）。

结果契约为 PASS / FAIL / BLOCKED / NA / SKIP；脚本异常、缺结果和非法
结果状态归一为 FAIL；明确排除项 SKIP 保留。
单条脚本退出码契约（生成器模板固化）：FAIL=1、异常/崩溃=2、其余=0；
本编排器据此区分"判定 FAIL"与"脚本异常退出"，不再把 FAIL 误判为崩溃。
"""
import json, os, re, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_SCRIPTS = __UDS_RESULT_CONTRACT_PATH__
if SKILL_SCRIPTS not in sys.path:
    sys.path.insert(0, SKILL_SCRIPTS)
from result_contract import normalize_result
from project_artifact_binding import ProjectArtifactBindingError, validate_project_context_binding
VALID = {"PASS", "FAIL", "BLOCKED", "NA", "SKIP"}
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except AttributeError:
    pass

def normalize(item, cid, fallback="", meta=None, trace_path="", fallback_failure_class=""):
    item = dict(item or {})
    item.setdefault("case_id", cid)
    # 即使专项脚本在导入/初始化阶段崩溃，汇总结果也必须保留该条
    # 时序用例的身份、指标和独立 trace 位置；否则报告会把它当成
    # 普通 FAIL 明细，无法证明 15 条时序是否逐条覆盖。
    if isinstance(meta, dict) and str(meta.get("status") or "").lower() == "timing":
        timing_spec = meta.get("timing_spec") if isinstance(meta.get("timing_spec"), dict) else {}
        item.setdefault("service", meta.get("service") or "TimeParm")
        item.setdefault("desc", "逐用例时序测量")
        item.setdefault("session", meta.get("session") or timing_spec.get("session") or "default")
        item.setdefault("expect", "timing")
        item.setdefault("payload", list(timing_spec.get("payload") or []))
        item.setdefault("timing_metric", timing_spec.get("metric") or "")
        item.setdefault("timing_spec", timing_spec)
        item.setdefault("evidence", trace_path)
    if isinstance(meta, dict) and meta.get("trace_required") and str(item.get("verdict") or "").upper() in ("PASS", "FAIL"):
        item.setdefault("evidence", trace_path)
    verdict = str(item.get("verdict") or "").upper()
    if verdict not in VALID:
        item["verdict"] = "FAIL"
        item["note"] = (str(item.get("note") or "") + "；非法/历史结果状态已归一为 FAIL").strip("；")
    else:
        item["verdict"] = verdict
    if fallback and not item.get("note"):
        item["note"] = fallback
    return normalize_result(item, fallback_failure_class=fallback_failure_class)

def validate_trace_result(item, cid, meta, trace_path):
    """已执行的 LIN 用例必须绑定本条原始硬件帧轨迹。"""
    if not meta.get("trace_required") or item.get("verdict") not in ("PASS", "FAIL"):
        return item
    problems = []
    evidence = str(item.get("evidence") or "")
    if not evidence:
        problems.append("缺少独立 LIN trace evidence 路径")
    elif os.path.abspath(evidence) != os.path.abspath(trace_path):
        problems.append("evidence 未指向当前用例 trace 文件")
    if not os.path.isfile(trace_path):
        problems.append("当前用例独立 LIN trace 文件不存在")
    else:
        try:
            with open(trace_path, encoding="utf-8", errors="replace") as handle:
                trace = json.load(handle)
            if trace.get("schema") != "uds-lin-trace.v1":
                problems.append("trace schema 不正确")
            if trace.get("case_id") != cid:
                problems.append("trace.case_id 与当前用例不一致")
            if trace.get("bus") != "lin":
                problems.append("trace.bus 不是 LIN")
            events = trace.get("events")
            if not isinstance(events, list) or not events:
                problems.append("measurement 缺少当前用例的原始 LIN trace")
            elif any(not isinstance(event, list) or len(event) < 4 for event in events):
                problems.append("原始 LIN trace 事件格式不完整")
        except (OSError, ValueError, TypeError) as exc:
            problems.append("trace 文件读取失败：%s" % exc)
    if problems:
        item["verdict"] = "FAIL"
        item["note"] = (str(item.get("note") or "") + "；LIN 证据完整性失败：" + "，".join(problems)).strip("；")
    return item

def validate_timing_result(item, cid, meta, result_path, trace_path):
    """拒绝把普通 UDS/P2 结果冒充成独立时序结果。"""
    if str(meta.get("status") or "").lower() != "timing":
        return item
    # SKIP 只允许表示用户明确排除的普通用例。时序用例一旦进入执行
    # 链路，就必须有独立采集结果；任何历史/手工写入的 SKIP 都是未完成
    # 测试，直接按 FAIL 统计，不改变报告对普通 SKIP 的展示能力。
    if item.get("verdict") == "SKIP":
        item["verdict"] = "FAIL"
        item["note"] = (str(item.get("note") or "")
                         + "；时序用例不允许 SKIP，未完成独立采集，已归一为 FAIL").strip("；")
        item["failure_class"] = "RESULT_INVALID"
    problems = []
    spec = item.get("timing_spec")
    metric = item.get("timing_metric")
    expected_spec = meta.get("timing_spec")
    if not isinstance(expected_spec, dict):
        problems.append("manifest 缺少生成时的独立 timing_spec")
    if not isinstance(spec, dict):
        problems.append("缺少 timing_spec")
    else:
        if spec.get("case_id") != cid:
            problems.append("timing_spec 未绑定当前 case_id")
        if not spec.get("metric"):
            problems.append("timing_spec 缺少 metric")
        elif metric != spec.get("metric"):
            problems.append("timing_metric 与 timing_spec.metric 不一致")
        if isinstance(expected_spec, dict) and spec != expected_spec:
            problems.append("结果 timing_spec 与 manifest 设计基线不一致")
    if item.get("service") != "TimeParm" or item.get("expect") != "timing":
        problems.append("时序结果未标记为 TimeParm/timing")
    evidence = str(item.get("evidence") or "")
    if not evidence:
        problems.append("缺少独立 trace evidence 路径")
    elif os.path.abspath(evidence) != os.path.abspath(trace_path):
        problems.append("evidence 未指向当前用例 trace 文件")
    if not os.path.isfile(trace_path):
        problems.append("当前用例独立 trace 文件不存在")
    else:
        try:
            trace = json.load(open(trace_path, encoding="utf-8", errors="replace"))
            if trace.get("case_id") != cid:
                problems.append("trace.case_id 与当前用例不一致")
            if isinstance(spec, dict) and trace.get("metric") != spec.get("metric"):
                problems.append("trace.metric 与当前 timing_spec 不一致")
            measurement = trace.get("measurement")
            # 硬件/驱动异常已经由 runner 作为 FAIL 记录；有错误证据时不
            # 再要求不存在的测量值。只要没有 error，却声称 PASS/FAIL，
            # 就必须满足该指标自己的数据形状和原始轨迹，防止普通 P2
            # 结果、人工填入的单个数值或空 trace 冒充其它时序项。
            if not isinstance(measurement, dict):
                problems.append("measurement 不是独立时序测量对象")
            elif not measurement.get("error"):
                if item.get("run_id") and trace.get("run_id") != item.get("run_id"):
                    problems.append("结果与 trace 的 run_id 不一致")
                if item.get("runner") and trace.get("runner") != item.get("runner"):
                    problems.append("结果与 trace 的 runner 身份不一致")
                kind = spec.get("metric") if isinstance(spec, dict) else None
                trace_events = measurement.get("traces")
                if not isinstance(trace_events, list) or not trace_events:
                    problems.append("measurement 缺少当前用例的原始 LIN trace")
                else:
                    has_tx = any(isinstance(event, dict)
                                 and event.get("direction") == "TX"
                                 and event.get("frame_id") == 0x3C
                                 for event in trace_events)
                    has_rx = any(isinstance(event, dict)
                                 and event.get("direction") == "RX"
                                 and event.get("frame_id") == 0x3D
                                 for event in trace_events)
                    tx_kinds = {"p2", "p4", "p2_distribution", "session_transitions",
                                "n_as", "frame_gap", "frame_jitter", "multi_frame",
                                "p2_star", "s3", "s3_boundary", "reset_recovery", "bs_stmin"}
                    rx_kinds = {"p2", "p4", "p2_distribution", "session_transitions",
                                "n_cr", "frame_gap", "multi_frame", "p2_star", "s3",
                                "s3_boundary", "reset_recovery", "bs_stmin"}
                    if kind in tx_kinds and not has_tx:
                        problems.append("measurement 缺少 0x3C TX 请求帧")
                    if kind in rx_kinds and not has_rx:
                        problems.append("measurement 缺少 0x3D RX 响应帧")
                lists = {
                    "p2": "p2_ms", "p4": "p4_ms", "p2_distribution": "p2_ms",
                    "session_transitions": "p2_ms", "n_as": "n_as_ms",
                    "n_cr": "n_cr_ms", "frame_gap": "frame_gap_ms",
                    "reset_recovery": "recovery_ms",
                }
                key = lists.get(kind)
                if key and not isinstance(measurement.get(key), list):
                    problems.append("measurement 缺少独立 %s 样本" % key)
                if kind == "n_as" and (
                        int(measurement.get("request_frame_count", 0) or 0) < 1
                        or int(measurement.get("response_frame_count", 0) or 0) < 1):
                    problems.append("measurement 缺少 N_As 的 0x3C 请求帧或 0x3D 响应帧")
                if kind == "n_cr" and int(measurement.get("response_frame_count", 0) or 0) < 2:
                    problems.append("measurement 缺少 N_Cr 的 FF/CF 响应帧")
                if kind in {"n_cr", "bs_stmin", "multi_frame"} and not measurement.get("response"):
                    problems.append("measurement 缺少完整响应")
                if kind == "p2_star" and (
                        not isinstance(measurement.get("p2_star_ms"), list)
                        or int(measurement.get("pending_count", 0) or 0) < 1):
                    problems.append("measurement 缺少 P2* 的 0x78 pending/最终响应链路")
                if kind == "s3" and (
                        not isinstance(measurement.get("s3_ms"), list)
                        or measurement.get("observed_session") is None):
                    problems.append("measurement 缺少 S3 独立等待或项目会话证据")
                if kind == "s3_boundary" and len(measurement.get("observations") or []) != len(spec.get("expected_sessions") or []):
                    problems.append("measurement 缺少完整 S3 边界分组")
                if kind == "bs_stmin":
                    fc = measurement.get("bs_stmin")
                    if (not isinstance(fc, dict) or fc.get("frame_id") != 0x3C
                            or fc.get("direction") != "TX"
                            or not isinstance(fc.get("payload"), list)
                            or len(fc.get("payload") or []) < 2):
                        problems.append("measurement 缺少独立 0x3C TX BS/STmin 流控帧")
                if kind == "frame_jitter" and (
                        not isinstance(measurement.get("slot_ms"), list)
                        or len(measurement.get("slot_ms") or []) < 2
                        or measurement.get("jitter_ms") is None):
                    problems.append("measurement 缺少独立帧抖动样本")
                if kind == "multi_frame" and (
                        int(measurement.get("request_frame_count", 0) or 0) < 2
                        or int(measurement.get("response_frame_count", 0) or 0) < 2
                        or not isinstance(measurement.get("n_as_ms"), list)
                        or not isinstance(measurement.get("n_cr_ms"), list)):
                    problems.append("measurement 缺少完整多帧 N_As/N_Cr 证据")
                if kind == "reset_recovery" and (
                        measurement.get("reset_response_ok") is not True
                        or measurement.get("recovered_session") != int(meta.get("default_session_id", 1))
                        or not isinstance(measurement.get("recovery_ms"), list)):
                    problems.append("measurement 缺少复位响应或复位后默认会话证据")
                if kind in {"p2", "p2_distribution", "session_transitions"}:
                    integrity = measurement.get("trace_integrity")
                    if not isinstance(integrity, dict):
                        problems.append("measurement 缺少 P2 原始 trace 一致性校验")
                    else:
                        if integrity.get("status") != "PASS":
                            problems.append("P2 原始 trace 一致性校验未通过")
                        if measurement.get("p2_ms") != measurement.get("trace_p2_ms"):
                            problems.append("p2_ms 与 trace_p2_ms 不一致")
                        if any(not event.get("transaction_id") or event.get("transaction_id") == "unassigned"
                               for event in (trace_events or []) if isinstance(event, dict)):
                            problems.append("P2 trace 存在未分配 transaction_id 的事件")
        except (OSError, ValueError, TypeError) as exc:
            problems.append("trace 文件读取失败：%s" % exc)
    if problems:
        item["verdict"] = "FAIL"
        item["failure_class"] = "RESULT_INVALID"
        item["note"] = (str(item.get("note") or "") + "；时序证据完整性失败：" + "，".join(problems)).strip("；")
    return item

def main():
    manifest = json.load(open(os.path.join(HERE, "manifest.json"), encoding="utf-8", errors="replace"))
    binding = manifest.get("project_context_binding")
    if binding:
        try:
            validate_project_context_binding(binding, HERE)
        except (OSError, ProjectArtifactBindingError, ValueError) as exc:
            print("[BLOCKED] 生成产物与 project_context 绑定校验失败: %s" % exc)
            sys.exit(2)
    else:
        print("[WARN] manifest 未绑定 project_context，按兼容模式执行")
    results = {}
    for cid, meta in manifest["cases"].items():
        sp = os.path.join(HERE, meta["script"])
        # 结果文件名必须与生成阶段同规则清洗（防 case_id 清洗差异导致读写错位）
        rp = os.path.join(HERE, "results", re.sub(r"_+", "_", re.sub(r"[^0-9A-Za-z_]", "_", cid)).strip("_") + ".json")
        trace = os.path.splitext(rp)[0] + ".trace.json"
        for stale in (rp, trace):
            if os.path.exists(stale):
                try:
                    os.remove(stale)
                except OSError as exc:
                    # DLP 加密目录下 os.remove 会被安全删除拦截（实测 2026-08-28）：
                    #   OSError('[safe-delete][SAFE_DELETE_FAIL_CLOSED] ...windows-sandbox-recycle-bin-unavailable')
                    # 降级为改名隔离（os.rename 在加密目录可用），保留"脚本运行前
                    # 旧结果不可见"语义，不阻断执行；改名都失败才拒绝采用 stale。
                    import time as _stale_t
                    backup = "%s.stale.%s.%d" % (stale, _stale_t.time(), os.getpid())
                    try:
                        os.rename(stale, backup)
                    except OSError:
                        results[cid] = normalize({}, cid, "无法清理旧结果，拒绝采用 stale result：%s" % exc,
                                                 meta=meta, trace_path=trace,
                                                 fallback_failure_class="RESULT_INVALID")
                        continue
        if cid in results:
            continue
        if not os.path.isfile(sp):
            results[cid] = normalize({}, cid, "用例脚本不存在", meta=meta, trace_path=trace,
                                     fallback_failure_class="SCRIPT_ERROR")
            continue
        r = subprocess.run([sys.executable, sp], capture_output=True, text=True, encoding="utf-8", errors="replace")
        out = r.stdout.strip()
        if out: print(out)
        # 单条脚本退出码契约（生成器模板固化）：FAIL 判定=1、异常/崩溃=2、其余=0。
        # 只有"判定 FAIL"(exit 1) 且结果文件含合法判定时才采用结果文件（含 FAIL
        # 明细与证据）；其余非零退出码一律按脚本异常/崩溃处理，不采用任何可能
        # 过期的结果文件（例如崩溃前写下的 BLOCKED）。
        if r.returncode == 1 and os.path.exists(rp):
            try:
                data = json.load(open(rp, encoding="utf-8", errors="replace"))
            except (OSError, ValueError, TypeError):
                data = None
            if data and str(data.get("verdict") or "").upper() in VALID:
                checked = validate_timing_result(
                    normalize(data, cid, meta=meta, trace_path=trace),
                    cid, meta, rp, trace,
                )
                results[cid] = validate_trace_result(checked, cid, meta, trace)
                continue
        if r.returncode != 0:
            results[cid] = normalize({"actual": "脚本异常退出(exit %d)" % r.returncode,
                                      "note": (r.stderr or r.stdout)[-200:]}, cid,
                                     meta=meta, trace_path=trace,
                                     fallback_failure_class="SCRIPT_ERROR")
            continue
        if os.path.exists(rp):
            try:
                checked = validate_timing_result(
                    normalize(json.load(open(rp, encoding="utf-8", errors="replace")), cid,
                              meta=meta, trace_path=trace),
                    cid, meta, rp, trace,
                )
                results[cid] = validate_trace_result(checked, cid, meta, trace)
            except (OSError, ValueError, TypeError) as exc:
                results[cid] = normalize({}, cid, "结果 JSON 读取失败：%s" % exc,
                                         meta=meta, trace_path=trace,
                                         fallback_failure_class="RESULT_INVALID")
        else:
            results[cid] = normalize({"actual": "脚本未输出结果", "note": (r.stderr or "")[-200:]}, cid,
                                     meta=meta, trace_path=trace,
                                     fallback_failure_class="RESULT_INVALID")
    out = os.path.join(HERE, "results_all.json")
    with open(out, "w", encoding="utf-8", errors="replace") as f:
        json.dump({"total": len(results), "results": list(results.values())}, f, ensure_ascii=False, indent=1)
    from collections import Counter
    c = Counter(x["verdict"] for x in results.values())
    fc = Counter(x.get("failure_class", "RESULT_INVALID") for x in results.values())
    print("\\n===== 汇总:", dict(c), "=====")
    print("根因:", dict(fc))
    print("结果:", out)
    failed = any(x.get("verdict") == "FAIL" for x in results.values())
    sys.exit(1 if failed else 0)
if __name__ == "__main__":
    main()
'''
    runner = runner.replace(
        "__UDS_RESULT_CONTRACT_PATH__",
        repr(str(Path(__file__).resolve().parent)),
    )
    with open(os.path.join(args.out_dir, "run_all.py"), "w", encoding="utf-8", errors="replace") as f:
        f.write(runner)
    from collections import Counter
    stat = Counter(m["status"] for m in manifest.values())
    print(f"[OK] 生成/更新 {len(cases)} 个脚本（manifest 共 {len(manifest)} 条用例）")
    print("     状态分布:", dict(stat))
    print("     目录:", args.out_dir)


if __name__ == "__main__":
    main()
