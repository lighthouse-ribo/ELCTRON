"""SWDL 计划和门禁离线测试；不连接 VickCAN/F1L1。"""

import hashlib
import json
import os
import sys
import unittest
from unittest.mock import patch


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from swdl_flow import (  # noqa: E402
    SwdlFlow,
    SwdlPlan,
    SwdlEraseSegment,
    SwdlSegment,
    build_activate_sbl_request,
    build_check_memory_request,
    build_flash_erase_request,
    build_request_download,
    build_swdl_plan,
    build_transfer_data_requests,
    security_key_status,
    validate_reset_response,
    validate_routine_response,
    validate_security_response,
    validate_session_response,
    validate_transfer_data_response,
    validate_transfer_exit_response,
)
from testsupport import WorkspaceTempDir  # noqa: E402


class TestSwdlFlow(unittest.TestCase):
    def setUp(self):
        self.workspace = WorkspaceTempDir("swdl")

    def tearDown(self):
        self.workspace.cleanup()

    def test_request_download_uses_bbs_alfid_44_and_four_byte_address_length(self):
        segment = SwdlSegment("image.bin", 0x00123456, b"abc")
        self.assertEqual(
            build_request_download(segment),
            [0x34, 0x00, 0x44, 0x00, 0x12, 0x34, 0x56, 0x00, 0x00, 0x00, 0x03],
        )

    def test_transfer_data_starts_at_one_and_wraps_bsc(self):
        data = bytes(range(10))
        requests = build_transfer_data_requests(data, max_number_of_block_length=5)
        self.assertEqual(requests[0], [0x36, 0x01, 0x00, 0x01, 0x02])
        self.assertEqual(requests[-1], [0x36, 0x04, 0x09])

    def test_plan_without_image_address_key_and_auth_is_blocked(self):
        plan = build_swdl_plan(target_partition="SBL")
        self.assertFalse(plan.segments)
        self.assertTrue(plan.blocked_reasons)
        self.assertFalse(plan.key_ready)
        self.assertFalse(plan.authentication_ready)

    def test_manifest_hash_can_make_authentication_ready_but_key_stays_independent(self):
        td = self.workspace.name
        image = os.path.join(td, "app.bin")
        check_memory = os.path.join(td, "check_memory.bin")
        manifest = os.path.join(td, "manifest.json")
        payload = b"download payload"
        with open(image, "wb") as handle:
            handle.write(payload)
        with open(check_memory, "wb") as handle:
            handle.write(bytes(512))
        with open(manifest, "w", encoding="utf-8") as handle:
            json.dump({
                "logical_block": "SBL",
                "segments": [{"file": "app.bin", "address": "0x1000"}],
                "erase_segments": [{"address": "0x1000", "length": "0x1000"}],
                "check_memory": {"file": "check_memory.bin"},
                "authentication": {
                    "status": "PASS",
                    "algorithm": "SHA256_RSA4096",
                    "payload_sha256": hashlib.sha256(payload).hexdigest(),
                },
            }, handle)
        plan = build_swdl_plan(manifest_path=manifest, target_partition="SBL")
        self.assertFalse(plan.authentication_ready)
        self.assertEqual(len(plan.check_memory_payload), 512)
        self.assertIn("RSA-4096", plan.authentication_reason)
        self.assertFalse(plan.key_ready)
        self.assertTrue(any("0x27" in item for item in plan.blocked_reasons))

    def test_swdl_request_builders_encode_documented_structures(self):
        erase = SwdlEraseSegment(0x1000, 0x2000)
        self.assertEqual(
            build_flash_erase_request(erase),
            [0x31, 0x01, 0xFF, 0x00, 0x00, 0x00, 0x10, 0x00,
             0x00, 0x00, 0x20, 0x00],
        )
        self.assertEqual(
            build_check_memory_request(bytes(512))[:4], [0x31, 0x01, 0x02, 0x12]
        )
        self.assertEqual(
            build_activate_sbl_request(0x12345678),
            [0x31, 0x01, 0x03, 0x01, 0x12, 0x34, 0x56, 0x78],
        )

    def test_structured_positive_response_validators_reject_wrong_fields(self):
        self.assertTrue(validate_session_response([0x50, 0x02], 0x02)[0])
        self.assertFalse(validate_session_response([0x50, 0x01], 0x02)[0])
        self.assertTrue(validate_security_response([0x67, 0x01] + [0] * 66, 0x01)[0])
        self.assertFalse(validate_security_response([0x67, 0x02] + [0] * 66, 0x01)[0])
        self.assertTrue(validate_transfer_data_response([0x76, 0xFE], 0xFE)[0])
        self.assertFalse(validate_transfer_data_response([0x76, 0xFD], 0xFE)[0])
        self.assertTrue(validate_transfer_exit_response([0x77])[0])
        self.assertTrue(validate_transfer_exit_response([0x77, 0x00])[0])
        self.assertFalse(validate_transfer_exit_response([0x77, 0x00], [0x01])[0])
        self.assertTrue(validate_routine_response([0x71, 0x01, 0x02, 0x12, 0x00, 0x00], 0x0212,
                                                  expected_result=0x00, require_result=True)[0])
        self.assertFalse(validate_routine_response([0x71, 0x01, 0x02, 0x12, 0x00, 0x01], 0x0212,
                                                   expected_result=0x00, require_result=True)[0])
        self.assertFalse(validate_routine_response([0x71, 0x02, 0x02, 0x12, 0x00, 0x00], 0x0212,
                                                   expected_result=0x00, require_result=True)[0])
        self.assertTrue(validate_reset_response([0x51, 0x01], 0x01)[0])
        self.assertFalse(validate_reset_response([0x51, 0x02], 0x01)[0])

    def test_ff_key_is_not_ready(self):
        path = os.path.join(self.workspace.name, "keys.json")
        with open(path, "w", encoding="utf-8") as handle:
            json.dump({
                "AES_cmac_key_0102": "FF" * 16,
                "AES_ctr_key_0102": "FF" * 16,
            }, handle)
        ready, reason = security_key_status(path)
        self.assertFalse(ready)
        self.assertIn("0xFF", reason)

    def test_blocked_plan_never_opens_hardware(self):
        class NeverOpen:
            def open(self):
                raise AssertionError("blocked plan must not open VickCAN")

            def close(self):
                raise AssertionError("blocked plan must not close an unopened device")

        plan = SwdlPlan(
            target_partition="SBL",
            nad=0x51,
            data_format_identifier=0,
            address_length_format_identifier=0x44,
            blocked_reasons=["missing key"],
        )
        td = self.workspace.name
        report = SwdlFlow(plan, td, approved=True, client_factory=NeverOpen).execute()
        self.assertEqual(report["overall"], "BLOCKED")
        self.assertTrue(os.path.isfile(os.path.join(td, "swdl_plan.json")))
        self.assertTrue(os.path.isfile(os.path.join(td, "swdl_report.json")))

    def test_wrong_runtime_partition_is_blocked_before_programming_request(self):
        class WrongPartitionClient:
            def __init__(self):
                self.requests = []

            def open(self):
                pass

            def current_partition(self, _nad, timeout=3.0):
                return "APP"

            def request(self, _nad, payload, timeout=3.0, retry=0):
                self.requests.append((payload, timeout, retry))
                return [0x50, 0x02]

            def close(self):
                pass

        client = WrongPartitionClient()
        plan = SwdlPlan(
            target_partition="SBL",
            nad=0x51,
            data_format_identifier=0,
            address_length_format_identifier=0x44,
            segments=[SwdlSegment("image.bin", 0x1000, b"abc")],
            key_ready=True,
            authentication_ready=True,
            erase_segments=[SwdlEraseSegment(0x1000, 0x1000)],
            check_memory_payload=bytes(512),
        )
        report = SwdlFlow(plan, self.workspace.name, approved=True, client_factory=lambda: client).execute()
        self.assertEqual(report["overall"], "BLOCKED")
        self.assertEqual(report["steps"][0]["step_id"], "partition-check")
        self.assertEqual(client.requests, [])

    def test_execute_uses_erase_validators_and_only_two_check_memory_attempts(self):
        class FakeSeedKey:
            def build_seed_request(self, level):
                return [0x27, level], bytes(16), bytes(16)

            def parse_seed_response(self, response, client_random, client_iv, level):
                return bytes(16), bytes(16), True

            def build_key_request(self, level, client_random, server_random):
                return [0x27, level, 0x00, 0x03]

        class FakeClient:
            def __init__(self):
                self.requests = []
                self.check_memory_count = 0
                self.opened = False

            def open(self):
                self.opened = True

            def close(self):
                self.opened = False

            def current_partition(self, _nad, timeout=3.0):
                return "SBL"

            def request(self, _nad, payload, timeout=3.0, retry=0):
                self.requests.append(list(payload))
                if payload[:2] == [0x10, 0x02]:
                    return [0x50, 0x02]
                if payload[0] == 0x27 and len(payload) == 2:
                    return [0x67, 0x01, 0x00, 0x02] + [0] * 64
                if payload[0] == 0x27:
                    return [0x67, 0x01]
                if payload[:4] == [0x31, 0x01, 0xFF, 0x00]:
                    return [0x71, 0x01, 0xFF, 0x00]
                if payload[0] == 0x34:
                    return [0x74, 0x20, 0x00, 0x10]
                if payload[0] == 0x36:
                    return [0x76, payload[1]]
                if payload[0] == 0x37:
                    return [0x77]
                if payload[:4] == [0x31, 0x01, 0x02, 0x12]:
                    self.check_memory_count += 1
                    result = 0x01 if self.check_memory_count == 1 else 0x00
                    return [0x71, 0x01, 0x02, 0x12, 0x00, result]
                if payload[:2] == [0x11, 0x01]:
                    return [0x51, 0x01]
                raise AssertionError(f"unexpected payload: {payload[:8]}")

        client = FakeClient()
        plan = SwdlPlan(
            target_partition="SBL",
            nad=0x51,
            data_format_identifier=0,
            address_length_format_identifier=0x44,
            logical_block="SBL",
            segments=[SwdlSegment("image.bin", 0x1000, bytes(range(15)))],
            erase_segments=[SwdlEraseSegment(0x1000, 0x1000)],
            check_memory_payload=bytes(512),
            key_ready=True,
            key_reason="test key",
            authentication_ready=True,
            authentication_reason="test signature",
        )
        with patch("swdl_flow._make_seed_key_generator", return_value=FakeSeedKey()):
            report = SwdlFlow(
                plan,
                self.workspace.name,
                approved=True,
                client_factory=lambda: client,
            ).execute()
        self.assertEqual(report["overall"], "PASS")
        self.assertEqual(client.check_memory_count, 2)
        self.assertEqual(
            [request[0] for request in client.requests],
            [0x10, 0x27, 0x27, 0x31, 0x34, 0x36, 0x36, 0x37, 0x31, 0x31, 0x11],
        )
        check_steps = [step for step in report["steps"] if step["step_id"].startswith("check-memory")]
        self.assertEqual([step["status"] for step in check_steps], ["RETRY", "PASS"])


if __name__ == "__main__":
    unittest.main()
