#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成后脚本审查的独立真值层（差分审查：与生成器非同一套推导）
=====================================================================
背景
----
旧版 script_review 直接 `from gen_case_scripts import (request_payload,
expected_info, ...)` 复用"需求 → 期望"推导函数：生成器与审查器共享
同一逻辑，推导函数的系统性缺陷（如 NRC 集合漏提取、正负例误判）会
被生成器写入脚本、又被审查器用同一函数"验证通过"，属自我审查盲区。

本模块为审查器提供**第二套独立实现**，完全不 import gen_case_scripts：
  1. 防漂移层：从 procedure 文本提取"请求 payload 证据候选集"，脚本
     PAYLOAD 必须命中其一（证据包含，而非与生成器相同的精确重算）；
  2. 协议真值层：按 ISO 14229 不变量校验脚本期望（合法请求 SID、
     正响应 SID = 请求 SID + 0x40、负响应帧 7F<SID><NRC> 的 SID 一致、
     NRC 值域 0x10~0x7F）；
  3. 项目数据层：与 uds_parsed.json 交叉校验（DID/RID 存在性、
     0x2E 写入正例与只读 DID 冲突），parsed 缺失时不阻断。

设计约束：纯标准库（openpyxl 不引入），离线、轻量、可单测。
"""
import re


# --------------------------------------------------------------------------
# 协议真值（ISO 14229-1）
# --------------------------------------------------------------------------
def _is_request_sid(sid):
    """UDS 请求 SID 值域：0x10~0x3E（标准服务）或 0x80~0xBF（安全相关）。
    0x00~0x0F / 0x40~0x7F（响应 SID 与负响应 0x7F）/ 0xC0~0xFF 不是请求。"""
    return (0x10 <= sid <= 0x3E) or (0x80 <= sid <= 0xBF)


def _valid_nrc(nrc):
    """ISO 14229 NRC 定义域 0x10~0x7F。"""
    return 0x10 <= nrc <= 0x7F


# ISO 14229-1 已登记的标准服务：SID → (服务名, 正例请求最小长度)
# 最小长度是"正例请求必须满足的结构下限"，用于在生成后、执行前拦截
# 结构性畸形请求。负例/条件受限用例故意发送畸形请求，不做长度约束
# （由调用方在 expect == "pos" 时才启用）。
UDS_SERVICES = {
    0x10: ("DiagnosticSessionControl", 2),
    0x11: ("ECUReset", 2),
    0x14: ("ClearDiagnosticInformation", 4),
    0x17: ("ReadEcuIdentification", 1),
    0x19: ("ReadDTCInformation", 2),
    0x22: ("ReadDataByIdentifier", 3),
    0x23: ("ReadMemoryByAddress", 4),
    0x24: ("ReadScalingDataByIdentifier", 3),
    0x27: ("SecurityAccess", 2),
    0x28: ("CommunicationControl", 3),
    0x29: ("ReadAuthenticationInformation", 2),
    0x2A: ("ReadDataByPeriodicIdentifier", 3),
    0x2C: ("DynamicallyDefineDataIdentifier", 4),
    0x2E: ("WriteDataByIdentifier", 4),
    0x2F: ("InputOutputControlByIdentifier", 4),
    0x31: ("RoutineControl", 4),
    0x34: ("RequestDownload", 5),
    0x35: ("RequestUpload", 5),
    0x36: ("TransferData", 3),
    0x37: ("RequestTransferExit", 1),
    0x38: ("RequestFileTransfer", 2),
    0x3D: ("WriteMemoryByAddress", 2),
    0x3E: ("TesterPresent", 2),
    0x83: ("AccessTimingParameter", 3),
    0x84: ("SecuredDataTransmission", 2),
    0x85: ("ControlDTCSetting", 2),
    0x86: ("ResponseOnEvent", 2),
    0x87: ("LinkControl", 2),
}
# 供应商自定义服务段（ISO 14229-1 未定义）：标准协议真值无法校验其结构，
# 审查器对该段不误报、不阻断。
_SUPPLIER_SID_MIN = 0x80
_SUPPLIER_SID_MAX = 0xBF
# RoutineControl(0x31) 子功能白名单（ISO 14229-1）
_ROUTINE_CONTROL_SUBS = (0x01, 0x02, 0x03, 0x04, 0x05, 0x06)


def service_min_len(sid):
    """已知标准服务的正例请求最小长度；未知/供应商自定义返回 None。"""
    entry = UDS_SERVICES.get(sid)
    return entry[1] if entry else None


def is_supplier_sid(sid):
    return _SUPPLIER_SID_MIN <= sid <= _SUPPLIER_SID_MAX


# --------------------------------------------------------------------------
# 文本 → 字节证据提取（独立于 gen_case_scripts 的实现）
# --------------------------------------------------------------------------
_HEX_SEQ = re.compile(
    r"(?<![0-9A-Fa-f])(?:[0-9A-Fa-f]{2}(?:\s+|(?=[^0-9A-Fa-f]|$)))+"
)


def hex_tokens(text):
    """提取文本中所有连续 hex 字节序列（2 位一组，空格/标点分隔）。

    例如 'RID 0206；31 03 02 06' → [[0x02,0x06],[0x31,0x03,0x02,0x06]]。
    与 gen_case_scripts.hex_tokens 语义等价但独立实现，作为差分对照。
    """
    out = []
    for m in _HEX_SEQ.finditer(text or ""):
        chunk = re.sub(r"[^0-9A-Fa-f]", "", m.group(0))
        if chunk and len(chunk) % 2 == 0:
            out.append([int(chunk[i:i + 2], 16) for i in range(0, len(chunk), 2)])
    return out


def _to_payload(toks, bus, nad):
    """单条 hex 序列 → 可能的 UDS payload；无法识别时返回 None。"""
    if not toks:
        return None
    # LIN 完整单帧：NAD + PCI(SF 长度) + payload（FF 填充由 PCI 截断）
    if bus == "lin" and toks[0] == nad and len(toks) >= 2 and (toks[1] >> 4) == 0x0:
        return toks[2:2 + (toks[1] & 0x0F)]
    # 直接 UDS payload（首字节即合法请求 SID，至少含 SID+1 参数）
    if len(toks) >= 2 and _is_request_sid(toks[0]):
        return toks
    # ISO-TP 单帧：PCI(SF 长度) + SID + 参数（CAN '02 10 03' → [10 03]）
    if (toks[0] >> 4) == 0x0 and len(toks) >= 2 and _is_request_sid(toks[1]):
        return toks[1:]
    return None


_0X_ANNOTATION = re.compile(r"0[xX][0-9A-Fa-f]+")


def _extract_payloads(line, bus, nad):
    out = []
    for toks in hex_tokens(line):
        p = _to_payload(toks, bus, nad)
        if p is not None:
            out.append(p)
    return out


def payload_candidates(procedure, bus, nad):
    """从 procedure 提取请求 payload 证据候选集（去重保序）。

    不再整行跳过含 '0x' 自然语言标记的行（2026-09-03 反馈 L6）：先按原行
    提取一次，再对去掉 '0x..' 标注的清洗行提取一次，救回两类被截留的
    证据——'扩展会话(0x03)下请求: 22 F1 90'（标注与帧同行）、'NAD 0x51
    发送 22 F1 90'（标注 NAD 与帧同行导致首字节被当成 NAD）。纯标注行
    （如 '读取 DID 0xF190'、'目标会话 0x03'）仍因首字节不是合法请求 SID
    或不足两字节而被过滤，不会误当请求报文。
    """
    cands = []
    for line in (procedure or "").splitlines():
        cands.extend(_extract_payloads(line, bus, nad))
        if _0X_ANNOTATION.search(line):
            cleaned = _0X_ANNOTATION.sub(" ", line)
            cands.extend(_extract_payloads(cleaned, bus, nad))
    seen, out = set(), []
    for c in cands:
        key = tuple(c)
        if key not in seen:
            seen.add(key)
            out.append(c)
    return out


def session_candidates(precondition, procedure, project_config=None):
    """会话证据：precondition + procedure 关键词 → 候选会话集。
    对只提供原始 0x10 报文的用例，同时纳入报文中的目标会话；无任何
    会话关键词时保守取项目 default（与生成器兜底一致）。"""
    text = " ".join(x for x in (precondition or "", procedure or "") if x)
    cands = set()
    configured = (project_config or {}).get("sessions", {}) if isinstance(project_config, dict) else {}
    supported = [int(value) for value in configured.get("supported", [])]
    names = {int(key): str(value) for key, value in configured.get("names", {}).items()}
    default_id = int(configured.get("default", 0x01)) if configured else 0x01
    if not supported:
        supported = [0x01, 0x02, 0x03]
    if not names:
        names = {0x01: "默认会话", 0x02: "编程会话", 0x03: "扩展会话"}

    # Match configured display names and stable legacy aliases. The value
    # written to generated SESSION metadata follows the same convention.
    aliases = {}
    for session_id in supported:
        values = {str(names.get(session_id, "")), f"0x{session_id:02X}", f"0x{session_id:02x}"}
        values.update({f"{session_id:02X}", f"{session_id:02x}"})
        values.update({
            0x01: {"默认会话", "default"},
            0x02: {"编程会话", "programming"},
            0x03: {"扩展会话", "extended"},
        }.get(session_id, set()))
        aliases[session_id] = {value.lower() for value in values if value}
    text_lower = text.lower()
    runtime_names = {0x01: "default", 0x02: "programming", 0x03: "extended"}
    for session_id, session_aliases in aliases.items():
        if any(alias in text_lower for alias in session_aliases
               if not re.fullmatch(r"(?:0x)?[0-9a-f]{2}", alias)):
            cands.add(runtime_names.get(
                session_id, names.get(session_id, f"0x{session_id:02X}")
            ))
    # 需求表常把会话只写成原始 LIN/CAN 帧（如“请求：10 02”），
    # 这时关键词层只能识别 precondition 的源会话。把 0x10 的目标会话
    # 作为独立证据加入候选集，避免审查器把合法的 01→02/03 误判为漂移。
    target_names = {}
    for session_id in supported:
        target_names[session_id] = {
            0x01: "default", 0x02: "programming", 0x03: "extended",
        }.get(session_id, names.get(session_id, f"0x{session_id:02X}"))
    configured_nad = int((project_config or {}).get("transport", {}).get("physical_nad", 0x51)) \
        if isinstance(project_config, dict) else 0x51
    for bus in ("lin", "can"):
        for payload in payload_candidates(procedure, bus, configured_nad):
            if len(payload) >= 2 and payload[0] == 0x10:
                target = payload[1] & 0x7F
                if target in target_names:
                    cands.add(target_names[target])
    if not cands:
        cands.add(target_names.get(default_id, names.get(default_id, "default")))
    return cands


def pre_action_candidates(procedure):
    """0x31 前置例程证据：'先启动 RID 0206' → [[31 01 02 06]]。"""
    out = []
    for m in re.finditer(r"(?:先启动|启动)\s*(?:RID\s*)?([0-9A-Fa-f]{4})", procedure or "", re.I):
        rid = m.group(1)
        out.append([0x31, 0x01, int(rid[:2], 16), int(rid[2:], 16)])
    return out


def expect_type_evidence(expected, test_point):
    """期望类型轻量证据：需求文本关键词 → 脚本 EXPECT 应属于的集合。
    无关键词时返回空集（不阻断，交由状态机/歧义检测判定）。"""
    text = " ".join(x for x in (expected or "", test_point or "") if x)
    # "抑制正响应"/"不应答" 是无响应期望，优先级最高（其文本常含"正响应"子串，
    # 必须先判，避免同时命中 pos 造成误报）。
    if any(t in text for t in ("不应答", "无应答", "不发送正响应", "抑制正响应", "suppressPosRsp")):
        return {"none"}
    ev = set()
    if any(t in text for t in ("负响应", "负向")):
        ev.add("neg")
    if any(t in text for t in ("正响应", "正常响应", "可正常响应")):
        ev.add("pos")
    return ev


def did_rid_from_payload(payload):
    """从 payload 提取 DID（0x22/0x2E）或 RID（0x31）→ (did, rid)，均以 4-hex 大写。"""
    if not payload:
        return None, None
    sid = payload[0]
    if sid in (0x22, 0x2E) and len(payload) >= 3:
        return "%02X%02X" % (payload[1], payload[2]), None
    if sid == 0x31 and len(payload) >= 4:
        return None, "%02X%02X" % (payload[2], payload[3])
    return None, None


# --------------------------------------------------------------------------
# 协议不变量校验（独立于需求文本的确定性规则）
# --------------------------------------------------------------------------
def protocol_issues(payload, expect, expect_nrc, expect_prefix):
    """返回 [(level, detail)]；level ∈ {ERROR, REVIEW_REQUIRED}。

    除既有的 SID 值域/NRC 值域/响应前缀一致性外，补充协议真值层：
      - 已知标准服务 → 正例请求结构下限校验（ERROR）；
      - RoutineControl(0x31) → 正例子功能白名单校验（ERROR）；
      - 供应商自定义服务段 0x80~0xBF → 无法用标准真值校验，不误报；
      - 请求值域内但未登记的标准 SID → 正例 REVIEW_REQUIRED。
    """
    issues = []
    sid = payload[0] if payload else None
    if sid is None or not _is_request_sid(sid):
        issues.append(("ERROR",
                       "脚本 PAYLOAD 首字节 0x%02X 不是合法 UDS 请求 SID" % (sid if sid is not None else 0x00)))
    for nrc in (expect_nrc or []):
        if not _valid_nrc(nrc):
            issues.append(("ERROR", "NRC 0x%02X 不在 ISO 14229 合法值域 0x10~0x7F" % nrc))
    if sid is not None and _is_request_sid(sid):
        if is_supplier_sid(sid):
            # 供应商自定义服务：标准协议真值无法校验结构，保持静默（不误报）。
            pass
        elif sid in UDS_SERVICES:
            name, min_len = UDS_SERVICES[sid]
            if expect == "pos" and len(payload) < min_len:
                issues.append((
                    "ERROR",
                    "%s(0x%02X) 正例请求过短：%d 字节 < 最小 %d 字节"
                    % (name, sid, len(payload), min_len),
                ))
            if sid == 0x31 and expect == "pos" and len(payload) >= 2:
                sub = payload[1]
                if sub not in _ROUTINE_CONTROL_SUBS:
                    issues.append((
                        "ERROR",
                        "RoutineControl(0x31) 子功能 0x%02X 非法（ISO 14229 仅 01/02/03/04/05/06）" % sub,
                    ))
        elif expect == "pos":
            issues.append((
                "REVIEW_REQUIRED",
                "正例使用未登记标准服务 SID 0x%02X，需人工确认协议版本/供应商实现" % sid,
            ))
    prefix = expect_prefix or []
    if prefix and sid is not None and _is_request_sid(sid):
        if prefix[0] == 0x7F:
            if len(prefix) < 2 or prefix[1] != sid:
                issues.append((
                    "ERROR",
                    "负响应前缀 %s 的请求 SID 与 PAYLOAD SID 0x%02X 不一致"
                    % (" ".join("%02X" % b for b in prefix), sid),
                ))
        elif expect == "pos" and prefix[0] != sid + 0x40:
            issues.append((
                "ERROR",
                "正响应前缀首字节 0x%02X ≠ 请求 SID 0x%02X + 0x40（应为 0x%02X）"
                % (prefix[0], sid, sid + 0x40),
            ))
    return issues


# --------------------------------------------------------------------------
# parsed.json 交叉校验（独立于需求文本的第三真值源；parsed 缺失时不阻断）
# --------------------------------------------------------------------------
def _norm_key(text):
    return str(text or "").upper().lstrip("0X")


def _defaulted_fields(parsed):
    """调查表字段溯源：DID → 使用了默认值的属性名集合。

    数据来自 parsed.defaults_used（如 [{"did": "F190", "defaults":
    [("rw_state", "R"), ("read_sessions", "...")]}]）。用途：把"调查表
    缺列导致填了默认值"与"调查表真实值"区分开——对前者不判硬冲突
    （ERROR），降级为需人工确认（REVIEW_REQUIRED），避免默认只读
    （rw_state=R）把合法的 0x2E 写入正例误杀成真错误。
    """
    out = {}
    for item in (parsed or {}).get("defaults_used") or []:
        if not isinstance(item, dict):
            continue
        did = item.get("did") or item.get("io_did")
        if not did:
            continue
        fields = out.setdefault(_norm_key(did), set())
        for entry in item.get("defaults") or []:
            if isinstance(entry, (list, tuple)) and entry:
                fields.add(str(entry[0]))
    return out


def parsed_issues(payload, session, parsed, expect):
    """返回 [(level, detail)]；检查 DID/RID 存在性与 0x2E 只读冲突。"""
    issues = []
    dids = list((parsed or {}).get("dids") or [])
    if not dids:
        return issues  # 无调查表数据：不做存在性校验，避免误杀
    did, rid = did_rid_from_payload(payload)
    if did:
        known = {_norm_key(d.get("did_number")) for d in dids}
        # Some requirements intentionally use a probe DID absent from the
        # survey export (for example the session probe F190), and FFFF is an
        # explicit invalid-DID negative sentinel.  These are provenance
        # declarations in the merged parsed JSON, not guessed ECU metadata.
        known.update(_norm_key(x) for x in (parsed or {}).get("requirement_referenced_dids", []))
        known.update(_norm_key(x) for x in (parsed or {}).get("negative_test_dids", []))
        if _norm_key(did) not in known:
            issues.append(("REVIEW_REQUIRED", "需求引用调查表外 DID 0x%s，需人工确认" % did))
            return issues
        if payload[0] == 0x2E and expect == "pos":
            defaulted = _defaulted_fields(parsed)
            for d in dids:
                if _norm_key(d.get("did_number")) != did:
                    continue
                if str(d.get("rw_state", "")).upper() == "R":
                    if "rw_state" in defaulted.get(_norm_key(did), ()):
                        issues.append((
                            "REVIEW_REQUIRED",
                            "调查表 DID 0x%s 读写列缺失（默认只读 R），0x2E 写入正例的可写性需人工确认" % did,
                        ))
                    else:
                        issues.append(("ERROR", "调查表 DID 0x%s 只读（rw_state=R），与 0x2E 写入正例冲突" % did))
                # 数据长度真值：0x2E 正例应写 size_bytes 个数据字节。
                # size_bytes 为解析器默认 1 时无法区分"真实 1 字节"与"未填默认值"，
                # 只在明确大于 1 时比对，避免默认值造成误杀；不一致按需人工确认。
                size = d.get("size_bytes")
                if isinstance(size, int) and size > 1 and len(payload) - 3 != size:
                    issues.append((
                        "REVIEW_REQUIRED",
                        "0x2E 写 DID 0x%s 数据 %d 字节 ≠ 调查表 size_bytes=%d，需人工确认"
                        % (did, max(0, len(payload) - 3), size),
                    ))
                break
    elif rid:
        routines = list((parsed or {}).get("routines") or [])
        if routines:
            known_rids = {_norm_key(r.get("routine_id")) for r in routines}
            if _norm_key(rid) not in known_rids:
                issues.append(("REVIEW_REQUIRED", "需求引用调查表外 RID 0x%s，需人工确认" % rid))
    return issues
