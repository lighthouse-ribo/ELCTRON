#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""逐用例 CAN/LIN UDS 时序采集、判定与证据落盘。

时序用例不能依赖一份“普通 P2 汇总报告”。本模块为每个 TimeParm 用例
建立独立的 measurement spec，执行独立请求/等待/采集，再将原始轨迹和
判定结果分别写入 ``<case_id>.trace.json`` 与 ``<case_id>.json``。

状态契约只有 PASS / FAIL / BLOCKED / NA。只有有有效 ECU 证据且断言不满足
时才产生 FAIL；硬件/运行时不可用返回 BLOCKED，避免把工具错误计入 ECU FAIL。
"""

from __future__ import annotations

import json
import hashlib
import importlib.util
import os
import re
import time
from datetime import datetime, timezone
from typing import Any

from result_contract import infer_failure_class


ALLOWED_VERDICTS = frozenset({"PASS", "FAIL", "BLOCKED", "NA"})
TIMING_RUNNER_VERSION = "2.1.0-trace-correlated"


def _now() -> float:
    return time.perf_counter()


def _hex(data: Any) -> str:
    if not data:
        return "无应答"
    return " ".join(f"{int(b):02X}" for b in data)


def _as_float_list(value: Any) -> list[float]:
    if not isinstance(value, (list, tuple)):
        return []
    out = []
    for item in value:
        try:
            out.append(float(item))
        except (TypeError, ValueError):
            continue
    return out


def _jsonable(value: Any) -> Any:
    if isinstance(value, tuple):
        return [_jsonable(x) for x in value]
    if isinstance(value, list):
        return [_jsonable(x) for x in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _parse_can_frame(frame: list[int]) -> tuple[str, int, list[int]]:
    """解析 CAN ISO-TP 单帧/首帧/连续帧/流控帧的有效负载。"""
    data = [int(value) & 0xFF for value in (frame or [])]
    if not data:
        return "unknown", 0, []
    pci = data[0]
    if pci == 0x00 and len(data) >= 2:
        length = data[1]
        return "sf", 0, data[2:2 + length]
    if (pci & 0xF0) == 0x00:
        length = pci & 0x0F
        return "sf", 0, data[1:1 + length]
    if (pci & 0xF0) == 0x10 and len(data) >= 2:
        length = ((pci & 0x0F) << 8) | data[1]
        return "ff", 0, data[2:2 + min(length, 6)]
    if (pci & 0xF0) == 0x20:
        return "cf", 0, data[1:]
    if (pci & 0xF0) == 0x30:
        return "fc", 0, data[1:]
    return "unknown", 0, []


def _can_frame_contains_payload(frame: list[int], payload: list[int]) -> bool:
    kind, _nad, frame_payload = _parse_can_frame(frame)
    if kind not in {"sf", "ff"}:
        return False
    return list(frame_payload) == list(payload[:len(frame_payload)])


def _limit_from_text(text: str, tokens: tuple[str, ...], default: float | None = None) -> float | None:
    if not text:
        return default
    pattern = r"(?:" + "|".join(re.escape(token) for token in tokens) + r")[^0-9]{0,30}(\d+(?:\.\d+)?)\s*ms"
    match = re.search(pattern, text, re.I)
    if not match:
        return default
    return float(match.group(1))


def _int_from_text(text: str, token: str, default: int | None = None) -> int | None:
    match = re.search(r"%s\s*=\s*(?:0x)?([0-9A-Fa-f]+)" % re.escape(token), text or "", re.I)
    if not match:
        return default
    try:
        raw = match.group(1)
        return int(raw, 16) if any(ch in raw.upper() for ch in "ABCDEF") else int(raw, 10)
    except ValueError:
        return default


_TIMEPARM_SPECS = {
    "0001": {"metric": "p2", "max_ms": 50.0, "samples": 5, "label": "P2"},
    "0002": {"metric": "p2", "max_ms": 50.0, "samples": 1, "label": "P2"},
    "0003": {"metric": "p2_star", "max_ms": 5000.0, "samples": 1, "label": "P2*"},
    "0004": {"metric": "s3", "max_ms": 5000.0, "samples": 1, "label": "S3"},
    "0005": {"metric": "n_as", "max_ms": 1000.0, "samples": 1, "label": "N_As"},
    "0006": {"metric": "n_cr", "max_ms": 1000.0, "samples": 1, "label": "N_Cr"},
    "0007": {"metric": "bs_stmin", "samples": 1, "label": "BS/STmin"},
    "0008": {"metric": "p4", "max_ms": 50.0, "samples": 1, "label": "P4"},
    "0009": {"metric": "frame_jitter", "jitter_limit_ms": 5.0, "samples": 10, "label": "帧抖动"},
    "0010": {"metric": "s3_boundary", "max_ms": 5000.0, "samples": 3, "label": "S3 边界"},
    "0011": {"metric": "frame_gap", "samples": 10, "label": "LIN 帧隙"},
    "0012": {"metric": "multi_frame", "max_ms": 1000.0, "samples": 1, "label": "多帧 N_As/N_Cr"},
    "0013": {"metric": "session_transitions", "max_ms": 50.0, "samples": 3, "label": "会话切换 P2"},
    "0014": {"metric": "reset_recovery", "samples": 1, "label": "复位恢复"},
    "0015": {"metric": "p2_distribution", "max_ms": 50.0, "samples": 20, "label": "P2 分布"},
}


def build_timing_spec(
    case_id: str,
    payload: list[int] | None,
    session: str,
    request_nad: int,
    expected_prefix: list[int] | None = None,
    procedure: str = "",
    expected: str = "",
    tx_frame_id: int | None = None,
    rx_frame_id: int | None = None,
    target_partition: str | None = None,
    p2_limit: float | None = None,
    allowed_response_nrcs: list[int] | tuple[int, ...] | None = None,
    bus: str = "lin",
    default_session_id: int | None = None,
    session_id_by_name: dict[str, int] | None = None,
) -> dict[str, Any]:
    """从用例构造稳定、可审计的逐用例时序 spec。

    TimeParm 编号优先使用显式项目映射；其它普通编号的时序用例根据
    需求文本选择指标，并从文本读取已有的 ``xx ms`` 限值，不擅自伪造
    缺失阈值。

    tx_frame_id/rx_frame_id：CAN 时序用例的请求/响应 CAN ID（LIN 时不传，
    轨迹语义默认 0x3C/0x3D）。采集、判定与 run_all 证据校验都按 spec 中
    的帧 ID 识别请求/响应方向，使同一套逻辑对 LIN/CAN 通用。
    """
    cid = str(case_id)
    suffix = cid.rsplit("_", 1)[-1] if cid else ""
    # 固定编号只属于 UDS_TimeParm_* 专项。普通 UDS_<SID>_<编号> 可能
    # 恰好使用相同后缀，但必须按其自身需求文本判定，不能误继承另一条
    # TimeParm 的指标（例如普通 TC0008 被误当成 P4、TC0010 被误当成
    # S3 边界）。
    is_timeparm = cid.startswith("UDS_TimeParm") or "TimeParm" in cid
    base = dict(_TIMEPARM_SPECS.get(suffix, {})) if is_timeparm else {}
    text = " ".join((cid, procedure or "", expected or ""))
    # The current BBS matrix numbers the dedicated timing rows as P2, P2*,
    # S3, ... while older generic templates used a different suffix map.
    # Prefer an explicit S3 requirement in the selected case, without
    # changing the legacy suffix behavior when no requirement text is given.
    if is_timeparm and suffix == "0003" and "S3Server" in text:
        base = {"metric": "s3", "max_ms": _limit_from_text(text, ("S3Server",), 5000.0), "samples": 1, "label": "S3"}
    if not base:
        # 普通 P2 用例的调查表说明可能同时列出 P2Server/P2*Server
        # 两个阈值；只有步骤真正要求 P2*，或明确出现 pending/0x78，
        # 才能选择 P2*，不能把阈值说明当成采集指标。
        p2_star_intent = ("P2*" in (procedure or "")
                          or "pending" in text.lower()
                          or "0x78" in text.lower())
        if p2_star_intent:
            base = {"metric": "p2_star", "max_ms": _limit_from_text(text, ("P2*Server",), 5000.0), "samples": 1, "label": "P2*"}
        elif "S3" in text:
            base = {"metric": "s3", "max_ms": _limit_from_text(text, ("S3Server",), 5000.0), "samples": 1, "label": "S3"}
        elif "N_As" in text:
            base = {"metric": "n_as", "max_ms": _limit_from_text(text, ("N_As",), 1000.0), "samples": 1, "label": "N_As"}
        elif "N_Cr" in text:
            base = {"metric": "n_cr", "max_ms": _limit_from_text(text, ("N_Cr",), 1000.0), "samples": 1, "label": "N_Cr"}
        elif "BS" in text or "STmin" in text:
            base = {"metric": "bs_stmin", "samples": 1, "label": "BS/STmin"}
        elif "复位恢复" in text or "reset recovery" in text.lower():
            base = {"metric": "reset_recovery", "samples": 1, "label": "复位恢复"}
        elif "抖动" in text or "jitter" in text.lower():
            base = {"metric": "frame_jitter", "jitter_limit_ms": 5.0, "samples": 10, "label": "帧抖动"}
        elif "P4Server" in text or re.search(r"\bP4\b", text, re.I):
            base = {"metric": "p4", "max_ms": _limit_from_text(text, ("P4Server",), 50.0), "samples": 1, "label": "P4"}
        else:
            base = {"metric": "p2", "max_ms": _limit_from_text(text, ("P2Server",), 50.0), "samples": 1, "label": "P2"}

    # The P2 limit belongs to the selected diagnostic partition.  Do not let
    # a generic 50 ms fallback override the confirmed 25 ms PBL/SBL limit.
    if p2_limit is not None and base["metric"] in {"p2", "p2_distribution", "session_transitions"}:
        base["max_ms"] = float(p2_limit)

    default_id = int(default_session_id if default_session_id is not None else 0x01)
    configured_ids = []
    for value in (session_id_by_name or {}).values():
        try:
            session_id = int(value)
        except (TypeError, ValueError):
            continue
        if session_id not in configured_ids:
            configured_ids.append(session_id)
    if default_id not in configured_ids:
        configured_ids.append(default_id)
    transition_ids = list(reversed(configured_ids))
    target_id = _resolve_session_id(session or "default", session_id_by_name, default_id)
    if target_id is None:
        target_id = default_id

    spec = {
        "case_id": cid,
        "metric": base["metric"],
        "label": base.get("label", base["metric"]),
        "payload": list(payload or []),
        "session": session or "default",
        "request_nad": int(request_nad),
        "expected_prefix": list(expected_prefix or []),
        # 专项 TimeParm 用例是正向测量；响应为 NRC 时仍然可以保留
        # P2 数值，但必须把响应内容单独判为 FAIL，不能把它混成 P2 超时。
        "response_policy": "positive" if is_timeparm else ("prefix" if expected_prefix else "unspecified"),
        "samples": int(base.get("samples", 1)),
        "max_ms": base.get("max_ms"),
        "jitter_limit_ms": base.get("jitter_limit_ms"),
        "procedure": procedure or "",
        "expected": expected or "",
        "target_partition": target_partition or "",
        "bus": str(bus or "lin").lower(),
        "default_session_id": default_id,
        "session_id_by_name": {
            str(key): int(value) for key, value in (session_id_by_name or {}).items()
        },
        "session_transition_ids": transition_ids,
        "p2_limit_ms": base.get("max_ms") if base["metric"] in {"p2", "p2_distribution", "session_transitions"} else None,
        "p2_limit_source": "PartitionModel" if p2_limit is not None and base["metric"] in {"p2", "p2_distribution", "session_transitions"} else "case/legacy default",
        "allowed_response_nrcs": sorted({int(value) for value in (allowed_response_nrcs or ())}),
    }
    if tx_frame_id is not None:
        spec["tx_frame_id"] = int(tx_frame_id)
    if rx_frame_id is not None:
        spec["rx_frame_id"] = int(rx_frame_id)
    if spec["metric"] == "bs_stmin":
        # 调查表常写 BS=0、STmin=0ms；若文本明确给出其它值，以文本为准。
        expected_text = " ".join((procedure or "", expected or ""))
        spec.update({
            "expected_bs": _int_from_text(expected_text, "BS", 0),
            "expected_stmin": _int_from_text(expected_text, "STmin", 0),
        })
    if spec["metric"] == "multi_frame" and len(spec["payload"]) <= 6:
        # “如写 F10A 34 字节”只给出了示例长度，没有给出可发送的
        # UDS SID/DID/数据内容。禁止补 0、补 FF 或拿普通 P2 请求冒充
        # 多帧请求；runner 会将该条明确记为 FAIL，避免静默不测试。
        spec["payload_error"] = "需求未提供完整多帧 UDS 请求 payload，禁止自动补造测试数据"
    if spec["metric"] == "s3_boundary":
        spec.update({
            "intervals_ms": [4500.0, 5000.0, 5500.0],
            "expected_sessions": [[target_id], [default_id, target_id], [default_id]],
        })
    return spec


def _result_base(spec: dict[str, Any], verdict: str, actual: str, note: str, metrics: dict[str, Any] | None, evidence_path: str | None) -> dict[str, Any]:
    if verdict not in ALLOWED_VERDICTS:
        verdict = "FAIL"
    return {
        "case_id": spec.get("case_id", "?"),
        "service": "TimeParm",
        "desc": "逐用例时序测量",
        "session": spec.get("session", "default"),
        "payload": list(spec.get("payload", [])),
        "expect": "timing",
        "actual": actual,
        "verdict": verdict,
        "failure_class": infer_failure_class(
            verdict, spec.get("failure_class", ""), f"{actual} {note}"
        ),
        "note": note,
        "timing_metric": spec.get("metric"),
        "timing_spec": spec,
        "metrics": metrics or {},
        "evidence": evidence_path or "",
    }


def _write_evidence(result_path: str, spec: dict[str, Any], measurement: dict[str, Any]) -> str:
    evidence_path = os.path.splitext(result_path)[0] + ".trace.json"
    payload = {
        "case_id": spec.get("case_id"),
        "metric": spec.get("metric"),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "run_id": measurement.get("run_id", ""),
        "runner": measurement.get("runner", _runner_metadata()),
        "measurement": _jsonable(measurement),
    }
    os.makedirs(os.path.dirname(evidence_path) or ".", exist_ok=True)
    with open(evidence_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return evidence_path


def _write_result(result_path: str, result: dict[str, Any]) -> dict[str, Any]:
    os.makedirs(os.path.dirname(result_path) or ".", exist_ok=True)
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(_jsonable(result), f, ensure_ascii=False, indent=2)
    print(f"[{result['verdict']}] {result['case_id']}: {result['actual']}（{result['note']}）")
    return result


def _failed(spec: dict[str, Any], note: str, measurement: dict[str, Any] | None = None) -> dict[str, Any]:
    measurement = measurement or {}
    error = str(measurement.get("error") or note)
    metrics = {k: v for k, v in measurement.items() if k not in {"trace", "traces", "error", "responses"}}
    return {"verdict": "FAIL", "actual": "时序证据不足或采集失败", "note": error, "metrics": metrics}


def _evaluate_timing_case_base(spec: dict[str, Any], measurement: dict[str, Any]) -> dict[str, Any]:
    """只根据单条用例的独立 measurement 判定，不读取其它用例报告。"""
    if measurement.get("blocked"):
        return {
            "verdict": "BLOCKED",
            "failure_class": measurement.get("failure_class", "BLOCKED"),
            "actual": "未执行（前置条件受限）",
            "note": str(measurement.get("error") or "前置条件受限"),
            "metrics": {},
        }
    if measurement.get("error"):
        return _failed(spec, str(measurement["error"]), measurement)
    integrity = measurement.get("trace_integrity")
    if isinstance(integrity, dict) and integrity.get("status") != "PASS":
        return _failed(
            spec,
            "原始 trace 与报告时序值一致性校验失败",
            measurement,
        )

    kind = spec.get("metric")
    limit = spec.get("max_ms")
    metrics = {k: v for k, v in measurement.items() if k not in {"trace", "traces", "responses", "error", "blocked"}}

    def timed_pass(key: str, label: str | None = None, require_min: int | None = None) -> dict[str, Any]:
        values = _as_float_list(measurement.get(key))
        if require_min is None:
            require_min = int(spec.get("samples", 1))
        if len(values) < require_min:
            return _failed(spec, f"{spec.get('label', kind)} 有效样本不足：{len(values)}/{require_min}", measurement)
        if limit is not None and max(values) > float(limit):
            return {"verdict": "FAIL", "actual": f"{label or spec.get('label', kind)} 最大 {max(values):.3f}ms 超限", "note": f"限值 {float(limit):.3f}ms", "metrics": metrics}
        return {"verdict": "PASS", "actual": f"{label or spec.get('label', kind)} 最大 {max(values):.3f}ms", "note": f"有效样本 {len(values)}，满足限值" if limit is not None else f"有效样本 {len(values)}", "metrics": metrics}

    if kind in {"p2", "p4", "n_as", "reset_recovery", "p2_distribution", "session_transitions"}:
        key = {
            "p2": "p2_ms",
            "p4": "p4_ms",
            "n_as": "n_as_ms",
            "reset_recovery": "recovery_ms",
            "p2_distribution": "p2_ms",
            "session_transitions": "p2_ms",
        }[kind]
        if kind == "reset_recovery":
            if not measurement.get("reset_response_ok"):
                return _failed(spec, "复位请求未获得 0x51 01 正响应", measurement)
            try:
                recovered_session = int(measurement.get("recovered_session", -1))
            except (TypeError, ValueError):
                recovered_session = -1
            default_session_id = int(spec.get("default_session_id", 0x01))
            if recovered_session != default_session_id:
                return _failed(
                    spec,
                    f"复位后未核验回到默认会话 F186={default_session_id:02X}",
                    measurement,
                )
        if kind == "n_as" and (
                int(measurement.get("request_frame_count", 0) or 0) < 1
                or int(measurement.get("response_frame_count", 0) or 0) < 1):
            return _failed(spec, "N_As 缺少本条用例的 0x3C 请求帧或 0x3D 响应帧", measurement)
        return timed_pass(key)

    if kind == "p2_star":
        values = _as_float_list(measurement.get("p2_star_ms"))
        pending = int(measurement.get("pending_count", 0) or 0)
        if pending < 1 or not values:
            return _failed(spec, "未捕获 0x78 pending → 最终响应的 P2* 证据", measurement)
        if limit is not None and max(values) > float(limit):
            return {"verdict": "FAIL", "actual": f"P2* 最大 {max(values):.3f}ms 超限", "note": f"限值 {float(limit):.3f}ms", "metrics": metrics}
        return {"verdict": "PASS", "actual": f"P2* 最大 {max(values):.3f}ms", "note": f"捕获 pending {pending} 次", "metrics": metrics}

    if kind == "s3":
        observed = measurement.get("observed_session")
        if observed is None:
            return _failed(spec, "S3 超时后未获得 F186 会话确认", measurement)
        expected = int(measurement.get(
            "expected_session", spec.get("default_session_id", 0x01)
        ))
        if int(observed) != expected:
            return {"verdict": "FAIL", "actual": f"S3 后 F186={int(observed):02X}", "note": f"期望 F186={expected:02X}", "metrics": metrics}
        values = _as_float_list(measurement.get("s3_ms"))
        if not values:
            return _failed(spec, "S3 等待时长未形成独立证据", measurement)
        # 本用例的目的，是在 S3Server 之后验证会话是否回默认；等待值
        # 是测试仪主动选择的 S3+余量，不是 ECU 触发回退的精确边沿。
        # 不能把“主动等待了 5.25s 后才发核验请求”再与 5.0s 直接比较，
        # 否则会把测量方法本身的调度/请求耗时误判成 ECU 超时。精确
        # 4.5s/5.0s/5.5s 边界由独立的 s3_boundary 用例判定。
        wait_note = (
            f"等待 {values[0]:.3f}ms 后 F186={expected:02X}；"
            "S3 边界由独立用例测量"
        )
        return {"verdict": "PASS", "actual": f"S3 后 F186={int(observed):02X}，观测 {values[0]:.3f}ms", "note": wait_note, "metrics": metrics}

    if kind == "s3_boundary":
        observations = measurement.get("observations") or []
        expected_sessions = spec.get("expected_sessions") or []
        if len(observations) != len(expected_sessions):
            return _failed(spec, f"S3 边界场景证据不完整：{len(observations)}/{len(expected_sessions)}", measurement)
        for index, (row, accepted) in enumerate(zip(observations, expected_sessions), 1):
            observed = row.get("session") if isinstance(row, dict) else None
            if observed is None or int(observed) not in [int(x) for x in accepted]:
                return {"verdict": "FAIL", "actual": f"S3 边界第 {index} 组 F186={observed}", "note": f"允许会话 {accepted}", "metrics": metrics}
        return {"verdict": "PASS", "actual": f"S3 边界 {len(observations)} 组均有会话证据", "note": "4.5s/5.0s/5.5s 场景已分别执行", "metrics": metrics}

    if kind == "n_cr":
        if int(measurement.get("response_frame_count", 0) or 0) < 2:
            return _failed(spec, "N_Cr 未捕获至少两帧 FF/CF 响应，不能用普通 P2 代替", measurement)
        return timed_pass("n_cr_ms", require_min=1)

    if kind == "bs_stmin":
        observed = measurement.get("bs_stmin")
        if not isinstance(observed, dict):
            return _failed(spec, "未捕获 LIN TP 流控 BS/STmin 帧，不能用普通 P2 结果替代", measurement)
        expected_fc_id = int(spec.get("tx_frame_id", 0x3C))
        if observed.get("frame_id") != expected_fc_id or observed.get("direction") != "TX":
            return _failed(
                spec,
                f"BS/STmin 不是本条用例的 0x{expected_fc_id:X} TX 流控帧，不能判定",
                measurement,
            )
        if int(measurement.get("response_frame_count", 0) or 0) < 2:
            return _failed(spec, "BS/STmin 用例未捕获完整 FF/CF 响应，不能判定流控参数", measurement)
        if not measurement.get("response"):
            return _failed(spec, "BS/STmin 测量未形成完整多帧传输响应", measurement)
        if int(observed.get("bs", -1)) != int(spec.get("expected_bs", 0)) or int(observed.get("stmin", -1)) != int(spec.get("expected_stmin", 0)):
            return {"verdict": "FAIL", "actual": f"BS={observed.get('bs')} STmin={observed.get('stmin')}", "note": "与调查表 Network Layer 参数不一致", "metrics": metrics}
        return {"verdict": "PASS", "actual": f"BS={observed['bs']} STmin={observed['stmin']}", "note": "流控帧独立捕获并匹配", "metrics": metrics}

    if kind == "frame_jitter":
        slots = _as_float_list(measurement.get("slot_ms"))
        jitter = measurement.get("jitter_ms")
        if len(slots) < 2 or jitter is None:
            return _failed(spec, "帧抖动有效样本不足", measurement)
        threshold = float(spec.get("jitter_limit_ms", 0.0))
        if threshold and float(jitter) > threshold:
            return {"verdict": "FAIL", "actual": f"帧抖动 {float(jitter):.3f}ms 超限", "note": f"限值 {threshold:.3f}ms", "metrics": metrics}
        return {"verdict": "PASS", "actual": f"帧抖动 {float(jitter):.3f}ms", "note": f"采集 {len(slots)} 个帧隙", "metrics": metrics}

    if kind == "frame_gap":
        return timed_pass("frame_gap_ms", label="LIN 帧隙", require_min=1)

    if kind == "multi_frame":
        if int(measurement.get("request_frame_count", 0) or 0) < 2:
            return _failed(spec, str(spec.get("payload_error") or "请求未形成多帧，无法判定 N_As/N_Cr"), measurement)
        if int(measurement.get("response_frame_count", 0) or 0) < 2:
            return _failed(spec, "响应未形成至少两帧 FF/CF，无法判定 N_As/N_Cr", measurement)
        if not _as_float_list(measurement.get("n_as_ms")) or not _as_float_list(measurement.get("n_cr_ms")):
            return _failed(spec, "多帧请求缺少 N_As 或 N_Cr 独立证据", measurement)
        if not measurement.get("response"):
            return _failed(spec, "多帧请求未形成完整响应", measurement)
        if limit is not None and max(_as_float_list(measurement.get("n_as_ms")) + _as_float_list(measurement.get("n_cr_ms"))) > float(limit):
            return {"verdict": "FAIL", "actual": "多帧 N_As/N_Cr 超限", "note": f"限值 {float(limit):.3f}ms", "metrics": metrics}
        return {"verdict": "PASS", "actual": "多帧 N_As/N_Cr 均有实测", "note": "请求帧、响应帧和帧间隔均已采集", "metrics": metrics}

    return _failed(spec, f"不支持的时序指标 {kind}", measurement)


def _finalize_timing_decision(
    spec: dict[str, Any],
    measurement: dict[str, Any],
    decision: dict[str, Any],
) -> dict[str, Any]:
    """把时序判定与响应内容判定合并，但保留两者的独立结论。"""
    timing_verdict = decision.get("verdict", "FAIL")
    decision["timing_verdict"] = timing_verdict
    response_verdict = str(measurement.get("response_verdict") or "NA")
    decision["response_verdict"] = response_verdict
    response_errors = list(measurement.get("response_errors") or [])
    if response_errors:
        decision["response_errors"] = response_errors
    if response_verdict == "FAIL" and timing_verdict not in {"BLOCKED"}:
        decision["verdict"] = "FAIL"
        response_note = "；".join(str(item) for item in response_errors) or "响应内容不符合要求"
        actual = str(decision.get("actual") or "")
        decision["actual"] = f"{actual}；响应内容 FAIL" if actual else "响应内容 FAIL"
        note = str(decision.get("note") or "")
        decision["note"] = f"{note}；{response_note}" if note else response_note
    return decision


def evaluate_timing_case(spec: dict[str, Any], measurement: dict[str, Any]) -> dict[str, Any]:
    """公开判定接口：分别输出 timing_verdict 与 response_verdict。"""
    decision = _evaluate_timing_case_base(spec, measurement)
    return _finalize_timing_decision(spec, measurement, decision)


def _frame_payload(frame: list[int], parser: Any) -> tuple[str, int, list[int]]:
    try:
        parsed = parser(frame)
        kind, nad, _pci, payload = parsed[:4]
        return str(kind), int(nad), list(payload)
    except Exception:
        return "unknown", 0, []


def _runner_metadata() -> dict[str, Any]:
    """返回可复核的 runner 身份，避免结果与 trace 跨版本/轮次混用。"""
    path = os.path.abspath(__file__)
    digest = ""
    try:
        with open(path, "rb") as handle:
            digest = hashlib.sha256(handle.read()).hexdigest()
    except OSError:
        digest = "unavailable"
    return {"version": TIMING_RUNNER_VERSION, "path": path, "sha256": digest}


def _new_run_id(case_id: str) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    return f"{case_id}:{stamp}:pid-{os.getpid()}"


def _expected_request_frame(nad: int, payload: list[int]) -> list[int]:
    # 延迟导入保持 timing_case_runner 的离线 spec/判定测试不依赖硬件模块。
    from lin_tp import pack_request

    frames = pack_request(int(nad), list(payload))
    return [int(b) for b in frames[0]] if frames else []


def _match_request_response(
    events: list[dict[str, Any]],
    nad: int,
    payload: list[int],
    bus: str = "lin",
    tx_frame_id: int | None = None,
    rx_frame_id: int | None = None,
) -> tuple[dict[str, Any], dict[str, Any]] | None:
    """严格关联当前 UDS 请求首帧与其后的首个从响应帧。"""
    expected = _expected_request_frame(nad, payload)
    if not expected:
        return None
    is_can = str(bus or "lin").lower() == "can"
    expected_tx_id = int(tx_frame_id if tx_frame_id is not None else 0x3C)
    expected_rx_id = int(rx_frame_id if rx_frame_id is not None else 0x3D)
    candidates = [
        event for event in events
        if event.get("direction") == "TX"
        and int(event.get("frame_id", -1)) == expected_tx_id
        and (
            _can_frame_contains_payload(list(event.get("data") or []), payload)
            if is_can else list(event.get("data") or []) == expected
        )
    ]
    for tx in candidates:
        tx_index = int(tx.get("event_index", -1))
        rx_candidates = [
            event for event in events
            if int(event.get("event_index", -1)) > tx_index
            and event.get("direction") == "RX"
            and int(event.get("frame_id", -1)) == expected_rx_id
            and (is_can or int(event.get("nad", -1)) == int(nad))
            and event.get("data")
        ]
        if rx_candidates:
            return tx, rx_candidates[0]
    return None


def _transaction_request_frames(
    events: list[dict[str, Any]],
    nad: int,
    payload: list[int],
    bus: str = "lin",
    tx_frame_id: int | None = None,
) -> list[dict[str, Any]]:
    """返回严格属于当前请求组帧的 TX 0x3C 帧。"""
    from lin_tp import pack_request

    expected = {tuple(int(b) for b in frame) for frame in pack_request(int(nad), list(payload))}
    is_can = str(bus or "lin").lower() == "can"
    expected_tx_id = int(tx_frame_id if tx_frame_id is not None else 0x3C)
    return [
        event for event in events
        if event.get("direction") == "TX"
        and int(event.get("frame_id", -1)) == expected_tx_id
        and (
            _can_frame_contains_payload(list(event.get("data") or []), payload)
            if is_can else tuple(int(b) for b in (event.get("data") or [])) in expected
        )
    ]


def _response_verdict(response: Any, spec: dict[str, Any]) -> tuple[str, str]:
    """独立判断响应内容，不覆盖已经采到的时序数值。"""
    if not response:
        return "FAIL", "无应答"
    if list(response[:1]) == [0x7F]:
        nrc = response[2] if len(response) >= 3 else None
        allowed = {int(value) for value in (spec.get("allowed_response_nrcs") or [])}
        if nrc is not None and int(nrc) in allowed:
            return "NA", f"收到矩阵允许的条件性 NRC=0x{int(nrc):02X}：{_hex(response)}"
    expected = list(spec.get("expected_prefix") or [])
    if expected and list(response[:len(expected)]) != expected:
        return "FAIL", f"响应前缀不匹配：{_hex(response)}"
    if spec.get("response_policy") == "positive" and list(response[:1]) == [0x7F]:
        nrc = response[2] if len(response) >= 3 else None
        suffix = f"，NRC=0x{int(nrc):02X}" if nrc is not None else ""
        return "FAIL", f"正向时序用例收到负响应{suffix}：{_hex(response)}"
    if expected or spec.get("response_policy") == "positive":
        return "PASS", f"响应匹配：{_hex(response)}"
    return "NA", f"已捕获响应：{_hex(response)}（未指定响应内容判定）"


def _trace_events(
    trace: list[Any],
    parser: Any,
    direction: str | None = None,
    transaction_id: str | None = None,
    sample_index: int | None = None,
    request_payload: list[int] | None = None,
) -> list[dict[str, Any]]:
    out = []
    for index, event in enumerate(trace or []):
        event_transaction_id = transaction_id
        if isinstance(event, dict):
            ts = event.get("ts")
            direct = event.get("direction")
            frame_id = event.get("frame_id")
            data = event.get("data")
            event_transaction_id = event.get("transaction_id") or event_transaction_id
        elif isinstance(event, (list, tuple)) and len(event) >= 4:
            ts, direct, frame_id, data = event[:4]
            # F1L1UDS v2.1 以后在原始 tuple 第 5 项写入事务 ID；
            # 老 Fake/驱动轨迹仍可由调用方注入 ID。
            if len(event) >= 5 and event[4]:
                event_transaction_id = str(event[4])
        else:
            continue
        if direction and direct != direction:
            continue
        if ts is None or direct is None or frame_id is None:
            continue
        kind, nad, payload = _frame_payload(list(data or []), parser)
        item = {
            "event_index": index,
            "ts": float(ts),
            "direction": direct,
            "frame_id": int(frame_id),
            "data": list(data or []),
            "kind": kind,
            "nad": nad,
            "payload": payload,
            "transaction_id": event_transaction_id or "unassigned",
        }
        if sample_index is not None:
            item["sample_index"] = int(sample_index)
        if request_payload is not None:
            item["request_payload"] = list(request_payload)
        out.append(item)
    return out


def _derive_p2_from_trace(
    traces: list[dict[str, Any]],
    default_nad: int,
    bus: str = "lin",
    tx_frame_id: int | None = None,
    rx_frame_id: int | None = None,
) -> tuple[list[float], list[dict[str, Any]], list[str]]:
    """仅从独立事务 trace 重算 P2，返回值、配对证据和错误。"""
    groups: dict[str, list[dict[str, Any]]] = {}
    for event in traces or []:
        if not isinstance(event, dict):
            continue
        transaction_id = str(event.get("transaction_id") or "unassigned")
        groups.setdefault(transaction_id, []).append(event)

    values: list[float] = []
    pairs: list[dict[str, Any]] = []
    errors: list[str] = []
    for transaction_id, events in groups.items():
        request_payload = next(
            (list(event.get("request_payload") or []) for event in events
             if event.get("request_payload") is not None),
            [],
        )
        if not request_payload:
            errors.append(f"事务 {transaction_id} 缺少 request_payload")
            continue
        # 不能从所有 TX 0x3C 事件的第一个解析 NAD 推断地址：调度表
        # 可能先返回填充帧（例如 FF），其首字节为 0xFF。事务 NAD
        # 应来自 timing spec，而请求帧的精确匹配再由 payload 验证。
        nad = int(default_nad)
        pair = _match_request_response(
            events, nad, request_payload, bus=bus,
            tx_frame_id=tx_frame_id, rx_frame_id=rx_frame_id,
        )
        if not pair:
            errors.append(f"事务 {transaction_id} 缺少严格匹配的 0x3C TX→0x3D RX")
            continue
        tx_event, rx_event = pair
        delta_ms = (float(rx_event["ts"]) - float(tx_event["ts"])) * 1000.0
        if delta_ms < 0:
            errors.append(f"事务 {transaction_id} 请求/响应硬件时间戳倒序")
            continue
        value = round(delta_ms, 3)
        values.append(value)
        pairs.append({
            "transaction_id": transaction_id,
            "sample_index": next((event.get("sample_index") for event in events
                                   if event.get("sample_index") is not None), None),
            "request_event_index": tx_event.get("event_index"),
            "response_event_index": rx_event.get("event_index"),
            "request_ts": tx_event.get("ts"),
            "response_ts": rx_event.get("ts"),
            "p2_ms": value,
        })
    return values, pairs, errors


def _reconcile_timing_measurement(
    spec: dict[str, Any],
    measurement: dict[str, Any],
) -> dict[str, Any]:
    """验证结果数值必须等于同一份原始 trace 的硬件时间戳重算值。"""
    if spec.get("metric") not in {"p2", "p2_distribution", "session_transitions"}:
        return measurement
    traces = measurement.get("traces")
    if not isinstance(traces, list) or not traces:
        return measurement
    derived, pairs, errors = _derive_p2_from_trace(
        traces, int(spec.get("request_nad", 0x51)),
        bus=spec.get("bus", "lin"),
        tx_frame_id=spec.get("tx_frame_id"),
        rx_frame_id=spec.get("rx_frame_id"),
    )
    reported = _as_float_list(measurement.get("p2_ms"))
    integrity = {
        "status": "PASS" if not errors and reported == derived else "INVALID",
        "method": "xcdevlay_hardware_timestamp",
        "definition": "0x3C TX request frame timestamp to subsequent 0x3D RX response frame timestamp",
        "reported_p2_ms": reported,
        "trace_p2_ms": derived,
        "transaction_count": len(pairs),
        "pairs": pairs,
        "errors": errors,
    }
    measurement["trace_integrity"] = integrity
    measurement["trace_p2_ms"] = derived
    measurement["trace_pairs"] = pairs
    if errors or reported != derived:
        mismatch = (
            f"P2 结果与原始 trace 不一致：result={reported}，trace={derived}"
            if reported != derived else "P2 原始 trace 关联不完整"
        )
        if errors:
            mismatch += "；" + "；".join(errors)
        measurement["error"] = mismatch
    return measurement


def _response_session(resp: Any) -> int | None:
    if isinstance(resp, (list, tuple)) and len(resp) >= 4 and list(resp[:3]) == [0x62, 0xF1, 0x86]:
        return int(resp[3])
    return None


def _request_with_trace(
    uds: Any,
    nad: int,
    payload: list[int],
    timeout: float,
    flow_control: tuple[int, int] | None = None,
    transaction_id: str | None = None,
) -> tuple[Any, list[Any], float, float]:
    if hasattr(uds, "request_with_trace"):
        request_with_trace = uds.request_with_trace
        try:
            return request_with_trace(
                nad, payload, timeout=timeout, flow_control=flow_control,
                transaction_id=transaction_id,
            )
        except TypeError as exc:
            # 兼容旧版 Fake/驱动封装；只有明确是未知关键字时才回退，
            # 不能吞掉 request_with_trace 内部真实的 TypeError。
            if "transaction_id" not in str(exc):
                raise
            return request_with_trace(nad, payload, timeout=timeout, flow_control=flow_control)
    started = _now()
    response = uds.request(nad, payload, timeout=timeout, retry=0)
    ended = _now()
    return response, [], started, ended


def _resolve_session_id(
    session: Any,
    session_id_by_name: dict[str, int] | None = None,
    default_session_id: int = 0x01,
) -> int | None:
    configured = {str(key).strip().lower(): int(value)
                  for key, value in (session_id_by_name or {}).items()}
    if isinstance(session, bool):
        return None
    if isinstance(session, int):
        return int(session)
    raw = str(session or "").strip()
    try:
        return int(raw, 0)
    except (TypeError, ValueError):
        pass
    if raw.lower() in configured:
        return configured[raw.lower()]
    legacy = {"default": 0x01, "programming": 0x02, "extended": 0x03}
    if raw.lower() in legacy and not configured:
        return legacy[raw.lower()]
    return configured.get(raw.lower(), default_session_id if raw.lower() == "default" else None)


def _establish_session(
    uds: Any,
    nad: int,
    session: str,
    session_id_by_name: dict[str, int] | None = None,
    default_session_id: int = 0x01,
) -> tuple[bool, str]:
    target = _resolve_session_id(session, session_id_by_name, default_session_id)
    if target is None:
        return False, f"项目配置未定义目标会话：{session}"
    baseline = uds.request(nad, [0x10, int(default_session_id)], timeout=3.0, retry=1)
    if (not baseline or baseline[0] != 0x50 or len(baseline) < 2
            or baseline[1] != int(default_session_id)):
        return False, "无法回默认会话：" + _hex(baseline)
    if target != int(default_session_id):
        changed = uds.request(nad, [0x10, target], timeout=3.0, retry=1)
        if not changed or changed[0] != 0x50 or len(changed) < 2 or changed[1] != target:
            return False, "无法进入目标会话：" + _hex(changed)
        # 0x10 02/03 starts S3.  Send the suppressed TesterPresent once
        # before the verification request so a slow setup/measurement path
        # cannot expire the newly entered non-default session.
        keepalive = uds.request(nad, [0x3E, 0x80], timeout=3.0, retry=1)
        if keepalive is not None:
            return False, "进入非默认会话后 0x3E 80 保活返回异常：" + _hex(keepalive)
    check = uds.request(nad, [0x22, 0xF1, 0x86], timeout=3.0, retry=1)
    if _response_session(check) != target:
        return False, "F186 会话核验失败：" + _hex(check)
    return True, ""


def _measure_case(uds: Any, spec: dict[str, Any], nad: int) -> dict[str, Any]:
    from lin_tp import parse_frame

    kind = spec["metric"]
    bus = str(spec.get("bus") or "lin").lower()
    tx_frame_id = int(spec.get("tx_frame_id", 0x3C))
    rx_frame_id = int(spec.get("rx_frame_id", 0x3D))
    frame_parser = _parse_can_frame if bus == "can" else parse_frame
    session_ids = spec.get("session_id_by_name") or None
    default_session_id = int(spec.get("default_session_id", 0x01))
    payload = list(spec.get("payload") or [])
    if not payload and kind not in {"s3", "s3_boundary", "reset_recovery", "session_transitions"}:
        return {"error": "用例没有可执行请求 payload"}

    def establish() -> tuple[bool, str]:
        return _establish_session(
            uds, nad, spec.get("session", "default"),
            session_ids, default_session_id,
        )

    def one_request(
        request_payload: list[int],
        timeout: float = 6.0,
        flow_control: tuple[int, int] | None = None,
    ) -> tuple[Any, list[dict[str, Any]], float, float]:
        one_request.counter += 1
        transaction_id = f"{spec.get('case_id', 'timing')}:txn-{one_request.counter:04d}"
        response, trace, started, ended = _request_with_trace(
            uds, nad, request_payload, timeout, flow_control=flow_control,
            transaction_id=transaction_id,
        )
        return response, _trace_events(
            trace, frame_parser, transaction_id=transaction_id,
            sample_index=one_request.counter,
            request_payload=request_payload,
        ), started, ended

    one_request.counter = 0

    if kind == "n_as":
        ok, reason = establish()
        if not ok:
            return {"error": reason}
        response, events, _started, _ended = one_request(
            payload,
            timeout=8.0,
        )
        if not response:
            return {"error": "N_As 请求完成后无有效响应", "traces": events}
        response_verdict, response_note = _response_verdict(response, spec)
        pair = _match_request_response(
            events, nad, payload, bus=bus,
            tx_frame_id=tx_frame_id, rx_frame_id=rx_frame_id,
        )
        if not pair:
            return {
                "error": "N_As 未捕获本条用例的请求帧到响应帧轨迹，禁止用普通 P2 代替",
                "request_frame_count": len(_transaction_request_frames(
                    events, nad, payload, bus=bus, tx_frame_id=tx_frame_id)),
                "traces": events,
            }
        tx, rx = pair
        return {
            # 本项目调查表对 N_As 的定义是主请求帧到从响应帧起始，
            # 因此即使本条请求是单帧，也必须以独立的 n_as_ms 记录，
            # 不能把另一份普通 P2 汇总数字拷贝过来。
            "n_as_ms": [round((rx["ts"] - tx["ts"]) * 1000.0, 3)],
            "request_frame_count": len(_transaction_request_frames(
                events, nad, payload, bus=bus, tx_frame_id=tx_frame_id)),
            "response_frame_count": 1,
            "response": response,
            "response_verdict": response_verdict,
            "response_errors": [] if response_verdict != "FAIL" else [response_note],
            "traces": events,
        }

    if kind == "bs_stmin":
        ok, reason = establish()
        if not ok:
            return {"error": reason}
        # TC0007 的请求是单帧读请求，F12E 的响应才是 FF/CF 多帧。
        # 不能用“请求 payload 长度”判断是否可以测 BS/STmin，否则会把
        # 真实的单帧请求→多帧响应场景错误地判成未测试。
        response, events, _started, _ended = one_request(
            payload,
            timeout=8.0,
            flow_control=(
                int(spec.get("expected_bs", 0)),
                int(spec.get("expected_stmin", 0)),
            ),
        )
        if response and spec.get("expected_prefix") and list(response[:len(spec["expected_prefix"])]) != list(spec["expected_prefix"]):
            return {"error": f"BS/STmin 响应前缀不匹配：{_hex(response)}", "traces": events, "response": response}
        # TC0007 读取 ECU 多帧响应，BS/STmin 应来自接收端（主机）发给
        # ECU 的 0x3C TX 流控帧。0x3D RX 上的普通响应或其它方向 FC
        # 不能被误认成该条用例的控制参数。
        fc = [e for e in events if e["kind"] == "fc" and e["frame_id"] == tx_frame_id and e["direction"] == "TX"]
        response_frames = [e for e in events if e["direction"] == "RX" and e["frame_id"] == rx_frame_id and e["kind"] in {"ff", "cf"}]
        observed = None
        if fc and len(fc[0]["payload"]) >= 2:
            observed = {
                "bs": fc[0]["payload"][0],
                "stmin": fc[0]["payload"][1],
                "direction": fc[0]["direction"],
                "frame_id": fc[0]["frame_id"],
                "data": fc[0]["data"],
                "payload": fc[0]["payload"],
                "ts": fc[0]["ts"],
            }
        return {"bs_stmin": observed, "response": response, "response_frame_count": len(response_frames), "traces": events}

    if kind in {"p2", "p4", "frame_gap", "p2_distribution", "session_transitions"}:
        ok, reason = establish()
        if not ok:
            return {"error": reason}
        if kind == "session_transitions":
            values = []
            traces = []
            transition_ids = []
            for value in (spec.get("session_transition_ids") or ()):
                try:
                    session_id = int(value)
                except (TypeError, ValueError):
                    continue
                if session_id not in transition_ids:
                    transition_ids.append(session_id)
            if not transition_ids:
                transition_ids = [int(spec.get("default_session_id", 0x01))]
            for target in transition_ids:
                response, events, started, ended = one_request([0x10, target])
                if not response or response[0] != 0x50 or len(response) < 2 or response[1] != target:
                    return {"error": f"会话切换 0x{target:02X} 无有效正响应：{_hex(response)}", "traces": traces}
                pair = _match_request_response(
                    events, nad, [0x10, target], bus=bus,
                    tx_frame_id=tx_frame_id, rx_frame_id=rx_frame_id,
                )
                if not pair:
                    return {
                        "error": f"会话切换 0x{target:02X} 缺少原始请求/响应帧，禁止用主机往返时间代替",
                        "p2_ms": values,
                        "traces": traces + events,
                    }
                tx_event, rx_event = pair
                values.append(round((rx_event["ts"] - tx_event["ts"]) * 1000.0, 3))
                traces.extend(events)
            return {"p2_ms": values, "traces": traces, "responses": []}

        count = int(spec.get("samples", 1))
        if kind == "p2_distribution":
            count = max(count, 20)
        values = []
        traces = []
        responses = []
        response_verdict = None
        response_errors = []
        for _ in range(count):
            response, events, started, ended = one_request(payload)
            responses.append(response)
            if not response:
                return {"error": f"请求超时：{_hex(payload)}", "p2_ms": values, "traces": traces, "responses": responses}
            current_response_verdict, response_note = _response_verdict(response, spec)
            if current_response_verdict == "FAIL":
                response_verdict = "FAIL"
                response_errors.append(response_note)
            elif response_verdict is None or response_verdict == "NA":
                response_verdict = current_response_verdict
            pair = _match_request_response(
                events, nad, payload, bus=bus,
                tx_frame_id=tx_frame_id, rx_frame_id=rx_frame_id,
            )
            if not pair:
                return {
                    "error": "未捕获本条用例完整原始请求/响应帧，禁止用普通 P2 往返时间代替",
                    "p2_ms": values,
                    "traces": traces + events,
                    "responses": responses,
                }
            tx_event, rx_event = pair
            delta_ms = (rx_event["ts"] - tx_event["ts"]) * 1000.0
            if delta_ms < 0:
                return {
                    "error": "原始 LIN 请求/响应硬件时间戳倒序，时序证据无效",
                    "p2_ms": values,
                    "traces": traces + events,
                    "responses": responses,
                }
            values.append(round(delta_ms, 3))
            traces.extend(events)
        key = "p4_ms" if kind == "p4" else "n_as_ms" if kind == "n_as" else "frame_gap_ms" if kind == "frame_gap" else "p2_ms"
        return {
            key: values,
            "traces": traces,
            "responses": responses,
            "response_verdict": response_verdict or "NA",
            "response_errors": response_errors,
        }

    if kind == "p2_star":
        ok, reason = establish()
        if not ok:
            return {"error": reason}
        response, events, started, ended = one_request(payload, timeout=8.0)
        if not response:
            return {"error": "P2* 最终响应超时", "traces": events}
        pair = _match_request_response(
            events, nad, payload, bus=bus,
            tx_frame_id=tx_frame_id, rx_frame_id=rx_frame_id,
        )
        if not pair:
            return {"error": "P2* 未捕获本条用例的请求帧到响应帧轨迹", "traces": events}
        tx_event, first_rx_event = pair
        rx = [
            e for e in events
            if int(e.get("event_index", -1)) >= int(first_rx_event.get("event_index", -1))
            and e["direction"] == "RX" and e["frame_id"] == rx_frame_id
        ]
        pending = [e for e in rx if len(e["payload"]) >= 3 and e["payload"][0] == 0x7F and e["payload"][2] == 0x78]
        finals = [e for e in rx if not (len(e["payload"]) >= 3 and e["payload"][0] == 0x7F and e["payload"][2] == 0x78)]
        if not pending or not finals:
            return {"error": "未形成请求→0x78 pending→最终响应链路", "pending_count": len(pending), "traces": events}
        response_verdict, response_note = _response_verdict(response, spec)
        return {
            "p2_star_ms": [round((finals[-1]["ts"] - tx_event["ts"]) * 1000.0, 3)],
            "pending_count": len(pending),
            "traces": events,
            "responses": [response],
            "response_verdict": response_verdict,
            "response_errors": [] if response_verdict != "FAIL" else [response_note],
        }

    if kind == "s3":
        session = spec.get("session") or "extended"
        ok, reason = _establish_session(
            uds, nad, session, session_ids, default_session_id,
        )
        if not ok:
            return {"error": reason}
        started = _now()
        time.sleep(float(spec.get("max_ms") or 5000.0) / 1000.0 + 0.25)
        response, events, _request_started, _request_ended = one_request([0x22, 0xF1, 0x86], timeout=3.0)
        elapsed = (_now() - started) * 1000.0
        session_id = _response_session(response)
        return {"s3_ms": [round(elapsed, 3)], "observed_session": session_id,
                "expected_session": default_session_id, "traces": events,
                "responses": [response]}

    if kind == "s3_boundary":
        rows = []
        traces = []
        for interval in spec.get("intervals_ms", [4500.0, 5000.0, 5500.0]):
            session = spec.get("session") or "extended"
            ok, reason = _establish_session(
                uds, nad, session, session_ids, default_session_id,
            )
            if not ok:
                return {"error": reason, "observations": rows, "traces": traces}
            time.sleep(float(interval) / 1000.0)
            # 按调查表实际步骤发送 3E 保活，再独立读取 F186 观察会话是否
            # 保持/回退；不能只发 F186 把 S3 保活场景简化成普通 P2。
            keepalive, keepalive_events, _ks, _ke = one_request([0x3E, 0x00], timeout=3.0)
            check, check_events, _cs, _ce = one_request([0x22, 0xF1, 0x86], timeout=3.0)
            rows.append({
                "interval_ms": interval,
                "keepalive_response": keepalive,
                "session": _response_session(check),
                "response": check,
            })
            traces.extend(keepalive_events)
            traces.extend(check_events)
        return {"observations": rows, "traces": traces}

    if kind == "n_cr":
        ok, reason = establish()
        if not ok:
            return {"error": reason}
        # N_Cr 专项必须完成真实的 FF/CF 传输；收到 ECU 首帧后显式发出
        # 主节点 0x3C 流控（BS=0、STmin=0），不能依赖 ECU 恰好自动连续
        # 发送，否则只收到一个 CF 时会把“未完成多帧”误当作 N_Cr 结果。
        response, events, _started, _ended = one_request(
            payload, timeout=8.0, flow_control=(0, 0))
        rx = [e for e in events if e["direction"] == "RX" and e["frame_id"] == rx_frame_id and e["kind"] in {"ff", "cf"}]
        slots = [round((rx[i]["ts"] - rx[i - 1]["ts"]) * 1000.0, 3) for i in range(1, len(rx))]
        if not response:
            return {"error": "多帧响应超时", "n_cr_ms": slots, "traces": events}
        if spec.get("expected_prefix") and list(response[:len(spec["expected_prefix"])]) != list(spec["expected_prefix"]):
            return {"error": f"N_Cr 响应前缀不匹配：{_hex(response)}", "n_cr_ms": slots, "response_frame_count": len(rx), "response": response, "traces": events}
        return {"n_cr_ms": [max(slots)] if slots else [], "response_frame_count": len(rx), "response": response, "traces": events, "responses": [response]}

    if kind == "frame_jitter":
        ok, reason = establish()
        if not ok:
            return {"error": reason}
        all_tx = []
        traces = []
        for _ in range(max(3, int(spec.get("samples", 10)))):
            response, events, _started, _ended = one_request([0x3E, 0x00], timeout=3.0)
            if not response:
                return {"error": "3E 保活请求超时", "traces": traces}
            tx = [e["ts"] for e in events if e["direction"] == "TX" and e["frame_id"] == tx_frame_id]
            all_tx.extend(tx)
            traces.extend(events)
        slots = [round((all_tx[i] - all_tx[i - 1]) * 1000.0, 3) for i in range(1, len(all_tx))]
        return {"slot_ms": slots, "jitter_ms": round(max(slots) - min(slots), 3) if slots else None, "traces": traces}

    if kind == "multi_frame":
        if len(payload) <= 6:
            return {"error": str(spec.get("payload_error") or f"请求 payload 仅 {len(payload)} 字节，不是多帧；禁止用普通 P2 代替")}
        ok, reason = establish()
        if not ok:
            return {"error": reason}
        response, events, _started, _ended = one_request(payload, timeout=8.0)
        tx = [e for e in events if e["direction"] == "TX" and e["frame_id"] == tx_frame_id and e["kind"] in {"ff", "cf"}]
        rx = [e for e in events if e["direction"] == "RX" and e["frame_id"] == rx_frame_id and e["kind"] in {"ff", "cf"}]
        tx_slots = [round((tx[i]["ts"] - tx[i - 1]["ts"]) * 1000.0, 3) for i in range(1, len(tx))]
        rx_slots = [round((rx[i]["ts"] - rx[i - 1]["ts"]) * 1000.0, 3) for i in range(1, len(rx))]
        n_as = [round((rx[0]["ts"] - tx[0]["ts"]) * 1000.0, 3)] if tx and rx else []
        if response and spec.get("expected_prefix") and list(response[:len(spec["expected_prefix"])]) != list(spec["expected_prefix"]):
            return {"error": f"多帧响应前缀不匹配：{_hex(response)}", "request_frame_count": len(tx), "response_frame_count": len(rx), "n_as_ms": n_as, "n_cr_ms": [max(rx_slots)] if rx_slots else [], "response": response, "traces": events}
        return {"request_frame_count": len(tx), "response_frame_count": len(rx), "n_as_ms": n_as, "n_cr_ms": [max(rx_slots)] if rx_slots else [], "tx_slots_ms": tx_slots, "response": response, "traces": events}

    if kind == "reset_recovery":
        ok, reason = establish()
        if not ok:
            return {"error": reason}
        started = _now()
        reset_response, reset_events, _rs, _re = one_request([0x11, 0x01], timeout=3.0)
        traces = list(reset_events)
        if not reset_response or list(reset_response[:2]) != [0x51, 0x01]:
            return {
                "error": "复位请求未获得 0x51 01 正响应：" + _hex(reset_response),
                "reset_response_ok": False,
                "traces": traces,
            }
        deadline = _now() + 5.0
        recovered = None
        last_response = None
        while _now() < deadline:
            response, events, _ps, _pe = one_request([0x22, 0xF1, 0x86], timeout=1.0)
            traces.extend(events)
            last_response = response
            if _response_session(response) == default_session_id:
                recovered = (_now() - started) * 1000.0
                break
            time.sleep(0.1)
        return {
            "recovery_ms": [round(recovered, 3)] if recovered is not None else [],
            "reset_response_ok": True,
            "recovered_session": _response_session(last_response),
            "response_ok": recovered is not None,
            "last_response": last_response,
            "traces": traces,
        }

    return {"error": f"不支持的时序指标 {kind}"}


class _CanTraceBus:
    """为生成的 CAN UDS 客户端收集逐帧时间戳，不改变其总线 API。"""

    def __init__(self, raw_bus: Any):
        self.raw_bus = raw_bus
        self.events: list[tuple[float, str, int, list[int]]] | None = None

    def start_trace(self):
        self.events = []

    def stop_trace(self) -> list[tuple[float, str, int, list[int]]]:
        events = self.events or []
        self.events = None
        return events

    def send(self, message: Any, *args: Any, **kwargs: Any) -> Any:
        result = self.raw_bus.send(message, *args, **kwargs)
        if self.events is not None:
            self.events.append((
                _now(), "TX", int(message.arbitration_id), list(message.data),
            ))
        return result

    def recv(self, timeout: float | None = None, *args: Any, **kwargs: Any) -> Any:
        message = self.raw_bus.recv(timeout, *args, **kwargs)
        if message is not None and self.events is not None:
            self.events.append((
                _now(), "RX", int(message.arbitration_id), list(message.data),
            ))
        return message

    def __getattr__(self, name: str) -> Any:
        return getattr(self.raw_bus, name)


class _CanTimingUDS:
    """适配生成的 Vector UdsClient，使其提供 LIN runner 所需的接口。"""

    def __init__(self, client: Any, trace_bus: _CanTraceBus, raw_bus: Any):
        self.client = client
        self.trace_bus = trace_bus
        self.raw_bus = raw_bus

    def request(self, _nad: int, payload: list[int], timeout: float = 3.0, retry: int = 0) -> Any:
        del retry
        return self.client.send_request(list(payload), timeout_ms=int(timeout * 1000))

    def request_with_trace(
        self,
        _nad: int,
        payload: list[int],
        timeout: float = 3.0,
        flow_control: tuple[int, int] | None = None,
        transaction_id: str | None = None,
    ) -> tuple[Any, list[Any], float, float]:
        # 当前生成的 CAN UdsClient 使用标准 ISO-TP 流控；flow_control 仅由
        # LIN F1L1 封装直接注入，CAN 侧仍记录客户端实际发出的 FC 帧。
        del flow_control, transaction_id
        self.trace_bus.start_trace()
        started = _now()
        try:
            response = self.client.send_request(
                list(payload), timeout_ms=int(timeout * 1000),
            )
            ended = _now()
        finally:
            trace = self.trace_bus.stop_trace()
        return response, trace, started, ended


def _create_can_timing_uds(
    can_runtime: str,
    channel: str,
    bitrate: int,
    tx_id: int,
    rx_id: int,
    serial: str,
    can_fd: bool,
) -> tuple[_CanTimingUDS, Any]:
    """加载项目生成的 CAN UDS runtime，并打开 Vector 总线。"""
    if not can_runtime or not os.path.isfile(can_runtime):
        raise RuntimeError("CAN 时序缺少已生成的 CAN 运行时脚本")
    import can

    module_spec = importlib.util.spec_from_file_location(
        "uds_can_timing_runtime", can_runtime,
    )
    if module_spec is None or module_spec.loader is None:
        raise RuntimeError(f"无法加载 CAN 运行时脚本: {can_runtime}")
    runtime = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(runtime)
    channel_value = int(channel) if str(channel).lstrip("-").isdigit() else channel
    bus_kwargs = {
        "interface": "vector",
        "channel": channel_value,
        "bitrate": int(bitrate),
        "fd": bool(can_fd),
        "receive_own_messages": False,
    }
    if serial:
        bus_kwargs["serial"] = serial
    raw_bus = can.interface.Bus(**bus_kwargs)
    trace_bus = _CanTraceBus(raw_bus)
    try:
        client = runtime.UdsClient(trace_bus, int(tx_id), int(rx_id))
    except Exception:
        raw_bus.shutdown()
        raise
    adapter = _CanTimingUDS(client, trace_bus, raw_bus)
    return adapter, raw_bus.shutdown


def run_timing_case(
    spec: dict[str, Any],
    result_path: str,
    bus: str = "lin",
    can_runtime: str = "",
    can_channel: str = "0",
    can_bitrate: int = 500000,
    can_tx_id: int = 0x7E0,
    can_rx_id: int = 0x7E8,
    can_serial: str = "",
    can_fd: bool = False,
) -> dict[str, Any]:
    """执行单条时序用例；硬件/运行时异常返回 BLOCKED。"""
    run_id = _new_run_id(str(spec.get("case_id", "timing")))
    runner = _runner_metadata()
    runtime_spec = dict(spec)
    runtime_spec["bus"] = str(bus or runtime_spec.get("bus") or "lin").lower()
    measurement: dict[str, Any]
    close_bus = None
    try:
        if runtime_spec["bus"] == "can":
            uds, close_bus = _create_can_timing_uds(
                can_runtime, can_channel, can_bitrate, can_tx_id, can_rx_id,
                can_serial, can_fd,
            )
            measurement = _measure_case(
                uds, runtime_spec, int(runtime_spec.get("request_nad", 0x51)),
            )
        elif runtime_spec["bus"] == "lin":
            from f1l1_uds import F1L1UDS, NAD_PHYS

            uds = F1L1UDS()
            uds.open()
            close_bus = uds.close
            measurement = _measure_case(
                uds, runtime_spec, int(runtime_spec.get("request_nad", NAD_PHYS)),
            )
        else:
            raise RuntimeError(f"不支持的时序总线: {runtime_spec['bus']}")
    except Exception as exc:  # 硬件/驱动/运行时异常不能计入 ECU FAIL
        measurement = {
            "blocked": True,
            "failure_class": "INFRA_ERROR",
            "error": f"时序用例执行异常：{type(exc).__name__}: {exc}",
        }
    finally:
        if close_bus is not None:
            try:
                close_bus()
            except Exception:
                pass

    measurement["run_id"] = run_id
    measurement["runner"] = runner
    measurement["measurement_method"] = "hardware_timestamp_trace"
    measurement = _reconcile_timing_measurement(runtime_spec, measurement)

    try:
        decision = evaluate_timing_case(runtime_spec, measurement)
    except Exception as exc:
        # 判定器异常是脚本错误，不能让异常逃逸为 ECU FAIL。
        decision = {
            "verdict": "BLOCKED",
            "failure_class": "SCRIPT_ERROR",
            "actual": "时序判定异常",
            "note": f"{type(exc).__name__}: {exc}",
            "metrics": {},
        }
    evidence_path = ""
    try:
        evidence_path = _write_evidence(result_path, runtime_spec, measurement)
    except Exception as exc:
        # 证据落盘失败属于测试基础设施问题，不能伪装成 ECU FAIL。
        decision = {
            "verdict": "BLOCKED",
            "failure_class": "INFRA_ERROR",
            "actual": "时序证据文件写入失败",
            "note": f"{decision.get('note', '')}；证据写入异常：{type(exc).__name__}: {exc}".strip("；"),
            "metrics": decision.get("metrics", {}),
        }
    runtime_spec["failure_class"] = decision.get("failure_class", "")
    result = _result_base(runtime_spec, decision["verdict"], decision["actual"], decision["note"], decision.get("metrics"), evidence_path)
    result.update({
        "run_id": run_id,
        "runner": runner,
        "measurement_method": "hardware_timestamp_trace",
        "timing_verdict": decision.get("timing_verdict", decision.get("verdict")),
        "response_verdict": decision.get("response_verdict", measurement.get("response_verdict", "NA")),
        "measurement_integrity": measurement.get("trace_integrity", {}),
    })
    try:
        return _write_result(result_path, result)
    except Exception as exc:
        # 结果文件自身不可写时无法伪造落盘成功，保留 BLOCKED 供上层处理。
        result["verdict"] = "BLOCKED"
        result["failure_class"] = "INFRA_ERROR"
        result["note"] = f"{result.get('note', '')}；结果文件写入异常：{type(exc).__name__}: {exc}".strip("；")
        print(f"[BLOCKED] {result.get('case_id', '?')}: {result['note']}")
        return result
