#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_case_scripts 离线回归测试（不连接 LIN/CAN 硬件）。"""
import json
import os
import subprocess
import sys
import unittest
from gen_case_scripts import (expected_info, expected_session, request_payload,
                              response_check_level, routine_prerequisites,
                              routine_prerequisites_from_matrix)
from testsupport import WorkspaceTempDir


HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.path.join(HERE, "gen_case_scripts.py")
def run_generator(cases, bus="can"):
    with WorkspaceTempDir("gen") as td:
        cases_path = os.path.join(td, "cases.json")
        parsed_path = os.path.join(td, "parsed.json")
        out_dir = os.path.join(td, "out")
        with open(cases_path, "w", encoding="utf-8") as f:
            json.dump({"cases": cases}, f, ensure_ascii=False)
        with open(parsed_path, "w", encoding="utf-8") as f:
            json.dump({}, f)
        result = subprocess.run(
            [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
             "--bus", bus, "--out-dir", out_dir, "--confirmed"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        files = {}
        if os.path.isdir(out_dir):
            for name in os.listdir(out_dir):
                path = os.path.join(out_dir, name)
                if os.path.isfile(path):
                    with open(path, encoding="utf-8") as f:
                        files[name] = f.read()
        return files, result


class TestGeneratedRouting(unittest.TestCase):
    def test_incremental_only_preserves_other_manifest_entries(self):
        with WorkspaceTempDir("gen-incremental") as td:
            cases_path = os.path.join(td, "cases.json")
            parsed_path = os.path.join(td, "parsed.json")
            out_dir = os.path.join(td, "out")
            cases = [{
                "case_id": "UDS_0x22_TC_A",
                "test_point": "读取 DID",
                "procedure": "请求: 22 F1 90",
                "expected": "正响应",
                "precondition": "默认会话",
            }, {
                "case_id": "UDS_0x22_TC_B",
                "test_point": "读取 DID",
                "procedure": "请求: 22 F1 91",
                "expected": "正响应",
                "precondition": "默认会话",
            }]
            with open(cases_path, "w", encoding="utf-8") as handle:
                json.dump({"cases": cases}, handle, ensure_ascii=False)
            with open(parsed_path, "w", encoding="utf-8") as handle:
                json.dump({}, handle)
            first = subprocess.run(
                [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
                 "--bus", "can", "--out-dir", out_dir, "--confirmed"],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
            )
            self.assertEqual(first.returncode, 0, first.stderr)
            second = subprocess.run(
                [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
                 "--bus", "can", "--out-dir", out_dir, "--confirmed", "--only",
                 "UDS_0x22_TC_A"],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
            )
            self.assertEqual(second.returncode, 0, second.stderr)
            with open(os.path.join(out_dir, "manifest.json"), encoding="utf-8") as handle:
                manifest = json.load(handle)
            self.assertEqual(set(manifest["cases"]), {"UDS_0x22_TC_A", "UDS_0x22_TC_B"})
            self.assertIn("case_fingerprint", manifest["cases"]["UDS_0x22_TC_A"])

    def test_legacy_generator_did_probes_do_not_use_bbs_f190(self):
        # The legacy all-services generator has its own boundary probes.  They
        # must share the selected valid DID instead of sending the undefined
        # BBS F190 as a convenient placeholder.
        path = os.path.join(HERE, "uds_test_generator.py")
        with open(path, encoding="utf-8") as handle:
            source = handle.read()
        # B1 Phase1: 模板已拆分至 script_header_template.py，断言需同时覆盖模板源文本
        with open(os.path.join(HERE, "script_header_template.py"), encoding="utf-8") as handle:
            source += handle.read()
        self.assertIn("PROBE_DID = TIMING_DID or (0xF1, 0x86)", source)
        self.assertNotIn("send_request([SID_READ_DID, 0xF1, 0x90])", source)
        self.assertNotIn("[SID_READ_DID] + [0xF1, 0x90] * 100", source)
        self.assertIn("resp[1:3] == list(PROBE_DID)", source)

    def test_can_case_uses_existing_can_uds_stack(self):
        cases = [{
            "case_id": "UDS_0x22_TC_CAN",
            "test_point": "0x22 正向读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        script = files["case_UDS_0x22_TC_CAN.py"]
        self.assertIn("UdsClient", script)
        self.assertIn('"interface": "vector"', script)
        self.assertIn('if BUS == "can":', script)

    def test_lin_case_emits_trace_capture_and_manifest_requirement(self):
        cases = [{
            "case_id": "UDS_0x22_TC_TRACE",
            "test_point": "0x22 正向读取 DID",
            "procedure": "请求: 22 F1 86",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        files, result = run_generator(cases, bus="lin")
        self.assertEqual(result.returncode, 0, result.stderr)
        script = files["case_UDS_0x22_TC_TRACE.py"]
        manifest = json.loads(files["manifest.json"])
        self.assertIn("TRACE_REQUIRED = True", script)
        self.assertIn("request_with_trace", script)
        self.assertIn("uds-lin-trace.v1", script)
        self.assertTrue(manifest["cases"]["UDS_0x22_TC_TRACE"]["trace_required"])

    def test_missing_key_only_blocks_key_dependent_security_case(self):
        cases = [
            {
                "case_id": "UDS_0x27_TC_SEED",
                "test_point": "0x27 请求 Seed 正向",
                "procedure": "请求: 27 01",
                "expected": "正响应",
                "precondition": "编程会话",
            },
            {
                "case_id": "UDS_0x27_TC_KEY",
                "test_point": "0x27 发送正确 Key 正向",
                "procedure": "请求: 27 02 + 16字节数据",
                "expected": "正响应",
                "precondition": "编程会话",
            },
        ]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads(files["manifest.json"])
        self.assertEqual(manifest["cases"]["UDS_0x27_TC_SEED"]["status"], "pos")
        self.assertEqual(manifest["cases"]["UDS_0x27_TC_KEY"]["status"], "blocked")

    def test_missing_key_blocks_14_and_2f_positive_paths(self):
        cases = [
            {
                "case_id": "UDS_0x14_TC_PROTECTED",
                "test_point": "0x14 正向清除诊断信息",
                "procedure": "请求: 14 FF FF FF",
                "expected": "正响应",
                "precondition": "编程会话",
            },
            {
                "case_id": "UDS_0x2F_TC_PROTECTED",
                "test_point": "0x2F 正向输入输出控制",
                "procedure": "请求: 2F F1 90 03",
                "expected": "正响应",
                "precondition": "编程会话",
            },
        ]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads(files["manifest.json"])
        self.assertEqual(manifest["cases"]["UDS_0x14_TC_PROTECTED"]["status"], "blocked")
        self.assertEqual(manifest["cases"]["UDS_0x2F_TC_PROTECTED"]["status"], "blocked")

    def test_timing_case_cannot_fall_through_to_normal_uds(self):
        cases = [{
            "case_id": "UDS_TimeParm_P2",
            "test_point": "P2 时序测量",
            "procedure": "请求: 22 F1 90",
            "expected": "P2 <= 50ms",
            "precondition": "默认会话",
        }]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        script = files["case_UDS_TimeParm_P2.py"]
        self.assertIn("timing_trace.py", script)
        self.assertIn("EXECUTABLE = False", script)
        self.assertIn("from timing_case_runner import run_timing_case", script)
        self.assertIn("TIMING_SPEC = {", script)
        timing_start = script.index('if STATUS == "timing":')
        normal_start = script.index('if STATUS not in', timing_start)
        timing_branch = script[timing_start:normal_start]
        self.assertIn("run_timing_case(", timing_branch)
        self.assertNotIn('_write("SKIP"', timing_branch)

    def test_timing_case_with_normal_uds_id_is_still_timing(self):
        case = {
            "case_id": "UDS_0x10_TC_TIMING",
            "test_point": "时序测量（P2/P2*/S3）",
            "procedure": "发送 10 01，测量请求末帧到响应首帧时间",
            "expected": "响应时间 ≤P2Server≤50ms",
            "precondition": "默认会话",
        }
        expect, _, _ = expected_info(case, set())
        self.assertEqual(expect, "timing")

    def test_plain_p2_limit_text_without_measurement_intent_stays_normal_uds(self):
        case = {
            "case_id": "UDS_0x22_TC_P2_NOTE",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应；诊断参数 P2Server=50ms",
            "precondition": "默认会话",
        }
        expect, _, _ = expected_info(case, set())
        self.assertEqual(expect, "pos")

    def test_plain_hard_reset_without_recovery_measurement_stays_normal_uds(self):
        case = {
            "case_id": "UDS_0x11_TC_HARD_RESET",
            "test_point": "Hard Reset 正向",
            "procedure": "请求: 11 01",
            "expected": "正响应 51 01；ECU 执行硬件复位",
            "precondition": "默认会话",
        }
        expect, _, _ = expected_info(case, set())
        self.assertEqual(expect, "pos")

    def test_decimal_timing_limit_is_not_treated_as_response_byte(self):
        from gen_case_scripts import expected_response_prefix

        self.assertEqual(
            expected_response_prefix(
                "1. 全部正响应；2. 最大响应 ≤ P2Server_max=50ms，无超时异常。",
                "lin", 0x51,
            ),
            [],
        )

    def test_p2_reference_in_expected_does_not_force_timing(self):
        # 回归：普通功能用例在 expected 里写时序参数名（P2Server/S3Server）作为
        # "预期值参考"不应被判为时序测量用例（否则 run_all 中误 SKIP）。
        case = {
            "case_id": "UDS_0x10_TC_0001",
            "test_point": "基于需求的测试",
            "procedure": "测试仪请求：51 02 10 01 FF FF FF FF",
            "expected": "1. DUT正响应：51 06 50 01 00 32 13 88（P2Server_max=50ms，P2*Server_max=5000ms）；\n2. 会话保持默认会话，F186=0x01。",
            "precondition": "默认会话",
        }
        expect, _, _ = expected_info(case, set())
        self.assertNotEqual(expect, "timing")

    def test_timing_only_by_explicit_intent_or_timeparm_prefix(self):
        # 只有 TimeParm 前缀或 test_point 显式时序意图才判 timing；
        # procedure/expected 中的"测量响应时间"等措辞不得触发（避免误伤普通用例）。
        cases = [
            {"case_id": "UDS_TimeParm_TC_0001", "test_point": "基于需求的测试",
             "procedure": "测试仪请求：51 03 22 F1 86 FF FF FF", "expected": "P2 <= 50ms",
             "precondition": "默认会话"},
            {"case_id": "UDS_0x10_TC_P2X", "test_point": "时序测量（P2/P2*/S3）",
             "procedure": "发送 10 01", "expected": "响应时间 ≤ P2Server_max=50ms",
             "precondition": "默认会话"},
            {"case_id": "UDS_0x22_TC_0027", "test_point": "基于需求的测试",
             "procedure": "1.测试仪请求：51 03 22 F1 86 FF FF FF；\n2. 等待并解析响应，测量响应时间。",
             "expected": "1. 连续两次读均正响应；\n2. 响应时间 ≤ P2Server_max=50ms。",
             "precondition": "默认会话"},
        ]
        self.assertEqual(expected_info(cases[0], set())[0], "timing")  # TimeParm 前缀
        self.assertEqual(expected_info(cases[1], set())[0], "timing")  # 显式意图
        self.assertNotEqual(expected_info(cases[2], set())[0], "timing")  # 措辞不触发

    def test_seed_text_with_missing_key_is_not_blocked(self):
        case = {
            "case_id": "UDS_0x27_TC_BLOCKED",
            "test_point": "基于需求的测试",
            "procedure": "请求 27 05 种子",
            "expected": "本轮不执行真实解锁；缺少客户授权密钥，状态判定为 BLOCKED",
            "precondition": "扩展会话",
        }
        expect, _, _ = expected_info(case, set())
        self.assertEqual(expect, "pos")

    def test_normal_response_wording_is_a_positive_expectation(self):
        case = {
            "case_id": "UDS_0x22_TC_NORMAL",
            "test_point": "基于需求的测试",
            "procedure": "请求: 22 D0 3A",
            "expected": "DID 数据读取正常响应，且全帧数据完整",
            "precondition": "默认会话",
        }
        expect, _, _ = expected_info(case, set())
        self.assertEqual(expect, "pos")

    def test_prefers_raw_lin_frame_over_earlier_text_step(self):
        payload, status, _ = request_payload(
            "1. 请求进入扩展会话；\n"
            "2. 测试仪请求：51 03 22 F1 86 FF FF FF；",
            "lin", 0x51,
        )
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x22, 0xF1, 0x86])

    def test_keeps_intentionally_short_write_request_executable(self):
        payload, status, _ = request_payload(
            "对 F10A 写入长度错误：51 03 2E F1 0A 00 FF FF FF；",
            "lin", 0x51,
        )
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x2E, 0xF1, 0x0A])

    def test_parses_raw_lin_frame_after_frame_type_label(self):
        payload, status, _ = request_payload(
            "1.测试仪请求（0x3C）：51 02 10 01 FF FF FF FF",
            "lin", 0x51,
        )
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x10, 0x01])

    def test_lin_pci_length_is_not_sent_as_uds_payload(self):
        # 复盘回归：51 04 中的 04 是 LIN PCI，末尾 FF FF 是填充，
        # 真正的 UDS payload 只有 31 01 02 06。
        payload, status, _ = request_payload(
            "请求：51 04 31 01 02 06 FF FF",
            "lin", 0x51,
        )
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x31, 0x01, 0x02, 0x06])

    def test_lin_pci_short_frame_is_needs_data(self):
        payload, status, reason = request_payload(
            "请求：51 06 31 01 02 06",
            "lin", 0x51,
        )
        self.assertIsNone(payload)
        self.assertEqual(status, "needs_data")
        self.assertIn("PCI 声明 6", reason)

    def test_parses_short_uds_request_written_in_procedure_text(self):
        payload, status, _ = request_payload(
            "1.发送 11 01 硬复位\n2.等待复位完成，发送 22 F1 86 读会话",
            "lin", 0x51,
        )
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x11, 0x01])

    def test_ignores_service_label_after_raw_lin_frame(self):
        payload, status, _ = request_payload(
            "1.测试仪请求：51 02 19 01 FF FF FF FF（0x19 未在调查表服务范围）",
            "lin", 0x51,
        )
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x19, 0x01])

    def test_embeds_explicit_expected_response_bytes_as_an_assertion(self):
        cases = [{
            "case_id": "UDS_0x10_TC_RESPONSE_DATA",
            "test_point": "默认会话",
            "procedure": "请求：51 02 10 01 FF FF FF FF",
            "expected": "DUT正响应：51 06 50 01 00 32 01 F4",
            "precondition": "默认会话",
        }]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        script = files["case_UDS_0x10_TC_RESPONSE_DATA.py"]
        self.assertIn("EXPECT_PREFIX = [80, 1, 0, 50, 1, 244]", script)
        self.assertIn("正响应数据与期望不符", script)

    def test_functional_lin_request_keeps_nad_and_no_response_expectation(self):
        cases = [{
            "case_id": "UDS_0x10_TC_FUNCTIONAL",
            "test_point": "功能寻址",
            "procedure": "测试仪以功能寻址请求：7E 02 10 03 FF FF FF FF；",
            "expected": "功能寻址不应答，仅执行会话切换",
            "precondition": "默认会话",
        }]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        script = files["case_UDS_0x10_TC_FUNCTIONAL.py"]
        self.assertIn("REQUEST_NAD = 126", script)
        self.assertIn("PAYLOAD = [16, 3]", script)
        self.assertIn("EXPECT = 'none'", script)
        self.assertIn("def _physical_request(payload, timeout):", script)

    def test_physical_10_02_and_10_03_enable_tester_present_keepalive(self):
        cases = [
            {
                "case_id": "UDS_0x10_TC_PROGRAMMING_KEEPALIVE",
                "test_point": "进入编程会话",
                "procedure": "请求: 10 02",
                "expected": "正响应",
                "precondition": "扩展会话",
            },
            {
                "case_id": "UDS_0x10_TC_EXTENDED_KEEPALIVE",
                "test_point": "进入扩展会话",
                "procedure": "请求: 10 03",
                "expected": "正响应",
                "precondition": "默认会话",
            },
        ]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads(files["manifest.json"])
        self.assertEqual(
            manifest["cases"][cases[0]["case_id"]]["session_setup_route"],
            [0x03],
            "扩展→编程的 0x10 用例只能先建立源会话，不能提前发送主请求 10 02",
        )
        self.assertEqual(
            manifest["cases"][cases[1]["case_id"]]["session_setup_route"],
            [],
            "默认→扩展的 0x10 用例必须由主请求首次执行 10 03",
        )
        for case in cases:
            meta = manifest["cases"][case["case_id"]]
            self.assertTrue(meta["session_keep_alive"])
            self.assertEqual(meta["keep_alive_interval"], 2.0)
            self.assertEqual(meta["keep_alive_subfunction"], 0x80)
            script = files[meta["script"]]
            self.assertIn("KEEP_ALIVE_REQUIRED = True", script)
            self.assertIn("SessionKeepAlive", script)
            self.assertIn("KEEP_ALIVE_SUBFUNCTION = 128", script)
            self.assertIn("[0x3E, KEEP_ALIVE_SUBFUNCTION]", script)

    def test_session_transition_case_does_not_preexecute_target_session(self):
        case = {
            "case_id": "UDS_0x10_TC_DEFAULT_TO_PROGRAMMING",
            "test_point": "默认会话切换到编程会话",
            "procedure": "测试仪请求：10 02",
            "expected": "正响应：50 02",
            "precondition": "默认会话",
        }
        files, result = run_generator([case])
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads(files["manifest.json"])
        meta = manifest["cases"][case["case_id"]]
        self.assertEqual(meta["session"], "default")
        self.assertEqual(meta["session_setup_route"], [])
        script = files[meta["script"]]
        self.assertIn("SESSION = 'default'", script)
        self.assertIn("PAYLOAD = [16, 2]", script)

    def test_functional_10_03_does_not_inject_physical_keepalive(self):
        cases = [{
            "case_id": "UDS_0x10_TC_FUNCTIONAL_KEEPALIVE",
            "test_point": "功能寻址进入扩展会话",
            "procedure": "测试仪以功能寻址请求：7E 02 10 03 FF FF FF FF；",
            "expected": "功能寻址不应答，仅执行会话切换",
            "precondition": "默认会话",
        }]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads(files["manifest.json"])
        meta = manifest["cases"][cases[0]["case_id"]]
        self.assertFalse(meta["session_keep_alive"])
        self.assertIn("KEEP_ALIVE_REQUIRED = False", files[meta["script"]])

    def test_suppressed_physical_10_02_still_verifies_keepalive(self):
        cases = [{
            "case_id": "UDS_0x10_TC_SUPPRESS_PROGRAMMING_KEEPALIVE",
            "test_point": "进入编程会话并抑制正响应",
            "procedure": "请求: 10 82",
            "expected": "不应答；保持编程会话",
            "precondition": "扩展会话",
        }]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads(files["manifest.json"])
        meta = manifest["cases"][cases[0]["case_id"]]
        self.assertTrue(meta["session_keep_alive"])
        script = files[meta["script"]]
        self.assertIn("suppressed_positive", script)

    def test_programming_precondition_uses_direct_programming_route(self):
        case = {
            "case_id": "UDS_0x22_TC_PROGRAMMING_PRECONDITION",
            "test_point": "编程会话读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "编程会话",
        }
        files, result = run_generator([case])
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads(files["manifest.json"])
        meta = manifest["cases"][case["case_id"]]
        self.assertEqual(meta["session_setup_route"], [0x02])
        self.assertIn("SESSION_SETUP_ROUTE = [2]", files[meta["script"]])

    def test_explicit_session_step_and_f186_expectation_are_preserved(self):
        cases = [{
            "case_id": "UDS_0x10_TC_SESSION_CHECK",
            "test_point": "会话确认",
            "procedure": "1. 请求进入扩展会话；\n2. 测试仪请求：51 03 22 F1 86 FF FF FF；",
            "expected": "DUT正响应：51 04 62 F1 86 03；读 F186 确认当前会话=03",
            "precondition": "默认会话",
        }]
        files, result = run_generator(cases)
        self.assertEqual(result.returncode, 0, result.stderr)
        script = files["case_UDS_0x10_TC_SESSION_CHECK.py"]
        self.assertIn("SESSION = 'extended'", script)
        self.assertIn("VERIFY_SESSION = 3", script)
        self.assertIn("EXPECT_PREFIX = [98, 241, 134, 3]", script)

    def test_suppress_positive_response_is_a_no_response_case_with_session_check(self):
        case = {
            "case_id": "UDS_0x3E_TC_SUPPRESS",
            "test_point": "子功能80抑制正响应",
            "procedure": "测试仪请求：51 02 3E 80 FF FF FF FF",
            "expected": "DUT不发送正响应；会话保持扩展会话",
            "precondition": "扩展会话",
        }
        expect, _, _ = expected_info(case, set())
        self.assertEqual(expect, "none")
        self.assertEqual(expected_session(case["expected"]), 0x03)

    def test_negative_case_accepts_all_documented_nrc_values(self):
        case = {
            "case_id": "UDS_0x2E_TC_ALT_NRC",
            "test_point": "负例（只读 DID）",
            "expected": "DUT负响应：NRC=0x31 或 0x72",
        }
        expect, nrcs, _ = expected_info(case, set())
        self.assertEqual(expect, "neg")
        self.assertEqual(nrcs, [0x31, 0x72])

    def test_negative_case_extracts_nrc_from_raw_response_frame(self):
        case = {
            "case_id": "UDS_0x2E_TC_RAW_NRC",
            "test_point": "负例（当前会话不支持写入）",
            "expected": "DUT负响应：7F 2E 7F（serviceNotSupportedInActiveSession）或 0x13",
        }
        expect, nrcs, _ = expected_info(case, set())
        self.assertEqual(expect, "neg")
        self.assertEqual(nrcs, [0x13, 0x7F])

    def test_version_dependent_payload_is_protocol_checked_not_exactly_asserted(self):
        case = {
            "case_id": "UDS_0x22_TC_VERSION",
            "test_point": "读取软件零件号",
            "expected": "DUT正响应：51 xx 62 F1 25 80 05 86 38",
        }
        self.assertEqual(response_check_level(case, [0x62, 0xF1, 0x25]), "protocol")

    def test_fixed_byte_rule_keeps_exact_assertion(self):
        case = {
            "case_id": "UDS_0x22_TC_FIXED",
            "test_point": "读取状态",
            "expected": "DUT正响应：62 D0 9B 01 05 01；Byte0=等级数01",
        }
        self.assertEqual(response_check_level(case, [0x62, 0xD0, 0x9B]), "exact")

    def test_explicit_exclude_service_generates_skip_without_runtime_access(self):
        cases = [{
            "case_id": "UDS_0x27_TC_EXCLUDED",
            "test_point": "请求 Seed",
            "procedure": "请求：27 05",
            "expected": "正响应",
            "precondition": "扩展会话",
        }]
        with WorkspaceTempDir("gen") as td:
            cases_path = os.path.join(td, "cases.json")
            parsed_path = os.path.join(td, "parsed.json")
            out_dir = os.path.join(td, "out")
            with open(cases_path, "w", encoding="utf-8") as f:
                json.dump({"cases": cases}, f, ensure_ascii=False)
            with open(parsed_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            result = subprocess.run(
                [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
                 "--out-dir", out_dir, "--exclude-service", "0x27"],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            with open(os.path.join(out_dir, "manifest.json"), encoding="utf-8") as handle:
                manifest = json.load(handle)
            self.assertEqual(manifest["cases"]["UDS_0x27_TC_EXCLUDED"]["status"], "skip")

    def test_routine_result_includes_explicit_start_prerequisite(self):
        case = {
            "case_id": "UDS_0x31_TC_RESULT",
            "procedure": "1. 扩展会话；\n2. 先启动 RID 0206；\n3. 请求例程结果。",
        }
        self.assertEqual(
            routine_prerequisites(case, [0x31, 0x03, 0x02, 0x06]),
            [[0x31, 0x01, 0x02, 0x06]],
        )

    def test_routine_prerequisite_matrix_has_priority_over_text(self):
        case = {"procedure": "请求例程结果。"}
        matrix = {"0206": {"start_payload": [0x31, 0x01, 0x02, 0x06], "two_step": True}}
        self.assertEqual(
            routine_prerequisites_from_matrix(case, [0x31, 0x03, 0x02, 0x06], matrix),
            [[0x31, 0x01, 0x02, 0x06]],
        )

    def test_reason_with_quotes_is_not_double_escaped(self):
        """🔴-01 回归：REASON 渲染只经 {reason!r} 一次转义，含引号不失真。

        生成器曾在 {reason!r} 前手动 replace 引号造成双重转义（生成脚本中
        REASON 实际值带字面反斜杠）。当前 reason 数据源不含引号故未触发，
        本条锁定渲染契约与源码契约，防止未来数据源变化时复发。
        """
        import inspect

        import gen_case_scripts as g

        # 渲染契约：模板对 reason 使用 !r（repr 已安全处理引号/反斜杠）
        rendered = "{!r}".format("It's a \"quoted\" reason")
        self.assertEqual(eval(rendered), "It's a \"quoted\" reason")
        # 源码契约：生成器不得在模板渲染前手动 replace 引号
        self.assertNotIn('reason.replace("', inspect.getsource(g))

    def test_template_fields_cover_all_generation_arguments(self):
        """🟡-05 回归：template_fields() 占位符与真实生成路径传参一致。

        main() 生成前会校验占位符齐全（缺失即 exit 1），真实生成成功
        即证明 SCRIPT_TPL 无漏填占位符；本条同时锁定关键占位符存在性。
        """
        import gen_case_scripts as g

        fields = g.template_fields()
        for key in ("case_id", "reason", "payload", "session", "expect", "status", "executable"):
            self.assertIn(key, fields)
        files, result = run_generator([{
            "case_id": "UDS_0x10_TC_TPL",
            "test_point": "进入扩展会话",
            "procedure": "请求: 10 03",
            "expected": "正响应",
            "precondition": "默认会话",
        }])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("case_UDS_0x10_TC_TPL.py", files)


def run_run_all(cases, mutate=None, bus="can", before_run=None):
    """生成脚本 → 可选注入崩溃 → 运行 run_all 冒烟汇总。

    返回 (gen_rc, run_all_result, results_by_id)。run_all 是执行阶段的冒烟汇总：
    脚本异常（非 0 退出码）必须记 FAIL，只有脚本自写的真实前置受限才允许 BLOCKED。
    """
    with WorkspaceTempDir("run_all") as td:
        cases_path = os.path.join(td, "cases.json")
        parsed_path = os.path.join(td, "parsed.json")
        out_dir = os.path.join(td, "out")
        with open(cases_path, "w", encoding="utf-8") as f:
            json.dump({"cases": cases}, f, ensure_ascii=False)
        with open(parsed_path, "w", encoding="utf-8") as f:
            json.dump({}, f)
        generated = subprocess.run(
            [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
             "--bus", bus, "--out-dir", out_dir, "--confirmed"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        if mutate:
            for name in os.listdir(out_dir):
                if not name.startswith("case_"):
                    continue
                path = os.path.join(out_dir, name)
                with open(path, encoding="utf-8") as f:
                    text = f.read()
                changed = mutate(text, name)
                if changed is not None and changed != text:
                    with open(path, "w", encoding="utf-8") as f:
                        f.write(changed)
        if before_run:
            before_run(out_dir)
        run_all_result = subprocess.run(
            [sys.executable, os.path.join(out_dir, "run_all.py")],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        results = {}
        results_all = os.path.join(out_dir, "results_all.json")
        if os.path.isfile(results_all):
            with open(results_all, encoding="utf-8", errors="replace") as f:
                data = json.load(f)
            results = {item["case_id"]: item for item in data.get("results", [])}
        return generated.returncode, run_all_result, results


def inject_after_timing_runner(text, body):
    # 注入点：run_timing_case(...) 调用之后、_VERDICT 退出码同步之前。
    marker = "        )\n        # 时序 runner"
    if marker not in text:
        raise AssertionError("generated timing branch marker not found")
    return text.replace(marker, "        )\n" + body + "\n        # 时序 runner", 1)


class TestLinTraceRunAllIntegrity(unittest.TestCase):
    def test_executed_lin_case_without_trace_is_fail(self):
        case = {
            "case_id": "UDS_0x22_TC_TRACE_MISSING",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 86",
            "expected": "正响应",
            "precondition": "默认会话",
        }

        def remove_trace(text, name):
            if name != "case_UDS_0x22_TC_TRACE_MISSING.py":
                return text
            marker = 'if __name__ == "__main__":\n    try:\n        main()'
            replacement = ('if __name__ == "__main__":\n'
                           '    try:\n'
                           '        _write("PASS", "synthetic", "")\n'
                           '        os.remove(TRACE_RESULT)')
            self.assertIn(marker, text)
            return text.replace(marker, replacement, 1)

        gen_rc, run_all, results = run_run_all([case], mutate=remove_trace, bus="lin")
        self.assertEqual(gen_rc, 0)
        self.assertNotEqual(run_all.returncode, 0)
        item = results[case["case_id"]]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertIn("独立 LIN trace 文件不存在", item.get("note", ""))


class TestTimingRunAllIntegrity(unittest.TestCase):
    CASE = {
        "case_id": "UDS_TimeParm_TC_0007",
        "test_point": "BS/STmin 时序采集",
        "procedure": "请求: 22 F1 86（响应为多帧时解析 BS/STmin）",
        "expected": "BS=0，STmin=0ms",
        "precondition": "默认会话",
    }

    def test_fifteen_timeparm_cases_each_emit_fail_and_private_evidence_without_skip(self):
        cases = []
        for index in range(1, 16):
            cases.append({
                "case_id": f"UDS_TimeParm_TC_{index:04d}",
                "test_point": "时序测量",
                "procedure": "请求: 22 F1 86",
                "expected": "独立采集并按专属指标判定",
                "precondition": "默认会话",
            })
        gen_rc, run_all, results = run_run_all(cases)
        self.assertEqual(gen_rc, 0)
        self.assertNotEqual(run_all.returncode, 0)
        self.assertEqual(set(results), {c["case_id"] for c in cases})
        self.assertEqual(len(results), 15)
        for case in cases:
            item = results[case["case_id"]]
            self.assertEqual(item["verdict"], "FAIL")
            self.assertNotIn("SKIP", json.dumps(item, ensure_ascii=False))
            self.assertTrue(item.get("timing_metric"))
            self.assertTrue(item.get("timing_spec", {}).get("case_id") == case["case_id"])
            self.assertTrue(item.get("evidence", "").endswith(".trace.json"))

    def test_plain_p2_result_cannot_cover_bs_stmin(self):
        def mutate(text, name):
            if name != "case_UDS_TimeParm_TC_0007.py":
                return text
            body = '''        with open(RESULT, encoding="utf-8") as f:
            item = json.load(f)
        item["service"] = "0x22"
        item["expect"] = "pos"
        item.pop("timing_metric", None)
        item.pop("timing_spec", None)
        item.pop("evidence", None)
        with open(RESULT, "w", encoding="utf-8") as f:
            json.dump(item, f)'''
            return inject_after_timing_runner(text, body)

        _, run_all, results = run_run_all([self.CASE], mutate=mutate)
        item = results[self.CASE["case_id"]]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertIn("时序证据完整性失败", item.get("note", ""))
        self.assertNotEqual(run_all.returncode, 0)

    def test_timing_skip_is_fail_but_normal_skip_remains_available(self):
        def mutate(text, name):
            if name != "case_UDS_TimeParm_TC_0007.py":
                return text
            body = '''        with open(RESULT, encoding="utf-8") as f:
            item = json.load(f)
        item["verdict"] = "SKIP"
        with open(RESULT, "w", encoding="utf-8") as f:
            json.dump(item, f)'''
            return inject_after_timing_runner(text, body)

        _, run_all, results = run_run_all([self.CASE], mutate=mutate)
        item = results[self.CASE["case_id"]]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertIn("不允许 SKIP", item.get("note", ""))
        self.assertNotEqual(run_all.returncode, 0)

    def test_missing_trace_is_fail(self):
        def mutate(text, name):
            if name != "case_UDS_TimeParm_TC_0007.py":
                return text
            return inject_after_timing_runner(
                text, '        os.remove(os.path.splitext(RESULT)[0] + ".trace.json")')

        _, run_all, results = run_run_all([self.CASE], mutate=mutate)
        item = results[self.CASE["case_id"]]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertIn("独立 trace 文件不存在", item.get("note", ""))
        self.assertNotEqual(run_all.returncode, 0)

    def test_timing_spec_drift_is_fail(self):
        def mutate(text, name):
            if name != "case_UDS_TimeParm_TC_0007.py":
                return text
            body = '''        with open(RESULT, encoding="utf-8") as f:
            item = json.load(f)
        item["timing_spec"]["metric"] = "p2"
        with open(RESULT, "w", encoding="utf-8") as f:
            json.dump(item, f)'''
            return inject_after_timing_runner(text, body)

        _, run_all, results = run_run_all([self.CASE], mutate=mutate)
        item = results[self.CASE["case_id"]]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertIn("设计基线不一致", item.get("note", ""))
        self.assertNotEqual(run_all.returncode, 0)

    def test_bs_stmin_trace_replaced_by_plain_p2_measurement_is_fail(self):
        def mutate(text, name):
            if name != "case_UDS_TimeParm_TC_0007.py":
                return text
            body = '''        trace_path = os.path.splitext(RESULT)[0] + ".trace.json"
        with open(trace_path, encoding="utf-8") as f:
            trace_item = json.load(f)
        trace_item["measurement"] = {
            "p2_ms": [1.0],
            "traces": [{"direction": "TX", "frame_id": 0x3C}],
        }
        with open(trace_path, "w", encoding="utf-8") as f:
            json.dump(trace_item, f)'''
            return inject_after_timing_runner(text, body)

        _, run_all, results = run_run_all([self.CASE], mutate=mutate)
        item = results[self.CASE["case_id"]]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertIn("BS/STmin", item.get("note", ""))
        self.assertNotEqual(run_all.returncode, 0)

    def test_stale_result_is_deleted_before_a_failed_script_can_run(self):
        cid = self.CASE["case_id"]

        def mutate(text, name):
            if name != "case_UDS_TimeParm_TC_0007.py":
                return text
            return text.replace(
                "import json, os, sys, time",
                "import json, os, sys, time\nraise RuntimeError(\"boom-before-result\")",
                1,
            )

        def seed_stale(out_dir):
            result_dir = os.path.join(out_dir, "results")
            os.makedirs(result_dir, exist_ok=True)
            with open(os.path.join(result_dir, cid + ".json"), "w", encoding="utf-8") as f:
                json.dump({"case_id": cid, "verdict": "PASS"}, f)
            with open(os.path.join(result_dir, cid + ".trace.json"), "w", encoding="utf-8") as f:
                json.dump({"case_id": cid, "metric": "bs_stmin", "measurement": {}}, f)

        _, run_all, results = run_run_all([self.CASE], mutate=mutate, before_run=seed_stale)
        item = results[cid]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertIn("脚本异常退出", item.get("actual", ""))
        self.assertNotEqual(run_all.returncode, 0)

    def test_stale_cleanup_failure_degrades_to_rename(self):
        """清理 stale 被拦截（os.remove 失败）时降级为改名隔离，不阻断执行。

        DLP 加密目录下 os.remove 会被安全删除拦截（实测 2026-08-28，
        SAFE_DELETE_FAIL_CLOSED），生成器 run_all 模板对清理失败降级为
        os.rename；此处用"stale 位置放目录"模拟 os.remove 失败
        （IsADirectoryError，跨环境可测），验证降级路径不 FAIL。
        """
        cid = self.CASE["case_id"]

        def seed_stale_as_dir(out_dir):
            result_dir = os.path.join(out_dir, "results")
            os.makedirs(result_dir, exist_ok=True)
            os.makedirs(os.path.join(result_dir, cid + ".json"), exist_ok=False)
            os.makedirs(os.path.join(result_dir, cid + ".trace.json"), exist_ok=False)

        _, run_all, results = run_run_all([self.CASE], before_run=seed_stale_as_dir)
        item = results[cid]
        self.assertIn(cid, results)
        self.assertNotIn("无法清理旧结果", item.get("note", ""))

    def test_timing_script_crash_keeps_per_case_metadata_for_report(self):
        def crash_before_result(text, name):
            if name != "case_UDS_TimeParm_TC_0007.py":
                return text
            return text.replace(
                "    try:\n        main()\n    except Exception as exc:",
                "    try:\n        raise RuntimeError(\"boom-before-result\")\n    except Exception as exc:",
                1,
            )

        _, run_all, results = run_run_all([self.CASE], mutate=crash_before_result)
        item = results[self.CASE["case_id"]]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertEqual(item["service"], "TimeParm")
        self.assertEqual(item["expect"], "timing")
        self.assertEqual(item["timing_spec"]["case_id"], self.CASE["case_id"])
        self.assertTrue(item["evidence"].endswith(".trace.json"))
        self.assertNotEqual(run_all.returncode, 0)


class TestRunAllSmokeExitCode(unittest.TestCase):
    """run_all 冒烟汇总必须检查子进程退出码：脚本异常是 FAIL，不是 BLOCKED。"""

    CASE = {
        "case_id": "UDS_0x22_TC_A",
        "test_point": "读取 DID",
        "procedure": "请求: 22 F1 90",
        "expected": "正响应",
        "precondition": "默认会话",
    }

    def test_crash_after_write_is_error_not_blocked(self):
        # 脚本写完结果后崩溃（main() 返回后模块级 raise）：退出码非 0，
        # 即使结果文件已存在也必须记 ERROR，不得采用结果文件里的旧 verdict。
        def crash_after_write(text, name):
            return text.replace(
                "    try:\n        main()\n    except Exception as exc:",
                "    try:\n        main()\n        raise RuntimeError(\"boom-after-write\")\n    except Exception as exc:",
            )

        gen_rc, run_all, results = run_run_all([self.CASE], mutate=crash_after_write)
        self.assertEqual(gen_rc, 0, run_all.stdout)
        item = results.get("UDS_0x22_TC_A", {})
        self.assertEqual(item.get("verdict"), "FAIL", run_all.stdout)
        self.assertIn("脚本异常退出", str(item.get("actual", "")))
        self.assertNotEqual(run_all.returncode, 0)

    def test_crash_before_write_is_error_not_blocked(self):
        # 模块级崩溃：无结果文件，必须记 ERROR（脚本缺陷），不是 BLOCKED（前置受限）。
        def crash_at_import(text, name):
            return text.replace(
                "import json, os, sys, time",
                "import json, os, sys, time\nraise RuntimeError(\"boom-at-import\")",
            )

        gen_rc, run_all, results = run_run_all([self.CASE], mutate=crash_at_import)
        self.assertEqual(gen_rc, 0, run_all.stdout)
        item = results.get("UDS_0x22_TC_A", {})
        self.assertEqual(item.get("verdict"), "FAIL", run_all.stdout)
        self.assertNotEqual(run_all.returncode, 0)

    def test_true_blocked_reason_stays_blocked(self):
        # 真实前置受限（CAN 运行时未提供，脚本自写 BLOCKED）必须保留 BLOCKED，
        # 且不计入失败（run_all 退出码 0）。
        gen_rc, run_all, results = run_run_all([self.CASE])
        self.assertEqual(gen_rc, 0, run_all.stdout)
        item = results.get("UDS_0x22_TC_A", {})
        self.assertEqual(item.get("verdict"), "BLOCKED", run_all.stdout)
        self.assertEqual(run_all.returncode, 0, run_all.stdout)

    def test_explicit_skip_written_by_a_case_is_preserved(self):
        def write_legacy_skip(text, name):
            return text.replace('_write("BLOCKED",', '_write("SKIP",', 1)

        gen_rc, run_all, results = run_run_all([self.CASE], mutate=write_legacy_skip)
        self.assertEqual(gen_rc, 0, run_all.stdout)
        item = results.get("UDS_0x22_TC_A", {})
        self.assertEqual(item.get("verdict"), "SKIP", run_all.stdout)
        self.assertIn("SKIP", json.dumps(item, ensure_ascii=False))
        self.assertEqual(run_all.returncode, 0, run_all.stdout)


class TestZeroPaddingNeedsData(unittest.TestCase):
    """自动补零的推断业务数据必须标记 needs_data，禁止直接进入硬件执行（OP-01）。"""

    def test_explicit_length_padding_is_needs_data(self):
        payload, status, _ = request_payload(
            "请求：2E D0 3A + 32字节数据",
            "can", 0x51,
        )
        self.assertEqual(status, "needs_data")
        self.assertEqual(len(payload or []), 35)

    def test_lin_ellipsis_length_padding_is_needs_data(self):
        payload, status, _ = request_payload(
            "测试仪请求：51 24 2E F1 0A 00 00 ...（34字节）",
            "lin", 0x51,
        )
        self.assertEqual(status, "needs_data")

    def test_routine_param_shortfall_is_needs_data(self):
        payload, status, _ = request_payload(
            "请求：31 01 02 06",
            "can", 0x51, {"0206": 4},
        )
        self.assertEqual(status, "needs_data")

    def test_routine_param_padding_is_needs_data(self):
        payload, status, _ = request_payload(
            "请求：31 01 02 06 + 参数",
            "can", 0x51, {"0206": 4},
        )
        self.assertEqual(status, "needs_data")


class TestResultStatusBoundary(unittest.TestCase):
    def test_uds_runtime_result_object_normalizes_legacy_statuses(self):
        # uds_test_generator.py 的完整运行时位于模板字符串中，不能直接 import
        # 为模块级 TestResult；静态检查模板内容，确保最终生成脚本仍有对象级边界。
        runtime = os.path.join(HERE, "uds_test_generator.py")
        with open(runtime, encoding="utf-8") as handle:
            source = handle.read()
        # B1 Phase1: 模板已拆分至 script_header_template.py，断言需同时覆盖模板源文本
        with open(os.path.join(HERE, "script_header_template.py"), encoding="utf-8") as handle:
            source += handle.read()
        self.assertIn('raw_status = str(status or "FAIL").upper()', source)
        # SCRIPT_HEADER is formatted with str.format(); braces in the
        # generated runtime must therefore be escaped in the template and
        # become single braces in the emitted script.
        self.assertIn('if raw_status not in {{"PASS", "FAIL", "BLOCKED", "NA", "SKIP"}}', source)
        self.assertIn('if raw_status == "ERROR"', source)


class TestSingleCaseExitCodeContract(unittest.TestCase):
    """P1-1：单用例脚本退出码契约（FAIL=1、异常=2、其余=0），直接运行也可信。"""

    def _generate(self, case_id="UDS_0x22_TC_EXIT"):
        td = WorkspaceTempDir("gen-exit")
        self.addCleanup(td.cleanup)
        cases_path = os.path.join(td.name, "cases.json")
        parsed_path = os.path.join(td.name, "parsed.json")
        out_dir = os.path.join(td.name, "out")
        with open(cases_path, "w", encoding="utf-8") as f:
            json.dump({"cases": [{
                "case_id": case_id,
                "test_point": "读取 DID",
                "procedure": "请求: 22 F1 90",
                "expected": "正响应",
                "precondition": "默认会话",
            }]}, f, ensure_ascii=False)
        with open(parsed_path, "w", encoding="utf-8") as f:
            json.dump({}, f)
        generated = subprocess.run(
            [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
             "--bus", "can", "--out-dir", out_dir, "--confirmed"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script_path = os.path.join(out_dir, "case_%s.py" % case_id)
        with open(script_path, encoding="utf-8") as f:
            text = f.read()
        return script_path, text

    def test_template_embeds_exit_code_contract(self):
        _, text = self._generate()
        self.assertIn("_VERDICT = None", text)
        self.assertIn('sys.exit(1 if _VERDICT == "FAIL" else 0)', text)
        self.assertIn("sys.exit(2)", text)

    def test_fail_verdict_exits_one_without_hardware(self):
        # 非法 STATUS 分支确定性写 FAIL，不连接硬件；退出码必须为 1。
        script_path, text = self._generate()
        self.assertIn("STATUS = 'pos'", text)
        text = text.replace("STATUS = 'pos'", "STATUS = 'invalid_status'")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(text)
        run = subprocess.run([sys.executable, script_path], capture_output=True, text=True,
                             encoding="utf-8", errors="replace")
        self.assertEqual(run.returncode, 1, run.stdout + run.stderr)
        result_path = os.path.join(os.path.dirname(script_path), "results", "UDS_0x22_TC_EXIT.json")
        with open(result_path, encoding="utf-8") as f:
            item = json.load(f)
        self.assertEqual(item["verdict"], "FAIL")

    def test_blocked_verdict_exits_zero(self):
        # BLOCKED（前置受限）不是脚本失败，退出码必须为 0。
        script_path, text = self._generate()
        text = text.replace("STATUS = 'pos'", "STATUS = 'blocked'")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(text)
        run = subprocess.run([sys.executable, script_path], capture_output=True, text=True,
                             encoding="utf-8", errors="replace")
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        result_path = os.path.join(os.path.dirname(script_path), "results", "UDS_0x22_TC_EXIT.json")
        with open(result_path, encoding="utf-8") as f:
            item = json.load(f)
        self.assertEqual(item["verdict"], "BLOCKED")

    def test_caught_exception_exits_two(self):
        # 模板兜底捕获的异常（写 FAIL 证据后）退出码必须为 2，与判定 FAIL(1) 区分。
        script_path, text = self._generate()
        text = text.replace(
            "    try:\n        main()\n    except Exception as exc:",
            "    try:\n        main()\n        raise RuntimeError('boom')\n    except Exception as exc:",
        )
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(text)
        run = subprocess.run([sys.executable, script_path], capture_output=True, text=True,
                             encoding="utf-8", errors="replace")
        self.assertEqual(run.returncode, 2, run.stdout + run.stderr)


class TestAnnotatedRequestLineParsing(unittest.TestCase):
    """2026-09-03 生成器修复：0x 标注/注释与请求帧同行的混合行不再整行
    解析失败（needs_data"无法解析 hex"），与审查层 payload_candidates
    同口径清洗提取。"""

    def _payload(self, procedure, bus="can", hint=None):
        payload, status, _reason = request_payload(procedure, bus, 0x51, service_hint=hint)
        return payload, status

    def test_frame_with_did_annotation_is_executable(self):
        payload, status = self._payload("请求: 22 F1 90（DID 0xF190 车架号 VIN）", hint="0x22")
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x22, 0xF1, 0x90])

    def test_session_annotation_mixed_line_is_executable(self):
        payload, status = self._payload("在扩展会话(0x03)下请求: 22 F1 90", hint="0x22")
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x22, 0xF1, 0x90])

    def test_lin_frame_with_trailing_annotation(self):
        payload, status = self._payload(
            "51 02 10 03 FF FF FF FF (0x10 03 扩展会话)", bus="lin", hint="0x10")
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x10, 0x03])

    def test_single_service_byte_never_becomes_bad_frame(self):
        # "发送 0x22 读取 DID F190" 只有一个服务字节：宁可 needs_data（不硬造），
        # 也不得产出 [0x22] 截断报文（防退化）。
        payload, status = self._payload("发送 0x22 读取 DID F190", hint="0x22")
        self.assertEqual(status, "needs_data", payload)
        self.assertNotEqual(payload, [0x22])

    def test_plain_frame_line_regression(self):
        payload, status = self._payload("请求: 22 F1 90", hint="0x22")
        self.assertEqual(status, "executable")
        self.assertEqual(payload, [0x22, 0xF1, 0x90])

    def test_annotated_line_end_to_end_script_is_executable(self):
        files, result = run_generator([{
            "case_id": "UDS_0x22_TC_ANNOT",
            "test_point": "读取 VIN",
            "procedure": "请求: 22 F1 90（DID 0xF190 车架号 VIN）",
            "expected": "正响应",
            "precondition": "默认会话",
        }])
        self.assertEqual(result.returncode, 0, result.stderr)
        script = files.get("case_UDS_0x22_TC_ANNOT.py", "")
        self.assertIn("PAYLOAD = [34, 241, 144]", script)
        self.assertIn("EXECUTABLE = True", script)
        self.assertNotIn("STATUS = 'needs_data'", script)


if __name__ == "__main__":
    unittest.main(verbosity=2)
