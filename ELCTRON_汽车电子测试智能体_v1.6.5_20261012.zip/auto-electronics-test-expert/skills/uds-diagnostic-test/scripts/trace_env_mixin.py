#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""trace_env_mixin.py — ASC 证据链自动落盘编排（通用 Mixin，v3.9 定稿口径）

把「open 时开逐帧捕获 / close 时自动落盘 trace JSON + ASC」的编排固化为可复用组件。
任何持有 `self.uds`（f1l1_uds.F1L1UDS 或提供 _trace_capture 协议的驱动实例）的
环境封装类，混入本类即可获得零手工证据产出能力——不绑定任何项目。

可移植性：
  - 仅依赖同目录 asc_evidence.py（其校验和有内置 fallback，单文件亦可独立）；
  - 不 import 项目侧任何模块；case_id / 输出目录 / 波特率全部参数化。

用法（宿主环境封装类）:

    from trace_env_mixin import EvidenceTraceMixin

    class MyEnv(EvidenceTraceMixin):
        def __init__(self, case_id):
            self.case_id = case_id
            ...
        def open(self):
            ok = ...  # 打开通道、构造 self.uds
            self.trace_begin()          # open 成功后调用：启用捕获 + 墙钟锚点
            return ok
        def close(self):
            self.trace_flush(result_file="results/result_%s.json" % self.case_id)
            ...                         # 关闭通道等收尾

自测（离线，无需硬件）:
    python trace_env_mixin.py
"""
import time
from pathlib import Path

try:
    from asc_evidence import LiveAscRecorder, save_case_evidence
except Exception:  # 直接以脚本方式从其它目录调用时兜底
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from asc_evidence import LiveAscRecorder, save_case_evidence


class EvidenceTraceMixin:
    """ASC 证据自动采集编排混入类。

    宿主约定：
      - self.uds      : F1L1UDS 实例（具备 _trace_capture 协议）—— trace_begin 前就绪；
      - self.case_id  : 用例号（如 "TG24_TC1"）；
      - self.steps    : 可选，list —— 落盘结果/异常会追加为一条记录（没有则忽略）。
    """

    def trace_begin(self, case_id=None, *, live_asc=True, out_dir="results",
                    brval=19200, channel="CANview-F1L1", session_id=None,
                    part_max_bytes=100 * 1024 * 1024):
        """启用逐帧捕获，并默认实时追加 ASC（100 MiB 自动分片）。"""
        self.case_id = case_id or getattr(self, "case_id", "UNKNOWN")
        self._trace_frames = None
        self._trace_wall0 = None
        self._live_asc = None
        uds = getattr(self, "uds", None)
        if uds is None or not hasattr(uds, "_trace_capture"):
            return False                       # 无捕获协议的驱动：静默降级（不阻塞测试）
        uds._trace_capture = []                # f1l1_uds._record_trace 由此开始记录
        self._trace_frames = uds._trace_capture
        self._trace_wall0 = time.time()
        if live_asc:
            recorder = LiveAscRecorder(
                self.case_id, out_dir=out_dir, brval=brval, channel=channel,
                wall0=self._trace_wall0, session_id=session_id,
                part_max_bytes=part_max_bytes,
            )
            uds._trace_live_sink = recorder.record
            self._live_asc = recorder
        return True

    def trace_flush(self, out_dir="results", brval=19200, result_file=None, channel="CANview-F1L1"):
        """落盘 trace JSON + ASC。close() 收尾时调用；空轨迹跳过，异常不吞宿主状态。

        返回 save_case_evidence 的结果 dict；无捕获/无帧返回 None。
        """
        frames = getattr(self, "_trace_frames", None)
        recorder = getattr(self, "_live_asc", None)
        try:
            r = None
            if frames:
                r = save_case_evidence(
                    getattr(self, "case_id", "UNKNOWN"), frames,
                    wall0=getattr(self, "_trace_wall0", None),
                    out_dir=out_dir, brval=brval, channel=channel, result_file=result_file)
            live = recorder.close(result_file=result_file) if recorder else None
            if r is None and live is None:
                return None
            if r is None:
                r = {"trace": None, "asc": None, "frames": 0}
            if live:
                r["live_asc"] = live
            live_error = getattr(getattr(self, "uds", None), "_trace_live_error", None)
            if live_error:
                r["live_asc_error"] = live_error
            if r and isinstance(getattr(self, "steps", None), list):
                self.steps.append("证据 | trace+ASC 自动落盘 %d 帧 -> %s" % (r["frames"], r["asc"]))
                if live:
                    self.steps.append("证据 | 实时 ASC %d 帧/%d 分片 -> %s" % (
                        live["frames"], len(live["parts"]), live["directory"]))
                if live_error:
                    self.steps.append("证据 | 实时 ASC 写入异常: %s" % live_error)
            return r
        except Exception as e:                 # 取证失败不得吞掉用例本身的状态
            if isinstance(getattr(self, "steps", None), list):
                self.steps.append("证据 | 自动落盘异常: %r" % (e,))
            return None
        finally:
            uds = getattr(self, "uds", None)
            if uds is not None and hasattr(uds, "_trace_capture"):
                uds._trace_capture = None      # 复位，防下一用例误续写
            if uds is not None and hasattr(uds, "_trace_live_sink"):
                uds._trace_live_sink = None
            if uds is not None and hasattr(uds, "_trace_live_error"):
                uds._trace_live_error = None
            self._live_asc = None


if __name__ == "__main__":
    # ---- 离线自测：假 uds 对象 + 参考样例帧，验证 begin/record/flush 全链 ----
    import json
    from testsupport import WorkspaceTempDir

    class FakeUDS:
        _trace_capture = None

        def _record_trace(self, direction, frame_id, data, timestamp=None):
            if self._trace_capture is None:
                return
            if timestamp is None:
                raise ValueError("无有效硬件时间戳，拒绝记录（真实性硬保证）")
            event = (timestamp, direction, frame_id, list(data))
            self._trace_capture.append(event)
            sink = getattr(self, "_trace_live_sink", None)
            if sink:
                sink(event)

    class Env(EvidenceTraceMixin):
        def __init__(self, case_id):
            self.case_id = case_id
            self.uds = FakeUDS()
            self.steps = []

    workspace = WorkspaceTempDir("trace-env-selftest")
    out = workspace.name
    env = Env("SELFTEST")
    assert env.trace_begin(out_dir=out) is True
    env.uds._record_trace("TX", 0x3C, [0x51, 0x02, 0x10, 0x01, 0xFF, 0xFF, 0xFF, 0xFF], 2.207066)
    env.uds._record_trace("RX", 0x3D, [0x51, 0x06, 0x50, 0x01, 0x00, 0x32, 0x01, 0xF4], 2.222516)
    r = env.trace_flush(out_dir=out)
    assert r and r["frames"] == 2
    asc = Path(r["asc"]).read_text(encoding="utf-8")
    assert "checksum = 9b" in asc and "checksum = 2f" in asc and "Li Li" not in asc
    assert any("证据" in s for s in env.steps)
    assert r["live_asc"]["frames"] == 2
    # 空轨迹：不落盘
    env2 = Env("EMPTY")
    env2.trace_begin()
    assert env2.trace_flush(out_dir=out) is None
    # 无捕获协议驱动：静默降级
    class BareEnv(EvidenceTraceMixin):
        case_id = "BARE"
    assert BareEnv().trace_begin() is False
    workspace.cleanup()
    print("SELFTEST OK: 2帧落盘+校验和9b/2f+steps登记+空轨迹跳过+无协议降级")
    print(json.dumps(r, ensure_ascii=False))
