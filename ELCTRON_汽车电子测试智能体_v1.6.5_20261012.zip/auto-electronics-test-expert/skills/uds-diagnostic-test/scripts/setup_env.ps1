# UDS Diagnostic Test Skill - Windows/Vector 环境安装脚本
# 用法: powershell -ExecutionPolicy Bypass -File .\scripts\setup_env.ps1

$ErrorActionPreference = "Stop"

$SkillDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$VenvDir = Join-Path $env:USERPROFILE ".uds_venv"
$WorkDir = Join-Path $env:USERPROFILE ".uds_workspace"
$EnvFile = Join-Path $env:USERPROFILE ".uds_env"

function Write-Step([string]$msg) {
    Write-Host "[setup_env] $msg"
}

# 1. 选择 64 位 Python
$python = $null
foreach ($cand in @((Get-Command py -ErrorAction SilentlyContinue), (Get-Command python -ErrorAction SilentlyContinue))) {
    if (-not $cand) { continue }
    $probe = & $cand.Source -c "import struct,sys; print(struct.calcsize('P')*8); print(sys.executable)" 2>$null
    if ($LASTEXITCODE -eq 0 -and $probe) {
        $bits = ($probe -split "`n")[0].Trim()
        if ($bits -eq "64") { $python = $cand.Source; break }
    }
}
if (-not $python) {
    Write-Host "[ERROR] 未找到 64 位 Python。请安装 Python 3.10+ (x64) 后重试。" -ForegroundColor Red
    exit 1
}
Write-Step "使用 Python: $python"

# 2. 创建虚拟环境
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    Write-Step "创建虚拟环境: $VenvDir"
    & $python -m venv $VenvDir
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERROR] venv 创建失败" -ForegroundColor Red
        exit 1
    }
}
Write-Step "虚拟环境 Python: $VenvPython"

# 3. 安装依赖 (python-can / openpyxl)
$req = Join-Path $SkillDir "requirements.txt"
Write-Step "安装依赖（按 requirements.txt：python-can / openpyxl / cryptography / cantools / pymupdf / pywin32）"
& $VenvPython -m pip install --disable-pip-version-check -r $req
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] pip 安装失败。若出现 can-0.0.0 或 python-can 1.5.x，属包源/镜像问题，请停止重试并检查 pip 源。" -ForegroundColor Red
    exit 1
}

# 4. 校验 python-can 与 Vector 后端
Write-Step "校验 python-can / Vector 后端..."
$check = & $VenvPython -c "import can, importlib.metadata as md; print('python-can', md.version('python-can')); import can.interfaces.vector; print('vector backend OK')" 2>&1
Write-Step ($check | Out-String).Trim()
if ($LASTEXITCODE -ne 0) {
    Write-Host "[WARN] Vector 后端校验失败。请安装 Vector Driver Setup (XL Driver Library, vxlapi64.dll)，并确认 Python 为 64 位。" -ForegroundColor Yellow
}

# 5. 写入环境文件 (key=value 格式, 供 uds_runner.py 复用)
New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
@(
    "UDS_PYTHON=$VenvPython",
    "UDS_SKILL_DIR=$SkillDir",
    "UDS_WORK=$WorkDir"
) | Set-Content -Path $EnvFile -Encoding Ascii
Write-Step "环境文件: $EnvFile"
Write-Step "工作目录: $WorkDir"
# 6. 可选能力校验 (PyMuPDF / pywin32)：srs-doc-extract 的加密 PDF 深解析通道
$optional = & $VenvPython -c "import importlib.util as u; print('fitz=%s' % bool(u.find_spec('fitz'))); print('win32com=%s' % bool(u.find_spec('win32com')))" 2>&1
Write-Step ("可选能力: " + (($optional | Out-String).Trim() -replace "`r?`n", " "))
if (($optional | Out-String) -match "False") {
    Write-Host "[WARN] 缺少 fitz/pywin32：加密 PDF 深解析（srs-doc-extract）会 ImportError。二者已列在 requirements.txt，请重跑本脚本安装。" -ForegroundColor Yellow
}

Write-Host "[OK] 环境准备完成。执行测试前请确认 VN1630A 已连接，且 CANoe / VickCAN 未占用通道。" -ForegroundColor Green
