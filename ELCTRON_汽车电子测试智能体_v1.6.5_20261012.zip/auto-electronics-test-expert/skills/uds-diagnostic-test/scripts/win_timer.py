#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Windows 高精度定时共享助手（跨脚本单一实现）
=========================================================================
timeBeginPeriod 把 time.sleep / perf_counter 的调度分辨率提升到 ms 级，
供 f1l1_uds（硬件执行引擎，模块导入时调用）与 timing_trace（时序采集，
main 入口调用）共用。原两处同名实现逐字节等价，2026-09-04 审计后合并至此。

约定：
  - 非 Windows / 无 winmm / 任意异常一律静默跳过，不允许影响主流程
  - 进程退出由系统自动恢复定时器分辨率，无持久副作用
"""


def set_timer_resolution(ms=1):
    """提升 Windows 定时器分辨率到 ms 级；失败静默（非 Windows / 无 winmm）"""
    try:
        import ctypes
        ctypes.windll.winmm.timeBeginPeriod(ms)
    except Exception:
        pass
