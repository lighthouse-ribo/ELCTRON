# -*- coding: utf-8 -*-
"""按参考“网络安全”工作表风格生成安全测试用例。

这里的 LIN 只表示承载/测试通道；不生成 LIN 帧、信号或调度测试。
"""

from __future__ import annotations

from typing import Iterable

from reference_case_adapter import make_reference_case


def _reqs(requirement_ids: Iterable[str]) -> str:
    values = [str(item).strip() for item in requirement_ids if str(item).strip()]
    return "\n".join(values) or "待绑定网络安全需求 ID（不得据此执行）"


def build_cybersecurity_cases(
    *,
    requirement_ids: Iterable[str] = (),
    key_material_ready: bool = False,
    bus: str = "LIN",
    env: str = "台架测试",
) -> dict:
    req_sources = _reqs(requirement_ids)
    definitions = [
        ("功能测试", "需求分析法", "L1", "0x27 Gen2 Seed/Key 正常认证", "认证请求与响应", "认证流程满足安全需求；真实密钥/算法证据可追溯"),
        ("功能测试", "功能相关性分析", "L1", "受保护服务未解锁访问控制", "未解锁时访问受保护服务", "拒绝访问并返回需求定义的 NRC，不产生未授权副作用"),
        ("功能测试", "需求分析法", "L1", "随机数不可预测性", "多次请求 seed 并记录序列", "seed 长度、变化性和重复率符合安全需求；不得把样例值当实测结论"),
        ("漏洞扫描", "错误推测法", "L1", "Seed/Key 重放攻击", "重放历史 seed/key 或跨会话 key", "认证失败并保持锁定；记录会话、计数器和 NRC"),
        ("漏洞扫描", "边界值", "L1", "Seed/Key 长度边界", "发送截断、超长、全零、全 FF 数据", "报文格式被拒绝或返回规定 NRC，不崩溃、不越权"),
        ("漏洞扫描", "错误推测法", "L2", "错误 Key 频次与时间锁定", "连续发送错误 key，观察延迟/锁定", "达到阈值后按需求进入延迟或锁定，不能绕过保护"),
        ("漏洞扫描", "错误推测法", "L2", "诊断会话切换后的权限保持", "在会话切换、复位、掉电后复用授权状态", "授权状态按需求清除或受控保持，不出现越权"),
        ("模糊测试", "等价类", "L2", "诊断安全接口模糊输入", "对 SID、subFunction、长度和 payload 做受控变异", "ECU 不崩溃、不复位失控、不泄露密钥；异常均有可追溯响应"),
    ]
    cases = []
    for index, (test_type, design, priority, title, procedure, expected) in enumerate(definitions, 1):
        needs_key = "0x27" in title
        blocked = ["security_key_material"] if needs_key and not key_material_ready else []
        cases.append(make_reference_case(
            req_sources=req_sources,
            case_id=f"TG1_TC{index}_SC1",
            priority=priority,
            auto_eval="否",
            test_point=title,
            test_method=test_type,
            design_method=design,
            env=env,
            precondition=(
                f"1. ECU 通过 {bus} 通道连接，网络安全测试授权已确认\n"
                "2. 已准备安全需求/威胁分析、测试数据和日志采集\n"
                "3. 0x27 真实密钥缺失时，仅允许生成 BLOCKED 用例，不得实机执行"
            ),
            procedure=f"1. {procedure}；\n2. 保存完整请求、响应、时间戳和异常日志；",
            expected=f"1. {expected}；\n2. 测试结论以实测证据为准，未执行保持 NOT_EXECUTED；",
            generation_status="BLOCKED" if blocked else "READY",
            blocked_by=blocked,
            category="cybersecurity",
            security_metadata={
                "bus": bus,
                "FuSa": "N/A",
                "CS": "是",
                "ASIL": "以安全需求为准",
                "CAL": "以威胁分析为准",
                "test_type": test_type,
            },
            title=title,
        ))
    return {
        "schema_version": "reference-case-bundle/v0.1",
        "module": "网络安全",
        "generation_status": "READY" if key_material_ready else "DEGRADED",
        "cases": cases,
        "policy": {"lin_means_transport_only": True, "unexecuted_verdict": "NOT_EXECUTED"},
    }


__all__ = ["build_cybersecurity_cases"]
