# -*- coding: utf-8 -*-
"""SWDL architecture contracts for staged project completion.

This module deliberately separates design readiness from execution readiness.
Missing project material produces explicit BLOCKED/DEGRADED states instead of
invented protocol values, credentials, or test verdicts.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence


STATUS_READY = "READY"
STATUS_DEGRADED = "DEGRADED"
STATUS_BLOCKED = "BLOCKED"
STATUS_PENDING = "PENDING"

_REQUIRED_INPUTS = (
    "flash_flowchart",
    "memory_map",
    "image",
    "security_key_material",
    "check_memory",
    "timing",
)

_STAGE_DEFINITIONS = (
    ("session-programming", "0x10", ("flash_flowchart",)),
    ("security-access", "0x27", ("security_key_material",)),
    ("request-download", "0x34", ("flash_flowchart", "memory_map", "image")),
    ("transfer-data", "0x36", ("flash_flowchart", "image")),
    ("transfer-exit", "0x37", ("flash_flowchart",)),
    ("check-memory", "0x31/0x0212", ("flash_flowchart", "check_memory")),
    ("reset", "0x11", ("flash_flowchart",)),
    ("version-confirmation", "project-defined", ("flash_flowchart",)),
)


def _status(value: Any) -> str:
    """Normalize one input status without treating presence as confirmation."""
    if isinstance(value, Mapping):
        raw = value.get("status", STATUS_PENDING)
    else:
        raw = value
    normalized = str(raw or STATUS_PENDING).strip().upper()
    if normalized in {"CONFIRMED", "READY", "AVAILABLE", "PASS"}:
        return STATUS_READY
    if normalized in {"BLOCKED", "MISSING", "INVALID"}:
        return STATUS_BLOCKED
    return STATUS_PENDING


def _has_material(value: Any) -> bool:
    if not isinstance(value, Mapping):
        return False
    if value.get("material") is False:
        return False
    return bool(value.get("material") or value.get("reference") or value.get("provider"))


def assess_swdl_capabilities(inputs: Mapping[str, Any] | None) -> dict[str, Any]:
    """Assess what can be designed, reviewed, executed and reported.

    The function is intentionally conservative: a missing flowchart blocks
    SWDL case design, while missing 0x27 material only blocks security access
    and dependent hardware execution. Report generation remains available.
    """
    data = dict(inputs or {})
    statuses = {key: _status(data.get(key)) for key in _REQUIRED_INPUTS}
    if "security_key_material" in data and _has_material(data["security_key_material"]):
        statuses["security_key_material"] = STATUS_READY

    missing_inputs = [key for key in _REQUIRED_INPUTS if statuses[key] != STATUS_READY]
    design_ready = statuses["flash_flowchart"] == STATUS_READY
    image_ready = statuses["image"] == STATUS_READY
    map_ready = statuses["memory_map"] == STATUS_READY
    key_ready = statuses["security_key_material"] == STATUS_READY
    static_ready = design_ready and (image_ready or statuses["image"] == STATUS_PENDING)
    execution_ready = design_ready and image_ready and map_ready and key_ready
    report_ready = True

    blockers: list[str] = []
    if not design_ready:
        blockers.append("缺少刷写流程图：SWDL 用例设计和脚本生成必须保持 BLOCKED")
    if not key_ready:
        blockers.append("缺少 0x27 可执行密钥材料：安全访问及依赖刷写执行保持 BLOCKED")
    if not image_ready:
        blockers.append("缺少有效刷写镜像或镜像哈希：不得执行 0x34/0x36")
    if not map_ready:
        blockers.append("缺少 Memory Map：不得确认下载地址、擦除范围和分区边界")

    capabilities = {
        "input_assessment": STATUS_READY,
        "case_design": STATUS_READY if design_ready else STATUS_BLOCKED,
        "static_review": STATUS_READY if static_ready else STATUS_BLOCKED,
        "script_generation": STATUS_READY if static_ready else STATUS_BLOCKED,
        "hardware_execution": STATUS_READY if execution_ready else STATUS_BLOCKED,
        "report_generation": STATUS_READY if report_ready else STATUS_BLOCKED,
    }
    overall = STATUS_READY if execution_ready else STATUS_DEGRADED
    if not design_ready:
        overall = STATUS_BLOCKED

    return {
        "schema_version": "swdl-architecture/v0.1",
        "overall_status": overall,
        "input_status": statuses,
        "missing_inputs": missing_inputs,
        "capabilities": capabilities,
        "execution_blockers": blockers,
        "policy": {
            "secret_material_in_context": False,
            "missing_key_verdict": "BLOCKED",
            "unexecuted_verdict": "NOT_EXECUTED",
            "allow_design_without_execution": design_ready,
        },
    }


def build_swdl_case_skeleton(
    target_partition: str,
    *,
    requirement_ids: Sequence[str] = (),
) -> dict[str, Any]:
    """Create a fillable baseline case, never pretending unknowns are PASS."""
    target = str(target_partition or "UNKNOWN").strip().upper()
    stages = []
    for stage_id, service, dependencies in _STAGE_DEFINITIONS:
        blocked_by = ["0x27"] if stage_id == "security-access" else []
        stages.append({
            "stage_id": stage_id,
            "service": service,
            "status": "BLOCKED" if blocked_by else "PENDING",
            "blocked_by": blocked_by,
            "input_dependencies": list(dependencies),
            "request": None,
            "expected_response": None,
            "evidence": [],
        })
    return {
        "schema_version": "swdl-case/v0.1",
        "case_id": f"SWDL-{target}-BASE-001",
        "title": f"{target} baseline software download",
        "status": "PLANNED",
        "target_partition": target,
        "requirement_ids": list(requirement_ids),
        "preconditions": [],
        "stages": stages,
        "expected_final_state": "UNKNOWN",
        "evidence_required": [
            "request_response_trace",
            "image_sha256",
            "authentication_result",
            "check_memory_result",
            "reset_result",
            "final_software_version",
        ],
        "execution": {
            "hardware": "PENDING",
            "approved": False,
            "verdict": "NOT_EXECUTED",
        },
        "notes": [
            "这是可填充架构骨架，不代表已经具备可执行资料",
            "0x27 真实密钥到位后才能将 security-access 从 BLOCKED 转为 READY",
        ],
    }
