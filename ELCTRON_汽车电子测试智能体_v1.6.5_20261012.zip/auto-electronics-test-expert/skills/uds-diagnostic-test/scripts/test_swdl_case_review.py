# -*- coding: utf-8 -*-
"""SWDL 用例契约回归。"""

import unittest

from swdl_architecture import build_swdl_case_skeleton
from swdl_case_review import validate_swdl_case


class TestSwdlCaseReview(unittest.TestCase):
    def test_baseline_skeleton_is_valid_but_warns_about_unbound_requirements(self):
        case = build_swdl_case_skeleton("SBL")
        result = validate_swdl_case(case)
        self.assertTrue(result["valid"])
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(any("需求 ID" in item for item in result["warnings"]))

    def test_wrong_stage_order_is_blocked(self):
        case = build_swdl_case_skeleton("SBL", requirement_ids=["REQ-1"])
        case["stages"].reverse()
        result = validate_swdl_case(case)
        self.assertFalse(result["valid"])
        self.assertEqual(result["status"], "BLOCKED")
        self.assertTrue(any("阶段顺序" in item for item in result["errors"]))

    def test_unexecuted_case_cannot_be_pass(self):
        case = build_swdl_case_skeleton("SBL", requirement_ids=["REQ-1"])
        case["execution"] = {"verdict": "PASS", "approved": False}
        result = validate_swdl_case(case)
        self.assertFalse(result["valid"])
        self.assertTrue(any("未执行" in item for item in result["errors"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
