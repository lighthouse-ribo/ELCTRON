#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LIN TP 离线单测（固化多帧/0x78/校验和经验，脱离硬件）
运行: python test_lin_tp.py
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lin_tp import (  # noqa: E402
    CF_DATA, FF_DATA, SF_MAX,
    assemble, compute_checksum, compute_pid,
    pack_cf, pack_fc, pack_ff, pack_request, pack_sf, parse_frame,
)


class TestPid(unittest.TestCase):
    def test_known_pids(self):
        # 规范已知值：0x3C→0x3C（MRF）、0x3D→0x7D（SRF）、项目帧 0x28→0xA8
        self.assertEqual(compute_pid(0x3C), 0x3C)
        self.assertEqual(compute_pid(0x3D), 0x7D)
        self.assertEqual(compute_pid(0x28), 0xA8)
        self.assertEqual(compute_pid(0x26), 0xA6)
        self.assertEqual(compute_pid(0x10), 0x50)

    def test_pid_never_zero_or_ff(self):
        for fid in range(0x40):
            pid = compute_pid(fid)
            self.assertNotIn(pid, (0x00, 0xFF), f"PID(0x{fid:02X}) 非法")


class TestChecksum(unittest.TestCase):
    def test_classic_example(self):
        # 速查表示例：Data=4A 55 93 E5 → 经典校验和 0xE6
        self.assertEqual(compute_checksum(0x00, bytes([0x4A, 0x55, 0x93, 0xE5]), enhanced=False), 0xE6)

    def test_enhanced_example(self):
        # 实测例：帧 0x22(PID=0xE2) 数据 0x1E → 增强校验和 0xFE
        self.assertEqual(compute_checksum(0x22, bytes([0x1E]), enhanced=True), 0xFE)

    def test_diag_frame_classic(self):
        # 诊断帧 MasterReq：22 F1 2E FF FF FF FF FF → 经典 0xBD
        self.assertEqual(compute_checksum(0x3C, bytes([0x22, 0xF1, 0x2E, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]),
                                          enhanced=False), 0xBD)


class TestSingleFrame(unittest.TestCase):
    def test_pack_sf(self):
        # 3 字节请求 22 F1 2E：PCI=3（消息字节数含 SID）
        fr = pack_sf(0x51, [0x22, 0xF1, 0x2E])
        self.assertEqual(fr, bytes([0x51, 0x03, 0x22, 0xF1, 0x2E, 0xFF, 0xFF, 0xFF]))
        kind, nad, pci, payload = parse_frame(fr)
        self.assertEqual((kind, nad, pci), ("sf", 0x51, 0x03))
        self.assertEqual(payload, bytes([0x22, 0xF1, 0x2E]))

    def test_sf_max(self):
        fr = pack_sf(0x51, list(range(SF_MAX)))
        self.assertEqual(len(fr), 8)
        with self.assertRaises(AssertionError):
            pack_sf(0x51, list(range(SF_MAX + 1)))


class TestMultiFrame(unittest.TestCase):
    def test_roundtrip_54b(self):
        # 0x27 Gen2 seed 请求 54 字节：FF + 9 CF 可靠传输（实测 28）
        payload = list(range(54))
        frames = pack_request(0x51, payload)
        self.assertEqual(len(frames), 10)
        kind, nad, pci, _p, total = parse_frame(frames[0])
        self.assertEqual((kind, nad, total), ("ff", 0x51, 54))
        # 逐帧序号 1..9
        for i, fr in enumerate(frames[1:], 1):
            k, _n, p2, _pay = parse_frame(fr)[0], parse_frame(fr)[1], parse_frame(fr)[2], parse_frame(fr)[3]
            self.assertEqual(k, "cf")
            self.assertEqual(p2 & 0x0F, i)
        # 重组
        parsed = [parse_frame(fr) for fr in frames]
        out = assemble(parsed)
        self.assertEqual(out, bytes(payload))

    def test_seq_wrap(self):
        # 16 个 CF 后序号回 0
        self.assertEqual(pack_cf(0x51, 15, [1])[1], 0x2F)
        self.assertEqual(pack_cf(0x51, 16, [1])[1], 0x20)

    def test_ff_payload_size(self):
        self.assertEqual(FF_DATA, 5)
        self.assertEqual(CF_DATA, 6)


class TestFlowControl(unittest.TestCase):
    def test_pack_fc(self):
        fr = pack_fc(0x51, bs=0, stmin=0)
        kind, nad, pci, payload = parse_frame(fr)
        self.assertEqual((kind, nad, pci), ("fc", 0x51, 0x30))
        self.assertEqual(payload, bytes([0x00, 0x00]))


class TestPending(unittest.TestCase):
    def test_sf_pending(self):
        fr = pack_sf(0x51, [0x7F, 0x22, 0x78])
        out = assemble([parse_frame(fr)])
        self.assertEqual(out, b"PENDING")

    def test_multiframe_pending(self):
        # FF 后跟 7F 78 单帧 → PENDING
        ff, rest = pack_ff(0x51, list(range(12)))
        pending = pack_sf(0x51, [0x7F, 0x27, 0x78])
        out = assemble([parse_frame(ff), parse_frame(pending)])
        self.assertEqual(out, b"PENDING")


class TestBadSequence(unittest.TestCase):
    def test_out_of_order_cf(self):
        payload = list(range(12))
        ff, rest = pack_ff(0x51, payload)
        cf1 = pack_cf(0x51, 1, rest[:6])
        cf3 = pack_cf(0x51, 3, rest[6:])  # 跳号
        out = assemble([parse_frame(ff), parse_frame(cf1), parse_frame(cf3)])
        self.assertIsNone(out)


if __name__ == "__main__":
    unittest.main(verbosity=2)
