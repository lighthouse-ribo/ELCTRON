#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LIN 诊断帧 PCI 解析契约。

LIN 诊断帧通常以 ``NAD + PCI + UDS payload + padding`` 表示。之前各个
脚本各自猜测第二个字节的含义，容易把 ``51 04 31 01 ...`` 中的 ``04``
误当成 UDS 数据。此模块集中定义识别、剥离和完整性检查规则，供生成器、
SDDB 抽取器和回归测试共同使用。
"""

from __future__ import annotations

from typing import Iterable, Optional


def _as_bytes(values: Iterable[int]) -> list[int]:
    return [int(value) & 0xFF for value in values]


def is_uds_sid(value: int) -> bool:
    """判断一个字节是否像 UDS 服务 ID/负响应 SID。"""
    value = int(value) & 0xFF
    return 0x10 <= value <= 0x3E or 0x7F <= value <= 0xBF


def _looks_like_wrapped_frame(values: list[int], nad: int) -> bool:
    if len(values) < 2:
        return False
    if values[0] == (int(nad) & 0xFF):
        return True
    # 功能寻址或导出工具未传入实际 NAD 时，完整 8 字节单帧仍可由
    # ``PCI=0x0N`` 识别。短 UDS payload 不走该分支，避免误剥离。
    return (
        len(values) >= 8
        and not is_uds_sid(values[0])
        and (values[1] >> 4) in (0x0, 0x1)
    )


def parse_lin_transport_frame(values: Iterable[int], nad: int = 0x51) -> dict:
    """解析一行 LIN 诊断传输帧并返回可审计元数据。

    返回字段包括 ``wrapped``、``frame_type``、``declared_length``、
    ``available_length``、``payload`` 和 ``padding``。单帧的 payload 严格
    按 PCI 低四位截取；若声明长度超过当前行提供的字节数，``complete``
    为 False，但仍保留已收到的 payload 供上层输出诊断信息。
    """
    raw = _as_bytes(values)
    if not _looks_like_wrapped_frame(raw, nad):
        return {
            "wrapped": False,
            "frame_type": "direct_payload",
            "nad": None,
            "pci": None,
            "declared_length": len(raw),
            "available_length": len(raw),
            "payload": raw,
            "padding": [],
            "complete": True,
        }

    actual_nad = raw[0]
    pci = raw[1]
    frame_kind = pci >> 4
    if frame_kind == 0x0:
        declared = pci & 0x0F
        payload_area = raw[2:]
        payload = payload_area[:declared]
        return {
            "wrapped": True,
            "frame_type": "single",
            "nad": actual_nad,
            "pci": pci,
            "declared_length": declared,
            "available_length": len(payload_area),
            "payload": payload,
            "padding": payload_area[declared:],
            "complete": len(payload_area) >= declared,
        }

    if frame_kind == 0x1 and len(raw) >= 3:
        declared = ((pci & 0x0F) << 8) | raw[2]
        payload = raw[3:]
        return {
            "wrapped": True,
            "frame_type": "first",
            "nad": actual_nad,
            "pci": pci,
            "declared_length": declared,
            "available_length": len(payload),
            "payload": payload,
            "padding": [],
            "complete": len(payload) >= declared,
        }

    if frame_kind == 0x2:
        return {
            "wrapped": True,
            "frame_type": "consecutive",
            "nad": actual_nad,
            "pci": pci,
            "declared_length": None,
            "available_length": max(0, len(raw) - 2),
            "payload": raw[2:],
            "padding": [],
            "complete": True,
        }

    return {
        "wrapped": True,
        "frame_type": "reserved",
        "nad": actual_nad,
        "pci": pci,
        "declared_length": None,
        "available_length": max(0, len(raw) - 2),
        "payload": raw[2:],
        "padding": [],
        "complete": False,
    }


def strip_lin_payload(
    values: Iterable[int], nad: int = 0x51, *, strict: bool = False
) -> Optional[list[int]]:
    """剥离 LIN NAD/PCI/填充，返回 UDS payload。

    ``strict=True`` 时，单帧声明长度不足或遇到保留 PCI 类型会返回 None；
    默认模式保留已有调用方的兼容行为，返回当前已解析出的 payload。
    """
    parsed = parse_lin_transport_frame(values, nad)
    if strict and (not parsed["complete"] or parsed["frame_type"] == "reserved"):
        return None
    return list(parsed["payload"])


def pci_rules() -> dict:
    """输出可写入 service_prereq.json 的机器可读规则摘要。"""
    return {
        "transport": "LIN diagnostic ISO-TP",
        "nad_index": 0,
        "pci_index": 1,
        "single_frame": {
            "type_nibble": 0,
            "length_source": "pci_low_nibble",
            "payload_start": 2,
            "padding": "bytes_after_declared_payload",
        },
        "first_frame": {
            "type_nibble": 1,
            "length_source": "pci_low_nibble_and_next_byte",
            "payload_start": 3,
        },
        "consecutive_frame": {"type_nibble": 2, "payload_start": 2},
        "rule_id": "LIN-UDS-PCI-001",
    }


__all__ = [
    "is_uds_sid",
    "parse_lin_transport_frame",
    "pci_rules",
    "strip_lin_payload",
]
