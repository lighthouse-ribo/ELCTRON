#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""F1L1 lifecycle regression tests; never connects to real hardware."""

import ctypes
import importlib.util
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch


SCRIPT_DIR = Path(__file__).resolve().parent


class FakeDll:
    def __init__(self, activity=0):
        self.activity_code = activity
        self.calls = []

    def xcdev_open(self, _hardtype, _index, err):
        err._obj.value = 0
        self.calls.append(("open",))
        return 1

    def xcdev_config_lin(self, *_args):
        self.calls.append(("config_lin",))
        return 0

    def xcdev_activity(self, _dev):
        self.calls.append(("activity",))
        return self.activity_code

    def xcdev_lin_set_entry(self, *_args):
        self.calls.append(("set_entry",))
        return 0

    def xcdev_lin_setup_scheduler(self, _channel, scheduler, *_args):
        self.calls.append(("setup", scheduler))
        return 0

    def xcdev_lin_start_scheduler(self, _channel, scheduler, *_args):
        self.calls.append(("start", scheduler))
        return 0

    def xcdev_lin_stop_scheduler(self, _channel, scheduler, *_args):
        self.calls.append(("stop", scheduler))
        return 0

    def xcdev_lin_remove_scheduler(self, _channel, scheduler, *_args):
        self.calls.append(("remove", scheduler))
        return 0

    def xcdev_receive(self, *_args):
        return 0

    def xcdev_close(self, dev):
        self.calls.append(("close", dev))


def fake_xcdev_module(dll):
    module = types.ModuleType("xcdev_wrapper")
    module.XC_HARDTYPE_CANVIEX_F1L1 = 3
    module.dll = dll

    class xNetpack(ctypes.Structure):
        _fields_ = [("data", ctypes.c_ubyte * 128)]

    class xLinOpt(ctypes.Structure):
        _fields_ = [("brval", ctypes.c_uint), ("mode", ctypes.c_ubyte),
                    ("outputV", ctypes.c_ubyte), ("padding", ctypes.c_ubyte * 14)]

    class xLinEntry(ctypes.Structure):
        _fields_ = [("id", ctypes.c_ubyte), ("channel", ctypes.c_ubyte),
                    ("role", ctypes.c_ubyte), ("rsp", ctypes.c_ubyte),
                    ("length", ctypes.c_uint), ("padding", ctypes.c_ubyte * 8)]

    class xLinAppoint(ctypes.Structure):
        _fields_ = [("ids", ctypes.c_ubyte * 8), ("delay", ctypes.c_uint)]

    module.xNetpack = xNetpack
    module.xLinOpt = xLinOpt
    module.xLinEntry = xLinEntry
    module.xLinAppoint = xLinAppoint
    module.make_lin_opt = lambda brval=19200: xLinOpt(brval=brval, mode=1, outputV=1)
    return module


def load_f1l1(fake_xcdev):
    name = "f1l1_lifecycle_test_target"
    spec = importlib.util.spec_from_file_location(name, SCRIPT_DIR / "f1l1_uds.py")
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {"xcdev_wrapper": fake_xcdev}):
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return module


class F1L1LifecycleTests(unittest.TestCase):
    def test_activity_failure_cleans_both_scheduler_slots(self):
        dll = FakeDll(activity=3)
        f1l1 = load_f1l1(fake_xcdev_module(dll))
        uds = f1l1.F1L1UDS()

        with patch.object(f1l1.time, "sleep"):
            with self.assertRaisesRegex(RuntimeError, "activity 失败 3"):
                uds.open(retries=1)

        self.assertIsNone(uds.dev)
        self.assertEqual([c for c in dll.calls if c[0] == "stop"],
                         [("stop", 0), ("stop", 1)])
        self.assertEqual([c for c in dll.calls if c[0] == "remove"],
                         [("remove", 0), ("remove", 1)])
        self.assertEqual(sum(c[0] == "close" for c in dll.calls), 1)

    def test_close_is_idempotent_and_removes_both_scheduler_slots(self):
        dll = FakeDll(activity=0)
        f1l1 = load_f1l1(fake_xcdev_module(dll))
        uds = f1l1.F1L1UDS()

        with patch.object(f1l1.time, "sleep"):
            self.assertTrue(uds.open(retries=1))
        uds.close()
        uds.close()

        self.assertIsNone(uds.dev)
        self.assertEqual([c for c in dll.calls if c[0] == "stop"],
                         [("stop", 0), ("stop", 1)])
        self.assertEqual([c for c in dll.calls if c[0] == "remove"],
                         [("remove", 0), ("remove", 1)])
        self.assertEqual(sum(c[0] == "close" for c in dll.calls), 1)


if __name__ == "__main__":
    unittest.main()
