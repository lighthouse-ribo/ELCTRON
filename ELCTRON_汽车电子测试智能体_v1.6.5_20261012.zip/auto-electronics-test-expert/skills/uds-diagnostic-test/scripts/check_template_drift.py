#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SCRIPT_HEADER 模板漂移校验（审计 B1 短期措施）
=========================================================================
uds_test_generator.py 顶部 4000+ 行是 SCRIPT_HEADER 字符串模板（生成
uds_test.py 冒烟脚本的运行时文本），其中 SeedKeyGen2 / AES 等实现与模块化
版本（seedkey_gen2.py 等）构成双份实现——改模块不改模板 = 确定性漂移。

本工具用 AST 提取「模板字符串」与「模块文件」的同名顶层 def/class 源码，
规范化（dedent + 去尾部空白 + 去空行）后逐名比对，报告漂移：

  python check_template_drift.py                    # 默认比对 seedkey_gen2 / lin_tp
  python check_template_drift.py --module xxx.py    # 指定模块（可多次传入）
  python check_template_drift.py --var OTHER_VAR    # 其他模板字符串变量名

退出码：0 = 全部同步；1 = 存在漂移或解析失败。
不执行生成器代码（纯 AST 静态提取），无第三方依赖。
"""

import argparse
import ast
import difflib
import os
import re
import sys
import textwrap


def _extract_string_assignment(source, var_name):
    """从模块源码提取顶层字符串赋值 var_name 的值（不执行模块代码）"""
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id == var_name:
                    return ast.literal_eval(node.value)
        if isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name) and node.target.id == var_name and node.value is not None:
                return ast.literal_eval(node.value)
    return None


def _normalize(code, template_mode=False):
    """规范化：dedent + 逐行去尾部空白 + 丢弃空行。

    template_mode=True 时先还原 .format 转义（{{ → {、}} → }）——
    模板字符串要过 .format()，字面花括号必须双写，属机制性转义而非逻辑差异。
    """
    if template_mode:
        code = code.replace("{{", "{").replace("}}", "}")
    code = textwrap.dedent(code)
    kept = []
    for line in code.splitlines():
        line = line.rstrip()
        if line.strip():
            kept.append(line)
    return "\n".join(kept)


# 列零出现以下形态时结束当前定义段：新 def/class、装饰器、赋值、导入
_SEG_BREAK = re.compile(
    r"^(?:async\s+def\s|def\s|class\s|@|#|[A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*\s*=(?!=)|from\s|import\s)")


def _top_level_sources(source, template_mode=False):
    """提取顶层（列零）def/class 的 {名字: 规范化源码}。

    用列零行扫描而非 ast.parse：模板字符串里混有类体缩进的方法片段与
    {placeholder} 占位符，整段不是合法 Python；行扫描对两侧对称提取，
    嵌套定义（缩进）天然跳过。列零的赋值/装饰器/导入行会终止当前段，
    避免把函数后的模块级语句并入函数体造成假差异。
    """
    out = {}
    lines = source.splitlines()
    cur_name = None
    buf = []
    for line in lines:
        m = re.match(r"^(?:async\s+def|def|class)\s+([A-Za-z_][A-Za-z0-9_]*)", line)
        if m:
            if cur_name is not None:
                out[cur_name] = _normalize("\n".join(buf), template_mode)
            cur_name = m.group(1)
            buf = [line]
        elif cur_name is not None and _SEG_BREAK.match(line):
            out[cur_name] = _normalize("\n".join(buf), template_mode)
            cur_name = None
            buf = []
        elif cur_name is not None:
            buf.append(line)
    if cur_name is not None:
        out[cur_name] = _normalize("\n".join(buf), template_mode)
    return out


def compare(template_code, module_path, ignore=(), template_name="SCRIPT_HEADER"):
    """比对模板与单个模块，返回 (漂移数, 报告行列表)"""
    tpl = _top_level_sources(template_code, template_mode=True)
    with open(module_path, "r", encoding="utf-8-sig") as f:
        mod = _top_level_sources(f.read())

    report = []
    drift = 0
    shared = sorted(set(tpl) & set(mod))
    if not shared:
        report.append("  (无同名顶层 def/class，跳过)")
    for name in shared:
        if name in ignore:
            report.append("  [SKIP ] %s (--ignore)" % name)
            continue
        if tpl[name] == mod[name]:
            report.append("  [SYNC ] %s" % name)
        else:
            drift += 1
            report.append("  [DRIFT] %s" % name)
            diff = difflib.unified_diff(
                mod[name].splitlines(), tpl[name].splitlines(),
                fromfile="module:" + os.path.basename(module_path),
                tofile="template:" + template_name, lineterm="")
            for i, line in enumerate(diff):
                if i >= 12:
                    report.append("        ...（diff 截断，详见两侧源码）")
                    break
                report.append("        " + line)
    only_tpl = sorted(set(tpl) - set(mod))
    only_mod = sorted(set(mod) - set(tpl))
    if only_tpl:
        report.append("  (仅模板存在: %s)" % ", ".join(only_tpl))
    if only_mod:
        report.append("  (仅模块存在: %s)" % ", ".join(only_mod))
    return drift, report


def _load_template_value(path, var_name):
    """优先按模块导入取值（SCRIPT_HEADER 可为运行时拼装，非字面量）；失败回退 AST 提取字面量"""
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("_drift_gen_mod", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        v = getattr(mod, var_name, None)
        if isinstance(v, str):
            return v
    except Exception:
        pass
    with open(path, "r", encoding="utf-8-sig") as f:
        code = _extract_string_assignment(f.read(), var_name)
    if code is None:
        raise ValueError("生成器中未找到顶层字符串赋值 %r" % var_name)
    return code


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description="SCRIPT_HEADER 模板 vs 模块化实现 漂移校验")
    ap.add_argument("--generator", default=os.path.join(here, "script_header_template.py"),
                    help="生成器文件（默认 uds_test_generator.py）")
    ap.add_argument("--var", default="SCRIPT_HEADER", help="模板字符串变量名（默认 SCRIPT_HEADER）")
    ap.add_argument("--module", action="append", default=None,
                    help="参与比对的模块文件（可多次传入；缺省 seedkey_gen2.py + lin_tp.py）")
    ap.add_argument("--ignore", default="", help="不参与比对的逗号分隔名字（如入口 main 等同名不同义者）")
    args = ap.parse_args()
    modules = args.module or [os.path.join(here, "seedkey_gen2.py"),
                              os.path.join(here, "lin_tp.py")]
    ignore = tuple(n.strip() for n in args.ignore.split(",") if n.strip())

    template_code = _load_template_value(args.generator, args.var)

    total_drift = 0
    print("== 模板漂移校验：%s :: %s ==" % (os.path.basename(args.generator), args.var))
    for m in modules:
        print("-- vs %s" % os.path.basename(m))
        try:
            d, lines_ = compare(template_code, m, ignore, args.var)
        except (ValueError, SyntaxError) as e:
            print("  [ERROR] %s" % e)
            total_drift += 1
            continue
        total_drift += d
        for ln in lines_:
            print(ln)
    print("== 结果：%s ==" % ("存在 %d 处漂移" % total_drift if total_drift else "全部同步"))
    sys.exit(1 if total_drift else 0)


if __name__ == "__main__":
    main()
