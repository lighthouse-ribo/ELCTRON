#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""uds_runner 编排逻辑离线回归测试。"""
import json
import os
import subprocess
import sys
import unittest
from unittest.mock import patch
from testsupport import WorkspaceTempDir


HERE = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(HERE, "uds_runner.py")
def test_tempdir():
    return WorkspaceTempDir("runner")
sys.path.insert(0, HERE)


class TestRunnerHelpers(unittest.TestCase):
    def test_workflow_timer_records_elapsed_phases(self):
        from uds_runner import WorkflowTimer

        timer = WorkflowTimer("test")
        timer.record("phase", timer.started_at, timer.started_mono, 0)
        self.assertEqual(timer.phases[0]["name"], "phase")
        self.assertEqual(timer.phases[0]["returncode"], 0)

    def test_representative_report_propagates_fail_and_runtime_exception(self):
        from uds_runner import representative_report_ok

        self.assertTrue(representative_report_ok(0, "| 失败 (FAIL) | 0 |"))
        self.assertFalse(representative_report_ok(0, "| 失败 (FAIL) | 2 |"))
        self.assertFalse(representative_report_ok(0, "", "[ERROR] 测试过程中发生异常: boom"))
        self.assertFalse(representative_report_ok(1, ""))
    def test_audited_cases_are_selected_for_downstream_steps(self):
        from uds_runner import select_cases_path

        self.assertEqual(select_cases_path("raw.json", "filled.json"), "filled.json")
        self.assertEqual(select_cases_path("raw.json", ""), "raw.json")
        self.assertEqual(select_cases_path("", "filled.json"), "filled.json")

    def test_direct_output_requires_no_occupying_process_and_no_canviex_device(self):
        from uds_runner import direct_output_allowed

        self.assertTrue(direct_output_allowed([], 0, 0))
        self.assertFalse(direct_output_allowed(["CANoe64"], 0, 0))
        self.assertFalse(direct_output_allowed([], 1, 0))
        # 无法完成设备探测时不能把“未知”误判为“无硬件”。
        self.assertFalse(direct_output_allowed([], None, 0))
        # OP-07：Vector XL 设备必须纳入统一硬件清单。
        self.assertFalse(direct_output_allowed([], 0, None))
        self.assertFalse(direct_output_allowed([], 0, 2))

    def test_generate_only_is_removed_from_project_cli(self):
        help_result = subprocess.run(
            [sys.executable, RUNNER, "project", "--help"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(help_result.returncode, 0, help_result.stderr)
        self.assertNotIn("--generate-only", help_result.stdout)

        rejected = subprocess.run(
            [sys.executable, RUNNER, "project", "--input", "missing.xlsx", "--generate-only"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertNotEqual(rejected.returncode, 0)
        self.assertIn("unrecognized arguments", rejected.stderr)

    def test_minimum_hardware_selection_is_one_executable_case_per_service(self):
        from uds_runner import select_minimum_hardware_cases

        with test_tempdir() as td:
            with open(os.path.join(td, "manifest.json"), "w", encoding="utf-8") as f:
                json.dump({"cases": {
                    "A": {"script": "case_A.py", "service": "0x22", "status": "pos"},
                    "B": {"script": "case_B.py", "service": "0x22", "status": "neg"},
                    "C": {"script": "case_C.py", "service": "0x27", "status": "blocked"},
                    "D": {"script": "case_D.py", "service": "0x10", "status": "timing"},
                }}, f)
            selected = select_minimum_hardware_cases(td)
        self.assertEqual([item["case_id"] for item in selected], ["A"])

    def test_minimum_hardware_retest_reads_sanitized_result_for_hyphenated_case_id(self):
        from uds_runner import run_minimum_hardware_retest

        with test_tempdir() as td:
            os.makedirs(os.path.join(td, "results"), exist_ok=True)
            with open(os.path.join(td, "manifest.json"), "w", encoding="utf-8") as f:
                json.dump({"cases": {
                    "A-B": {"script": "case_A_B.py", "service": "0x22", "status": "pos"},
                }}, f)
            with open(os.path.join(td, "case_A_B.py"), "w", encoding="utf-8") as f:
                f.write("# external smoke process is mocked\n")

            def fake_smoke_process(*args, **kwargs):
                with open(os.path.join(td, "results", "A_B.json"), "w", encoding="utf-8") as result:
                    json.dump({"case_id": "A-B", "verdict": "PASS"}, result)
                return subprocess.CompletedProcess(args[0], 0, stdout="", stderr="")

            smoke_out = os.path.join(td, "hardware_smoke.json")
            with patch("uds_runner._run_subprocess", side_effect=fake_smoke_process):
                self.assertTrue(run_minimum_hardware_retest(td, smoke_out))

            with open(smoke_out, encoding="utf-8") as f:
                self.assertEqual(json.load(f)["results"][0]["verdict"], "PASS")

    def test_survey_directory_requires_explicit_partition_when_ambiguous(self):
        from uds_runner import resolve_survey_input

        with test_tempdir() as td:
            for name in ("SDDB_APP_diagnostic.xlsx", "SDDB_PBL_diagnostic.xlsx"):
                open(os.path.join(td, name), "wb").close()
            self.assertEqual(resolve_survey_input(td), "")

    def test_survey_directory_selects_only_matching_partition(self):
        from uds_runner import resolve_survey_input

        with test_tempdir() as td:
            app = os.path.join(td, "SDDB_APP_diagnostic.xlsx")
            pbl = os.path.join(td, "SDDB_PBL_diagnostic.xlsx")
            open(app, "wb").close()
            open(pbl, "wb").close()
            self.assertEqual(resolve_survey_input(td, "PBL"), os.path.abspath(pbl))

    def test_smoke_script_error_is_not_ecu_fail(self):
        from uds_runner import run_minimum_hardware_retest

        with test_tempdir() as td:
            os.makedirs(os.path.join(td, "results"), exist_ok=True)
            with open(os.path.join(td, "manifest.json"), "w", encoding="utf-8") as f:
                json.dump({"cases": {
                    "A": {"script": "case_A.py", "service": "0x22", "status": "pos"},
                }}, f)
            with open(os.path.join(td, "case_A.py"), "w", encoding="utf-8") as f:
                f.write("# mocked below\n")

            def failed_smoke_process(*args, **kwargs):
                return subprocess.CompletedProcess(args[0], 2, stdout="", stderr="boom")

            smoke_out = os.path.join(td, "hardware_smoke.json")
            with patch("uds_runner._run_subprocess", side_effect=failed_smoke_process):
                self.assertFalse(run_minimum_hardware_retest(td, smoke_out))

            with open(smoke_out, encoding="utf-8") as f:
                result = json.load(f)["results"][0]
            self.assertEqual(result["failure_class"], "SCRIPT_ERROR")
            self.assertEqual(result["verdict"], "BLOCKED")

    def test_project_does_not_auto_confirm_missing_can_parameters(self):
        from uds_runner import config_gate_allows_generation, resolve_effective_config

        effective = resolve_effective_config({"can_config": {}}, {"bus": "can"})
        self.assertTrue(effective["requires_confirmation"])
        self.assertFalse(config_gate_allows_generation(effective, confirmed=False, bus="can"))
        self.assertTrue(config_gate_allows_generation(effective, confirmed=True, bus="can"))

    def test_project_rejects_skip_link_check_and_no_case_exec(self):
        # OP-04：正式 project 模式锁定关键门禁，禁止绕过链路探测或退回冒烟执行。
        from uds_runner import project

        with test_tempdir() as td:
            self.assertFalse(project("missing.xlsx", td, skip_link_check=True))
            self.assertFalse(project("missing.xlsx", td, no_case_exec=True))

    def test_effective_can_config_has_one_source_for_all_downstream_steps(self):
        from uds_runner import resolve_effective_config

        resolved = resolve_effective_config(
            {"can_config": {"tx_id": 0x671, "rx_id": 0x679, "bitrate": 250000}},
            {"bus": "can", "channel": "1", "serial": "VN123", "tx_id": None,
             "rx_id": None, "bitrate": None, "can_fd": None},
        )
        self.assertEqual(resolved["can"]["tx_id"], 0x671)
        self.assertEqual(resolved["can"]["rx_id"], 0x679)
        self.assertEqual(resolved["can"]["bitrate"], 250000)
        self.assertEqual(resolved["can"]["channel"], "1")
        self.assertFalse(resolved["requires_confirmation"])
        overridden = resolve_effective_config(
            {"can_config": {"tx_id": 0x671, "rx_id": 0x679, "bitrate": 250000}},
            {"bus": "can", "tx_id": "0x7E0", "rx_id": "0x7E8", "bitrate": 500000},
        )
        self.assertEqual(overridden["can"]["tx_id"], 0x7E0)
        self.assertEqual(overridden["can"]["rx_id"], 0x7E8)
        self.assertEqual(overridden["can"]["bitrate"], 500000)

    def test_pipeline_delegates_to_project_gate(self):
        from uds_runner import pipeline

        with patch("uds_runner.project", return_value=True) as project_call:
            self.assertTrue(pipeline("survey.xlsx", "out", confirmed=True))
        project_call.assert_called_once_with("survey.xlsx", "out", confirmed=True)

    def test_expectation_check_receives_project_config(self):
        from uds_runner import run_expectation_check

        with patch("uds_runner._run_ok", return_value=True) as run_ok:
            self.assertTrue(run_expectation_check(
                "cases.json", "expectation.json", bus="lin", nad=0x60,
                project_config="project.json"))
        command = run_ok.call_args.args[0]
        self.assertIn("--project-config", command)
        self.assertEqual(command[command.index("--project-config") + 1], "project.json")

    def test_project_lin_bitrate_prefers_brval(self):
        from uds_runner import _effective_lin_bitrate

        self.assertEqual(_effective_lin_bitrate({"brval": 10400, "bitrate": 500000}), 10400)
        self.assertEqual(_effective_lin_bitrate({"bitrate": 19200}), 19200)
        self.assertEqual(_effective_lin_bitrate({}), 19200)

    def test_script_review_receives_project_config_from_cli(self):
        from uds_runner import main

        with patch("uds_runner.run_script_review", return_value=True) as review:
            with patch.object(sys, "argv", [
                RUNNER, "script-review", "--cases", "cases.json",
                "--parsed", "parsed.json", "--scripts-dir", "scripts",
                "--project-config", "project.json",
            ]):
                with self.assertRaises(SystemExit) as exit_info:
                    main()
        self.assertEqual(exit_info.exception.code, 0)
        self.assertEqual(review.call_args.kwargs["project_config"], "project.json")


class TestRunAllExitCode(unittest.TestCase):
    def test_run_all_returns_nonzero_when_a_case_verdict_is_fail(self):
        with test_tempdir() as td:
            cases_path = os.path.join(td, "cases.json")
            parsed_path = os.path.join(td, "parsed.json")
            out_dir = os.path.join(td, "out")
            with open(cases_path, "w", encoding="utf-8") as f:
                json.dump({"cases": [{
                    "case_id": "C1",
                    "test_point": "需要补充参数",
                    "procedure": "请求: 31 01 + 参数",
                    "expected": "正响应",
                    "precondition": "默认会话",
                }]}, f)
            with open(parsed_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            generated = subprocess.run(
                [sys.executable, os.path.join(HERE, "gen_case_scripts.py"),
                 "--cases", cases_path, "--parsed", parsed_path, "--out-dir", out_dir,
                 "--confirmed"],
                capture_output=True, text=True,
            )
            self.assertEqual(generated.returncode, 0, generated.stderr)
            with open(os.path.join(out_dir, "case_C1.py"), "w", encoding="utf-8") as f:
                f.write(
                    "import json, os\n"
                    "os.makedirs('results', exist_ok=True)\n"
                    "json.dump({'case_id':'C1','verdict':'FAIL'}, open('results/C1.json','w'))\n"
                )
            result = subprocess.run(
                [sys.executable, os.path.join(out_dir, "run_all.py")],
                cwd=out_dir,
                capture_output=True, text=True, encoding="utf-8", errors="replace",
            )
            self.assertNotEqual(result.returncode, 0)

    def _gen_single_case(self):
        """生成单条可执行用例脚本目录，返回 (td, out_dir)。"""
        td = test_tempdir()
        self.addCleanup(td.cleanup)
        cases_path = os.path.join(td.name, "cases.json")
        parsed_path = os.path.join(td.name, "parsed.json")
        out_dir = os.path.join(td.name, "out")
        with open(cases_path, "w", encoding="utf-8") as f:
            json.dump({"cases": [{
                "case_id": "C1",
                "test_point": "读取 DID",
                "procedure": "请求: 22 F1 90",
                "expected": "正响应",
                "precondition": "默认会话",
            }]}, f)
        with open(parsed_path, "w", encoding="utf-8") as f:
            json.dump({}, f)
        generated = subprocess.run(
            [sys.executable, os.path.join(HERE, "gen_case_scripts.py"),
             "--cases", cases_path, "--parsed", parsed_path, "--out-dir", out_dir,
             "--bus", "can", "--confirmed"],
            capture_output=True, text=True,
        )
        self.assertEqual(generated.returncode, 0, generated.stderr)
        return td, out_dir

    def test_run_all_adopts_fail_result_when_script_exits_one(self):
        # P1-1：单条脚本对 FAIL 判定返回退出码 1；run_all 必须采用结果文件
        # （含 FAIL 明细与证据），不能误判为"脚本异常退出"。
        td, out_dir = self._gen_single_case()
        with open(os.path.join(out_dir, "case_C1.py"), "w", encoding="utf-8") as f:
            f.write(
                "import json, os, sys\n"
                "os.makedirs('results', exist_ok=True)\n"
                "json.dump({'case_id':'C1','verdict':'FAIL','actual':'协议不匹配','note':'判定失败'},\n"
                "          open('results/C1.json','w'))\n"
                "sys.exit(1)\n"
            )
        result = subprocess.run(
            [sys.executable, os.path.join(out_dir, "run_all.py")],
            cwd=out_dir, capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertNotEqual(result.returncode, 0)
        with open(os.path.join(out_dir, "results_all.json"), encoding="utf-8") as handle:
            data = json.load(handle)
        item = data["results"][0]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertEqual(item["actual"], "协议不匹配")
        self.assertEqual(item["failure_class"], "ECU_FAIL")
        self.assertNotIn("脚本异常退出", item.get("actual", ""))

    def test_run_all_marks_crash_without_result_as_abnormal_exit(self):
        # P1-1：退出码 2 且无结果文件 → 归为脚本异常退出（FAIL + 兜底说明），
        # 且不会被误报为 BLOCKED 或 PASS。
        td, out_dir = self._gen_single_case()
        with open(os.path.join(out_dir, "case_C1.py"), "w", encoding="utf-8") as f:
            f.write("import sys\nsys.exit(2)\n")
        result = subprocess.run(
            [sys.executable, os.path.join(out_dir, "run_all.py")],
            cwd=out_dir, capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertNotEqual(result.returncode, 0)
        with open(os.path.join(out_dir, "results_all.json"), encoding="utf-8") as handle:
            data = json.load(handle)
        item = data["results"][0]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertEqual(item["failure_class"], "SCRIPT_ERROR")
        self.assertIn("脚本异常退出", item.get("actual", ""))

    def test_run_all_marks_missing_result_as_invalid_evidence(self):
        td, out_dir = self._gen_single_case()
        with open(os.path.join(out_dir, "case_C1.py"), "w", encoding="utf-8") as f:
            f.write("# exits normally without writing the required result\n")
        result = subprocess.run(
            [sys.executable, os.path.join(out_dir, "run_all.py")],
            cwd=out_dir, capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertNotEqual(result.returncode, 0)
        with open(os.path.join(out_dir, "results_all.json"), encoding="utf-8") as handle:
            data = json.load(handle)
        item = data["results"][0]
        self.assertEqual(item["verdict"], "FAIL")
        self.assertEqual(item["failure_class"], "RESULT_INVALID")
        self.assertEqual(item["actual"], "脚本未输出结果")

if __name__ == "__main__":
    unittest.main(verbosity=2)
