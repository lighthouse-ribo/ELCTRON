#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""xcdev_wrapper.py — CANviex xcdevlay DLL 的 ctypes 封装（F1L1 LIN 通道）
=====================================================================
依据 SDK 头文件 xcdevlay.h v1.3.8 / xcdevlay_lin.h 编写。
供 f1l1_uds.py 使用；目录通过环境变量 F1L1_XCWRAPPER_DIR 指定（缺省 cwd/脚本目录）。

DLL 加载优先级：
  1. 环境变量 F1L1_DLL_PATH（显式指定 dll 完整路径）
  2. 默认 SDK 目录 D:/VickCAN_x64_QT5_2.37++3/xcdevlay.1.3.8/xcdevlay.1.3.8/x64/xcdevlay.dll
  3. 系统 PATH / 当前目录
注意：
  - 结构体对齐用 C 编译器默认（8 字节），禁止 _pack_=1（xNetpack 152 字节，错位会导致解析异常）
  - 执行前必须关闭 VickCAN.exe / CANoe（同一通道独占）
  - LIN 收发器供电：xLinOpt.outputV=1（DB9 pin4=LIN-VBAT），无外部 12V 时必须开
"""

import ctypes
import os
from ctypes import c_int, c_ubyte, c_ushort, c_uint, c_void_p, c_longlong, POINTER, byref

# ---------------- 常量（与头文件一致） ----------------
XC_HARDTYPE_CANVIEX_F1 = 1
XC_HARDTYPE_CANVIEX_F2 = 2
XC_HARDTYPE_CANVIEX_F1L1 = 3
XC_HARDTYPE_CANVIEX_C1 = 4
XC_HARDTYPE_CANUPOKS = 5
XC_HARDTYPE_CANVIEX_C2K1 = 6

XC_LIN_MODE_SLAVE = 0
XC_LIN_MODE_MASTER = 1
XC_LIN_CS_AUTO = 0
XC_LIN_CS_CLASSIC = 1
XC_LIN_CS_ENHANCE = 2

XC_ERR_OK = 0
XC_ERR_DEV_NULL = 1
XC_ERR_NOT_OPEN = 2
XC_ERR_GENERAL_ERROR = 3

XC_NETPACK_TYPE_CAN = 0
XC_NETPACK_TYPE_LIN = 1
XC_NETPACK_TYPE_KWP = 2

XC_NETPACK_FLAG_TX = 0x0001
XC_NETPACK_FLAG_CAN_EXT = 0x0002
XC_NETPACK_FLAG_CAN_FDF = 0x0004
XC_NETPACK_FLAG_CAN_BRS = 0x0008
XC_NETPACK_FLAG_CAN_ESI = 0x0010
XC_NETPACK_FLAG_CAN_ERR = 0x0020
XC_NETPACK_FLAG_LIN_ASKONLY = 0x0002
XC_NETPACK_FLAG_LIN_WAKEUP = 0x0004
XC_NETPACK_FLAG_LIN_ENHCS = 0x0008

# ---------------- 结构体（C 默认对齐，无 _pack_） ----------------
class xNetpack(ctypes.Structure):
    """数据帧（152 字节：id/type/channel/flag/length/data[128]/timestamp）"""
    _fields_ = [
        ("id", c_uint),          # 0
        ("type", c_ubyte),       # 4
        ("channel", c_ubyte),    # 5
        ("flag", c_ushort),      # 6
        ("length", c_uint),      # 8
        ("data", c_ubyte * 128), # 12
        ("timestamp", c_longlong),  # 144（140 非 8 对齐，编译器补 4）
    ]

class xLinOpt(ctypes.Structure):
    """LIN 参数（16 字节）"""
    _fields_ = [
        ("brval", c_uint),       # 0 波特率 bps
        ("mode", c_ubyte),       # 4 主从模式
        ("outputV", c_ubyte),    # 5 内置 12V 输出
        ("__1", c_ubyte),        # 6
        ("__2", c_ubyte),        # 7
        ("csRx", c_ubyte),       # 8
        ("csTx", c_ubyte),       # 9
        ("csTpRx", c_ubyte),     # 10
        ("csTpTx", c_ubyte),     # 11
        ("waitrspEx", c_ushort), # 12
        ("delayEx", c_ushort),   # 14
    ]

class xLinEntry(ctypes.Structure):
    """LIN 帧属性（20 字节）"""
    _fields_ = [
        ("id", c_ubyte),         # 0
        ("channel", c_ubyte),    # 1
        ("cst", c_ubyte),        # 2 校验方式
        ("role", c_ubyte),       # 3
        ("rsp", c_ubyte),        # 4
        ("init", c_ubyte),       # 5
        ("__1", c_ubyte),        # 6
        ("__2", c_ubyte),        # 7
        ("length", c_uint),      # 8
        ("data", c_ubyte * 8),   # 12
    ]

class xLinAppoint(ctypes.Structure):
    """调度表项目（16 字节）"""
    _fields_ = [
        ("ids", c_ubyte * 8),    # 0（仅第 0 个有效）
        ("resolve", c_ubyte),    # 8
        ("type", c_ubyte),       # 9
        ("__1", c_ubyte),        # 10
        ("delay", c_uint),       # 12
    ]

# ---------------- DLL 加载 ----------------
def _find_dll():
    env = os.environ.get("F1L1_DLL_PATH", "").strip()
    if env and os.path.isfile(env):
        return env
    cands = [
        r"D:/VickCAN_x64_QT5_2.37++3/xcdevlay.1.3.8/xcdevlay.1.3.8/x64/xcdevlay.dll",
        r"C:/VickCAN_x64_QT5_2.37++3/xcdevlay.1.3.8/xcdevlay.1.3.8/x64/xcdevlay.dll",
    ]
    for p in cands:
        if os.path.isfile(p):
            return p
    return "xcdevlay.dll"  # 最后尝试系统 PATH


def _load_dll():
    dll_path = _find_dll()
    dll_dir = os.path.dirname(os.path.abspath(dll_path))
    if os.path.isdir(dll_dir):
        try:
            os.add_dll_directory(dll_dir)  # 依赖 libgcc/libstdc++/libwinpthread 同目录
        except Exception:
            pass
    dll = ctypes.WinDLL(dll_path)
    return dll


dll = _load_dll()

# ---------------- 函数原型（与头文件一致） ----------------
dll.xcdev_version.restype = c_uint
dll.xcdev_version.argtypes = []

dll.xcdev_detect.restype = c_int
dll.xcdev_detect.argtypes = [c_int]

dll.xcdev_detect_ex.restype = c_int
dll.xcdev_detect_ex.argtypes = [c_int, POINTER(c_uint)]

dll.xcdev_open.restype = c_void_p
dll.xcdev_open.argtypes = [c_int, c_int, POINTER(c_int)]

dll.xcdev_config_lin.restype = c_int
dll.xcdev_config_lin.argtypes = [c_int, POINTER(xLinOpt), c_void_p]

dll.xcdev_activity.restype = c_int
dll.xcdev_activity.argtypes = [c_void_p]

dll.xcdev_close.restype = None
dll.xcdev_close.argtypes = [c_void_p]

dll.xcdev_receive.restype = c_int
dll.xcdev_receive.argtypes = [c_int, POINTER(xNetpack), c_int, c_void_p]

dll.xcdev_transmit.restype = c_int
dll.xcdev_transmit.argtypes = [POINTER(xNetpack), c_void_p]

dll.xcdev_lin_set_entry.restype = c_int
dll.xcdev_lin_set_entry.argtypes = [POINTER(xLinEntry), c_int, c_void_p]

dll.xcdev_lin_setup_scheduler.restype = c_int
dll.xcdev_lin_setup_scheduler.argtypes = [c_int, c_int, POINTER(xLinAppoint), c_int, c_void_p]

dll.xcdev_lin_start_scheduler.restype = c_int
dll.xcdev_lin_start_scheduler.argtypes = [c_int, c_int, c_void_p]

dll.xcdev_lin_stop_scheduler.restype = c_int
dll.xcdev_lin_stop_scheduler.argtypes = [c_int, c_int, c_void_p]

dll.xcdev_lin_remove_scheduler.restype = c_int
dll.xcdev_lin_remove_scheduler.argtypes = [c_int, c_int, c_void_p]

dll.xcdev_lin_update_bytearray.restype = c_int
dll.xcdev_lin_update_bytearray.argtypes = [c_int, c_int, c_int, POINTER(c_ubyte), c_int, c_void_p]

# ---------------- 便捷构造 ----------------
def make_lin_opt(brval=19200):
    """构造 LIN 参数（默认主机模式 + 增强校验 + 内置 12V 输出）
    csTpTx 默认 CLASSIC（诊断帧 0x3C/0x3D 经典校验，Volvo LIN 项目实测）"""
    opt = xLinOpt()
    opt.brval = brval
    opt.mode = XC_LIN_MODE_MASTER
    opt.outputV = 1
    opt.csRx = XC_LIN_CS_AUTO
    opt.csTx = XC_LIN_CS_ENHANCE
    opt.csTpRx = XC_LIN_CS_AUTO
    opt.csTpTx = XC_LIN_CS_CLASSIC
    opt.waitrspEx = 0
    opt.delayEx = 0
    return opt


def version():
    """DLL 版本号（31~16 主版本 / 15~8 次版本 / 7~0 修正）"""
    v = dll.xcdev_version()
    return "%d.%d.%d" % ((v >> 16) & 0xFFFF, (v >> 8) & 0xFF, v & 0xFF)


def detect(hardtype=XC_HARDTYPE_CANVIEX_F1L1):
    """返回指定类型已连接设备数量（0 = 无设备）"""
    return dll.xcdev_detect(hardtype)
