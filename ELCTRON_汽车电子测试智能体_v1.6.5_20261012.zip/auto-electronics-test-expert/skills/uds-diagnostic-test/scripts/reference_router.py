"""Select the smallest useful reference set for a test task."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any


DEFAULT_RG = Path(r"C:\Users\80026384\AppData\Local\OpenAI\Codex\bin\53c73f34a40c42be\rg.exe")


def _read_text(path: Path) -> str:
    """Read normal UTF-8, with the project DLP/rg fallback for encrypted files."""
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        rg = shutil.which("rg") or str(DEFAULT_RG)
        completed = subprocess.run(
            [rg, "-a", "--passthru", "-N", "--no-heading", ".", str(path)],
            check=True,
            capture_output=True,
        )
        return completed.stdout.decode("utf-8")


class ReferenceRouter:
    """Resolve a task description to one primary branch and minimal assets."""

    def __init__(self, route_file: str | Path):
        self.route_file = Path(route_file)
        payload = json.loads(_read_text(self.route_file))
        self.branches = {item["id"]: item for item in payload["branches"]}
        self.routes = payload["routes"]

    @staticmethod
    def _normalize_bus(bus: str | None) -> str | None:
        if not bus:
            return None
        normalized = bus.strip().upper().replace("_", "-")
        if normalized in {"CANFD", "CAN-FD"}:
            return "CAN-FD"
        if normalized in {"CAN", "LIN"}:
            return normalized
        raise ValueError(f"unsupported bus: {bus}")

    @staticmethod
    def _infer_bus(text: str) -> str | None:
        upper = text.upper()
        if "LIN" in upper or "NAD" in upper or "0X3C" in upper or "0X3D" in upper:
            return "LIN"
        if "CANFD" in upper or "CAN-FD" in upper:
            return "CAN-FD"
        if "CAN" in upper:
            return "CAN"
        return None

    def resolve(self, task: str, bus: str | None = None) -> dict[str, Any]:
        if not task or not task.strip():
            raise ValueError("task must not be empty")

        task_bus = self._normalize_bus(bus) or self._infer_bus(task)
        lowered = task.casefold()
        scored = []
        for order, route in enumerate(self.routes):
            keywords = [*route.get("aliases", []), *route["when"]]
            matches = [keyword for keyword in keywords if keyword.casefold() in lowered]
            if matches:
                scored.append((len(matches), -order, route, matches))
        if not scored:
            raise LookupError("no reference route matched the task")

        _, _, route, matches = max(scored, key=lambda item: (item[0], item[1]))
        primary = route["primary"]
        secondary: list[str] = []
        selected_secondary = route.get("secondary_by_bus", {}).get(task_bus)
        if selected_secondary and selected_secondary != primary:
            secondary.append(selected_secondary)
        companion = route.get("application_companion")
        if companion and companion != primary and companion not in secondary:
            secondary.append(companion)

        mounted_assets = list(route.get("required_assets", []))
        for branch_id in [primary, *secondary]:
            branch = self.branches[branch_id]
            index = branch["index"]
            if index not in mounted_assets:
                mounted_assets.insert(0, index)
            if branch_id in secondary:
                companion_asset = branch["canonical_assets"][0]
                if companion_asset not in mounted_assets:
                    mounted_assets.append(companion_asset)

        return {
            "route_id": route["id"],
            "matched_keywords": matches,
            "bus": task_bus,
            "primary_branch": primary,
            "secondary_branches": secondary,
            "mounted_assets": mounted_assets,
            "optional_assets": list(route.get("optional_assets", [])),
        }


def main() -> int:
    parser = argparse.ArgumentParser(description="Resolve expert reference assets for a task")
    parser.add_argument("task", help="task description")
    parser.add_argument("--bus", choices=["CAN", "CAN-FD", "LIN"], help="explicit bus override")
    parser.add_argument(
        "--routes",
        default=str(Path(__file__).resolve().parents[3] / "references" / "reference-routing.json"),
        help="routing JSON path",
    )
    args = parser.parse_args()
    result = ReferenceRouter(args.routes).resolve(args.task, args.bus)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
