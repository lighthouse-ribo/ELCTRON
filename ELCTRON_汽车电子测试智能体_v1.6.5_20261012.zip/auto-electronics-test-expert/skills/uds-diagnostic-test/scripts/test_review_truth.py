#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""review_truth.py（差分审查独立真值层）的离线回归测试。

不连接硬件，不 import gen_case_scripts —— 验证审查真值层是独立实现：
1. 协议不变量：非法 SID / 正响应 SID 规则 / 负响应帧 SID 一致性 / NRC 值域
2. 项目数据层：parsed.json 交叉校验（DID 存在性 / 0x2E 只读冲突 / 空 parsed 跳过）
3. 证据提取：payload / session / pre_action / expect 类型的独立推导
"""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import review_truth as rt  # noqa: E402


class TestProtocolIssues(unittest.TestCase):
    """协议不变量校验（与生成器无关的 ISO 14229 规则）"""

    def test_valid_service_sid_passes(self):
        # 0x22 读 DID，正例：SID 合法，无响应帧断言 → 无 ERROR
        issues = rt.protocol_issues([0x22, 0xF1, 0x90], "pos", [], [])
        self.assertEqual([lvl for lvl, _ in issues if lvl == "ERROR"], [])

    def test_non_uds_sid_is_error(self):
        # 脚本 PAYLOAD 首字节不是合法 UDS 服务 SID → ERROR（协议层兜底）
        issues = rt.protocol_issues([0x02, 0x10], "pos", [], [])
        self.assertTrue(any(lvl == "ERROR" for lvl, _ in issues), issues)

    def test_positive_prefix_sid_rule(self):
        # 正响应前缀首字节必须是 请求SID + 0x40：0x22 → 0x62
        issues = rt.protocol_issues([0x22, 0xF1, 0x90], "pos", [], [0x62, 0xF1, 0x90])
        self.assertEqual([lvl for lvl, _ in issues if lvl == "ERROR"], [])
        # 写错成 0x63 → ERROR
        issues = rt.protocol_issues([0x22, 0xF1, 0x90], "pos", [], [0x63, 0xF1, 0x90])
        self.assertTrue(any(lvl == "ERROR" for lvl, _ in issues), issues)

    def test_negative_prefix_sid_must_match_request(self):
        # 负响应帧 7F <请求SID> <NRC>：第二位必须等于请求 SID
        issues = rt.protocol_issues([0x22, 0xF1, 0x90], "neg", [0x31], [0x7F, 0x22, 0x31])
        self.assertEqual([lvl for lvl, _ in issues if lvl == "ERROR"], [])
        # 第二位写成 0x2E（与请求 SID 不符）→ ERROR
        issues = rt.protocol_issues([0x22, 0xF1, 0x90], "neg", [0x31], [0x7F, 0x2E, 0x31])
        self.assertTrue(any(lvl == "ERROR" for lvl, _ in issues), issues)

    def test_nrc_value_out_of_range_is_error(self):
        # NRC 值域校验：0x10~0x7F 合法；0x00 非法
        issues = rt.protocol_issues([0x10, 0x03], "neg", [0x12], [])
        self.assertEqual([lvl for lvl, _ in issues if lvl == "ERROR"], [])
        issues = rt.protocol_issues([0x10, 0x03], "neg", [0x00], [])
        self.assertTrue(any(lvl == "ERROR" for lvl, _ in issues), issues)


class TestParsedIssues(unittest.TestCase):
    """parsed.json 交叉校验（独立于需求文本的第三真值源）"""

    def test_empty_parsed_skips_data_checks(self):
        # parsed={}（测试/无调查表场景）→ 不做存在性校验，不误杀
        issues = rt.parsed_issues([0x22, 0xF1, 0x90], "default", {}, "pos")
        self.assertEqual(issues, [])

    def test_unknown_did_is_review_required(self):
        # parsed 提供 dids 列表但缺 F190 → 需求引用了调查表外 DID → 人工复核
        parsed = {"dids": [{"did_number": "0xF12E", "rw_state": "RW"}]}
        issues = rt.parsed_issues([0x22, 0xF1, 0x90], "default", parsed, "pos")
        self.assertTrue(any(lvl == "REVIEW_REQUIRED" for lvl, _ in issues), issues)

    def test_readonly_did_write_positive_is_error(self):
        # 0x2E 写正例 + 调查表只读 DID → 需求与调查表硬冲突 → ERROR
        parsed = {"dids": [{"did_number": "0xF10A", "rw_state": "R"}]}
        issues = rt.parsed_issues([0x2E, 0xF1, 0x0A, 0x01], "extended", parsed, "pos")
        self.assertTrue(any(lvl == "ERROR" for lvl, _ in issues), issues)

    def test_known_did_passes(self):
        parsed = {"dids": [{"did_number": "0xF190", "rw_state": "RW"}]}
        issues = rt.parsed_issues([0x22, 0xF1, 0x90], "default", parsed, "pos")
        self.assertEqual(issues, [])

    def test_defaulted_readonly_write_positive_is_review_not_error(self):
        # 反馈 L3/L5：调查表缺读写列 → 解析器默认 rw_state=R 并登记 defaults_used。
        # 0x2E 写入正例对"默认只读"只应降级为 REVIEW_REQUIRED（可写性需人工确认），
        # 不得判 ERROR 硬冲突——否则缺列调查表下所有写正例都被误杀成真错误。
        parsed = {
            "dids": [{"did_number": "0xF10A", "rw_state": "R"}],
            "defaults_used": [{
                "did": "0xF10A", "name": "测试DID",
                "defaults": [("rw_state", "R"), ("read_sessions", "CDD无会话权限信息，默认仅default可读(Y)")],
            }],
        }
        issues = rt.parsed_issues([0x2E, 0xF1, 0x0A, 0x01], "extended", parsed, "pos")
        self.assertFalse(any(lvl == "ERROR" for lvl, _ in issues), issues)
        self.assertTrue(
            any(lvl == "REVIEW_REQUIRED" and "读写列缺失" in detail for lvl, detail in issues),
            issues)

    def test_real_readonly_write_positive_stays_error(self):
        # 调查表真实标记只读（defaults_used 无该 DID）→ 与 0x2E 写正例硬冲突 ERROR
        parsed = {
            "dids": [{"did_number": "0xF10A", "rw_state": "R"}],
            "defaults_used": [{"did": "0xF10B", "defaults": [("rw_state", "R")]}],
        }
        issues = rt.parsed_issues([0x2E, 0xF1, 0x0A, 0x01], "extended", parsed, "pos")
        self.assertTrue(any(lvl == "ERROR" for lvl, _ in issues), issues)

    def test_known_rid_with_leading_zero_passes(self):
        # 回归：RID 带前导零（0x0206）时，norm 后应与调查表 routine_id 匹配，
        # 不得误报"调查表外 RID"（norm 会剥掉前导 0，比较两侧都必须 norm）。
        # dids 非空使 parsed_issues 进入 RID 分支（空 dids 会提前返回跳过校验）。
        parsed = {"dids": [{"did_number": "0xF186", "rw_state": "RW"}],
                  "routines": [{"routine_id": "0x0206"}, {"routine_id": "0x0231"}]}
        issues = rt.parsed_issues([0x31, 0x01, 0x02, 0x06], "default", parsed, "pos")
        self.assertEqual(issues, [])

    def test_known_all_zero_did_passes(self):
        # 回归：DID 0x0000（非法保留对象，负例测试）norm 后为 "0"，
        # 比较两侧都必须 norm，不得误报"调查表外 DID"。
        parsed = {"dids": [{"did_number": "0x0000", "rw_state": "R"}]}
        issues = rt.parsed_issues([0x22, 0x00, 0x00], "default", parsed, "neg")
        self.assertEqual(issues, [])


class TestPayloadCandidates(unittest.TestCase):
    """从 procedure 文本独立提取请求 payload 证据（防漂移层，非精确重算）"""

    def test_can_raw_payload(self):
        cands = rt.payload_candidates("请求: 22 F1 90", "can", 0x51)
        self.assertIn([0x22, 0xF1, 0x90], cands)

    def test_can_iso_tp_single_frame_pci_stripped(self):
        # CAN ISO-TP 单帧 "02 10 03"（PCI 长度 2 + SID 0x10 + 子功能）→ 剥 PCI
        cands = rt.payload_candidates("发送 02 10 03", "can", 0x51)
        self.assertIn([0x10, 0x03], cands)

    def test_lin_full_frame_strips_nad_and_pci(self):
        # LIN 完整单帧 51 02 10 03 FF FF FF FF → 去 NAD+PCI → [10 03]
        cands = rt.payload_candidates("51 02 10 03 FF FF FF FF", "lin", 0x51)
        self.assertIn([0x10, 0x03], cands)

    def test_rid_label_not_mistaken_for_payload(self):
        # "RID 0206" 的 0206 首字节 0x02 不是合法 SID → 不应成为 payload 证据
        cands = rt.payload_candidates("1. 先启动 RID 0206；\n2. 请求例程结果：31 03 02 06", "can", 0x51)
        self.assertNotIn([0x02, 0x06], cands)
        self.assertIn([0x31, 0x03, 0x02, 0x06], cands)

    def test_zero_x_text_without_frame_yields_no_candidates(self):
        # "0x22 读取 DID F190" 无完整帧证据 → 空候选（不阻断，靠协议层兜底）
        cands = rt.payload_candidates("0x22 读取 DID F190", "can", 0x51)
        self.assertEqual(cands, [])

    def test_zero_x_annotation_with_frame_is_extracted(self):
        # 反馈 L6：含 '0x' 标注与帧同行的行不再整行跳过
        cands = rt.payload_candidates("在扩展会话(0x03)下请求: 22 F1 90", "can", 0x51)
        self.assertIn([0x22, 0xF1, 0x90], cands)

    def test_zero_x_annotated_nad_prefix_still_extracts(self):
        # "NAD 0x51 发送 22 F1 90"：0x 标注的 NAD 挤在帧前，清洗后仍须提取到帧
        cands = rt.payload_candidates("NAD 0x51 发送 22 F1 90", "lin", 0x51)
        self.assertIn([0x22, 0xF1, 0x90], cands)

    def test_annotation_only_line_still_yields_nothing(self):
        # 纯标注行（无完整帧）不得因清洗产生虚假证据
        cands = rt.payload_candidates("目标会话为 0x03（扩展），使用 DID 0xF190", "can", 0x51)
        self.assertEqual(cands, [])

    def test_annotated_full_frame_line_is_deduplicated(self):
        # 原行与清洗行都命中同一帧时只保留一条证据
        cands = rt.payload_candidates("请求: 22 F1 90（DID 0xF190）", "can", 0x51)
        self.assertEqual(cands.count([0x22, 0xF1, 0x90]), 1)


class TestSessionCandidates(unittest.TestCase):
    """会话证据：precondition + procedure 关键词 → 候选会话集"""

    def test_from_precondition(self):
        self.assertIn("extended", rt.session_candidates("扩展会话", ""))
        self.assertIn("programming", rt.session_candidates("编程会话", ""))
        self.assertIn("default", rt.session_candidates("默认会话", ""))

    def test_from_procedure_step(self):
        # procedure 显式"进入编程会话" → 候选含 programming（可覆盖前置）
        cands = rt.session_candidates("默认会话", "请求进入编程会话")
        self.assertIn("programming", cands)

    def test_no_keyword_defaults_to_default(self):
        self.assertEqual(rt.session_candidates("", ""), {"default"})


class TestPreActionCandidates(unittest.TestCase):
    """0x31 前置例程证据提取"""

    def test_start_rid_detected(self):
        cands = rt.pre_action_candidates("1. 先启动 RID 0206；\n2. 请求例程结果：31 03 02 06")
        self.assertIn([0x31, 0x01, 0x02, 0x06], cands)

    def test_no_start_no_actions(self):
        self.assertEqual(rt.pre_action_candidates("请求: 31 03 02 06"), [])


class TestExpectTypeEvidence(unittest.TestCase):
    """期望类型轻量证据：需求文本关键词 ↔ 脚本 EXPECT 的一致性"""

    def test_negative_wording_requires_neg(self):
        self.assertEqual(rt.expect_type_evidence("负响应 NRC=0x13", ""), {"neg"})

    def test_positive_wording_requires_pos(self):
        self.assertEqual(rt.expect_type_evidence("正响应", ""), {"pos"})

    def test_no_response_wording_requires_none(self):
        self.assertEqual(rt.expect_type_evidence("抑制正响应", ""), {"none"})

    def test_ambiguous_wording_yields_no_evidence(self):
        # "响应内容由项目确认" 无明确关键词 → 空证据（不阻断，走状态机）
        self.assertEqual(rt.expect_type_evidence("响应内容由项目确认", ""), set())


class TestDidRidExtraction(unittest.TestCase):
    def test_did_from_read_write(self):
        self.assertEqual(rt.did_rid_from_payload([0x22, 0xF1, 0x90]), ("F190", None))
        self.assertEqual(rt.did_rid_from_payload([0x2E, 0xF1, 0x0A, 0x01]), ("F10A", None))

    def test_rid_from_routine(self):
        self.assertEqual(rt.did_rid_from_payload([0x31, 0x01, 0x02, 0x06]), (None, "0206"))

    def test_none_for_other_services(self):
        self.assertEqual(rt.did_rid_from_payload([0x10, 0x03]), (None, None))


if __name__ == "__main__":
    unittest.main(verbosity=2)
