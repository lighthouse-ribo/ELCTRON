#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第八步：project-pack 接入 uds_runner 的离线回归测试。"""

import hashlib
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from testsupport import WorkspaceTempDir  # noqa: E402
from uds_runner import (  # noqa: E402
    PortablePackError,
    project,
    resolve_project_pack_inputs,
)


def test_tempdir():
    return WorkspaceTempDir("project-pack")


def write_file(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest_entry(file_id, role, relative_path, partition, sha256):
    return {
        "id": file_id,
        "role": role,
        "path": relative_path,
        "partition": partition,
        "sha256": sha256,
        "sensitivity": "internal",
        "authority": "project",
    }


class TestProjectPackRunner(unittest.TestCase):
    def make_pack(self):
        temp_dir = test_tempdir()
        self.addCleanup(temp_dir.cleanup)
        root = Path(temp_dir.name)
        survey_rel = "diagnostic/APP/survey.json"
        survey = json.dumps({
            "dids": [{"did_number": "F190"}],
            "io_controls": [],
            "routines": [],
            "dtcs": [],
            "can_config": {},
            "defaults_used": [],
            "missing_attributes": [],
        })
        survey_sha = write_file(root / survey_rel, survey)
        config_rel = "project_config.json"
        config_sha = write_file(root / config_rel, "{}")
        manifest = {
            "$schema": "portable-contract/v0.1",
            "schema_version": "portable-contract/v0.1",
            "project": {"id": "runner-test", "bus": "CAN"},
            "partitions": ["APP", "PBL", "SBL", "shared"],
            "files": [
                manifest_entry("survey-app", "diag_survey", survey_rel, "APP", survey_sha),
                manifest_entry("project-config", "project_config", config_rel, "shared", config_sha),
            ],
        }
        manifest_path = root / "input_manifest.json"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
        return root, manifest_path, survey

    def test_pack_selects_partitioned_survey_and_config(self):
        root, manifest_path, _ = self.make_pack()

        inputs = resolve_project_pack_inputs(root, "APP")

        self.assertEqual(Path(inputs["manifest_path"]), manifest_path.resolve())
        self.assertEqual(Path(inputs["survey"]), (root / "diagnostic/APP/survey.json").resolve())
        self.assertEqual(Path(inputs["project_config"]), (root / "project_config.json").resolve())

    def test_multiple_surveys_require_partition(self):
        root, manifest_path, _ = self.make_pack()
        pbl_rel = "diagnostic/PBL/survey.json"
        pbl_sha = write_file(root / pbl_rel, "{}")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["files"].append(
            manifest_entry("survey-pbl", "diag_survey", pbl_rel, "PBL", pbl_sha)
        )
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

        with self.assertRaises(PortablePackError):
            resolve_project_pack_inputs(root)
        selected = resolve_project_pack_inputs(root, "PBL")
        self.assertEqual(Path(selected["survey"]), (root / pbl_rel).resolve())

    def test_project_uses_pack_context_without_mutating_pack(self):
        root, manifest_path, survey = self.make_pack()
        output_dir = root / "run-output"

        def fake_parser(input_path, output_path):
            self.assertEqual(Path(input_path), (root / "diagnostic/APP/survey.json").resolve())
            data = json.loads(survey)
            data["can_config"] = {
                "tx_id": "0x7E0", "rx_id": "0x7E8", "bitrate": 500000,
            }
            Path(output_path).write_text(json.dumps(data), encoding="utf-8")
            return True

        with patch("uds_runner.run_parser", side_effect=fake_parser), \
                patch("uds_runner.run_generator", return_value=True), \
                patch("uds_runner.run_script_compile", return_value=True), \
                patch("uds_runner.detect_hardware_state", return_value=([], 0, 0)):
            self.assertTrue(project("", str(output_dir), project_pack=str(manifest_path), confirmed=True))

        context_files = list(output_dir.glob("project_context_*.json"))
        self.assertEqual(len(context_files), 1)
        context = json.loads(context_files[0].read_text(encoding="utf-8"))
        self.assertTrue(any(fact["id"].startswith("diagnostic.APP.survey-app")
                            for fact in context["facts"]))
        effective_files = list(output_dir.glob("effective_config_*.json"))
        self.assertEqual(len(effective_files), 1)
        effective = json.loads(effective_files[0].read_text(encoding="utf-8"))
        binding = effective["project_context_binding"]
        self.assertEqual(
            binding["project_context"]["sha256"],
            hashlib.sha256(context_files[0].read_bytes()).hexdigest(),
        )
        gate_files = list(output_dir.glob("project_capability_generation_*.json"))
        self.assertEqual(len(gate_files), 1)
        self.assertEqual(json.loads(gate_files[0].read_text(encoding="utf-8"))["state"], "READY")
        flow_files = list(output_dir.glob("flow_context_*.json"))
        self.assertEqual(len(flow_files), 1)
        flow_context = json.loads(flow_files[0].read_text(encoding="utf-8"))
        self.assertIn(str(context_files[0]), flow_context["source_files"])
        self.assertIn(str(gate_files[0]), flow_context["source_files"])
        self.assertTrue(manifest_path.is_file())
        self.assertFalse((root / "project_context.json").exists())

    def test_blocked_context_stops_generation_before_parser(self):
        root, manifest_path, _ = self.make_pack()
        survey_path = root / "diagnostic/APP/survey.json"
        survey_path.write_text("not valid survey input", encoding="utf-8")
        output_dir = root / "blocked-output"

        with patch("uds_runner.run_parser") as parser:
            self.assertFalse(project("", str(output_dir), project_pack=str(manifest_path), confirmed=True))
        parser.assert_not_called()
        gate_files = list(output_dir.glob("project_capability_generation_*.json"))
        self.assertEqual(len(gate_files), 1)
        gate = json.loads(gate_files[0].read_text(encoding="utf-8"))
        self.assertEqual(gate["state"], "BLOCKED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
