#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""script_review.py 的离线回归测试（不连接 CAN/LIN 硬件）。"""
import json
import os
import subprocess
import sys
import unittest
from testsupport import WorkspaceTempDir

HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.path.join(HERE, "gen_case_scripts.py")
REVIEW = os.path.join(HERE, "script_review.py")

# 顶层 import：只 import 脚本本身（纯离线依赖），不 import gen_case_scripts。
sys.path.insert(0, HERE)
import script_review as sr  # noqa: E402
def generate(cases, project_config=None):
    td = WorkspaceTempDir("review")
    cases_path = os.path.join(td.name, "cases.json")
    parsed_path = os.path.join(td.name, "parsed.json")
    out_dir = os.path.join(td.name, "case_scripts")
    with open(cases_path, "w", encoding="utf-8") as f:
        json.dump({"cases": cases}, f, ensure_ascii=False)
    with open(parsed_path, "w", encoding="utf-8") as f:
        json.dump({}, f)
    if project_config is not None:
        config_path = os.path.join(td.name, "project_config.json")
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(project_config, f, ensure_ascii=False)
        td.project_config_path = config_path
    result = subprocess.run(
        [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
         "--bus", "can", "--out-dir", out_dir, "--confirmed"]
        + (["--project-config", td.project_config_path] if project_config is not None else []),
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    return td, cases_path, parsed_path, out_dir, result


class TestScriptReview(unittest.TestCase):
    def test_reviews_mapping_and_generated_protocol_metadata(self):
        cases = [{
            "case_id": "UDS_0x22_TC_REVIEW",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        report = os.path.join(td.name, "script_review.json")
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can", "--out", report],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 0, reviewed.stderr)
        with open(report, encoding="utf-8") as f:
            data = json.load(f)
        self.assertEqual(data["status"], "PASS")
        self.assertEqual(data["summary"]["errors"], 0)
        self.assertEqual(data["cases"][0]["status"], "PASS")

    def test_custom_project_session_config_is_used_by_review(self):
        config = {
            "project": "custom-session-project",
            "transport": {"physical_nad": "0x60"},
            "sessions": {
                "supported": ["0x01", "0x04"],
                "names": {"0x01": "Normal", "0x04": "Diagnostic"},
                "default": "0x01",
                "allowed_transitions": {"0x01": ["0x01", "0x04"], "0x04": ["0x01", "0x04"]},
                "s3_required": ["0x04"],
            },
        }
        cases = [{
            "case_id": "UDS_0x10_TC_CUSTOM_SESSION",
            "test_point": "进入 Diagnostic 会话",
            "procedure": "请求: 10 04",
            "expected": "正响应",
            "precondition": "Normal",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases, config)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        report = os.path.join(td.name, "script_review_custom.json")
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can",
             "--project-config", td.project_config_path, "--out", report],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 0, reviewed.stdout + reviewed.stderr)
        with open(report, encoding="utf-8") as f:
            data = json.load(f)
        self.assertEqual(data["status"], "PASS")
        self.assertEqual(data["summary"]["errors"], 0)
        with open(os.path.join(out_dir, "manifest.json"), encoding="utf-8") as f:
            manifest = json.load(f)
        self.assertEqual(manifest["project"], "custom-session-project")
        self.assertEqual(
            manifest["project_config"], os.path.abspath(td.project_config_path)
        )
        self.assertEqual(
            manifest["cases"]["UDS_0x10_TC_CUSTOM_SESSION"]["project_config"],
            os.path.abspath(td.project_config_path),
        )
        script_path = os.path.join(out_dir, "case_UDS_0x10_TC_CUSTOM_SESSION.py")
        with open(script_path, encoding="utf-8") as f:
            generated_text = f.read()
        self.assertIn("and (int(payload[1]) & 0x7F) in S3_SESSION_IDS", generated_text)

    def test_detects_payload_drift_before_hardware_execution(self):
        cases = [{
            "case_id": "UDS_0x10_TC_DRIFT",
            "test_point": "进入扩展会话",
            "procedure": "请求: 10 03",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script = os.path.join(out_dir, "case_UDS_0x10_TC_DRIFT.py")
        with open(script, encoding="utf-8") as f:
            text = f.read()
        text = text.replace("PAYLOAD = [16, 3]", "PAYLOAD = [16, 2]")
        with open(script, "w", encoding="utf-8") as f:
            f.write(text)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("ERROR", reviewed.stdout)

    def test_missing_key_is_case_blocked_but_not_script_error(self):
        cases = [{
            "case_id": "UDS_0x27_TC_KEY",
            "test_point": "发送正确 Key",
            "procedure": "请求: 27 02 + 16字节数据",
            "expected": "正响应",
            "precondition": "编程会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        report = os.path.join(td.name, "script_review.json")
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can", "--out", report],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 0, reviewed.stderr)
        with open(report, encoding="utf-8") as f:
            data = json.load(f)
        self.assertEqual(data["status"], "PASS")
        self.assertEqual(data["cases"][0]["status"], "BLOCKED")

    def test_skip_case_does_not_require_runtime_expectation_evidence(self):
        cases = [{
            "case_id": "UDS_0x27_TC_SKIP_GATE",
            "test_point": "发送正确 Key",
            "procedure": "请求: 27 02 00 00",
            "expected": "正响应",
            "precondition": "编程会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        # Regenerate with the service explicitly excluded, matching the
        # hardware run requested by the user.
        generated = subprocess.run(
            [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
             "--bus", "can", "--out-dir", out_dir, "--confirmed",
             "--exclude-service", "0x27"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(generated.returncode, 0, generated.stderr)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 0, reviewed.stdout + reviewed.stderr)

    def test_explicitly_excluded_case_is_reviewed_as_skip(self):
        cases = [{
            "case_id": "UDS_0x27_TC_EXCLUDED",
            "test_point": "请求 Seed",
            "procedure": "请求：27 05",
            "expected": "正响应",
            "precondition": "扩展会话",
        }]
        td = WorkspaceTempDir("review-skip")
        self.addCleanup(td.cleanup)
        cases_path = os.path.join(td.name, "cases.json")
        parsed_path = os.path.join(td.name, "parsed.json")
        out_dir = os.path.join(td.name, "case_scripts")
        with open(cases_path, "w", encoding="utf-8") as f:
            json.dump({"cases": cases}, f, ensure_ascii=False)
        with open(parsed_path, "w", encoding="utf-8") as f:
            json.dump({}, f)
        generated = subprocess.run(
            [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
             "--out-dir", out_dir, "--bus", "can", "--confirmed",
             "--exclude-service", "0x27"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(generated.returncode, 0, generated.stderr)
        report = os.path.join(td.name, "script_review.json")
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can", "--out", report],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 0, reviewed.stdout + reviewed.stderr)
        data = json.load(open(report, encoding="utf-8"))
        self.assertEqual(data["status"], "PASS")
        self.assertEqual(data["cases"][0]["status"], "SKIP")

    def test_unclassified_expectation_requires_review(self):
        cases = [{
            "case_id": "UDS_0x22_TC_AMBIGUOUS",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "响应内容由项目确认",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 3, reviewed.stdout + reviewed.stderr)
        self.assertIn("REVIEW_REQUIRED", reviewed.stdout)

    def test_conditional_positive_negative_expectation_requires_review(self):
        cases = [{
            "case_id": "UDS_0x31_TC_BRANCH",
            "test_point": "例程保护探测",
            "procedure": "请求: 31 01 02 06",
            "expected": "若例程受保护：负响应 7F 31 33；若不受保护：正常响应",
            "precondition": "扩展会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 3, reviewed.stdout + reviewed.stderr)

    def test_duplicate_script_mapping_is_error(self):
        # OP-03：manifest 两个用例映射同一脚本，破坏 1:1 约束，必须 ERROR。
        cases = [
            {"case_id": "UDS_0x22_TC_A", "test_point": "读取 DID",
             "procedure": "请求: 22 F1 90", "expected": "正响应", "precondition": "默认会话"},
            {"case_id": "UDS_0x22_TC_B", "test_point": "读取 DID",
             "procedure": "请求: 22 F1 91", "expected": "正响应", "precondition": "默认会话"},
        ]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        manifest_path = os.path.join(out_dir, "manifest.json")
        with open(manifest_path, encoding="utf-8") as f:
            manifest = json.load(f)
        shared = manifest["cases"]["UDS_0x22_TC_A"]["script"]
        manifest["cases"]["UDS_0x22_TC_B"]["script"] = shared
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("同一脚本", reviewed.stdout)

    def test_pre_actions_drift_is_error(self):
        # OP-02：脚本 PRE_ACTIONS 与需求重解析（先启动 RID 0206）不一致必须 ERROR。
        cases = [{
            "case_id": "UDS_0x31_TC_PRE",
            "test_point": "例程结果未解锁负例",
            "procedure": "1. 先启动 RID 0206；\n2. 请求例程结果：31 03 02 06",
            "expected": "负响应 NRC=0x33",
            "precondition": "扩展会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script = os.path.join(out_dir, "case_UDS_0x31_TC_PRE.py")
        with open(script, encoding="utf-8") as f:
            text = f.read()
        self.assertIn("PRE_ACTIONS = [[49, 1, 2, 6]]", text)
        text = text.replace("PRE_ACTIONS = [[49, 1, 2, 6]]", "PRE_ACTIONS = []")
        with open(script, "w", encoding="utf-8") as f:
            f.write(text)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("PRE_ACTIONS", reviewed.stdout)

    def test_can_runtime_path_missing_is_error(self):
        # OP-02：CAN 运行时依赖路径不存在必须 ERROR。
        cases = [{
            "case_id": "UDS_0x22_TC_RUNTIME",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script = os.path.join(out_dir, "case_UDS_0x22_TC_RUNTIME.py")
        with open(script, encoding="utf-8") as f:
            text = f.read()
        text = text.replace("CAN_RUNTIME = ''", "CAN_RUNTIME = 'C:/nonexistent/uds_test.py'")
        with open(script, "w", encoding="utf-8") as f:
            f.write(text)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("CAN 运行时脚本不存在", reviewed.stdout)

    def test_classic_can_fd_false_consistency(self):
        # OP-02：Classic CAN（未传 --can-fd）时脚本 CAN_FD 必须为 False。
        cases = [{
            "case_id": "UDS_0x10_TC_FD",
            "test_point": "进入扩展会话",
            "procedure": "请求: 10 03",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script = os.path.join(out_dir, "case_UDS_0x10_TC_FD.py")
        with open(script, encoding="utf-8") as f:
            text = f.read()
        self.assertIn("CAN_FD = False", text)
        text = text.replace("CAN_FD = False", "CAN_FD = True")
        with open(script, "w", encoding="utf-8") as f:
            f.write(text)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("CAN_FD", reviewed.stdout)

    def test_review_rejects_missing_keepalive_contract_for_10_03(self):
        cases = [{
            "case_id": "UDS_0x10_TC_KEEPALIVE_REVIEW",
            "test_point": "进入扩展会话",
            "procedure": "请求: 10 03",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script = os.path.join(out_dir, "case_UDS_0x10_TC_KEEPALIVE_REVIEW.py")
        with open(script, encoding="utf-8") as f:
            text = f.read()
        text = text.replace("KEEP_ALIVE_REQUIRED = True", "KEEP_ALIVE_REQUIRED = False")
        with open(script, "w", encoding="utf-8") as f:
            f.write(text)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "lin"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("KEEP_ALIVE_REQUIRED", reviewed.stdout)

    def test_review_rejects_session_route_drift(self):
        cases = [{
            "case_id": "UDS_0x22_TC_SESSION_ROUTE_REVIEW",
            "test_point": "编程会话读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "编程会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script = os.path.join(out_dir, "case_UDS_0x22_TC_SESSION_ROUTE_REVIEW.py")
        with open(script, encoding="utf-8") as f:
            text = f.read()
        text = text.replace("SESSION_SETUP_ROUTE = [2]", "SESSION_SETUP_ROUTE = [3, 2]")
        with open(script, "w", encoding="utf-8") as f:
            f.write(text)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("SESSION_SETUP_ROUTE", reviewed.stdout)

    def test_review_accepts_direct_default_to_programming(self):
        cases = [{
            "case_id": "UDS_0x10_TC_DEFAULT_TO_PROGRAMMING_REVIEW",
            "test_point": "正向：默认会话直接切换到编程会话",
            "procedure": "请求: 10 02",
            "expected": "DUT正响应：50 02",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script = os.path.join(out_dir, "case_UDS_0x10_TC_DEFAULT_TO_PROGRAMMING_REVIEW.py")
        with open(script, encoding="utf-8") as f:
            text = f.read()
        self.assertIn("SESSION_SETUP_ROUTE = []", text)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 0, reviewed.stdout + reviewed.stderr)

    def test_empty_serial_consistency(self):
        # OP-02：未指定序列号时脚本 CAN_SERIAL 必须为空（不凭空绑定设备）。
        cases = [{
            "case_id": "UDS_0x10_TC_SERIAL",
            "test_point": "进入扩展会话",
            "procedure": "请求: 10 03",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        script = os.path.join(out_dir, "case_UDS_0x10_TC_SERIAL.py")
        with open(script, encoding="utf-8") as f:
            text = f.read()
        self.assertIn("CAN_SERIAL = ''", text)
        text = text.replace("CAN_SERIAL = ''", "CAN_SERIAL = 'VN123'")
        with open(script, "w", encoding="utf-8") as f:
            f.write(text)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("CAN_SERIAL", reviewed.stdout)


class TestProtocolTruthLayer(unittest.TestCase):
    """P1-2：生成后审查的协议真值层（ISO 14229 服务白名单 / 结构下限 / 长度）。"""

    def _review(self, cases, parsed=None):
        td = WorkspaceTempDir("truth")
        self.addCleanup(td.cleanup)
        cases_path = os.path.join(td.name, "cases.json")
        parsed_path = os.path.join(td.name, "parsed.json")
        out_dir = os.path.join(td.name, "case_scripts")
        with open(cases_path, "w", encoding="utf-8") as f:
            json.dump({"cases": cases}, f, ensure_ascii=False)
        with open(parsed_path, "w", encoding="utf-8") as f:
            json.dump(parsed or {}, f, ensure_ascii=False)
        generated = subprocess.run(
            [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
             "--bus", "can", "--out-dir", out_dir, "--confirmed"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(generated.returncode, 0, generated.stderr)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        return reviewed

    def test_positive_short_write_request_is_error(self):
        # 0x2E 正例无数据字节 → 结构下限 ERROR，阻断交付。
        reviewed = self._review([{
            "case_id": "UDS_0x2E_TC_SHORT",
            "test_point": "写入 DID 正向",
            "procedure": "请求: 2E F1 0A",
            "expected": "正响应",
            "precondition": "默认会话",
        }])
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("请求过短", reviewed.stdout)

    def test_positive_unknown_standard_sid_requires_review(self):
        # 0x12 未在 ISO 14229 登记；正例使用需人工确认（REVIEW_REQUIRED）。
        reviewed = self._review([{
            "case_id": "UDS_0x12_TC_UNKNOWN",
            "test_point": "未登记服务正向",
            "procedure": "请求: 12 01",
            "expected": "正响应",
            "precondition": "默认会话",
        }])
        self.assertEqual(reviewed.returncode, 3, reviewed.stdout + reviewed.stderr)
        self.assertIn("未登记标准服务", reviewed.stdout)

    def test_supplier_specific_sid_is_not_flagged(self):
        # 0x82（供应商自定义段）无法用标准协议真值校验，不得误报。
        reviewed = self._review([{
            "case_id": "UDS_0x82_TC_SUPPLIER",
            "test_point": "供应商自定义服务",
            "procedure": "请求: 82 01 02",
            "expected": "正响应",
            "precondition": "默认会话",
        }])
        self.assertEqual(reviewed.returncode, 0, reviewed.stdout + reviewed.stderr)

    def test_routine_control_invalid_subfunction_is_error(self):
        # 0x31 子功能 0x07 不在 ISO 14229 白名单（01/02/03/04/05/06）→ ERROR。
        reviewed = self._review([{
            "case_id": "UDS_0x31_TC_BADSUB",
            "test_point": "例程控制正向",
            "procedure": "请求: 31 07 02 06",
            "expected": "正响应",
            "precondition": "默认会话",
        }])
        self.assertEqual(reviewed.returncode, 2, reviewed.stdout + reviewed.stderr)
        self.assertIn("子功能 0x07 非法", reviewed.stdout)

    def test_negative_short_write_request_is_allowed(self):
        # 负例故意发送畸形请求（写入长度错误），不做结构下限约束，应 PASS。
        reviewed = self._review([{
            "case_id": "UDS_0x2E_TC_NEGSHORT",
            "test_point": "负例（写入长度错误）",
            "procedure": "请求: 2E F1 0A",
            "expected": "DUT负响应：NRC=0x13",
            "precondition": "默认会话",
        }])
        self.assertEqual(reviewed.returncode, 0, reviewed.stdout + reviewed.stderr)

    def test_write_data_length_mismatch_requires_review(self):
        # 调查表 DID size_bytes=8，正例只写 1 字节 → REVIEW_REQUIRED（非阻断）。
        parsed = {"dids": [{
            "did_number": "F190", "rw_state": "RW", "size_bytes": 8,
            "read_security": {"level0_locked": "N"},
            "read_sessions": {"default_0x01": "Y", "programming_0x02": "N", "extended_0x03": "N"},
        }]}
        reviewed = self._review([{
            "case_id": "UDS_0x2E_TC_SIZEM",
            "test_point": "写入 DID 正向",
            "procedure": "请求: 2E F1 90 00",
            "expected": "正响应",
            "precondition": "默认会话",
        }], parsed=parsed)
        self.assertEqual(reviewed.returncode, 3, reviewed.stdout + reviewed.stderr)
        self.assertIn("size_bytes=8", reviewed.stdout)


class TestReviewPoliciesAndDepth(unittest.TestCase):
    """2026-09-03 反馈落地：歧义启发式收窄 + 分级策略 + 深度完备性核对块"""

    # ---- 单元：歧义启发式不再把裸 "NRC" 字样当负向信号 ----
    def test_ambiguity_heuristic_ignores_bare_nrc_mentions(self):
        # 正向用例正文附带说明性 NRC 值（无"负响应/负向"字样）不再被自动挂起
        case = {
            "case_id": "UDS_0x2E_TC_NRC_MENTION",
            "test_point": "写入 DID",
            "procedure": "请求: 2E F1 0A 01",
            "expected": "若写入成功返回正响应，否则返回 NRC 0x13",
            "precondition": "默认会话",
        }
        self.assertFalse(sr._expectation_requires_review(case))

    def test_ambiguity_heuristic_keeps_real_branch_detection(self):
        # 真正的"若保护：负响应 / 若未保护：正常响应"双路径歧义仍命中
        case = {
            "case_id": "UDS_0x31_TC_BRANCH2",
            "test_point": "例程保护探测",
            "procedure": "请求: 31 01 02 06",
            "expected": "若例程受保护：负响应 7F 31 33；若不受保护：正常响应",
            "precondition": "扩展会话",
        }
        self.assertTrue(sr._expectation_requires_review(case))

    # ---- 集成：歧义用例在 report 策略下只挂清单、不再退出码 3 ----
    def test_review_policy_report_keeps_review_list_but_exits_zero(self):
        cases = [{
            "case_id": "UDS_0x31_TC_REPORT_POLICY",
            "test_point": "例程保护探测",
            "procedure": "请求: 31 01 02 06",
            "expected": "若例程受保护：负响应 7F 31 33；若不受保护：正常响应",
            "precondition": "扩展会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can", "--review-policy", "report"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 0, reviewed.stdout + reviewed.stderr)
        self.assertIn("不阻断本轮", reviewed.stdout)

    # ---- 集成：深度完备性核对块（默认 report 不改判定；block 才升级）----
    def test_depth_gaps_reported_but_not_blocking_by_default(self):
        cases = [{
            "case_id": "UDS_0x22_TC_DEPTH_SHALLOW",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        report = os.path.join(td.name, "script_review_depth.json")
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can", "--out", report],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        # 默认 depth-policy=report：浅集一致性全绿仍 PASS，缺口只进核对表
        self.assertEqual(reviewed.returncode, 0, reviewed.stdout + reviewed.stderr)
        with open(report, encoding="utf-8") as f:
            data = json.load(f)
        self.assertEqual(data["status"], "PASS")
        self.assertEqual(data["policies"]["depth"], "report")
        gap_texts = [g["gap"] for g in data["depth"]["gaps"]]
        self.assertTrue(any("F190" in t and "负例" in t for t in gap_texts), gap_texts)
        self.assertTrue(any(p["service"] == "0x22" for p in data["depth"]["profile"]))

    def test_depth_policy_block_escalates_to_exit3(self):
        cases = [{
            "case_id": "UDS_0x22_TC_DEPTH_BLOCK",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "默认会话",
        }]
        td, cases_path, parsed_path, out_dir, generated = generate(cases)
        self.addCleanup(td.cleanup)
        self.assertEqual(generated.returncode, 0, generated.stderr)
        reviewed = subprocess.run(
            [sys.executable, REVIEW, "--cases", cases_path, "--parsed", parsed_path,
             "--scripts-dir", out_dir, "--bus", "can", "--depth-policy", "block"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(reviewed.returncode, 3, reviewed.stdout + reviewed.stderr)
        self.assertIn("深度完备性", reviewed.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
