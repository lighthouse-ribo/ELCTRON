#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SDDB/诊断调查表前置矩阵抽取器。

输出 ``service_prereq.json``，把 Control Routine、DID、IOControl 和安全/会话
属性收敛为机器可读的服务前置矩阵。抽取器不猜测业务参数；当启动例程需要
参数而原表没有提供时，只记录 ``start_payload=null`` 和 ``requires_start_data``。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Iterable, Mapping

from lin_pci import pci_rules


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _norm_header(value: Any) -> str:
    return re.sub(r"\s+", " ", _text(value).lower()).strip()


def _first_index(headers: list[str], patterns: Iterable[str]) -> int | None:
    for pattern in patterns:
        for index, header in enumerate(headers):
            if re.search(pattern, header, re.I):
                return index
    return None


def _find_header(rows: list[list[Any]]) -> int | None:
    for index, row in enumerate(rows[:40]):
        headers = [_norm_header(value) for value in row]
        joined = " | ".join(headers)
        if (
            re.search(r"rid|routine|identifier|data identification", joined, re.I)
            and re.search(r"request|control|condition|security|parameter", joined, re.I)
        ):
            return index
    return None


def _identifier(value: Any) -> str | None:
    raw = _text(value).upper().replace("0X", "")
    match = re.search(r"(?<![0-9A-F])([0-9A-F]{4})(?![0-9A-F])", raw)
    return match.group(1) if match else None


def _parse_request_length(text: str) -> int | None:
    patterns = (
        r"request\s*(?:parameter)?\s*[:=]\s*(\d+)\s*(?:byte|bytes|字节)?",
        r"request[^\r\n]{0,40}?([0-9]+)\s*bytes?",
        r"请求[^\r\n]{0,40}?([0-9]+)\s*字节",
    )
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            return int(match.group(1))
    return None


def _parse_control_type(value: Any, text: str) -> str | None:
    raw = _text(value).upper()
    match = re.search(r"(?<![0-9A-F])([0-9A-F]{2})(?![0-9A-F])", raw)
    if match and match.group(1) in {"01", "02", "03"}:
        return match.group(1)
    names = {
        "START": "01", "STARTROUTINE": "01", "启动": "01",
        "STOP": "02", "STOPROUTINE": "02", "停止": "02",
        "RESULT": "03", "REQUESTRESULT": "03", "结果": "03",
    }
    compact = re.sub(r"[ _-]", "", raw)
    for token, control_type in names.items():
        if token in compact:
            return control_type
    return None


def _hex_payload(value: Any) -> list[int] | None:
    text = _text(value)
    # 只接受空格分隔或明确的 0x 字节序列，避免把 RID/长度当作 payload。
    matches = re.findall(r"(?<![0-9A-Fa-f])(?:0x)?([0-9A-Fa-f]{2})(?![0-9A-Fa-f])", text)
    if not matches:
        return None
    return [int(item, 16) for item in matches]


def extract_control_routines(rows: Iterable[Iterable[Any]], source_file: str = "") -> dict[str, dict]:
    """从二维表格行抽取 Control Routine 前置矩阵。"""
    normalized_rows = [list(row) for row in rows]
    header_index = _find_header(normalized_rows)
    if header_index is None:
        return {}
    headers = [_norm_header(value) for value in normalized_rows[header_index]]
    rid_index = _first_index(headers, (r"\brid\b", r"identifier", r"data identification"))
    control_index = _first_index(headers, (r"control.*type", r"sub.?function", r"控制类型"))
    request_index = _first_index(headers, (r"request", r"请求"))
    parameter_index = _first_index(headers, (r"parameter", r"参数"))
    condition_index = _first_index(headers, (r"condition", r"条件"))
    security_index = _first_index(headers, (r"security", r"安全"))
    name_index = _first_index(headers, (r"name", r"名称", r"description"))

    routines: dict[str, dict] = {}
    current_rid: str | None = None
    for row_number, row in enumerate(normalized_rows[header_index + 1:], header_index + 2):
        rid = _identifier(row[rid_index]) if rid_index is not None and rid_index < len(row) else None
        if rid:
            current_rid = rid
            entry = routines.setdefault(rid, {
                "rid": rid,
                "name": _text(row[name_index]) if name_index is not None and name_index < len(row) else "",
                "control_types": [],
                "request_parameter_length": None,
                "conditions": [],
                "security_levels": [],
                "evidence": [],
            })
            if not entry["name"] and name_index is not None and name_index < len(row):
                entry["name"] = _text(row[name_index])
        if not current_rid or not any(_text(value) for value in row):
            continue

        entry = routines[current_rid]
        combined = " | ".join(_text(value) for value in row if _text(value))
        control_value = row[control_index] if control_index is not None and control_index < len(row) else ""
        control_type = _parse_control_type(control_value, combined)
        if control_type and control_type not in entry["control_types"]:
            entry["control_types"].append(control_type)

        request_values = []
        for index in (request_index, parameter_index):
            if index is not None and index < len(row):
                request_values.append(_text(row[index]))
        request_text = " | ".join(value for value in request_values if value) or combined
        length = _parse_request_length(request_text)
        if length is not None:
            previous = entry["request_parameter_length"]
            entry["request_parameter_length"] = length if previous is None else max(previous, length)

        condition = _text(row[condition_index]) if condition_index is not None and condition_index < len(row) else ""
        security = _text(row[security_index]) if security_index is not None and security_index < len(row) else ""
        if condition and condition not in entry["conditions"]:
            entry["conditions"].append(condition)
        if security and security not in entry["security_levels"]:
            entry["security_levels"].append(security)
        entry["evidence"].append({"row": row_number, "text": combined, "control_type": control_type})

    for entry in routines.values():
        entry["control_types"] = sorted(entry["control_types"])
        has_start = "01" in entry["control_types"]
        follow_up = [value for value in ("02", "03") if value in entry["control_types"]]
        entry["two_step"] = bool(has_start and follow_up)
        entry["requires_start_for"] = follow_up
        param_length = entry["request_parameter_length"]
        if has_start and param_length in (None, 0):
            entry["start_payload"] = [0x31, 0x01, int(entry["rid"][:2], 16), int(entry["rid"][2:], 16)]
            entry["requires_start_data"] = False
        else:
            entry["start_payload"] = None
            entry["requires_start_data"] = bool(has_start and param_length)
        entry["source_file"] = source_file
    return routines


def build_service_prereq(parsed: Mapping[str, Any] | None = None,
                         routines: Mapping[str, Mapping[str, Any]] | None = None,
                         source_files: Iterable[str] = ()) -> dict:
    """构造统一 service_prereq.json 数据。"""
    parsed = parsed or {}
    dids = {}
    for item in parsed.get("dids", []) or []:
        if not isinstance(item, Mapping):
            continue
        raw = _text(item.get("did_number")).upper().replace("0X", "")
        if not raw:
            continue
        dids[raw] = {
            "name": item.get("did_name", ""),
            "rw_state": item.get("rw_state", ""),
            "read_sessions": item.get("read_sessions", {}),
            "write_sessions": item.get("write_sessions", {}),
            "read_security": item.get("read_security", {}),
            "write_security": item.get("write_security", {}),
            "functional_addressing": item.get("functional_addressing", "N"),
        }
    io_controls = {}
    for item in parsed.get("io_controls", []) or []:
        if isinstance(item, Mapping):
            key = _text(item.get("did_number")).upper().replace("0X", "")
            if key:
                io_controls[key] = dict(item)
    routines = {str(key).upper().replace("0X", ""): dict(value) for key, value in (routines or {}).items()}
    return {
        "schema_version": 1,
        "source_files": [str(path) for path in source_files if path],
        "pci_rules": {"lin": pci_rules()},
        "services": {
            "0x22": {"objects": dids, "source": "SDDB.DID.read_sessions/read_security"},
            "0x2E": {"objects": dids, "source": "SDDB.DID.write_sessions/write_security"},
            "0x2F": {"objects": io_controls, "source": "SDDB.IOControl"},
            "0x31": {"objects": routines, "source": "SDDB.Control Routine"},
        },
    }


def _xlsx_files(path: str | Path) -> list[Path]:
    target = Path(path)
    if target.is_file():
        return [target]
    return sorted(item for item in target.rglob("*.xlsx") if item.is_file())


def extract_sddb(input_path: str | Path, parsed: Mapping[str, Any] | None = None) -> dict:
    try:
        import openpyxl
    except ImportError as exc:
        raise RuntimeError("缺少 openpyxl，无法读取 SDDB xlsx") from exc
    routines: dict[str, dict] = {}
    sources: list[str] = []
    for workbook_path in _xlsx_files(input_path):
        workbook = openpyxl.load_workbook(workbook_path, read_only=True, data_only=True)
        matched = [name for name in workbook.sheetnames if re.search(r"control\s*routine|routine", name, re.I)]
        for sheet_name in matched:
            rows = workbook[sheet_name].iter_rows(values_only=True)
            extracted = extract_control_routines(rows, str(workbook_path))
            routines.update(extracted)
            if extracted:
                sources.append(str(workbook_path))
        workbook.close()
    return build_service_prereq(parsed, routines, sources or [str(input_path)])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="SDDB/诊断调查表前置矩阵抽取器")
    parser.add_argument("--input", "-i", required=True, help="SDDB xlsx 文件或目录")
    parser.add_argument("--parsed", default="", help="可选 uds_parsed.json，用于 DID/IOControl 矩阵")
    parser.add_argument("--output", "-o", required=True, help="service_prereq.json 输出路径")
    args = parser.parse_args(argv)
    parsed = {}
    if args.parsed:
        with open(args.parsed, encoding="utf-8", errors="replace") as handle:
            parsed = json.load(handle)
    try:
        result = extract_sddb(args.input, parsed)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"[ERROR] SDDB 前置矩阵抽取失败: {exc}")
        return 1
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    routine_count = len(result["services"]["0x31"]["objects"])
    did_count = len(result["services"]["0x22"]["objects"])
    print(f"[OK] SDDB 前置矩阵: DID={did_count} Routine={routine_count} 输出={output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
