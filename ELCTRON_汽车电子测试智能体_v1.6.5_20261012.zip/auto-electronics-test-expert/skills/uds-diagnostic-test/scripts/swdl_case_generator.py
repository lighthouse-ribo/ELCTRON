# -*- coding: utf-8 -*-
"""按系统合格性测试用例表风格生成 SWDL 结构化用例。"""

from __future__ import annotations

from typing import Iterable

from reference_case_adapter import make_reference_case


def _reqs(requirement_ids: Iterable[str]) -> str:
    values = [str(item).strip() for item in requirement_ids if str(item).strip()]
    return "\n".join(values) or "待绑定 SWDL 需求 ID（不得据此执行）"


def build_swdl_cases(
    *,
    requirement_ids: Iterable[str] = (),
    flowchart_ready: bool = False,
    key_material_ready: bool = False,
    env: str = "台架测试",
) -> dict:
    """生成正向主流程、异常/故障注入和边界用例；不生成实测 PASS。"""
    req_sources = _reqs(requirement_ids)
    definitions = [
        ("L1", "基于需求的测试", "需求分析法", "进入编程会话", "51 02 10 02 FF FF FF FF", "51 06 50 02 00 19 13 88"),
        ("L1", "基于需求的测试", "需求分析法", "SecurityAccess 认证流程", "51 02 27 01 FF FF FF FF", "0x67 01 + 54B seed（具体值以实测为准）"),
        ("L1", "基于需求的测试", "需求分析法", "RequestDownload 参数边界", "51 0A 34 ...（地址/长度来自 Memory Map）", "正响应 0x74，长度格式与 Memory Map 一致"),
        ("L1", "基于需求的测试", "需求分析法", "TransferData 连续块传输", "51 ... 36 blockCounter data...", "每个块正响应 0x76，块计数器按流程递增"),
        ("L1", "基于需求的测试", "需求分析法", "RequestTransferExit", "51 01 37 FF FF FF FF FF", "正响应 0x77，进入校验阶段"),
        ("L1", "基于需求的测试", "需求分析法", "CheckMemory 校验", "51 ... 31 01 02 12 ...", "正响应 0x71，校验结果与镜像哈希一致"),
        ("L1", "基于需求的测试", "需求分析法", "刷写后 ECU 复位", "51 02 11 01 FF FF FF FF", "正响应 0x51，ECU 按需求复位并恢复通信"),
        ("L1", "基于需求的测试", "需求分析法", "刷写后版本确认", "读取项目定义的软件版本 DID", "版本与目标镜像/项目资料一致"),
        ("L2", "故障注入", "错误推测法", "未解锁执行受保护刷写服务", "未完成 0x27 解锁，发送 0x34/0x36", "负响应 NRC=0x33 securityAccessDenied；不得写入镜像"),
        ("L2", "故障注入", "边界值", "TransferData 块计数器错误", "发送重复或跳变 blockCounter", "负响应按 SRS/SWRS 定义；传输状态可追溯，不得静默接受"),
        ("L2", "故障注入", "等价类", "RequestDownload 地址越界", "发送 Memory Map 外地址/长度", "负响应 NRC=0x31 requestOutOfRange；不得擦写越界区域"),
        ("L2", "故障注入", "错误推测法", "刷写中断恢复", "传输中断电或断开通信后重新上电", "ECU 进入需求定义的安全恢复状态，结果不得误判为 PASS"),
    ]
    cases = []
    for index, (priority, point, design, title, request, expected) in enumerate(definitions, 1):
        blocked = []
        if not flowchart_ready:
            blocked.append("flash_flowchart")
        if "0x27" in title or "0x34" in request or "0x36" in request:
            if not key_material_ready:
                blocked.append("security_key_material")
        status = "BLOCKED" if blocked else "READY"
        cases.append(make_reference_case(
            req_sources=req_sources,
            case_id=f"SWDL_TC_{index:04d}",
            priority=priority,
            auto_eval="否" if "中断" in title else "是",
            test_point=point,
            test_method=design,
            design_method=design,
            env=env,
            precondition=(
                "1. ECU 供电与通信正常\n"
                "2. 已确认目标分区、流程图、Memory Map 与镜像哈希\n"
                "3. 0x27 真实密钥材料已授权；缺失时本用例保持 BLOCKED"
            ),
            procedure=f"1. {title}\n2. 测试仪请求：{request}；",
            expected=f"1. DUT 结果：{expected}\n2. 记录 request/response trace、镜像 SHA-256 与最终版本；",
            generation_status=status,
            blocked_by=blocked,
            category="swdl",
            title=title,
        ))
    return {
        "schema_version": "reference-case-bundle/v0.1",
        "module": "SWDL",
        "generation_status": "READY" if flowchart_ready else "DEGRADED",
        "cases": cases,
        "policy": {"unexecuted_verdict": "NOT_EXECUTED", "missing_material_verdict": "BLOCKED"},
    }


__all__ = ["build_swdl_cases"]
