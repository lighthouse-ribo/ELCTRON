#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UDS测试执行器 (Windows + Vector)
调用已生成的测试脚本，通过 Vector (VN1630A, XL Driver Library) 硬件执行测试并生成报告
也可作为独立编排工具：解析 → 生成 → 执行 一站式完成
"""

__version__ = "1.14.0"

import argparse
import importlib.util
import json
import os
import subprocess
import sys
import re
import time
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Any

_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))

_CONTEXT_SCRIPTS_DIR = _SKILLS_DIR / "srs-uds-testcase-designer" / "scripts"
if str(_CONTEXT_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_CONTEXT_SCRIPTS_DIR))

from flow_contract import FlowKind, build_flow_context, get_flow_definition, normalize_flow
from execution_profile import ExecutionProfileError, validate_execution_profile
from gen_case_scripts import sanitize_strong
from portable_pack_reader import PortablePackError, load_json as load_portable_json, resolve_pack_path
from project_artifact_binding import (
    ProjectArtifactBindingError,
    build_project_context_binding,
    validate_artifact_binding,
)
from project_capability_gate import evaluate_project_capability
from project_config import load_project_config, project_identity
from project_context_builder import build_context_from_manifest
from result_contract import normalize_result
from swdl_flow import SwdlFlow, build_swdl_plan


def _configure_console_encoding():
    """统一 Windows 控制台输出，避免中文/符号触发 GBK 编码异常或乱码。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError):
                pass


_configure_console_encoding()

SCRIPT_DIR = Path(__file__).parent
ENV_FILE = Path(os.environ.get("UDS_ENV_FILE", str(Path.home() / ".uds_env")))


def _load_env_file():
    """读取 ~/.uds_env，允许调用端不显式 source 也能复用固定环境。"""
    if not ENV_FILE.is_file():
        return {}

    env_map = {}
    for raw_line in ENV_FILE.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        env_map[key.strip()] = value.strip().strip('"').strip("'")
    return env_map


def _bootstrap_runtime_env():
    """优先从 UDS 环境文件恢复运行时变量，减少对 shell 前缀的依赖。"""
    env_map = _load_env_file()
    for key in ("UDS_PYTHON", "UDS_SKILL_DIR", "UDS_WORK"):
        if env_map.get(key) and not os.environ.get(key):
            os.environ[key] = env_map[key]

    os.environ.setdefault("UDS_SKILL_DIR", str(SCRIPT_DIR.parent))
    os.environ.setdefault("UDS_WORK", str(Path.home() / ".uds_workspace"))


def _runtime_python():
    """统一选择后续子脚本使用的解释器。"""
    configured = os.environ.get("UDS_PYTHON", "").strip()
    if configured and Path(configured).is_file():
        return configured

    # 兼容已存在但尚未写入 ~/.uds_env 的用户级运行时；优先使用规范 venv，
    # 再兼容 WorkBuddy 已配置的默认 Python，避免日志中的“环境未初始化”假失败。
    fallback_candidates = (
        Path.home() / ".uds_venv" / "Scripts" / "python.exe",
        Path.home() / ".workbuddy" / "binaries" / "python" / "envs" / "default" / "Scripts" / "python.exe",
    )
    for fallback in fallback_candidates:
        if fallback.is_file():
            return str(fallback)

    if ENV_FILE.is_file():
        raise SystemExit(
            f"[ERROR] UDS_PYTHON missing or invalid in {ENV_FILE}: {configured or '<empty>'}\n"
            "[ERROR] Enter the uds-diagnostic-test skill root, then run PowerShell: .\\scripts\\setup_env.ps1"
        )

    # 环境文件和已知运行时都不存在时不立即报错，允许 --help 等命令正常显示；
    # 真正执行 parse/generate/run/pipeline 时再提示初始化。
    return None


_bootstrap_runtime_env()
RUNTIME_PYTHON = _runtime_python()


def _load_project_config(source=""):
    """加载并校验统一项目配置；CLI 子进程只传路径，避免配置漂移。"""
    try:
        return load_project_config(source or None)
    except ValueError as exc:
        print(f"[ERROR] 项目配置读取失败: {exc}")
        return None


def _project_physical_nad(project_config=""):
    config = _load_project_config(project_config)
    if config is None:
        return None
    return int(config["transport"]["physical_nad"])


def _project_identity(project_config=""):
    """项目身份（project / display_name / run_id_prefix / 源工作簿 / 版本前缀）。

    统一从项目配置取用；未移植项目（未传 ``--project-config`` 且输入包内无
    ``project_config.json``）时回退到参考项目档，技能代码内不写项目字面量。
    """
    try:
        return project_identity(project_config or None)
    except ValueError as exc:
        print(f"[ERROR] 项目配置读取失败: {exc}")
        return None


def _effective_nad(value, project_config=""):
    """解析 CLI NAD；未显式传入时使用项目 transport.physical_nad。"""
    if value not in (None, ""):
        try:
            return int(str(value), 0)
        except (TypeError, ValueError):
            return None
    return _project_physical_nad(project_config)


def _effective_lin_bitrate(kwargs):
    """解析 project 流程的 LIN 波特率，优先使用 LIN 专用 ``brval``。"""
    return kwargs.get("brval") or kwargs.get("bitrate") or 19200


_ACTIVE_WORKFLOW_TIMER = None


class WorkflowTimer:
    """记录一键流程及其子命令耗时，输出 JSON 供后续轮次比较。"""

    def __init__(self, command):
        self.command = command
        self.started_at = datetime.now().astimezone()
        self.started_mono = time.perf_counter()
        self.phases = []

    def record(self, label, started_at, started_mono, returncode=None):
        ended_at = datetime.now().astimezone()
        self.phases.append({
            "name": label,
            "start": started_at.isoformat(timespec="milliseconds"),
            "end": ended_at.isoformat(timespec="milliseconds"),
            "elapsed_s": round(time.perf_counter() - started_mono, 3),
            "returncode": returncode,
        })

    def write(self, output_dir, result):
        finished_at = datetime.now().astimezone()
        summary = {
            "schema_version": 1,
            "command": self.command,
            "status": "PASS" if result else "FAIL",
            "started_at": self.started_at.isoformat(timespec="milliseconds"),
            "finished_at": finished_at.isoformat(timespec="milliseconds"),
            "elapsed_s": round(time.perf_counter() - self.started_mono, 3),
            "phases": self.phases,
        }
        os.makedirs(output_dir, exist_ok=True)
        stamp = self.started_at.strftime("%Y%m%d_%H%M%S")
        path = os.path.join(output_dir, f"timing_summary_{stamp}.json")
        with open(path, "w", encoding="utf-8", errors="replace") as handle:
            json.dump(summary, handle, ensure_ascii=False, indent=2)
        print("\n===== 流程耗时汇总 =====")
        print(f"总耗时: {summary['elapsed_s']:.3f}s ｜ 状态: {summary['status']}")
        for phase in self.phases:
            print(f"- {phase['name']}: {phase['elapsed_s']:.3f}s (rc={phase['returncode']})")
        print(f"[完成] 耗时记录: {path}")
        return path


def _timed_workflow(func):
    @wraps(func)
    def wrapper(survey_file, output_dir, *args, **kwargs):
        global _ACTIVE_WORKFLOW_TIMER
        timer = WorkflowTimer(func.__name__)
        previous = _ACTIVE_WORKFLOW_TIMER
        _ACTIVE_WORKFLOW_TIMER = timer
        result = False
        try:
            result = bool(func(survey_file, output_dir, *args, **kwargs))
            return result
        finally:
            try:
                timer.write(output_dir, result)
            finally:
                _ACTIVE_WORKFLOW_TIMER = previous
    return wrapper


def _resolve_can_config(can_if, channel):
    """选择CAN接口和通道 (Windows: Vector VN1630A 等)"""
    if not can_if or can_if == "auto":
        can_if = "vector"
    if not channel or str(channel).upper().startswith("PCAN_"):
        channel = "0"
    return can_if, str(channel)


_CAN_DEFAULTS = {
    "tx_id": 0x7E0,
    "rx_id": 0x7E8,
    "func_id": 0x7DF,
    "bitrate": 500000,
    "sample_point": 0.8,
    "can_fd": False,
    "fd_data_bitrate": 2000000,
    "fd_dsample_point": 0.8,
}


def _coerce_config_value(key, value):
    """将调查表/CLI 的 CAN 值规范化；非法值返回 None，不默默当成有效配置。"""
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    try:
        if key in {"tx_id", "rx_id", "func_id"}:
            return int(str(value), 0)
        if key in {"bitrate", "fd_data_bitrate"}:
            return int(value)
        if key in {"sample_point", "fd_dsample_point"}:
            result = float(value)
            return result / 100.0 if result > 1.0 else result
        if key == "can_fd":
            if isinstance(value, bool):
                return value
            return str(value).strip().lower() in {"1", "true", "yes", "y", "on", "enable", "enabled", "启用"}
    except (TypeError, ValueError):
        return None
    return value


def resolve_effective_config(parsed_data, cli_args=None):
    """解析一次最终 CAN 配置，供生成、用例脚本、审查和链路检查共同使用。

    关键参数的优先级为 CLI > 调查表 > 默认值。使用默认的 TX/RX ID 或
    波特率会被标记为 ``requires_confirmation``，调用方不得在未确认时继续生成。
    """
    parsed_data = parsed_data or {}
    cli_args = cli_args or {}
    survey = parsed_data.get("can_config") or {}
    can = {}
    sources = {}
    missing = []

    for key, default in _CAN_DEFAULTS.items():
        cli_value = cli_args.get(key)
        # argparse 的 store_true 默认 False 不是“显式配置”；只有 True 或
        # can_fd_cli=False 才代表用户明确选择了 Classic CAN。
        if key == "can_fd" and cli_args.get("can_fd_cli") is None and cli_value is False:
            cli_value = None
        survey_value = _coerce_config_value(key, survey.get(key))
        chosen = _coerce_config_value(key, cli_value)
        if chosen is not None:
            can[key] = chosen
            sources[key] = "cli"
        elif survey_value is not None:
            can[key] = survey_value
            sources[key] = "survey"
        else:
            can[key] = default
            sources[key] = "default"
            if key in {"tx_id", "rx_id", "bitrate"}:
                missing.append(key)

    can_if, channel = _resolve_can_config(cli_args.get("can_if", "vector"), cli_args.get("channel", "0"))
    can["channel"] = channel
    can["serial"] = str(cli_args.get("serial") or "")
    can["can_if"] = can_if
    sources["channel"] = "cli/default"
    return {
        "bus": cli_args.get("bus", "can"),
        "can": can,
        "sources": sources,
        "missing": missing,
        "requires_confirmation": bool(missing),
    }


def config_gate_allows_generation(effective_config, confirmed=False, bus="can"):
    """生成前门禁：CAN 关键参数使用默认值时必须有明确确认。"""
    if bus != "can":
        return True
    return not effective_config.get("requires_confirmation", True) or bool(confirmed)


def _append_cli_arg(cmd, key, val):
    """按argparse语义追加CLI参数，避免把False/None错误转成字符串参数。"""
    if val is None:
        return

    flag = f"--{key.replace('_', '-')}"
    if isinstance(val, (list, tuple)):
        if val:
            cmd.append(flag)
            cmd.extend(str(item) for item in val)
        return
    if isinstance(val, bool):
        if val:
            cmd.append(flag)
        return

    if isinstance(val, str) and val == "":
        return

    cmd.extend([flag, str(val)])


def direct_output_allowed(occupying_processes, canviex_device_count, vector_device_count=None):
    """只有明确确认无占用进程、无 CANviex、无 Vector 设备时才允许直接输出。

    ``None`` 表示设备探测失败/未知，不能按“无硬件”处理，否则会让探测
    故障绕过硬件执行门禁（OP-07：Vector XL 设备必须纳入统一硬件清单）。
    """
    if vector_device_count is None or vector_device_count > 0:
        return False
    return not occupying_processes and canviex_device_count == 0


def detect_occupying_processes():
    """检测 CANoe/VickCAN 等可能占用总线的进程。"""
    try:
        from can_init import check_process_occupancy
        return check_process_occupancy()
    except Exception as exc:
        print(f"[ERROR] CANoe/VickCAN 进程检测失败: {exc}")
        return ["<process-detection-unknown>"]


def detect_canviex_devices():
    """检测 CANviex/F1L1 设备数量；返回 None 表示无法完成探测。"""
    wrapper_dir = os.environ.get("F1L1_XCWRAPPER_DIR", "").strip()
    if wrapper_dir and wrapper_dir not in sys.path:
        sys.path.insert(0, wrapper_dir)
    if str(SCRIPT_DIR) not in sys.path:
        sys.path.insert(0, str(SCRIPT_DIR))
    try:
        import xcdev_wrapper as xw
        count = int(xw.detect(xw.XC_HARDTYPE_CANVIEX_F1L1))
        print(f"[INFO] CANviex/F1L1 设备检测: {count} 台（DLL {xw.version()}）")
        return count
    except Exception as exc:
        print(f"[ERROR] CANviex/F1L1 设备检测失败: {exc}")
        print("[HINT] 无法确认硬件是否存在，禁止直接输出；请检查 F1L1_DLL_PATH/F1L1_XCWRAPPER_DIR。")
        return None


def detect_vector_devices():
    """检测 Vector XL 硬件通道数（vxlapi64.dll）；返回 None 表示无法完成探测。

    未安装 Vector XL Driver Library 视为无 Vector 硬件（返回 0）；
    DLL 存在但枚举失败视为未知（返回 None，阻断直接输出）。
    """
    try:
        import ctypes
        try:
            vxl = ctypes.WinDLL("vxlapi64.dll")
        except OSError:
            return 0
        num = ctypes.c_ulong()
        rc = vxl.VXL_GetNumberOfHardwareChannels(ctypes.byref(num))
        if rc == 0:
            print(f"[INFO] Vector XL 通道检测: {int(num.value)}（vxlapi64.dll）")
            return int(num.value)
        print(f"[ERROR] VXL_GetNumberOfHardwareChannels 返回 {rc}")
        return None
    except Exception as exc:
        print(f"[ERROR] Vector XL 设备检测失败: {exc}")
        return None


def detect_hardware_state():
    """返回执行门禁所需的进程、CANviex 和 Vector 设备状态（三元组）。"""
    processes = detect_occupying_processes()
    canviex_count = detect_canviex_devices()
    vector_count = detect_vector_devices()
    return processes, canviex_count, vector_count


def run_hardware_preflight(bus="can"):
    """硬件执行预检：LIN 走 CANviex，CAN 走 Vector。"""
    processes = detect_occupying_processes()
    if processes:
        print("[ERROR] 检测到 CANoe/VickCAN 等占用进程，硬件执行已阻断。")
        return False
    if bus == "lin":
        count = detect_canviex_devices()
        if count is None or count <= 0:
            print("[ERROR] LIN 硬件路径要求 CANviex/F1L1 设备在线。")
            return False
        print("[OK] CANviex/F1L1 LIN 硬件预检通过")
        return True
    return run_preflight(bus="can")


def select_cases_path(raw_cases, filled_cases):
    """下游步骤统一使用审计填充后的 cases；没有填充结果时回退原始文件。"""
    if filled_cases:
        return filled_cases
    return raw_cases if raw_cases else ""


def readonly_dids_from_parsed(parsed_data):
    """从调查表解析结果提取明确标记为只读的 DID，供 case_lint R1 使用。"""
    out = []
    for did in (parsed_data or {}).get("dids", []):
        number = str(did.get("did_number", "")).strip().upper()
        if number.startswith("0X"):
            number = number[2:]
        if number and "W" not in str(did.get("rw_state", "R")).upper():
            out.append(number)
    return ",".join(sorted(set(out)))


def run_preflight(bus="auto"):
    """执行前硬件预检：自动识别 CANviex/F1L1 或回退 Vector。"""
    if bus in ("auto", "lin"):
        processes = detect_occupying_processes()
        canviex_count = detect_canviex_devices()
        if canviex_count is not None and canviex_count > 0:
            if processes:
                print("[ERROR] CANviex/F1L1 在线但检测到通道占用进程。")
                return False
            print("[OK] CANviex/F1L1 LIN 硬件预检通过")
            return True
        if bus == "lin":
            print("[ERROR] LIN 预检未检测到 CANviex/F1L1 硬件。")
            return False
    cmd = [RUNTIME_PYTHON, str(SCRIPT_DIR / "can_init.py"), "--preflight"]
    return _run_ok(cmd, "执行预检")


def _run_subprocess(cmd, label, *, utf8_env=False, print_cmd=True):
    """统一子进程执行样板：环境检查 → 执行 → 回显 → 返回 CompletedProcess。

    - label: [INFO] 行描述（print_cmd=False 时跳过，供 py_compile 等静默检查用）
    - utf8_env: 注入 PYTHONIOENCODING=utf-8（子进程含中文/符号打印时用，
      Windows 子进程默认可能继承 GBK，导致输出阶段 UnicodeEncodeError）
    返回 CompletedProcess；RUNTIME_PYTHON 未初始化时打印提示并返回 None。
    """
    started_at = datetime.now().astimezone()
    started_mono = time.perf_counter()
    if not RUNTIME_PYTHON:
        print("[ERROR] Runtime environment is not initialized, run PowerShell: ./scripts/setup_env.ps1")
        return None
    if print_cmd:
        print(f"[INFO] {label}: {' '.join(cmd)}")
    child_env = os.environ.copy()
    if utf8_env:
        child_env["PYTHONIOENCODING"] = "utf-8"
    result = subprocess.run(cmd, capture_output=True, text=True,
                            encoding="utf-8", errors="replace", env=child_env)
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(result.stderr)
    ended_at = datetime.now().astimezone()
    elapsed = time.perf_counter() - started_mono
    print(f"[TIMING] {label}: start={started_at.isoformat(timespec='milliseconds')} "
          f"end={ended_at.isoformat(timespec='milliseconds')} "
          f"elapsed={elapsed:.3f}s rc={result.returncode}")
    if _ACTIVE_WORKFLOW_TIMER is not None:
        _ACTIVE_WORKFLOW_TIMER.record(label, started_at, started_mono, result.returncode)
    return result


def _run_ok(cmd, label, *, fail_hint="", utf8_env=False, print_cmd=True):
    """执行子进程并返回 bool 成功；rc!=0 且提供 fail_hint 时打印专属失败文案。"""
    result = _run_subprocess(cmd, label, utf8_env=utf8_env, print_cmd=print_cmd)
    if result is None:
        return False
    if result.returncode != 0 and fail_hint:
        print(fail_hint)
    return result.returncode == 0


def run_parser(input_file, output_json):
    """运行诊断调查表解析器"""
    cmd = [
        RUNTIME_PYTHON, str(SCRIPT_DIR / "uds_survey_parser.py"),
        "--input", input_file,
        "--output", output_json,
    ]
    return _run_ok(cmd, "执行解析")


def run_generator(input_json, output_script, **kwargs):
    """运行测试脚本生成器"""
    cmd = [
        RUNTIME_PYTHON, str(SCRIPT_DIR / "uds_test_generator.py"),
        "--input", input_json,
        "--output", output_script,
    ]
    for key, val in kwargs.items():
        _append_cli_arg(cmd, key, val)
    return _run_ok(cmd, "执行生成")


def representative_report_ok(returncode, report_text="", stdout="", stderr=""):
    """将代表脚本的真实 FAIL/异常转换为编排器失败状态。

    旧版生成脚本捕获测试异常后仍可能退出 0，因此不能只看子进程退出码。
    BLOCKED/NA/SKIP 不在这里视为 FAIL；ERROR 或非法状态均视为 FAIL。
    """
    if returncode != 0:
        return False
    combined = "\n".join((stdout or "", stderr or ""))
    if "测试过程中发生异常" in combined or "Traceback (most recent call last)" in combined:
        return False
    match = re.search(r"失败\s*\(FAIL\)\s*\|\s*(\d+)", report_text or "")
    if match and int(match.group(1)) > 0:
        return False
    if re.search(r"(?:ERROR)\s*[:|)]|错误\s*\(ERROR\)", report_text or combined, re.I):
        return False
    return True


def run_test_script(test_script, report_path, **kwargs):
    """执行生成的测试脚本"""
    cmd = [
        RUNTIME_PYTHON, test_script,
        "--report", report_path,
    ]
    for key, val in kwargs.items():
        _append_cli_arg(cmd, key, val)
    result = _run_subprocess(cmd, "执行测试")
    if result is None:
        return False
    report_text = ""
    if not os.path.isfile(report_path):
        print(f"[ERROR] 代表脚本未生成报告: {report_path}")
        return False
    try:
        with open(report_path, encoding="utf-8", errors="replace") as f:
            report_text = f.read()
    except OSError as exc:
        print(f"[ERROR] 代表脚本报告读取失败: {exc}")
        return False
    return representative_report_ok(result.returncode, report_text,
                                    result.stdout, result.stderr)


def run_gen_case_scripts(cases_path, parsed_path, out_dir, **kwargs):
    """用例 ↔ 脚本 一一对应生成（每条用例唯一脚本，不漏不重）"""
    cmd = [RUNTIME_PYTHON, str(SCRIPT_DIR / "gen_case_scripts.py"),
           "--cases", cases_path, "--parsed", parsed_path, "--out-dir", out_dir]
    for key, val in kwargs.items():
        _append_cli_arg(cmd, key, val)
    return _run_ok(cmd, "生成用例脚本")


def run_script_review(cases_path, parsed_path, scripts_dir, out_path, **kwargs):
    """审查生成后的脚本；默认 ERROR/REVIEW_REQUIRED 均阻断硬件执行。

    策略由调用方透传（kwargs 中的 review_policy/depth_policy，缺省与
    script_review 自身默认一致）：review_policy=report 时 REVIEW_REQUIRED
    仅作待确认清单、不再退出码 3；depth_policy=block 时深度完备性缺口
    并入 REVIEW_REQUIRED。ERROR（退出码 2）任何策略下都阻断。
    """
    script = SCRIPT_DIR / "script_review.py"
    if not script.is_file():
        print(f"[ERROR] script_review.py 不存在: {script}")
        return False
    cmd = [RUNTIME_PYTHON, str(script),
           "--cases", cases_path, "--parsed", parsed_path,
           "--scripts-dir", scripts_dir]
    if out_path:
        cmd += ["--out", out_path]
    for key, val in kwargs.items():
        _append_cli_arg(cmd, key, val)
    return _run_ok(cmd, "执行生成后脚本审查",
                   fail_hint="[ERROR] 脚本审查未通过，禁止生成正式 FAIL/BLOCKED 统计或进入硬件执行")


def run_expectation_check(cases_path, out_path, *, bus="lin", nad=0x51,
                          project_config=""):
    """执行 ISO 14229 设计期望校验，阻止明显语义错误泄漏到实机。"""
    script = SCRIPT_DIR / "expectation_check.py"
    if not script.is_file():
        print(f"[ERROR] expectation_check.py 不存在: {script}")
        return False
    cmd = [RUNTIME_PYTHON, str(script), "--cases", cases_path,
           "--bus", bus, "--nad", str(nad), "--out", out_path]
    if project_config:
        cmd += ["--project-config", project_config]
    return _run_ok(cmd, "执行 ISO 14229 期望校验",
                   fail_hint="[ERROR] ISO 14229 期望校验未通过，阻断脚本生成")


def run_sddb_extract(input_path, output_path, parsed_path=""):
    """抽取 SDDB 服务前置矩阵；无 Control Routine 时保留可审计空矩阵。"""
    script = SCRIPT_DIR / "sddb_extract.py"
    if not script.is_file():
        print(f"[ERROR] sddb_extract.py 不存在: {script}")
        return False
    cmd = [RUNTIME_PYTHON, str(script), "--input", input_path, "--output", output_path]
    if parsed_path:
        cmd += ["--parsed", parsed_path]
    return _run_ok(cmd, "抽取 SDDB 前置矩阵")


def resolve_survey_input(survey_input, target_partition=""):
    """解析调查表输入；目录候选不唯一时禁止静默选择。"""
    path = Path(str(survey_input or "")).expanduser()
    target = str(target_partition or "").strip().upper()
    if path.is_file():
        if target:
            stem = path.stem.upper()
            named_partitions = {
                part for part in ("APP", "PBL", "SBL")
                if re.search(r"(?<![A-Z0-9])%s(?![A-Z0-9])" % part, stem)
            }
            if named_partitions and target not in named_partitions:
                print(f"[ERROR] 调查表与目标分区不一致: {path.name} != {target}")
                return ""
        return str(path.resolve())
    if not path.is_dir():
        print(f"[ERROR] 调查表文件或目录不存在: {survey_input}")
        return ""

    suffixes = {".xlsx", ".xls", ".csv", ".json", ".cdd"}
    try:
        candidates = sorted({
            str(item.resolve()) for item in path.rglob("*")
            if item.is_file() and item.suffix.lower() in suffixes
        })
    except OSError as exc:
        print(f"[ERROR] 扫描调查表目录失败: {path}: {exc}")
        return ""
    if not candidates:
        print(f"[ERROR] 目录中未找到调查表文件: {path}")
        return ""

    if target:
        matches = [item for item in candidates if re.search(
            r"(?<![A-Z0-9])%s(?![A-Z0-9])" % target,
            Path(item).stem.upper(),
        )]
        if len(matches) == 1:
            print(f"[INFO] 依据目标分区 {target} 选用调查表: {matches[0]}")
            return matches[0]
        if not matches:
            print(f"[ERROR] 目录中没有与目标分区 {target} 匹配的调查表: {path}")
        else:
            print(f"[ERROR] 目标分区 {target} 对应多个调查表，禁止自动选择:")
            for item in matches:
                print(f"  - {item}")
        return ""

    if len(candidates) == 1:
        print(f"[INFO] 目录中唯一调查表: {candidates[0]}")
        return candidates[0]
    print("[ERROR] 目录中存在多个调查表，禁止静默选择；请传入单个文件或 --uds-target-partition:")
    for item in candidates:
        print(f"  - {item}")
    return ""


def _project_pack_manifest_path(project_pack):
    """Resolve a project-pack directory or its input_manifest.json."""
    path = Path(str(project_pack or "")).expanduser()
    if path.is_dir():
        manifest_path = path / "input_manifest.json"
    elif path.is_file() and path.name.lower() == "input_manifest.json":
        manifest_path = path
    else:
        raise PortablePackError(
            f"project-pack 必须是目录或 input_manifest.json: {project_pack}"
        )
    if not manifest_path.is_file():
        raise PortablePackError(f"project-pack 缺少 input_manifest.json: {manifest_path}")
    return manifest_path.resolve()


def _select_project_pack_file(manifest_path, entries, role, target_partition=""):
    """Select one manifest entry without silently crossing project partitions."""
    if not entries:
        return ""
    candidates = list(entries)
    target = str(target_partition or "").strip().upper()
    if target:
        exact = [item for item in candidates
                 if str(item.get("partition", "shared")).upper() == target]
        shared = [item for item in candidates
                  if str(item.get("partition", "shared")).lower() == "shared"]
        candidates = exact or shared
    if len(candidates) != 1:
        listed = ", ".join(str(item.get("path", "<missing path>")) for item in candidates)
        raise PortablePackError(
            f"project-pack 的 {role} 输入不唯一，禁止静默选择: {listed}"
        )
    relative_path = candidates[0].get("path", "")
    return str(resolve_pack_path(manifest_path.parent, relative_path))


def resolve_project_pack_inputs(project_pack, target_partition=""):
    """Resolve manifest-backed survey/LDF/config paths for one project run."""
    manifest_path = _project_pack_manifest_path(project_pack)
    manifest = load_portable_json(manifest_path)
    if not isinstance(manifest, dict):
        raise PortablePackError("input_manifest.json 根节点必须是对象")
    entries = [item for item in manifest.get("files") or [] if isinstance(item, dict)]
    by_role = {}
    for item in entries:
        role = str(item.get("role", "")).strip()
        if role:
            by_role.setdefault(role, []).append(item)

    survey = _select_project_pack_file(
        manifest_path, by_role.get("diag_survey", []), "diag_survey", target_partition
    )
    if not survey:
        raise PortablePackError("project-pack 未声明 diag_survey 输入")
    return {
        "manifest_path": str(manifest_path),
        "survey": survey,
        "ldf": _select_project_pack_file(
            manifest_path, by_role.get("ldf", []), "ldf", target_partition
        ),
        "project_config": _select_project_pack_file(
            manifest_path, by_role.get("project_config", []), "project_config", target_partition
        ),
    }


def build_project_context_artifact(manifest_path, output_dir, timestamp, *, return_context=False):
    """Build context from the pack and write it only to this run's output."""
    output_path = Path(output_dir) / f"project_context_{timestamp}.json"
    context = build_context_from_manifest(manifest_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(context, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    if return_context:
        return str(output_path), context
    return str(output_path)


def build_capability_gate_artifact(
    context_path, output_dir, timestamp, capability, *, context=None, satisfied_domains=()
):
    """Write a value-free gate decision for one execution capability."""
    context = context if context is not None else load_portable_json(context_path)
    if not isinstance(context, dict):
        raise PortablePackError("project_context 根节点必须是对象")
    result = evaluate_project_capability(
        context, capability, satisfied_domains=set(satisfied_domains or ())
    )
    result["project_context"] = str(Path(context_path).resolve())
    output_path = Path(output_dir) / f"project_capability_{capability}_{timestamp}.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return str(output_path), result


def build_execution_profile_artifact(
    profile_path, output_dir, timestamp, *, project_context_path=None, require_files=False
):
    """Validate and persist only a redacted execution-profile binding summary."""
    result = validate_execution_profile(
        profile_path,
        project_context_path=project_context_path,
        require_files=require_files,
    )
    output_path = Path(output_dir) / f"execution_profile_{timestamp}.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return str(output_path), result


def validate_generated_project_artifacts(
    effective_config_path: str | Path,
    project_context_path: str | Path,
    case_scripts_dir: str | Path | None = None,
) -> list[dict[str, Any]]:
    """Validate every generated JSON artifact that carries project context."""

    artifacts = [Path(effective_config_path)]
    if case_scripts_dir:
        artifacts.append(Path(case_scripts_dir) / "manifest.json")
    return [
        validate_artifact_binding(
            artifact,
            expected_context_path=project_context_path,
        )
        for artifact in artifacts
    ]


def run_script_compile(test_script):
    """无设计用例时仍审查代表脚本语法，禁止语法错误进入执行路径。"""
    result = _run_subprocess([RUNTIME_PYTHON, "-m", "py_compile", test_script],
                             "代表脚本编译检查", print_cmd=False)
    if result is None:
        return False
    if result.returncode != 0:
        print(f"[ERROR] 代表脚本 py_compile 失败: {test_script}")
        return False
    print(f"[OK] 代表脚本 py_compile 通过: {test_script}")
    return True


def run_case_scripts_all(scripts_dir):
    """执行 1:1 用例脚本（run_all.py）并汇总 results_all.json"""
    runner = os.path.join(scripts_dir, "run_all.py")
    if not os.path.isfile(runner):
        print(f"[ERROR] 未找到 {runner}（先执行 gen-scripts）")
        return False
    result = _run_subprocess([RUNTIME_PYTHON, runner], "执行全量用例脚本", utf8_env=True)
    if result is None:
        return False
    results_path = os.path.join(scripts_dir, "results_all.json")
    if not os.path.isfile(results_path):
        print(f"[ERROR] 全量执行未生成结果汇总: {results_path}")
        return False
    try:
        with open(results_path, encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        rows = data.get("results", []) if isinstance(data, dict) else []
        invalid = []
        for item in rows:
            normalized = normalize_result(item)
            item.clear()
            item.update(normalized)
            if item.get("failure_class") == "RESULT_INVALID":
                invalid.append(item)
        if invalid:
            with open(results_path, "w", encoding="utf-8", errors="replace") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            print(f"[ERROR] 结果汇总含非法状态，已标记 RESULT_INVALID 并阻断: {len(invalid)} 条")
            return False
    except (OSError, ValueError, TypeError) as exc:
        print(f"[ERROR] 全量结果汇总读取失败: {exc}")
        return False
    return result.returncode == 0


def select_minimum_hardware_cases(scripts_dir):
    """每个可执行服务选择一条最小硬件复测用例；阻塞/时序服务不伪造冒烟。"""
    manifest_path = os.path.join(scripts_dir, "manifest.json")
    if not os.path.isfile(manifest_path):
        return []
    with open(manifest_path, encoding="utf-8", errors="replace") as f:
        manifest = json.load(f)
    selected = {}
    for case_id, meta in manifest.get("cases", {}).items():
        service = str(meta.get("service", "")).lower()
        if meta.get("status") not in ("pos", "neg", "none"):
            continue
        if service not in selected:
            selected[service] = {
                "case_id": case_id,
                "service": service,
                "script": os.path.join(scripts_dir, str(meta.get("script", ""))),
                "status": meta.get("status"),
            }
    return [selected[key] for key in sorted(selected)]


def run_minimum_hardware_retest(scripts_dir, out_path):
    """先按服务做最小硬件复测，任何 FAIL/无回包都阻断全量执行。"""
    selected = select_minimum_hardware_cases(scripts_dir)
    if not selected:
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        with open(out_path, "w", encoding="utf-8", errors="replace") as f:
            json.dump({"selected": [], "results": []}, f, ensure_ascii=False, indent=2)
        print("[ERROR] 没有可执行的服务用例可供最小硬件复测，禁止全量执行")
        return False
    results = []
    for item in selected:
        script_path = item["script"]
        # 生成器将 case_id 清洗为安全文件名；冒烟读取必须复用同一规则。
        result_path = os.path.join(
            scripts_dir, "results", sanitize_strong(item["case_id"]) + ".json"
        )
        before = os.stat(result_path).st_mtime_ns if os.path.isfile(result_path) else None
        if not os.path.isfile(script_path):
            results.append({"case_id": item["case_id"], "service": item["service"],
                            "verdict": "FAIL", "failure_class": "SCRIPT_ERROR",
                            "note": "冒烟脚本不存在"})
            continue
        run = _run_subprocess([RUNTIME_PYTHON, script_path],
                              "冒烟: " + item["case_id"], utf8_env=True)
        if run is None:
            results.append({"case_id": item["case_id"], "service": item["service"],
                            "verdict": "BLOCKED", "failure_class": "INFRA_ERROR",
                            "note": "运行环境未初始化"})
            continue
        # 冒烟门禁：先看子进程退出码。脚本异常（即使崩溃前恰好写了结果文件）是脚本缺陷，
        # 不是前置受限，直接记 FAIL 阻断全量执行。
        if run.returncode != 0:
            after = os.stat(result_path).st_mtime_ns if os.path.isfile(result_path) else None
            if run.returncode == 1 and after is not None and (before is None or after != before):
                try:
                    with open(result_path, encoding="utf-8", errors="replace") as f:
                        observed = normalize_result(json.load(f))
                except (OSError, ValueError, TypeError) as exc:
                    observed = {"verdict": "FAIL", "failure_class": "RESULT_INVALID",
                                "note": f"冒烟结果读取失败: {exc}"}
                results.append({"case_id": item["case_id"], "service": item["service"],
                                "verdict": observed.get("verdict", "FAIL"),
                                "failure_class": observed.get("failure_class", "RESULT_INVALID"),
                                "actual": observed.get("actual", ""),
                                "note": observed.get("note", "")})
            else:
                results.append({"case_id": item["case_id"], "service": item["service"],
                                "verdict": "BLOCKED", "failure_class": "SCRIPT_ERROR",
                                "actual": "冒烟脚本异常退出(exit %d)" % run.returncode,
                                "note": (run.stderr or run.stdout)[-500:]})
            continue
        after = os.stat(result_path).st_mtime_ns if os.path.isfile(result_path) else None
        if after is None or (before is not None and after == before):
            results.append({"case_id": item["case_id"], "service": item["service"],
                            "verdict": "BLOCKED", "failure_class": "INFRA_ERROR",
                            "note": "冒烟未产生新的实测结果",
                            "stderr": run.stderr[-500:]})
            continue
        try:
            with open(result_path, encoding="utf-8", errors="replace") as f:
                observed = normalize_result(json.load(f))
        except (OSError, ValueError, TypeError) as exc:
            observed = {"verdict": "BLOCKED", "failure_class": "RESULT_INVALID",
                        "note": f"冒烟结果读取失败: {exc}"}
        results.append({"case_id": item["case_id"], "service": item["service"],
                        "verdict": observed.get("verdict", "FAIL"),
                        "failure_class": observed.get("failure_class", "RESULT_INVALID"),
                        "actual": observed.get("actual", ""),
                        "note": observed.get("note", "")})
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "w", encoding="utf-8", errors="replace") as f:
        json.dump({"selected": selected, "results": results}, f, ensure_ascii=False, indent=2)
    failed = [item for item in results if item.get("verdict") != "PASS"]
    if failed:
        print(f"[ERROR] 最小硬件复测未通过，阻断全量执行: {len(failed)} 条")
        return False
    print(f"[OK] 最小硬件复测通过: {len(results)} 个服务")
    return True


def run_report_html(results_json, extra_json, out_html, project_config=""):
    """执行结果 → 单文件 HTML 报告页（report_to_html.py）"""
    cmd = [RUNTIME_PYTHON, str(SCRIPT_DIR / "report_to_html.py"),
           "--results", results_json, "--out", out_html]
    if extra_json and os.path.isfile(extra_json):
        cmd += ["--extra", extra_json]
    if project_config:
        cmd += ["--project-config", project_config]
    return _run_ok(cmd, "生成 HTML 报告")


def run_error_log(results_json, out_dir, run_id="", journal=""):
    """错误处理日志：非 PASS 用例归纳为 检测→分类→处置→状态 流程"""
    cmd = [RUNTIME_PYTHON, str(SCRIPT_DIR / "error_log.py"),
           "--results", results_json, "--out-dir", out_dir]
    if run_id:
        cmd += ["--run-id", run_id]
    if journal:
        cmd += ["--journal", journal]
    return _run_ok(cmd, "生成错误处理日志")


def run_timing(**kwargs):
    """高实时时序采集与分析（采集-后处理，不走上位机 COM）"""
    cmd = [RUNTIME_PYTHON, str(SCRIPT_DIR / "timing_trace.py")]
    for key, val in kwargs.items():
        _append_cli_arg(cmd, key, val)
    return _run_ok(cmd, "执行时序采集")


def run_link_check(**kwargs):
    """执行前链路通探测（总线活动 + ECU 应答），不通返回 False 由编排器中止"""
    cmd = [RUNTIME_PYTHON, str(SCRIPT_DIR / "link_check.py")]
    for key, val in kwargs.items():
        _append_cli_arg(cmd, key, val)
    return _run_ok(cmd, "执行链路通探测")


def run_swdl_flow(output_dir, *, image="", manifest="", partition="SBL", address="",
                  key_file="", nad=0x51, brval=19200, approve_swdl=False,
                  check_memory=True, project_config="", project_id=""):
    """执行或生成 VickCAN/F1L1 SWDL 下载流程。

    计划和报告始终落盘；只有镜像、认证、Gen2 密钥和显式高风险审批全部满足，
    才会执行 LIN 硬件预检并打开 F1L1。缺口统一为 BLOCKED，不伪装成硬件 FAIL。
    项目号取自项目配置（``--project-config``，未移植项目时回退参考项目档），
    技能代码内不写任何项目字面量。
    """
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    identity = _project_identity(project_config) or {}
    resolved_project_id = project_id or str(identity.get("project") or "")
    try:
        flow = normalize_flow(FlowKind.SWDL)
        plan = build_swdl_plan(
            image_path=image,
            manifest_path=manifest,
            target_partition=partition,
            address=address,
            nad=nad,
            key_file=key_file,
        )
    except (ValueError, OSError, RuntimeError) as exc:
        print(f"[BLOCKED] SWDL 计划构建失败: {exc}")
        return False

    context_path = os.path.join(output_dir, f"flow_context_{timestamp}.json")
    context = build_flow_context(
        flow,
        run_id=f"SWDL_{timestamp}",
        output_dir=output_dir,
        project_id=resolved_project_id,
        source_files=tuple(path for path in (image, manifest, key_file) if path),
        extra={"target_partition": plan.target_partition, "hardware": "VickCAN/F1L1"},
    )
    with open(context_path, "w", encoding="utf-8", errors="replace") as handle:
        json.dump(context, handle, ensure_ascii=False, indent=2)

    print("=" * 64)
    print("SWDL 软件下载流程（VickCAN/F1L1，LIN）")
    print(f"目标分区: {plan.target_partition} ｜ NAD: 0x{plan.nad:02X}")
    print(f"segment: {len(plan.segments)} ｜ 总字节数: {plan.total_bytes}")
    print(f"流程上下文: {context_path}")
    if plan.blocked_reasons:
        print("[BLOCKED] 前置条件未满足:")
        for reason in plan.blocked_reasons:
            print(f"  - {reason}")

    flow_runner = SwdlFlow(
        plan,
        output_dir,
        approved=bool(approve_swdl),
        brval=int(brval or 19200),
        check_memory=bool(check_memory),
    )
    if plan.blocked_reasons or not approve_swdl:
        report = flow_runner.execute()
        print(f"[BLOCKED] SWDL 未进入硬件阶段，报告: {os.path.join(output_dir, 'swdl_report.json')}")
        return report.get("overall") == "PASS"

    if not run_hardware_preflight(bus="lin"):
        report = flow_runner._blocked_report(["VickCAN/F1L1 LIN 硬件预检未通过，未打开设备"])
        report["overall"] = "FAIL"
        flow_runner._write_artifacts(report, [])
        return False

    report = flow_runner.execute()
    print(f"[{'OK' if report.get('overall') == 'PASS' else 'ERROR'}] SWDL 结果: {report.get('overall')}")
    print(f"[INFO] SWDL 报告: {os.path.join(output_dir, 'swdl_report.json')}")
    return report.get("overall") == "PASS"


def run_ldf_parser(ldf_input, output_json):
    """解析 LDF（LIN 描述文件）→ lin_db.json"""
    cmd = [RUNTIME_PYTHON, str(SCRIPT_DIR / "ldf_parser.py"),
           "--input", ldf_input, "--output", output_json]
    return _run_ok(cmd, "执行 LDF 解析")


def run_audit(cases_path, out_path, audit_path, cdd="", dbc="", ldf=""):
    """用例报文审计（steps_generator）：FAIL 时退出码 2，作门禁阻断"""
    script = SCRIPT_DIR.parent.parent / "srs-uds-testcase-designer" / "scripts" / "steps_generator.py"
    if not script.is_file():
        print(f"[ERROR] steps_generator.py 不存在: {script}")
        return False
    cmd = [RUNTIME_PYTHON, str(script), "--cases", cases_path, "--out", out_path, "--audit", audit_path]
    for flag, val in (("--cdd", cdd), ("--dbc", dbc), ("--ldf", ldf)):
        if val:
            cmd += [flag, val]
    return _run_ok(cmd, "执行用例审计",
                   fail_hint="[ERROR] 用例审计存在 FAIL/错误，阻断交付（先修复用例或数据源）",
                   utf8_env=True)


def run_case_lint(cases_path, out_path, ro_dids="", sa_session_map="", project_config=""):
    """执行生成后规则 lint；FAIL 时阻断后续生成和执行。"""
    script = SCRIPT_DIR.parent.parent / "srs-uds-testcase-designer" / "scripts" / "case_lint.py"
    if not script.is_file():
        print(f"[ERROR] case_lint.py 不存在: {script}")
        return False
    cmd = [RUNTIME_PYTHON, str(script), "--cases", cases_path, "--out", out_path]
    if ro_dids:
        cmd += ["--ro-dids", ro_dids]
    if sa_session_map:
        cmd += ["--sa-session-map", sa_session_map]
    if project_config:
        cmd += ["--project-config", project_config]
    return _run_ok(cmd, "执行用例规则 lint",
                   fail_hint="[ERROR] 用例规则 lint 未通过，阻断交付")


def run_coverage(cases_path, srs_path, out_path):
    """需求覆盖率（req_coverage）：用例 ↔ REQ 追溯 + 漏测/孤儿检测"""
    script = SCRIPT_DIR.parent.parent / "srs-uds-testcase-designer" / "scripts" / "req_coverage.py"
    if not script.is_file():
        print(f"[ERROR] req_coverage.py 不存在: {script}")
        return False
    cmd = [RUNTIME_PYTHON, str(script), "--cases", cases_path, "--srs", srs_path, "--out", out_path]
    return _run_ok(cmd, "执行覆盖率")


@_timed_workflow
def project(survey_file, output_dir, **kwargs):
    """一键项目编排（含执行前门禁）：
    解析调查表 → LDF → 用例审计(可选) → 生成脚本 → 硬件预检 → 链路通探测 → 执行 → 覆盖率(可选)"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    try:
        flow = normalize_flow(kwargs.get("flow"))
        flow_definition = get_flow_definition(flow)
    except ValueError as exc:
        print(f"[ERROR] 流程选择无效: {exc}")
        return False
    project_pack = str(kwargs.get("project_pack") or "")
    project_context_path = ""
    project_context = None
    pack_inputs = None
    if project_pack and flow != FlowKind.SWDL:
        try:
            pack_inputs = resolve_project_pack_inputs(
                project_pack, kwargs.get("uds_target_partition", "")
            )
            if not survey_file:
                survey_file = pack_inputs["survey"]
            if not kwargs.get("ldf") and pack_inputs["ldf"]:
                kwargs["ldf"] = pack_inputs["ldf"]
            if not kwargs.get("project_config") and pack_inputs["project_config"]:
                kwargs["project_config"] = pack_inputs["project_config"]
            project_context_path, project_context = build_project_context_artifact(
                pack_inputs["manifest_path"], output_dir, timestamp, return_context=True
            )
            print(f"[INFO] project-pack 已接入: {pack_inputs['manifest_path']}")
            print(f"[INFO] 项目上下文已固化: {project_context_path}")
        except (OSError, PortablePackError, ValueError) as exc:
            print(f"[ERROR] project-pack 读取失败: {exc}")
            return False
    execution_profile_path = str(kwargs.get("execution_profile") or "").strip()
    execution_profile_artifact_path = ""
    execution_profile = None
    if execution_profile_path:
        profile_context_path = None
        if pack_inputs:
            candidate = Path(pack_inputs["manifest_path"]).parent / "project_context.json"
            if candidate.is_file():
                profile_context_path = str(candidate)
        try:
            execution_profile_artifact_path, execution_profile = build_execution_profile_artifact(
                execution_profile_path,
                output_dir,
                timestamp,
                project_context_path=profile_context_path,
            )
        except (OSError, ExecutionProfileError, ValueError) as exc:
            print(f"[ERROR] execution profile 校验失败: {exc}")
            return False
        print(f"[INFO] execution profile 已绑定: {execution_profile['profile_id']}")
    project_config_path = str(kwargs.get("project_config") or "")
    if project_config_path:
        project_config_path = str(Path(project_config_path).expanduser().resolve())
    project_config = _load_project_config(project_config_path)
    if project_config is None:
        return False
    satisfied_domains = set()
    if project_config_path:
        satisfied_domains.update({
            "diagnostic.session_config",
            "transport.config",
            "lint.rules",
        })
    configured_nad = int(project_config["transport"]["physical_nad"])
    raw_nad = kwargs.get("nad")
    if raw_nad in (None, ""):
        project_nad = configured_nad
    else:
        try:
            project_nad = int(str(raw_nad), 0)
        except (TypeError, ValueError):
            print(f"[ERROR] LIN NAD 无效: {raw_nad}")
            return False
    if flow == FlowKind.SWDL:
        return run_swdl_flow(
            output_dir,
            image=kwargs.get("image", ""),
            manifest=kwargs.get("manifest", ""),
            partition=kwargs.get("partition", "SBL"),
            address=kwargs.get("address", ""),
            key_file=kwargs.get("swdl_key_file", ""),
            nad=project_nad,
            brval=kwargs.get("brval", 19200),
            approve_swdl=kwargs.get("approve_swdl", False),
            check_memory=kwargs.get("check_memory", True),
            project_config=kwargs.get("project_config", ""),
        )
    if not flow_definition.implemented:
        print(f"[BLOCKED] {flow_definition.display_name} 当前仅完成结构占位，未实现业务执行。")
        print(f"[BLOCKED] 本次不生成、不发送该流程的硬件请求: {flow_definition.description}")
        return False
    os.makedirs(output_dir, exist_ok=True)
    target_partition = kwargs.get("uds_target_partition", "")
    source_input = resolve_survey_input(survey_file, target_partition)
    if not source_input:
        return False
    survey_input = source_input
    if kwargs.get("survey"):
        survey_input = resolve_survey_input(kwargs["survey"], target_partition)
        if not survey_input:
            return False
    parsed_json = os.path.join(output_dir, f"parsed_{timestamp}.json")
    lin_db = os.path.join(output_dir, f"lin_db_{timestamp}.json")
    test_script = os.path.join(output_dir, f"test_uds_{timestamp}.py")
    report_path = os.path.join(output_dir, f"report_{timestamp}.md")
    can_log_path = os.path.join(output_dir, f"can_trace_{timestamp}.asc")
    flow_context_path = os.path.join(output_dir, f"flow_context_{timestamp}.json")
    flow_sources = [str(source_input)]
    flow_extra = None
    generation_gate_path = ""
    generation_gate = None
    if project_context_path:
        flow_sources.append(project_context_path)
        try:
            generation_gate_path, generation_gate = build_capability_gate_artifact(
                project_context_path,
                output_dir,
                timestamp,
                "generation",
                context=project_context,
                satisfied_domains=satisfied_domains,
            )
        except (OSError, PortablePackError, ValueError) as exc:
            print(f"[ERROR] 项目能力门控失败: {exc}")
            return False
        flow_sources.append(generation_gate_path)
        flow_extra = {
            "project_context": project_context_path,
            "generation_gate": generation_gate_path,
        }
    if execution_profile_path:
        flow_sources.extend((execution_profile_path, execution_profile_artifact_path))
        flow_extra = dict(flow_extra or {})
        flow_extra["execution_profile"] = {
            "profile_id": execution_profile["profile_id"],
            "project_context_sha256": execution_profile["project_context"]["sha256"],
        }
        # This acknowledges only the hardware capability; project facts remain
        # in project_context and are never copied into the local profile.
        satisfied_domains.add("hardware_execution")
    flow_context = build_flow_context(
        flow,
        run_id=f"UDS_{timestamp}",
        output_dir=output_dir,
        project_id=str(kwargs.get("project_id", "")),
        source_files=tuple(flow_sources),
        extra=flow_extra,
    )
    with open(flow_context_path, "w", encoding="utf-8", errors="replace") as f:
        json.dump(flow_context, f, ensure_ascii=False, indent=2)
    # OP-09：仅 auto/空 时生成默认路径；off 关闭；其他传入值视为用户指定的证据路径，保留并校验。
    can_log_arg = str(kwargs.get("can_log", "auto"))
    if can_log_arg.lower() == "off":
        can_log_path = ""
    elif can_log_arg.lower() not in ("auto", ""):
        can_log_path = can_log_arg

    print("=" * 64)
    print(f"{flow_definition.display_name} 一键项目编排（含执行前门禁）")
    print(f"输入: {source_input}")
    print(f"输出目录: {output_dir}")
    print(f"流程: {flow_definition.kind.value} ｜ 流程上下文: {flow_context_path}")
    print("=" * 64)

    if generation_gate and generation_gate["state"] == "BLOCKED":
        print("[BLOCKED] 项目上下文缺口阻断脚本生成:")
        for item in generation_gate["blocking_gaps"]:
            print(f"  - {item['id']} ({item['status']})")
        print(f"[INFO] 能力门控证据: {generation_gate_path}")
        return False
    if generation_gate and generation_gate["state"] == "DEGRADED":
        print("[WARN] 项目上下文存在 pending 缺口，允许生成但不代表可硬件执行")
        print(f"[INFO] 能力门控证据: {generation_gate_path}")

    # OP-04：正式 project 模式锁定关键门禁，禁止绕过链路通探测或退回代表脚本冒烟。
    if kwargs.get("skip_link_check"):
        print("[ERROR] project 模式禁止 --skip-link-check：链路通探测为强制门禁，不可绕过。")
        return False
    if kwargs.get("no_case_exec"):
        print("[ERROR] project 模式禁止 --no-case-exec：提供设计用例即 1:1 全量执行，不可退回代表脚本冒烟。")
        return False

    # Step 1: 解析已明确选定的调查表
    print("\n[Step 1/8] 解析诊断调查表...")
    if not run_parser(source_input, parsed_json):
        print("[ERROR] 解析失败")
        return False
    with open(parsed_json, encoding="utf-8", errors="replace") as f:
        parsed_data = json.load(f)
    if parsed_data.get("defaults_used"):
        print("\n⚠ 以下属性使用了默认值：")
        for item in parsed_data["defaults_used"]:
            ident = item.get("did") or item.get("io_did") or item.get("rid") or item.get("dtc") or "?"
            for attr, val in item.get("defaults", []):
                print(f"  {ident}: {attr} = {val}")
    if parsed_data.get("missing_attributes"):
        print("⚠ 缺失属性：", parsed_data["missing_attributes"])

    # Step 2: 解析 LDF（LIN）
    ldf_input = kwargs.get("ldf", "")
    if ldf_input:
        print("\n[Step 2/8] 解析 LDF（LIN 描述文件）...")
        if not run_ldf_parser(ldf_input, lin_db):
            print("[WARN] LDF 解析失败，继续（LIN 帧级步骤将无法自动生成）")
    else:
        print("\n[Step 2/8] 未提供 LDF，跳过（LIN 项目强烈建议提供）")

    # Step 3: 用例审计（可选门禁）
    cases_path = kwargs.get("cases", "")
    filled_cases = ""
    if cases_path:
        print("\n[Step 3/8] 用例报文审计（steps_generator）...")
        filled_cases = os.path.join(output_dir, f"cases_filled_{timestamp}.json")
        audit_path = os.path.join(output_dir, f"audit_{timestamp}.json")
        if not run_audit(cases_path, filled_cases, audit_path,
                         cdd=kwargs.get("cdd", ""), dbc=kwargs.get("dbc", ""),
                         ldf=lin_db if ldf_input else ""):
            print("[ERROR] 用例审计未通过，阻断交付")
            return False
    else:
        print("\n[Step 3/8] 未提供用例 JSON，跳过审计（执行侧直接生成）")

    bus = kwargs.get("bus", "can")
    selected_cases = select_cases_path(cases_path, filled_cases)
    if selected_cases:
        print("\n[Step 3b/8] 用例规则 lint（R1~R5）...")
        lint_path = os.path.join(output_dir, f"case_lint_{timestamp}.md")
        ro_dids = kwargs.get("ro_dids", "") or readonly_dids_from_parsed(parsed_data)
        if not run_case_lint(selected_cases, lint_path,
                             ro_dids=ro_dids,
                             sa_session_map=kwargs.get("sa_session_map", ""),
                             project_config=project_config_path):
            print("[ERROR] 用例规则 lint 未通过，阻断交付")
            return False
        print("\n[Step 3c/8] ISO 14229 期望校验（设计期门禁）...")
        expectation_path = os.path.join(output_dir, f"expectation_check_{timestamp}.json")
        if not run_expectation_check(
                selected_cases, expectation_path,
                bus=bus if bus in ("can", "lin") else "can",
                 nad=project_nad,
                 project_config=project_config_path):
            print("[ERROR] ISO 14229 期望校验未通过，阻断生成")
            return False
    else:
        print("\n[Step 3b/8] 未提供用例 JSON，跳过规则 lint/期望校验")

    effective = resolve_effective_config(parsed_data, {**kwargs, "bus": bus})
    effective["project"] = project_config.get("project", "legacy-default")
    effective["project_config"] = project_config_path or "兼容默认配置"
    effective["transport"] = project_config.get("transport", {})
    if project_context_path:
        try:
            effective["project_context_binding"] = build_project_context_binding(
                project_context_path, output_dir
            )
        except (OSError, ProjectArtifactBindingError, ValueError) as exc:
            print(f"[ERROR] 生成产物 project_context 绑定失败: {exc}")
            return False
    confirmed = bool(kwargs.get("confirmed", False))
    if parsed_data.get("defaults_used") and not confirmed:
        print("[ERROR] 调查表存在使用默认值的属性，未获得明确确认，禁止生成。")
        print("[ERROR] 请补充这些属性，或传入 --confirmed 后重新执行。")
        return False
    if not config_gate_allows_generation(effective, confirmed, bus):
        print("[ERROR] 调查表/CLI 未提供完整 CAN 配置，禁止生成或进入硬件执行。")
        print("[ERROR] 缺失或无效的关键参数: " + ", ".join(effective["missing"]))
        print("[ERROR] 请补充 TX/RX CAN ID、波特率，或明确传入 --confirmed 确认使用默认值。")
        return False

    can = effective["can"]
    effective_config_path = os.path.join(output_dir, f"effective_config_{timestamp}.json")
    with open(effective_config_path, "w", encoding="utf-8", errors="replace") as f:
        json.dump(effective, f, ensure_ascii=False, indent=2)
    print(f"[INFO] 最终配置已固化: {effective_config_path}")
    print(f"[INFO] 统一最终 CAN 配置: channel={can['channel']}, TX=0x{can['tx_id']:X}, "
          f"RX=0x{can['rx_id']:X}, bitrate={can['bitrate']}")

    # Step 4: 生成脚本
    print("\n[Step 4/8] 生成测试脚本...")
    prereq_path = kwargs.get("prereq", "")
    if not prereq_path:
        sddb_input = survey_input
        if sddb_input and (os.path.isdir(sddb_input) or str(sddb_input).lower().endswith(".xlsx")):
            prereq_path = os.path.join(output_dir, f"service_prereq_{timestamp}.json")
            if not run_sddb_extract(sddb_input, prereq_path, parsed_json):
                print("[WARN] SDDB 前置矩阵抽取失败，继续使用文本/调查表兼容规则")
                prereq_path = ""
    gen_kwargs = {k: v for k, v in kwargs.items()
                  if k in ("channel", "serial", "can_if", "bitrate", "sample_point", "tx_id", "rx_id", "func_id",
                           "can_fd", "fd_data_bitrate", "fd_dsample_point",
                           "p2_timeout", "p2_star_timeout", "sa_dll", "sa_key_file")}
    # 所有下游步骤只接收这一份最终配置；不得再各自回退到另一套默认值。
    gen_kwargs.update({key: can[key] for key in (
        "channel", "serial", "can_if", "bitrate", "sample_point", "tx_id", "rx_id", "func_id",
        "can_fd", "fd_data_bitrate", "fd_dsample_point")})
    gen_kwargs["confirmed"] = bool(kwargs.get("confirmed", False) or bus != "can")
    if not run_generator(parsed_json, test_script, **gen_kwargs):
        print("[ERROR] 生成失败")
        return False

    # 铁律：提供设计用例即默认 1:1 全量执行（--no-case-exec 已在 project 入口锁定拒绝，见上方 OP-04）
    case_exec = bool(cases_path)
    case_scripts_dir = os.path.join(output_dir, "case_scripts")
    if case_exec:
        print("\n[Step 4b/8] 生成用例↔脚本一一对应（gen-scripts）...")
        if not run_gen_case_scripts(selected_cases, parsed_json, case_scripts_dir,
                                    bus=bus,
                                    nad=project_nad,
                                    project_config=project_config_path,
                                    sa_key_file=kwargs.get("sa_key_file", ""),
                                    survey=survey_input,
                                    did_check=kwargs.get("did_check", ""),
                                    target_partition=kwargs.get("uds_target_partition", ""),
                                    partition_gate=kwargs.get("partition_gate", "enforce"),
                                    can_runtime=test_script,
                                    project_context=project_context_path,
                                    channel=can["channel"],
                                    bitrate=can["bitrate"],
                                    tx_id=can["tx_id"],
                                    rx_id=can["rx_id"],
                                    serial=can["serial"],
                                    can_fd=can["can_fd"],
                                    prereq=prereq_path,
                                    only=kwargs.get("only", [])):
            print("[ERROR] 用例脚本生成失败")
            return False

        try:
            validate_generated_project_artifacts(
                effective_config_path,
                project_context_path,
                case_scripts_dir,
            )
        except (OSError, ProjectArtifactBindingError, ValueError) as exc:
            print(f"[ERROR] 用例脚本 project_context 绑定校验失败: {exc}")
            return False

        print("\n[Step 4c/8] 生成后脚本审查（离线，不连接硬件）...")
        script_review_path = os.path.join(output_dir, f"script_review_{timestamp}.json")
        if not run_script_review(
                selected_cases, parsed_json, case_scripts_dir, script_review_path,
                script=test_script,
                bus=bus,
                nad=project_nad,
                survey=survey_input,
                channel=can["channel"], bitrate=can["bitrate"],
                tx_id=can["tx_id"], rx_id=can["rx_id"],
                serial=can["serial"], can_fd=can["can_fd"],
                project_config=project_config_path,
                review_policy=kwargs.get("review_policy", "block"),
                depth_policy=kwargs.get("depth_policy", "report")):
            print("[ERROR] 生成后脚本审查未通过，阻断后续硬件预检和执行")
            return False
    elif not run_script_compile(test_script):
        print("[ERROR] 代表脚本审查未通过，阻断后续硬件预检和执行")
        return False

    if project_context_path and not case_exec:
        try:
            validate_generated_project_artifacts(
                effective_config_path,
                project_context_path,
            )
        except (OSError, ProjectArtifactBindingError, ValueError) as exc:
            print(f"[ERROR] 代表脚本 project_context 绑定校验失败: {exc}")
            return False

    # Step 5: 执行策略门禁 + 硬件预检
    print("\n[Step 5/8] 检测 CANoe/VickCAN、CANviex/F1L1 与 Vector XL 硬件...")
    occupying_processes, canviex_count, vector_count = detect_hardware_state()
    if direct_output_allowed(occupying_processes, canviex_count, vector_count):
        print("[INFO] 未检测到 CANoe/VickCAN 占用进程，且 CANviex/F1L1=0 台；允许直接输出脚本与设计产物。")
        print(f"[完成] 脚本: {test_script}" + (f" ｜ 用例脚本目录: {case_scripts_dir}" if case_exec else ""))
        return True

    print("[INFO] 检测到硬件/占用环境或探测结果未知，强制进入硬件执行路径。")
    if execution_profile_path:
        try:
            build_execution_profile_artifact(
                execution_profile_path,
                output_dir,
                timestamp,
                project_context_path=(
                    str(Path(pack_inputs["manifest_path"]).parent / "project_context.json")
                    if pack_inputs and (Path(pack_inputs["manifest_path"]).parent / "project_context.json").is_file()
                    else None
                ),
                require_files=True,
            )
        except (OSError, ExecutionProfileError, ValueError) as exc:
            print(f"[BLOCKED] execution profile 文件检查失败，禁止硬件执行: {exc}")
            return False
    if project_context_path:
        try:
            hardware_gate_path, hardware_gate = build_capability_gate_artifact(
                project_context_path,
                output_dir,
                timestamp,
                "hardware_execution",
                context=project_context,
                satisfied_domains=satisfied_domains,
            )
        except (OSError, PortablePackError, ValueError) as exc:
            print(f"[ERROR] 硬件能力门控失败: {exc}")
            return False
        if hardware_gate["state"] == "BLOCKED":
            print("[BLOCKED] 项目上下文缺口阻断硬件执行:")
            for item in hardware_gate["blocking_gaps"]:
                print(f"  - {item['id']} ({item['status']})")
            print(f"[INFO] 能力门控证据: {hardware_gate_path}")
            return False
    print("\n[Step 5/8] 硬件预检（后端/进程占用/通道）...")
    if not run_hardware_preflight(bus=bus):
        print("[ERROR] 硬件预检未通过（先关闭 VickCAN/CANoe 或检查 CANviex/Vector 硬件）")
        return False

    # Step 6: 链路通探测（强制门禁；--skip-link-check 已在 project 入口锁定拒绝，无跳过分支）
    print("\n[Step 6/8] 链路通探测（总线活动 + ECU 应答）...")
    link_kwargs = {"bus": bus}
    if bus == "can":
        link_kwargs.update(channel=can["channel"], tx_id=can["tx_id"],
                           rx_id=can["rx_id"], bitrate=can["bitrate"],
                           serial=can["serial"])
    else:
        link_kwargs.update(nad=project_nad,
                           brval=_effective_lin_bitrate(kwargs))
    if not run_link_check(**link_kwargs):
        print("[ERROR] 链路不通，中止执行（修复环境后重跑）")
        return False

    # Step 7: 执行（case-exec=1:1 全量；否则代表脚本）。
    # 全量执行失败仍继续生成报告、错误日志和覆盖率，最后统一传播失败状态。
    execution_ok = True
    report_ok = True
    error_log_ok = True
    if case_exec:
        print("\n[Step 6b/8] 按服务执行最小硬件复测（冒烟门禁）...")
        smoke_path = os.path.join(output_dir, f"hardware_smoke_{timestamp}.json")
        if not run_minimum_hardware_retest(case_scripts_dir, smoke_path):
            print("[ERROR] 最小硬件复测未通过，禁止进入 1:1 全量执行")
            return False
        print("\n[Step 7/8] 执行全量用例脚本（run_all，1:1）...")
        execution_ok = run_case_scripts_all(case_scripts_dir)
        if not execution_ok:
            print("[WARNING] 部分用例脚本异常，查看 results_all.json")
        results_all = os.path.join(case_scripts_dir, "results_all.json")
        if os.path.isfile(results_all):
            html_out = os.path.join(output_dir, f"report_{timestamp}.html")
            report_ok = run_report_html(results_all, kwargs.get("extra", ""), html_out,
                                        project_config=kwargs.get("project_config", ""))
            journal = os.path.join(output_dir, "error_journal.jsonl")
            identity = _project_identity(kwargs.get("project_config", "")) or {}
            error_log_ok = run_error_log(results_all, output_dir,
                                         run_id=f"{identity.get('run_id_prefix', 'UDS')}_{timestamp}",
                                         journal=journal)
            print(f"[完成] 全量结果: {results_all}")
            print(f"[完成] HTML 报告: {html_out}")
        else:
            report_ok = False
            error_log_ok = False
            print(f"[ERROR] 未生成全量结果: {results_all}")
    else:
        print("\n[Step 7/8] 执行测试（代表脚本）...")
        run_kwargs = {key: can[key] for key in (
            "channel", "serial", "can_if", "bitrate", "sample_point", "tx_id", "rx_id", "func_id",
            "can_fd", "fd_data_bitrate", "fd_dsample_point")}
        run_kwargs["can_log"] = can_log_path
        execution_ok = run_test_script(test_script, report_path, **run_kwargs)
        if not execution_ok:
            print("[WARNING] 测试执行可能有错误，请查看报告")
        print(f"[完成] 报告: {report_path}")

    # Step 8: 覆盖率（可选）
    srs_path = kwargs.get("srs", "")
    coverage_ok = True
    if selected_cases and srs_path:
        print("\n[Step 8/8] 需求覆盖率...")
        cov_out = os.path.join(output_dir, f"coverage_{timestamp}.md")
        coverage_ok = run_coverage(selected_cases, srs_path, cov_out)
    else:
        print("\n[Step 8/8] 跳过覆盖率（需 --cases + --srs）")
    return execution_ok and report_ok and error_log_ok and coverage_ok


def pipeline(survey_file, output_dir, **kwargs):
    """兼容入口；严格复用 project，禁止维护第二套执行流程。"""
    return project(survey_file, output_dir, **kwargs)


def main():
    parser = argparse.ArgumentParser(description="UDS测试执行器 (Windows + Vector)")
    sub = parser.add_subparsers(dest="command", help="子命令")

    # parse子命令
    p_parse = sub.add_parser("parse", help="仅解析诊断调查表")
    p_parse.add_argument("--input", "-i", required=True, help="诊断调查表文件")
    p_parse.add_argument("--output", "-o", required=True, help="输出JSON")

    # execution-profile 子命令
    p_profile = sub.add_parser(
        "execution-profile-check",
        help="校验机器本地 execution profile 与项目上下文绑定",
    )
    p_profile.add_argument("--profile", required=True, help="execution_profile.local.json")
    p_profile.add_argument("--project-context", default="", help="覆盖 profile 中 path 的 project_context.json")
    p_profile.add_argument("--require-files", action="store_true", help="同时检查 Python 和传输 DLL 文件")
    p_profile.add_argument("--out", default="", help="输出脱敏后的绑定摘要 JSON")

    # generate子命令
    p_gen = sub.add_parser("generate", help="基于解析结果生成测试脚本")
    p_gen.add_argument("--input", "-i", required=True, help="解析后的JSON")
    p_gen.add_argument("--output", "-o", required=True, help="输出测试脚本")
    p_gen.add_argument("--channel", default="", help="CAN通道 (Vector: 0-3, 如VN1630A)")
    p_gen.add_argument("--serial", default="", help="Vector 设备序列号 (留空=自动; 多盒子时指定 VN1630A/VN1640A)")
    p_gen.add_argument("--can-if", default="vector", choices=["vector"],
                        help="CAN接口类型 (仅支持vector, Vector XL Driver Library)")
    p_gen.add_argument("--bitrate", type=int, default=None, help="显式覆盖CAN波特率；留空则使用调查表/默认值")
    p_gen.add_argument("--sample-point", type=float, default=None, help="显式覆盖CAN采样点 (0.0~1.0)")
    p_gen.add_argument("--can-fd", action="store_true", default=False, help="启用CAN FD模式")
    p_gen.add_argument("--fd-data-bitrate", type=int, default=None, help="显式覆盖CAN FD数据段波特率")
    p_gen.add_argument("--fd-dsample-point", type=float, default=None, help="显式覆盖CAN FD数据段采样点 (0.0~1.0)")
    p_gen.add_argument("--tx-id", default=None, help="显式覆盖发送CAN ID")
    p_gen.add_argument("--rx-id", default=None, help="显式覆盖接收CAN ID")
    p_gen.add_argument("--sa-dll", default="", help="$27 SeedKey DLL路径 (Vector标准接口)")
    p_gen.add_argument("--sa-key-file", default="", help="$27 Gen2 密钥 JSON 文件（占位 0xFF 会标 BLOCKED）")
    p_gen.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    p_gen.add_argument("--confirmed", action="store_true", default=False,
                       help="明确确认调查表缺失关键 CAN 参数时使用硬编码默认值")

    # preflight子命令
    p_pre = sub.add_parser("preflight", help="执行前硬件预检（Vector 后端/进程占用/通道）")

    # run子命令
    p_run = sub.add_parser("run", help="执行测试脚本")
    p_run.add_argument("--test-script", "-t", required=True, help="测试脚本路径")
    p_run.add_argument("--report", "-r", default="uds_test_report.md", help="报告输出路径")
    p_run.add_argument("--channel", default="", help="CAN通道 (Vector: 0-3)")
    p_run.add_argument("--serial", default="", help="Vector 设备序列号 (留空=自动; 多盒子时指定 VN1630A/VN1640A)")
    p_run.add_argument("--can-if", default="vector", choices=["vector"],
                        help="CAN接口类型 (仅支持vector, Vector XL Driver Library)")
    p_run.add_argument("--bitrate", type=int, default=None, help="显式覆盖CAN波特率；留空则使用脚本内默认值")
    p_run.add_argument("--sample-point", type=float, default=None, help="显式覆盖CAN采样点 (0.0~1.0)")
    p_run.add_argument("--can-fd", action="store_true", default=False, help="启用CAN FD模式")
    p_run.add_argument("--fd-data-bitrate", type=int, default=None, help="显式覆盖CAN FD数据段波特率")
    p_run.add_argument("--fd-dsample-point", type=float, default=None, help="显式覆盖CAN FD数据段采样点 (0.0~1.0)")
    p_run.add_argument("--tx-id", default=None, help="显式覆盖发送CAN ID")
    p_run.add_argument("--rx-id", default=None, help="显式覆盖接收CAN ID")
    p_run.add_argument("--can-log", default="", help="CAN通信日志输出路径 (支持.asc/.blf格式, 留空则不记录)")

    # pipeline子命令
    p_pipe = sub.add_parser("pipeline", help="完整流水线：解析→生成→执行→报告")
    p_pipe.add_argument("--input", "-i", default="",
                        help="诊断调查表文件；使用 --project-pack 时可省略")
    p_pipe.add_argument("--project-pack", default="",
                        help="可移植 project-pack 目录或 input_manifest.json")
    p_pipe.add_argument("--execution-profile", default="",
                        help="机器本地 execution profile；仅用于绑定运行环境，不进入项目上下文")
    p_pipe.add_argument("--output-dir", "-o", default="./uds_test_output", help="输出目录")
    p_pipe.add_argument("--channel", default="", help="CAN通道 (Vector: 0-3)")
    p_pipe.add_argument("--serial", default="", help="Vector 设备序列号 (留空=自动; 多盒子时指定 VN1630A/VN1640A)")
    p_pipe.add_argument("--can-if", default="vector", choices=["vector"],
                        help="CAN接口类型 (仅支持vector, Vector XL Driver Library)")
    p_pipe.add_argument("--bitrate", type=int, default=None, help="显式覆盖CAN波特率；留空则使用调查表/默认值")
    p_pipe.add_argument("--sample-point", type=float, default=None, help="显式覆盖CAN采样点 (0.0~1.0)")
    p_pipe.add_argument("--can-fd", action="store_true", default=None, help="启用CAN FD模式")
    p_pipe.add_argument("--fd-data-bitrate", type=int, default=None, help="显式覆盖CAN FD数据段波特率")
    p_pipe.add_argument("--fd-dsample-point", type=float, default=None, help="显式覆盖CAN FD数据段采样点 (0.0~1.0)")
    p_pipe.add_argument("--can-log", default="auto", help="CAN通信日志: auto=自动生成.asc, off=不记录, 或指定路径")
    p_pipe.add_argument("--tx-id", default=None, help="显式覆盖发送CAN ID")
    p_pipe.add_argument("--rx-id", default=None, help="显式覆盖接收CAN ID")
    p_pipe.add_argument("--func-id", default=None, help="显式覆盖功能寻址CAN ID")
    p_pipe.add_argument("--sa-dll", default="", help="$27 SeedKey DLL路径 (Vector标准接口)")
    p_pipe.add_argument("--sa-key-file", default="", help="$27 Gen2 密钥 JSON 文件（占位 0xFF 会标 BLOCKED）")
    p_pipe.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    p_pipe.add_argument("--uds-target-partition", choices=["APP", "PBL", "SBL"], default="",
                        help="UDS 用例目标分区；留空时必须由用例字段或文本明确推断")
    p_pipe.add_argument("--partition-gate", choices=["enforce", "report", "off"], default="enforce",
                        help="UDS 分区/语义门禁：enforce=阻断，report=只记录，off=关闭")
    p_pipe.add_argument("--confirmed", action="store_true", default=False,
                        help="明确确认调查表缺失关键 CAN 参数时使用硬编码默认值")
    p_pipe.add_argument("--preflight", action="store_true", help="执行前先跑硬件预检（后端/进程占用/通道）")
    p_pipe.add_argument("--flow", choices=[item.value for item in FlowKind], default="basic_uds",
                        help="单次运行的业务流程；basic_uds 或 SWDL")
    p_pipe.add_argument("--image", default="", help="SWDL raw binary 镜像（与 --manifest 二选一/配合）")
    p_pipe.add_argument("--manifest", default="", help="SWDL JSON manifest（地址、认证和 segment 元数据）")
    p_pipe.add_argument("--partition", choices=["PBL", "SBL"], default="SBL", help="SWDL 目标分区")
    p_pipe.add_argument("--address", default="", help="单一 raw binary 的 4 字节起始地址，如 0x00010000")
    p_pipe.add_argument("--key-file", dest="swdl_key_file", default="", help="SWDL 0x27 Gen2 密钥 JSON")
    p_pipe.add_argument("--brval", type=int, default=19200, help="VickCAN/F1L1 LIN 波特率")
    p_pipe.add_argument("--approve-swdl", action="store_true", help="显式批准高风险 SWDL 硬件写入")
    p_pipe.add_argument("--skip-check-memory", dest="check_memory", action="store_false", default=True,
                        help="跳过下载后的 0x31 01 02 12 Check Memory（不建议）")

    # swdl 子命令：独立于 CAN/CANoe 的 VickCAN/F1L1 下载入口
    p_swdl = sub.add_parser("swdl", help="VickCAN/F1L1 LIN SWDL 下载：计划/认证/密钥/硬件门禁")
    p_swdl.add_argument("--output-dir", "-o", default="./swdl_output")
    p_swdl.add_argument("--image", default="", help="raw binary 镜像路径")
    p_swdl.add_argument("--manifest", default="", help="JSON manifest（推荐，含 segment 地址和认证状态）")
    p_swdl.add_argument("--partition", choices=["PBL", "SBL"], default="SBL")
    p_swdl.add_argument("--address", default="", help="单一 raw binary 起始地址，如 0x00010000")
    p_swdl.add_argument("--key-file", dest="swdl_key_file", default="", help="0x27 Gen2 密钥 JSON")
    p_swdl.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    p_swdl.add_argument("--nad", type=lambda s: int(s, 0), default=None)
    p_swdl.add_argument("--brval", type=int, default=19200)
    p_swdl.add_argument("--approve-swdl", action="store_true", help="显式批准高风险 SWDL 硬件写入")
    p_swdl.add_argument("--skip-check-memory", dest="check_memory", action="store_false", default=True,
                        help="跳过下载后的 0x31 01 02 12 Check Memory（不建议）")

    # link-check子命令
    p_link = sub.add_parser("link-check", help="执行前链路通探测（总线活动 + ECU 应答），不通返回 1")
    p_link.add_argument("--bus", choices=["can", "lin"], default="can", help="总线类型")
    p_link.add_argument("--channel", default="0", help="CAN 通道 (Vector: 0-3)")
    p_link.add_argument("--tx-id", type=lambda s: int(s, 0), default=None, help="诊断请求 CAN ID")
    p_link.add_argument("--rx-id", type=lambda s: int(s, 0), default=None, help="诊断响应 CAN ID")
    p_link.add_argument("--bitrate", type=int, default=None, help="CAN/LIN 波特率")
    p_link.add_argument("--serial", default="", help="Vector 设备序列号")
    p_link.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    p_link.add_argument("--nad", type=lambda s: int(s, 0), default=None, help="LIN 从机 NAD（未传时使用项目配置）")

    # sddb-extract 子命令（离线构建服务前置矩阵）
    p_sddb = sub.add_parser("sddb-extract", help="从 SDDB/诊断调查表抽取 service_prereq.json")
    p_sddb.add_argument("--input", "-i", required=True, help="SDDB xlsx 文件或目录")
    p_sddb.add_argument("--parsed", default="", help="可选 uds_parsed.json")
    p_sddb.add_argument("--output", "-o", required=True, help="service_prereq.json 输出路径")

    # timing子命令
    p_timing = sub.add_parser("timing", help="高实时时序采集-后处理（帧隙/P2/P2*/0x37，不走上位机 COM）")
    p_timing.add_argument("--bus", choices=["can", "lin"], default="lin", help="总线类型")
    p_timing.add_argument("--duration", type=float, default=10.0, help="采集时长（秒）")
    p_timing.add_argument("--out", "-o", help="Markdown 报告输出路径")
    p_timing.add_argument("--nad", type=lambda s: int(s, 0), default=None, help="LIN 从机 NAD")
    p_timing.add_argument("--brval", type=int, default=None, help="LIN 波特率")
    p_timing.add_argument("--channel", default="0", help="CAN 通道")
    p_timing.add_argument("--tx-id", type=lambda s: int(s, 0), default=None, help="CAN 请求 ID")
    p_timing.add_argument("--rx-id", type=lambda s: int(s, 0), default=None, help="CAN 应答 ID")
    p_timing.add_argument("--bitrate", type=int, default=None, help="CAN 波特率")
    p_timing.add_argument("--serial", default="", help="Vector 设备序列号")
    p_timing.add_argument("--project-config", default="", help="项目配置 JSON（可选）")

    # gen-scripts子命令（用例↔脚本 一一对应）
    p_gs = sub.add_parser("gen-scripts", help="用例↔脚本 一一对应生成：每条用例唯一脚本 + manifest + run_all")
    p_gs.add_argument("--cases", "-c", required=True, help="设计用例 JSON（case-schema，如 503 条）")
    p_gs.add_argument("--parsed", "-p", required=True, help="uds_parsed.json（调查表解析）")
    p_gs.add_argument("--out-dir", "-o", default="./case_scripts")
    p_gs.add_argument("--project-context", default="",
                      help="project_context.json；写入 manifest 绑定摘要并供 run_all 执行前校验")
    p_gs.add_argument("--bus", choices=["lin", "can"], default="lin")
    p_gs.add_argument("--nad", type=lambda s: int(s, 0), default=None)
    p_gs.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    p_gs.add_argument("--sa-key-file", default="")
    p_gs.add_argument("--survey", default="", help="诊断调查表目录/文件（解析例程请求长度自动补参）")
    p_gs.add_argument("--did-check", default="", help="DID检查表 xlsx（DID×APP/PBL/SBL 支持矩阵，0x22 分层受限判定）")
    p_gs.add_argument("--target-partition", choices=["APP", "PBL", "SBL"], default="",
                      help="本批 UDS 用例目标分区；用例自身字段优先")
    p_gs.add_argument("--partition-gate", choices=["enforce", "report", "off"], default="enforce",
                      help="UDS 分区/语义门禁：enforce=阻断，report=只记录，off=关闭")
    p_gs.add_argument("--can-runtime", default="", help="CAN 运行时脚本（通常传入生成的 uds_test.py）")
    p_gs.add_argument("--channel", default="0", help="CAN 通道")
    p_gs.add_argument("--bitrate", type=int, default=500000, help="CAN 波特率")
    p_gs.add_argument("--tx-id", type=lambda s: int(s, 0), default=0x7E0, help="CAN 请求 ID")
    p_gs.add_argument("--rx-id", type=lambda s: int(s, 0), default=0x7E8, help="CAN 响应 ID")
    p_gs.add_argument("--serial", default="", help="Vector 设备序列号")
    p_gs.add_argument("--can-fd", action="store_true", default=False, help="启用 CAN FD")
    p_gs.add_argument("--prereq", default="", help="service_prereq.json（SDDB 前置矩阵）")
    p_gs.add_argument("--only", nargs="+", default=[], help="仅增量重建指定 case_id")
    p_gs.add_argument("--confirmed", action="store_true", default=False,
                      help="明确确认调查表缺失关键 CAN 参数时使用硬编码默认值")

    # script-review 子命令（生成后离线审查，不连接硬件）
    p_sr = sub.add_parser("script-review", help="生成后离线审查脚本与用例映射，未通过则禁止硬件执行")
    p_sr.add_argument("--cases", "-c", required=True, help="设计用例 JSON")
    p_sr.add_argument("--parsed", "-p", required=True, help="uds_parsed.json")
    p_sr.add_argument("--scripts-dir", required=True, help="gen-scripts 输出目录")
    p_sr.add_argument("--script", default="", help="代表/主测试脚本，可选")
    p_sr.add_argument("--bus", choices=["lin", "can"], default="lin")
    p_sr.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    p_sr.add_argument("--nad", type=lambda s: int(s, 0), default=None)
    p_sr.add_argument("--survey", default="")
    p_sr.add_argument("--out", default="", help="审查 JSON 输出路径")
    p_sr.add_argument("--review-policy", choices=["block", "report"], default="block",
                      help="REVIEW_REQUIRED 处置：block=退出码 3 阻断；report=仅输出待确认清单不阻断")
    p_sr.add_argument("--depth-policy", choices=["report", "block"], default="report",
                      help="深度完备性缺口：report=核对表不阻断；block=缺口升级 REVIEW_REQUIRED")

    # expectation-check 子命令（设计期 ISO 14229 语义门禁）
    p_ec = sub.add_parser("expectation-check", help="设计期 ISO 14229 期望校验，不连接硬件")
    p_ec.add_argument("--cases", "-c", required=True, help="设计用例 JSON")
    p_ec.add_argument("--bus", choices=["lin", "can"], default="lin")
    p_ec.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    p_ec.add_argument("--nad", type=lambda s: int(s, 0), default=None)
    p_ec.add_argument("--out", "-o", required=True, help="校验 JSON 输出路径")

    # error-log子命令
    p_el = sub.add_parser("error-log", help="错误处理日志：非 PASS 用例归纳 检测→分类→处置→状态（可累积 journal）")
    p_el.add_argument("--results", "-r", required=True, help="执行结果 JSON")
    p_el.add_argument("--out-dir", "-o", default="./error_log")
    p_el.add_argument("--run-id", default="", help="本轮标识")
    p_el.add_argument("--journal", "-j", default="", help="追加日志 jsonl（累积每一次执行）")

    # project子命令（一键编排，含门禁）
    p_proj = sub.add_parser("project", help="一键项目编排：解析→LDF→审计→生成→预检→链路探测→执行→覆盖率")
    p_proj.add_argument("--input", "-i", default="",
                        help="诊断调查表文件或目录；使用 --project-pack 时可省略")
    p_proj.add_argument("--project-pack", default="",
                        help="可移植 project-pack 目录或 input_manifest.json")
    p_proj.add_argument("--execution-profile", default="",
                        help="机器本地 execution profile；仅用于绑定运行环境，不进入项目上下文")
    p_proj.add_argument("--output-dir", "-o", default="./uds_project_output", help="输出目录")
    p_proj.add_argument("--ldf", default="", help="LDF 文件（LIN 项目，解析为 lin_db.json）")
    p_proj.add_argument("--cdd", default="", help="CDD 诊断文件（用例审计用）")
    p_proj.add_argument("--dbc", default="", help="DBC 文件（用例审计用）")
    p_proj.add_argument("--cases", default="", help="设计用例 JSON（可选，做报文审计 + 覆盖率）")
    p_proj.add_argument("--srs", default="", help="SRS 明文 txt（可选，覆盖率用）")
    p_proj.add_argument("--ro-dids", default="", help="只读 DID 列表（逗号分隔，覆盖自动识别结果）")
    p_proj.add_argument("--sa-session-map", default="", help="0x27 等级会话映射（如 01:02,05:03）")
    p_proj.add_argument("--bus", choices=["can", "lin"], default="can", help="链路探测总线类型")
    p_proj.add_argument("--channel", default="0", help="CAN 通道 (Vector: 0-3)")
    p_proj.add_argument("--serial", default="", help="Vector 设备序列号")
    p_proj.add_argument("--bitrate", type=int, default=None, help="CAN 波特率")
    p_proj.add_argument("--sample-point", type=float, default=None, help="CAN 采样点")
    p_proj.add_argument("--tx-id", default=None, help="发送 CAN ID")
    p_proj.add_argument("--rx-id", default=None, help="接收 CAN ID")
    p_proj.add_argument("--func-id", default=None, help="功能寻址 CAN ID")
    p_proj.add_argument("--can-fd", action="store_true", default=None, help="CAN FD")
    p_proj.add_argument("--fd-data-bitrate", type=int, default=None, help="CAN FD 数据段波特率")
    p_proj.add_argument("--fd-dsample-point", type=float, default=None, help="CAN FD 数据段采样点")
    p_proj.add_argument("--sa-dll", default="", help="$27 SeedKey DLL路径 (Vector标准接口)")
    p_proj.add_argument("--sa-key-file", default="", help="$27 Gen2 密钥 JSON 文件")
    p_proj.add_argument("--confirmed", action="store_true", default=False,
                        help="明确确认调查表缺失关键 CAN 参数时使用硬编码默认值")
    p_proj.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    p_proj.add_argument("--nad", default=None, help="LIN 从机 NAD；未传时使用项目配置")
    p_proj.add_argument("--skip-link-check", action="store_true",
                        help="（已锁定：project 模式拒绝此参数，链路探测为强制门禁）")
    p_proj.add_argument("--no-case-exec", action="store_true",
                        help="（已锁定：project 模式拒绝此参数，提供用例即 1:1 全量执行）")
    p_proj.add_argument("--extra", default="", help="HTML 报告附加数据 JSON（report_to_html.py --extra）")
    p_proj.add_argument("--did-check", default="", help="DID检查表 xlsx（DID×APP/PBL/SBL 支持矩阵，0x22 分层受限判定）")
    p_proj.add_argument("--uds-target-partition", choices=["APP", "PBL", "SBL"], default="",
                        help="UDS 用例目标分区；与 SWDL 的 --partition 分开")
    p_proj.add_argument("--partition-gate", choices=["enforce", "report", "off"], default="enforce",
                        help="UDS 分区/语义门禁：enforce=阻断，report=只记录，off=关闭")
    p_proj.add_argument("--review-policy", choices=["block", "report"], default="block",
                        help="生成后审查 REVIEW_REQUIRED 处置：block=整轮阻断（默认，维持既有行为）；"
                             "report=深而疑用例不再卡死整轮，转为待人工确认清单")
    p_proj.add_argument("--depth-policy", choices=["report", "block"], default="report",
                        help="深度完备性（P0-1）：report=审查报告输出核对表不改变判定（默认）；"
                             "block=存在深度缺口时审查以退出码 3 阻断")
    p_proj.add_argument("--prereq", default="", help="service_prereq.json（SDDB 前置矩阵）")
    p_proj.add_argument("--only", nargs="+", default=[], help="仅增量重建指定 case_id")
    p_proj.add_argument("--flow", choices=[item.value for item in FlowKind], default="basic_uds",
                        help="单次运行的业务流程；basic_uds 或 SWDL")
    p_proj.add_argument("--image", default="", help="SWDL raw binary 镜像")
    p_proj.add_argument("--manifest", default="", help="SWDL JSON manifest")
    p_proj.add_argument("--partition", choices=["PBL", "SBL"], default="SBL", help="SWDL 目标分区")
    p_proj.add_argument("--address", default="", help="单一 raw binary 的 4 字节起始地址")
    p_proj.add_argument("--key-file", dest="swdl_key_file", default="", help="SWDL 0x27 Gen2 密钥 JSON")
    p_proj.add_argument("--brval", type=int, default=19200, help="VickCAN/F1L1 LIN 波特率")
    p_proj.add_argument("--approve-swdl", action="store_true", help="显式批准高风险 SWDL 硬件写入")
    p_proj.add_argument("--skip-check-memory", dest="check_memory", action="store_false", default=True,
                        help="跳过下载后的 Check Memory（不建议）")

    args = parser.parse_args()

    if args.command == "execution-profile-check":
        try:
            result = validate_execution_profile(
                args.profile,
                project_context_path=args.project_context or None,
                require_files=args.require_files,
            )
            if args.out:
                output = Path(args.out)
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(
                    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8",
                )
            print(f"[OK] execution profile: {result['profile_id']}")
            success = True
        except (OSError, ExecutionProfileError, ValueError) as exc:
            print(f"[ERROR] execution profile 校验失败: {exc}")
            success = False
    elif args.command == "error-log":
        success = run_error_log(args.results, args.out_dir, run_id=args.run_id, journal=args.journal)
    elif args.command == "expectation-check":
        nad = _effective_nad(args.nad, args.project_config)
        success = nad is not None and run_expectation_check(
            args.cases, args.out, bus=args.bus, nad=nad,
            project_config=args.project_config,
        )
    elif args.command == "sddb-extract":
        success = run_sddb_extract(args.input, args.output, args.parsed)
    elif args.command == "script-review":
        nad = _effective_nad(args.nad, args.project_config)
        review_kwargs = {
            "script": args.script,
            "bus": args.bus,
            "nad": nad,
            "survey": args.survey,
            "project_config": args.project_config,
            "review_policy": args.review_policy,
            "depth_policy": args.depth_policy,
        }
        success = run_script_review(args.cases, args.parsed, args.scripts_dir,
                                    args.out, **review_kwargs)
    elif args.command == "gen-scripts":
        gs_kwargs = {k: getattr(args, k, None) for k in
                     ("bus", "nad", "sa_key_file", "survey", "did_check", "target_partition",
                      "partition_gate", "can_runtime",
                      "channel", "bitrate", "tx_id", "rx_id", "serial", "can_fd", "confirmed",
                      "prereq", "only", "project_config", "project_context")}
        success = run_gen_case_scripts(args.cases, args.parsed, args.out_dir, **gs_kwargs)
        if success:
            review_out = os.path.join(args.out_dir, "script_review.json")
            review_nad = args.nad
            if review_nad is None:
                review_nad = _project_physical_nad(args.project_config)
            success = run_script_review(
                args.cases, args.parsed, args.out_dir, review_out,
                bus=args.bus, nad=review_nad, survey=args.survey,
                project_config=args.project_config)
    elif args.command == "timing":
        t_kwargs = {k: getattr(args, k, None) for k in
                     ("bus", "duration", "out", "nad", "brval", "channel", "tx_id", "rx_id", "bitrate", "serial")}
        t_kwargs["nad"] = _effective_nad(args.nad, args.project_config)
        success = run_timing(**t_kwargs)
    elif args.command == "link-check":
        link_kwargs = {"bus": args.bus, "channel": args.channel, "tx_id": args.tx_id,
                       "rx_id": args.rx_id, "bitrate": args.bitrate, "serial": args.serial,
                       "nad": _effective_nad(args.nad, args.project_config)}
        success = run_link_check(**link_kwargs)
    elif args.command == "swdl":
        success = run_swdl_flow(
            args.output_dir,
            image=args.image,
            manifest=args.manifest,
            partition=args.partition,
            address=args.address,
            key_file=args.swdl_key_file,
            nad=_effective_nad(args.nad, args.project_config),
            brval=args.brval,
            approve_swdl=args.approve_swdl,
            check_memory=args.check_memory,
            project_config=args.project_config,
        )
    elif args.command == "project":
        proj_keys = ("ldf", "cdd", "dbc", "cases", "srs", "bus", "channel", "serial",
                     "bitrate", "sample_point", "tx_id", "rx_id", "func_id",
                     "can_fd", "fd_data_bitrate", "fd_dsample_point", "sa_dll", "sa_key_file",
                     "nad", "project_config", "skip_link_check", "ro_dids", "sa_session_map",
                     "no_case_exec", "extra", "did_check", "confirmed", "flow", "image",
                     "uds_target_partition", "partition_gate",
                     "review_policy", "depth_policy",
                     "prereq", "only",
                     "manifest", "partition", "address", "swdl_key_file", "brval",
                     "approve_swdl", "check_memory", "project_pack", "execution_profile")
        proj_kwargs = {k: getattr(args, k, None) for k in proj_keys}
        success = project(args.input, args.output_dir, **proj_kwargs)
    elif args.command == "preflight":
        success = run_preflight()
    elif args.command == "parse":
        success = run_parser(args.input, args.output)
    elif args.command == "generate":
        can_if_val = getattr(args, 'can_if', 'vector')
        success = run_generator(args.input, args.output,
                                channel=args.channel, can_if=can_if_val,
                                serial=args.serial,
                                bitrate=args.bitrate,
                                sample_point=args.sample_point,
                                can_fd=args.can_fd,
                                fd_data_bitrate=args.fd_data_bitrate,
                                fd_dsample_point=args.fd_dsample_point,
                                tx_id=args.tx_id, rx_id=args.rx_id,
                                sa_dll=args.sa_dll, sa_key_file=args.sa_key_file,
                                confirmed=args.confirmed)
    elif args.command == "run":
        can_if_val = getattr(args, 'can_if', 'vector')
        success = run_test_script(args.test_script, args.report,
                                  channel=args.channel, can_if=can_if_val,
                                  serial=args.serial,
                                  bitrate=args.bitrate,
                                  sample_point=args.sample_point,
                                  can_fd=args.can_fd,
                                  fd_data_bitrate=args.fd_data_bitrate,
                                  fd_dsample_point=args.fd_dsample_point,
                                  can_log=args.can_log,
                                  tx_id=args.tx_id, rx_id=args.rx_id)
    elif args.command == "pipeline":
        can_if_val = getattr(args, 'can_if', 'vector')
        pipeline_kwargs = {
            "channel": args.channel, "can_if": can_if_val, "serial": args.serial,
            "bitrate": args.bitrate, "sample_point": args.sample_point,
            "can_fd": args.can_fd, "fd_data_bitrate": args.fd_data_bitrate,
            "fd_dsample_point": args.fd_dsample_point, "can_log": args.can_log,
            "tx_id": args.tx_id, "rx_id": args.rx_id, "func_id": args.func_id,
            "sa_dll": args.sa_dll, "sa_key_file": args.sa_key_file,
            "confirmed": args.confirmed, "flow": args.flow,
            "uds_target_partition": args.uds_target_partition,
            "partition_gate": args.partition_gate,
            "image": args.image, "manifest": args.manifest, "partition": args.partition,
            "address": args.address, "swdl_key_file": args.swdl_key_file,
            "brval": args.brval, "approve_swdl": args.approve_swdl,
            "check_memory": args.check_memory, "project_config": args.project_config,
            "execution_profile": args.execution_profile,
        }
        if args.project_pack:
            pipeline_kwargs["project_pack"] = args.project_pack
        success = pipeline(args.input, args.output_dir, **pipeline_kwargs)
    else:
        parser.print_help()
        success = True

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
