#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAN 接口检查/初始化 - Windows + Vector (VN1630A 等, XL Driver Library)

用法:
    python can_init.py --check                  # 检查 Vector 后端 + 硬件通道 (默认)
    python can_init.py --connect --channel 0    # 实际打开通道验证后关闭
    python can_init.py --check --serial 12345   # 查看通道时同时显示设备序列号
"""

import argparse
import sys


def _step(msg):
    print(f"[can_init] {msg}")


def check_vector_backend():
    try:
        import can.interfaces.vector.xldriver  # noqa: F401  # also verifies vxlapi64 is loadable
        _step("Vector 后端加载成功 (python-can vector interface)")
        return True
    except Exception as exc:
        print(f"[ERROR] Vector 后端不可用: {exc}")
        print("[HINT] 请安装 Vector Driver Setup (XL Driver Library, vxlapi64.dll)，并确认 Python 为 64 位。")
        print("[HINT] 执行测试前请关闭 CANoe / VickCAN。")
        return False


def check_process_occupancy():
    """检测可能占用 Vector/LIN 通道的进程（同一通道同一时间只允许一个程序占用）
    实测：VickCAN.exe 后台运行时所有收发 0 帧；CANoe 未彻底退出时占用 Vector 总线。"""
    import subprocess
    suspects = ["VickCAN", "CANoe64", "CANoe32", "CANalyzer", "CANape", "zS_Gen3"]  # zS_Gen3 是 VickCAN 底层引擎
    running = []
    try:
        result = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True,
                                text=True, encoding="utf-8", errors="ignore")
        if result.returncode != 0:
            raise RuntimeError(f"tasklist exited {result.returncode}: {result.stderr[:160]}")
        for line in result.stdout.splitlines():
            name = line.split(",")[0].strip().strip('"') if line else ""
            for s in suspects:
                if name.lower().startswith(s.lower()) and s not in running:
                    running.append(s)
    except Exception as e:
        raise RuntimeError(f"进程占用检测失败: {e}") from e
    if running:
        print(f"[WARN] 检测到可能占用总线的进程: {', '.join(running)}")
        print("[WARN] 执行测试前请关闭这些程序（VickCAN 需彻底退出，CANoe 需 COM Quit + 强制结束）")
    else:
        print("[OK] 未检测到 VickCAN/CANoe 等占用进程")
    return running


def list_channels():
    import can
    try:
        configs = can.detect_available_configs(["vector"])
    except Exception as exc:
        print(f"[WARN] Vector 通道检测失败: {exc}")
        print("[WARN] 可改用 --connect 直接打开通道验证。")
        return []
    if configs:
        print("[INFO] 检测到 Vector 通道:")
        for c in configs:
            print(f"  channel={c.get('channel')}  serial={c.get('serial', '?')}  desc={c.get('description', '')}")
    else:
        print("[WARN] 未检测到 Vector 硬件。请确认 VN1630A / VN1640A 已连接、驱动正常，且未被 CANoe/VickCAN 占用。")
    return configs


def try_connect(channel, serial, bitrate, fd, data_bitrate):
    import can
    ch = int(channel) if str(channel).lstrip("-").isdigit() else channel
    kwargs = dict(
        interface="vector",
        channel=ch,
        bitrate=bitrate,
        fd=fd,
        app_name="UDS-Diagnostic-Test",
        receive_own_messages=False,
    )
    if serial:
        kwargs["serial"] = serial
    if fd and data_bitrate:
        kwargs["data_bitrate"] = data_bitrate
    try:
        bus = can.interface.Bus(**kwargs)
        print(f"[OK] 成功打开 Vector 通道 {channel} (serial={serial or 'auto'}) @ {bitrate}bps ({'CAN FD' if fd else 'Classic CAN'})")
        bus.shutdown()
        print("[OK] 通道已关闭，可以继续执行测试。")
        return True
    except Exception as exc:
        print(f"[ERROR] 打开 Vector 通道失败: {exc}")
        print("[HINT] 检查: 驱动安装 / 通道占用 / 硬件连接 / serial 是否填对 / Python 位数。")
        return False


def main():
    parser = argparse.ArgumentParser(description="CAN 接口检查/初始化 (Vector VN1630A)")
    parser.add_argument("--check", action="store_true", help="检查 Vector 后端与硬件通道")
    parser.add_argument("--preflight", action="store_true", help="执行前预检：后端 + 进程占用 + 通道列表（推荐执行测试前必跑）")
    parser.add_argument("--connect", action="store_true", help="实际打开通道验证")
    parser.add_argument("--channel", default="0", help="Vector 通道号 (0-3；VN1630A CH3/4 需装 CAN Piggy)")
    parser.add_argument("--serial", default="", help="Vector 设备序列号 (留空=自动; 多盒子时指定 VN1630A/VN1640A)")
    parser.add_argument("--bitrate", type=int, default=500000, help="仲裁段波特率")
    parser.add_argument("--fd", action="store_true", help="CAN FD 模式")
    parser.add_argument("--data-bitrate", type=int, default=2000000, help="CAN FD 数据段波特率")
    args = parser.parse_args()

    if not check_vector_backend():
        sys.exit(1)

    if args.preflight:
        print("\n[preflight] 步骤1/3: Vector 后端检查 ... OK")
        print("[preflight] 步骤2/3: 进程占用检查 ...")
        try:
            occupied = check_process_occupancy()
        except RuntimeError as exc:
            print(f"[ERROR] {exc}")
            sys.exit(2)
        print("[preflight] 步骤3/3: 通道列表 ...")
        channels = list_channels()
        if occupied or not channels:
            print("[ERROR] 预检未通过：通道被占用或未检测到 Vector 通道。")
            sys.exit(2)
        print("[DONE] 预检通过；仍须核对项目通道和波特率后才能执行。")
        sys.exit(0)

    if args.connect:
        ok = try_connect(args.channel, args.serial, args.bitrate, args.fd, args.data_bitrate)
        sys.exit(0 if ok else 1)

    channels = list_channels()
    if not channels:
        print("[ERROR] 未检测到可用 Vector 通道。")
        sys.exit(2)
    print("[DONE] 环境检查通过；仍须核对项目通道和波特率。")
    sys.exit(0)


if __name__ == "__main__":
    main()
