# -*- coding: utf-8 -*-
"""执行结果根因分类回归。"""

import unittest

from result_contract import normalize_result


class TestResultContract(unittest.TestCase):
    def test_script_exception_is_not_ecu_fail(self):
        result = normalize_result({
            "case_id": "A",
            "verdict": "FAIL",
            "actual": "脚本异常退出(exit 2)",
        })
        self.assertEqual(result["failure_class"], "SCRIPT_ERROR")

    def test_invalid_result_is_recorded_separately(self):
        result = normalize_result({"case_id": "A", "verdict": "ERROR"})
        self.assertEqual(result["verdict"], "FAIL")
        self.assertEqual(result["failure_class"], "RESULT_INVALID")

    def test_legacy_protocol_fail_remains_ecu_fail(self):
        result = normalize_result({
            "case_id": "A",
            "verdict": "FAIL",
            "actual": "7F 22 31",
        })
        self.assertEqual(result["failure_class"], "ECU_FAIL")

    def test_explicit_infrastructure_class_wins(self):
        result = normalize_result({
            "case_id": "A",
            "verdict": "BLOCKED",
            "failure_class": "INFRA_ERROR",
        })
        self.assertEqual(result["failure_class"], "INFRA_ERROR")


if __name__ == "__main__":
    unittest.main(verbosity=2)
