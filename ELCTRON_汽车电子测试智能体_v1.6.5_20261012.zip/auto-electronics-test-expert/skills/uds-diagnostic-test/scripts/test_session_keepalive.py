#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""项目会话保活组件离线回归；不连接 VickCAN/LIN 硬件。"""

import threading
import time
import unittest

from session_keepalive import (
    KEEP_ALIVE_SUBFUNCTION,
    SessionKeepAlive,
    is_positive_session_response,
    is_positive_tester_present_response,
    is_suppressed_tester_present_result,
    is_session_entry,
    should_keep_session_alive,
)


class TestSessionKeepAlive(unittest.TestCase):
    def test_session_entry_and_positive_response_helpers(self):
        self.assertTrue(is_session_entry([0x10, 0x02]))
        self.assertTrue(is_session_entry([0x10, 0x83]))
        self.assertFalse(is_session_entry([0x10, 0x01]))
        self.assertTrue(is_positive_session_response([0x50, 0x03, 0x00], 0x03))
        self.assertTrue(is_positive_tester_present_response([0x7E, 0x00]))
        self.assertFalse(is_positive_tester_present_response([0x7E, 0x80]))
        self.assertEqual(KEEP_ALIVE_SUBFUNCTION, 0x80)
        self.assertTrue(is_suppressed_tester_present_result(None))
        self.assertFalse(is_suppressed_tester_present_result([0x7E, 0x00]))

    def test_keepalive_rule_distinguishes_physical_and_functional_session_entry(self):
        # 01→02 允许直接进入编程会话，物理寻址下需要保活。
        self.assertTrue(should_keep_session_alive("default", [0x10, 0x02], 0x51, 0x51))
        self.assertTrue(should_keep_session_alive("extended", [0x10, 0x02], 0x51, 0x51))
        self.assertTrue(should_keep_session_alive("default", [0x10, 0x03], None, 0x51))
        self.assertFalse(should_keep_session_alive("default", [0x10, 0x03], 0x7E, 0x51))
        self.assertTrue(should_keep_session_alive("extended", [0x22, 0xF1, 0x86], 0x7E, 0x51))

    def test_keepalive_rule_uses_custom_session_ids_and_s3_policy(self):
        config = {
            "transport": {"physical_nad": "0x60"},
            "sessions": {
                "supported": ["0x01", "0x04"],
                "names": {"0x01": "Normal", "0x04": "Diagnostic"},
                "default": "0x01",
                "allowed_transitions": {"0x01": ["0x01", "0x04"], "0x04": ["0x01", "0x04"]},
                "s3_required": ["0x04"],
            },
        }
        self.assertTrue(is_session_entry([0x10, 0x84], config))
        self.assertTrue(should_keep_session_alive("Normal", [0x10, 0x04], 0x60, None, config))
        self.assertFalse(should_keep_session_alive("Normal", [0x10, 0x04], 0x70, None, config))
        self.assertTrue(should_keep_session_alive("Diagnostic", [0x22, 0xF1, 0x90], 0x70, None, config))
        self.assertFalse(should_keep_session_alive("Normal", [0x22, 0xF1, 0x90], 0x60, None, config))

    def test_non_s3_custom_session_does_not_inherit_legacy_keepalive_rule(self):
        config = {
            "sessions": {
                "supported": ["0x01", "0x04"],
                "names": {"0x01": "Normal", "0x04": "Diagnostic"},
                "default": "0x01",
                "s3_required": [],
            },
        }
        self.assertFalse(should_keep_session_alive("Diagnostic", [0x22, 0xF1, 0x90], 0x51, None, config))

    def test_periodic_keepalive_uses_injected_request_and_can_stop(self):
        calls = []
        active = 0
        max_active = 0
        state_lock = threading.Lock()

        def send_request(payload, timeout):
            nonlocal active, max_active
            with state_lock:
                active += 1
                max_active = max(max_active, active)
            time.sleep(0.01)
            calls.append((list(payload), timeout))
            with state_lock:
                active -= 1
            return None

        manager = SessionKeepAlive(send_request, interval=0.1, timeout=0.2)
        self.assertIsNone(manager.send_once())
        self.assertEqual(manager.last_error, "")
        manager.start()
        time.sleep(0.25)
        self.assertEqual(manager.stop(), "")
        self.assertGreaterEqual(len(calls), 2)
        self.assertEqual(max_active, 1)
        self.assertTrue(all(payload == [0x3E, 0x80] for payload, _ in calls))

    def test_keepalive_records_failed_response(self):
        manager = SessionKeepAlive(lambda payload, timeout: [0x7E, 0x00])
        self.assertEqual(manager.send_once(), [0x7E, 0x00])
        self.assertIn("0x3E 80", manager.last_error)


if __name__ == "__main__":
    unittest.main(verbosity=2)
