#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统一项目配置的准确性回归。"""

import unittest
from pathlib import Path
import sys

SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(SKILLS_DIR))

from project_config import (
    REFERENCE_PROJECT_PROFILE,
    canonical_hex_bytes,
    load_project_config,
    project_identity,
    short_version,
)


class TestProjectConfig(unittest.TestCase):
    def test_security_constant_key_keeps_byte_pair(self):
        self.assertEqual(canonical_hex_bytes("0x0708"), "0708")
        config = load_project_config({
            "generation": {"security_constant_dids": {"0x0708": "A001"}}
        })
        self.assertEqual(config["generation"]["security_constant_dids"]["0708"], "A001")

    def test_empty_enabled_rules_means_no_rules(self):
        config = load_project_config({"lint": {"enabled_rules": []}})
        self.assertEqual(config["lint"]["enabled_rules"], [])

    def test_invalid_transport_and_write_limit_fail_fast(self):
        with self.assertRaises(ValueError):
            load_project_config({"transport": {"physical_nad": "0x100"}})
        with self.assertRaises(ValueError):
            load_project_config({"generation": {"max_write_dids": "not-a-number"}})

    def test_session_id_cannot_use_suppress_positive_response_bit(self):
        with self.assertRaises(ValueError):
            load_project_config({"sessions": {"supported": ["0x80"]}})
        with self.assertRaises(ValueError):
            load_project_config({"sessions": {"allowed_transitions": {"0x01": ["0x81"]}}})


class TestProjectIdentity(unittest.TestCase):
    """参考项目档「独立成段、仅未移植项目时读取」的契约回归。"""

    def test_unported_project_uses_reference_profile(self):
        identity = project_identity(None)
        reference = REFERENCE_PROJECT_PROFILE["identity"]
        self.assertEqual(identity["project"], REFERENCE_PROJECT_PROFILE["project"])
        self.assertEqual(identity["display_name"], reference["display_name"])
        self.assertEqual(identity["run_id_prefix"], reference["run_id_prefix"])
        self.assertEqual(identity["source_workbook"], reference["source_workbook"])
        self.assertEqual(identity["version_prefixes"], reference["version_prefixes"])

    def test_ported_project_does_not_inherit_reference_identity(self):
        """移植新项目时，未声明的字段回退中性值，绝不残留参考项目信息。"""
        identity = project_identity({"project": "NEW_PROJECT"})
        self.assertEqual(identity["project"], "NEW_PROJECT")
        self.assertEqual(identity["display_name"], "NEW_PROJECT")  # 回退项目号
        self.assertEqual(identity["run_id_prefix"], "UDS")           # 中性前缀
        self.assertEqual(identity["source_workbook"], "")
        self.assertEqual(identity["version_prefixes"], [])
        self.assertNotIn("BBS", identity["display_name"])

    def test_ported_project_identity_overrides_reference(self):
        identity = project_identity({
            "project": "NEW_PROJECT",
            "identity": {
                "display_name": "New Project",
                "run_id_prefix": "NEW",
                "source_workbook": "new.xlsx",
                "version_prefixes": ["NEW_"],
            },
        })
        self.assertEqual(
            (identity["display_name"], identity["run_id_prefix"],
             identity["source_workbook"], identity["version_prefixes"]),
            ("New Project", "NEW", "new.xlsx", ["NEW_"]),
        )

    def test_reference_profile_is_an_isolated_section(self):
        """参考项目档只承载项目身份，不掺杂结构性配置。"""
        self.assertEqual(set(REFERENCE_PROJECT_PROFILE), {"project", "identity"})

    def test_short_version_prefers_version_token_then_strips_prefix(self):
        self.assertEqual(short_version("V436"), "V436")
        self.assertEqual(short_version("BBS_P519_V436"), "P519_V436")  # 参考档前缀
        self.assertEqual(
            short_version("BBS_P519_V436", {"project": "NEW_PROJECT"}),  # 移植项目不剥离
            "BBS_P519_V436",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
