# -*- coding: utf-8 -*-
"""SWDL 用例契约校验。

只校验公开的用例数据契约，不连接硬件、不计算密钥、不判定实机结果。
"""

from __future__ import annotations

from typing import Any, Mapping


EXPECTED_STAGE_ORDER = (
    "session-programming",
    "security-access",
    "request-download",
    "transfer-data",
    "transfer-exit",
    "check-memory",
    "reset",
    "version-confirmation",
)

REQUIRED_EVIDENCE = (
    "request_response_trace",
    "image_sha256",
    "authentication_result",
    "check_memory_result",
    "reset_result",
    "final_software_version",
)


def validate_swdl_case(case: Mapping[str, Any] | None) -> dict[str, Any]:
    """Return deterministic errors/warnings for a fillable SWDL case."""
    data = dict(case or {})
    errors: list[str] = []
    warnings: list[str] = []

    for field in ("schema_version", "case_id", "target_partition", "stages"):
        if not data.get(field):
            errors.append(f"缺少必填字段: {field}")

    stages = data.get("stages")
    if not isinstance(stages, list):
        stages = []
        errors.append("stages 必须是数组")
    stage_ids = [str(item.get("stage_id", "")) for item in stages if isinstance(item, Mapping)]
    if stage_ids != list(EXPECTED_STAGE_ORDER):
        errors.append("SWDL 阶段顺序必须为 0x10→0x27→0x34→0x36→0x37→CheckMemory→0x11→版本确认")

    stage_map = {str(item.get("stage_id")): item for item in stages if isinstance(item, Mapping)}
    security = stage_map.get("security-access", {})
    if str(security.get("status", "")).upper() == "PASS":
        errors.append("0x27 阶段不能在未提供独立认证证据时标记 PASS")
    if not security.get("blocked_by") and security.get("request") is None:
        warnings.append("0x27 请求尚未填充；拿到密钥材料后再补充")

    evidence = data.get("evidence_required")
    if not isinstance(evidence, list):
        errors.append("evidence_required 必须是数组")
        evidence = []
    missing_evidence = [item for item in REQUIRED_EVIDENCE if item not in evidence]
    if missing_evidence:
        errors.append("缺少证据要求: " + ", ".join(missing_evidence))

    execution = data.get("execution")
    if not isinstance(execution, Mapping):
        errors.append("execution 必须是对象")
    else:
        verdict = str(execution.get("verdict", "")).upper()
        if verdict == "PASS" and str(data.get("status", "")).upper() != "EXECUTED":
            errors.append("未执行用例不能标记 PASS")

    if not data.get("requirement_ids"):
        warnings.append("尚未绑定需求 ID，不能形成需求追溯闭环")

    return {
        "schema_version": "swdl-case-review/v0.1",
        "valid": not errors,
        "status": "PASS" if not errors else "BLOCKED",
        "errors": errors,
        "warnings": warnings,
    }
