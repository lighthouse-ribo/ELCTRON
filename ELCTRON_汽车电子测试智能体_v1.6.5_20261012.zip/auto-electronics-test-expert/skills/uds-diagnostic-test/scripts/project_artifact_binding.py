# -*- coding: utf-8 -*-
"""Bind generated artifacts to one project_context without copying its facts."""

from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path, PurePosixPath
from typing import Any, Mapping


SCHEMA = "project-artifact-binding/v0.1"
SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")
DRIVE_RE = re.compile(r"^[A-Za-z]:")


class ProjectArtifactBindingError(ValueError):
    """Raised when generated output is not bound to the expected context."""


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_json(path: Path) -> Mapping[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError) as exc:
        raise ProjectArtifactBindingError(f"无法读取 JSON: {path}: {exc}") from exc
    if not isinstance(value, Mapping):
        raise ProjectArtifactBindingError(f"JSON 根节点必须是对象: {path}")
    return value


def _relative_posix_path(path: Path, base_dir: Path) -> str:
    try:
        relative = os.path.relpath(path, base_dir)
    except ValueError as exc:
        raise ProjectArtifactBindingError(
            "project_context 与生成产物不在同一磁盘，无法建立可移植相对路径"
        ) from exc
    result = PurePosixPath(relative.replace("\\", "/")).as_posix()
    if not result or result in (".", "..") or "\x00" in result:
        raise ProjectArtifactBindingError("project_context 绑定路径无效")
    return result


def _resolve_relative_path(base_dir: Path, raw_path: Any) -> Path:
    value = str(raw_path or "").strip()
    if not value or "\x00" in value or "\\" in value:
        raise ProjectArtifactBindingError("绑定路径必须是非空的 POSIX 相对路径")
    if value.startswith("/") or DRIVE_RE.match(value):
        raise ProjectArtifactBindingError("绑定路径禁止使用绝对路径")
    parts = PurePosixPath(value).parts
    if not parts or any(part in ("", ".") for part in parts):
        raise ProjectArtifactBindingError("绑定路径含有非法路径段")
    return (base_dir / Path(*parts)).resolve()


def _context_identity(context: Mapping[str, Any]) -> dict[str, str]:
    project = context.get("project")
    project_id = ""
    if isinstance(project, Mapping):
        project_id = str(project.get("id") or project.get("project_id") or "").strip()
    result = {"context_schema_version": str(context.get("schema_version") or "")}
    if project_id:
        result["project_id"] = project_id
    return result


def build_project_context_binding(
    context_path: str | Path,
    artifact_dir: str | Path,
) -> dict[str, Any]:
    """Create a small, portable binding summary for a generated artifact."""

    context_file = Path(context_path).expanduser().resolve()
    if not context_file.is_file():
        raise ProjectArtifactBindingError(f"project_context 不存在: {context_file}")
    artifact_root = Path(artifact_dir).expanduser().resolve()
    context = _load_json(context_file)
    result: dict[str, Any] = {
        "$schema": SCHEMA,
        "schema_version": SCHEMA,
        "project_context": {
            "path": _relative_posix_path(context_file, artifact_root),
            "sha256": sha256_file(context_file),
        },
    }
    result.update(_context_identity(context))
    return result


def validate_project_context_binding(
    binding: Mapping[str, Any],
    artifact_dir: str | Path,
    *,
    expected_context_path: str | Path | None = None,
) -> dict[str, Any]:
    """Validate the binding path/hash and optionally bind it to a current context."""

    if not isinstance(binding, Mapping):
        raise ProjectArtifactBindingError("生成产物缺少 project_context_binding")
    if binding.get("$schema") not in (None, SCHEMA):
        raise ProjectArtifactBindingError("project_context_binding schema 无效")
    if binding.get("schema_version") != SCHEMA:
        raise ProjectArtifactBindingError("project_context_binding schema_version 无效")
    context_spec = binding.get("project_context")
    if not isinstance(context_spec, Mapping):
        raise ProjectArtifactBindingError("project_context_binding 缺少 project_context")
    context_file = _resolve_relative_path(
        Path(artifact_dir).expanduser().resolve(), context_spec.get("path")
    )
    if not context_file.is_file():
        raise ProjectArtifactBindingError(f"绑定的 project_context 不存在: {context_file}")
    expected_hash = str(context_spec.get("sha256") or "").lower()
    if not SHA256_RE.fullmatch(expected_hash):
        raise ProjectArtifactBindingError("project_context_binding.sha256 必须是 64 位 SHA-256")
    actual_hash = sha256_file(context_file).lower()
    if actual_hash != expected_hash:
        raise ProjectArtifactBindingError("生成产物绑定的 project_context SHA-256 不匹配")

    if expected_context_path is not None:
        expected_file = Path(expected_context_path).expanduser().resolve()
        if not expected_file.is_file():
            raise ProjectArtifactBindingError(f"当前 project_context 不存在: {expected_file}")
        if sha256_file(expected_file).lower() != actual_hash:
            raise ProjectArtifactBindingError("生成产物与当前 project_context 不一致")

    context = _load_json(context_file)
    identity = _context_identity(context)
    for key in ("context_schema_version", "project_id"):
        declared = str(binding.get(key) or "")
        if declared and declared != identity.get(key, ""):
            raise ProjectArtifactBindingError(f"project_context_binding.{key} 与 context 不一致")
    return {
        "$schema": SCHEMA,
        "schema_version": SCHEMA,
        "project_context": {"path": context_spec["path"], "sha256": actual_hash},
        **identity,
    }


def validate_artifact_binding(
    artifact_path: str | Path,
    *,
    expected_context_path: str | Path | None = None,
    field: str = "project_context_binding",
) -> dict[str, Any]:
    """Read an artifact JSON and validate its project context binding."""

    artifact_file = Path(artifact_path).expanduser().resolve()
    artifact = _load_json(artifact_file)
    return validate_project_context_binding(
        artifact.get(field),
        artifact_file.parent,
        expected_context_path=expected_context_path,
    )


__all__ = [
    "ProjectArtifactBindingError",
    "SCHEMA",
    "build_project_context_binding",
    "sha256_file",
    "validate_artifact_binding",
    "validate_project_context_binding",
]
