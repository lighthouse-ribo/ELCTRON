#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""不稳定项 N 次一致性判定（实测固化：F12C 类条件受限项一次 PASS 后续 FAIL [43]）
=========================================================================
对同一测试脚本的多份报告（uds_test.py 输出的 Markdown）按用例聚合，
应用 N 次一致性规则：只有 N 次全部/按比例一致才判 PASS，混合结果标记「不稳定」，
建议标 NA 或重测，不直接判 FAIL。

用法:
  python consistency_check.py --reports run1.md run2.md run3.md [--rule 3/3] [--out summary.md]
  --rule 3/3 = 必须全部 PASS；--rule 2/3 = 至少 2 次 PASS 判 PASS
退出码: 0=全部稳定, 2=存在不稳定或 FAIL
"""

import argparse
import math
import os
import re
import sys


def parse_report(path):
    """解析报告 md → {test_name: status}；SKIP 保留为未执行状态。"""
    results = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line.startswith("|"):
                continue
            cells = [c.strip() for c in line.strip("|").split("|")]
            if len(cells) < 8:
                continue
            if not cells[0].lstrip("#").strip().isdigit():
                continue
            test_name = cells[1]
            status = cells[-1].replace("*", "").strip().upper()
            if status in ("PASS", "FAIL", "BLOCKED", "NA", "SKIP"):
                results[test_name] = status
    return results


def judge(name, statuses, rule_num, rule_den):
    """一致性判定：
    PASS 计数/参与计数（仅排除 BLOCKED/NA）>= rule → PASS；否则不稳定/FAIL"""
    judged = [s for s in statuses if s in ("PASS", "FAIL")]
    if not judged:
        return "NA", f"全部运行均为条件受限（{sorted(set(statuses))}）"
    passes = sum(1 for s in judged if s == "PASS")
    need = math.ceil(rule_num / rule_den * len(judged))
    if passes == len(judged):
        return "PASS", f"{passes}/{len(judged)} 全 PASS"
    if passes >= need:
        return "PASS", f"{passes}/{len(judged)} 达 {rule_num}/{rule_den} 一致性"
    if passes == 0:
        return "FAIL", f"{passes}/{len(judged)} 全 FAIL"
    return "UNSTABLE", f"{passes}/{len(judged)} 混合结果（建议标 NA 或重测）"


def main():
    ap = argparse.ArgumentParser(description="N 次执行一致性判定")
    ap.add_argument("--reports", "-r", nargs="+", required=True, help="多份报告 md（按执行顺序）")
    ap.add_argument("--rule", default="3/3", help="一致性规则，如 3/3（全 PASS）或 2/3（至少 2 次 PASS）")
    ap.add_argument("--out", "-o", help="汇总报告输出路径（可选）")
    args = ap.parse_args()

    try:
        num, den = (int(x) for x in args.rule.split("/"))
    except ValueError:
        print(f"[ERROR] --rule 格式应为 N/M，如 3/3: {args.rule}")
        sys.exit(1)
    if num > den:
        print(f"[ERROR] --rule 分子不能大于分母: {args.rule}")
        sys.exit(1)

    per_case = {}
    for path in args.reports:
        if not os.path.exists(path):
            print(f"[ERROR] 报告不存在: {path}")
            sys.exit(1)
        for name, status in parse_report(path).items():
            per_case.setdefault(name, []).append(status)

    rows = []
    unstable = []
    fails = []
    for name, statuses in sorted(per_case.items()):
        verdict, detail = judge(name, statuses, num, den)
        rows.append((name, statuses, verdict, detail))
        if verdict == "UNSTABLE":
            unstable.append((name, statuses, detail))
        elif verdict == "FAIL":
            fails.append((name, statuses, detail))

    print(f"[INFO] {len(args.reports)} 份报告，{len(per_case)} 个用例，规则 {num}/{den}")
    for name, statuses, verdict, detail in rows:
        print(f"  [{verdict:<9}] {name}  {statuses}  {detail}")

    if args.out:
        L = ["# 执行一致性判定报告\n"]
        L.append(f"- 报告数: {len(args.reports)} ｜ 规则: {num}/{den}")
        L.append("")
        L.append("| 用例 | 各次状态 | 判定 | 说明 |")
        L.append("|---|---|---|---|")
        for name, statuses, verdict, detail in rows:
            L.append(f"| {name} | {', '.join(statuses)} | **{verdict}** | {detail} |")
        if unstable:
            L.append("\n## 不稳定项（建议标 NA 或重测）")
            for name, statuses, detail in unstable:
                L.append(f"- {name}: {statuses} → {detail}")
        if fails:
            L.append("\n## 稳定 FAIL（需修复）")
            for name, statuses, detail in fails:
                L.append(f"- {name}: {statuses} → {detail}")
        with open(args.out, "w", encoding="utf-8") as f:
            f.write("\n".join(L) + "\n")
        print(f"[INFO] 报告: {args.out}")

    if unstable or fails:
        print("[WARN] 存在不稳定/FAIL 项，不稳定项建议标 NA 或按根因重测")
        sys.exit(2)
    print("[OK] 全部稳定")
    sys.exit(0)


if __name__ == "__main__":
    main()
