#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""0x10 会话矩阵与前置建会话路径离线回归。"""

import unittest

from session_flow import (
    DEFAULT_SESSION,
    EXTENDED_SESSION,
    PROGRAMMING_SESSION,
    allowed_transition,
    parse_session_target,
    requires_s3,
    normalize_session,
    session_name,
    session_runtime_name,
    setup_route,
    transition_expected_nrc,
)


class TestSessionFlow(unittest.TestCase):
    def test_transition_matrix(self):
        expected = {
            (1, 1): True, (1, 2): True, (1, 3): True,
            (2, 1): True, (2, 2): True, (2, 3): False,
            (3, 1): True, (3, 2): True, (3, 3): True,
        }
        for pair, value in expected.items():
            with self.subTest(pair=pair):
                self.assertEqual(allowed_transition(*pair), value)
        self.assertEqual(transition_expected_nrc(1, 2), ())
        self.assertEqual(transition_expected_nrc(2, 3), (0x22,))
        self.assertEqual(transition_expected_nrc(3, 2), ())

    def test_suppressed_session_target_is_normalized(self):
        self.assertEqual(parse_session_target([0x10, 0x82]), PROGRAMMING_SESSION)
        self.assertEqual(parse_session_target([0x10, 0x83]), EXTENDED_SESSION)
        self.assertIsNone(parse_session_target([0x10, 0x7F]))
        self.assertIsNone(parse_session_target([0x22, 0xF1, 0x86]))

    def test_setup_route_finds_shortest_legal_path(self):
        self.assertEqual(setup_route(DEFAULT_SESSION, DEFAULT_SESSION), ())
        self.assertEqual(setup_route(DEFAULT_SESSION, EXTENDED_SESSION), (EXTENDED_SESSION,))
        self.assertEqual(setup_route(DEFAULT_SESSION, PROGRAMMING_SESSION), (PROGRAMMING_SESSION,))
        self.assertEqual(
            setup_route(PROGRAMMING_SESSION, EXTENDED_SESSION),
            (DEFAULT_SESSION, EXTENDED_SESSION),
        )

    def test_only_non_default_sessions_require_s3(self):
        self.assertFalse(requires_s3(DEFAULT_SESSION))
        self.assertTrue(requires_s3(PROGRAMMING_SESSION))
        self.assertTrue(requires_s3(EXTENDED_SESSION))

    def test_custom_project_sessions_drive_route_and_s3_policy(self):
        config = {
            "project": "custom-session-project",
            "sessions": {
                "supported": ["0x01", "0x04"],
                "names": {"0x01": "Normal", "0x04": "Diagnostic"},
                "default": "0x01",
                "allowed_transitions": {
                    "0x01": ["0x01", "0x04"],
                    "0x04": ["0x01", "0x04"],
                },
                "s3_required": ["0x04"],
            },
        }
        self.assertEqual(normalize_session("Diagnostic", config), 0x04)
        self.assertEqual(normalize_session("default", config), 0x01)
        self.assertEqual(session_name(0x04, config), "Diagnostic")
        self.assertEqual(session_runtime_name(0x04, config), "Diagnostic")
        self.assertEqual(parse_session_target([0x10, 0x84], config), 0x04)
        self.assertEqual(setup_route(0x01, 0x04, config), (0x04,))
        self.assertTrue(requires_s3(0x04, config))
        self.assertFalse(requires_s3(0x01, config))

    def test_custom_matrix_finds_multihop_route_and_uses_custom_nrc(self):
        config = {
            "sessions": {
                "supported": ["0x01", "0x04", "0x05"],
                "names": {"0x01": "Normal", "0x04": "Diag", "0x05": "Boot"},
                "default": "0x01",
                "allowed_transitions": {
                    "0x01": ["0x01", "0x04"],
                    "0x04": ["0x04", "0x05"],
                    "0x05": ["0x01", "0x05"],
                },
                "transition_nrc": "0x24",
                "s3_required": ["0x05"],
            },
        }
        self.assertEqual(setup_route(0x01, 0x05, config), (0x04, 0x05))
        self.assertEqual(transition_expected_nrc(0x05, 0x04, config), (0x24,))
        self.assertTrue(requires_s3(0x05, config))
        self.assertFalse(requires_s3(0x04, config))

    def test_transition_matrix_can_be_disabled_for_custom_project(self):
        config = {
            "sessions": {
                "supported": ["0x01", "0x04"],
                "names": {"0x01": "Normal", "0x04": "Diag"},
                "default": "0x01",
                "allowed_transitions": {"0x01": ["0x01"], "0x04": ["0x04"]},
                "enforce_transition_matrix": False,
            },
        }
        self.assertTrue(allowed_transition(0x04, 0x01, config))
        self.assertEqual(setup_route(0x04, 0x01, config), (0x01,))


if __name__ == "__main__":
    unittest.main(verbosity=2)
