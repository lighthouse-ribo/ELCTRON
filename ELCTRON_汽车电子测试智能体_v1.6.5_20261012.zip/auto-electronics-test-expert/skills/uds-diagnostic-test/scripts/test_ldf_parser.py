# -*- coding: utf-8 -*-
"""ldf_parser 纯逻辑单元测试（离线，无硬件依赖）。

期望值来源（独立于实现，符合 tdd 技能"不同义反复"要求）：
- LIN 2.2A 规范 2.3.1.3：P0 = ID0^ID1^ID2^ID4；P1 = ~(ID1^ID3^ID4^ID5)
- electronics.stackexchange.com/q/502292 引用规范原文并给出示例：
  0x3C（MasterReq）PID=0x3C（原样发送）、0x3D（SlaveResp）PID=0x7D
- Microchip LIN Data Link Layer 文档同公式；规范设计约束 PID 不得为全 0/全 1
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))  # noqa: E402

from ldf_parser import (  # noqa: E402
    compute_pid,
    extract_block,
    parse_schedule_tables,
    strip_comments,
)


class TestComputePid(unittest.TestCase):
    """受保护 ID 奇偶校验位（LIN 2.2A 规范固定公式）。"""

    def test_diagnostic_frames_spec_examples(self):
        # LIN 2.2A 规范/SE 示例：0x3C 原样发送、0x3D 变为 0x7D
        self.assertEqual(compute_pid(0x3C), 0x3C)
        self.assertEqual(compute_pid(0x3D), 0x7D)

    def test_known_hand_calculated(self):
        # 按规范公式手算（P1 取反）：
        # 0x00: P0=0, P1=1 -> 0x80
        # 0x01: P0=1, P1=1 -> 0xC1
        # 0x02: P0=1, P1=0 -> 0x42
        # 0x22: P0=1, P1=1 -> 0xE2
        self.assertEqual(compute_pid(0x00), 0x80)
        self.assertEqual(compute_pid(0x01), 0xC1)
        self.assertEqual(compute_pid(0x02), 0x42)
        self.assertEqual(compute_pid(0x22), 0xE2)

    def test_low6bits_preserved(self):
        # PID 低 6 位必须等于原始帧 ID
        for fid in range(0x40):
            self.assertEqual(compute_pid(fid) & 0x3F, fid)

    def test_no_allzero_allone(self):
        # 规范设计约束：PID 不允许全 0 / 全 1（可据此判传输错误）
        for fid in range(0x40):
            pid = compute_pid(fid)
            self.assertNotEqual(pid, 0x00)
            self.assertNotEqual(pid, 0xFF)

    def test_out_of_range_masked(self):
        # 帧 ID 只取低 6 位，高位必须被掩掉
        self.assertEqual(compute_pid(0x3C | 0x100), compute_pid(0x3C))


class TestTextUtils(unittest.TestCase):
    """注释剥离与块提取。"""

    def test_strip_block_and_line_comments(self):
        text = "/* 版权头 */\nNodes {\n  Master: XXX, 1; // 主机节点\n}"
        out = strip_comments(text)
        self.assertNotIn("/*", out)
        self.assertNotIn("//", out)
        self.assertIn("Master", out)

    def test_extract_block(self):
        text = "Nodes {\n  Master: XXX, 1;\n}"
        self.assertIn("Master", extract_block(text, "Nodes"))

    def test_extract_block_missing(self):
        self.assertIsNone(extract_block("no blocks here", "Nodes"))


class TestScheduleTables(unittest.TestCase):
    """调度表解析：表名 + 帧名/delay 条目。"""

    def test_parse_single_table(self):
        block = "Normal {\n  Fr1 delay 10.000 ms;\n  Fr2 delay 5.0 ms;\n}"
        tables = parse_schedule_tables(block)
        self.assertIn("Normal", tables)
        self.assertEqual(len(tables["Normal"]), 2)
        self.assertEqual(tables["Normal"][0], {"frame": "Fr1", "delay_ms": 10.0})
        self.assertEqual(tables["Normal"][1], {"frame": "Fr2", "delay_ms": 5.0})

    def test_parse_multiple_tables(self):
        block = ("Normal {\n  Fr1 delay 10.000 ms;\n}\n"
                 "Sleep {\n  GTS delay 100.0 ms;\n}")
        tables = parse_schedule_tables(block)
        self.assertEqual(set(tables.keys()), {"Normal", "Sleep"})

    def test_empty_entries_skipped(self):
        block = "Empty {\n}\n"
        self.assertEqual(parse_schedule_tables(block), {})


if __name__ == "__main__":
    unittest.main()
