#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一键运行全包 test_*.py（离线工具回归收口）。

用法:
    python run_tests.py                  # 全包：所有技能的 test_*.py（默认）
    python run_tests.py --scope current   # 仅本技能（uds-diagnostic-test）
    python run_tests.py --list            # 只列清单、不执行
    python run_tests.py --verbose         # 透传子进程 stdout/stderr
    python run_tests.py --python <解释器>  # 指定测试解释器（默认见下）

解释器解析顺序（技能测试依赖 openpyxl / can / cantools 等第三方包）:
    --python  >  $env:UDS_PYTHON  >  %USERPROFILE%\\.uds_env 的 UDS_PYTHON  >  sys.executable

    **必须用装全依赖的解释器**。若直接继承裸基础解释器（没有任何第三方包），
    测试会以「ModuleNotFoundError: openpyxl」形式**假失败**，看起来像代码坏了。
    本脚本启动时会探测并用 WARN 明确区分「环境缺包」与「真实测试失败」。

约定:
    - 默认扫描 <plugin>/skills/*/scripts/**/test_*.py —— 全包唯一收口入口，
      避免「只扫自身目录」导致的其它技能测试长期失管。
    - 名字像测试但没有测试语义的模块（无 ``def test_`` / ``TestCase``，
      如 ``testsupport.py`` 这类辅助模块）自动记为 SKIP，不计入失败。
    - 每个测试文件以子进程运行，cwd 设为该文件所在目录。
    - 任一测试文件返回非 0 即视为失败，最后以退出码 1 汇总（全通过为 0）。
    - 不连硬件；硬件相关测试均通过「允许的外部 mock」离线执行。
    - 与 tdd/SKILL.md 的收口门禁配套：改动工具后必须跑通本入口才算完成。
"""
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))   # <plugin>/skills/uds-diagnostic-test/scripts
SKILL_DIR = os.path.dirname(HERE)                   # <plugin>/skills/uds-diagnostic-test
SKILLS_DIR = os.path.dirname(SKILL_DIR)             # <plugin>/skills

_SKIP_DIRS = {"__pycache__", "data", ".venv", ".git", ".pytest_cache", "templates"}
_TEST_HINT = re.compile(r"(^\s*def test_|^\s*class Test|TestCase)", re.M)
_REQUIRED_MODULES = ("openpyxl", "can", "cantools")


def _from_env_file():
    """读取 %USERPROFILE%\\.uds_env 里写的 UDS_PYTHON。"""
    env_file = os.path.join(os.path.expanduser("~"), ".uds_env")
    if not os.path.isfile(env_file):
        return ""
    try:
        with open(env_file, encoding="utf-8", errors="replace") as handle:
            for line in handle:
                key, sep, value = line.partition("=")
                if sep and key.strip() == "UDS_PYTHON":
                    return value.strip()
    except OSError:
        return ""
    return ""


def resolve_python(argv):
    """解析测试解释器；详见模块文档的解析顺序。"""
    if "--python" in argv:
        index = argv.index("--python")
        if index + 1 < len(argv):
            return argv[index + 1]
    return os.environ.get("UDS_PYTHON", "").strip() or _from_env_file() or sys.executable


def missing_modules(python, modules=_REQUIRED_MODULES):
    """返回该解释器缺失的依赖模块名（用于区分环境问题与真实测试失败）。"""
    code = "import importlib.util as u,sys;print(','.join(m for m in %r if not u.find_spec(m)))" % (modules,)
    try:
        proc = subprocess.run([python, "-c", code], capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.SubprocessError):
        return list(modules)
    if proc.returncode != 0:
        return list(modules)
    return [name for name in (proc.stdout or "").strip().split(",") if name]


def discover_tests(scope="all"):
    """发现测试文件；``scope="current"`` 只扫本技能，``"all"`` 扫全包。"""
    roots = [SKILL_DIR] if scope == "current" else [SKILLS_DIR]
    found = []
    for root in roots:
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
            for name in sorted(filenames):
                if name.startswith("test_") and name.endswith(".py"):
                    found.append(os.path.join(dirpath, name))
    return sorted(found)


def looks_like_test(path):
    """粗判文件是否包含测试语义；读不了时按「是测试」处理，交由子进程报错。"""
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            return bool(_TEST_HINT.search(handle.read()))
    except OSError:
        return True


def _label(path):
    return os.path.relpath(path, SKILLS_DIR).replace(os.sep, "/")


def _skill_of(path):
    return os.path.relpath(path, SKILLS_DIR).split(os.sep, 1)[0]


def main():
    argv = sys.argv[1:]
    verbose = "--verbose" in argv
    list_only = "--list" in argv
    scope = "current" if "--scope" in argv and "current" in argv else "all"

    python = resolve_python(argv)
    tests = discover_tests(scope)
    if not tests:
        print("[run_tests] 未找到任何 test_*.py")
        return 1

    runnable, skipped = [], []
    for path in tests:
        (runnable if looks_like_test(path) else skipped).append(path)

    print(f"[run_tests] 解释器: {python}")
    absent = missing_modules(python)
    if absent:
        print(f"[run_tests][WARN] 该解释器缺少依赖 {', '.join(absent)}；"
              f"相关测试会 ImportError（属环境问题，非代码缺陷）。"
              f"请用 $env:UDS_PYTHON 指向装全 requirements.txt 的解释器。")
    print(f"[run_tests] scope={scope}  发现 {len(tests)} 个 test_*.py"
          f"（可执行 {len(runnable)}，非测试辅助 {len(skipped)}）")
    by_skill = {}
    for path in runnable:
        by_skill.setdefault(_skill_of(path), []).append(path)
    for skill in sorted(by_skill):
        print(f"  · {skill}: {len(by_skill[skill])}")
    for path in skipped:
        print(f"  [SKIP] {_label(path)}（无测试语义，不执行）")
    if list_only:
        for path in runnable:
            print(f"    {_label(path)}")
        return 0

    failed = []
    for path in runnable:
        proc = subprocess.run(
            [python, path],
            cwd=os.path.dirname(path),
            capture_output=not verbose,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        ok = proc.returncode == 0
        print(f"  [{'PASS' if ok else 'FAIL'}] {_label(path)}")
        if not ok:
            failed.append(path)
            if proc.stdout:
                sys.stdout.write(proc.stdout[-4000:])
            if proc.stderr:
                sys.stderr.write(proc.stderr[-4000:])

    print(f"[run_tests] 完成：{len(runnable) - len(failed)}/{len(runnable)} 通过"
          f"（跳过 {len(skipped)} 个非测试模块）")
    if failed:
        print("[run_tests] 失败文件：")
        for path in failed:
            print(f"  - {_label(path)}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
