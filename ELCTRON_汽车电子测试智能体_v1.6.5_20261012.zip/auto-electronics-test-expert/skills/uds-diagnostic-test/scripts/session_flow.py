# -*- coding: utf-8 -*-
"""项目 0x10 会话流转模型。

ISO 14229 允许 ECU 按项目配置会话跳转。本模块的决策函数全部读取
``project_config``；不传配置时才使用历史兼容默认值。模块只描述会话语义，
不访问总线，也不决定 ECU 的具体 P2 参数。
"""

from __future__ import annotations

from collections import deque
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence
_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))
from project_config import DEFAULT_PROJECT_CONFIG, load_project_config, parse_int


# Public constants are retained as a compatibility API for older callers and
# tests. Their values are derived from the compatibility configuration rather
# than being used as the source of truth by the runtime functions below.
_LEGACY_SESSIONS = DEFAULT_PROJECT_CONFIG["sessions"]
DEFAULT_SESSION = parse_int(_LEGACY_SESSIONS["default"], 0x01)
PROGRAMMING_SESSION = next(
    (parse_int(value) for value, name in _LEGACY_SESSIONS["names"].items()
     if str(name).strip() == "编程会话"),
    0x02,
)
EXTENDED_SESSION = next(
    (parse_int(value) for value, name in _LEGACY_SESSIONS["names"].items()
     if str(name).strip() == "扩展会话"),
    0x03,
)
SUPPORTED_SESSIONS = frozenset(parse_int(value) for value in _LEGACY_SESSIONS["supported"])

SESSION_NAMES = {
    DEFAULT_SESSION: "default",
    PROGRAMMING_SESSION: "programming",
    EXTENDED_SESSION: "extended",
}
SESSION_IDS = {name: value for value, name in SESSION_NAMES.items()}

# Legacy snapshots for callers that still import these names. Runtime
# decisions use ``project_config['sessions']`` exclusively.
ALLOWED_TRANSITIONS = {
    (source, target): target in {
        parse_int(item) for key, values in _LEGACY_SESSIONS["allowed_transitions"].items()
        if parse_int(key) == source for item in values
    }
    for source in SUPPORTED_SESSIONS
    for target in SUPPORTED_SESSIONS
}
TRANSITION_NRC = parse_int(_LEGACY_SESSIONS["transition_nrc"], 0x22)


def normalize_session(
    value: Any,
    project_config: Mapping[str, Any] | str | None = None,
) -> int | None:
    """按项目配置把会话名/整数/字符串转换为会话 ID。"""
    config = load_project_config(project_config)
    supported = set(config["sessions"]["supported"])
    names = config["sessions"]["names"]
    legacy_aliases = {
        0x01: {"default"},
        0x02: {"programming"},
        0x03: {"extended"},
    }
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value in supported else None
    raw = str(value or "").strip().lower()
    for session_id, name in names.items():
        aliases = {
            str(name).strip().lower(),
            f"0x{session_id:02x}",
            f"{session_id:02x}",
        }
        # Stable public tokens remain accepted when a project changes the
        # display label of one of the compatibility session IDs. These are
        # aliases only; transition/S3 policy still comes entirely from the
        # project configuration.
        aliases.update(legacy_aliases.get(int(session_id), ()))
        if raw in aliases:
            return session_id
    number = parse_int(raw)
    return number if number in supported else None


def session_name(
    value: Any,
    project_config: Mapping[str, Any] | str | None = None,
) -> str | None:
    config = load_project_config(project_config)
    normalized = normalize_session(value, config)
    return config["sessions"]["names"].get(normalized)


def session_runtime_name(
    value: Any,
    project_config: Mapping[str, Any] | str | None = None,
) -> str | None:
    """Return a stable runtime token while keeping display names configurable.

    Generated manifests and scripts historically exposed ``default``,
    ``programming`` and ``extended``. Keep those tokens for the compatibility
    session IDs, while custom session IDs use their configured display name
    (or a deterministic hexadecimal token).
    """
    config = load_project_config(project_config)
    session_id = normalize_session(value, config)
    if session_id is None:
        return None
    legacy = {0x01: "default", 0x02: "programming", 0x03: "extended"}
    return legacy.get(session_id, config["sessions"]["names"].get(
        session_id, f"0x{session_id:02X}"
    ))


def parse_session_target(
    payload: Sequence[int] | None,
    project_config: Mapping[str, Any] | str | None = None,
) -> int | None:
    """提取 0x10 的目标会话，屏蔽抑制正响应位 0x80。"""
    try:
        if payload is None or len(payload) < 2:
            return None
        if int(payload[0]) != 0x10:
            return None
        target = int(payload[1]) & 0x7F
    except (TypeError, ValueError, IndexError):
        return None
    return target if target in set(load_project_config(project_config)["sessions"]["supported"]) else None


def allowed_transition(
    source: Any,
    target: Any,
    project_config: Mapping[str, Any] | str | None = None,
) -> bool | None:
    """返回项目配置中的转换是否允许。"""
    config = load_project_config(project_config)
    source_id = normalize_session(source, config)
    target_id = normalize_session(target, config)
    if source_id is None or target_id is None:
        return None
    if not config["sessions"].get("enforce_transition_matrix", True):
        return True
    return target_id in config["sessions"]["allowed_transitions"].get(source_id, ())


def is_cross_session(
    source: Any,
    target: Any,
    project_config: Mapping[str, Any] | str | None = None,
) -> bool:
    source_id = normalize_session(source, project_config)
    target_id = normalize_session(target, project_config)
    return source_id is not None and target_id is not None and source_id != target_id


def requires_s3(
    target: Any,
    project_config: Mapping[str, Any] | str | None = None,
) -> bool:
    """按项目配置判断目标会话是否需要 S3/TesterPresent 保活。"""
    config = load_project_config(project_config)
    return normalize_session(target, config) in set(config["sessions"]["s3_required"])


def transition_expected_nrc(
    source: Any,
    target: Any,
    project_config: Mapping[str, Any] | str | None = None,
) -> tuple[int, ...]:
    """返回项目配置定义的禁止跳转 NRC；允许跳转返回空集合。"""
    config = load_project_config(project_config)
    allowed = allowed_transition(source, target, config)
    return (config["sessions"]["transition_nrc"],) if allowed is False else ()


def setup_route(
    source: Any,
    target: Any,
    project_config: Mapping[str, Any] | str | None = None,
) -> tuple[int, ...]:
    """返回从 source 建立 target 的最短合法会话请求序列。

    对本项目的前置初始化，source 通常是上电后的默认会话。默认会话可以
    直接建立编程会话，因此 ``01→02`` 返回单步路径 ``(02,)``；禁止跳转
    用例的主请求仍然保持单步发送，不会被门禁偷偷替换。
    """
    config = load_project_config(project_config)
    source_id = normalize_session(source, config)
    target_id = normalize_session(target, config)
    if source_id is None or target_id is None:
        raise ValueError("未知会话，无法生成会话建立路径")
    if source_id == target_id:
        return ()
    if not config["sessions"].get("enforce_transition_matrix", True):
        return (target_id,)

    # 配置允许通过中间会话建立目标会话时，返回最短合法路径；不再把
    # “源→目标不可直达”误判为“目标无法建立”。
    transitions = config["sessions"].get("allowed_transitions", {})
    queue = deque([(source_id, ())])
    visited = {source_id}
    while queue:
        current, route = queue.popleft()
        for next_session in transitions.get(current, ()):
            if next_session in visited:
                continue
            next_route = route + (next_session,)
            if next_session == target_id:
                return next_route
            visited.add(next_session)
            queue.append((next_session, next_route))
    raise ValueError(
        "按项目会话矩阵无法从 0x%02X 建立到 0x%02X 的路径"
        % (source_id, target_id)
    )


__all__ = [
    "ALLOWED_TRANSITIONS",
    "DEFAULT_SESSION",
    "EXTENDED_SESSION",
    "PROGRAMMING_SESSION",
    "SESSION_IDS",
    "SESSION_NAMES",
    "SUPPORTED_SESSIONS",
    "TRANSITION_NRC",
    "allowed_transition",
    "is_cross_session",
    "normalize_session",
    "parse_session_target",
    "requires_s3",
    "session_name",
    "session_runtime_name",
    "setup_route",
    "transition_expected_nrc",
]
