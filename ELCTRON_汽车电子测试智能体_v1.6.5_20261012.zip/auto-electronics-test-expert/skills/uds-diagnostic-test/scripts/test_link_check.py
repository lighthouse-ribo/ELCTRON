#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""链路探测 warm-up 重试回归测试。"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))

from link_check import probe_with_warmup


class TestWarmup(unittest.TestCase):
    def test_retries_after_cold_start_failure(self):
        calls = []

        def probe(attempt):
            calls.append(attempt)
            return attempt == 2

        sleeps = []
        ok, attempts = probe_with_warmup(probe, attempts=2, interval=1.5, sleep=sleeps.append)
        self.assertTrue(ok)
        self.assertEqual(attempts, 2)
        self.assertEqual(calls, [1, 2])
        self.assertEqual(sleeps, [1.5])

    def test_attempts_are_at_least_one(self):
        ok, attempts = probe_with_warmup(lambda _: False, attempts=0, interval=0, sleep=lambda _: None)
        self.assertFalse(ok)
        self.assertEqual(attempts, 1)


if __name__ == "__main__":
    unittest.main()
