#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成后 UDS 用例脚本审查器（差分审查）。

该工具只做离线审查，不打开 Vector/CANviex，不向 ECU 发送任何报文。

审查采用"差分"机制，与生成器（gen_case_scripts）**不是同一套推导逻辑**：
  1. 防漂移层：从需求文本（procedure/precondition/expected/test_point）用
     review_truth 的独立实现提取"证据候选集"，脚本中的最终常量（PAYLOAD/
     SESSION/PRE_ACTIONS/EXPECT）必须命中证据，防止"脚本生成成功但请求/
     期望已漂移"直接进入硬件执行和 FAIL 统计；
  2. 协议真值层：按 ISO 14229 不变量校验脚本期望（合法请求 SID、正响应
     SID = 请求 SID + 0x40、负响应帧 7F<SID><NRC> 的 SID 一致、NRC 值域）；
  3. 项目数据层：与 uds_parsed.json 交叉校验（DID/RID 存在性、0x2E 写入
     正例与只读 DID 冲突），parsed 缺失时不阻断。

注意：本模块不再 import gen_case_scripts 的任何"需求→期望"推导函数，
独立推导实现见 review_truth.py；这也意味着推导函数自身的系统性缺陷
无法通过"需求重推导与脚本比对"暴露，需靠协议/数据真值层兜底。

深度完备性（P0-1，2026-09-03）：与一致性正交的第三面检查由
review_depth.py 承担（"该写的深场景写了没有"，补"浅而一致全绿"盲区）。
默认 --depth-policy report 只输出核对表（profile+gaps），不改变判定；
--depth-policy block 时缺口升级为 REVIEW_REQUIRED。

歧义处置分级（反馈 P1-2）：--review-policy block 维持既有行为（任何
REVIEW_REQUIRED 退出码 3、阻断硬件轮次）；--review-policy report 时
REVIEW_REQUIRED 只作待人工确认清单输出、不阻断轮次（ERROR 仍为 2 始终阻断）。

退出码：
  0 结构审查通过（单条用例的 BLOCKED / SKIP 会在报告中保留）
  2 脚本/映射/协议元数据错误（任何策略下均阻断）
  3 需求或参数存在歧义，需要人工复核（默认 block；report 模式下降为 0）
    —— 或 --depth-policy block 时存在深度完备性缺口
"""
import argparse
import ast
import json
import os
import py_compile
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
SKILLS_DIR = HERE.parents[1]
if str(SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(SKILLS_DIR))

import review_depth as rdepth  # noqa: E402
from review_truth import (  # noqa: E402
    expect_type_evidence,
    parsed_issues,
    payload_candidates,
    pre_action_candidates,
    protocol_issues,
    session_candidates,
)
from project_config import load_project_config  # noqa: E402
from session_keepalive import DEFAULT_INTERVAL_SECONDS, should_keep_session_alive  # noqa: E402
from session_flow import (  # noqa: E402
    allowed_transition,
    normalize_session,
    parse_session_target,
    setup_route,
)


def _int_value(text):
    return int(str(text), 0)


def _load_json(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        return json.load(f)


def _cases_from_json(data):
    if isinstance(data, dict):
        return data.get("cases", [])
    return data if isinstance(data, list) else []


def _literal_assignments(path):
    """读取生成脚本的常量赋值，不 import 脚本，避免触发硬件访问。"""
    tree = ast.parse(Path(path).read_text(encoding="utf-8", errors="replace"), filename=str(path))
    values = {}
    for node in ast.walk(tree):
        targets = []
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, ast.AnnAssign):
            targets = [node.target]
        for target in targets:
            if not isinstance(target, ast.Name) or getattr(node, "value", None) is None:
                continue
            try:
                values[target.id] = ast.literal_eval(node.value)
            except (ValueError, TypeError, SyntaxError):
                # 非字面量赋值不是本审查器的重点；必需元数据会在后面报 ERROR。
                continue
    return values


def _same(left, right):
    """比较 JSON/Python 元数据，统一 list/tuple 差异。"""
    if isinstance(left, (list, tuple)) or isinstance(right, (list, tuple)):
        if not isinstance(left, (list, tuple)) or not isinstance(right, (list, tuple)):
            return False
        return len(left) == len(right) and all(_same(a, b) for a, b in zip(left, right))
    if isinstance(left, dict) or isinstance(right, dict):
        if not isinstance(left, dict) or not isinstance(right, dict):
            return False
        return set(left) == set(right) and all(_same(left[key], right[key]) for key in left)
    return left == right


def _manifest_case_status(meta, values):
    expected = meta.get("status")
    actual = values.get("STATUS")
    if expected != actual:
        return "ERROR", f"manifest.status={expected!r} 与脚本 STATUS={actual!r} 不一致"
    if actual == "skip":
        return "SKIP", values.get("REASON", "用户明确排除，本轮不执行")
    if actual == "blocked":
        return "BLOCKED", values.get("REASON", "前置条件受限")
    if actual == "needs_data":
        return "REVIEW_REQUIRED", "请求参数仍含占位内容，不能直接进行正式判定"
    if actual == "na" and "无法判定期望类型" in str(values.get("REASON", "")):
        return "REVIEW_REQUIRED", "需求未明确正响应、负响应或无响应期望"
    return "PASS", values.get("REASON", "")


def _service(case_id, meta=None):
    """服务 SID：优先读 manifest 写入的 service 字段；缺失时降级解析 case_id。

    不依赖 case_id 的 `UDS_<SID>_...` 命名约定，避免 ID 格式变化时
    BLOCKED 白名单（0x27/0x34/0x36/0x37）与报告服务列静默失真。
    """
    svc = str((meta or {}).get("service", "") or "")
    if svc:
        return svc
    parts = str(case_id).split("_")
    return parts[1] if len(parts) > 1 else ""


def _blocked_is_allowed(case_id, reason, meta=None):
    service = _service(case_id, meta).lower()
    if service in {"0x14", "0x27", "0x2E", "0x2F", "0x31", "0x34", "0x36", "0x37"}:
        return True
    return any(token in str(reason) for token in ("授权", "密钥", "刷写", "高风险"))


def _expectation_requires_review(case):
    """检测同一用例同时给出条件正/负路径的需求歧义。

    2026-09-03 收窄（反馈：歧义启发式过宽误伤深而疑用例）：负向词元只认
    "负响应/负向"，不再把正文中任何 "NRC" 字样（如正向句里附带说明的
    NRC 值）当作负向信号——纯正向/纯负向、只是提到 NRC 值的用例不再被
    自动挂起。真正的"若 X 正响应、否则负响应"双路径歧义仍会命中。
    """
    text = " ".join(str(case.get(key, "") or "") for key in ("test_point", "procedure", "expected"))
    has_branch = any(token in text for token in ("若", "如果", "视", "以调查表为准"))
    has_positive = any(token in text for token in ("正响应", "正常响应", "可正常响应"))
    has_negative = any(token in text for token in ("负响应", "负向"))
    return has_branch and has_positive and has_negative


def _issue(case_id, status, message, **extra):
    item = {"case_id": case_id, "status": status, "message": message}
    item.update(extra)
    return item


def review(args):
    errors = []
    reviews = []
    cases_report = []
    records = []  # 深度完备性核对输入（review_depth.py，纯统计不参与一致性判定）
    try:
        case_data = _load_json(args.cases)
        parsed = _load_json(args.parsed) if args.parsed and os.path.isfile(args.parsed) else {}
        project_config = load_project_config(getattr(args, "project_config", "") or None)
    except (OSError, ValueError, TypeError) as exc:
        return {"status": "ERROR", "summary": {"cases": 0, "errors": 1,
                "review_required": 0, "blocked": 0},
                "cases": [_issue("<input>", "ERROR", f"输入读取失败: {exc}")]}

    cases = _cases_from_json(case_data)
    cases_by_id = {str(c.get("case_id")): c for c in cases if c.get("case_id")}
    scripts_dir = Path(args.scripts_dir)
    manifest_path = scripts_dir / "manifest.json"
    if not manifest_path.is_file():
        errors.append(_issue("<manifest>", "ERROR", f"未找到 {manifest_path}"))
        return _final_report(cases_report, errors, reviews)

    try:
        manifest = _load_json(manifest_path)
    except (OSError, ValueError, TypeError) as exc:
        errors.append(_issue("<manifest>", "ERROR", f"manifest 读取失败: {exc}"))
        return _final_report(cases_report, errors, reviews)

    manifest_cases = manifest.get("cases", {}) if isinstance(manifest, dict) else {}
    if not isinstance(manifest_cases, dict):
        errors.append(_issue("<manifest>", "ERROR", "manifest.cases 不是对象"))
        return _final_report(cases_report, errors, reviews)

    if manifest.get("total") != len(cases_by_id):
        errors.append(_issue("<manifest>", "ERROR",
                             f"manifest.total={manifest.get('total')!r}，需求用例数={len(cases_by_id)}"))
    missing = sorted(set(cases_by_id) - set(manifest_cases))
    extra = sorted(set(manifest_cases) - set(cases_by_id))
    for case_id in missing:
        errors.append(_issue(case_id, "ERROR", "需求用例没有 manifest 映射"))
    for case_id in extra:
        errors.append(_issue(case_id, "ERROR", "manifest 存在需求之外的孤儿用例"))

    script_names = {p.name for p in scripts_dir.glob("case_*.py")}
    mapped_names = {str(meta.get("script")) for meta in manifest_cases.values()}
    for name in sorted(script_names - mapped_names):
        errors.append(_issue(name, "ERROR", "存在未被 manifest 引用的孤儿脚本"))
    # OP-03：对脚本名建立反向索引，破坏 70 条用例 ↔ 70 个唯一脚本的 1:1 约束必须 ERROR。
    script_to_cases = {}
    for cid, meta in manifest_cases.items():
        script_to_cases.setdefault(str(meta.get("script")), []).append(cid)
    for name, owners in script_to_cases.items():
        if len(owners) > 1:
            errors.append(_issue(name, "ERROR",
                                 "manifest 多个用例映射同一脚本，破坏 1:1 约束: " + ", ".join(sorted(owners))))

    required = (
        "CASE", "PAYLOAD", "PRE_ACTIONS", "REQUEST_NAD", "SESSION", "SESSION_SETUP_ROUTE",
        "VERIFY_SESSION", "EXPECT",
        "EXPECT_NRC", "EXPECT_PREFIX", "RESPONSE_CHECK", "STATUS", "EXECUTABLE",
        "TIMING_SPEC", "PARTITION_CONTEXT", "GATE_DECISION", "GATE_FINDINGS",
        "KEEP_ALIVE_REQUIRED", "KEEP_ALIVE_INTERVAL", "KEEP_ALIVE_SUBFUNCTION",
    )
    review_nad = getattr(args, "nad", None)
    if review_nad is None:
        review_nad = project_config["transport"]["physical_nad"]
    expected_can = {
        "CAN_CHANNEL": getattr(args, "channel", None),
        "CAN_BITRATE": getattr(args, "bitrate", None),
        "CAN_TX_ID": getattr(args, "tx_id", None),
        "CAN_RX_ID": getattr(args, "rx_id", None),
        # OP-02：未显式指定时，Classic CAN 必须 can_fd=False；空序列号表示不绑定设备。
        "CAN_SERIAL": getattr(args, "serial", None) or "",
        "CAN_FD": False if getattr(args, "can_fd", None) is None else getattr(args, "can_fd", None),
    }
    expected_can = {key: value for key, value in expected_can.items() if value is not None}
    for case_id, case in cases_by_id.items():
        meta = manifest_cases.get(case_id)
        if not meta:
            continue
        script_path = scripts_dir / str(meta.get("script", ""))
        if not script_path.is_file():
            errors.append(_issue(case_id, "ERROR", f"脚本文件不存在: {script_path}"))
            continue
        try:
            py_compile.compile(str(script_path), doraise=True)
            values = _literal_assignments(script_path)
        except (SyntaxError, OSError, py_compile.PyCompileError) as exc:
            errors.append(_issue(case_id, "ERROR", f"脚本无法编译或读取: {exc}"))
            continue

        missing_constants = [key for key in required if key not in values]
        if missing_constants:
            errors.append(_issue(case_id, "ERROR", "脚本缺少必需元数据: " + ", ".join(missing_constants)))
            continue

        # ---- 差分审查（独立真值层；不再复用 gen_case_scripts 的推导函数）----
        mismatches = []
        if values.get("CASE") != case_id:
            mismatches.append(f"CASE: 脚本={values.get('CASE')!r}，manifest={case_id!r}")
        if not _same(values.get("SESSION_SETUP_ROUTE"), meta.get("session_setup_route")):
            mismatches.append("SESSION_SETUP_ROUTE 与 manifest 不一致")
        if not _same(values.get("PARTITION_CONTEXT"), meta.get("partition_context")):
            mismatches.append("PARTITION_CONTEXT 与 manifest 不一致")
        if not _same(values.get("GATE_DECISION"), meta.get("gate_decision")):
            mismatches.append("GATE_DECISION 与 manifest 不一致")
        gate_findings = values.get("GATE_FINDINGS")
        gate_decision = values.get("GATE_DECISION")
        if not isinstance(gate_findings, list) or not isinstance(gate_decision, dict):
            mismatches.append("门禁元数据类型非法：GATE_DECISION 必须为对象，GATE_FINDINGS 必须为列表")
        elif not _same(gate_findings, gate_decision.get("findings", [])):
            mismatches.append("GATE_FINDINGS 与 GATE_DECISION.findings 不一致")
        expected_keep_alive = should_keep_session_alive(
            values.get("SESSION"), values.get("PAYLOAD"), values.get("REQUEST_NAD"),
            review_nad, project_config
        )
        if values.get("KEEP_ALIVE_REQUIRED") != expected_keep_alive:
            mismatches.append(
                "KEEP_ALIVE_REQUIRED 与项目 0x10 会话/S3 规则不一致"
            )
        if not _same(values.get("KEEP_ALIVE_REQUIRED"), meta.get("session_keep_alive")):
            mismatches.append("KEEP_ALIVE_REQUIRED 与 manifest.session_keep_alive 不一致")
        if not _same(values.get("KEEP_ALIVE_INTERVAL"), meta.get("keep_alive_interval")):
            mismatches.append("KEEP_ALIVE_INTERVAL 与 manifest.keep_alive_interval 不一致")
        if not _same(values.get("KEEP_ALIVE_INTERVAL"), DEFAULT_INTERVAL_SECONDS):
            mismatches.append("KEEP_ALIVE_INTERVAL 不符合统一保活周期")
        if values.get("KEEP_ALIVE_SUBFUNCTION") != 0x80:
            mismatches.append("KEEP_ALIVE_SUBFUNCTION 必须为 0x80（抑制正响应）")
        if not _same(values.get("KEEP_ALIVE_SUBFUNCTION"), meta.get("keep_alive_subfunction")):
            mismatches.append("KEEP_ALIVE_SUBFUNCTION 与 manifest.keep_alive_subfunction 不一致")

        source_session = normalize_session(values.get("SESSION"), project_config)
        if source_session is not None:
            try:
                expected_route = list(setup_route(
                    project_config["sessions"]["default"], source_session, project_config
                ))
            except ValueError as exc:
                mismatches.append("SESSION_SETUP_ROUTE 无法按统一会话矩阵生成：%s" % exc)
            else:
                if values.get("SESSION_SETUP_ROUTE") != expected_route:
                    mismatches.append(
                        "SESSION_SETUP_ROUTE 与源会话不一致：期望 %r，实际 %r"
                        % (expected_route, values.get("SESSION_SETUP_ROUTE"))
                    )

        transition_target = parse_session_target(values.get("PAYLOAD") or [], project_config)
        if transition_target is not None and source_session is not None:
            transition_allowed = allowed_transition(source_session, transition_target, project_config)
            expected_nrcs = set(values.get("EXPECT_NRC") or [])
            transition_nrc = project_config["sessions"]["transition_nrc"]
            if transition_allowed is False and (
                    values.get("EXPECT") != "neg" or transition_nrc not in expected_nrcs):
                mismatches.append(
                    "禁止的会话跳转 0x%02X→0x%02X 必须为负例 NRC 0x%02X"
                    % (source_session, transition_target, transition_nrc)
                )
            elif transition_allowed is True and (
                    values.get("EXPECT") == "neg" and transition_nrc in expected_nrcs):
                mismatches.append(
                    "允许的会话跳转 0x%02X→0x%02X 不应期望 NRC 0x%02X"
                    % (source_session, transition_target, transition_nrc)
                )
        # 防漂移层：脚本最终常量必须命中需求文本证据（blocked/needs_data/timing
        # 不产生可判定结果，跳过证据检查，避免对推断填充数据误杀）。
        if values.get("STATUS") not in ("blocked", "needs_data", "timing", "skip"):
            evidences = payload_candidates(case.get("procedure"), args.bus, review_nad)
            payload = values.get("PAYLOAD") or []
            if evidences and payload not in evidences:
                mismatches.append(f"PAYLOAD 与需求文本证据不符：脚本={payload!r}，候选={evidences!r}")
            sess_cands = session_candidates(
                case.get("precondition"), case.get("procedure"), project_config
            )
            if values.get("SESSION") not in sess_cands:
                mismatches.append(
                    f"SESSION={values.get('SESSION')!r} 不在需求会话证据 {sorted(sess_cands)!r} 内")
            pre_ev = pre_action_candidates(case.get("procedure"))
            pre_actions = values.get("PRE_ACTIONS") or []
            missing_pre = [a for a in pre_ev if a not in pre_actions]
            if missing_pre:
                mismatches.append("脚本 PRE_ACTIONS 缺失需求要求的前置例程: " + repr(missing_pre))
            exp_ev = expect_type_evidence(case.get("expected"), case.get("test_point"))
            if exp_ev and values.get("EXPECT") not in exp_ev:
                mismatches.append(
                    f"EXPECT={values.get('EXPECT')!r} 与需求期望证据 {sorted(exp_ev)!r} 冲突")
        if mismatches:
            errors.append(_issue(case_id, "ERROR", "；".join(mismatches), script=str(script_path)))
            continue
        if values.get("STATUS") == "timing":
            timing_spec = values.get("TIMING_SPEC")
            if not isinstance(timing_spec, dict) or timing_spec.get("case_id") != case_id or not timing_spec.get("metric"):
                errors.append(_issue(case_id, "ERROR",
                                     "时序用例缺少与 case_id 绑定的 TIMING_SPEC/metric",
                                     script=str(script_path)))
                continue
        # 真值层：协议不变量 + parsed.json 交叉（对全部状态执行）
        truth_issues = (
            protocol_issues(values.get("PAYLOAD") or [], values.get("EXPECT"),
                            values.get("EXPECT_NRC") or [], values.get("EXPECT_PREFIX") or [])
            + parsed_issues(values.get("PAYLOAD") or [], values.get("SESSION"),
                            parsed, values.get("EXPECT"))
        )
        truth_errors = [detail for lvl, detail in truth_issues if lvl == "ERROR"]
        if truth_errors:
            errors.append(_issue(case_id, "ERROR", "；".join(truth_errors), script=str(script_path)))
            continue

        for key, expected_value in expected_can.items():
            if key not in values:
                errors.append(_issue(case_id, "ERROR", f"脚本缺少统一 CAN 配置字段: {key}", script=str(script_path)))
                continue
            actual_value = values.get(key)
            if key in {"CAN_TX_ID", "CAN_RX_ID"}:
                try:
                    expected_value = int(str(expected_value), 0)
                except (TypeError, ValueError):
                    pass
            if not _same(actual_value, expected_value):
                errors.append(_issue(case_id, "ERROR",
                                     f"{key}: 脚本={actual_value!r}，统一最终配置={expected_value!r}",
                                     script=str(script_path)))
                break

        # OP-02：运行时依赖路径。CAN_RUNTIME 非空时必须存在，否则脚本一执行即崩，
        # 属脚本/环境缺陷（ERROR），不得等到硬件阶段暴露。
        can_runtime = values.get("CAN_RUNTIME")
        if can_runtime and not os.path.isfile(can_runtime):
            errors.append(_issue(case_id, "ERROR", f"CAN 运行时脚本不存在: {can_runtime}",
                                 script=str(script_path)))
            continue

        case_status, message = _manifest_case_status(meta, values)
        truth_reviews = [detail for lvl, detail in truth_issues if lvl == "REVIEW_REQUIRED"]
        if truth_reviews:
            case_status = "REVIEW_REQUIRED"
            message = "；".join(truth_reviews)
        elif _expectation_requires_review(case):
            case_status = "REVIEW_REQUIRED"
            message = "同一用例包含条件正/负路径，需确认实际 ECU 变体和允许响应"
        if case_status == "BLOCKED" and not _blocked_is_allowed(case_id, message, meta):
            errors.append(_issue(case_id, "ERROR", "非允许的 BLOCKED：" + str(message)))
            continue
        # 深度完备性核对输入：收集通过一致性/真值层的用例（skip=用户排除，
        # 不参与深度；blocked/needs_data 代表设计意图，计入）。
        if values.get("STATUS") != "skip" and values.get("PAYLOAD"):
            timing_spec = values.get("TIMING_SPEC")
            records.append({
                "case_id": case_id,
                "service": _service(case_id, meta),
                "expect": str(values.get("EXPECT") or ""),
                "status": str(values.get("STATUS") or ""),
                "payload": list(values.get("PAYLOAD") or []),
                "pre_actions": list(values.get("PRE_ACTIONS") or []),
                "expect_nrc": list(values.get("EXPECT_NRC") or []),
                "timing_metric": str((timing_spec or {}).get("metric") or "")
                if isinstance(timing_spec, dict) else "",
            })
        item = _issue(case_id, case_status, message, script=str(script_path), service=_service(case_id, meta))
        cases_report.append(item)
        if case_status == "REVIEW_REQUIRED":
            reviews.append(item)

    for generated in (scripts_dir / "run_all.py",):
        if generated.is_file():
            try:
                py_compile.compile(str(generated), doraise=True)
            except (SyntaxError, OSError, py_compile.PyCompileError) as exc:
                errors.append(_issue(generated.name, "ERROR", f"编排脚本无法编译: {exc}"))
    if args.script:
        main_script = Path(args.script)
        if not main_script.is_file():
            errors.append(_issue(main_script.name, "ERROR", "主测试脚本不存在"))
        else:
            try:
                py_compile.compile(str(main_script), doraise=True)
                main_values = _literal_assignments(main_script)
                main_names = {
                    "CAN_CHANNEL": "DEFAULT_CHANNEL",
                    "CAN_BITRATE": "DEFAULT_BITRATE",
                    "CAN_TX_ID": "DEFAULT_TX_ID",
                    "CAN_RX_ID": "DEFAULT_RX_ID",
                    "CAN_SERIAL": "DEFAULT_SERIAL",
                }
                for case_name, main_name in main_names.items():
                    if case_name not in expected_can:
                        continue
                    if main_name not in main_values:
                        errors.append(_issue(main_script.name, "ERROR",
                                             f"主测试脚本缺少统一 CAN 配置字段: {main_name}"))
                        continue
                    expected_value = expected_can[case_name]
                    actual_value = main_values[main_name]
                    if case_name in {"CAN_TX_ID", "CAN_RX_ID"}:
                        try:
                            expected_value = int(str(expected_value), 0)
                        except (TypeError, ValueError):
                            pass
                    if not _same(actual_value, expected_value):
                        errors.append(_issue(
                            main_script.name, "ERROR",
                            f"{main_name}: 主脚本={actual_value!r}，统一最终配置={expected_value!r}"))
            except (SyntaxError, OSError, py_compile.PyCompileError) as exc:
                errors.append(_issue(main_script.name, "ERROR", f"主测试脚本无法编译: {exc}"))

    report = _final_report(cases_report, errors, reviews)
    depth_result = rdepth.coverage_gaps(records)
    depth_policy = getattr(args, "depth_policy", "report")
    review_policy = getattr(args, "review_policy", "block")
    report["depth"] = depth_result
    report["policies"] = {"review": review_policy, "depth": depth_policy}
    # --depth-policy block：深度完备性缺口升级为 REVIEW_REQUIRED（opt-in）；
    # 默认 report 只输出核对表（profile + gaps），不改变一致性审查的判定。
    if depth_result["gaps"] and depth_policy == "block":
        for idx, gap in enumerate(depth_result["gaps"], start=1):
            gap_item = _issue(
                "%s|深度-%d" % (gap["service"], idx), "REVIEW_REQUIRED",
                "深度完备性：" + gap["gap"], service=gap["service"])
            reviews.append(gap_item)
            cases_report.append(gap_item)
        report = _final_report(cases_report, errors, reviews)
        report["depth"] = depth_result
        report["policies"] = {"review": review_policy, "depth": depth_policy}
    return report


def _final_report(cases_report, errors, reviews):
    status = "ERROR" if errors else ("REVIEW_REQUIRED" if reviews else "PASS")
    case_items = cases_report + errors
    counts = Counter(item["status"] for item in case_items)
    return {
        "status": status,
        "summary": {
            "cases": len(case_items),
            "errors": len(errors),
            "review_required": len(reviews),
            "blocked": counts.get("BLOCKED", 0),
            "pass": counts.get("PASS", 0),
        },
        "cases": case_items,
    }


def main():
    # 审查结果可能包含中文诊断信息；被 subprocess 管道捕获时强制 UTF-8，
    # 避免 Windows 控制台代码页把门禁原因变成替换字符，导致回归断言和人工
    # 排障都失去关键信息。
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass
    parser = argparse.ArgumentParser(description="UDS 生成脚本离线审查（不连接硬件）")
    parser.add_argument("--cases", required=True, help="设计用例 JSON")
    parser.add_argument("--parsed", default="", help="uds_parsed.json")
    parser.add_argument("--scripts-dir", required=True, help="gen-scripts 输出目录")
    parser.add_argument("--script", default="", help="代表/主测试脚本，可选")
    parser.add_argument("--bus", choices=["lin", "can"], default="lin")
    parser.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    parser.add_argument("--nad", type=_int_value, default=None)
    parser.add_argument("--survey", default="",
                        help="(兼容保留) 调查表路径；差分审查改由 parsed.json 真值层校验，不再需要例程长度表")
    parser.add_argument("--channel", default=None)
    parser.add_argument("--bitrate", type=int, default=None)
    parser.add_argument("--tx-id", default=None)
    parser.add_argument("--rx-id", default=None)
    parser.add_argument("--serial", default=None)
    parser.add_argument("--can-fd", action="store_true", default=None)
    parser.add_argument("--out", default="", help="审查 JSON 输出路径")
    parser.add_argument("--review-policy", choices=["block", "report"], default="block",
                        help="歧义/待确认(REVIEW_REQUIRED)的处置：block=退出码 3 阻断"
                             "硬件轮次（默认）；report=仅输出待人工确认清单、不阻断"
                             "（ERROR 仍为 2，任何策略都阻断）")
    parser.add_argument("--depth-policy", choices=["report", "block"], default="report",
                        help="深度完备性缺口：report=输出核对表不改变判定（默认）；"
                             "block=缺口升级为 REVIEW_REQUIRED（退出码 3）")
    args = parser.parse_args()
    report = review(args)
    serialized = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(serialized + "\n", encoding="utf-8")
    print(f"[SCRIPT_REVIEW] {report['status']} {json.dumps(report['summary'], ensure_ascii=False)}")
    for item in report["cases"]:
        if item["status"] != "PASS":
            print(f"[{item['status']}] {item['case_id']}: {item['message']}")
    depth = report.get("depth") or {}
    for gap in depth.get("gaps", []):
        print(f"[深度完备性] {gap['service']}: {gap['gap']}")
    profile = depth.get("profile") or []
    if profile:
        print(f"[深度核对表] 服务数={len(profile)}："
              + "; ".join("%s(%d条)" % (p["service"], p["cases"]) for p in profile))
    depth_blocked = bool(depth.get("gaps")) and args.depth_policy == "block"
    if report["status"] == "ERROR":
        return 2
    if report["status"] == "REVIEW_REQUIRED":
        # report 策略只降级"需求/参数歧义"类挂起；深度完备性缺口在
        # --depth-policy block 下始终以 3 阻断（其自身就是门禁）。
        if depth_blocked:
            return 3
        if args.review_policy == "report":
            print("[SCRIPT_REVIEW] review-policy=report：REVIEW_REQUIRED 仅作待人工确认清单，不阻断本轮")
            return 0
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
