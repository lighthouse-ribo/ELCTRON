# -*- coding: utf-8 -*-
"""SWDL → unified HTML report CLI regression."""

import json
import os
import subprocess
import unittest

from testsupport import WorkspaceTempDir


PYTHON = os.environ.get("UDS_PYTHON", "python")
ROOT = os.path.dirname(os.path.abspath(__file__))
REPORT = os.path.join(ROOT, "report_to_html.py")


class TestSwdlReportCli(unittest.TestCase):
    def test_swdl_report_can_feed_unified_html_report(self):
        with WorkspaceTempDir("swdl_report_cli") as td:
            report_path = os.path.join(td, "swdl_report.json")
            html_path = os.path.join(td, "swdl.html")
            with open(report_path, "w", encoding="utf-8") as handle:
                json.dump({
                    "overall": "BLOCKED",
                    "target_partition": "SBL",
                    "steps": [],
                    "blocked_reasons": ["缺少 0x27 可执行密钥材料"],
                }, handle, ensure_ascii=False)

            completed = subprocess.run(
                [PYTHON, REPORT, "--swdl-report", report_path, "--out", html_path],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            with open(html_path, encoding="utf-8") as handle:
                html = handle.read()
            self.assertIn("SWDL 软件刷写", html)
            self.assertIn("BLOCKED", html)
            self.assertIn("0x27", html)


if __name__ == "__main__":
    unittest.main(verbosity=2)
