#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DBC (CAN数据库) 解析器 —— cantools 适配层
读取 DBC 文件 → 输出 can_db.json（报文/信号/DID 定义），供用例报文级步骤生成使用

依赖: pip install cantools

用法:
  python dbc_parser.py --input vehicle.dbc --output can_db.json
  python dbc_parser.py --input vehicle.dbc --output can_db.json --msg 0x1F0 --sig AverageRadius
"""

__version__ = "1.0.0"

import argparse
import json
import os
import sys


def parse_dbc(filepath, msg_filter=None, sig_filter=None):
    """解析 DBC 文件，输出标准化 can_db.json

    Args:
        filepath: DBC 文件路径
        msg_filter: 可选，仅输出指定 frame_id（如 0x1F0）
        sig_filter: 可选，仅输出指定信号名

    Returns:
        dict: {"source_file", "version", "nodes", "buses", "messages": [...]}
    """
    try:
        import cantools
    except ImportError:
        print("[ERROR] 解析DBC需要 cantools 库，请先安装: pip install cantools")
        sys.exit(1)

    db = cantools.database.load_file(filepath)

    result = {
        "source_file": os.path.basename(filepath),
        "version": db.version or "",
        "nodes": [n.name for n in db.nodes] if hasattr(db, "nodes") else [],
        "buses": list(db.buses) if hasattr(db, "buses") else [],
        "messages": [],
    }

    for msg in db.messages:
        # 报文过滤
        if msg_filter is not None and msg.frame_id != msg_filter:
            continue

        msg_entry = {
            "frame_id": "0x{:X}".format(msg.frame_id),
            "name": msg.name,
            "is_extended_frame": msg.is_extended_frame,
            "is_fd": getattr(msg, "is_fd", False),
            "length": msg.length,
            "cycle_time": getattr(msg, "cycle_time", 0) or 0,
            "senders": list(msg.senders) if msg.senders else [],
            "signals": [],
        }

        for sig in msg.signals:
            # 信号过滤
            if sig_filter is not None and sig.name != sig_filter:
                continue

            sig_entry = {
                "name": sig.name,
                "start": sig.start,
                "length": sig.length,
                "byte_order": sig.byte_order,
                "is_signed": sig.is_signed,
                "scale": sig.scale,
                "offset": sig.offset,
                "unit": sig.unit or "",
                "minimum": sig.minimum,
                "maximum": sig.maximum,
                "choices": sig.choices,
                "comment": getattr(sig, "comment", None) or "",
            }
            msg_entry["signals"].append(sig_entry)

        result["messages"].append(msg_entry)

    return result


def main():
    parser = argparse.ArgumentParser(description="DBC (CAN数据库) 解析器 - cantools 适配层")
    parser.add_argument("--input", "-i", required=True, help="DBC文件路径")
    parser.add_argument("--output", "-o", required=True, help="输出 can_db.json 路径")
    parser.add_argument("--msg", type=lambda s: int(s, 16), default=None,
                        help="仅输出指定报文ID（十六进制，如 0x1F0）")
    parser.add_argument("--sig", default=None, help="仅输出指定信号名")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"[ERROR] 文件不存在: {args.input}")
        sys.exit(1)

    print(f"[INFO] 解析 DBC: {args.input}")
    result = parse_dbc(args.input, msg_filter=args.msg, sig_filter=args.sig)

    total_sigs = sum(len(m["signals"]) for m in result["messages"])
    print(f"[INFO] 解析完成:")
    print(f"  - 节点数量: {len(result['nodes'])}")
    print(f"  - 报文数量: {len(result['messages'])}")
    print(f"  - 信号总数: {total_sigs}")

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)

    print(f"\n[INFO] 输出文件: {args.output}")
    print(f"[HINT] 下游可用 cantools 编解码：encode_message/decode_message（见 SKILL.md）")


if __name__ == "__main__":
    main()
