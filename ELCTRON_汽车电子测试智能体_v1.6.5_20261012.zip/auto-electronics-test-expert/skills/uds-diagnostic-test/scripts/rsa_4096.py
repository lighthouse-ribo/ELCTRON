#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RSA-4096 刷写签名/验证工具（开发测试用）
=========================================================================
依据 NOTE-SWRS-34088390-01-15 4.2.3.8/4.2.3.9：
  - 签名方案：PKCS#1 v2.2 RSASSA-PSS，哈希 SHA-256，盐长=哈希长度（32B）
  - 开发私钥：SWRS 4.2.3.9 REQ-137011 提供的 RSA-4096 开发私钥（PKCS#8 PEM，未加密）
  - 生产签名由 OEM Trust Centre 执行；本工具仅用于开发/测试环境

用法:
  # 校验开发私钥与 VolvoKey.json 公钥一致
  python rsa_4096.py check-key --private-key <dev.pem> --key-json VolvoKey.json
  # 签名（刷写文件/任意数据 → 签名文件）
  python rsa_4096.py sign --private-key <dev.pem> --input <file> --out <sig.bin>
  # 验证（用 VolvoKey.json 的公钥字段）
  python rsa_4096.py verify --public-key-modulus <hex> --public-key-exponent 65537 \
        --input <file> --signature <sig.bin>
  # 只读解析密钥文件
  python rsa_4096.py parse-json --key-json VolvoKey.json
"""

import argparse
import json
import os
import sys


def _crypto():
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, rsa
        return hashes, serialization, padding, rsa
    except ImportError:
        print("[ERROR] 需要 cryptography 库：pip install cryptography（见 requirements.txt）")
        sys.exit(1)


def load_private_key(path):
    hashes, serialization, padding, rsa = _crypto()
    if not os.path.isfile(path):
        print(f"[ERROR] 私钥文件不存在: {path}")
        sys.exit(1)
    with open(path, "rb") as f:
        data = f.read()
    try:
        return serialization.load_pem_private_key(data, password=None)
    except Exception as e:
        try:
            return serialization.load_der_private_key(data, password=None)
        except Exception:
            print(f"[ERROR] 私钥解析失败（支持 PKCS#8/PKCS#1 PEM 或 DER）: {e}")
            sys.exit(1)


def pss_padding(padding):
    from cryptography.hazmat.primitives import hashes
    return padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=hashes.SHA256().digest_size)


def sign(private_key, input_path, out_path):
    hashes, serialization, padding, rsa = _crypto()
    if private_key.key_size != 4096:
        print(f"[WARN] 私钥长度 {private_key.key_size} bit，SWRS 要求 4096")
    with open(input_path, "rb") as f:
        data = f.read()
    sig = private_key.sign(data, pss_padding(padding), hashes.SHA256())
    with open(out_path, "wb") as f:
        f.write(sig)
    print(f"[OK] 签名完成: {out_path}（{len(sig)} 字节，RSASSA-PSS/SHA-256，盐长 32）")
    return True


def verify(modulus_hex, exponent, input_path, sig_path):
    hashes, serialization, padding, rsa = _crypto()
    n = int(str(modulus_hex).strip(), 16)
    pub = rsa.RSAPublicNumbers(int(exponent), n).public_key()
    with open(input_path, "rb") as f:
        data = f.read()
    with open(sig_path, "rb") as f:
        sig = f.read()
    try:
        pub.verify(sig, data, pss_padding(padding), hashes.SHA256())
        print("[OK] 验证通过：签名有效（公钥匹配 SWRS 4096-bit 开发密钥）")
        return True
    except Exception as e:
        print(f"[FAIL] 验证失败: {e}")
        return False


def check_key(private_key, key_json):
    hashes, serialization, padding, rsa = _crypto()
    pub = private_key.public_key().public_numbers()
    derived_n = format(pub.n, "X").upper()
    print(f"[INFO] 私钥长度: {private_key.key_size} bit ｜ 公钥指数: {pub.e}")
    if key_json and os.path.isfile(key_json):
        with open(key_json, encoding="utf-8") as f:
            jd = json.load(f)
        jn = str(jd.get("RSA_public_key_modulus", "")).upper()
        je = str(jd.get("RSA_public_key_exponent", "")).strip()
        ok_n = derived_n == jn
        ok_e = str(pub.e) == je
        print(f"[{'OK' if ok_n else 'FAIL'}] 模数匹配 VolvoKey.json: {ok_n}")
        print(f"[{'OK' if ok_e else 'FAIL'}] 指数匹配 VolvoKey.json: {ok_e}（{pub.e} vs {je}）")
        return ok_n and ok_e
    print(f"[INFO] 派生公钥模数（前 32 位）: {derived_n[:32]}…")
    return True


def parse_json(key_json):
    with open(key_json, encoding="utf-8") as f:
        jd = json.load(f)
    n = str(jd.get("RSA_public_key_modulus", ""))
    e = str(jd.get("RSA_public_key_exponent", ""))
    bits = (len(n) * 4) if n else 0
    print(f"[INFO] {os.path.basename(key_json)}")
    print(f"  RSA 公钥: {bits} bit ｜ exponent={e}")
    print(f"  模数前 16 位: {n[:16].upper()}…（{len(n)} hex）")
    for k in ("AES_cmac_key_0102", "AES_ctr_key_0102", "AES_cmac_key_0506", "AES_ctr_key_0506"):
        v = str(jd.get(k, ""))
        mask = "占位 0xFF" if v and set(v.upper()) == {"F"} else ("已配置" if v else "缺失")
        print(f"  {k:<24}: {mask}")


def main():
    ap = argparse.ArgumentParser(description="RSA-4096 刷写签名/验证（开发测试用，SWRS 4.2.3.8/4.2.3.9）")
    sub = ap.add_subparsers(dest="mode", required=True)

    p_sign = sub.add_parser("sign", help="RSASSA-PSS/SHA-256 签名")
    p_sign.add_argument("--private-key", required=True)
    p_sign.add_argument("--input", required=True, help="待签名文件（如刷写数据）")
    p_sign.add_argument("--out", required=True, help="签名输出文件")

    p_ver = sub.add_parser("verify", help="用公钥验证签名")
    p_ver.add_argument("--public-key-modulus", required=True, help="十六进制模数（VolvoKey.json RSA_public_key_modulus）")
    p_ver.add_argument("--public-key-exponent", default="65537")
    p_ver.add_argument("--input", required=True)
    p_ver.add_argument("--signature", required=True)

    p_chk = sub.add_parser("check-key", help="校验私钥与 VolvoKey.json 公钥一致")
    p_chk.add_argument("--private-key", required=True)
    p_chk.add_argument("--key-json", default="", help="VolvoKey.json 路径")

    p_parse = sub.add_parser("parse-json", help="只读解析 VolvoKey.json")
    p_parse.add_argument("--key-json", required=True)

    args = ap.parse_args()
    if args.mode == "sign":
        ok = sign(load_private_key(args.private_key), args.input, args.out)
    elif args.mode == "verify":
        ok = verify(args.public_key_modulus, args.public_key_exponent, args.input, args.signature)
    elif args.mode == "check-key":
        ok = check_key(load_private_key(args.private_key), args.key_json)
    else:
        parse_json(args.key_json)
        ok = True
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
