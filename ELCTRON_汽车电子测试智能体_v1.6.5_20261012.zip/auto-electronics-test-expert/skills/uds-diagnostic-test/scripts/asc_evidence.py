#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""asc_evidence.py — 用例总线轨迹证据落盘（JSON trace + LIN-ASC 转写）

真实性保证（转写，非编造）——ASC 标准证据固定口径（v3.9 用户批准）:
  - 帧数据与时间戳来自驱动逐帧捕获（F1L1 xNetpack 硬件时间戳，微秒→秒），
    由 f1l1_uds._record_trace 在收发时强制记录（无有效硬件时间戳会拒绝记录）。
  - 本模块只做格式转写：把捕获到的真实帧写成 LIN-ASC 方言（与 VickCAN 录制
    格式一致，CANoe/CANalyzer/VickCAN 可打开）；帧校验和按 LIN 规范由帧内容
    实算（lin_tp.compute_checksum，诊断帧 0x3C/0x3D 经典校验，其余增强校验）。
  - 溯源：ASC 头部注释声明来源 trace JSON 与用例；trace JSON 保存原始帧与
    时间戳来源声明。禁止编造：任何 ASC 行都必须能回溯到 trace JSON 原始帧。

用法:
  A) 库调用（推荐，宿主脚本在 env.close() 时调用）:
     from asc_evidence import save_case_evidence
     save_case_evidence(case_id, frames, wall0=time.time(), out_dir="results")
     frames = [(ts_sec, 'TX'/'RX', frame_id, [data]), ...]
  B) 命令行重转写（从已有 trace JSON 重新生成 ASC）:
     python asc_evidence.py --trace results/trace_<case>.json [--out-dir results]
"""
import argparse
import csv
import json
import re
import sys
import uuid
from datetime import datetime
from pathlib import Path

try:
    from lin_tp import compute_checksum as _lin_checksum
except Exception:
    _lin_checksum = None


def _standalone_checksum(frame_id, data, enhanced):
    """内置 LIN 校验和实算（与 lin_tp.compute_checksum 同算法）。

    可移植性设计：本模块不强依赖 lin_tp——skill 目录内用 lin_tp（单一实现源），
    单文件拷贝到任意项目时自动退回内置实现，校验和依然实算而非置 n/a。
    带进位加法（≥256 减 255）逐位取反；经典=仅数据，增强=受保护 ID+数据。
    """
    fid = frame_id & 0x3F
    if enhanced:
        p0 = ((fid >> 0) ^ (fid >> 1) ^ (fid >> 2) ^ (fid >> 4)) & 1
        xor1 = ((fid >> 1) ^ (fid >> 3) ^ (fid >> 4) ^ (fid >> 5)) & 1
        total = (((1 - xor1) & 1) << 7) | (p0 << 6) | fid
    else:
        total = 0
    for b in data:
        total += b
        if total >= 256:
            total -= 255
    return (~total) & 0xFF


def _checksum(frame_id, data, enhanced):
    if _lin_checksum is not None:
        try:
            return int(_lin_checksum(int(frame_id), list(data), enhanced=bool(enhanced)))
        except Exception:
            pass
    try:
        return _standalone_checksum(int(frame_id), [int(b) & 0xFF for b in data], enhanced)
    except Exception:
        return None


def _asc_date():
    now = datetime.now()
    return "%s.%03d %s %s" % (
        now.strftime("%a %b %d %I:%M:%S"),
        now.microsecond // 1000,
        now.strftime("%p").lower(),
        now.strftime("%Y"),
    )


def _safe_session_label(value):
    """Keep a capture directory inside the configured evidence root."""
    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "live"))
    return cleaned.strip("._") or "live"


def _asc_header(*, source, channel, brval, wall_clock_anchor=None, part=None):
    lines = [
        "date %s" % _asc_date(),
        "base hex  timestamps absolute",
        "no internal events logged",
        "// version 13.0.0",
        "// Measurement UUID: %s" % uuid.uuid4(),
        "// provenance: %s" % source,
        "// timestamps: driver hardware timestamps (us->s), relative to first frame",
        "// wall clock anchor: %s" % (wall_clock_anchor or "n/a"),
        "// channel: %s  BR = %d" % (channel, brval),
    ]
    if part is not None:
        lines.append("// SWDL live capture part %02d" % part)
    return lines


def _asc_frame_line(ts, t0, direction, fid, data, brval):
    """Format one verified LIN frame using the same dialect as saved evidence."""
    data = [int(item) & 0xFF for item in data[:8]]
    enhanced = fid not in (0x3C, 0x3D)
    checksum = _checksum(fid, data, enhanced)
    checksum_mode = "enhanced" if enhanced else "classic"
    dircap = "Tx" if str(direction).upper() == "TX" else "Rx"
    hexs = " ".join("%02x" % item for item in data).ljust(23)
    line = "%9.6f Li %-19s %-6s %d %s  " % (
        float(ts) - float(t0), ("%02x" % int(fid)).ljust(19), dircap, len(data), hexs)
    if checksum is not None:
        return line + "checksum = %02x   BR = %d  CSM = %s" % (checksum, brval, checksum_mode)
    return line + "checksum = n/a   BR = %d  CSM = %s" % (brval, checksum_mode)


class LiveAscRecorder:
    """Append real captured LIN frames to split ASC files during execution.

    The recorder never manufactures timestamps or frames.  It accepts the exact
    events supplied by the driver hook and flushes every accepted frame so a
    running SWDL job remains inspectable.  Splitting happens before a new line
    would exceed ``part_max_bytes``; an individual line may exceed a very tiny
    test threshold, but never a practical 100 MiB threshold.
    """

    def __init__(self, case_id, *, out_dir="results", brval=19200,
                 channel="CANview-F1L1", wall0=None, session_id=None,
                 part_max_bytes=100 * 1024 * 1024):
        if int(part_max_bytes) < 256:
            raise ValueError("part_max_bytes 必须不少于 256 字节")
        session = _safe_session_label(session_id or datetime.now().strftime("loop_%Y%m%d_%H%M%S"))
        self.case_id = str(case_id or "UNKNOWN")
        self.brval = int(brval)
        self.channel = str(channel)
        self.wall0 = wall0
        self.part_max_bytes = int(part_max_bytes)
        self.directory = Path(out_dir) / "traces" / "SWDL" / session
        self._t0 = None
        self._part_index = 0
        self._part_frames = 0
        self._part_path = None
        self._part_handle = None
        self.frames = 0
        self.parts = []
        self.closed = False
        self.runlog_path = self.directory / "runlog_part01.txt"
        self.rounds_path = self.directory / "loop_rounds.csv"

    def _ensure_started(self):
        if self._part_handle is not None:
            return
        self.directory.mkdir(parents=True, exist_ok=True)
        self._open_part()
        self._log("ASC", "实时留证已开启：%s（单文件满 %d MB 自动换片）" % (
            self.directory, self.part_max_bytes // (1024 * 1024)))

    def _log(self, category, message):
        stamp = datetime.now().strftime("%H:%M:%S")
        with self.runlog_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write("[%s] %-6s %s\n" % (stamp, category, message))

    def _open_part(self):
        if self._part_handle is not None:
            self._part_handle.flush()
            self._part_handle.close()
        self._part_index += 1
        self._part_frames = 0
        self._part_path = self.directory / ("part%02d.asc" % self._part_index)
        self._part_handle = self._part_path.open("w", encoding="utf-8", newline="\n")
        anchor = None
        if self.wall0:
            anchor = datetime.fromtimestamp(self.wall0).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        for line in _asc_header(source="driver live capture (auto-electronics-test-expert)",
                                channel=self.channel, brval=self.brval,
                                wall_clock_anchor=anchor, part=self._part_index):
            self._part_handle.write(line + "\n")
        self._part_handle.flush()
        self.parts.append(str(self._part_path))

    def record(self, event):
        """Persist exactly one driver event: ``(ts, direction, id, data, ...)``."""
        if self.closed:
            raise RuntimeError("实时 ASC 记录器已关闭")
        if not event or len(event) < 4 or event[0] is None:
            raise ValueError("实时 ASC 记录缺少硬件时间戳或帧字段")
        self._ensure_started()
        ts, direction, frame_id, data = event[:4]
        if self._t0 is None:
            self._t0 = float(ts)
        line = _asc_frame_line(ts, self._t0, direction, int(frame_id), list(data), self.brval) + "\n"
        encoded_size = len(line.encode("utf-8"))
        current_size = self._part_handle.tell()
        if self._part_frames and current_size + encoded_size > self.part_max_bytes:
            previous = self._part_path.name
            self._open_part()
            self._log("ASC", "%s 达到阈值，切换至 %s" % (previous, self._part_path.name))
        self._part_handle.write(line)
        self._part_handle.flush()  # Explicitly visible to CANoe/CANalyzer while running.
        self._part_frames += 1
        self.frames += 1

    def close(self, *, result_file=None):
        if self.closed:
            return self.status()
        if not self.frames:
            self.closed = True
            return None
        if self._part_handle is not None:
            self._part_handle.flush()
            self._part_handle.close()
            self._part_handle = None
        new_file = not self.rounds_path.exists()
        with self.rounds_path.open("a", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            if new_file:
                writer.writerow(("case_id", "finished_at", "frames", "parts", "result_file"))
            writer.writerow((self.case_id, datetime.now().isoformat(timespec="seconds"),
                             self.frames, len(self.parts), result_file or ""))
        self._log("ASC", "实时留证结束：%d 帧，%d 个分片" % (self.frames, len(self.parts)))
        self.closed = True
        return self.status()

    def status(self):
        return {
            "directory": str(self.directory),
            "parts": list(self.parts),
            "frames": self.frames,
            "runlog": str(self.runlog_path),
            "rounds": str(self.rounds_path),
            "closed": self.closed,
        }


def save_case_evidence(case_id, frames, wall0=None, out_dir="results", brval=19200,
                       channel="CANview-F1L1", result_file=None):
    """把一次用例执行的帧轨迹落盘为证据（trace JSON 源件 + ASC 转写件）。

    frames: [(ts_sec, direction('TX'/'RX'), frame_id, [data]), ...]
            时间戳为驱动硬件时间戳（微秒→秒），由 _record_trace 保证真实性。
    wall0:  捕获起始墙钟时间（time.time()），写入溯源锚点。
    out_dir:证据输出根目录（trace 写 out_dir，ASC 写 out_dir/asc）。
    返回:   {"trace": 路径, "asc": 路径, "frames": n}；frames 为空时返回 None（不落盘）。
    """
    frames = [f for f in (frames or []) if f and f[0] is not None]
    if not frames:
        return None
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    asc_dir = out / "asc"
    asc_dir.mkdir(exist_ok=True)

    # ---- 1) 原始帧轨迹 JSON（溯源主件，证据源）----
    trace_path = out / ("trace_%s.json" % case_id)
    anchor = None
    if wall0:
        anchor = datetime.fromtimestamp(wall0).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    trace = {
        "case_id": case_id,
        "captured_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "wall_clock_anchor": anchor,
        "timestamp_source": "driver hardware timestamp (us -> seconds)",
        "brval": brval,
        "frame_count": len(frames),
        "frames": [
            {"ts": float(f[0]), "dir": str(f[1]), "id": int(f[2]), "data": [int(b) for b in f[3]]}
            for f in frames
        ],
    }
    trace_path.write_text(json.dumps(trace, ensure_ascii=False, indent=1), encoding="utf-8")

    # ---- 2) LIN-ASC 转写（格式基准：VickCAN 自产样例，逐字段对齐实测验证）----
    t0 = float(frames[0][0])
    lines = []
    lines.append("date %s" % _asc_date())
    lines.append("base hex  timestamps absolute")
    lines.append("no internal events logged")
    lines.append("// version 13.0.0")
    lines.append("// Measurement UUID: %s" % uuid.uuid4())
    lines.append("// provenance: transcribed by python (auto-electronics-test-expert)")
    lines.append("// source trace: %s" % trace_path.name)
    if result_file:
        lines.append("// case result: %s" % result_file)
    lines.append("// timestamps: driver hardware timestamps (us->s), relative to first frame")
    lines.append("// wall clock anchor: %s" % (anchor or "n/a"))
    lines.append("// channel: %s  BR = %d" % (channel, brval))

    n_written = 0
    for f in frames:
        ts, direction, fid, data = float(f[0]), str(f[1]), int(f[2]), [int(b) for b in f[3]]
        data = data[:8]
        enhanced = fid not in (0x3C, 0x3D)   # 诊断帧经典校验，其余增强校验
        cs = _checksum(fid, data, enhanced)
        csm = "enhanced" if enhanced else "classic"
        dircap = "Tx" if direction.upper() == "TX" else "Rx"
        hexs = " ".join("%02x" % b for b in data).ljust(23)
        # 行格式注意：帧 ID 字段只写一次 "Li <id>"（历史上曾出现 "Li Li xx" 双前缀 bug，
        # 与 VickCAN 实物样例逐字段比对定位后修正——新版本改动必须用实物样例帧回归）。
        line = "%9.6f Li %-19s %-6s %d %s  " % (
            ts - t0, ("%02x" % fid).ljust(19), dircap, len(data), hexs)
        if cs is not None:
            line += "checksum = %02x   BR = %d  CSM = %s" % (cs, brval, csm)
        else:
            line += "checksum = n/a   BR = %d  CSM = %s" % (brval, csm)
        lines.append(line)
        n_written += 1

    asc_path = asc_dir / ("%s.asc" % case_id)
    asc_path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return {"trace": str(trace_path), "asc": str(asc_path), "frames": n_written}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="trace JSON -> LIN-ASC 重转写")
    ap.add_argument("--trace", required=True, help="已有 trace JSON 路径")
    ap.add_argument("--case", default=None, help="用例号（默认取 trace 内 case_id）")
    ap.add_argument("--out-dir", default="results", help="输出根目录（默认 results）")
    ap.add_argument("--brval", type=int, default=19200, help="LIN 波特率（默认 19200）")
    args = ap.parse_args()
    d = json.loads(Path(args.trace).read_text(encoding="utf-8"))
    cid = args.case or d.get("case_id", "REPLAY")
    frames = [(f["ts"], f["dir"], f["id"], f["data"]) for f in d.get("frames", [])]
    r = save_case_evidence(cid, frames, wall0=None, out_dir=args.out_dir, brval=args.brval)
    print(json.dumps(r, ensure_ascii=False))
