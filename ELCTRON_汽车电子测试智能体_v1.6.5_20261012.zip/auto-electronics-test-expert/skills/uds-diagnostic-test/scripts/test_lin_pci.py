#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LIN PCI 解析回归测试。"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))

from lin_pci import parse_lin_transport_frame, pci_rules, strip_lin_payload


class TestLinPci(unittest.TestCase):
    def test_single_frame_removes_nad_pci_and_padding(self):
        parsed = parse_lin_transport_frame([0x51, 0x04, 0x31, 0x01, 0x02, 0x06, 0xFF, 0xFF])
        self.assertTrue(parsed["wrapped"])
        self.assertEqual(parsed["frame_type"], "single")
        self.assertEqual(parsed["declared_length"], 4)
        self.assertEqual(parsed["payload"], [0x31, 0x01, 0x02, 0x06])
        self.assertEqual(parsed["padding"], [0xFF, 0xFF])
        self.assertEqual(strip_lin_payload([0x51, 0x04, 0x31, 0x01, 0x02, 0x06, 0xFF, 0xFF]),
                         [0x31, 0x01, 0x02, 0x06])

    def test_short_single_frame_is_incomplete(self):
        parsed = parse_lin_transport_frame([0x51, 0x06, 0x31, 0x01, 0x02, 0x06])
        self.assertFalse(parsed["complete"])
        self.assertEqual(parsed["available_length"], 4)
        self.assertIsNone(strip_lin_payload([0x51, 0x06, 0x31, 0x01, 0x02, 0x06], strict=True))

    def test_direct_uds_payload_is_not_misread_as_pci(self):
        parsed = parse_lin_transport_frame([0x11, 0x01])
        self.assertFalse(parsed["wrapped"])
        self.assertEqual(parsed["payload"], [0x11, 0x01])

    def test_rules_are_machine_readable(self):
        rules = pci_rules()
        self.assertEqual(rules["single_frame"]["length_source"], "pci_low_nibble")
        self.assertEqual(rules["single_frame"]["payload_start"], 2)


if __name__ == "__main__":
    unittest.main()
