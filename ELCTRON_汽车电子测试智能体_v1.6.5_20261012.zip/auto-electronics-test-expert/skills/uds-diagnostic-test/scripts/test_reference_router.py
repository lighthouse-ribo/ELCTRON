"""Reference routing contract tests.

These tests are intentionally offline: they validate task-to-reference selection
and the existence of every asset returned by the routing table.
"""

from pathlib import Path
import sys


SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from reference_router import ReferenceRouter  # noqa: E402


ROOT = SCRIPT_DIR.parents[2]
ROUTES = ROOT / "references" / "reference-routing.json"


def test_uds_on_lin_mounts_lin_primary_and_uds_companion():
    result = ReferenceRouter(ROUTES).resolve("UDS-over-LIN 使用 F1L1 诊断 NAD 0x3C/0x3D")

    assert result["route_id"] == "lin-uds-and-diagnostics"
    assert result["primary_branch"] == "ISO-17987"
    assert "ISO-14229" in result["secondary_branches"]
    assert any(asset.startswith("skills/srs-uds-testcase-designer/references/ISO14229-") for asset in result["mounted_assets"])
    assert any(asset.startswith("references/ISO-17987/ISO17987-7_") for asset in result["mounted_assets"])


def test_can_physical_task_does_not_mount_uds_assets_by_default():
    result = ReferenceRouter(ROUTES).resolve("CAN 总线 Error Frame、Bus Off 和终端电阻排查")

    assert result["route_id"] == "can-link-and-physical"
    assert result["primary_branch"] == "ISO-11898"
    assert result["secondary_branches"] == []
    assert all("14229" not in asset for asset in result["mounted_assets"])


def test_uds_application_on_can_adds_can_transport_branch():
    result = ReferenceRouter(ROUTES).resolve("设计 0x27 安全访问和 NRC 用例", bus="CAN")

    assert result["route_id"] == "uds-application"
    assert result["primary_branch"] == "ISO-14229"
    assert result["secondary_branches"] == ["ISO-11898"]
    assert any(asset.startswith("references/ISO-11898/ISO11898-") for asset in result["mounted_assets"])


def test_all_returned_assets_exist():
    router = ReferenceRouter(ROUTES)
    for route in router.routes:
        result = router.resolve(route["when"][0], bus="LIN" if route["id"].startswith("lin-") else None)
        for asset in result["mounted_assets"] + result["optional_assets"]:
            assert (ROOT / asset).is_file(), asset


def test_branch_indexes_and_canonical_assets_exist():
    router = ReferenceRouter(ROUTES)
    for branch in router.branches.values():
        for asset in [branch["index"], *branch["canonical_assets"]]:
            assert (ROOT / asset).is_file(), asset


def test_default_cli_route_file_is_at_plugin_root():
    assert SCRIPT_DIR.parents[3] / "references" / "reference-routing.json" == ROUTES


def test_standard_branch_aliases_are_accepted():
    router = ReferenceRouter(ROUTES)

    assert router.resolve("ISO 14229 服务语义")["primary_branch"] == "ISO-14229"
    assert router.resolve("118998 高速 CAN 物理层")["primary_branch"] == "ISO-11898"
    assert router.resolve("ISO 17987 LIN 调度表")["primary_branch"] == "ISO-17987"


if __name__ == "__main__":
    for test in (
        test_uds_on_lin_mounts_lin_primary_and_uds_companion,
        test_can_physical_task_does_not_mount_uds_assets_by_default,
        test_uds_application_on_can_adds_can_transport_branch,
        test_all_returned_assets_exist,
    ):
        test()
    print("reference router tests: PASS")
