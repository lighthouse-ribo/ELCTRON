# -*- coding: utf-8 -*-
"""CLI：生成参考系统合格性测试用例风格的 SWDL/网络安全 JSON。"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from cybersecurity_case_generator import build_cybersecurity_cases
from swdl_case_generator import build_swdl_cases


def main() -> int:
    parser = argparse.ArgumentParser(description="生成 SWDL 或网络安全参考风格用例 JSON")
    parser.add_argument("--module", choices=("swdl", "cybersecurity"), required=True)
    parser.add_argument("--requirement", action="append", default=[], help="需求 ID，可重复")
    parser.add_argument("--out", required=True, help="输出 JSON 路径")
    parser.add_argument("--flowchart-ready", action="store_true", help="已提供并确认刷写流程图")
    parser.add_argument("--key-material-ready", action="store_true", help="已提供并授权真实密钥材料")
    parser.add_argument("--bus", default="LIN", help="网络安全承载通道，仅作为元数据")
    args = parser.parse_args()

    if args.module == "swdl":
        result = build_swdl_cases(
            requirement_ids=args.requirement,
            flowchart_ready=args.flowchart_ready,
            key_material_ready=args.key_material_ready,
        )
    else:
        result = build_cybersecurity_cases(
            requirement_ids=args.requirement,
            key_material_ready=args.key_material_ready,
            bus=args.bus,
        )

    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"已生成 {len(result['cases'])} 条 {result['module']} 用例: {output}")
    print(f"generation_status={result['generation_status']}; 未执行用例保持 NOT_EXECUTED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
