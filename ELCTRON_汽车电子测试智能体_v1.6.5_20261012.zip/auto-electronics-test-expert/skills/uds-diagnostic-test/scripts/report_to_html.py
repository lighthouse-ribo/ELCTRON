#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UDS 测试报告 → 美观前端页面（单文件 HTML，离线可用，无构建依赖）
=========================================================================
将执行结果（exec_results.json）+ 附加报告数据（--extra）渲染为自包含 HTML 页面，
可作为最终交付物直接打开/分享/归档。

用法:
  python report_to_html.py --results exec_results.json [--extra extra.json] [--out report.html]

--results: uds_runner 执行结果 JSON（results[] 含 case_id/service/desc/actual/verdict 等）
--extra :  附加数据 JSON（meta/versions/modules/links/evidence/blocked/timing/coverage/mapping/legend），可选

设计说明（方向契约见页面 body 首注释）：浅色科技风 + 科技蓝强调的精密仪器面板语言，
Read 模式，左对齐非对称，等宽数据，克制动效（KPI 计数一次，尊重 prefers-reduced-motion）。
"""

import argparse
import json
import os
import re
import sys
from collections import Counter, defaultdict

_HERE = os.path.dirname(os.path.abspath(__file__))
_SKILLS_DIR = os.path.dirname(os.path.dirname(_HERE))
if _SKILLS_DIR not in sys.path:
    sys.path.insert(0, _SKILLS_DIR)

from project_config import load_project_config  # noqa: E402
from result_contract import infer_failure_class
from swdl_report_adapter import swdl_report_to_results


def _resolve_version_prefixes(source=None):
    """短版本号要剥离的前缀，来自项目配置。

    未移植项目（未传 ``--project-config``）时回退「参考项目档」，因此既有
    报告行为不变；移植新项目时由项目配置的 ``identity.version_prefixes`` 覆盖。
    """
    try:
        config = load_project_config(source or None)
    except ValueError:
        return ()
    identity = config.get("identity") or {}
    return tuple(str(value) for value in (identity.get("version_prefixes") or []) if str(value).strip())


# 默认取参考项目档；main() 里按 --project-config 重新解析。
_VERSION_PREFIXES = _resolve_version_prefixes()


PAGE_CSS = """
:root {
  color-scheme: light;
  --bg: #f6f8fb;
  --bg-2: #ffffff;
  --bg-3: #eef2f7;
  --ink: #182031;
  --ink-2: #46566e;
  --ink-3: #5d6c80;
  --hairline: rgba(24, 32, 49, 0.12);
  --accent: #2563eb;
  --accent-deep: #1d4ed8;
  --accent-2: #60a5fa;
  --ok: #15803d;
  --na: #64748b;
  --fail: #b91c1c;
  --warn: #b45309;
  --grid-line: rgba(37, 99, 235, 0.055);
  --nav-h: 46px;
  --radius: 6px;
  --mono: "Cascadia Mono", "JetBrains Mono", "SF Mono", Consolas, Menlo, monospace;
  --sans: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "PingFang SC", "Microsoft YaHei", sans-serif;
  --ease-out-quart: cubic-bezier(0.25, 1, 0.5, 1);
  --ease-out-expo: cubic-bezier(0.16, 1, 0.3, 1);
  --ease-in: cubic-bezier(0.7, 0, 0.84, 0);
  --shadow-soft: 0 1px 2px rgba(24, 32, 49, 0.05), 0 10px 28px -14px rgba(24, 32, 49, 0.14);
  --shadow-float: 0 4px 16px -6px rgba(24, 32, 49, 0.16);
}
* { box-sizing: border-box; }
html { scrollbar-color: #c8d2e0 var(--bg); }
body {
  margin: 0;
  background:
    radial-gradient(1100px 460px at 82% -10%, rgba(37, 99, 235, 0.07), transparent 62%),
    radial-gradient(900px 400px at -10% 110%, rgba(96, 165, 250, 0.05), transparent 55%),
    var(--bg);
  color: var(--ink);
  font-family: var(--sans);
  font-size: 15px;
  line-height: 1.55;
  -webkit-font-smoothing: antialiased;
}
::selection { background: rgba(37, 99, 235, 0.18); color: var(--ink); }
::placeholder { color: var(--ink-3); }
a { color: var(--accent); text-decoration-thickness: 1px; text-underline-offset: 3px; }
a:focus-visible, button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.wrap { max-width: 1180px; margin: 0 auto; padding: 0 28px; }

/* ===== 入场动效（impeccable: 500-800ms 入场 + ease-out-quart，只动 transform/opacity）===== */
@keyframes rise {
  from { opacity: 0; transform: translateY(16px); }
  to   { opacity: 1; transform: translateY(0); }
}
@keyframes fadein { from { opacity: 0; } to { opacity: 1; } }
@keyframes growx {
  from { transform: scaleX(0); }
  to   { transform: scaleX(1); }
}
.rise { opacity: 0; animation: rise 640ms var(--ease-out-quart) forwards; }
.reveal { opacity: 0; transform: translateY(22px); transition: opacity 700ms var(--ease-out-quart), transform 700ms var(--ease-out-quart); }
.reveal.in { opacity: 1; transform: translateY(0); }
.d1 { animation-delay: 60ms; } .d2 { animation-delay: 140ms; } .d3 { animation-delay: 220ms; }
.d4 { animation-delay: 300ms; } .d5 { animation-delay: 380ms; }

/* ===== 顶栏 ===== */
.masthead {
  padding: 52px 0 30px; border-bottom: 1px solid var(--hairline);
  position: relative; overflow: hidden;
  background: var(--bg-2);
  box-shadow: var(--shadow-soft);
}
.masthead::before { content: ""; position: absolute; inset: 0; z-index: 0; pointer-events: none; }
.masthead::after {
  content: ""; position: absolute; left: 0; right: 0; bottom: -1px; height: 2.5px;
  background: linear-gradient(90deg, var(--accent), var(--accent-2), transparent 72%);
  transform-origin: left; animation: growx 900ms var(--ease-out-expo) 400ms backwards;
}
.masthead .wrap { position: relative; z-index: 1; }

/* ===== 粘性章节导航（长报告快速定位，打印隐藏） ===== */
.snav {
  position: sticky; top: 0; z-index: 30;
  background: rgba(246, 248, 251, 0.88);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  border-bottom: 1px solid var(--hairline);
}
.snav .wrap { display: flex; align-items: center; gap: 4px; height: var(--nav-h); overflow-x: auto; scrollbar-width: none; }
.snav .wrap::-webkit-scrollbar { display: none; }
.snav a {
  font-family: var(--mono); font-size: 12px; letter-spacing: 0.03em;
  color: var(--ink-3); padding: 6px 13px; border-radius: 999px;
  text-decoration: none; white-space: nowrap;
  transition: color 150ms ease-out, background 150ms ease-out;
}
.snav a:hover { color: var(--accent); background: rgba(37, 99, 235, 0.07); }
.snav a.on { color: var(--accent-deep); background: rgba(37, 99, 235, 0.11); font-weight: 600; }
section.block { scroll-margin-top: calc(var(--nav-h) + 10px); }
.masthead .meta-line {
  display: flex; flex-wrap: wrap; gap: 10px 18px; align-items: baseline;
  color: var(--ink-3); font-size: 12.5px; letter-spacing: 0.01em;
  font-family: var(--mono);
}
.meta-cell {
  display: inline-flex; align-items: baseline; gap: 10px;
  padding: 2px 18px 2px 0; margin-right: 16px;
  border-right: 1px solid var(--hairline);
}
.meta-cell:last-child { border-right: 0; margin-right: 0; padding-right: 0; }
.meta-cell b { color: var(--ink-2); font-weight: 500; }
}
.masthead h1 {
  margin: 18px 0 12px;
  font-size: clamp(30px, 4.6vw, 50px);
  line-height: 1.05;
  letter-spacing: -0.03em;
  font-weight: 700;
  max-width: 22ch;
  font-family: var(--sans);
  color: var(--ink);
}
.masthead h1 em { font-style: normal; color: var(--accent); }
.masthead .sub { color: var(--ink-2); max-width: 66ch; margin: 0; font-size: 15.5px; }
.masthead .flag {
  display: inline-flex; align-items: center; gap: 9px;
  margin-top: 20px; font-size: 13px; font-weight: 500; color: var(--ok);
}
.masthead .flag::before {
  content: ""; width: 8px; height: 8px; border-radius: 50%;
  background: var(--ok);
  box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.4);
  animation: pulse 2.4s var(--ease-out-quart) infinite;
}
@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.40); }
  70% { box-shadow: 0 0 0 9px rgba(22, 163, 74, 0); }
  100% { box-shadow: 0 0 0 0 rgba(22, 163, 74, 0); }
}

/* ===== KPI 带 ===== */
.kpis {
  display: grid; grid-template-columns: repeat(5, minmax(0, 1fr));
  border-bottom: 1px solid var(--hairline);
  background: var(--bg-2);
}
.kpi { padding: 30px 20px 26px 0; border-right: 1px solid var(--hairline); position: relative; transition: transform .15s, border-color .15s, background .15s; }
.kpi:last-child { border-right: 0; }
.kpi:hover { transform: translateY(-1px); border-color: var(--accent); }
.kpi:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.kpi.kpi-active { background: #f1f5fd; border-color: var(--accent); box-shadow: 0 4px 12px -6px var(--accent); }
.kpi .num {
  font-family: var(--sans); font-variant-numeric: tabular-nums lining-nums;
  font-feature-settings: "tnum" 1, "ss01" off;
  font-size: clamp(28px, 3.2vw, 40px); line-height: 1; letter-spacing: -0.02em;
  display: inline-block;
}
.kpi .lbl { margin-top: 10px; color: var(--ink-3); font-size: 13px; }
.kpi .sub { margin-top: 5px; color: var(--ink-3); font-size: 11.5px; font-family: var(--mono); letter-spacing: 0.02em; }
.kpi .bar { margin-top: 14px; height: 3px; background: var(--bg-3); border-radius: 2px; overflow: hidden; }
.kpi .bar i { display: block; height: 100%; width: 100%; background: currentColor; transform-origin: left; animation: growx 1.1s var(--ease-out-expo) backwards; }
.kpi.pass { color: var(--ok); } .kpi.na { color: var(--na); }
.kpi.blocked { color: var(--warn); } .kpi.fail { color: var(--fail); } .kpi.rate { color: var(--accent); }
.kpi .num, .kpi .lbl { color: inherit; }
.kpi.rate .lbl { color: var(--ink-3); }

/* ===== 章节 ===== */
section.block { padding: 46px 0 38px; border-bottom: 1px solid var(--hairline); background: transparent; }
section.block:last-of-type { border-bottom: 0; }
.block h2 {
  margin: 0 0 22px; font-size: 20px; font-weight: 620; letter-spacing: -0.015em;
  display: flex; align-items: baseline; gap: 12px; color: var(--ink);
}
.block h2 .no {
  font-family: var(--mono); font-size: 12.5px; color: var(--accent);
  letter-spacing: 0.08em; font-weight: 600;
  background: rgba(37, 99, 235, 0.09); padding: 2px 8px; border-radius: 4px;
}
.block h2 .cnt { font-family: var(--mono); font-size: 12.5px; color: var(--ink-3); font-weight: 400; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0 56px; }

/* 链路验证 */
.link-rows { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0 56px; }
.link-row {
  display: grid; grid-template-columns: 64px 1fr; align-items: center; gap: 14px;
  padding: 12px 0; border-bottom: 1px solid var(--hairline);
  font-size: 14.5px;
}
.link-row .st {
  font-family: var(--mono); font-size: 11px; font-weight: 600; letter-spacing: 0.06em;
  color: var(--ok); min-width: 56px; padding: 3px 8px;
  border: 1px solid currentColor; border-radius: 4px; text-align: center;
  background: rgba(22, 163, 74, 0.06);
}
.link-row.off .st { color: var(--warn); background: rgba(217, 119, 6, 0.08); }
.link-row .name { color: var(--ink-2); }

/* 数据表 */
.tbl { width: 100%; border-collapse: collapse; font-size: 14px; }
.tbl th {
  text-align: left; font-weight: 600; color: var(--ink-3);
  font-size: 12px; letter-spacing: 0.05em; text-transform: uppercase;
  padding: 0 12px 10px 0; white-space: nowrap;
}
.tbl td { padding: 10px 12px 10px 0; border-top: 1px solid var(--hairline); vertical-align: top; }
.tbl td.mono, .tbl th.mono { font-family: var(--mono); font-variant-numeric: tabular-nums; font-size: 13px; }
.tbl .num { text-align: right; }
.tbl tbody tr { transition: background-color 200ms ease-out; }
.tbl tbody tr:hover { background: rgba(37, 99, 235, 0.05); }

/* 徽章 */
.chip {
  display: inline-block; min-width: 40px; text-align: center;
  font-family: var(--mono); font-size: 11.5px; font-weight: 600; letter-spacing: 0.04em;
  border: 1px solid currentColor; border-radius: 999px;
  padding: 2px 10px; line-height: 1.45;
  background: transparent;
}
.chip.pass { color: var(--ok); background: rgba(22, 163, 74, 0.07); }
.chip.na { color: var(--na); background: rgba(100, 116, 139, 0.08); }
.chip.blocked { color: var(--warn); background: rgba(180, 83, 9, 0.09); }
.chip.fail { color: var(--fail); background: rgba(185, 28, 28, 0.07); }
.chip.skip { color: #2563eb; background: rgba(37, 99, 235, 0.08); }
.chip.retest { color: #7c3aed; background: rgba(124, 58, 237, 0.08); }
.chip.deviation { color: #0f766e; background: rgba(13, 148, 136, 0.08); }

/* 空态与补充说明 */
.empty-state {
  padding: 22px 0 10px; color: var(--ink-3); font-family: var(--mono);
  font-size: 12.5px; text-align: center; letter-spacing: 0.02em;
}
tr.empty-state-row td { text-align: center; padding: 20px 0 8px; }
.chain-note {
  padding: 12px 0; color: var(--ok); font-size: 13.5px;
  display: flex; align-items: baseline; gap: 10px;
}
.chain-note::before {
  content: ""; width: 7px; height: 7px; border-radius: 50%;
  background: var(--ok); flex: 0 0 auto;
}

/* 用例明细：表头吸顶 */
.tbl.sticky thead th {
  position: sticky; top: var(--nav-h); z-index: 5;
  background: var(--bg-2); box-shadow: 0 1px 0 var(--hairline);
}

/* 证据链 */
.chain { display: grid; gap: 0; }
.chain-item { position: relative; padding: 14px 0 14px 24px; border-bottom: 1px solid var(--hairline); }
.chain-item::before {
  content: ""; position: absolute; left: 3px; top: 18px; bottom: -18px;
  width: 1.5px; background: linear-gradient(180deg, var(--accent), rgba(37, 99, 235, 0.05));
}
.chain-item::after {
  content: ""; position: absolute; left: 0; top: 20px; width: 9px; height: 9px;
  border-radius: 50%; background: var(--bg-2); border: 1.5px solid var(--accent);
}
.chain-item:last-child::before { display: none; }
.chain-item .t { font-size: 14.5px; color: var(--ink); }
.chain-item .d { margin-top: 4px; font-size: 13px; color: var(--ink-2); font-family: var(--mono); }
.chain-item .d:empty { display: none; }

/* 时序 */
.timing-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px 56px; }
.timing-item { padding: 4px 0 22px; }
.timing-item .k { color: var(--ink-3); font-size: 12.5px; letter-spacing: 0.02em; }
.timing-item .v {
  font-family: var(--sans); font-variant-numeric: tabular-nums lining-nums;
  font-feature-settings: "tnum" 1, "ss01" off;
  font-size: clamp(17px, 1.7vw, 21px); margin-top: 8px; color: var(--accent);
  display: block; font-weight: 600; line-height: 1.45;
  white-space: normal; overflow-wrap: anywhere;
}
.timing-item .n { color: var(--ink-3); font-size: 12.5px; margin-top: 2px; }

/* 覆盖率 */
.cov-row { display: grid; grid-template-columns: 180px 1fr; gap: 18px; align-items: center; padding: 13px 0; }
.cov-row .k { color: var(--ink-2); font-size: 14px; }
.cov-row .track { position: relative; height: 6px; background: var(--bg-3); border-radius: 3px; overflow: hidden; }
.cov-row .fill {
  position: absolute; left: 0; top: 0; height: 100%;
  background: linear-gradient(90deg, var(--accent), var(--accent-2));
  border-radius: 3px;
  transform: scaleX(0); transform-origin: left;
  animation: growx 1.2s var(--ease-out-expo) backwards;
}
.cov-row .val { font-family: var(--sans); font-size: 14px; margin-left: 14px; color: var(--ink); font-variant-numeric: tabular-nums lining-nums; font-feature-settings: "tnum" 1, "ss01" off; font-weight: 600; }

/* 页脚 */
footer { padding: 40px 0 60px; color: var(--ink-3); font-size: 13px; }
footer .rule {
  display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0 40px;
  padding-top: 28px; border-top: 1px solid var(--hairline);
}
footer .rule b { color: var(--ink-2); font-weight: 600; }
footer .gen { margin-top: 26px; font-family: var(--mono); font-size: 12px; }

/* 筛选与用例明细 */
.filters { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin: 0 0 16px; }
.fbtn {
  font-family: var(--mono); font-size: 12px; color: var(--ink-2);
  background: var(--bg-2); border: 1px solid var(--hairline); border-radius: 999px;
  padding: 5px 14px; cursor: pointer;
  transition: color 150ms ease-out, border-color 150ms ease-out, background 150ms ease-out, transform 150ms ease-out, box-shadow 150ms ease-out;
}
.fbtn:hover { color: var(--accent); border-color: var(--accent); transform: translateY(-1px); box-shadow: 0 2px 8px -2px rgba(37, 99, 235, 0.3); }
.fbtn[aria-pressed="true"] { color: #fff; background: var(--accent); border-color: var(--accent); box-shadow: 0 2px 10px -2px rgba(37, 99, 235, 0.45); }
.fbtn:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.search {
  margin-left: auto; background: var(--bg-2); color: var(--ink);
  border: 1px solid var(--hairline); border-radius: 8px;
  padding: 6px 12px; font-family: var(--mono); font-size: 13px; min-width: 220px;
}
.search:focus { outline: 2px solid var(--accent); outline-offset: 1px; border-color: var(--accent); }
.search::placeholder { color: var(--ink-3); }
.tbl tbody tr.empty td { text-align: center; color: var(--ink-3); padding: 18px 0; }

@media print {
  body { background: #fff; color: #111; }
  .wrap { max-width: none; }
  .snav, .filters, .flag, footer .gen, .masthead::before { display: none !important; }
  .masthead { box-shadow: none; }
  section.block, .kpi, .link-row { border-color: #ddd; page-break-inside: avoid; }
  .kpi .num, .kpi.pass .num, .kpi.na .num, .kpi.blocked .num, .kpi.fail .num { color: #111; }
  .kpi .sub { color: #555; }
  .kpi .bar, .masthead::after { display: none; }
  .chip.pass { color: #0a6; } .chip.na { color: #555; } .chip.blocked { color: #a86; } .chip.fail { color: #b33; } .chip.skip { color: #2563eb; }
  .tbl.sticky thead th { position: static; box-shadow: none; background: #fff; }
  .empty-state, .chain-note { color: #555; }
  .tbl { font-size: 12px; }
  .tbl td, .tbl th { border-color: #ddd; }
  a { color: #333; }
  .rise, .reveal { opacity: 1 !important; transform: none !important; animation: none !important; }
}

@media (max-width: 900px) {
  .kpis { grid-template-columns: repeat(2, 1fr); }
  .kpi { border-bottom: 1px solid var(--hairline); }
  .kpi:nth-child(5) { border-bottom: 0; }
  .link-rows, .grid2 { grid-template-columns: 1fr; }
  .timing-grid { grid-template-columns: repeat(2, 1fr); }
  .link-row { grid-template-columns: 56px 1fr; gap: 10px; }
  footer .rule { grid-template-columns: 1fr; gap: 14px; }
  .tbl.sticky thead th { position: static; }
}
@media (max-width: 560px) {
  .wrap { padding: 0 18px; }
  .kpis { grid-template-columns: 1fr; }
  .kpi { border-right: 0; }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
  .rise, .reveal { opacity: 1 !important; transform: none !important; }
  .kpi .bar i, .cov-row .fill, .masthead::after { transform: scaleX(1) !important; }
}

"""

REPORT_TEMPLATE_CSS = r"""
/* 软件版本与报告内模块：时间轴只切换版本，模块属于当前版本报告 */
.report-timeline { padding: 24px 0 0; background: transparent; }
.version-timeline { background: var(--bg-2); border: 1px solid var(--hairline); border-radius: 12px; padding: 18px 20px 20px; box-shadow: var(--shadow-soft); }
.version-timeline .head { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; }
.version-timeline h2 { margin: 0; color: var(--ink); font-size: 15px; font-weight: 750; letter-spacing: 0.01em; }
.version-timeline .note { color: var(--ink-3); font-size: 12px; }
.version-rail { position: relative; min-height: 142px; margin-top: 18px; padding-top: 8px; }
.version-rail::before { content: \"\"; position: absolute; left: 24px; right: 24px; top: 15px; height: 2px; border-radius: 2px; background: linear-gradient(90deg, var(--accent), var(--accent-2)); opacity: .42; }
.version-nodes { display: flex; gap: 18px; overflow-x: auto; padding: 0 4px 4px; }
.version-node { display: flex; flex-direction: column; align-items: center; gap: 8px; flex: none; min-width: 280px; border: 0; padding: 0; background: transparent; color: inherit; font: inherit; text-align: left; cursor: pointer; }
.version-node .dot { position: relative; width: 14px; height: 14px; z-index: 1; border: 3px solid var(--bg-2); border-radius: 50%; background: var(--accent); box-shadow: 0 0 0 2px var(--accent); }
.version-card { display: grid; grid-template-columns: auto minmax(0, 1fr); grid-template-areas: \"tag time\" \"tag mods\" \"tag sum\"; align-items: center; column-gap: 12px; row-gap: 4px; width: 100%; min-height: 108px; padding: 12px 14px; background: var(--bg-2); border: 1px solid var(--hairline); border-radius: 10px; transition: transform 150ms ease-out, border-color 150ms ease-out, box-shadow 150ms ease-out; }
.version-node:hover .version-card, .version-node.active .version-card { border-color: var(--accent); box-shadow: 0 8px 18px -16px rgba(37, 99, 235, .8); transform: translateY(-1px); }
.version-tag { grid-area: tag; align-self: stretch; display: grid; place-items: center; padding: 8px 12px; border-radius: 8px; color: #fff; background: var(--accent); font-size: 16px; font-weight: 800; letter-spacing: .03em; }
.version-time { grid-area: time; color: var(--ink); font-family: var(--mono); font-size: 12px; font-weight: 700; }
.version-modules { grid-area: mods; display: flex; gap: 4px; flex-wrap: wrap; }
.version-modules span { padding: 1px 7px; border-radius: 999px; color: #fff; background: var(--accent); font-size: 10px; font-weight: 800; }
.version-modules .planned { background: #be185d; }
.version-summary { grid-area: sum; color: var(--ink-3); font-size: 11px; font-variant-numeric: tabular-nums; }
.report-shell { padding: 18px 0 0; }
.report-shell .wrap { background: var(--bg-2); border: 1px solid var(--hairline); border-radius: 12px; box-shadow: var(--shadow-soft); overflow: hidden; }
.report-summary { display: flex; align-items: center; gap: 14px; padding: 14px 16px 10px; flex-wrap: wrap; }
.report-summary .badge { display: grid; place-items: center; min-width: 58px; min-height: 40px; padding: 7px 10px; border-radius: 8px; color: #fff; background: var(--accent); font-family: var(--mono); font-size: 16px; font-weight: 800; }
.report-summary h2 { margin: 0; color: var(--ink); font-size: 17px; font-weight: 800; }
.report-summary p { margin: 2px 0 0; color: var(--ink-3); font-size: 12px; }
.module-tabs { display: flex; align-items: center; gap: 8px; padding: 10px 16px 14px; border-top: 1px solid var(--hairline); flex-wrap: wrap; }
.module-tabs .label { margin-right: 4px; color: var(--ink-3); font-size: 11px; font-weight: 800; letter-spacing: .05em; }
.module-tab { display: inline-flex; align-items: center; gap: 7px; min-height: 32px; padding: 5px 10px; border: 1px solid var(--hairline); border-radius: 8px; color: var(--ink-2); background: var(--bg-2); font: inherit; font-size: 12px; font-weight: 800; cursor: pointer; }
.module-tab:hover { color: var(--accent); border-color: var(--accent); }
.module-tab[aria-selected=\"true\"] { color: var(--accent); border-color: var(--accent); background: rgba(37, 99, 235, .07); }
.module-tab .count { color: var(--ink-3); font-size: 10.5px; font-weight: 600; }
.module-tab[aria-selected=\"true\"] .count { color: inherit; opacity: .82; }
.module-panel[hidden] { display: none; }
.security-placeholder { max-width: 1180px; margin: 28px auto 0; padding: 0 28px; }
.security-placeholder .inner { padding: 24px; border: 1px dashed rgba(190, 24, 93, .55); border-radius: 12px; background: rgba(255, 255, 255, .86); }
.security-placeholder h2 { margin: 0; color: #9d174d; font-size: 18px; }
.security-placeholder p { margin: 8px 0 0; color: var(--ink-2); font-size: 13px; }
/* 覆盖率与时序：同高概览双卡，覆盖率信息固定纵向排列 */
.overview { padding: 28px 0 6px; }
.overview-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); align-items: stretch; gap: 16px; }
.overview-card { display: flex; flex-direction: column; padding: 18px; border: 1px solid var(--hairline); border-radius: 12px; background: var(--bg-2); box-shadow: var(--shadow-soft); }
.overview-card h2 { margin: 0 0 12px; color: var(--ink); font-size: 14px; font-weight: 800; }
.coverage-item, .timing-overview-item { display: flex; flex: 1 1 0; flex-direction: column; justify-content: center; gap: 7px; padding: 10px 0; border-bottom: 1px dashed var(--hairline); }
.coverage-item:last-child, .timing-overview-item:last-child { border-bottom: 0; }
.coverage-item .k, .timing-overview-item .k { color: var(--ink-2); font-size: 13px; font-weight: 600; }
.coverage-item .track { height: 7px; overflow: hidden; border-radius: 999px; background: var(--bg-3); }
.coverage-item .fill { height: 100%; border-radius: inherit; background: linear-gradient(90deg, var(--ok), #34c7b4); transform: scaleX(0); transform-origin: left; animation: growx 1.2s var(--ease-out-expo) backwards; }
.coverage-item .v { color: var(--ink); font-size: 12px; font-weight: 700; font-variant-numeric: tabular-nums; }
.timing-overview-item .v { color: var(--accent); font-size: 14px; font-weight: 800; font-variant-numeric: tabular-nums; }
.timing-overview-item .n { color: var(--ink-3); font-size: 11.5px; }
@media (max-width: 900px) { .overview-grid { grid-template-columns: 1fr; } }
@media (max-width: 560px) {
  .version-timeline { padding: 15px 14px 16px; }
  .version-rail { min-height: 138px; }
  .version-rail::before { left: 18px; right: 18px; }
  .version-node { min-width: min(280px, calc(100vw - 58px)); }
  .module-tabs { align-items: stretch; }
  .module-tabs .label { width: 100%; }
  .module-tab { flex: 1 1 140px; justify-content: center; }
  .security-placeholder { padding: 0 18px; }
}
"""

PAGE_CSS += REPORT_TEMPLATE_CSS

# v2 报告布局：以“一个软件版本的一份综合报告”为核心，时间轴只做报告切换，
# 模块页签只做当前报告内的模块切换。保留旧样式定义是为了不破坏早期报告，v2
# 使用独立 v2-* 类名，避免新旧页面相互覆盖。
PAGE_CSS += r"""
.v2-report { padding: 24px 0 56px; }
.v2-context { margin: 0 0 18px; border: 1px solid var(--hairline); border-radius: 14px; overflow: hidden; background: var(--bg-2); box-shadow: var(--shadow-soft); }
.v2-context-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 20px; padding: 20px 22px 16px; }
.v2-context h2 { margin: 0; font-size: 18px; line-height: 1.3; letter-spacing: -0.015em; }
.v2-context p { margin: 5px 0 0; color: var(--ink-3); font-size: 13px; }
.v2-context .scope { flex: 0 0 auto; padding: 5px 8px; border-radius: 999px; color: var(--accent-deep); background: rgba(37, 99, 235, .08); font: 600 11px/1.3 var(--mono); }
.v2-timeline { display: flex; gap: 10px; overflow-x: auto; padding: 14px 22px 18px; border-top: 1px solid var(--hairline); background: #fbfcfe; }
.v2-version { display: grid; grid-template-columns: 9px minmax(165px, 1fr); gap: 9px; min-width: 245px; padding: 0; border: 0; color: inherit; text-decoration: none; background: transparent; text-align: left; }
.v2-version i { display: block; width: 9px; height: 9px; margin-top: 9px; border-radius: 50%; background: #a5b4c8; box-shadow: 0 0 0 3px #e8edf5; }
.v2-version.active i { background: var(--accent); box-shadow: 0 0 0 3px rgba(37, 99, 235, .15); }
.v2-version-card { padding: 9px 11px; border: 1px solid transparent; border-radius: 8px; }
.v2-version:hover .v2-version-card, .v2-version.active .v2-version-card { border-color: rgba(37, 99, 235, .32); background: var(--bg-2); }
.v2-version strong { display: block; color: var(--ink); font: 700 13px/1.3 var(--mono); }
.v2-version span, .v2-version small { display: block; margin-top: 3px; color: var(--ink-3); font-size: 11.5px; }
.v2-tabs { display: flex; align-items: center; gap: 8px; padding: 10px 22px; border-top: 1px solid var(--hairline); }
.v2-tabs-label { margin-right: 4px; color: var(--ink-3); font-size: 12px; }
.v2-tabs .module-tab { border-radius: 7px; }
.v2-notice { display: grid; grid-template-columns: auto minmax(0, 1fr); gap: 10px; align-items: start; padding: 12px 14px; border: 1px solid rgba(180, 83, 9, .26); border-radius: 10px; background: #fffbeb; color: #713f12; font-size: 13px; }
.v2-notice b { font: 700 11px/1.5 var(--mono); letter-spacing: .04em; }
.v2-summary { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)); border: 1px solid var(--hairline); border-radius: 12px; background: var(--bg-2); overflow: hidden; }
.v2-stat { min-height: 112px; padding: 18px; border-right: 1px solid var(--hairline); }
.v2-stat:last-child { border-right: 0; }
.v2-stat .n { font-variant-numeric: tabular-nums; font-size: 30px; font-weight: 750; line-height: 1; letter-spacing: -.03em; }
.v2-stat .l { margin-top: 8px; color: var(--ink-2); font-size: 12px; }
.v2-stat .s { margin-top: 4px; color: var(--ink-3); font: 11px/1.4 var(--mono); }
.v2-stat.pass .n { color: var(--ok); }.v2-stat.fail .n { color: var(--fail); }.v2-stat.blocked .n { color: var(--warn); }.v2-stat.skip .n { color: var(--na); }.v2-stat.retest .n { color: #7c3aed; }.v2-stat.deviation .n { color: #0f766e; }.v2-stat.rate .n { color: var(--accent); }
.v2-section { margin-top: 18px; padding: 22px; border: 1px solid var(--hairline); border-radius: 12px; background: var(--bg-2); }
.v2-section h2 { margin: 0 0 15px; color: var(--ink); font-size: 16px; letter-spacing: -.01em; }
.v2-section > p { margin: -7px 0 15px; color: var(--ink-3); font-size: 12.5px; }
.v2-grid { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 18px; }
.v2-pane { min-width: 0; }
.v2-pane + .v2-pane { padding-left: 18px; border-left: 1px solid var(--hairline); }
.v2-pane h3 { margin: 0 0 12px; color: var(--ink-2); font-size: 13px; }
.v2-list { margin: 0; padding: 0; list-style: none; }
.v2-list li { display: grid; grid-template-columns: minmax(120px, .8fr) minmax(0, 1.2fr); gap: 12px; padding: 9px 0; border-bottom: 1px solid var(--hairline); }
.v2-list li:last-child { border-bottom: 0; }.v2-list b { color: var(--ink-2); font-size: 12.5px; }.v2-list span { color: var(--ink-3); font: 11.5px/1.5 var(--mono); overflow-wrap: anywhere; }
.v2-evidence { display: grid; gap: 9px; }.v2-evidence-row { display: grid; grid-template-columns: minmax(90px, .55fr) minmax(135px, 1fr) minmax(0, 1.15fr); gap: 9px; align-items: start; padding: 10px; border-radius: 8px; background: #f8fafc; }
.v2-evidence code { color: var(--accent-deep); font: 11px/1.45 var(--mono); overflow-wrap: anywhere; }.v2-evidence p { margin: 0; color: var(--ink-2); font-size: 12px; }
.v2-table-wrap { overflow-x: auto; }.v2-table { width: 100%; min-width: 720px; border-collapse: collapse; font-size: 12.5px; }.v2-table th { padding: 0 10px 9px 0; color: var(--ink-3); text-align: left; font-size: 11px; font-weight: 650; }.v2-table td { padding: 10px 10px 10px 0; border-top: 1px solid var(--hairline); vertical-align: top; }.v2-table .num { text-align: right; font-variant-numeric: tabular-nums; }.v2-table .mono { font-family: var(--mono); font-size: 11.5px; }.v2-table .actual { max-width: 265px; color: var(--ink-2); overflow-wrap: anywhere; }.v2-table .note { max-width: 260px; color: var(--ink-3); }.v2-table tbody tr:hover { background: #f8fbff; }
.v2-filters { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin: 0 0 14px; }.v2-filters .search { margin-left: auto; }.v2-empty { padding: 18px 0; color: var(--ink-3); text-align: center; font-size: 12px; }
.v2-security { margin-top: 18px; }.v2-security .v2-section { background: #fbfcfe; }.v2-security p { margin: 0; color: var(--ink-2); max-width: 72ch; font-size: 13px; }
.v2-module-panel { margin-top: 18px; }.v2-module-panel .v2-section { background: #fbfcfe; }.v2-module-panel p { margin: 0; color: var(--ink-2); max-width: 72ch; font-size: 13px; }
@media (max-width: 900px) { .v2-summary { grid-template-columns: repeat(2, minmax(0, 1fr)); }.v2-stat:nth-child(2n) { border-right: 0; }.v2-stat { border-bottom: 1px solid var(--hairline); }.v2-stat:last-child { border-bottom: 0; }.v2-grid { grid-template-columns: 1fr; }.v2-pane + .v2-pane { padding: 18px 0 0; border-top: 1px solid var(--hairline); border-left: 0; }.v2-evidence-row { grid-template-columns: 1fr 1fr; }.v2-evidence-row p { grid-column: 1 / -1; }.v2-context-head { display: block; }.v2-context .scope { display: inline-block; margin-top: 10px; } }
@media (max-width: 560px) { .v2-report { padding-top: 14px; }.v2-context-head, .v2-tabs, .v2-timeline, .v2-section { padding-left: 14px; padding-right: 14px; }.v2-summary { grid-template-columns: 1fr; }.v2-stat, .v2-stat:nth-child(2n) { border-right: 0; }.v2-list li { grid-template-columns: 1fr; gap: 3px; }.v2-filters .search { width: 100%; margin-left: 0; }.v2-evidence-row { grid-template-columns: 1fr; }.v2-evidence-row p { grid-column: auto; } }
@media print { .v2-report { padding: 0; }.v2-context, .v2-summary, .v2-section { box-shadow: none; }.v2-notice { background: #fff; }.v2-tabs, .v2-filters { display: none; } }
"""


def esc(v):
    return (str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("—", "-").replace("–", "-"))


def esc_attr(v):
    return esc(v).replace('"', "&quot;").replace("'", "&#39;")


def safe_id(value, fallback="module"):
    """把外部模块键转换为可用于 HTML id/data 属性的稳定标识。"""
    text = re.sub(r"[^A-Za-z0-9_-]+", "-", str(value or "")).strip("-")
    return text or fallback


def chip(v):
    cls = {"PASS": "pass", "NA": "na", "BLOCKED": "blocked", "FAIL": "fail", "SKIP": "skip",
           "RETEST": "retest", "DEVIATION": "deviation"}.get(str(v).upper(), "na")
    return '<span class="chip %s">%s</span>' % (cls, esc(v))


def _is_timing_result(item):
    return (str(item.get("service") or "") == "TimeParm"
            or bool(item.get("timing_metric"))
            or isinstance(item.get("timing_spec"), dict))


FAILURE_CLASS_LABELS = {
    "ECU_FAIL": "ECU_FAIL：ECU/协议实际判定失败",
    "SCRIPT_ERROR": "SCRIPT_ERROR：脚本异常或崩溃",
    "INFRA_ERROR": "INFRA_ERROR：Vector、CAN、运行环境等基础设施异常",
    "INPUT_INVALID": "INPUT_INVALID：调查表或输入数据无效",
    "RESULT_INVALID": "RESULT_INVALID：结果文件缺失、非法或证据不完整",
    "BLOCKED": "BLOCKED：前置条件不满足",
}


def _failure_annotation(item):
    """仅对 HTML 中的 FAIL 展示失败原因，其他状态保留内部分类但不外显。"""
    if str(item.get("verdict") or "").upper() != "FAIL":
        return ""
    failure_class = str(item.get("failure_class") or "RESULT_INVALID").upper()
    return FAILURE_CLASS_LABELS.get(
        failure_class, "RESULT_INVALID：结果文件缺失、非法或证据不完整"
    )


def _normalize_report_result(item):
    """保留明确排除项的 SKIP；时序项的 SKIP 代表未测试，必须判 FAIL。"""
    item = dict(item or {})
    verdict = str(item.get("verdict") or "").upper()
    if verdict == "SKIP" and _is_timing_result(item):
        item["verdict"] = "FAIL"
        item["failure_class"] = "RESULT_INVALID"
        item["note"] = (str(item.get("note") or "")
                         + "；时序用例未完成独立采集，已归一为 FAIL").strip("；")
    elif verdict not in {"PASS", "FAIL", "BLOCKED", "NA", "SKIP", "RETEST", "DEVIATION"}:
        item["verdict"] = "FAIL"
        item["failure_class"] = "RESULT_INVALID"
        item["note"] = (str(item.get("note") or "")
                         + "；非法/ERROR 结果状态已归一为 FAIL").strip("；")
    else:
        item["verdict"] = verdict
    if item["verdict"] in {"RETEST", "DEVIATION"} and not item.get("failure_class"):
        item["failure_class"] = "NONE"
    else:
        item["failure_class"] = infer_failure_class(
            item["verdict"], item.get("failure_class"),
            "%s %s" % (item.get("actual") or "", item.get("note") or ""),
        )
    return item


def build_html(data):
    """v2 报告阅读面。所有数量从 results[] 计算，附加数据只提供上下文。"""
    meta = data.get("meta", {})
    summary = data.get("summary", {})
    cases = data.get("cases_detail", [])
    total = summary.get("total", len(cases))
    title = meta.get("title", "UDS 测试执行报告")
    version = str(meta.get("version") or meta.get("software_version") or "当前软件版本")
    test_time = str(meta.get("test_time") or "测试时间待录入")
    executed = summary.get("executed", 0)
    judged = summary.get("judged", summary.get("PASS", 0) + summary.get("FAIL", 0))

    # 报告模型：时间轴是软件版本，模块页签是同一版本报告内的测试块。
    # 不再把 UDS/网络安全写死，后续模块只需在 extra.json 的 modules[] 中声明即可。
    raw_modules = data.get("modules") or [
        {"id": "uds", "label": "UDS 诊断", "status": "executed", "count": total},
        {"id": "security", "label": "网络安全", "status": "planned", "count": 0},
    ]
    modules = []
    seen_module_ids = set()
    for index, item in enumerate(raw_modules):
        if isinstance(item, str):
            item = {"id": item, "label": item}
        item = item if isinstance(item, dict) else {}
        module_id = safe_id(item.get("id") or item.get("key") or item.get("label"), "module-%d" % index)
        if module_id in seen_module_ids:
            module_id = "%s-%d" % (module_id, index)
        seen_module_ids.add(module_id)
        modules.append({
            "id": module_id,
            "label": str(item.get("label") or item.get("name") or module_id),
            "status": str(item.get("status") or "planned").lower(),
            "count": item.get("count", item.get("total", 0)),
            "summary": str(item.get("summary") or ""),
            "description": str(item.get("description") or item.get("note") or ""),
        })
    if not modules:
        modules = [{"id": "uds", "label": "UDS 诊断", "status": "executed", "count": total,
                    "summary": "当前报告无模块数据", "description": ""}]
    active_module = next((m["id"] for m in modules if m["id"] == "uds"), modules[0]["id"])

    def module_count_text(item):
        status = item["status"]
        if status in ("planned", "planning", "not_run", "pending"):
            return "规划中"
        if status in ("blocked", "na"):
            return status.upper()
        return "%s 条" % item["count"] if item["count"] not in (None, "") else "已记录"

    module_tabs = "".join(
        '<button class="module-tab" type="button" role="tab" aria-selected="%s" '
        'aria-controls="module-%s" data-module="%s">%s <span class="count">%s</span></button>'
        % ("true" if item["id"] == active_module else "false", item["id"], item["id"],
           esc(item["label"]), esc(module_count_text(item)))
        for item in modules
    )

    def module_panel(item):
        if item["id"] == "uds":
            return ""
        state_text = {
            "planned": "规划中，尚未产生实测结论。",
            "planning": "规划中，尚未产生实测结论。",
            "blocked": "当前模块受前置条件限制，尚未执行。",
            "na": "当前模块没有可判定的实测记录。",
        }.get(item["status"], "该模块已归入当前软件版本报告。")
        detail = item["description"] or item["summary"] or state_text
        hidden = "" if item["id"] == active_module else " hidden"
        return ('<section class="module-panel v2-module-panel" id="module-%s" role="tabpanel" '
                'data-module-panel="%s"%s><div class="wrap"><div class="v2-section">'
                '<h2>%s</h2><p>%s</p></div></div></section>'
                % (item["id"], item["id"], hidden, esc(item["label"]), esc(detail)))

    module_panels = "".join(module_panel(item) for item in modules if item["id"] != "uds")

    def version_card(item):
        item_version = str(item.get("version") or item.get("name") or version)
        is_active = bool(item.get("active", item_version == version))
        date = str(item.get("test_time") or item.get("date") or test_time)
        version_modules = item.get("modules") or [module["label"] for module in modules]
        desc = str(item.get("summary") or ("%s 条用例，%s 条 FAIL" % (total, summary.get("FAIL", 0))))
        href = item.get("report_url") or "#"
        cls = "v2-version active" if is_active else "v2-version"
        attrs = 'aria-current="page"' if is_active else ''
        if is_active:
            href = "#report-top"
        return ('<a class="%s" href="%s" %s><i></i><span class="v2-version-card">'
                '<strong>%s</strong><span>%s</span><small>%s</small><small>%s</small>'
                '</span></a>' % (cls, esc(href), attrs, esc(item_version), esc(date),
                                  esc(" / ".join(str(m) for m in version_modules)), esc(desc)))

    versions = data.get("versions") or [{
        "version": version, "test_time": test_time,
        "modules": [item["label"] for item in modules],
        "summary": "%s 条用例，%s 条 FAIL" % (total, summary.get("FAIL", 0)),
        "active": True,
    }]
    timeline = "".join(version_card(v) for v in versions)

    def stat(cls, value, label, note):
        return ('<div class="v2-stat %s"><div class="n">%s</div><div class="l">%s</div>'
                '<div class="s">%s</div></div>' % (cls, esc(value), esc(label), esc(note)))

    stats = "".join([
        stat("pass", summary.get("PASS", 0), "PASS", "回包符合当前判定规则"),
        stat("retest", summary.get("RETEST", 0), "需复测", "旧脚本前置或判定不可靠"),
        stat("deviation", summary.get("DEVIATION", 0), "数据偏差", "协议正响应，版本数据待确认"),
        stat("fail", summary.get("FAIL", 0), "FAIL", "实测与调查表期望不符"),
        stat("blocked", summary.get("BLOCKED", 0), "BLOCKED", "未满足前置或风险限制"),
        stat("rate", "%.1f%%" % summary.get("pass_rate", 0), "协议通过率", "%s 条可判定，%s 条已执行" % (judged, executed)),
    ])

    coverage = data.get("coverage", {}).get("rows", [])
    coverage_rows = "".join(
        '<li><b>%s</b><span>%s</span></li>' % (esc(row.get("k", "")), esc(row.get("v", "")))
        for row in coverage
    ) or '<div class="v2-empty">无覆盖率数据</div>'
    timing_rows = "".join(
        '<li><b>%s</b><span>%s<br>%s</span></li>' % (esc(row.get("k", "")), esc(row.get("v", "")), esc(row.get("n", "")))
        for row in data.get("timing", [])
    ) or '<div class="v2-empty">无独立时序测量数据</div>'

    evidence_rows = "".join(
        '<div class="v2-evidence-row"><code>%s</code><code>%s</code><p>%s</p></div>'
        % (esc(row[0]), esc(row[1]), esc(row[2]))
        for row in data.get("evidence", [])
    ) or '<div class="v2-empty">无实测证据</div>'
    restriction_rows = "".join(
        '<li><b>%s</b><span>%s</span></li>' % (esc(row.get("t", "")), esc(row.get("d", "")))
        for row in data.get("blocked", [])
    ) or '<div class="v2-empty">无受限项</div>'

    service_rows = "".join(
        '<tr><td class="mono">%s</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td>'
        '<td class="num">%s</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td>'
        '<td class="note">%s</td></tr>'
        % (esc(row.get("name", "")), row.get("total", 0), row.get("PASS", 0), row.get("FAIL", 0),
            row.get("RETEST", 0), row.get("DEVIATION", 0), row.get("NA", 0), row.get("BLOCKED", 0),
            esc(row.get("note", "")))
        for row in data.get("services", [])
    ) or '<tr><td colspan="9" class="v2-empty">无服务执行记录</td></tr>'

    detail_rows = []
    for item in cases:
        payload = item.get("payload_text", "")
        actual = str(item.get("actual", ""))
        note = str(item.get("note", ""))
        failure_annotation = _failure_annotation(item)
        if failure_annotation:
            note = "%s；%s" % (failure_annotation, note) if note else failure_annotation
        detail_rows.append(
            '<tr data-case="%s" data-service="%s" data-verdict="%s"><td class="mono">%s</td>'
            '<td class="mono">%s</td><td>%s</td><td>%s</td><td>%s</td><td class="actual">%s</td>'
            '<td class="note">%s</td></tr>'
            % (esc(item.get("case_id", "")), esc(item.get("service", "")), esc(item.get("verdict", "")),
               esc(item.get("case_id", "")), esc(item.get("service", "")), esc(item.get("desc", "")),
               esc(item.get("session", "")), chip(item.get("verdict", "")), esc(payload or actual), esc(note))
        )
    details = "".join(detail_rows) or '<tr><td colspan="7" class="v2-empty">无用例明细</td></tr>'
    filters = "".join(
        '<button class="fbtn" data-v="%s"%s>%s</button>' % (kind, ' aria-pressed="true"' if kind == "ALL" else "", label)
        for kind, label in (("ALL", "全部"), ("PASS", "PASS"), ("FAIL", "FAIL"), ("NA", "NA"), ("BLOCKED", "BLOCKED"))
    )

    notice = str(meta.get("notice") or "请求/响应来自执行结果；未执行项按范围限制或前置条件单独标注。")
    flag = str(meta.get("flag") or "执行范围与链路状态见本报告证据")
    context_hidden = "" if active_module == "uds" else " hidden"
    return """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s</title>
<style>%s</style>
</head>
<body>
<header class="masthead" id="report-top"><div class="wrap">
  <div class="meta-line"><span class="meta-cell">软件版本 %s</span><span class="meta-cell">测试时间 %s</span><span class="meta-cell">%s</span></div>
  <h1>%s</h1><p class="sub">%s</p><div class="flag">%s</div>
</div></header>
<div class="wrap v2-report">
  <section class="v2-context" aria-label="报告版本与模块">
    <div class="v2-context-head"><div><h2>本次软件测试报告</h2><p>时间轴切换软件版本。模块页签切换同一版本报告内的测试块。</p></div><span class="scope">当前版本 %s</span></div>
    <div class="v2-timeline" aria-label="软件版本测试时间轴">%s</div>
    <nav class="v2-tabs module-tabs" role="tablist" aria-label="当前报告模块"><span class="v2-tabs-label">测试模块</span>%s</nav>
  </section>
</div>
<main class="module-panel" id="module-uds" role="tabpanel" data-module-panel="uds"%s>
<div class="wrap v2-report">
  <div class="v2-notice"><b>数据状态</b><span>%s</span></div>
  <section class="v2-summary" aria-label="测试结果汇总">%s</section>
  <section class="v2-section"><h2>测试覆盖与时序证据</h2><div class="v2-grid"><div class="v2-pane"><h3>覆盖范围</h3><ul class="v2-list">%s</ul></div><div class="v2-pane"><h3>时序采集</h3><ul class="v2-list">%s</ul></div></div></section>
  <section class="v2-section"><h2>实测证据</h2><p>请求和响应均保留为台架采集证据，版本相关数据不再被当成协议错误。</p><div class="v2-evidence">%s</div></section>
  <section class="v2-section"><h2>服务执行分布</h2><div class="v2-table-wrap"><table class="v2-table"><thead><tr><th>服务</th><th class="num">总数</th><th class="num">PASS</th><th class="num">FAIL</th><th class="num">需复测</th><th class="num">数据偏差</th><th class="num">NA</th><th class="num">BLOCKED</th><th>说明</th></tr></thead><tbody>%s</tbody></table></div></section>
  <section class="v2-section"><h2>范围限制与待复测项</h2><ul class="v2-list">%s</ul></section>
  <section class="v2-section"><h2>用例明细</h2><p>可按结果筛选或按用例、服务、描述搜索。BLOCKED 不作为 ECU 失败；FAIL 项会在判定说明中标注失败原因。</p><div class="v2-filters filters">%s<input class="search" type="search" placeholder="搜索用例 ID、服务或描述"></div><div class="v2-table-wrap"><table class="v2-table" id="detail"><thead><tr><th>用例 ID</th><th>服务</th><th>测试点</th><th>会话</th><th>结果</th><th>请求或响应</th><th>判定说明</th></tr></thead><tbody>%s</tbody></table></div></section>
</div>
</main>
%s
<footer><div class="wrap"><div class="gen">生成时间：%s。总用例 %s，已执行 %s，可判定 %s。</div></div></footer>
<script></script>
</body></html>""" % (
        esc(title), PAGE_CSS, esc(version), esc(test_time), esc(modules[0]["label"]), esc(title), esc(meta.get("sub", "")), esc(flag),
        esc(version), timeline, module_tabs, context_hidden, esc(notice), stats, coverage_rows, timing_rows, evidence_rows, service_rows,
        restriction_rows, filters, details, module_panels, esc(meta.get("generated", "")), total, executed, judged,
    )


def load_results(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return load_results_from_data(data)


def load_results_from_data(data):
    results = data.get("results", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
    normalized = []
    for raw in results:
        normalized.append(_normalize_report_result(raw))
    results = normalized
    cnt = Counter(r.get("verdict") for r in results)
    failure_counts = Counter(str(r.get("failure_class") or "RESULT_INVALID").upper() for r in results)
    services = defaultdict(lambda: Counter())
    for r in results:
        services[r.get("service", "?")][r.get("verdict")] += 1
    svc_rows = []
    for svc in sorted(services):
        c = services[svc]
        svc_rows.append({
            "name": svc, "total": sum(c.values()),
            "PASS": c.get("PASS", 0), "FAIL": c.get("FAIL", 0),
            "RETEST": c.get("RETEST", 0), "DEVIATION": c.get("DEVIATION", 0),
            "NA": c.get("NA", 0), "BLOCKED": c.get("BLOCKED", 0),
            "SKIP": c.get("SKIP", 0),
            "note": "",
        })
    total = len(results)
    executed = (cnt.get("PASS", 0) + cnt.get("FAIL", 0) + cnt.get("NA", 0)
                + cnt.get("RETEST", 0) + cnt.get("DEVIATION", 0))
    judged = cnt.get("PASS", 0) + cnt.get("FAIL", 0)
    rate = round(cnt.get("PASS", 0) / judged * 100, 1) if judged else 0
    return {
        "summary": {
            "PASS": cnt.get("PASS", 0), "NA": cnt.get("NA", 0),
            "BLOCKED": cnt.get("BLOCKED", 0), "FAIL": cnt.get("FAIL", 0),
            "RETEST": cnt.get("RETEST", 0), "DEVIATION": cnt.get("DEVIATION", 0),
            "SKIP": cnt.get("SKIP", 0),
            "failure_classes": dict(failure_counts),
            "ecu_fail": failure_counts.get("ECU_FAIL", 0),
            "ecu_judged": cnt.get("PASS", 0) + failure_counts.get("ECU_FAIL", 0),
            "total": total, "executed": executed,
            "judged": judged, "pass_rate": rate,
        },
        "services": svc_rows,
        "cases_detail": [
            {"case_id": r.get("case_id", ""), "service": r.get("service", ""),
             "desc": r.get("desc", ""), "session": r.get("session", ""),
             "verdict": r.get("verdict", ""), "actual": r.get("actual", ""),
             "failure_class": r.get("failure_class", ""),
             "note": r.get("note", ""),
             "payload_text": " ".join("%02X" % b for b in r.get("payload", []) if isinstance(b, int)),
             "timing_metric": r.get("timing_metric", ""),
             "timing_spec": r.get("timing_spec"),
             "metrics": r.get("metrics", {}),
             "evidence": r.get("evidence", "")}
            for r in results
        ],
    }


def _timing_rows_from_cases(cases):
    """从逐条结果自动生成时序卡片，禁止附加数据用一行 P2 覆盖 15 条。"""
    rows = []
    evidence = []
    for item in cases:
        metric = str(item.get("timing_metric") or "").strip()
        spec = item.get("timing_spec") if isinstance(item.get("timing_spec"), dict) else {}
        if not metric and item.get("service") != "TimeParm" and not spec:
            continue
        label = str(spec.get("label") or metric or "时序")
        case_id = str(item.get("case_id") or "?")
        verdict = str(item.get("verdict") or "FAIL").upper()
        actual = str(item.get("actual") or "无实测结果")
        note = str(item.get("note") or "")
        evidence_path = str(item.get("evidence") or "")
        metrics = item.get("metrics") if isinstance(item.get("metrics"), dict) else {}
        sample_text = ""
        for key in ("p2_ms", "p2_star_ms", "s3_ms", "n_as_ms", "n_cr_ms", "recovery_ms", "slot_ms", "frame_gap_ms"):
            values = metrics.get(key)
            if isinstance(values, list):
                sample_text = "%s=%d样本" % (key, len(values))
                break
        rows.append({
            "k": "%s · %s" % (case_id, label),
            "v": "%s · %s" % (verdict, actual),
            "sub": "metric=%s%s" % (metric, ("；" + sample_text) if sample_text else ""),
            "n": ("独立 trace: %s" % evidence_path) if evidence_path else "独立 trace 缺失（FAIL）",
        })
        evidence.append((case_id, evidence_path or "<missing trace>", note or actual))
    return rows, evidence


FRAMEWORK_TEMPLATE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "templates", "uds_report_framework.html")


def _replace_once(document, pattern, replacement):
    # 用 lambda 传 replacement：re.sub 的字符串 repl 会把反斜杠当正则转义，
    # Windows 路径（C:\\Users\\...）会触发 "bad escape \\U"。lambda 返回值按字面处理。
    return re.sub(pattern, lambda m: replacement, document, count=1, flags=re.S)


def _short_version(value):
    text = str(value or "当前版本")
    match = re.search(r"\bV\d+[\w.-]*\b", text, re.IGNORECASE)
    if match:
        return match.group(0)
    # 无独立版本令牌时，剥离项目配置声明的展示前缀（未移植项目时为参考档前缀）。
    for prefix in _VERSION_PREFIXES:
        if text.startswith(prefix):
            return text[len(prefix):]
    return text


def _module_definitions(data, total):
    raw = data.get("modules") or [
        {"id": "uds", "label": "UDS 诊断", "status": "executed", "count": total},
        {"id": "security", "label": "网络安全", "status": "planned", "count": 0},
    ]
    palette = [
        ("#2563eb", "#e8effd"), ("#be185d", "#fce7f0"),
        ("#7c5cd6", "#f0ebfb"), ("#4f46e5", "#ecebfb"),
        ("#0f9f8f", "#e5f4f2"),
    ]
    result = []
    used = set()
    for index, entry in enumerate(raw):
        if isinstance(entry, str):
            entry = {"id": entry, "label": entry}
        entry = entry if isinstance(entry, dict) else {}
        module_id = safe_id(entry.get("id") or entry.get("key") or entry.get("label"),
                            "module-%d" % index)
        if module_id in used:
            module_id = "%s-%d" % (module_id, index)
        used.add(module_id)
        color, bg = palette[index % len(palette)]
        result.append({
            "id": module_id,
            "label": str(entry.get("label") or entry.get("name") or module_id),
            "status": str(entry.get("status") or "planned").lower(),
            "count": entry.get("count", entry.get("total", 0)),
            "color": str(entry.get("color") or color),
            "bg": str(entry.get("bg") or bg),
            "description": str(entry.get("description") or entry.get("note") or ""),
            "summary": str(entry.get("summary") or ""),
        })
    return result or [{"id": "uds", "label": "UDS 诊断", "status": "executed",
                       "count": total, "color": "#2563eb", "bg": "#e8effd",
                       "description": "", "summary": ""}]


def _module_count_text(module):
    if module["status"] in ("planned", "planning", "pending", "not_run"):
        return "规划中"
    if module["status"] in ("blocked", "na"):
        return module["status"].upper()
    return "%s 条" % module["count"] if module["count"] not in (None, "") else "已记录"


def _state_chip(value):
    state = str(value or "NA").upper()
    known = {"PASS", "NA", "BLOCKED", "FAIL", "SKIP", "RETEST", "DEVIATION"}
    cls = state if state in known else "NA"
    inline = {
        "RETEST": " style=\"color:#7c5cd6;background:#f0ebfb\"",
        "DEVIATION": " style=\"color:#0f766e;background:#e5f4f2\"",
        "SKIP": " style=\"color:#2563eb;background:#e8effd\"",
    }.get(state, "")
    return '<span class="vchip %s"%s>%s</span>' % (cls, inline, esc(state))


def _status_summary(row):
    order = ("PASS", "FAIL", "RETEST", "DEVIATION", "NA", "BLOCKED", "SKIP")
    parts = []
    for state in order:
        count = int(row.get(state, 0) or 0)
        if count:
            parts.append("%s %s" % (state, count))
    return " / ".join(parts) or "无执行记录"


def _render_framework_html(data):
    """使用原始交付页的 DOM/CSS/脚本框架，只替换其数据内容。"""
    if not os.path.exists(FRAMEWORK_TEMPLATE):
        raise FileNotFoundError("报告框架模板不存在: %s" % FRAMEWORK_TEMPLATE)
    with open(FRAMEWORK_TEMPLATE, encoding="utf-8") as f:
        document = f.read()

    meta = data.get("meta", {})
    summary = data.get("summary", {})
    cases = data.get("cases_detail", [])
    # 报告渲染是最后一道防线：保留明确排除项的 SKIP；时序项的 SKIP
    # 表示没有完成采集，统一显示为 FAIL。
    for item in cases:
        item.update(_normalize_report_result(item))
    # 只要结果集中存在逐条 TimeParm，就以结果中的 1:1 case 证据重建时序区，
    # 覆盖外部 extra 里的旧版汇总，避免一行普通 P2 报告掩盖其它 14 条。
    timing_rows, evidence_rows = _timing_rows_from_cases(cases)
    if timing_rows:
        data["timing"] = timing_rows
        data["evidence"] = evidence_rows
    counts = Counter(str(item.get("verdict") or "FAIL").upper() for item in cases)
    failure_counts = Counter(str(item.get("failure_class") or "RESULT_INVALID").upper()
                             for item in cases)
    for key in ("PASS", "FAIL", "BLOCKED", "NA", "SKIP", "RETEST", "DEVIATION"):
        summary[key] = counts.get(key, 0)
    summary.pop("ERROR", None)
    summary["total"] = len(cases) or summary.get("total", 0)
    judged = summary.get("PASS", 0) + summary.get("FAIL", 0)
    summary["judged"] = judged
    summary["executed"] = summary.get("PASS", 0) + summary.get("FAIL", 0) + summary.get("NA", 0)
    summary["pass_rate"] = round(summary.get("PASS", 0) / judged * 100, 1) if judged else 0
    summary["failure_classes"] = dict(failure_counts)
    summary["ecu_fail"] = failure_counts.get("ECU_FAIL", 0)
    summary["ecu_judged"] = summary.get("PASS", 0) + summary["ecu_fail"]
    total = summary.get("total", len(cases))
    version = str(meta.get("version") or meta.get("software_version") or "当前软件版本")
    short_version = _short_version(version)
    report_id = safe_id(short_version, "current")
    test_time = str(meta.get("test_time") or meta.get("run_time") or "测试时间待录入")
    title = str(meta.get("title") or "UDS 诊断测试日志统计平台")
    project = str(meta.get("project") or meta.get("meta1") or title)
    client_product = str(meta.get("client_product") or meta.get("meta2") or "测试参数待录入")
    transport = str(meta.get("transport") or meta.get("meta2") or "测试链路待录入")
    modules = _module_definitions(data, total)
    module_labels = " / ".join(m["label"] for m in modules)
    main_module = next((m for m in modules if m["id"] == "uds"), modules[0])

    topbar = ('<header class="topbar"><div class="brand"><span class="mark">U</span>'
              '<span class="pt">UDS 诊断测试日志统计平台</span></div><div class="meta">'
              '项目 <b>%s</b> · 版本 <b>%s</b><br>测试时间 %s</div></header>'
              % (esc(project), esc(short_version), esc(test_time)))
    hero = ('<section class="hero"><h1>%s</h1><p class="sub">%s</p>'
            '<div class="meta-grid"><div class="mcell"><div class="k">软件版本</div>'
            '<div class="v blue num">%s</div></div><div class="mcell"><div class="k">测试报告数</div>'
            '<div class="v teal num">1 份</div></div><div class="mcell"><div class="k">客户 / 产品</div>'
            '<div class="v">%s</div></div><div class="mcell"><div class="k">测试模块</div>'
            '<div class="v rose">%s</div></div></div><div class="typebar">%s</div></section>'
            % (esc(title), esc(meta.get("sub") or "时间轴按软件版本切换，版本内按测试模块分块。"),
               esc(short_version), esc(client_product), esc(module_labels), "".join(
                   '<span class="typetag" style="background:%s">%s</span>' % (m["color"], esc(m["label"]))
                   for m in modules)))

    versions = data.get("versions") or [{
        "version": short_version, "test_time": test_time, "modules": [m["label"] for m in modules],
        "summary": "%s 条 · %s FAIL" % (total, summary.get("FAIL", 0)), "active": True,
    }]
    nodes = []
    for index, item in enumerate(versions):
        item_version = _short_version(item.get("version") or item.get("name") or short_version)
        item_id = safe_id(item_version, "version-%d" % index)
        active = bool(item.get("active", item_version == short_version))
        item_time = str(item.get("test_time") or item.get("date") or test_time)
        item_modules = item.get("modules") or [m["label"] for m in modules]
        item_summary = str(item.get("summary") or ("%s 条 · %s FAIL" % (total, summary.get("FAIL", 0))))
        item_color = str(item.get("color") or (main_module["color"] if active else "#94a3b8"))
        item_bg = str(item.get("bg") or (main_module["bg"] if active else "#f1f5f9"))
        report_url = item.get("report_url")
        action = ("window.location.href='%s'" % esc_attr(report_url)
                  if report_url and not active else "goRpt('%s')" % esc_attr(item_id))
        cls = "tnode active" if active else "tnode"
        nodes.append(
            '<button class="%s" data-id="%s" style="--tcol:%s;--tbg:%s" onclick="%s">'
            '<div class="tstem"><span class="tdot"></span></div><div class="tcard">'
            '<div class="ttime num">%s</div><span class="ttag">%s</span><div class="tmods">%s</div>'
            '<div class="tsum num">%s</div></div></button>'
            % (cls, esc_attr(item_id), esc_attr(item_color), esc_attr(item_bg), action,
               esc(item_time), esc(item_version), "".join(
                   '<span class="tmod" style="background:%s">%s</span>' % (
                       m["color"], esc(m["label"])) for m in modules if m["label"] in item_modules),
               esc(item_summary)))
    timeline = ('<nav class="tnav" id="tnav"><div class="cap"><span class="timeline-title">'
                '软件版本测试时间轴</span><span class="timeline-note">按测试时间排序，点击版本卡切换报告'
                '</span></div><div class="ttrack"><div class="taxis"></div><div class="tnodes">%s'
                '</div></div></nav>' % "".join(nodes))

    def kpi(cls, value, label, style="", status=None):
        # KPI 卡片可点击：onclick 调用 kpiFilter(status) 复用现有 fbtn 过滤；
        # status 用于 data-status（fbtn 的 data-v 也是大写 status 字串），缺省回退 cls 去前缀 k-
        s = status or cls[len("k-"):] if cls.startswith("k-") else cls.upper()
        return ('<div class="kpi %s" data-status="%s" onclick="kpiFilter(\'%s\')" tabindex="0" role="button"'
                ' aria-label="%s（%s）" style="cursor:pointer;%s"><div class="num">%s</div>'
                '<div class="lbl">%s</div></div>') % (
            cls, s, s, esc(label), value, style.lstrip(";") + (";" if style else ""), esc(value), esc(label))

    kpis = (kpi("k-pass", summary.get("PASS", 0), "PASS 正例符合预期", status="PASS")
            + kpi("k-na", summary.get("NA", 0), "NA 条件受限", status="NA")
            + kpi("k-blocked", summary.get("BLOCKED", 0), "BLOCKED 前置未满足", status="BLOCKED")
            + kpi("k-fail", summary.get("FAIL", 0), "FAIL 实测不符", status="FAIL")
            + kpi("k-skipped", summary.get("SKIP", 0), "SKIP 本批排除/待测量", status="SKIP")
            + kpi("k-retest", summary.get("RETEST", 0), "RETEST 修复后复测",
                 '--kc:#7c5cd6', status="RETEST")
            + kpi("k-deviation", summary.get("DEVIATION", 0), "DEVIATION 版本数据偏差",
                 '--kc:#0f766e', status="DEVIATION")
            + kpi("k-all", summary.get("total", 140), "全部 用例", '--kc:#1f2a4d', status="ALL"))

    coverage = data.get("coverage", {}).get("rows", [])
    coverage_html = "".join(
        '<div class="cov"><div class="k">%s</div><div class="r"><div class="track">'
        '<div class="fill" style="width:%s%%"></div></div><div class="v num">%s</div></div></div>'
        % (esc(row.get("k", "")), max(0, min(100, float(row.get("pct", 0) or 0))),
           esc(row.get("v", ""))) for row in coverage)
    if not coverage_html:
        coverage_html = '<div class="sec-empty">无覆盖率数据</div>'

    timing_html = "".join(
        '<div class="tm"><div class="k">%s</div><div class="v num">%s</div><div class="sub">%s</div>'
        '<div class="n">%s</div></div>'
        % (esc(row.get("k", "")), esc(row.get("v", "")), esc(row.get("sub", "")), esc(row.get("n", "")))
        for row in data.get("timing", [])) or '<div class="sec-empty">无独立时序测量数据</div>'

    blocked_html = "".join(
        '<tr><td>%s</td><td class="count num">%s</td><td class="mono">%s</td><td>%s</td><td class="sol">%s</td></tr>'
        % (esc(row.get("t", row.get("category", ""))), esc(row.get("count", "未单独统计")),
           esc(row.get("affected", "未提供")), esc(row.get("reason", row.get("d", ""))),
           esc(row.get("solution", "满足前置条件后按新脚本复测")))
        for row in data.get("blocked", []))
    if not blocked_html:
        blocked_html = '<tr><td colspan="5">无受限项，当前前置条件均已满足</td></tr>'

    params = data.get("parameters", [])
    if not params:
        params = [
            {"k": "测试链路", "v": transport},
            {"k": "报告范围", "v": " / ".join(m["label"] for m in modules)},
            {"k": "执行统计", "v": "%s 条用例，%s 条已执行" % (total, summary.get("executed", 0))},
            {"k": "判定统计", "v": "%s 条可直接判定，协议通过率 %s%%" % (
                summary.get("judged", 0), summary.get("pass_rate", 0))},
        ]
    parameter_html = "".join(
        '<div class="row"><div class="k">%s</div><div class="v">%s</div></div>' %
        (esc(row.get("k", "")), esc(row.get("v", ""))) for row in params)

    service_html = "".join(
        '<div class="cell" style="--sc:%s"><b>%s</b><span class="num">%s 条</span><span>%s</span></div>' %
        ("#b91c1c" if row.get("FAIL", 0) else "#d97706" if row.get("BLOCKED", 0) or row.get("RETEST", 0)
         else "#059669" if row.get("PASS", 0) else "#94a3b8", esc(row.get("name", "")),
         row.get("total", 0), esc(_status_summary(row))) for row in data.get("services", []))
    if not service_html:
        service_html = '<div class="sec-empty">无服务执行记录</div>'

    detail_rows = []
    for item in cases:
        state = str(item.get("verdict") or "FAIL").upper()
        note_parts = []
        if item.get("session"):
            note_parts.append("会话: %s" % item.get("session"))
        actual = item.get("actual") or item.get("payload_text")
        if actual:
            note_parts.append("实测: %s" % actual)
        if item.get("note"):
            note_parts.append(str(item.get("note")))
        failure_annotation = _failure_annotation(item)
        if failure_annotation:
            note_parts.insert(0, failure_annotation)
        detail_rows.append(
            '<tr data-v="%s"><td class="mono">%s</td><td class="mono">%s</td><td>%s</td>'
            '<td>%s</td><td class="sol">%s</td></tr>' %
            (esc_attr(state), esc(item.get("case_id", "")), esc(item.get("service", "")),
             esc(item.get("desc", "")), _state_chip(state), esc("；".join(note_parts))))
    details_html = "".join(detail_rows) or '<tr><td colspan="5">无用例明细</td></tr>'
    filters = "".join(
        '<button class="fbtn" data-v="%s" aria-pressed="%s">%s</button>' %
        (state, "true" if index == 0 else "false", label)
        for index, (state, label) in enumerate((
            ("ALL", "全部 %s" % total), ("PASS", "PASS %s" % summary.get("PASS", 0)),
            ("RETEST", "RETEST %s" % summary.get("RETEST", 0)),
            ("DEVIATION", "DEVIATION %s" % summary.get("DEVIATION", 0)),
            ("BLOCKED", "BLOCKED %s" % summary.get("BLOCKED", 0)),
            ("NA", "NA %s" % summary.get("NA", 0)), ("SKIP", "SKIP %s" % summary.get("SKIP", 0)),
            ("FAIL", "FAIL %s" % summary.get("FAIL", 0)),
        )))

    report_module_chips = "".join(
        '<span class="mod-chip" style="--mc:%s;--mbg:%s">%s</span>' %
        (m["color"], m["bg"], esc(m["label"])) for m in modules)
    report_tabs = "".join(
        '<button class="module-tab" type="button" role="tab" aria-selected="%s" '
        'aria-controls="module-%s-%s" data-module="%s" style="--mc:%s;--mbg:%s">%s '
        '<span class="module-count">%s</span></button>' %
        ("true" if m["id"] == main_module["id"] else "false", report_id, m["id"], m["id"],
         m["color"], m["bg"], esc(m["label"]), esc(_module_count_text(m))) for m in modules)

    uds_panel = (
        '<div class="mod-block module-panel" id="module-%s-uds" role="tabpanel" data-module-panel="uds">'
        '<div class="mod-head" style="--mc:%s;--mbg:%s"><span class="mod-badge">%s</span>'
        '<span class="mod-sub">%s</span></div><section class="kpis">%s</section><section class="grid">'
        '<article class="card c-cov"><h2>覆盖率</h2>%s</article><article class="card c-tm"><h2>时序实测</h2>%s</article>'
        '<article class="card c-blk span"><h2>阻塞清单</h2><table><thead><tr><th>类别</th><th>数量</th>'
        '<th>受影响用例</th><th>原因</th><th>解除路径</th></tr></thead><tbody>%s</tbody></table></article>'
        '<article class="card c-par span"><h2>关键参数</h2><div class="par">%s</div></article></section>'
        '<article class="card c-svc" style="margin-bottom:16px"><h2>服务分布</h2><div class="svc">%s</div></article>'
        '<article class="card"><h2>用例明细</h2><div class="toolbar">%s<input class="search" type="search" placeholder="搜索 用例ID / 服务 / 描述"></div>'
        '<div class="tbl-wrap"><table><thead><tr><th>用例 ID</th><th>服务</th><th>测试点</th><th>状态</th><th>说明</th></tr></thead>'
        '<tbody>%s</tbody></table></div><div class="legend"><b>状态口径</b>%s</div></article></div>'
        % (report_id, main_module["color"], main_module["bg"], esc(main_module["label"]),
           esc(meta.get("execution_note") or "真实执行结果与范围限制见下方数据"), kpis, coverage_html, timing_html,
           blocked_html, parameter_html, service_html, filters, details_html, "".join(
               '<span><span class="vchip %s" style="margin-right:4px">%s</span>%s</span>' %
                (("NA" if str(row.get("k", "")).upper() not in {"PASS", "NA", "BLOCKED", "SKIP", "FAIL", "RETEST", "DEVIATION"}
                 else str(row.get("k", "")).upper()), esc(row.get("k", "")), esc(row.get("v", "")))
               for row in data.get("legend", []))))

    def other_panel(module):
        hidden = "" if module["id"] == main_module["id"] else " hidden"
        if module["id"] == "security":
            return ('<div class="mod-block module-panel" id="module-%s-%s" role="tabpanel" '
                    'data-module-panel="%s"%s><div class="mod-head" style="--mc:%s;--mbg:%s">'
                    '<span class="mod-badge">%s</span><span class="mod-sub">规划占位（ISO/SAE 21434 + UN-R155）</span></div>'
                    '<div class="sec-banner"><span class="b1">规划占位</span><span class="b2">本节为网络安全测试预留结构，数据待录入。</span></div>'
                    '<section class="sec-kpis"><div class="skpi"><div class="num">…</div><div class="lbl">入口点（attack surface）</div></div>'
                    '<div class="skpi"><div class="num">…</div><div class="lbl">拦截率（blocked rate）</div></div>'
                    '<div class="skpi"><div class="num">…</div><div class="lbl">高危漏洞（critical）</div></div>'
                    '<div class="skpi"><div class="num">…</div><div class="lbl">测试场景（scenarios）</div></div></section>'
                    '<section class="grid"><article class="card c-sec-as"><h2>攻击面覆盖</h2><div class="sec-grid2">'
                    '<div class="item"><div class="k">诊断服务入口</div><div class="v">UDS over CAN/CAN FD 攻击面，待按项目范围录入</div></div>'
                    '<div class="item"><div class="k">物理接口</div><div class="v">CAN / CAN FD / Ethernet / USB / 调试口，待确认</div></div>'
                    '<div class="item"><div class="k">无线接口</div><div class="v">Wi-Fi / 蓝牙 / 蜂窝 / OTA，待确认</div></div>'
                    '<div class="item"><div class="k">车内网络</div><div class="v">网关、SecOC / TLS 等保护面，待确认</div></div>'
                    '<div class="item"><div class="k">ECU 固件</div><div class="v">bootloader / APP / 升级链路，待确认</div></div>'
                    '<div class="item"><div class="k">数据资产</div><div class="v">密钥 / 证书 / 调试凭据 / 日志，待确认</div></div></div></article>'
                    '<article class="card c-sec-pt"><h2>渗透测试结果</h2><div class="sec-empty">渗透结果待录入</div></article>'
                    '<article class="card c-sec-vul span"><h2>漏洞 / 风险清单</h2><div class="sec-empty">风险项待录入，当前没有网络安全实测结论</div></article>'
                    '<article class="card c-sec-mit span"><h2>缓解措施</h2><div class="sec-empty">缓解措施待录入</div></article></section>'
                    '<article class="card c-sec-cs"><h2>测试场景明细</h2><div class="sec-empty">测试场景待录入</div></article></div>'
                    % (report_id, module["id"], module["id"], hidden, module["color"], module["bg"], esc(module["label"])))
        return ('<div class="mod-block module-panel" id="module-%s-%s" role="tabpanel" data-module-panel="%s"%s>'
                '<div class="mod-head" style="--mc:%s;--mbg:%s"><span class="mod-badge">%s</span>'
                '<span class="mod-sub">规划占位</span></div><article class="card"><h2>%s</h2>'
                '<div class="sec-empty">%s</div></article></div>'
                % (report_id, module["id"], module["id"], hidden, module["color"], module["bg"],
                   esc(module["label"]), esc(module["label"]), esc(module["description"] or "后续测试模块待录入")))

    module_panels = uds_panel + "".join(other_panel(m) for m in modules if m["id"] != "uds")
    report_block = (
        '<section class="report-block" id="rpt-%s" style="--rc:%s"><header class="report-head">'
        '<span class="ver-badge">%s</span><div><h2>%s</h2><p>测试时间 %s ｜ 共 %s 个测试模块 ｜ %s</p></div>'
        '<div class="meta2">%s</div><button class="back" onclick="goTop()">回到顶部</button></header>'
        '<nav class="module-nav" data-report="%s" role="tablist" aria-label="%s 测试报告模块">'
        '<span class="module-nav-label">测试模块</span>%s</nav>%s</section>'
        % (report_id, main_module["color"], esc(short_version), esc(title), esc(test_time), len(modules),
           esc(transport), report_module_chips, report_id, esc(short_version), report_tabs, module_panels))

    footer = ('<footer><span>%s</span><span>生成于 %s</span></footer>' %
              (esc(meta.get("source") or "执行结果 JSON + 附加报告数据"), esc(meta.get("generated") or test_time)))

    document = _replace_once(document, r"<title>.*?</title>",
                             "<title>%s · %s</title>" % (esc(title), esc(short_version)))
    document = _replace_once(document, r"<header class=\"topbar\">.*?</header>", topbar)
    document = _replace_once(document, r"<section class=\"hero\">.*?</section>", hero)
    document = _replace_once(document, r"<nav class=\"tnav\" id=\"tnav\">.*?</nav>", timeline)
    document = _replace_once(document, r"<main>.*?</main>", "<main>%s</main>" % report_block)
    document = _replace_once(document, r"<footer>.*?</footer>", footer)
    document = _replace_once(document, r"<script>.*?</script>", "<script>" + PAGE_JS_FRAMEWORK + "</script>")
    return document


PAGE_JS_FRAMEWORK = r"""
function kpiFilter(status){
  if (!status) return;
  // KPI 卡片点击：复用 fbtn 过滤（data-v 与 KPI data-status 同字串）
  var btns = document.querySelectorAll('.fbtn[data-v="' + status + '"]');
  for (var i = 0; i < btns.length; i++) { btns[i].click(); }
  // 视觉高亮：当前 KPI 加 active，其他移除
  var kpis = document.querySelectorAll('.kpi[data-status]');
  for (var j = 0; j < kpis.length; j++) {
    if (kpis[j].getAttribute('data-status') === status) kpis[j].classList.add('kpi-active');
    else kpis[j].classList.remove('kpi-active');
  }
  // 滚动到用例明细表
  var first = document.querySelector('.report-block .tbl-wrap, .report-block tbody');
  if (first) {
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    first.scrollIntoView({behavior: reduce ? 'auto' : 'smooth', block: 'start'});
  }
}
function goRpt(id){
  var el = document.getElementById('rpt-' + id);
  if (!el) return;
  setModule(id, 'uds', false);
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  el.scrollIntoView({behavior: reduce ? 'auto' : 'smooth', block: 'start'});
  if (!reduce) { el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); }
}
function setModule(reportId, moduleId, shouldScroll){
  var report = document.getElementById('rpt-' + reportId);
  if (!report) return;
  var tabs = report.querySelectorAll('.module-tab');
  var panels = report.querySelectorAll('.module-panel');
  tabs.forEach(function(tab){
    var selected = tab.getAttribute('data-module') === moduleId;
    tab.setAttribute('aria-selected', selected ? 'true' : 'false');
    tab.tabIndex = selected ? 0 : -1;
  });
  panels.forEach(function(panel){ panel.hidden = panel.getAttribute('data-module-panel') !== moduleId; });
  if (shouldScroll) {
    var panel = report.querySelector('[data-module-panel="' + moduleId + '"]');
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (panel) panel.scrollIntoView({behavior: reduce ? 'auto' : 'smooth', block: 'start'});
  }
}
function goTop(){
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  window.scrollTo({top: 0, behavior: reduce ? 'auto' : 'smooth'});
}
document.querySelectorAll('.report-block').forEach(function(block){
  var tbody = block.querySelector('tbody');
  if (!tbody) return;
  var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr[data-v]'));
  var btns = block.querySelectorAll('.fbtn');
  var search = block.querySelector('.search');
  function apply(){
    var on = block.querySelector('.fbtn[aria-pressed="true"]');
    var v = on ? on.getAttribute('data-v') : 'ALL';
    var q = (search.value || '').toLowerCase();
    rows.forEach(function(r){
      var hit = r.textContent.toLowerCase().indexOf(q) !== -1;
      r.hidden = !(hit && (v === 'ALL' || r.getAttribute('data-v') === v));
    });
  }
  btns.forEach(function(b){ b.addEventListener('click', function(){
    btns.forEach(function(x){ x.setAttribute('aria-pressed', 'false'); });
    b.setAttribute('aria-pressed', 'true'); apply();
  }); });
  if (search) search.addEventListener('input', apply);
});
document.querySelectorAll('.module-nav').forEach(function(nav){
  var initialTab = nav.querySelector('.module-tab[aria-selected="true"]') || nav.querySelector('.module-tab');
  if (initialTab) setModule(nav.getAttribute('data-report'), initialTab.getAttribute('data-module'), false);
  nav.addEventListener('click', function(e){
    var tab = e.target.closest('.module-tab');
    if (tab) setModule(nav.getAttribute('data-report'), tab.getAttribute('data-module'), true);
  });
  nav.addEventListener('keydown', function(e){
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    var tabs = Array.prototype.slice.call(nav.querySelectorAll('.module-tab'));
    var current = tabs.indexOf(document.activeElement); if (current < 0) return;
    e.preventDefault();
    var next = (current + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
    tabs[next].focus(); setModule(nav.getAttribute('data-report'), tabs[next].getAttribute('data-module'), true);
  });
});
"""


def main():
    ap = argparse.ArgumentParser(description="UDS 测试报告 → 单文件 HTML 页面")
    ap.add_argument("--results", "-r", help="执行结果 JSON（results[] 含 verdict）")
    ap.add_argument("--extra", "-e", help="附加报告数据 JSON（meta/versions/modules/links/evidence/blocked/timing/coverage/mapping/legend）")
    ap.add_argument("--swdl-report", help="SWDL 执行报告 JSON；自动转换为统一报告输入")
    ap.add_argument("--out", "-o", default="uds_report.html", help="输出 HTML 路径")
    ap.add_argument("--project-config", default="", help="项目配置 JSON（可选）；决定短版本号展示前缀")
    args = ap.parse_args()

    global _VERSION_PREFIXES
    _VERSION_PREFIXES = _resolve_version_prefixes(args.project_config or None)

    input_results = args.swdl_report or args.results
    if not input_results:
        ap.error("必须提供 --results 或 --swdl-report")
    if not os.path.exists(input_results):
        print(f"[ERROR] 结果文件不存在: {input_results}")
        sys.exit(1)
    if args.swdl_report:
        with open(args.swdl_report, encoding="utf-8") as f:
            swdl_report = json.load(f)
        converted = swdl_report_to_results(swdl_report)
        data = load_results_from_data(converted["results"])
        for k, v in converted["extra"].items():
            data[k] = v
    else:
        data = load_results(args.results)
    if args.extra and os.path.exists(args.extra):
        with open(args.extra, encoding="utf-8") as f:
            extra = json.load(f)
        for k, v in extra.items():
            data[k] = v
    html = _render_framework_html(data)
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"RESULT ok=True CASES={data['summary']['executed']} OUT={args.out}")


if __name__ == "__main__":
    main()
