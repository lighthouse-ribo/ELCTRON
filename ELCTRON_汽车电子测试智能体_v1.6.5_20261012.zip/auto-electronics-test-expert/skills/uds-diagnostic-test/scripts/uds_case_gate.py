#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UDS 用例生成前的统一语义门禁。

该模块是 ``PartitionModel`` 和用例生成器之间的唯一语义决策层。它只检查
用例设计是否与诊断资料一致，不访问硬件，也不负责脚本编译。生成器可以在
兼容模式下记录门禁结果，或在 strict 模式下拒绝有问题的用例。

职责边界：
* PartitionModel：提供 DID/分区/会话/读写/矩阵事实；
* 本模块：把事实应用到单条 UDS 用例并输出 GateDecision；
* gen_case_scripts：把决策编译为脚本和 manifest；
* script_review：只检查生成后是否发生漂移。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
import re
import sys
from typing import Any, Mapping, Sequence

from partition_model import MatrixExpectation, PartitionModel, infer_case_partition, normalize_did, normalize_partition
from session_flow import (
    allowed_transition,
    normalize_session,
    parse_session_target,
)

_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))
from project_config import load_project_config, parse_int  # noqa: E402


DECISIONS = {"GENERATE", "NEGATIVE", "BLOCKED", "REVIEW_REQUIRED", "REJECT"}
SEVERITIES = {"ERROR", "BLOCKED", "REVIEW_REQUIRED", "INFO"}

# Compatibility export for older callers. The gate itself always reads the
# project configuration and never uses this snapshot for decisions.
from project_config import DEFAULT_PROJECT_CONFIG  # noqa: E402

SA_SESSION_MAP = {
    parse_int(level): str(DEFAULT_PROJECT_CONFIG["sessions"]["names"].get(
        parse_int(sessions[0]), f"0x{parse_int(sessions[0], 0):02X}"
    ))
    for level, sessions in DEFAULT_PROJECT_CONFIG["security"]["level_to_sessions"].items()
    if sessions
}
UNLOCK_REQUIRED_SERVICES = frozenset(
    DEFAULT_PROJECT_CONFIG["security"]["unlock_required_services"]
)


@dataclass(frozen=True)
class GateFinding:
    code: str
    severity: str
    message: str
    source: str = ""

    def __post_init__(self) -> None:
        if self.severity not in SEVERITIES:
            raise ValueError(f"未知门禁严重级别: {self.severity}")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class GateDecision:
    case_id: str
    decision: str
    service: str
    did: str | None = None
    rid: str | None = None
    session: str | None = None
    target_partition: str | None = None
    expected_nrc: tuple[int, ...] = ()
    allowed_nrc: tuple[int, ...] = ()
    findings: tuple[GateFinding, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if self.decision not in DECISIONS:
            raise ValueError(f"未知门禁决策: {self.decision}")

    @property
    def blocking(self) -> bool:
        return self.decision in {"REJECT", "REVIEW_REQUIRED", "BLOCKED"}

    @property
    def reason(self) -> str:
        return "；".join(f.message for f in self.findings if f.severity != "INFO")

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["expected_nrc"] = list(self.expected_nrc)
        data["allowed_nrc"] = list(self.allowed_nrc)
        data["findings"] = [finding.to_dict() for finding in self.findings]
        data["blocking"] = self.blocking
        data["reason"] = self.reason
        return data


def _service(value: Any, payload: Sequence[int] | None = None) -> str:
    if payload:
        return f"0x{int(payload[0]) & 0xFF:02X}"
    raw = str(value or "").strip().upper()
    match = re.search(r"(?:0X)?([0-9A-F]{2})", raw)
    return f"0x{match.group(1)}" if match else raw


def _identifiers(payload: Sequence[int] | None) -> tuple[str | None, str | None]:
    if not payload:
        return None, None
    sid = int(payload[0]) & 0xFF
    if sid in (0x22, 0x2E) and len(payload) >= 3:
        return f"{payload[1]:02X}{payload[2]:02X}", None
    if sid == 0x31 and len(payload) >= 4:
        return None, f"{payload[2]:02X}{payload[3]:02X}"
    return None, None


def extract_expected_nrcs(expected: Any) -> tuple[int, ...]:
    """从 expected 中提取显式 NRC，避免把普通数据字节当作 NRC。"""

    text = str(expected or "")
    values: set[int] = set()
    for match in re.finditer(r"NRC\s*(?:=|:)?\s*0?x?([0-9A-Fa-f]{2})", text, re.I):
        values.add(int(match.group(1), 16))
    for match in re.finditer(r"7F\s+[0-9A-Fa-f]{2}\s+([0-9A-Fa-f]{2})", text, re.I):
        values.add(int(match.group(1), 16))
    return tuple(sorted(values))


def _is_negative(
    case: Mapping[str, Any],
    expectation: str,
    project_config: Mapping[str, Any] | str | None = None,
) -> bool:
    if expectation in {"neg", "negative"}:
        return True
    text = " ".join(str(case.get(key, "") or "") for key in ("test_point", "expected"))
    config = load_project_config(project_config)
    keywords = config.get("lint", {}).get("negative_keywords", ())
    return any(str(token) and str(token) in text for token in keywords)


def _is_positive(
    case: Mapping[str, Any],
    expectation: str,
    project_config: Mapping[str, Any] | str | None = None,
) -> bool:
    if expectation in {"pos", "positive"}:
        return True
    text = " ".join(str(case.get(key, "") or "") for key in ("test_point", "expected"))
    return any(token in text for token in ("正向", "正响应", "正常响应", "数据完整")) and not _is_negative(
        case, expectation, project_config
    )


def _session_declared(
    case: Mapping[str, Any],
    project_config: Mapping[str, Any] | str | None = None,
) -> bool:
    text = " ".join(str(case.get(key, "") or "") for key in ("precondition", "procedure", "test_point"))
    lowered = text.lower()
    if "会话" in text or "session" in lowered:
        return True
    config = load_project_config(project_config)
    names = config.get("sessions", {}).get("names", {})
    supported = config.get("sessions", {}).get("supported", [])
    labels = {
        str(names.get(session_id, "")).strip().lower()
        for session_id in supported
        if str(names.get(session_id, "")).strip()
    }
    labels.update({f"0x{int(session_id):02x}" for session_id in supported})
    labels.update({f"{int(session_id):02x}" for session_id in supported})
    return any(label in lowered for label in labels)


def _requires_unlock(
    case: Mapping[str, Any],
    service: str,
    *,
    positive: bool,
    payload: Sequence[int] | None = None,
    project_config: Mapping[str, Any] | str | None = None,
) -> bool:
    if not positive:
        return False
    if service == "0x27":
        # 奇数子功能请求 Seed，不需要真实 Key；偶数子功能发送 Key，才
        # 依赖客户授权密钥。这个区别必须在门禁层统一处理。
        return bool(payload and len(payload) >= 2 and int(payload[1]) % 2 == 0)
    config = load_project_config(project_config)
    protected_services = set(config.get("security", {}).get("unlock_required_services", ()))
    if service in protected_services:
        # This is a service-level rule, not a free-text marker. Negative
        # cases return earlier and can intentionally test the locked ECU.
        return True
    return False


def _matrix_available(model: PartitionModel) -> bool:
    return model.matrix_loaded or any(
        expectation.defined
        for spec in model.dids.values()
        for expectation in spec.matrix.values()
    )


def _append_session_transition_findings(
    findings: list[GateFinding],
    *,
    case: Mapping[str, Any],
    payload: Sequence[int] | None,
    source_session: str | None,
    expected_nrc: tuple[int, ...],
    negative: bool,
    project_config: Mapping[str, Any] | str | None = None,
) -> None:
    """校验项目约束下的 0x10 源会话→目标会话语义。"""
    config = load_project_config(project_config)
    if not config["sessions"].get("enforce_transition_matrix", True):
        return
    target = parse_session_target(payload, config)
    source = normalize_session(source_session, config)
    if target is None:
        return
    if source is None:
        findings.append(GateFinding(
            "SESSION-TRANS-003", "REVIEW_REQUIRED",
            "0x10 会话切换未明确源会话，无法应用项目跳转矩阵",
            "项目会话跳转矩阵",
        ))
        return
    allowed = allowed_transition(source, target, config)
    # load_project_config always normalizes this field. Do not fall back to
    # the legacy session_flow constant: custom projects must be authoritative.
    transition_nrc = int(config["sessions"]["transition_nrc"])
    if allowed is False:
        if not negative or transition_nrc not in expected_nrc:
            findings.append(GateFinding(
                "SESSION-TRANS-001", "ERROR",
                "禁止的会话跳转 0x%02X→0x%02X 必须设计为负例并期望 NRC 0x%02X"
                % (source, target, transition_nrc),
                "项目会话跳转矩阵",
            ))
    elif negative and transition_nrc in expected_nrc:
        findings.append(GateFinding(
            "SESSION-TRANS-002", "ERROR",
            "允许的会话跳转 0x%02X→0x%02X 不应声明 NRC 0x%02X 负例"
            % (source, target, transition_nrc),
            "项目会话跳转矩阵",
        ))


def _append_partition_findings(
    findings: list[GateFinding],
    *,
    case: Mapping[str, Any],
    model: PartitionModel,
    did: str | None,
    target: str | None,
    service: str,
    session: str | None,
    expected_nrc: tuple[int, ...],
    positive: bool,
    negative: bool,
) -> None:
    if service not in {"0x22", "0x2E"}:
        return
    # 读写属性是 DID 本身的全局约束，即使当前没有加载分区矩阵，也应
    # 先阻止明显的 0x22/0x2E 方向错误。
    generic_spec = model.lookup(did) if did else None
    if positive and generic_spec and not generic_spec.attributes_provisional:
        rw = str(generic_spec.rw_state or "").strip().upper()
        if service == "0x22" and rw == "W":
            findings.append(GateFinding("RW-001", "ERROR", f"DID {did} 为只写，不能生成 0x22 正向读取", "诊断库 DID 属性"))
        if service == "0x2E" and rw == "R":
            findings.append(GateFinding("RW-002", "ERROR", f"DID {did} 为只读，不能生成 0x2E 正向写入", "诊断库 DID 属性"))
    if not _matrix_available(model):
        return

    # A DID present in the survey but empty in every layer is not a valid
    # positive object. This check intentionally happens before the target
    # partition check so an unqualified F190 request is rejected as an
    # undefined DID, rather than downgraded to an ambiguous APP review item.
    if positive and not target and generic_spec and all(
        not item.defined for item in generic_spec.matrix.values()
    ):
        findings.append(GateFinding(
            "DID-003", "ERROR",
            f"DID {did} 在 APP/PBL/SBL 矩阵中均未定义，不能生成正向 {service} 用例",
            "DID检查矩阵",
        ))
        return

    if positive and generic_spec is None:
        findings.append(GateFinding(
            "DID-001", "ERROR", f"DID {did or '?'} 不在诊断模型中，不能生成正向用例",
            "PartitionModel",
        ))
        return

    if not target:
        if positive:
            findings.append(GateFinding(
                "PART-001", "REVIEW_REQUIRED",
                "正向 DID 用例未明确目标分区，禁止隐式按 APP 判断",
                "PartitionModel",
            ))
        else:
            findings.append(GateFinding(
                "PART-INFO", "INFO", "目标分区未明确，本条仅保留为非正向用例",
                "PartitionModel",
            ))
        return
    spec = model.lookup(did, target) if did else None
    if spec is None:
        if positive:
            findings.append(GateFinding(
                "DID-001", "ERROR", f"DID {did or '?'} 不在诊断模型中，不能生成正向用例",
                "PartitionModel",
            ))
        return
    expectation = spec.for_partition(target)
    if expectation is None or not expectation.defined:
        if positive:
            findings.append(GateFinding(
                "PART-002", "ERROR", f"DID {did} 未在目标分区 {target} 定义",
                "DID检查矩阵",
            ))
        return
    if expectation.kind == "negative":
        if positive:
            findings.append(GateFinding(
                "PART-003", "ERROR",
                f"DID {did} 在目标分区 {target} 的矩阵期望为负响应，不能生成正向用例",
                "DID检查矩阵",
            ))
        elif negative and expectation.expected_nrc and not set(expected_nrc).intersection(expectation.expected_nrc):
            findings.append(GateFinding(
                "NRC-001", "ERROR",
                f"DID {did} 的负例期望 NRC {list(expected_nrc) or ['未填写']} 与分区矩阵 {list(expectation.expected_nrc)} 不一致",
                "DID检查矩阵",
            ))
    elif negative and service == "0x22" and 0x31 in expected_nrc:
        # NRC 0x31 is the requestOutOfRange path for an unsupported DID.  A
        # negative case cannot force that expectation when the selected layer
        # explicitly defines the DID as readable; this was the root of the
        # D09B/PBL false-fail design.  Session/security negatives must model
        # their own precondition and NRC instead of contradicting the matrix.
        findings.append(GateFinding(
            "MATRIX-NEG-001", "ERROR",
            f"DID {did} 在目标分区 {target} 已由矩阵定义为可读，不能将 0x31 作为“不支持读取”期望",
            "DID检查矩阵",
        ))
    if positive:
        allowed = spec.session_allowed(session, write=service == "0x2E")
        if allowed is False:
            findings.append(GateFinding(
                "SESSION-001", "ERROR",
                f"DID {did} 在 {target} 不允许 {session or '未知'} 会话执行正向 {service}",
                "诊断库 DID 属性",
            ))


def evaluate_case(
    case: Mapping[str, Any],
    *,
    payload: Sequence[int] | None,
    model: PartitionModel,
    service: str = "",
    expectation: str = "",
    expected_nrc: Sequence[int] | None = None,
    session: str | None = None,
    target_partition: str | None = None,
    key_ready: bool = False,
    project_config: Mapping[str, Any] | str | None = None,
) -> GateDecision:
    """评估单条用例；不访问硬件、不写文件。"""

    config = load_project_config(project_config)
    cid = str(case.get("case_id", "?"))
    svc = _service(service, payload)
    did, rid = _identifiers(payload)
    target = normalize_partition(target_partition) or infer_case_partition(case)
    expected = tuple(sorted({int(value) for value in (expected_nrc or ())}))
    if not expected:
        expected = extract_expected_nrcs(case.get("expected"))
    negative = _is_negative(case, expectation, config)
    timing_did = str(expectation or "").lower() == "timing" and svc in {"0x22", "0x2E"}
    positive = _is_positive(case, expectation, config) or timing_did
    findings: list[GateFinding] = []
    allowed_nrc: tuple[int, ...] = ()

    if svc == "0x10":
        _append_session_transition_findings(
            findings,
            case=case,
            payload=payload,
            source_session=session,
            expected_nrc=expected,
            negative=negative,
            project_config=config,
        )

    if svc == "0x27":
        require_security_session = config.get("lint", {}).get("require_session_for_security", True)
        if require_security_session and not _session_declared(case, config):
            findings.append(GateFinding("SA-001", "ERROR", "0x27 用例缺少会话前置声明", "UDS用例"))
        sub = int(payload[1]) if payload and len(payload) >= 2 else None
        level_to_sessions = config.get("security", {}).get("level_to_sessions", {})
        if sub is not None and sub in level_to_sessions:
            required_sessions = level_to_sessions[sub]
        elif sub is not None:
            # Keep the gate aligned with case_lint: projects may provide a
            # catch-all session policy for security levels not listed
            # individually, while an explicitly empty level remains empty.
            required_sessions = config.get("security", {}).get(
                "default_level_sessions", ()
            )
        else:
            required_sessions = ()
        current_session = normalize_session(session, config)
        if positive and required_sessions and current_session is not None and current_session not in required_sessions:
            names = config.get("sessions", {}).get("names", {})
            required_text = ", ".join(
                str(names.get(int(item), f"0x{int(item):02X}")) for item in required_sessions
            )
            findings.append(GateFinding(
                "SA-002", "ERROR", f"0x27 等级 0x{sub:02X} 应在 {required_text}，当前为 {session}", "UDS用例"))
        if not negative and sub is not None and sub % 2 == 0 and not key_ready:
            findings.append(GateFinding("SA-003", "BLOCKED", "真实 0x27 Key/解锁密钥未就绪", "密钥材料"))
        if negative and not expected and config.get("lint", {}).get("require_nrc_for_negative", True):
            findings.append(GateFinding("NRC-002", "ERROR", "0x27 负例未声明具体 NRC", "UDS用例"))

    if svc in {"0x22", "0x2E"} and positive and payload is not None and not did:
        findings.append(GateFinding("DID-002", "ERROR", f"{svc} 正向用例缺少完整 DID", "UDS请求"))
    _append_partition_findings(
        findings, case=case, model=model, did=did, target=target, service=svc,
        session=session, expected_nrc=expected, positive=positive, negative=negative,
    )

    if did and target:
        expectation_model = model.expectation(did, target)
        if expectation_model is not None:
            allowed_nrc = tuple(expectation_model.conditional_nrc)
            if allowed_nrc and positive:
                findings.append(GateFinding(
                    "MATRIX-INFO-001", "INFO",
                    f"DID {did} 在 {target} 允许条件性 NRC {['0x%02X' % n for n in allowed_nrc]}；运行时不判为协议 FAIL",
                    "DID检查矩阵/条件响应模型",
                ))

    if (negative and not expected and svc != "0x27"
            and config.get("lint", {}).get("require_nrc_for_negative", True)):
        findings.append(GateFinding("NRC-003", "ERROR", "负向用例未声明具体 NRC", "UDS用例"))

    # 非负例但被明确标记为需要解锁的用例（包括 expectation=na 的条件
    # 用例）也必须在生成阶段 BLOCKED；负例可用未解锁状态独立验证 NRC，
    # 因此不继承真实密钥依赖。负例额外记录 INFO 证据，明确说明这里的
    # “未解锁”是被测条件，而不是遗漏了 0x27 前置。
    unlock_candidate = not negative
    requires_unlock = _requires_unlock(
        case, svc, positive=unlock_candidate, payload=payload, project_config=config
    )
    if svc != "0x27" and requires_unlock and not key_ready:
        findings.append(GateFinding("SEC-001", "BLOCKED", "用例需要 0x27 解锁，但真实密钥未就绪", "安全前置"))
    elif unlock_candidate and svc == "0x2E" and did:
        did_spec = model.lookup(did, target) or model.lookup(did)
        write_security = (dict(did_spec.write_security)
                          if did_spec and not did_spec.attributes_provisional else {})
        if any(str(value).strip().upper() == "Y" for value in write_security.values()) and not key_ready:
            findings.append(GateFinding("SEC-003", "BLOCKED", f"DID {did} 写入需要安全等级，但真实 0x27 密钥未就绪", "诊断库 DID 属性"))
        if (requires_unlock
                and config.get("lint", {}).get("require_session_for_security", True)
                and not _session_declared(case, config)):
            findings.append(GateFinding("SEC-002", "ERROR", f"{svc} 解锁正例缺少会话/安全前置声明", "安全前置"))
    elif (unlock_candidate and svc in {"0x2E", "0x31"} and requires_unlock
          and config.get("lint", {}).get("require_session_for_security", True)
          and not _session_declared(case, config)):
        findings.append(GateFinding("SEC-002", "ERROR", f"{svc} 解锁正例缺少会话/安全前置声明", "安全前置"))
    elif negative and svc in set(config.get("security", {}).get("unlock_required_services", ())):
        findings.append(GateFinding(
            "SEC-NEG-INFO", "INFO",
            f"{svc} 负向用例在未解锁状态下验证 ECU 拒绝，不要求真实 0x27 Key",
            "安全前置",
        ))

    if any(item.severity == "ERROR" for item in findings):
        decision = "REJECT"
    elif any(item.severity == "BLOCKED" for item in findings):
        decision = "BLOCKED"
    elif any(item.severity == "REVIEW_REQUIRED" for item in findings):
        decision = "REVIEW_REQUIRED"
    elif negative:
        decision = "NEGATIVE"
    else:
        decision = "GENERATE"
    return GateDecision(
        case_id=cid,
        decision=decision,
        service=svc,
        did=did,
        rid=rid,
        session=session,
        target_partition=target,
        expected_nrc=expected,
        allowed_nrc=allowed_nrc,
        findings=tuple(findings),
    )


def gate_cases(
    cases: Sequence[Mapping[str, Any]],
    *,
    payloads: Mapping[str, Sequence[int] | None],
    model: PartitionModel,
    expectations: Mapping[str, str] | None = None,
    expected_nrcs: Mapping[str, Sequence[int]] | None = None,
    sessions: Mapping[str, str] | None = None,
    key_ready: bool = False,
    project_config: Mapping[str, Any] | str | None = None,
) -> tuple[list[GateDecision], dict[str, int]]:
    decisions = []
    for case in cases:
        cid = str(case.get("case_id", "?"))
        decision = evaluate_case(
            case,
            payload=payloads.get(cid),
            model=model,
            expectation=(expectations or {}).get(cid, ""),
            expected_nrc=(expected_nrcs or {}).get(cid, ()),
            session=(sessions or {}).get(cid),
            key_ready=key_ready,
            project_config=project_config,
        )
        decisions.append(decision)
    summary = {decision: sum(1 for item in decisions if item.decision == decision) for decision in DECISIONS}
    return decisions, summary


__all__ = [
    "DECISIONS",
    "GateDecision",
    "GateFinding",
    "SA_SESSION_MAP",
    "evaluate_case",
    "extract_expected_nrcs",
    "gate_cases",
    "UNLOCK_REQUIRED_SERVICES",
]
