#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tp_layout.py — CAN/LIN 诊断帧结构统一解析（防止两套 TP 口径混用，v3.9.2）

背景（2026-09-11 实际事故）：审计抽查脚本把 CAN-TP 风格的 FF 偏移用在 LIN 帧上，
两轮误报"0x27 认证链帧缺失"——帧都在，是解析口径错了。教训固化：**判"缺失"前
必须用本组件取偏移，禁止手写魔法数字**。

两套口径的核心差异（混淆根源）:

| 维度        | LIN TP (ISO 17987 / LIN 2.x)      | CAN TP (ISO 15765-2)            |
|-------------|-----------------------------------|---------------------------------|
| 帧载体      | 固定 8B，帧 ID 0x3C(主)/0x3D(从)  | CAN 数据场 ≤8B，11/29 位 ID 寻址|
| NAD         | 有（d[0]）→ 所有偏移 +1           | 无（靠 CAN ID 寻址）            |
| SF          | [NAD, 0x0L, SID@d[2]...]          | [0x0L, SID@d[1]...]             |
| FF          | [NAD, 0x1H, len_lo, SID@d[3]...]  | [0x1H, FF_DL, SID@d[2]...]      |
|             | （PCI 2B：len_hi 4 位 + len_lo）  | （PCI 1B + FF_DL，12 位长度）   |
| CF          | [NAD, 0x2S, data@d[2]...]         | [0x2S, data@d[1]...]            |
| FC          | LIN 无流控帧（调度表机制）        | [0x3S, BS, STmin, ...]          |
| 诊断帧校验和| classic（0x3C/0x3D）              | 无（CAN CRC 由控制器处理）      |

用法:
    from tp_layout import parse_tp_frame, detect_bus
    info = parse_tp_frame("lin", 0x3C, [0x51, 0x03, 0x22, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF])
    # -> {"type": "SF", "payload_off": 2, "sid_off": 2, "sid": 0x22, "tp_len": 3, ...}

自测（含 LIN 与 CAN 双套样例帧，含本次事故的真实帧）:  python tp_layout.py
"""
from __future__ import annotations

LIN_DIAG_IDS = (0x3C, 0x3D)


def detect_bus(frame_id: int) -> str:
    """按帧 ID 判总线：0x3C/0x3D = LIN 诊断帧；其余视为 CAN（LIN 应用帧 ID 0x00-0x3B
    由调用方显式传 bus='lin' 区分）。"""
    return "lin" if frame_id in LIN_DIAG_IDS else "can"


def parse_tp_frame(bus: str, frame_id: int, data) -> dict:
    """解析单条诊断帧的 TP 结构，返回偏移口径（审计/抽查脚本统一调用本函数）。"""
    d = list(data)
    bus = bus.lower()
    if bus == "lin":
        # 调度表轮询帧：空 3D 或全 FF 3C（非 TP 帧）
        if len(d) == 0:
            return {"bus": "lin", "type": "SCHED", "payload_off": None, "sid_off": None}
        if len(d) >= 2 and all(b == 0xFF for b in d):
            return {"bus": "lin", "type": "SCHED", "payload_off": None, "sid_off": None}
        if len(d) < 2:
            return {"bus": "lin", "type": "MALFORMED", "payload_off": None, "sid_off": None}
        pci = d[1] & 0xF0
        if pci == 0x00:                                    # SF：PCI 1B = 长度
            n = d[1] & 0x0F
            return {"bus": "lin", "type": "SF", "payload_off": 2, "sid_off": 2,
                    "tp_len": n, "sid": d[2] if len(d) > 2 else None}
        if pci == 0x10:                                    # FF：PCI 2B（12 位长度）
            total = ((d[1] & 0x0F) << 8) | d[2]
            return {"bus": "lin", "type": "FF", "payload_off": 3, "sid_off": 3,
                    "tp_len": total, "sid": d[3] if len(d) > 3 else None}
        if pci == 0x20:                                    # CF：seq = d[1]&0x0F
            return {"bus": "lin", "type": "CF", "payload_off": 2, "sid_off": None,
                    "seq": d[1] & 0x0F}
        return {"bus": "lin", "type": "UNKNOWN", "payload_off": None, "sid_off": None,
                "pci": d[1]}
    elif bus == "can":
        if not d:
            return {"bus": "can", "type": "MALFORMED", "payload_off": None, "sid_off": None}
        pci = d[0] & 0xF0
        if pci == 0x00:                                    # SF：PCI 1B = 长度（≤7）
            n = d[0] & 0x0F
            return {"bus": "can", "type": "SF", "payload_off": 1, "sid_off": 1,
                    "tp_len": n, "sid": d[1] if len(d) > 1 else None}
        if pci == 0x10:                                    # FF：FF_DL 12 位
            total = ((d[0] & 0x0F) << 8) | d[1]
            return {"bus": "can", "type": "FF", "payload_off": 2, "sid_off": 2,
                    "tp_len": total, "sid": d[2] if len(d) > 2 else None}
        if pci == 0x20:                                    # CF
            return {"bus": "can", "type": "CF", "payload_off": 1, "sid_off": None,
                    "seq": d[0] & 0x0F}
        if pci == 0x30:                                    # FC：BS/STmin
            return {"bus": "can", "type": "FC", "payload_off": 1, "sid_off": None,
                    "bs": d[1] if len(d) > 1 else None,
                    "stmin": d[2] if len(d) > 2 else None}
        return {"bus": "can", "type": "UNKNOWN", "payload_off": None, "sid_off": None,
                "pci": d[0]}
    raise ValueError("bus 必须为 'lin' 或 'can'，收到 %r" % bus)


def find_sid(bus: str, frames, sid_bytes) -> list:
    """在帧序列中按正确口径检索 SID 子功能（抽查/审计统一入口，替代手写偏移）。
    frames: [{"id":.., "dir":.., "data":[..]}, ...]；匹配 FF（首帧）与 SF。"""
    n = len(sid_bytes)
    out = []
    for f in frames:
        info = parse_tp_frame(bus, f["id"], f["data"])
        if info["type"] in ("SF", "FF") and info["sid_off"] is not None:
            d = list(f["data"])
            if len(d) >= info["sid_off"] + n and d[info["sid_off"]:info["sid_off"] + n] == list(sid_bytes):
                out.append((info["type"], f))
    return out


if __name__ == "__main__":
    # ---- LIN 样例（含 2026-09-11 事故的真实帧）----
    lin_sf = [0x51, 0x03, 0x22, 0xD0, 0x3A, 0xFF, 0xFF, 0xFF]          # SF: 22 D0 3A
    i = parse_tp_frame("lin", 0x3C, lin_sf)
    assert i["type"] == "SF" and i["sid"] == 0x22 and i["sid_off"] == 2, i
    lin_ff = [0x51, 0x10 | 0x00, 52, 0x27, 0x05, 0xAA, 0xBB, 0xCC]     # FF: 27 05（52B 多帧）
    i = parse_tp_frame("lin", 0x3C, lin_ff)
    assert i["type"] == "FF" and i["sid"] == 0x27 and i["sid_off"] == 3 and i["tp_len"] == 52, i
    i = parse_tp_frame("lin", 0x3C, [0x51, 0x21, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06])
    assert i["type"] == "CF" and i["seq"] == 1 and i["payload_off"] == 2, i
    i = parse_tp_frame("lin", 0x3C, [0xFF] * 8)
    assert i["type"] == "SCHED", i
    i = parse_tp_frame("lin", 0x3D, [])
    assert i["type"] == "SCHED", i
    # ---- CAN 样例（15765-2）----
    i = parse_tp_frame("can", 0x7E0, [0x02, 0x10, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00])
    assert i["type"] == "SF" and i["sid"] == 0x10 and i["sid_off"] == 1, i
    i = parse_tp_frame("can", 0x7E8, [0x10, 0x14, 0x62, 0xF1, 0x86, 0x01, 0x00, 0x00])
    assert i["type"] == "FF" and i["sid"] == 0x62 and i["sid_off"] == 2 and i["tp_len"] == 0x14, i
    i = parse_tp_frame("can", 0x7E0, [0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
    assert i["type"] == "FC", i
    # ---- 混淆检查：同为 27 05 多帧首帧，LIN 与 CAN 的 SID 偏移必须差 1（NAD 语义）----
    # 事故回放：LIN 帧 [NAD, 0x10, lo, 27, 05, ...] 被按 CAN 口径查 d[2] → 误报缺失
    lin_f = [0x51, 0x10, 0x34, 0x27, 0x05, 0xAA, 0xBB, 0xCC]   # LIN FF: NAD + PCI2B
    a = parse_tp_frame("lin", 0x3C, lin_f)
    assert a["type"] == "FF" and a["sid"] == 0x27 and a["sid_off"] == 3, a
    can_f = [0x10, 0x34, 0x27, 0x05, 0xAA, 0xBB, 0xCC, 0xDD]   # CAN FF: PCI + FF_DL
    b = parse_tp_frame("can", 0x7E0, can_f)
    assert b["type"] == "FF" and b["sid"] == 0x27 and b["sid_off"] == 2, b
    assert a["sid_off"] == b["sid_off"] + 1                     # NAD 使 LIN 全体 +1
    # find_sid 统一入口：两套帧序列各自命中，口径自动正确
    hits = find_sid("lin", [{"id": 0x3C, "dir": "TX", "data": lin_f}], [0x27, 0x05])
    assert len(hits) == 1 and hits[0][0] == "FF"
    hits = find_sid("can", [{"id": 0x7E0, "dir": "TX", "data": can_f}], [0x27, 0x05])
    assert len(hits) == 1 and hits[0][0] == "FF"
    print("SELFTEST OK: LIN SF/FF/CF/SCHED + CAN SF/FF/FC + SID 偏移差异（lin=3, can=2, NAD+1）+ find_sid 双口径")
