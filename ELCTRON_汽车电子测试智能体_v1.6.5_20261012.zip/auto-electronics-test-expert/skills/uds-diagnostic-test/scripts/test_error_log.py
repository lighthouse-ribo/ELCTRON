#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""错误台账状态闭集回归。"""

import json
import os
import unittest

from error_log import build_log, load_results
from testsupport import WorkspaceTempDir


class TestErrorLogStatusContract(unittest.TestCase):
    def test_error_is_fail_but_explicit_skip_is_recorded(self):
        with WorkspaceTempDir("error_log") as td:
            path = os.path.join(td, "results.json")
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"results": [
                    {"case_id": "A", "verdict": "SKIP"},
                    {"case_id": "B", "verdict": "ERROR"},
                    {"case_id": "C", "verdict": "UNKNOWN"},
                ]}, handle)
            rows = load_results(path)
            self.assertEqual([row["verdict"] for row in rows], ["SKIP", "FAIL", "FAIL"])
            self.assertEqual([row["failure_class"] for row in rows],
                             ["NONE", "RESULT_INVALID", "RESULT_INVALID"])
            summary, entries = build_log(rows)
            self.assertEqual(summary["by_verdict"], {"SKIP": 1, "FAIL": 2})
            self.assertEqual(summary["by_failure_class"], {"NONE": 1, "RESULT_INVALID": 2})
            self.assertIn("SKIP", json.dumps(entries, ensure_ascii=False))
            self.assertNotIn("ERROR", json.dumps(entries, ensure_ascii=False))


if __name__ == "__main__":
    unittest.main(verbosity=2)
