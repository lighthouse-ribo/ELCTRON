"""Offline tests for real-time ASC append, split, and SWDL session artifacts."""

import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from trace_env_mixin import EvidenceTraceMixin  # noqa: E402
from testsupport import WorkspaceTempDir  # noqa: E402


class FakeUDS:
    def __init__(self):
        self._trace_capture = None
        self._trace_live_sink = None

    def record(self, direction, frame_id, data, timestamp):
        event = (timestamp, direction, frame_id, list(data))
        self._trace_capture.append(event)
        if self._trace_live_sink:
            self._trace_live_sink(event)


class Env(EvidenceTraceMixin):
    def __init__(self, case_id):
        self.case_id = case_id
        self.uds = FakeUDS()
        self.steps = []


class TestLiveAscRecorder(unittest.TestCase):
    def setUp(self):
        self.workspace = WorkspaceTempDir("live-asc")

    def tearDown(self):
        self.workspace.cleanup()

    def test_appends_immediately_splits_and_writes_session_summary(self):
        env = Env("SWDL_TC_001")
        self.assertTrue(env.trace_begin(
            out_dir=self.workspace.name,
            session_id="loop_20260914_160405",
            part_max_bytes=256,
        ))
        env.uds.record("TX", 0x3C, [0x51, 0x02, 0x10, 0x02, 0xFF, 0xFF, 0xFF, 0xFF], 1.0)
        first = os.path.join(self.workspace.name, "traces", "SWDL", "loop_20260914_160405", "part01.asc")
        self.assertTrue(os.path.isfile(first))
        with open(first, encoding="utf-8") as handle:
            self.assertIn("0.000000 Li 3c", handle.read())

        env.uds.record("RX", 0x3D, [0x51, 0x06, 0x50, 0x02, 0x00, 0x19, 0x01, 0xF4], 1.01)
        result = env.trace_flush(out_dir=self.workspace.name, result_file="result.json")
        self.assertEqual(result["frames"], 2, env.steps)
        live = result["live_asc"]
        self.assertEqual(live["frames"], 2)
        self.assertGreaterEqual(len(live["parts"]), 2)
        self.assertTrue(os.path.isfile(live["runlog"]))
        self.assertTrue(os.path.isfile(live["rounds"]))
        with open(live["rounds"], encoding="utf-8") as handle:
            self.assertIn("SWDL_TC_001", handle.read())
        self.assertTrue(any("实时 ASC" in item for item in env.steps))


if __name__ == "__main__":
    unittest.main()
