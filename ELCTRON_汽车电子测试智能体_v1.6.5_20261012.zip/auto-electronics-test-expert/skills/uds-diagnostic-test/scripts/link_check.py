#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
链路通探测 —— 执行前确认「总线有活动 + ECU 应答」，不通不跑用例
=========================================================================
实测固化：VChannelMapping 为空 / 系统级通道配置未生效 / LIN outputV=0 时，
所有用例都是「假失败」（问题 16/17/24）。本脚本把这些检查前置到执行前，
任一项不通过即返回非零退出码，编排器据此中止，避免白跑一整轮。

用法:
  # CAN (Vector VN1630A/1640A)
  python link_check.py --bus can --channel 0 --tx-id 0x7E0 --rx-id 0x7E8 --bitrate 500000 [--serial X]
  # LIN (F1L1/CANviex，需 F1L1_XCWRAPPER_DIR 指向 xcdev_wrapper.py)
  python link_check.py --bus lin [--nad 0x51] [--brval 19200]
  # 经执行器：uds_runner.py link-check --bus can ...

退出码: 0=链路通，1=链路不通或参数错误
"""

import argparse
import os
import sys
import time


def probe_with_warmup(probe, attempts=2, interval=1.5, sleep=time.sleep):
    """执行冷启动容错探测；返回 (是否成功, 尝试次数)。"""
    attempts = max(1, int(attempts))
    for attempt in range(1, attempts + 1):
        if attempt > 1 and interval > 0:
            sleep(float(interval))
        if probe(attempt):
            return True, attempt
    return False, attempts


def check_can(channel, tx_id, rx_id, bitrate, serial="", warmup_attempts=2,
              warmup_interval=1.5):
    """CAN 链路检查：①总线活动 ②0x3E TesterPresent 应答"""
    import can
    channel_num = int(channel) if str(channel).lstrip("-").isdigit() else channel
    kwargs = dict(
        interface="vector",
        channel=channel_num,
        bitrate=bitrate,
        app_name="UDS-Link-Check",
        receive_own_messages=False,
    )
    if serial:
        kwargs["serial"] = serial
    try:
        bus = can.interface.Bus(**kwargs)
    except Exception as e:
        print(f"[ERROR] 打开 CAN 通道失败: {e}")
        print("[HINT] 检查驱动 / 通道占用（VickCAN/CANoe）/ 硬件连接")
        return False
    ok = True

    # 1) 总线活动：2s 内收到任意帧
    got = bus.recv(timeout=2.0)
    if got is not None:
        print(f"[OK] 总线有活动: id=0x{got.arbitration_id:X} dlc={got.dlc} data={got.data.hex()}")
    else:
        print("[FAIL] 2s 内未收到任何帧（周期帧缺失：通道未映射 / 无供电 / 主节点未调度）")
        ok = False

    # 2) 0x3E 探测（单帧 UDS TesterPresent）。设备刚打开时 ECU/调度器
    # 可能尚未完成冷启动，失败后按固定间隔重试，避免一次瞬态误报。
    def probe(_attempt):
        try:
            req = bytes([0x02, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
            bus.send(can.Message(arbitration_id=tx_id, data=req, is_extended_id=False))
        except Exception as exc:
            print(f"[ERROR] 发送 0x3E 失败: {exc}")
            return False
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            r = bus.recv(timeout=max(0.1, deadline - time.monotonic()))
            if r is None:
                break
            if r.arbitration_id == rx_id and 0x7E in r.data[1:4] and (r.data[0] & 0xF0) in (0x00, 0x10):
                print(f"[OK] ECU 应答 0x3E: id=0x{r.arbitration_id:X} data={r.data.hex()}")
                return True
        return False

    got_ecu, attempts = probe_with_warmup(probe, warmup_attempts, warmup_interval)
    if not got_ecu:
        print("[FAIL] 0x3E 探测无应答（ECU 未上电 / CAN ID 不匹配 / 总线不通）")
        ok = False
    elif attempts > 1:
        print(f"[INFO] 0x3E 探测在第 {attempts} 次 warm-up 重试后通过")
    bus.shutdown()
    return ok


def check_lin(nad=0x51, brval=19200, warmup_attempts=2, warmup_interval=1.5):
    """LIN 链路检查（F1L1）：①设备打开+供电 ②0x3E TesterPresent 应答"""
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    if scripts_dir not in sys.path:
        sys.path.insert(0, scripts_dir)
    try:
        from f1l1_uds import F1L1UDS
    except ImportError as e:
        print(f"[ERROR] f1l1_uds 导入失败: {e}")
        print("[HINT] 设置 F1L1_XCWRAPPER_DIR 指向 xcdev_wrapper.py 所在目录")
        return False
    ok = True
    uds = F1L1UDS(brval=brval)
    try:
        uds.open()
        print("[OK] F1L1 设备打开成功（outputV=1，LIN 收发器已供电）")
    except Exception as e:
        print(f"[FAIL] F1L1 打开/配置失败: {e}")
        return False
    try:
        def probe(_attempt):
            resp = uds.request(nad, [0x3E, 0x00], timeout=3.0, retry=0)
            if resp and resp[0] == 0x7E:
                print(f"[OK] ECU 应答 0x3E: NAD=0x{nad:02X} resp={[hex(b) for b in resp]}")
                return True
            return False

        got_ecu, attempts = probe_with_warmup(probe, warmup_attempts, warmup_interval)
        if not got_ecu:
            print(f"[FAIL] 0x3E 探测无应答（NAD=0x{nad:02X}；查调度表是否含 0x3D / NAD / PID / 从机供电）")
            ok = False
        elif attempts > 1:
            print(f"[INFO] LIN 0x3E 探测在第 {attempts} 次 warm-up 重试后通过")
    finally:
        uds.close()
    return ok


def main():
    parser = argparse.ArgumentParser(description="链路通探测（CAN/LIN），执行前门禁")
    parser.add_argument("--bus", choices=["can", "lin"], default="can", help="总线类型")
    # CAN
    parser.add_argument("--channel", default="0", help="CAN 通道 (Vector: 0-3)")
    parser.add_argument("--tx-id", type=lambda s: int(s, 0), default=0x7E0, help="诊断请求 CAN ID")
    parser.add_argument("--rx-id", type=lambda s: int(s, 0), default=0x7E8, help="诊断响应 CAN ID")
    parser.add_argument("--bitrate", type=int, default=500000, help="CAN 波特率")
    parser.add_argument("--serial", default="", help="Vector 设备序列号（多盒子时指定）")
    parser.add_argument("--warmup-attempts", type=int, default=2,
                        help="设备打开后的 0x3E 探测次数（默认 2）")
    parser.add_argument("--warmup-interval", type=float, default=1.5,
                        help="warm-up 探测间隔秒数（默认 1.5）")
    # LIN
    parser.add_argument("--nad", type=lambda s: int(s, 0), default=0x51, help="LIN 从机 NAD（十六进制，如 0x51）")
    parser.add_argument("--brval", type=int, default=19200, help="LIN 波特率")
    args = parser.parse_args()

    if args.bus == "can":
        ok = check_can(args.channel, args.tx_id, args.rx_id, args.bitrate, args.serial,
                       args.warmup_attempts, args.warmup_interval)
    else:
        ok = check_lin(args.nad, args.brval, args.warmup_attempts, args.warmup_interval)

    print("[RESULT] " + ("链路通，可以开始执行测试" if ok else "链路不通，先修复环境再执行（见上方 FAIL 项）"))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
