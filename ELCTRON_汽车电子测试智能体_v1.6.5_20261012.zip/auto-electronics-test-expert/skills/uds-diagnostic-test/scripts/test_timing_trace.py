#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""轨迹时序分析离线单测（合成轨迹，脱离硬件）
运行: python test_timing_trace.py
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lin_tp import analyze_trace  # noqa: E402


def tx(t, data):
    return (t, "TX", 0x3C, data)


def rx(t, data):
    return (t, "RX", 0x3D, data)


class TestFrameSlot(unittest.TestCase):
    def test_slot_20ms(self):
        trace = [tx(0.0, [0x51, 0x03, 0x3E, 0x00]),
                 tx(0.02, [0x51, 0x03, 0x3E, 0x00]),
                 tx(0.04, [0x51, 0x03, 0x3E, 0x00])]
        s = analyze_trace(trace)
        self.assertEqual(s["frame_slot_ms"]["avg"], 20.0)
        self.assertEqual(s["frame_slot_ms"]["min"], 20.0)
        self.assertEqual(s["frame_slot_ms"]["max"], 20.0)


class TestP2(unittest.TestCase):
    def test_p2_5ms(self):
        trace = [tx(0.0, [0x51, 0x03, 0x22, 0xF1, 0x2E]),
                 rx(0.005, [0x51, 0x05, 0x62, 0xF1, 0x2E, 0x01])]
        s = analyze_trace(trace)
        self.assertEqual(s["p2_ms"], [5.0])
        self.assertEqual(s["p2_star_ms"], [])
        self.assertEqual(s["pending_count"], 0)


class TestP2Star(unittest.TestCase):
    def test_pending_78(self):
        trace = [tx(0.0, [0x51, 0x03, 0x31, 0x01, 0x02]),
                 rx(0.005, [0x51, 0x05, 0x7F, 0x31, 0x78, 0x00]),
                 rx(0.080, [0x51, 0x05, 0x71, 0x01, 0x02, 0x01])]
        s = analyze_trace(trace)
        self.assertEqual(s["pending_count"], 1)
        self.assertEqual(s["p2_star_ms"], [80.0])
        self.assertEqual(s["p2_ms"], [])


class TestNrc37Delay(unittest.TestCase):
    def test_delay_gap(self):
        trace = [tx(0.0, [0x51, 0x03, 0x27, 0x05]),
                 rx(0.005, [0x51, 0x04, 0x7F, 0x27, 0x37]),
                 tx(10.0, [0x51, 0x03, 0x27, 0x05]),
                 rx(10.005, [0x51, 0x04, 0x7F, 0x27, 0x37])]
        s = analyze_trace(trace)
        self.assertEqual(s["nrc37_gaps_ms"], [10000.0])


class TestWarnings(unittest.TestCase):
    def test_slot_jitter(self):
        trace = [tx(0.0, [0x51, 0x03, 0x3E, 0x00]),
                 tx(0.02, [0x51, 0x03, 0x3E, 0x00]),
                 tx(0.05, [0x51, 0x03, 0x3E, 0x00])]  # 30ms 抖动
        s = analyze_trace(trace)
        self.assertTrue(any("帧隙抖动" in w for w in s["warnings"]))

    def test_p2_over_50(self):
        trace = [tx(0.0, [0x51, 0x03, 0x22, 0xF1, 0x2E]),
                 rx(0.060, [0x51, 0x05, 0x62, 0xF1, 0x2E, 0x01])]
        s = analyze_trace(trace)
        self.assertTrue(any("P2 最大" in w for w in s["warnings"]))


class TestProbeTrace(unittest.TestCase):
    """采集层主动注入闭环：周期性 TX 0x3C 诊断请求 + RX 0x3D 响应
    （对应 capture_trace(probe_payloads=...) 生成的轨迹 → analyze_trace 算出 P2）"""

    def _probe_trace(self, n, interval=1.0, p2_ms=25.0):
        trace = []
        for i in range(n):
            t = i * interval
            trace.append(tx(t, [0x51, 0x03, 0x22, 0xF1, 0x86]))     # 注入读 F186
            trace.append(rx(t + p2_ms / 1000.0, [0x51, 0x04, 0x62, 0xF1, 0x86, 0x01]))
        return trace

    def test_periodic_probe_yields_p2_samples(self):
        trace = self._probe_trace(n=4, interval=1.0, p2_ms=25.0)
        s = analyze_trace(trace)
        self.assertEqual(len(s["p2_ms"]), 4)         # 每次注入都算出 P2
        self.assertTrue(all(25.0 - 1e-9 <= v <= 25.0 + 1e-9 for v in s["p2_ms"]))
        self.assertEqual(s["pending_count"], 0)

    def test_probe_mixed_3e_and_22(self):
        # 交替注入 3E 00 / 22 F1 86，P2 均应被识别（读 DID 响应为 RX）
        trace = [tx(0.0, [0x51, 0x02, 0x3E, 0x00]), rx(0.005, [0x51, 0x02, 0x7E, 0x00]),
                 tx(1.0, [0x51, 0x03, 0x22, 0xF1, 0x86]), rx(1.005, [0x51, 0x04, 0x62, 0xF1, 0x86, 0x01]),
                 tx(2.0, [0x51, 0x02, 0x3E, 0x00]), rx(2.005, [0x51, 0x02, 0x7E, 0x00])]
        s = analyze_trace(trace)
        self.assertEqual(len(s["p2_ms"]), 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
