#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试错误处理日志模块：把每次执行的非 PASS 用例归纳为错误处理流程日志
=========================================================================
对执行结果（exec_results / results_all.json）中 FAIL / NA / BLOCKED / SKIP 的用例，
归纳为「检测 → 分类 → 处置 → 状态」四步流程，输出：
  error_handling_log.json  —— 结构化归纳（可二次统计）
  error_handling_log.md    —— 可读报告
并可追加到 journal（jsonl）累积每一次执行，形成跨轮错误处理台账。

用法:
  python error_log.py --results results_all.json [--journal error_journal.jsonl] --out-dir logs/
  uds_runner.py error-log --results ... --out-dir ...
"""

import argparse
import json
import os
from collections import Counter
from datetime import datetime

from result_contract import normalize_result as normalize_contract_result


ACTION = {
    "环境-密钥缺失": "等待 OEM 提供真实 AES 密钥 → seedkey_gen2.py --check → 重跑解锁",
    "环境-ECU状态（待确认）": "向主机厂确认（如软件结构号是否应出厂预置）",
    "流程-需授权": "获取授权（0x11 复位 / 刷写）后独立执行",
    "流程-用户明确排除": "解除本轮排除后重新生成并执行该用例",
    "资料-参数待补": "按调查表/ SWRS 补全参数后重新生成脚本",
    "资料-输入无效": "修复输入文件或调查表映射后重新生成脚本",
    "设计-正确拒绝": "判定正确，标 NA，无需处理",
    "设计-条件受限": "标 NA，记录受限条件，不视为缺陷",
    "脚本-执行异常": "修复生成脚本/运行时异常后重跑，不计入 ECU FAIL",
    "基础设施-执行异常": "修复 Vector/CAN/LIN/运行环境后重跑，不计入 ECU FAIL",
    "结果-状态非法": "修复结果文件或结果契约后重跑，不计入 ECU FAIL",
    "脚本/协议-待排查": "复测 + 一致性判定；必要时修脚本/协议实现",
    "环境-前置未满足": "补齐前置条件（会话/供电/工具占用）后重跑",
    "其他": "人工复核",
}
VALID_VERDICTS = {"PASS", "FAIL", "BLOCKED", "NA", "SKIP"}


def normalize_result(case):
    """保留旧 verdict 展示，同时补齐 failure_class 根因字段。"""
    return normalize_contract_result(case)


def classify(case):
    """错误分类：返回 (类别, resolved, 证据)"""
    v = (case.get("verdict") or "").upper()
    note = str(case.get("note") or "")
    desc = str(case.get("desc") or "")
    svc = str(case.get("service") or "")
    text = note + " " + desc
    nrc = case.get("nrc")
    actual = str(case.get("actual") or "未执行")
    evidence = actual
    if nrc is not None:
        evidence += f"（NRC=0x{nrc:02X}）"
    failure_class = str(case.get("failure_class") or "").upper()
    if failure_class == "SCRIPT_ERROR":
        return "脚本-执行异常", False, evidence
    if failure_class == "INFRA_ERROR":
        return "基础设施-执行异常", False, evidence
    if failure_class == "INPUT_INVALID":
        return "资料-输入无效", False, evidence
    if failure_class == "RESULT_INVALID":
        return "结果-状态非法", False, evidence
    if v == "SKIP":
        return "流程-用户明确排除", True, evidence
    if v == "BLOCKED":
        if "密钥" in text or svc in ("0x27", "0x34", "0x36", "0x37"):
            return "环境-密钥缺失", False, evidence
        if "授权" in text:
            return "流程-需授权", False, evidence
        if "待补" in text:
            return "资料-参数待补", False, evidence
        return "环境-前置未满足", False, evidence
    if v == "NA":
        if "授权" in text:
            return "流程-需授权", False, evidence
        if "需解锁" in text or "密钥" in text:
            return "环境-密钥缺失", False, evidence
        if "未配置" in text or "结构号" in text:
            return "环境-ECU状态（待确认）", False, evidence
        if "受限" in text or "分区" in text or "只写" in text or "不可读" in text:
            return "设计-正确拒绝", True, evidence
        return "设计-条件受限", True, evidence
    if v == "FAIL":
        return "脚本/协议-待排查", False, evidence
    return "其他", False, evidence


def build_flow(case, cat, resolved):
    nrc = case.get("nrc")
    detail = str(case.get("actual") or "未执行")
    if nrc is not None:
        detail += f"，NRC=0x{nrc:02X}"
    status = "已解决（正确拒绝）" if resolved else ("待外部条件" if cat.startswith(("环境", "流程", "资料")) else "待确认")
    return [
        {"step": "检测", "detail": detail},
        {"step": "分类", "detail": cat},
        {"step": "处置", "detail": ACTION.get(cat, ACTION["其他"])},
        {"step": "状态", "detail": status},
    ]


def load_results(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    rows = data.get("results", data if isinstance(data, list) else [])
    return [normalize_result(row) for row in rows]


def build_log(results, run_id=""):
    entries = []
    for raw in results:
        c = normalize_result(raw)
        v = (c.get("verdict") or "").upper()
        if v == "PASS":
            continue
        cat, resolved, evidence = classify(c)
        entries.append({
            "case_id": c.get("case_id", "?"),
            "service": c.get("service", ""),
            "desc": c.get("desc", ""),
            "session": c.get("session", ""),
            "verdict": v,
            "failure_class": c.get("failure_class", "RESULT_INVALID"),
            "category": cat,
            "resolved": resolved,
            "evidence": evidence,
            "note": c.get("note", ""),
            "flow": build_flow(c, cat, resolved),
        })
    summary = {
        "run_id": run_id,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_issues": len(entries),
        "by_verdict": dict(Counter(e["verdict"] for e in entries)),
        "by_failure_class": dict(Counter(e["failure_class"] for e in entries)),
        "by_category": dict(Counter(e["category"] for e in entries)),
        "resolved": sum(1 for e in entries if e["resolved"]),
        "pending": sum(1 for e in entries if not e["resolved"]),
    }
    return summary, entries


def render_md(summary, entries, path):
    L = ["# 测试错误处理日志\n"]
    L.append(f"- 轮次: {summary['run_id'] or '-'} ｜ 时间: {summary['timestamp']}")
    L.append(f"- 问题数: {summary['total_issues']} ｜ 已解决(正确拒绝): {summary['resolved']} ｜ 待处理: {summary['pending']}")
    L.append("")
    L.append("## 分类汇总")
    for cat, n in summary["by_category"].items():
        L.append(f"- {cat}: {n}")
    L.append("")
    for e in entries:
        L.append(f"### {e['case_id']} [{e['verdict']}] {e['desc']}")
        L.append(f"- 根因: {e['failure_class']} ｜ 类别: {e['category']} ｜ 已解决: {'是' if e['resolved'] else '否'}")
        for s in e["flow"]:
            L.append(f"- **{s['step']}**: {s['detail']}")
        L.append("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


def append_journal(journal, summary, entries):
    if not journal:
        return
    with open(journal, "a", encoding="utf-8") as f:
        f.write(json.dumps({"summary": summary, "entries": entries}, ensure_ascii=False) + "\n")


def main():
    ap = argparse.ArgumentParser(description="测试错误处理日志模块")
    ap.add_argument("--results", "-r", required=True, help="执行结果 JSON（results[] 含 verdict/actual/nrc/note）")
    ap.add_argument("--journal", "-j", help="追加日志 jsonl（累积每一次执行，可选）")
    ap.add_argument("--out-dir", "-o", default="./error_log")
    ap.add_argument("--run-id", default="", help="本轮标识（默认时间戳）")
    args = ap.parse_args()

    if not os.path.exists(args.results):
        print(f"[ERROR] 结果文件不存在: {args.results}")
        return 1
    results = load_results(args.results)
    run_id = args.run_id or os.path.splitext(os.path.basename(args.results))[0]
    summary, entries = build_log(results, run_id)
    os.makedirs(args.out_dir, exist_ok=True)
    with open(os.path.join(args.out_dir, "error_handling_log.json"), "w", encoding="utf-8") as f:
        json.dump({"summary": summary, "entries": entries}, f, ensure_ascii=False, indent=2)
    render_md(summary, entries, os.path.join(args.out_dir, "error_handling_log.md"))
    append_journal(args.journal, summary, entries)
    print(f"[OK] 错误处理日志: {os.path.join(args.out_dir, 'error_handling_log.md')}")
    print(f"     问题 {summary['total_issues']} ｜ 已解决 {summary['resolved']} ｜ 待处理 {summary['pending']}")
    for cat, n in summary["by_category"].items():
        print(f"     {cat}: {n}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
