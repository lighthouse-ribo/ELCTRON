#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""审查模块的深度完备性核对（P0-1：把"深度"变成可度量、可门禁的属性）
=====================================================================
与 script_review 的一致性审查正交：一致性回答"写出来的与证据一致且合法
吗"，本模块回答"该写的深场景写了没有"——补上"浅而一致全绿"的盲区
（反馈 2026-09-02：审查只查一致性、不查完备性）。

生效策略：
  - report（默认）：只输出核对表（profile + gaps），不改变审查状态/退出码；
  - block：缺口由 script_review 升级为 REVIEW_REQUIRED（--depth-policy block）。

规则 v1（宁缺勿滥，避免对部分覆盖的交付误报；全部为纯函数、可单测）：
  R1  DID 正反成对：0x22/0x2E 下出现正例的 DID 必须同时有负例；
      "有正无负"是 TRM 深度的最低完备性线（对照 814 条基线每 DID 正反成对）。
  R2  0x31 例程：每 RID 若出现结果读取(03)正例，必须存在启动(01)来源——
      来源可以是本 RID 的 01 用例，也可以是其它用例 PRE_ACTIONS 中的
      "先启动 RID XXXX"，防"读结果没有启动"的空转深度。
  R3  0x10 会话矩阵：目标会话全为 {0x01}（无切换），或只覆盖单一非默认
      目标且无恢复(01)时提示，供人工核对来源×目标矩阵。

扩展点：后续 S3± 边界对 / 0x27 等级×会话 / 时序组(TimeParm) / 0x10 抑制位
等规则只需在本文件追加同名函数并在 GAP_RULES 注册，不影响调用方。
"""
from collections import Counter, defaultdict

# 深度核对涉及的 SID → 服务短名（与 script_review._service 对齐，4-hex）
_SID_SERVICE = {
    0x10: "0x10", 0x22: "0x22", 0x2E: "0x2E",
    0x31: "0x31", 0x27: "0x27", 0x3E: "0x3E",
}
_SESSION_TARGET_NAMES = {
    0x01: "default(01)", 0x02: "programming(02)", 0x03: "extended(03)",
}


def _norm_service(service):
    """统一服务名（manifest 的 service 可能是 0x22 / '0x22' 大小写变体）。"""
    text = str(service or "").strip().lower()
    return text if text.startswith("0x") else ("0x" + text.lstrip("x")) if text else ""


def _payload_first(payload):
    return payload[0] if isinstance(payload, (list, tuple)) and payload else None


def _object_from_payload(payload):
    """DID/RID（4-hex 大写）提取；与 review_truth 语义一致但不引入依赖。"""
    payload = list(payload or [])
    if len(payload) < 2:
        return None
    sid = payload[0]
    if sid in (0x22, 0x2E) and len(payload) >= 3:
        return "%02X%02X" % (payload[1], payload[2])
    if sid == 0x31 and len(payload) >= 4:
        return "%02X%02X" % (payload[2], payload[3])
    return None


def _pre_started_rids(records):
    """被任何用例 PRE_ACTIONS 启动过的 RID 集合（含显式 01 正例的兜底）。"""
    started = set()
    for rec in records:
        payload = rec.get("payload")
        sid = _payload_first(payload)
        if sid == 0x31 and isinstance(payload, (list, tuple)) and len(payload) >= 4 \
                and payload[1] == 0x01:
            started.add("%02X%02X" % (payload[2], payload[3]))
        for action in (rec.get("pre_actions") or []):
            if isinstance(action, (list, tuple)) and len(action) >= 4 \
                    and action[0] == 0x31 and action[1] == 0x01:
                started.add("%02X%02X" % (action[2], action[3]))
    return started


# --------------------------------------------------------------------------
# 规则：每条返回 (service, gap_text) 列表；被 GAP_RULES 收集
# --------------------------------------------------------------------------
def _gap_did_pairing(records):
    """R1：DID 正反成对（0x22/0x2E）。"""
    by_did = defaultdict(set)          # (service, did) -> set(expect)
    for rec in records:
        payload = rec.get("payload")
        sid = _payload_first(payload)
        if sid not in (0x22, 0x2E):
            continue
        did = _object_from_payload(payload)
        if not did:
            continue
        svc = _norm_service(rec.get("service")) or _SID_SERVICE.get(sid, "")
        if svc:
            by_did[(svc, did)].add(str(rec.get("expect") or ""))
    gaps = []
    for (svc, did), expects in sorted(by_did.items()):
        if "pos" in expects and "neg" not in expects:
            gaps.append((svc, "DID 0x%s 有正例无负例（深度完备性 R1：正反应成对）" % did))
    return gaps


def _gap_routine_start(records):
    """R2：0x31 结果读取必须有启动(01)来源。"""
    rid_subs = defaultdict(set)        # rid -> {sub}
    for rec in records:
        payload = rec.get("payload")
        sid = _payload_first(payload)
        if sid != 0x31 or not isinstance(payload, (list, tuple)) or len(payload) < 2:
            continue
        rid = _object_from_payload(payload)
        if rid:
            rid_subs[rid].add(payload[1])
    started = _pre_started_rids(records)
    gaps = []
    for rid in sorted(rid_subs):
        subs = rid_subs[rid]
        if 0x03 in subs and 0x01 not in subs and rid not in started:
            gaps.append(("0x31", "RID 0x%s 结果读取(03)无启动来源（深度完备性 R2：缺 01 或先启动）" % rid))
    return gaps


def _gap_session_matrix(records):
    """R3：0x10 会话跳转矩阵最低线。"""
    targets = set()
    for rec in records:
        payload = rec.get("payload")
        if _payload_first(payload) != 0x10 or str(rec.get("expect") or "") != "pos":
            continue
        if isinstance(payload, (list, tuple)) and len(payload) >= 2:
            targets.add(payload[1] & 0x7F)
    if not targets:
        return []
    if targets == {0x01}:
        return [("0x10", "0x10 会话用例仅覆盖默认目标 0x01（无会话切换，深度完备性 R3）")]
    if len(targets) == 1 and 0x01 not in targets:
        target = next(iter(targets))
        return [("0x10", "0x10 仅覆盖单一非默认目标 0x%02X，缺恢复 0x01/来源×目标矩阵（深度完备性 R3）" % target)]
    return []


GAP_RULES = (_gap_did_pairing, _gap_routine_start, _gap_session_matrix)


# --------------------------------------------------------------------------
# 核对表 profile：各服务已观测维度（供报告/前端展示，不参与判定）
# --------------------------------------------------------------------------
def _build_profile(records):
    grouped = defaultdict(list)
    for rec in records:
        payload = rec.get("payload")
        sid = _payload_first(payload)
        svc = _norm_service(rec.get("service")) or _SID_SERVICE.get(sid, "")
        if not svc:
            continue
        grouped[svc].append((rec, sid, payload))
    profile = []
    for svc in sorted(grouped):
        expect = Counter(str(rec.get("expect") or "") for rec, _, _ in grouped[svc])
        objects, subs, targets, nrcs = set(), set(), set(), set()
        timing_metrics = set()
        for rec, sid, payload in grouped[svc]:
            payload = list(payload or [])
            obj = _object_from_payload(payload)
            if obj:
                objects.add(obj)
            if sid == 0x10 and len(payload) >= 2:
                targets.add(payload[1] & 0x7F)
            elif sid in (0x31, 0x27) and len(payload) >= 2:
                subs.add(payload[1])
            if str(rec.get("status") or "") == "timing" and rec.get("timing_metric"):
                timing_metrics.add(str(rec.get("timing_metric")))
            for nrc in (rec.get("expect_nrc") or []):
                try:
                    nrcs.add(int(nrc))
                except (TypeError, ValueError):
                    pass
        entry = {
            "service": svc,
            "cases": sum(expect.values()),
            "expect": dict(sorted(expect.items())),
            "objects": sorted(objects),
            "nrcs": sorted(nrcs),
            "timing_metrics": sorted(timing_metrics),
        }
        if svc == "0x10":
            entry["target_sessions"] = sorted(
                _SESSION_TARGET_NAMES.get(t, "0x%02X" % t) for t in targets)
        if svc in ("0x31", "0x27"):
            entry["subfunctions"] = sorted("0x%02X" % s for s in subs)
        profile.append(entry)
    return profile


def coverage_gaps(records):
    """records: list[dict]，字段与 script_review 单条审查记录对齐：
    case_id / service / expect / payload / status / pre_actions / expect_nrc /
    timing_metric（后两者可选）。

    返回 {"gaps": [{service, gap}], "profile": [服务维度核对表]}。
    """
    gaps = []
    for rule in GAP_RULES:
        gaps.extend(rule(records or []))
    return {
        "gaps": [{"service": svc, "gap": text} for svc, text in sorted(set(gaps))],
        "profile": _build_profile(records or []),
    }


if __name__ == "__main__":
    import json
    import sys
    sample = [
        {"case_id": "UDS_0x22_TC_POS", "service": "0x22", "expect": "pos",
         "payload": [0x22, 0xF1, 0x90], "status": "pos"},
    ]
    print(json.dumps(coverage_gaps(sample), ensure_ascii=False, indent=2))
    sys.exit(0)
