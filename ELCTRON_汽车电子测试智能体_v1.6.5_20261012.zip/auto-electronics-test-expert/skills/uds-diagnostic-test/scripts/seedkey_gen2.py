#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
0x27 Generation 2 安全访问纯 Python 实现（AES-128-CTR + AES-128-CMAC）
=====================================================================
用途：
  1) 作为 uds_test_generator.py --sa-key-file 的独立参考实现（模板内嵌同款类）
  2) 单独预校验密钥文件：python seedkey_gen2.py --check VolvoKey.json

密钥从 JSON 读取（本模块不硬编码任何密钥，红线合规）。字段名兼容 VolvoKey.json：
  aes_cmac_key_0102 / aes_ctr_key_0102 / aes_cmac_key_0506 / aes_ctr_key_0506
密钥为 16 字节 hex。全 0xFF **默认**按占位处理（保守默认，供未确认的项目使用）；
若项目已明确该 0xFF 即样件约定密钥，调用 load(accept_all_ff=True) 接受。
算法依据：27SecurityAccess.docx（Gen2：Seed 请求 54B / Key 请求 52B）。
"""

import argparse
import json
import os
import sys


def _to_key_bytes(raw):
    """密钥字段 -> 16 字节 bytes；支持 hex 字符串（可带 0x/空格）或字节列表"""
    if isinstance(raw, (list, tuple)):
        return bytes(int(x, 16) if isinstance(x, str) else x for x in raw)
    s = str(raw).strip().replace(" ", "").replace(",", "")
    if s.startswith("0x") or s.startswith("0X"):
        s = s[2:]
    if len(s) != 32:
        raise ValueError(f"密钥应为 32 位 hex（16 字节），实际 {len(s)} 位: {s[:8]}...")
    return bytes.fromhex(s)


def _aes_ctr(Cipher, algorithms, modes, key, iv, data):
    c = Cipher(algorithms.AES(key), modes.CTR(iv))
    e = c.encryptor()
    return e.update(data) + e.finalize()


def _aes_cmac(CMAC, algorithms, key, data):
    c = CMAC(algorithms.AES(key))
    c.update(data)
    return c.finalize()


class SeedKeyGen2:
    """0x27 Generation 2 安全访问纯 Python 实现（AES-128-CTR + AES-128-CMAC）
    密钥从 JSON 文件读取（模块不硬编码密钥，红线合规）：
      字段名（兼容 VolvoKey.json）：aes_cmac_key_0102 / aes_ctr_key_0102 /
                                    aes_cmac_key_0506 / aes_ctr_key_0506
    密钥为 16 字节 hex；全 0xFF 默认按占位 → ready=False（保守默认）。
    accept_all_ff=True 时视为项目约定密钥（如开发样件两端约定全 0xFF），ready=True。
    算法依据：27SecurityAccess.docx（Gen2：Seed 请求 54B / Key 请求 52B）。
    """

    def __init__(self, key_file):
        self.key_file = key_file
        self.keys = {}
        self.ready = False
        self.reason = ""

    def load(self, accept_all_ff=False):
        if not self.key_file or not os.path.isfile(self.key_file):
            self.reason = f"密钥文件不存在: {self.key_file}"
            return False
        try:
            with open(self.key_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            self.reason = f"密钥文件解析失败: {e}"
            return False
        aliases = {
            "aes_cmac_key_0102": ("aes_cmac_key_0102", "cmac_0102", "key_cmac_0102"),
            "aes_ctr_key_0102": ("aes_ctr_key_0102", "ctr_0102", "key_ctr_0102"),
            "aes_cmac_key_0506": ("aes_cmac_key_0506", "cmac_0506", "key_cmac_0506"),
            "aes_ctr_key_0506": ("aes_ctr_key_0506", "ctr_0506", "key_ctr_0506"),
        }
        data_lower = {str(k).lower(): v for k, v in data.items()}
        for key, cands in aliases.items():
            raw = None
            for c in cands:
                if c in data_lower and data_lower[c]:
                    raw = data_lower[c]
                    break
            if raw is None:
                continue
            try:
                self.keys[key] = _to_key_bytes(raw)
            except ValueError as e:
                self.reason = f"字段 {key} 解析失败: {e}"
                return False
        if "aes_cmac_key_0102" not in self.keys or "aes_ctr_key_0102" not in self.keys:
            self.reason = "缺少等级 01/02 密钥字段（aes_cmac_key_0102 / aes_ctr_key_0102）"
            return False
        # 全 0xFF 密钥：默认按占位处理（保守）；项目确认其为约定密钥时传 accept_all_ff=True。
        self.all_ff_keys = [k for k, v in self.keys.items() if v == b"\xff" * 16]
        if self.all_ff_keys and not accept_all_ff:
            self.reason = (f"密钥含全 0xFF: {self.all_ff_keys}（默认按占位处理，未就绪）；"
                           f"若项目已确认该值即样件约定密钥，改用 load(accept_all_ff=True)")
            return False
        if self.all_ff_keys:
            self.reason = (f"OK（{self.all_ff_keys} 为全 0xFF，按 accept_all_ff=True "
                           f"确认为项目/样件约定密钥）")
        self.ready = True
        return True

    def supports_level(self, level):
        if level in (0x01, 0x02):
            return "aes_cmac_key_0102" in self.keys and "aes_ctr_key_0102" in self.keys
        if level in (0x05, 0x06):
            return "aes_cmac_key_0506" in self.keys and "aes_ctr_key_0506" in self.keys
        return False

    def _keys_for(self, level):
        grp = "0102" if level in (0x01, 0x02) else "0506"
        return self.keys.get(f"aes_cmac_key_{grp}"), self.keys.get(f"aes_ctr_key_{grp}")

    def _import_crypto(self):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives.cmac import CMAC
        return Cipher, algorithms, modes, CMAC

    def build_seed_request(self, level, client_random=None, client_iv=None):
        """构造 0x27 请求 Seed 报文（54 字节 payload，不含 NAD/PCI）
        返回 (payload, client_random, client_iv)"""
        Cipher, algorithms, modes, CMAC = self._import_crypto()
        key_cmac, key_ctr = self._keys_for(level)
        if client_random is None:
            client_random = os.urandom(16)
        if client_iv is None:
            client_iv = os.urandom(16)
        enc = _aes_ctr(Cipher, algorithms, modes, key_ctr, client_iv, client_random)
        hdr = bytes([0x27, level, 0x00, 0x01, 0x00, 0x01])
        cmac = _aes_cmac(CMAC, algorithms, key_ctr, hdr + client_iv + enc)
        return list(hdr) + list(client_iv) + list(enc) + list(cmac), client_random, client_iv

    def parse_seed_response(self, resp, client_random, client_iv, level):
        """解析 67 响应（Gen2）：[67 level 00 02 iv[16] enc[32] cmac[16]]
        返回 (server_random, server_proof, ok)"""
        Cipher, algorithms, modes, CMAC = self._import_crypto()
        key_cmac, key_ctr = self._keys_for(level)
        server_iv = bytes(resp[4:20])
        enc = bytes(resp[20:52])
        plain = _aes_ctr(Cipher, algorithms, modes, key_ctr, server_iv, enc)
        server_random = plain[:16]
        server_proof = plain[16:32]
        expect = _aes_cmac(CMAC, algorithms, key_cmac, server_random + client_random)
        return server_random, server_proof, (expect == server_proof)

    def build_key_request(self, level, client_random, server_random, client_iv=None):
        """构造 0x27 发送 Key 报文（52 字节 payload）"""
        Cipher, algorithms, modes, CMAC = self._import_crypto()
        key_cmac, key_ctr = self._keys_for(level)
        if client_iv is None:
            client_iv = os.urandom(16)
        client_proof = _aes_cmac(CMAC, algorithms, key_cmac, client_random + server_random)
        enc = _aes_ctr(Cipher, algorithms, modes, key_ctr, client_iv, client_proof)
        hdr = bytes([0x27, level, 0x00, 0x03])
        cmac = _aes_cmac(CMAC, algorithms, key_ctr, hdr + client_iv + enc)
        return list(hdr) + list(client_iv) + list(enc) + list(cmac)

    def unlock(self, uds, level):
        """完整 Gen2 解锁流程（在 UdsClient 上执行）。
        返回 (success, seed_req_hex, key_req_hex, resp, detail)"""
        try:
            seed_payload, client_random, client_iv = self.build_seed_request(level)
        except ImportError:
            return (False, "", "", [], "缺少 cryptography 依赖：pip install cryptography")
        resp = uds.send_request(seed_payload)
        if resp is None:
            return (False, "", "", None, "Seed 请求无响应")
        if len(resp) < 3 or resp[0] == 0x7F:
            return (False, "", "", resp, f"Seed 请求被拒 {describe_nrc(resp)}")
        if resp[0] != 0x67:
            return (False, "", "", resp, "Seed 响应 SID 非 0x67")
        try:
            server_random, server_proof, ok = self.parse_seed_response(resp, client_random, client_iv, level)
        except Exception as e:
            return (False, "", "", resp, f"Seed 响应解析失败: {e}")
        if not ok:
            return (False, "", "", resp, "服务器所有权证明校验失败（密钥不符或算法参数错误）")
        key_payload = self.build_key_request(level, client_random, server_random, client_iv)
        resp2 = uds.send_request(key_payload)
        if resp2 is not None and len(resp2) >= 2 and resp2[0] == 0x67:
            return (True, "", "", resp2, "Gen2 解锁成功")
        return (False, "", "", resp2, f"SendKey 被拒 {describe_nrc(resp2)}")


# ============================================================================
# NRC 语义速查（报告自动解释；实测固化：0x22/0x31/0x7F/0x37 是 0x27 最常见的误判 NRC）
# ============================================================================
NRC_MEANING = {
    0x10: "generalReject", 0x11: "serviceNotSupported", 0x12: "subFunctionNotSupported",
    0x13: "incorrectMessageLengthOrInvalidFormat", 0x14: "responseTooLong",
    0x21: "busyRepeatRequest", 0x22: "conditionsNotCorrect",
    0x24: "requestSequenceError", 0x31: "requestOutOfRange",
    0x33: "securityAccessDenied", 0x35: "invalidKey",
    0x36: "exceedNumberOfAttempts", 0x37: "requiredTimeDelayNotExpired",
    0x7E: "subFunctionNotSupportedInActiveSession", 0x7F: "serviceNotSupportedInActiveSession",
}


def nrc_name(nrc):
    """NRC -> 英文名（未知返回 unknownNrc）"""
    return NRC_MEANING.get(nrc, "unknownNrc")


def describe_nrc(resp):
    """负响应 -> 'NRC=0x22 (conditionsNotCorrect)'；非负响应返回 'No NRC'"""
    if resp and len(resp) >= 3 and resp[0] == 0x7F:
        return f"NRC=0x{resp[2]:02X} ({nrc_name(resp[2])})"
    return "No NRC"


def main():
    ap = argparse.ArgumentParser(description="Gen2 密钥文件预校验")
    ap.add_argument("--check", required=True, help="密钥 JSON 文件路径（VolvoKey.json 格式）")
    ap.add_argument("--level", default="01,05", help="要检查的安全等级（逗号分隔，默认 01,05）")
    args = ap.parse_args()

    sk = SeedKeyGen2(args.check)
    ok = sk.load()
    print(f"key_file   : {args.check}")
    print(f"ready      : {sk.ready}")
    print(f"reason     : {sk.reason or 'OK'}")
    for f in ("aes_cmac_key_0102", "aes_ctr_key_0102", "aes_cmac_key_0506", "aes_ctr_key_0506"):
        v = sk.keys.get(f)
        masked = (v.hex()[:4] + "..." + v.hex()[-4:]) if v else "(缺失)"
        print(f"  {f:<22}: {masked}")
    for lv in (int(x, 16) for x in args.level.replace(" ", "").split(",") if x):
        avail = sk.ready and sk.supports_level(lv)
        print(f"level 0x{lv:02X} : {'可用' if avail else '不可用（未就绪：占位/缺失/解析失败）'}")
    sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()
