#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_cache.py — 解析产物 content-addressed 缓存（SHA-256 键控，v3.9.2）

解决：Excel/LDF/SDDB/PDF 需求文件在多阶段（设计→生成→审查→审计）与多会话中被
反复全量解析。首次解析后把结构化产物落盘缓存，键 = 源文件 SHA-256 + 解析器版本；
源文件未变且解析器未升级 → 直接复用，否则自动重解析。

用法（包住任何"路径进、结构出"的解析器）:

    from parse_cache import cached_parse
    from ldf_parser import parse_ldf

    model = cached_parse("BBS1LIN.ldf", parse_ldf,
                         parser_name="ldf_parser", parser_version="1.0")

    # 带参数的解析器（参数参与缓存键，不同过滤条件不串缓存）
    sddb = cached_parse("SDDB.xlsx", extract_sddb,
                        parser_name="sddb_extract", parser_version="1.0",
                        parse_args={"parsed": None})

设计要点：
  - 缓存键 = SHA-256(源文件全文) + parser_version —— 内容寻址：文件变了或解析器
    升级自动失效，不存在旧缓存污染；
  - 缓存产物 JSON 含溯源头（源路径/哈希/解析器版本/解析时间），审计可对账；
  - SHA-256 全文哈希成本 << 解析成本（大 xlsx/PDF 尤其），命中即省全量解析；
  - 与专家模块既有 manifest.sha256 / execution_profile 校验架构同构（同一哈希口径）；
  - **上下文压缩对策（第二收益）**：解析产物落盘 = 单一事实源。长会话被压缩、或换
    会话后，需求不靠对话记忆恢复——直接读盘上缓存/需求索引文件（键含源哈希，文件
    未变即视为仍然有效），配合输入 manifest（路径+sha256）即可无损续跑。

自测（离线）:  python parse_cache.py
"""
import hashlib
import json
import sys
import time
from pathlib import Path


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _cache_path(cache_dir, parser_name, parser_version, key, args_sig=""):
    # 参数签名进文件名：不同过滤条件各自缓存（无参 = noargs），不互相顶掉
    tag = "noargs" if args_sig in ("", "{}") else hashlib.md5(args_sig.encode("utf-8")).hexdigest()[:8]
    return Path(cache_dir) / ("%s_v%s_%s_%s.json" % (parser_name, parser_version, key[:16], tag))


def cached_parse(source, parse_fn, parser_name, parser_version="1",
                 cache_dir=None, parse_args=None, force=False):
    """带缓存解析：源文件 SHA-256 + 解析器版本键控。

    source:      源文件路径（xlsx/ldf/pdf/json...）
    parse_fn:    解析函数，签名 parse_fn(source_path, **parse_args)，返回可 JSON 序列化对象
    parser_name: 解析器名（缓存文件名前缀）
    parser_version: 解析器版本号——解析逻辑变更时必须递增，旧缓存自动失效
    cache_dir:   缓存目录（默认 <源文件目录>/.parse_cache）
    parse_args:  解析函数额外参数（参与缓存键）
    force:       True 时跳过缓存强制重解析（调试用）
    返回:        (result, meta)；meta = {"cache_hit": bool, "cache_file": 路径, "sha256": 键}
    """
    src = Path(source)
    if not src.is_file():
        raise FileNotFoundError(str(src))
    key = sha256_file(src)
    args_sig = json.dumps(parse_args or {}, sort_keys=True, ensure_ascii=False, default=str)
    cache_dir = Path(cache_dir) if cache_dir else src.parent / ".parse_cache"
    cpath = _cache_path(cache_dir, parser_name, parser_version, key, args_sig)

    if not force and cpath.is_file():
        try:
            doc = json.loads(cpath.read_text(encoding="utf-8"))
            prov = doc.get("provenance", {})
            if (prov.get("source_sha256") == key
                    and prov.get("parser_version") == str(parser_version)
                    and prov.get("args_sig") == args_sig
                    and "result" in doc):
                return doc["result"], {"cache_hit": True, "cache_file": str(cpath), "sha256": key}
        except Exception:
            pass  # 缓存损坏视为未命中，重解析重建

    result = parse_fn(src, **(parse_args or {}))
    cache_dir.mkdir(parents=True, exist_ok=True)
    doc = {
        "provenance": {
            "source": str(src),
            "source_sha256": key,
            "parser_name": parser_name,
            "parser_version": str(parser_version),
            "args_sig": args_sig,
            "parsed_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        },
        "result": result,
    }
    cpath.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    return result, {"cache_hit": False, "cache_file": str(cpath), "sha256": key}


if __name__ == "__main__":
    # ---- 离线自测：命中 / 文件变更失效 / 版本失效 / 参数隔离 ----
    import tempfile

    tmp = tempfile.mkdtemp()
    src = Path(tmp) / "demo.xlsx"
    src.write_text("initial", encoding="utf-8")   # 先建源文件（缓存键 = 文件内容哈希）
    calls = {"n": 0}

    def fake_parse(path, extra=None):
        calls["n"] += 1
        return {"sheets": 2, "from": str(path), "extra": extra}

    # 1) 首次解析（未命中）
    r1, m1 = cached_parse(src, fake_parse, "demo", "1", cache_dir=tmp)
    assert not m1["cache_hit"] and calls["n"] == 1
    # 2) 再解析（命中，parse_fn 不被调用）
    r2, m2 = cached_parse(src, fake_parse, "demo", "1", cache_dir=tmp)
    assert m2["cache_hit"] and r2 == r1 and calls["n"] == 1
    # 3) 源文件变更 → 失效重解析
    src.write_text("changed", encoding="utf-8")
    r3, m3 = cached_parse(src, fake_parse, "demo", "1", cache_dir=tmp)
    assert not m3["cache_hit"] and calls["n"] == 2
    # 4) 解析器版本升级 → 失效重解析
    src.write_text("same", encoding="utf-8")
    cached_parse(src, fake_parse, "demo", "1", cache_dir=tmp)
    r4, m4 = cached_parse(src, fake_parse, "demo", "2", cache_dir=tmp)
    assert not m4["cache_hit"] and calls["n"] == 4  # v1("same")未命中=3 + v2未命中=4
    # 5) 参数不同 → 不同缓存键，不串缓存
    cached_parse(src, fake_parse, "demo", "2", cache_dir=tmp)
    r5, m5 = cached_parse(src, fake_parse, "demo", "2", cache_dir=tmp, parse_args={"extra": 1})
    assert not m5["cache_hit"] and r5["extra"] == 1 and calls["n"] == 5  # 新参数=新缓存文件
    r5b, m5b = cached_parse(src, fake_parse, "demo", "2", cache_dir=tmp, parse_args={"extra": 1})
    assert m5b["cache_hit"] and r5b == r5 and calls["n"] == 5            # 同参数再调 → 命中
    # 6) 溯源头完整
    doc = json.loads(Path(m5["cache_file"]).read_text(encoding="utf-8"))
    assert doc["provenance"]["parser_name"] == "demo" and len(doc["provenance"]["source_sha256"]) == 64
    print("SELFTEST OK: 未命中/命中/文件变更失效/版本失效/参数隔离/溯源头 全部通过")
