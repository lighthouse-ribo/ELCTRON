#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""F1L1 多帧应答（LIN TP 流控帧）回归测试；不连接真实硬件。

回归目标（2026-09-14 实机缺陷）：
  默认路径在收到 ECU 首帧(FF)后，必须保证从机能继续发连续帧(CF)——即
  「宽限窗口内没有 CF 就补发主节点流控帧 FC(PCI 0x30, BS=0, STmin=0)」。
  修复前默认路径假设"本 ECU 自动连发 CF、无需 FC"，导致所有 ≥6 字节应答
  （0x22 多字节 DID、EDA0 分区读）在需要 FC 的 ECU 上 100% 超时。

覆盖：
  1. 从机等 FC 才发 CF → 默认路径必须发出 FC 并成功拼包；
  2. 从机自动连发 CF（旧行为）→ 默认路径不得多发 FC（保持兼容）；
  3. 显式传 flow_control → 仍按调用方给定的 BS/STmin 发 FC；
  4. FC_GRACE_MS=0（排障开关）→ 无条件先发 FC。
"""

import ctypes
import importlib.util
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch


SCRIPT_DIR = Path(__file__).resolve().parent
NAD = 0x51

# 真实硬件抓包（2026-09-14）：
#   FF 51 10 0A 62 F1 20 80 04   → total=0x00A=10 字节，首帧带 5 字节 payload
#   CF 51 21 94 11 20 41 41 FF   → 补齐为 62 F1 20 80 04 94 11 20 41 41
FF_FRAME = [NAD, 0x10, 0x0A, 0x62, 0xF1, 0x20, 0x80, 0x04]
CF_FRAME = [NAD, 0x21, 0x94, 0x11, 0x20, 0x41, 0x41, 0xFF]
EXPECTED = [0x62, 0xF1, 0x20, 0x80, 0x04, 0x94, 0x11, 0x20, 0x41, 0x41]


class FakeDll:
    """只记录 0x3C 缓冲区更新，不发真实帧。"""

    def __init__(self):
        self.updates = []

    def xcdev_lin_update_bytearray(self, _channel, lin_id, _start, buf, length, _dev):
        self.updates.append([int(b) for b in buf[:length]])
        return 0


def fake_xcdev_module(dll):
    module = types.ModuleType("xcdev_wrapper")
    module.XC_HARDTYPE_CANVIEX_F1L1 = 3
    module.dll = dll
    module.XC_NETPACK_TYPE_LIN = 1
    module.XC_NETPACK_FLAG_TX = 1

    class xNetpack(ctypes.Structure):
        _fields_ = [("data", ctypes.c_ubyte * 128)]

    class xLinOpt(ctypes.Structure):
        _fields_ = [("brval", ctypes.c_uint), ("mode", ctypes.c_ubyte),
                    ("outputV", ctypes.c_ubyte), ("padding", ctypes.c_ubyte * 14)]

    class xLinEntry(ctypes.Structure):
        _fields_ = [("id", ctypes.c_ubyte), ("channel", ctypes.c_ubyte),
                    ("role", ctypes.c_ubyte), ("rsp", ctypes.c_ubyte),
                    ("length", ctypes.c_uint), ("padding", ctypes.c_ubyte * 8)]

    class xLinAppoint(ctypes.Structure):
        _fields_ = [("ids", ctypes.c_ubyte * 8), ("delay", ctypes.c_uint)]

    module.xNetpack = xNetpack
    module.xLinOpt = xLinOpt
    module.xLinEntry = xLinEntry
    module.xLinAppoint = xLinAppoint
    module.make_lin_opt = lambda brval=19200: xLinOpt(brval=brval, mode=1, outputV=1)
    return module


def load_f1l1(fake_xcdev):
    name = "f1l1_multiframe_test_target"
    spec = importlib.util.spec_from_file_location(name, SCRIPT_DIR / "f1l1_uds.py")
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {"xcdev_wrapper": fake_xcdev}):
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return module


def make_session(frames_when_no_fc, frames_after_fc=()):
    """构造被测 UDS 实例：把 _recv_lin / _tx_wait_echo 换成脚本化假实现。

    返回 (uds, sent_fc, f1l1_module)。
    sent_fc 收集所有已发出的流控帧（PCI 0x30 帧）。
    """
    dll = FakeDll()
    f1l1 = load_f1l1(fake_xcdev_module(dll))
    uds = f1l1.F1L1UDS()
    uds.dev = 1  # 仅供假 _recv_lin/_tx_wait_echo 判定"已打开"

    sent_fc = []
    state = {"fc_done": False, "queue": list(frames_when_no_fc)}
    after_fc = list(frames_after_fc)

    def fake_recv_lin(timeout_ms=200):
        del timeout_ms
        if state["fc_done"]:
            return after_fc.pop(0) if after_fc else None
        return state["queue"].pop(0) if state["queue"] else None

    def fake_tx_wait_echo(data8, timeout=0.4):
        del timeout
        frame = [int(b) for b in data8]
        if len(frame) >= 2 and (frame[1] >> 4) == 0x3:
            sent_fc.append(frame)
            state["fc_done"] = True
        return True

    uds._recv_lin = fake_recv_lin
    uds._tx_wait_echo = fake_tx_wait_echo
    return uds, sent_fc, f1l1


class F1L1MultiframeTests(unittest.TestCase):
    def test_default_path_sends_fc_when_slave_waits(self):
        """从机停在首帧 → 默认路径补发 FC(PCI 0x30)，并成功拼出完整应答。"""
        # 宽限窗口先收到一帧重复首帧（实测行为：0x3C 重发期间从机反复回 FF）
        uds, sent_fc, _ = make_session([FF_FRAME, FF_FRAME], [CF_FRAME])

        resp = uds._recv_response_frames(NAD, timeout=1.0)

        self.assertEqual(resp, EXPECTED)
        self.assertEqual(len(sent_fc), 1, "默认路径必须在宽限窗口无 CF 后补发流控帧")
        self.assertEqual(sent_fc[0][1], 0x30, "流控帧 PCI 必须为 0x30")
        self.assertEqual(sent_fc[0][0], NAD)
        self.assertEqual(sent_fc[0][2:4], [0x00, 0x00], "默认 BS=0 / STmin=0")

    def test_default_path_skips_fc_when_slave_auto_streams(self):
        """旧行为从机自动连发 CF → 默认路径不得多发 FC（保持兼容）。"""
        uds, sent_fc, _ = make_session([FF_FRAME, CF_FRAME])

        resp = uds._recv_response_frames(NAD, timeout=1.0)

        self.assertEqual(resp, EXPECTED)
        self.assertEqual(sent_fc, [], "从机已自动连发时不应补发 FC")

    def test_explicit_flow_control_keeps_caller_bs_stmin(self):
        """显式传参路径仍按调用方给定的 BS/STmin 发 FC（专项测量语义不变）。"""
        uds, sent_fc, _ = make_session([FF_FRAME], [CF_FRAME])

        resp = uds._recv_response_frames(NAD, timeout=1.0, flow_control=(2, 5))

        self.assertEqual(resp, EXPECTED)
        self.assertEqual(len(sent_fc), 1)
        self.assertEqual(sent_fc[0][1], 0x30)
        self.assertEqual(sent_fc[0][2:4], [0x02, 0x05])

    def test_fc_grace_zero_forces_fc_immediately(self):
        """F1L1_FC_GRACE_MS=0（排障开关）→ 不等宽限窗口，无条件先发 FC。"""
        uds, sent_fc, f1l1 = make_session([FF_FRAME], [CF_FRAME])
        f1l1.FC_GRACE_MS = 0

        resp = uds._recv_response_frames(NAD, timeout=1.0)

        self.assertEqual(resp, EXPECTED)
        self.assertEqual(len(sent_fc), 1)

    def test_single_frame_response_needs_no_fc(self):
        """单帧应答路径不受影响：不发 FC。"""
        # 真实抓包：51 02 7E 00 FF FF FF FF（SF, PCI=0x02）
        sf = [NAD, 0x02, 0x7E, 0x00, 0xFF, 0xFF, 0xFF, 0xFF]
        uds, sent_fc, _ = make_session([sf])

        resp = uds._recv_response_frames(NAD, timeout=1.0)

        self.assertEqual(resp, [0x7E, 0x00])
        self.assertEqual(sent_fc, [])


if __name__ == "__main__":
    unittest.main()
