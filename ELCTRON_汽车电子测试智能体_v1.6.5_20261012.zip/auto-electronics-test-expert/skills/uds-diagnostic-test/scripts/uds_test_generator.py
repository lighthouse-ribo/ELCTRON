#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UDS测试脚本生成器
基于解析后的诊断调查表JSON生成可执行的测试脚本
生成的脚本包含完整的 Vector (XL Driver Library) CAN 通信、UDS 协议和测试报告功能
"""

__version__ = "1.7.1"

import argparse
import json
import os
import sys
import textwrap
from datetime import datetime


# ============================================================================
# 测试脚本模板
# ============================================================================

from script_header_template import SCRIPT_HEADER  # B1 Phase1: 模板原样搬移至 script_header_template.py（值 MD5 不变，2026-09-04）


def generate_did_read_tests(dids):
    """生成DID读取测试方法"""
    methods = []
    calls = []

    if not dids:
        return "", ""

    method = []
    method.append('    def test_read_dids(self):')
    method.append('        """测试 $22 ReadDataByIdentifier"""')
    method.append('        print("\\n=== 测试 $22 ReadDataByIdentifier ===")')
    method.append('')

    for did in dids:
        did_num = did["did_number"]
        did_name = did.get("did_name", "Unknown")
        did_int = int(did_num, 16)
        size = did.get("size_bytes", 1)
        rw = did.get("rw_state", "R").upper()
        func_addr = did.get("functional_addressing", "N")

        if "R" not in rw:
            continue

        read_sessions = did.get("read_sessions", {})
        read_security = did.get("read_security", {})
        data_type = did.get("data_type", "RAW").upper()

        # 提取读取所需的SA等级
        read_sa_level = None
        read_sa_name = "无"
        for key, sa_val in [("level1", 0x01), ("level_fbl", 0x03), ("level_immo", 0x05)]:
            if read_security.get(key, "N").upper() == "Y":
                read_sa_level = sa_val
                read_sa_name = {"level1": "Level1", "level_fbl": "Level3(FBL)", "level_immo": "Level5(IMMO)"}[key]
                break
        needs_read_security = read_sa_level is not None

        # 生成每个会话的测试
        for session_key, session_val in [
            ("default_0x01", 0x01),
            ("programming_0x02", 0x02),
            ("extended_0x03", 0x03),
        ]:
            supported = read_sessions.get(session_key, "N") == "Y"
            session_name = SESSION_NAMES_MAP.get(session_val, f"0x{session_val:02X}")

            method.append(f'        # DID {did_num} - {did_name} - 会话 {session_name}')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        self.switch_session(0x{session_val:02X})')
            method.append(f'        time.sleep(0.05)')

            # 对于有安全访问需求的DID，在支持的会话中先解锁
            if supported and needs_read_security:
                method.append(f'        self.unlock_security(0x{read_sa_level:02X})  # {read_sa_name}')

            method.append(f'        resp = self.uds.read_did(0x{did_int:04X})')

            if supported:
                method.append(f'        if self.is_positive_response(resp, SID_READ_DID):')
                method.append(f'            resp_len = len(resp) - 3  # 减去SID+DID两字节')
                method.append(f'            len_ok = resp_len == {size}')
                # 数值范围校验 (仅数值型DID)
                range_min = did.get("range_min", 0)
                range_max = did.get("range_max", None)
                has_numeric_range = (isinstance(range_min, (int, float)) and
                                     isinstance(range_max, (int, float)) and
                                     data_type not in ("ASCII", "BCD"))
                if has_numeric_range:
                    r_min = int(range_min)
                    r_max = int(range_max)
                    method.append(f'            # 数据范围校验: [{r_min}, {r_max}]')
                    method.append(f'            data_bytes = resp[3:]')
                    method.append(f'            data_val = int.from_bytes(data_bytes, "big") if data_bytes else 0')
                    method.append(f'            range_ok = {r_min} <= data_val <= {r_max}')
                    method.append(f'            self.add_result(')
                    method.append(f'                service="$22", test_name="读取{did_num} {did_name[:20]}({session_name})",')
                    method.append(f'                did_rid="{did_num}", session="{session_name}",')
                    method.append(f'                expected="正响应+长度{size}B+范围[{r_min},{r_max}]",')
                    method.append(f'                actual=self.resp_to_hex(resp),')
                    method.append(f'                status="PASS" if (len_ok and range_ok) else "FAIL",')
                    method.append(f'                detail=f"len={{resp_len}}/{size} val={{data_val}} range=[{r_min},{r_max}] " +')
                    method.append(f'                    ("" if (len_ok and range_ok) else ("长度不匹配" if not len_ok else "范围越界")))')
                else:
                    method.append(f'            self.add_result(')
                    method.append(f'                service="$22", test_name="读取{did_num} {did_name[:20]}({session_name})",')
                    method.append(f'                did_rid="{did_num}", session="{session_name}",')
                    method.append(f'                expected="正响应+长度{size}B",')
                    method.append(f'                actual=self.resp_to_hex(resp),')
                    method.append(f'                status="PASS" if len_ok else "FAIL",')
                    method.append(f'                detail="" if len_ok else f"长度不匹配:期望{size},实际{{resp_len}}")')
                method.append(f'        else:')
                method.append(f'            self.add_result(')
                method.append(f'                service="$22", test_name="读取{did_num} {did_name[:20]}({session_name})",')
                method.append(f'                did_rid="{did_num}", session="{session_name}",')
                method.append(f'                expected="正响应 0x62",')
                method.append(f'                actual=self.resp_to_hex(resp), status="FAIL")')
            else:
                method.append(f'        if self.is_negative_response(resp):')
                method.append(f'            nrc = self.get_nrc(resp)')
                method.append(f'            self.add_result(')
                method.append(f'                service="$22", test_name="读取{did_num}({session_name})应拒绝",')
                method.append(f'                did_rid="{did_num}", session="{session_name}",')
                method.append(f'                expected="NRC 0x7F/0x31/0x22",')
                method.append(f'                actual=self.resp_to_hex(resp),')
                method.append(f'                status="PASS" if nrc in (0x7F, 0x31, 0x22, 0x33, 0x11) else "FAIL")')
                method.append(f'        elif self.is_positive_response(resp, SID_READ_DID):')
                method.append(f'            self.add_result(')
                method.append(f'                service="$22", test_name="读取{did_num}({session_name})应拒绝",')
                method.append(f'                did_rid="{did_num}", session="{session_name}",')
                method.append(f'                expected="NRC", actual="意外的正响应", status="FAIL")')
                method.append(f'        else:')
                method.append(f'            self.add_result(')
                method.append(f'                service="$22", test_name="读取{did_num}({session_name})应拒绝",')
                method.append(f'                did_rid="{did_num}", session="{session_name}",')
                method.append(f'                expected="NRC", actual=self.resp_to_hex(resp), status="FAIL")')

            method.append('')

        # 有安全访问需求的DID: 不解锁时应返回NRC 0x33
        if needs_read_security:
            # 找一个支持的会话来测试
            for sk2, sv2 in [("default_0x01", 0x01), ("programming_0x02", 0x02), ("extended_0x03", 0x03)]:
                if read_sessions.get(sk2, "N") == "Y":
                    sn2 = SESSION_NAMES_MAP.get(sv2, f"0x{sv2:02X}")
                    method.append(f'        # DID {did_num} - 无安全访问读取 (需要{read_sa_name})')
                    method.append(f'        self.reset_to_default_session()')
                    method.append(f'        self.switch_session(0x{sv2:02X})')
                    method.append(f'        time.sleep(0.05)')
                    method.append(f'        resp = self.uds.read_did(0x{did_int:04X})  # 不先解锁')
                    method.append(f'        if self.is_negative_response(resp, 0x33):')
                    method.append(f'            self.add_result(')
                    method.append(f'                service="$22", test_name="读取{did_num}无SA解锁→NRC0x33",')
                    method.append(f'                did_rid="{did_num}", session="{sn2}", security="{read_sa_name}",')
                    method.append(f'                expected="NRC 0x33", actual=self.resp_to_hex(resp), status="PASS")')
                    method.append(f'        else:')
                    method.append(f'            self.add_result(')
                    method.append(f'                service="$22", test_name="读取{did_num}无SA解锁",')
                    method.append(f'                did_rid="{did_num}", session="{sn2}", security="{read_sa_name}",')
                    method.append(f'                expected="NRC 0x33", actual=self.resp_to_hex(resp),')
                    method.append(f'                status="PASS" if (self.is_positive_response(resp, SID_READ_DID) or')
                    method.append(f'                                  self.is_negative_response(resp)) else "FAIL",')
                    method.append(f'                detail="可能ECU不要求SA或通过其他方式授权")')
                    method.append('')
                    break

        # 功能寻址测试
        if func_addr == "Y":
            method.append(f'        # DID {did_num} - 功能寻址测试')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        resp = self.uds.read_did(0x{did_int:04X}, functional=True)')
            method.append(f'        if self.is_positive_response(resp, SID_READ_DID):')
            method.append(f'            self.add_result(')
            method.append(f'                service="$22", test_name="功能寻址读取{did_num}",')
            method.append(f'                did_rid="{did_num}", session="Default",')
            method.append(f'                expected="正响应", actual=self.resp_to_hex(resp), status="PASS")')
            method.append(f'        else:')
            method.append(f'            self.add_result(')
            method.append(f'                service="$22", test_name="功能寻址读取{did_num}",')
            method.append(f'                did_rid="{did_num}", session="Default",')
            method.append(f'                expected="正响应", actual=self.resp_to_hex(resp), status="FAIL")')
            method.append('')

        # 错误长度测试
        method.append(f'        # DID {did_num} - 错误长度请求')
        method.append(f'        self.reset_to_default_session()')
        method.append(f'        resp = self.uds.send_request([SID_READ_DID, 0x{(did_int >> 8) & 0xFF:02X}])  # 缺少DID低字节')
        method.append(f'        if self.is_negative_response(resp, 0x13):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$22", test_name="错误长度读取{did_num}",')
        method.append(f'                did_rid="{did_num}",')
        method.append(f'                expected="NRC 0x13", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$22", test_name="错误长度读取{did_num}",')
        method.append(f'                did_rid="{did_num}",')
        method.append(f'                expected="NRC 0x13", actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

    method.append('        self.reset_to_default_session()')
    methods.append('\n'.join(method))
    calls.append('            self.test_read_dids()')

    return '\n\n'.join(methods), '\n'.join(calls)


def generate_did_write_tests(dids):
    """生成DID写入测试方法"""
    write_dids = [d for d in dids if "W" in d.get("rw_state", "R").upper()]
    if not write_dids:
        return "", ""

    method = []
    method.append('    def test_write_dids(self):')
    method.append('        """测试 $2E WriteDataByIdentifier"""')
    method.append('        print("\\n=== 测试 $2E WriteDataByIdentifier ===")')
    method.append('')

    for did in write_dids:
        did_num = did["did_number"]
        did_name = did.get("did_name", "Unknown")
        did_int = int(did_num, 16)
        size = did.get("size_bytes", 1)
        data_type = did.get("data_type", "RAW").upper()

        write_sessions = did.get("write_sessions", {})
        write_security = did.get("write_security", {})

        # 生成测试数据
        if "ASCII" in data_type:
            test_data_str = f'[0x41] * {size}  # "AAA..."'
        else:
            test_data_str = f'[0x00] * {size}'

        # 在不支持的会话中写入
        for session_key, session_val in [
            ("default_0x01", 0x01),
            ("programming_0x02", 0x02),
            ("extended_0x03", 0x03),
        ]:
            supported = write_sessions.get(session_key, "N") == "Y"
            session_name = SESSION_NAMES_MAP.get(session_val, f"0x{session_val:02X}")

            if not supported:
                method.append(f'        # DID {did_num} 写入 - 不支持的会话 {session_name}')
                method.append(f'        self.switch_session(0x{session_val:02X})')
                method.append(f'        time.sleep(0.05)')
                method.append(f'        test_data = {test_data_str}')
                method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, test_data)')
                method.append(f'        if self.is_negative_response(resp):')
                method.append(f'            self.add_result(')
                method.append(f'                service="$2E", test_name="写入{did_num}({session_name})应拒绝",')
                method.append(f'                did_rid="{did_num}", session="{session_name}",')
                method.append(f'                expected="NRC", actual=self.resp_to_hex(resp), status="PASS")')
                method.append(f'        else:')
                method.append(f'            self.add_result(')
                method.append(f'                service="$2E", test_name="写入{did_num}({session_name})应拒绝",')
                method.append(f'                did_rid="{did_num}", session="{session_name}",')
                method.append(f'                expected="NRC", actual=self.resp_to_hex(resp), status="FAIL")')
                method.append('')

        # 无安全访问写入（在支持的会话中）
        supported_sessions = [(k, v) for k, v in [
            ("default_0x01", 0x01), ("programming_0x02", 0x02), ("extended_0x03", 0x03)
        ] if write_sessions.get(k, "N") == "Y"]

        if supported_sessions:
            sk, sv = supported_sessions[0]
            session_name = SESSION_NAMES_MAP.get(sv, f"0x{sv:02X}")

            # 需要安全访问但未解锁
            needs_security = any(v == "Y" for k, v in write_security.items() if k != "level0_locked")

            # 提取具体SA等级
            sa_level = None
            sa_level_name = "无"
            for key, sa_val in [("level1", 0x01), ("level_fbl", 0x03), ("level_immo", 0x05)]:
                if write_security.get(key, "N").upper() == "Y":
                    sa_level = sa_val
                    sa_level_name = {"level1": "Level1", "level_fbl": "Level3(FBL)", "level_immo": "Level5(IMMO)"}[key]
                    break  # 取最高优先级的

            if needs_security:
                method.append(f'        # DID {did_num} 写入 - 无安全访问 (需要{sa_level_name})')
                method.append(f'        self.reset_to_default_session()')
                method.append(f'        self.switch_session(0x{sv:02X})')
                method.append(f'        time.sleep(0.05)')
                method.append(f'        test_data = {test_data_str}')
                method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, test_data)')
                method.append(f'        if self.is_negative_response(resp, 0x33):')
                method.append(f'            self.add_result(')
                method.append(f'                service="$2E", test_name="写入{did_num}无安全访问→NRC0x33",')
                method.append(f'                did_rid="{did_num}", session="{session_name}", security="{sa_level_name}",')
                method.append(f'                expected="NRC 0x33", actual=self.resp_to_hex(resp), status="PASS")')
                method.append(f'        else:')
                method.append(f'            self.add_result(')
                method.append(f'                service="$2E", test_name="写入{did_num}无安全访问",')
                method.append(f'                did_rid="{did_num}", session="{session_name}", security="{sa_level_name}",')
                method.append(f'                expected="NRC 0x33", actual=self.resp_to_hex(resp),')
                method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
                method.append('')

                # SA解锁后正向写入测试
                if sa_level is not None:
                    method.append(f'        # DID {did_num} 写入 - SA解锁后 (SA=0x{sa_level:02X} {sa_level_name})')
                    method.append(f'        self.reset_to_default_session()')
                    method.append(f'        self.switch_session(0x{sv:02X})')
                    method.append(f'        time.sleep(0.05)')
                    method.append(f'        self.unlock_security(0x{sa_level:02X})')
                    method.append(f'        test_data = {test_data_str}')
                    method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, test_data)')
                    method.append(f'        if self.is_positive_response(resp, SID_WRITE_DID):')
                    method.append(f'            self.add_result(')
                    method.append(f'                service="$2E", test_name="写入{did_num} SA解锁后成功",')
                    method.append(f'                did_rid="{did_num}", session="{session_name}", security="{sa_level_name}",')
                    method.append(f'                expected="正响应 0x6E", actual=self.resp_to_hex(resp), status="PASS")')
                    method.append(f'        else:')
                    method.append(f'            nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
                    method.append(f'            self.add_result(')
                    method.append(f'                service="$2E", test_name="写入{did_num} SA解锁后",')
                    method.append(f'                did_rid="{did_num}", session="{session_name}", security="{sa_level_name}",')
                    method.append(f'                expected="正响应 0x6E", actual=self.resp_to_hex(resp),')
                    method.append(f'                status="PASS" if nrc in (0x22, 0x72) else "FAIL",')
                    method.append(f'                detail="NRC 0x22(条件不满足)/0x72可接受")')
                    method.append('')

        # 错误长度写入
        if supported_sessions:
            sk, sv = supported_sessions[0]
            session_name = SESSION_NAMES_MAP.get(sv, f"0x{sv:02X}")
            wrong_size = max(1, size + 3)
            method.append(f'        # DID {did_num} 写入 - 错误长度')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        self.switch_session(0x{sv:02X})')
            method.append(f'        time.sleep(0.05)')
            method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, [0x00] * {wrong_size})')
            method.append(f'        if self.is_negative_response(resp, 0x13):')
            method.append(f'            self.add_result(')
            method.append(f'                service="$2E", test_name="过长数据写入{did_num}({wrong_size}B>期望{size}B)",')
            method.append(f'                did_rid="{did_num}", session="{session_name}",')
            method.append(f'                expected="NRC 0x13", actual=self.resp_to_hex(resp), status="PASS")')
            method.append(f'        else:')
            method.append(f'            self.add_result(')
            method.append(f'                service="$2E", test_name="过长数据写入{did_num}({wrong_size}B>期望{size}B)",')
            method.append(f'                did_rid="{did_num}", session="{session_name}",')
            method.append(f'                expected="NRC 0x13", actual=self.resp_to_hex(resp),')
            method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
            method.append('')

            # 过短数据写入 (仅DID无数据)
            method.append(f'        # DID {did_num} 写入 - 过短数据(0字节)')
            method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, [])')
            method.append(f'        if self.is_negative_response(resp, 0x13):')
            method.append(f'            self.add_result(')
            method.append(f'                service="$2E", test_name="过短数据写入{did_num}(0B<期望{size}B)",')
            method.append(f'                did_rid="{did_num}", session="{session_name}",')
            method.append(f'                expected="NRC 0x13", actual=self.resp_to_hex(resp), status="PASS")')
            method.append(f'        else:')
            method.append(f'            self.add_result(')
            method.append(f'                service="$2E", test_name="过短数据写入{did_num}(0B<期望{size}B)",')
            method.append(f'                did_rid="{did_num}", session="{session_name}",')
            method.append(f'                expected="NRC 0x13", actual=self.resp_to_hex(resp),')
            method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
            method.append('')

            if size > 1:
                short_size = size - 1
                method.append(f'        # DID {did_num} 写入 - 少1字节({short_size}B<期望{size}B)')
                method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, [0x00] * {short_size})')
                method.append(f'        if self.is_negative_response(resp, 0x13):')
                method.append(f'            self.add_result(')
                method.append(f'                service="$2E", test_name="少1字节写入{did_num}({short_size}B<期望{size}B)",')
                method.append(f'                did_rid="{did_num}", session="{session_name}",')
                method.append(f'                expected="NRC 0x13", actual=self.resp_to_hex(resp), status="PASS")')
                method.append(f'        else:')
                method.append(f'            self.add_result(')
                method.append(f'                service="$2E", test_name="少1字节写入{did_num}({short_size}B<期望{size}B)",')
                method.append(f'                did_rid="{did_num}", session="{session_name}",')
                method.append(f'                expected="NRC 0x13", actual=self.resp_to_hex(resp),')
                method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
                method.append('')

        # 数据范围越界写入测试 (需要有写入会话和数值型range)
        range_min = did.get("range_min", 0)
        range_max = did.get("range_max", None)
        if supported_sessions and isinstance(range_min, (int, float)) and isinstance(range_max, (int, float)):
            sk, sv = supported_sessions[0]
            session_name = SESSION_NAMES_MAP.get(sv, f"0x{sv:02X}")
            r_min = int(range_min)
            r_max = int(range_max)
            byte_max = (1 << (size * 8)) - 1

            # 在有SA需求时先解锁
            unlock_code = ""
            if sa_level is not None:
                unlock_code = f"\n        self.unlock_security(0x{sa_level:02X})"

            # 超上限值测试 (range_max + 1, 如果不超过字节容量)
            if r_max < byte_max:
                over_val = r_max + 1
                over_bytes = []
                for bi in range(size - 1, -1, -1):
                    over_bytes.append(f"0x{(over_val >> (bi * 8)) & 0xFF:02X}")
                over_bytes_str = f"[{', '.join(over_bytes)}]"

                method.append(f'        # DID {did_num} 写入 - 超上限值({over_val} > max {r_max})')
                method.append(f'        self.reset_to_default_session()')
                method.append(f'        self.switch_session(0x{sv:02X})')
                method.append(f'        time.sleep(0.05)')
                if unlock_code:
                    method.append(f'        self.unlock_security(0x{sa_level:02X})')
                method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, {over_bytes_str})')
                method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
                method.append(f'        self.add_result(')
                method.append(f'            service="$2E", test_name="超上限写入{did_num}(val={over_val}>max={r_max})",')
                method.append(f'            did_rid="{did_num}", session="{session_name}",')
                method.append(f'            expected="NRC 0x31(requestOutOfRange)",')
                method.append(f'            actual=self.resp_to_hex(resp),')
                method.append(f'            status="PASS" if nrc in (0x31, 0x72, 0x22) else "FAIL",')
                method.append(f'            detail="超范围写入应返回NRC 0x31/0x22")')
                method.append('')

            # 超下限值测试 (range_min - 1, 如果 > 0)
            if r_min > 0:
                under_val = r_min - 1
                under_bytes = []
                for bi in range(size - 1, -1, -1):
                    under_bytes.append(f"0x{(under_val >> (bi * 8)) & 0xFF:02X}")
                under_bytes_str = f"[{', '.join(under_bytes)}]"

                method.append(f'        # DID {did_num} 写入 - 低于下限值({under_val} < min {r_min})')
                method.append(f'        self.reset_to_default_session()')
                method.append(f'        self.switch_session(0x{sv:02X})')
                method.append(f'        time.sleep(0.05)')
                if unlock_code:
                    method.append(f'        self.unlock_security(0x{sa_level:02X})')
                method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, {under_bytes_str})')
                method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
                method.append(f'        self.add_result(')
                method.append(f'            service="$2E", test_name="低于下限写入{did_num}(val={under_val}<min={r_min})",')
                method.append(f'            did_rid="{did_num}", session="{session_name}",')
                method.append(f'            expected="NRC 0x31(requestOutOfRange)",')
                method.append(f'            actual=self.resp_to_hex(resp),')
                method.append(f'            status="PASS" if nrc in (0x31, 0x72, 0x22) else "FAIL",')
                method.append(f'            detail="低于范围写入应返回NRC 0x31/0x22")')
                method.append('')

            # 全FF写入测试 (最大字节值)
            if byte_max > r_max:
                method.append(f'        # DID {did_num} 写入 - 全0xFF(字节最大值)')
                method.append(f'        self.reset_to_default_session()')
                method.append(f'        self.switch_session(0x{sv:02X})')
                method.append(f'        time.sleep(0.05)')
                if unlock_code:
                    method.append(f'        self.unlock_security(0x{sa_level:02X})')
                method.append(f'        resp = self.uds.write_did(0x{did_int:04X}, [0xFF] * {size})')
                method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
                method.append(f'        self.add_result(')
                method.append(f'            service="$2E", test_name="全FF写入{did_num}(0x{"FF"*size})",')
                method.append(f'            did_rid="{did_num}", session="{session_name}",')
                method.append(f'            expected="NRC 0x31(超范围)或正响应(看ECU)",')
                method.append(f'            actual=self.resp_to_hex(resp),')
                method.append(f'            status="PASS" if resp is not None else "FAIL",')
                method.append(f'            detail="全FF写入 — ECU行为可能因实现而异")')
                method.append('')

    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_write_dids()'


def generate_multi_did_read_tests(dids):
    """生成多DID单次读取测试方法 - ISO 14229 $22支持一次请求多个DID"""
    readable_dids = [d for d in dids if "R" in d.get("rw_state", "R").upper()]
    if len(readable_dids) < 2:
        return "", ""

    method = []
    method.append('    def test_multi_did_read(self):')
    method.append('        """测试 $22 多DID单次读取"""')
    method.append('        print("\\n=== 测试 $22 多DID单次读取 ===")')
    method.append('')
    method.append('        self.reset_to_default_session()')
    method.append('        time.sleep(0.05)')

    # 取默认会话下可读的前几个DID
    default_readable = []
    for d in readable_dids:
        if d.get("read_sessions", {}).get("default_0x01", "N") == "Y":
            default_readable.append(d)
        if len(default_readable) >= 5:
            break

    # 兜底：默认会话无可读 DID 时，用任意可读 DID 或公共 DID 0xF186 供“有效+无效”测试使用
    fallback_did = (default_readable[0] if default_readable
                    else readable_dids[0] if readable_dids else {"did_number": "0xF186"})
    d1_int = int(fallback_did["did_number"], 16)

    if len(default_readable) >= 2:
        # 2个DID
        d1, d2 = default_readable[0], default_readable[1]
        d1_int = int(d1["did_number"], 16)
        d2_int = int(d2["did_number"], 16)
        method.append(f'        # 读取2个DID: {d1["did_number"]} + {d2["did_number"]}')
        method.append(f'        req = [SID_READ_DID, 0x{(d1_int>>8)&0xFF:02X}, 0x{d1_int&0xFF:02X}, 0x{(d2_int>>8)&0xFF:02X}, 0x{d2_int&0xFF:02X}]')
        method.append(f'        resp = self.uds.send_request(req)')
        method.append(f'        if self.is_positive_response(resp, SID_READ_DID):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$22", test_name="多DID读取({d1["did_number"]}+{d2["did_number"]})",')
        method.append(f'                expected="正响应含两个DID数据", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        elif self.is_negative_response(resp):')
        method.append(f'            nrc = self.get_nrc(resp)')
        method.append(f'            self.add_result(')
        method.append(f'                service="$22", test_name="多DID读取({d1["did_number"]}+{d2["did_number"]})",')
        method.append(f'                expected="正响应或NRC",')
        method.append(f'                actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if nrc == 0x14 else "FAIL",')
        method.append(f'                detail="NRC 0x14=responseTooLong是可接受的")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$22", test_name="多DID读取({d1["did_number"]}+{d2["did_number"]})",')
        method.append(f'                expected="正响应", actual=self.resp_to_hex(resp), status="FAIL")')
        method.append('')

    if len(default_readable) >= 3:
        # 3个DID
        d3 = default_readable[2]
        d3_int = int(d3["did_number"], 16)
        method.append(f'        # 读取3个DID')
        method.append(f'        req = [SID_READ_DID, 0x{(d1_int>>8)&0xFF:02X}, 0x{d1_int&0xFF:02X}, 0x{(d2_int>>8)&0xFF:02X}, 0x{d2_int&0xFF:02X}, 0x{(d3_int>>8)&0xFF:02X}, 0x{d3_int&0xFF:02X}]')
        method.append(f'        resp = self.uds.send_request(req)')
        method.append(f'        self.add_result(')
        method.append(f'            service="$22", test_name="多DID读取(3个DID)",')
        method.append(f'            expected="正响应或NRC 0x14",')
        method.append(f'            actual=self.resp_to_hex(resp),')
        method.append(f'            status="PASS" if (self.is_positive_response(resp, SID_READ_DID) or self.is_negative_response(resp)) else "FAIL")')
        method.append('')

    # 一个有效DID + 一个无效DID
    method.append(f'        # 有效DID + 无效DID 0xFFFF (混合有效/无效)')
    method.append(f'        req = [SID_READ_DID, 0x{(d1_int>>8)&0xFF:02X}, 0x{d1_int&0xFF:02X}, 0xFF, 0xFF]')
    method.append(f'        resp = self.uds.send_request(req)')
    method.append(f'        self.add_result(')
    method.append(f'            service="$22", test_name="多DID读取(有效+无效0xFFFF)",')
    method.append(f'            expected="NRC 0x31或部分响应",')
    method.append(f'            actual=self.resp_to_hex(resp),')
    method.append(f'            status="PASS" if resp is not None else "FAIL")')
    method.append('')

    # 5+个DID读取 → 测试NRC 0x14 responseTooLong
    if len(default_readable) >= 5:
        did_bytes = []
        did_names = []
        for dr in default_readable[:5]:
            di = int(dr["did_number"], 16)
            did_bytes.extend([f'0x{(di>>8)&0xFF:02X}', f'0x{di&0xFF:02X}'])
            did_names.append(dr["did_number"])
        method.append(f'        # 5个DID同时读取 → 可能NRC 0x14 responseTooLong')
        method.append(f'        req = [SID_READ_DID, {", ".join(did_bytes)}]')
        method.append(f'        resp = self.uds.send_request(req)')
        method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
        method.append(f'        self.add_result(')
        method.append(f'            service="$22", test_name="多DID读取(5个: {"+".join(did_names)})",')
        method.append(f'            expected="正响应或NRC 0x14",')
        method.append(f'            actual=self.resp_to_hex(resp),')
        method.append(f'            status="PASS" if (self.is_positive_response(resp, SID_READ_DID) or nrc == 0x14) else')
        method.append(f'                   ("PASS" if self.is_negative_response(resp) else "FAIL"),')
        method.append(f'            detail="NRC 0x14=responseTooLong 当多个DID响应超过单帧容量时")')
        method.append('')

    # 响应长度验证 - 单DID读取后验证DID echo
    method.append(f'        # DID echo验证 - 响应中DID应与请求匹配')
    method.append(f'        resp = self.uds.read_did(0x{d1_int:04X})')
    method.append(f'        if self.is_positive_response(resp, SID_READ_DID) and len(resp) >= 3:')
    method.append(f'            echo_did = (resp[1] << 8) | resp[2]')
    method.append(f'            self.add_result(')
    method.append(f'                service="$22", test_name="DID echo验证({fallback_did["did_number"]})",')
    method.append(f'                expected="响应中DID=0x{d1_int:04X}",')
    method.append(f'                actual=f"echo DID=0x{{echo_did:04X}}",')
    method.append(f'                status="PASS" if echo_did == 0x{d1_int:04X} else "FAIL")')
    method.append(f'        else:')
    method.append(f'            self.add_result(')
    method.append(f'                service="$22", test_name="DID echo验证({fallback_did["did_number"]})",')
    method.append(f'                expected="正响应含DID", actual=self.resp_to_hex(resp),')
    method.append(f'                status="FAIL" if resp is not None and not self.is_positive_response(resp, SID_READ_DID) else "PASS")')
    method.append('')

    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_multi_did_read()'


def generate_functional_write_reject_tests(dids):
    """生成功能寻址写入拒绝测试 - $2E功能寻址应被拒绝"""
    write_dids = [d for d in dids if "W" in d.get("rw_state", "R").upper()]
    if not write_dids:
        return "", ""

    method = []
    method.append('    def test_functional_write_reject(self):')
    method.append('        """测试 $2E 功能寻址写入应被拒绝"""')
    method.append('        print("\\n=== 测试 $2E 功能寻址写入拒绝 ===")')
    method.append('')

    # 只取第一个可写DID做测试
    did = write_dids[0]
    did_num = did["did_number"]
    did_int = int(did_num, 16)
    size = did.get("size_bytes", 1)

    method.append(f'        # 功能寻址$2E应被拒绝或无响应')
    method.append(f'        self.reset_to_default_session()')
    method.append(f'        self.switch_session(SESSION_EXTENDED)')
    method.append(f'        time.sleep(0.05)')
    method.append(f'        req = [SID_WRITE_DID, 0x{(did_int>>8)&0xFF:02X}, 0x{did_int&0xFF:02X}] + [0x00] * {size}')
    method.append(f'        resp = self.uds.send_request(req, functional=True)')
    method.append(f'        if resp is None or self.is_negative_response(resp):')
    method.append(f'            self.add_result(')
    method.append(f'                service="$2E", test_name="功能寻址写入{did_num}应拒绝",')
    method.append(f'                did_rid="{did_num}",')
    method.append(f'                expected="NRC或无响应", actual=self.resp_to_hex(resp), status="PASS")')
    method.append(f'        else:')
    method.append(f'            self.add_result(')
    method.append(f'                service="$2E", test_name="功能寻址写入{did_num}应拒绝",')
    method.append(f'                did_rid="{did_num}",')
    method.append(f'                expected="NRC或无响应", actual=self.resp_to_hex(resp), status="FAIL",')
    method.append(f'                detail="ISO 14229: $2E不应支持功能寻址")')
    method.append('')
    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_functional_write_reject()'


def generate_did_timing_tests(dids):
    """生成DID级P2时间验证测试"""
    readable_dids = [d for d in dids if "R" in d.get("rw_state", "R").upper()
                     and d.get("read_sessions", {}).get("default_0x01", "N") == "Y"]
    if not readable_dids:
        return "", ""

    # 取前5个可读DID做P2测试
    test_dids = readable_dids[:5]

    method = []
    method.append('    def test_did_response_timing(self):')
    method.append('        """测试各DID P2响应时间合规"""')
    method.append('        print("\\n=== 测试 DID P2响应时间 ===")')
    method.append('')
    method.append('        self.reset_to_default_session()')
    method.append('        time.sleep(0.1)')

    for did in test_dids:
        did_num = did["did_number"]
        did_int = int(did_num, 16)
        did_name = did.get("did_name", "Unknown")[:20]

        method.append(f'        # P2 timing: {did_num} {did_name}')
        method.append(f'        resp, elapsed = self.uds.send_request_timed([SID_READ_DID, 0x{(did_int>>8)&0xFF:02X}, 0x{did_int&0xFF:02X}])')
        method.append(f'        p2_ok = elapsed <= P2_TIMEOUT * 1.1')
        method.append(f'        self.add_result(')
        method.append(f'            service="Timing", test_name="P2 DID {did_num} {did_name}",')
        method.append(f'            did_rid="{did_num}",')
        method.append(f'            expected=f"<={{P2_TIMEOUT}}ms",')
        method.append(f'            actual=f"{{elapsed:.1f}}ms",')
        method.append(f'            status="PASS" if (p2_ok and resp is not None) else ("FAIL" if resp is not None else "FAIL"),')
        method.append(f'            detail="P2超时" if not p2_ok else "")')
        method.append('')

    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_did_response_timing()'


def select_timing_did(dids):
    """选择旧版通用生成器的 DID 时序对象。

    BBS 的 F190 未在 APP/PBL/SBL DID 矩阵中定义，不能作为默认探针。
    优先使用已知的活动会话 DID F186；否则从调查表中选择明确可读的
    DID，最后才使用调查表中存在但会话权限尚未补齐的读 DID。没有 DID
    资料时返回 None，由调用方生成一个不执行的保守请求，避免伪造 F190。
    """
    records = [item for item in (dids or []) if isinstance(item, dict)]

    def did_number(item):
        raw = str(item.get("did_number", "")).strip().upper().replace("0X", "")
        try:
            return int(raw, 16)
        except (TypeError, ValueError):
            return None

    readable = [item for item in records
                if "R" in str(item.get("rw_state", "")).upper()
                and did_number(item) is not None]
    for item in readable:
        if did_number(item) == 0xF186:
            return (0xF1, 0x86)
    for item in readable:
        sessions = item.get("read_sessions") or {}
        if str(sessions.get("default_0x01", "")).strip().upper() in {"Y", "YES", "TRUE", "1"}:
            value = did_number(item)
            return ((value >> 8) & 0xFF, value & 0xFF)
    if readable:
        value = did_number(readable[0])
        return ((value >> 8) & 0xFF, value & 0xFF)
    return None


def generate_routine_timing_tests(routines):
    """生成Routine P2响应时间测试"""
    if not routines:
        return "", ""

    method = []
    method.append('    def test_routine_response_timing(self):')
    method.append('        """测试 $31 RoutineControl P2响应时间"""')
    method.append('        print("\\n=== 测试 $31 Routine P2响应时间 ===")')
    method.append('')

    for routine in routines:
        rid_num = routine["rid_number"]
        rid_name = routine.get("rid_name", "Unknown")[:20]
        rid_int = int(rid_num, 16)
        conditions = routine.get("conditions", "Extended Session")
        security = routine.get("security_level", "Level1")

        # 确定会话
        if "program" in conditions.lower():
            target_session = 0x02
            session_name = "Programming"
        elif "extend" in conditions.lower():
            target_session = 0x03
            session_name = "Extended"
        else:
            target_session = 0x01
            session_name = "Default"

        # 解析SA
        sa_level = None
        if security:
            s = security.strip().lower()
            if "3" in s or "fbl" in s or "prog" in s:
                sa_level = 0x03
            elif "5" in s or "immo" in s:
                sa_level = 0x05
            elif "1" in s:
                sa_level = 0x01

        # 构建参数
        req_params = routine.get("req_parameters", [])
        req_data = []
        for p in req_params:
            bit_len = safe_int_gen(p.get("bit_length", 8))
            byte_len = max(1, (bit_len + 7) // 8)
            req_data.extend([0x00] * byte_len)
        req_data_str = str(req_data) if req_data else "[]"

        method.append(f'        # Routine {rid_num} - {rid_name} P2时间测量')
        method.append(f'        self.reset_to_default_session()')
        method.append(f'        self.switch_session(0x{target_session:02X})')
        method.append(f'        time.sleep(0.05)')
        if sa_level is not None:
            method.append(f'        self.unlock_security(0x{sa_level:02X})')
        # 构建原始请求以使用send_request_timed
        rid_hi = (rid_int >> 8) & 0xFF
        rid_lo = rid_int & 0xFF
        method.append(f'        req_data = [SID_ROUTINE_CONTROL, 0x01, 0x{rid_hi:02X}, 0x{rid_lo:02X}] + {req_data_str}')
        method.append(f'        resp, elapsed = self.uds.send_request_timed(req_data)')
        method.append(f'        p2_ok = elapsed <= P2_STAR_TIMEOUT * 1.1')
        method.append(f'        if self.is_positive_response(resp, SID_ROUTINE_CONTROL):')
        method.append(f'            self.add_result(')
        method.append(f'                service="Timing", test_name="P2 Routine {rid_num} {rid_name}",')
        method.append(f'                did_rid="{rid_num}",')
        method.append(f'                expected=f"<={{P2_STAR_TIMEOUT}}ms(允许P2*)",')
        method.append(f'                actual=f"{{elapsed:.1f}}ms",')
        method.append(f'                status="PASS" if p2_ok else "FAIL",')
        method.append(f'                detail=f"Routine可能使用NRC0x78 pending, 总耗时{{elapsed:.1f}}ms")')
        method.append(f'        else:')
        method.append(f'            nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
        method.append(f'            self.add_result(')
        method.append(f'                service="Timing", test_name="P2 Routine {rid_num} {rid_name}",')
        method.append(f'                did_rid="{rid_num}",')
        method.append(f'                expected=f"正响应+P2合规",')
        method.append(f'                actual=f"{{self.resp_to_hex(resp)}} {{elapsed:.1f}}ms",')
        method.append(f'                status="PASS" if nrc in (0x22, 0x72, 0x31) else "FAIL",')
        method.append(f'                detail=f"NRC 0x22/0x72条件不满足可接受, 耗时{{elapsed:.1f}}ms")')
        method.append('')

    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_routine_response_timing()'


def generate_io_control_timing_tests(io_controls):
    """生成IOControl P2响应时间测试"""
    if not io_controls:
        return "", ""

    method = []
    method.append('    def test_io_control_response_timing(self):')
    method.append('        """测试 $2F IOControl P2响应时间"""')
    method.append('        print("\\n=== 测试 $2F IOControl P2响应时间 ===")')
    method.append('')

    for io in io_controls:
        did_num = io["did_number"]
        did_name = io.get("did_name", "Unknown")[:20]
        did_int = int(did_num, 16)
        conditions = io.get("conditions", "Extended Session")
        security = io.get("security_level", "Level1")

        # 确定会话
        if "extend" in conditions.lower():
            target_session = 0x03
        elif "program" in conditions.lower():
            target_session = 0x02
        else:
            target_session = 0x01

        # 解析SA
        sa_level = None
        if security:
            s = security.strip().lower()
            if "3" in s or "fbl" in s:
                sa_level = 0x03
            elif "5" in s or "immo" in s:
                sa_level = 0x05
            elif "1" in s:
                sa_level = 0x01

        did_hi = (did_int >> 8) & 0xFF
        did_lo = did_int & 0xFF

        method.append(f'        # IOControl {did_num} - {did_name} P2时间测量')
        method.append(f'        self.reset_to_default_session()')
        method.append(f'        self.switch_session(0x{target_session:02X})')
        method.append(f'        time.sleep(0.05)')
        if sa_level is not None:
            method.append(f'        self.unlock_security(0x{sa_level:02X})')
        # ReturnControlToECU (0x00) - 最安全的操作
        method.append(f'        req_data = [SID_IO_CONTROL, 0x{did_hi:02X}, 0x{did_lo:02X}, 0x00]')
        method.append(f'        resp, elapsed = self.uds.send_request_timed(req_data)')
        method.append(f'        p2_ok = elapsed <= P2_TIMEOUT * 1.1')
        method.append(f'        self.add_result(')
        method.append(f'            service="Timing", test_name="P2 IOCtrl {did_num} {did_name}",')
        method.append(f'            did_rid="{did_num}",')
        method.append(f'            expected=f"<={{P2_TIMEOUT}}ms",')
        method.append(f'            actual=f"{{elapsed:.1f}}ms",')
        method.append(f'            status="PASS" if (p2_ok or self.is_negative_response(resp)) else "FAIL",')
        method.append(f'            detail=f"ReturnControlToECU(0x00) 耗时{{elapsed:.1f}}ms")')
        method.append('')

    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_io_control_response_timing()'


def generate_io_control_tests(io_controls):
    """生成IOControl测试方法"""
    if not io_controls:
        return "", ""

    method = []
    method.append('    def test_io_controls(self):')
    method.append('        """测试 $2F InputOutputControlByIdentifier"""')
    method.append('        print("\\n=== 测试 $2F InputOutputControlByIdentifier ===")')
    method.append('')

    for io in io_controls:
        did_num = io["did_number"]
        did_name = io.get("did_name", "Unknown")
        did_int = int(did_num, 16)
        conditions = io.get("conditions", "Extended Session")
        security = io.get("security_level", "Level1")

        # 解析安全等级
        sa_level = None
        sa_level_name = "无"
        if security:
            s = security.strip().lower()
            if "3" in s or "fbl" in s or "prog" in s:
                sa_level = 0x03
                sa_level_name = "Level3(FBL)"
            elif "5" in s or "immo" in s:
                sa_level = 0x05
                sa_level_name = "Level5(IMMO)"
            elif "1" in s:
                sa_level = 0x01
                sa_level_name = "Level1"

        # 确定需要的会话
        if "extend" in conditions.lower():
            target_session = 0x03
            session_name = "Extended (0x03)"
        elif "program" in conditions.lower():
            target_session = 0x02
            session_name = "Programming (0x02)"
        else:
            target_session = 0x01
            session_name = "Default (0x01)"

        # 错误会话测试
        wrong_session = 0x01 if target_session != 0x01 else 0x03
        wrong_session_name = SESSION_NAMES_MAP.get(wrong_session, f"0x{wrong_session:02X}")

        method.append(f'        # IOControl {did_num} - {did_name} - 错误会话')
        method.append(f'        self.reset_to_default_session()')
        method.append(f'        self.switch_session(0x{wrong_session:02X})')
        method.append(f'        time.sleep(0.05)')
        method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x03)')  # ShortTermAdjustment
        method.append(f'        if self.is_negative_response(resp):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$2F", test_name="IO {did_num}({wrong_session_name})应拒绝",')
        method.append(f'                did_rid="{did_num}", session="{wrong_session_name}",')
        method.append(f'                expected="NRC", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$2F", test_name="IO {did_num}({wrong_session_name})应拒绝",')
        method.append(f'                did_rid="{did_num}", session="{wrong_session_name}",')
        method.append(f'                expected="NRC", actual=self.resp_to_hex(resp), status="FAIL")')
        method.append('')

        # 无安全访问测试
        method.append(f'        # IOControl {did_num} - 无安全访问 (需要{sa_level_name})')
        method.append(f'        self.reset_to_default_session()')
        method.append(f'        self.switch_session(0x{target_session:02X})')
        method.append(f'        time.sleep(0.05)')
        method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x03)')
        method.append(f'        if self.is_negative_response(resp, 0x33):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$2F", test_name="IO {did_num}无安全访问→NRC0x33",')
        method.append(f'                did_rid="{did_num}", session="{session_name}", security="{sa_level_name}",')
        method.append(f'                expected="NRC 0x33", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$2F", test_name="IO {did_num}无安全访问",')
        method.append(f'                did_rid="{did_num}", session="{session_name}", security="{sa_level_name}",')
        method.append(f'                expected="NRC 0x33", actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

        # SA解锁后正向测试 - ShortTermAdjustment
        if sa_level is not None:
            method.append(f'        # IOControl {did_num} - SA解锁后ShortTermAdjust (SA=0x{sa_level:02X} {sa_level_name})')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        self.switch_session(0x{target_session:02X})')
            method.append(f'        time.sleep(0.05)')
            method.append(f'        self.unlock_security(0x{sa_level:02X})')
            method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x03)')
            method.append(f'        if self.is_positive_response(resp, SID_IO_CONTROL):')
            method.append(f'            self.add_result(')
            method.append(f'                service="$2F", test_name="IO {did_num} SA解锁后ShortTermAdjust",')
            method.append(f'                did_rid="{did_num}", session="{session_name}", security="{sa_level_name}",')
            method.append(f'                expected="正响应 0x6F", actual=self.resp_to_hex(resp), status="PASS")')
            method.append(f'        else:')
            method.append(f'            nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
            method.append(f'            self.add_result(')
            method.append(f'                service="$2F", test_name="IO {did_num} SA解锁后ShortTermAdjust",')
            method.append(f'                did_rid="{did_num}", session="{session_name}", security="{sa_level_name}",')
            method.append(f'                expected="正响应 0x6F", actual=self.resp_to_hex(resp),')
            method.append(f'                status="PASS" if nrc in (0x22, 0x31) else "FAIL",')
            method.append(f'                detail="NRC 0x22(条件不满足)/0x31可接受")')
            method.append('')

        # ReturnControlToECU测试（0x00）
        method.append(f'        # IOControl {did_num} - ReturnControlToECU')
        method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x00)')
        method.append(f'        self.add_result(')
        method.append(f'            service="$2F", test_name="IO {did_num} ReturnControlToECU(0x00)",')
        method.append(f'            did_rid="{did_num}", session="{session_name}",')
        method.append(f'            expected="正响应或NRC",')
        method.append(f'            actual=self.resp_to_hex(resp),')
        method.append(f'            status="PASS" if resp is not None else "FAIL")')
        method.append('')

        # ResetToDefault测试（0x01）
        method.append(f'        # IOControl {did_num} - ResetToDefault')
        method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x01)')
        method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
        method.append(f'        self.add_result(')
        method.append(f'            service="$2F", test_name="IO {did_num} ResetToDefault(0x01)",')
        method.append(f'            did_rid="{did_num}", session="{session_name}",')
        method.append(f'            expected="正响应或NRC 0x12/0x31",')
        method.append(f'            actual=self.resp_to_hex(resp),')
        method.append(f'            status="PASS" if (self.is_positive_response(resp, SID_IO_CONTROL)')
        method.append(f'                              or nrc in (0x12, 0x31, 0x22, 0x33)) else "FAIL")')
        method.append('')

        # FreezeCurrentState测试（0x02）
        method.append(f'        # IOControl {did_num} - FreezeCurrentState')
        method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x02)')
        method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
        method.append(f'        self.add_result(')
        method.append(f'            service="$2F", test_name="IO {did_num} FreezeCurrentState(0x02)",')
        method.append(f'            did_rid="{did_num}", session="{session_name}",')
        method.append(f'            expected="正响应或NRC 0x12/0x31",')
        method.append(f'            actual=self.resp_to_hex(resp),')
        method.append(f'            status="PASS" if (self.is_positive_response(resp, SID_IO_CONTROL)')
        method.append(f'                              or nrc in (0x12, 0x31, 0x22, 0x33)) else "FAIL")')
        method.append('')

        # 无效controlOptionRecord（0x04 reserved）
        method.append(f'        # IOControl {did_num} - 无效controlOption(0x04)')
        method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x04)')
        method.append(f'        self.add_result(')
        method.append(f'            service="$2F", test_name="IO {did_num} 无效controlOption(0x04)",')
        method.append(f'            did_rid="{did_num}", session="{session_name}",')
        method.append(f'            expected="NRC 0x12/0x31",')
        method.append(f'            actual=self.resp_to_hex(resp),')
        method.append(f'            status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

        # 参数长度逆向测试 (controlStatusRecord 过长/过短)
        io_params = io.get("parameters", [])
        total_io_bytes = 0
        has_io_params = False
        for p in io_params:
            bl = safe_int_gen(p.get("bit_length", 0))
            if bl > 0:
                total_io_bytes += max(1, (bl + 7) // 8)
                has_io_params = True

        if has_io_params and total_io_bytes > 0:
            # ShortTermAdjust + 过长record
            over_len = total_io_bytes + 3
            method.append(f'        # IOControl {did_num} - 过长controlStatusRecord({over_len}B>期望{total_io_bytes}B)')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        self.switch_session(0x{target_session:02X})')
            method.append(f'        time.sleep(0.05)')
            if sa_level is not None:
                method.append(f'        self.unlock_security(0x{sa_level:02X})')
            method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x03, [0x00] * {over_len})')
            method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
            method.append(f'        self.add_result(')
            method.append(f'            service="$2F", test_name="IO {did_num}过长record({over_len}B>期望{total_io_bytes}B)",')
            method.append(f'            did_rid="{did_num}", session="{session_name}",')
            method.append(f'            expected="NRC 0x13(incorrectMessageLength)",')
            method.append(f'            actual=self.resp_to_hex(resp),')
            method.append(f'            status="PASS" if nrc in (0x13, 0x31, 0x22) else "FAIL",')
            method.append(f'            detail="某些ECU可能忽略多余字节")')
            method.append('')

            # ShortTermAdjust + 无record (0字节)
            method.append(f'        # IOControl {did_num} - 无controlStatusRecord(期望{total_io_bytes}B)')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        self.switch_session(0x{target_session:02X})')
            method.append(f'        time.sleep(0.05)')
            if sa_level is not None:
                method.append(f'        self.unlock_security(0x{sa_level:02X})')
            method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x03)')
            method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
            method.append(f'        self.add_result(')
            method.append(f'            service="$2F", test_name="IO {did_num}无record(期望{total_io_bytes}B)",')
            method.append(f'            did_rid="{did_num}", session="{session_name}",')
            method.append(f'            expected="NRC 0x13(incorrectMessageLength)",')
            method.append(f'            actual=self.resp_to_hex(resp),')
            method.append(f'            status="PASS" if nrc in (0x13, 0x31, 0x22) else "FAIL")')
            method.append('')

            # ShortTermAdjust + 过短record (少1字节)
            if total_io_bytes > 1:
                short_len = total_io_bytes - 1
                method.append(f'        # IOControl {did_num} - 过短controlStatusRecord({short_len}B<期望{total_io_bytes}B)')
                method.append(f'        self.reset_to_default_session()')
                method.append(f'        self.switch_session(0x{target_session:02X})')
                method.append(f'        time.sleep(0.05)')
                if sa_level is not None:
                    method.append(f'        self.unlock_security(0x{sa_level:02X})')
                method.append(f'        resp = self.uds.io_control(0x{did_int:04X}, 0x03, [0x00] * {short_len})')
                method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
                method.append(f'        self.add_result(')
                method.append(f'            service="$2F", test_name="IO {did_num}过短record({short_len}B<期望{total_io_bytes}B)",')
                method.append(f'            did_rid="{did_num}", session="{session_name}",')
                method.append(f'            expected="NRC 0x13(incorrectMessageLength)",')
                method.append(f'            actual=self.resp_to_hex(resp),')
                method.append(f'            status="PASS" if nrc in (0x13, 0x31, 0x22) else "FAIL")')
                method.append('')

    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_io_controls()'


def generate_routine_tests(routines):
    """生成RoutineControl测试方法"""
    if not routines:
        return "", ""

    method = []
    method.append('    def test_routines(self):')
    method.append('        """测试 $31 RoutineControl"""')
    method.append('        print("\\n=== 测试 $31 RoutineControl ===")')
    method.append('')

    for routine in routines:
        rid_num = routine["rid_number"]
        rid_name = routine.get("rid_name", "Unknown")
        rid_int = int(rid_num, 16)
        conditions = routine.get("conditions", "Extended Session")
        security = routine.get("security_level", "Level1")
        control_type = routine.get("control_type", "01")

        # 确定需要的会话
        if "program" in conditions.lower():
            target_session = 0x02
            session_name = "Programming (0x02)"
        elif "extend" in conditions.lower():
            target_session = 0x03
            session_name = "Extended (0x03)"
        else:
            target_session = 0x01
            session_name = "Default (0x01)"

        # 构建请求数据
        req_params = routine.get("req_parameters", [])
        req_data = []
        for p in req_params:
            bit_len = safe_int_gen(p.get("bit_length", "8"))
            byte_len = max(1, (bit_len + 7) // 8)
            req_data.extend([0x00] * byte_len)

        req_data_str = str(req_data) if req_data else "[]"

        # 错误会话测试
        wrong_session = 0x01 if target_session != 0x01 else 0x03
        wrong_session_name = SESSION_NAMES_MAP.get(wrong_session, f"0x{wrong_session:02X}")

        method.append(f'        # Routine {rid_num} - {rid_name} - 错误会话')
        method.append(f'        self.reset_to_default_session()')
        method.append(f'        self.switch_session(0x{wrong_session:02X})')
        method.append(f'        time.sleep(0.05)')
        method.append(f'        resp = self.uds.routine_control(0x01, 0x{rid_int:04X}, {req_data_str})')
        method.append(f'        if self.is_negative_response(resp):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$31", test_name="Routine {rid_num}({wrong_session_name})应拒绝",')
        method.append(f'                did_rid="{rid_num}", session="{wrong_session_name}",')
        method.append(f'                expected="NRC", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$31", test_name="Routine {rid_num}({wrong_session_name})应拒绝",')
        method.append(f'                did_rid="{rid_num}", session="{wrong_session_name}",')
        method.append(f'                expected="NRC", actual=self.resp_to_hex(resp), status="FAIL")')
        method.append('')

        # 解析安全等级
        sa_level = None
        sa_level_name = "无"
        if security:
            s = security.strip().lower()
            if "3" in s or "fbl" in s or "prog" in s:
                sa_level = 0x03
                sa_level_name = "Level3(FBL)"
            elif "5" in s or "immo" in s:
                sa_level = 0x05
                sa_level_name = "Level5(IMMO)"
            elif "1" in s:
                sa_level = 0x01
                sa_level_name = "Level1"

        # 无安全访问测试
        method.append(f'        # Routine {rid_num} - 无安全访问 (需要{sa_level_name})')
        method.append(f'        self.reset_to_default_session()')
        method.append(f'        self.switch_session(0x{target_session:02X})')
        method.append(f'        time.sleep(0.05)')
        method.append(f'        resp = self.uds.routine_control(0x01, 0x{rid_int:04X}, {req_data_str})')
        method.append(f'        if self.is_negative_response(resp, 0x33):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$31", test_name="Routine {rid_num}无安全访问→NRC0x33",')
        method.append(f'                did_rid="{rid_num}", session="{session_name}", security="{sa_level_name}",')
        method.append(f'                expected="NRC 0x33", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$31", test_name="Routine {rid_num}无安全访问",')
        method.append(f'                did_rid="{rid_num}", session="{session_name}", security="{sa_level_name}",')
        method.append(f'                expected="NRC 0x33", actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

        # SA解锁后正向测试
        if sa_level is not None:
            method.append(f'        # Routine {rid_num} - SA解锁后执行 (SA=0x{sa_level:02X} {sa_level_name})')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        self.switch_session(0x{target_session:02X})')
            method.append(f'        time.sleep(0.05)')
            method.append(f'        self.unlock_security(0x{sa_level:02X})')
            method.append(f'        resp = self.uds.routine_control(0x01, 0x{rid_int:04X}, {req_data_str})')
            method.append(f'        if self.is_positive_response(resp, SID_ROUTINE_CONTROL):')
            method.append(f'            self.add_result(')
            method.append(f'                service="$31", test_name="Routine {rid_num} SA解锁后startRoutine",')
            method.append(f'                did_rid="{rid_num}", session="{session_name}", security="{sa_level_name}",')
            method.append(f'                expected="正响应 0x71", actual=self.resp_to_hex(resp), status="PASS")')
            method.append(f'        else:')
            method.append(f'            nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
            method.append(f'            self.add_result(')
            method.append(f'                service="$31", test_name="Routine {rid_num} SA解锁后startRoutine",')
            method.append(f'                did_rid="{rid_num}", session="{session_name}", security="{sa_level_name}",')
            method.append(f'                expected="正响应 0x71", actual=self.resp_to_hex(resp),')
            method.append(f'                status="PASS" if nrc in (0x22, 0x72) else "FAIL",')
            method.append(f'                detail="NRC 0x22(条件不满足)/0x72(requestSequenceError)可接受")')
            method.append('')

        # 无效的ControlType测试
        method.append(f'        # Routine {rid_num} - 无效ControlType')
        method.append(f'        resp = self.uds.routine_control(0x04, 0x{rid_int:04X})')
        method.append(f'        if self.is_negative_response(resp, 0x12):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$31", test_name="Routine {rid_num}无效ControlType",')
        method.append(f'                did_rid="{rid_num}", session="{session_name}",')
        method.append(f'                expected="NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$31", test_name="Routine {rid_num}无效ControlType",')
        method.append(f'                did_rid="{rid_num}", session="{session_name}",')
        method.append(f'                expected="NRC 0x12", actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

        # 参数长度逆向测试 (过长/过短请求)
        total_param_bytes = 0
        has_real_params = False
        for p in req_params:
            bl = safe_int_gen(p.get("bit_length", 0))
            if bl > 0:
                total_param_bytes += max(1, (bl + 7) // 8)
                has_real_params = True

        if has_real_params and total_param_bytes > 0:
            # 过短参数 (少1字节)
            if total_param_bytes > 1:
                short_len = total_param_bytes - 1
                method.append(f'        # Routine {rid_num} - 过短参数({short_len}B<期望{total_param_bytes}B)')
                method.append(f'        self.reset_to_default_session()')
                method.append(f'        self.switch_session(0x{target_session:02X})')
                method.append(f'        time.sleep(0.05)')
                if sa_level is not None:
                    method.append(f'        self.unlock_security(0x{sa_level:02X})')
                method.append(f'        resp = self.uds.routine_control(0x01, 0x{rid_int:04X}, [0x00] * {short_len})')
                method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
                method.append(f'        self.add_result(')
                method.append(f'            service="$31", test_name="Routine {rid_num}过短参数({short_len}B<期望{total_param_bytes}B)",')
                method.append(f'            did_rid="{rid_num}", session="{session_name}",')
                method.append(f'            expected="NRC 0x13(incorrectMessageLength)",')
                method.append(f'            actual=self.resp_to_hex(resp),')
                method.append(f'            status="PASS" if nrc in (0x13, 0x31, 0x22) else "FAIL")')
                method.append('')

            # 无参数 (仅发SID+ControlType+RID)
            method.append(f'        # Routine {rid_num} - 无参数(期望{total_param_bytes}B)')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        self.switch_session(0x{target_session:02X})')
            method.append(f'        time.sleep(0.05)')
            if sa_level is not None:
                method.append(f'        self.unlock_security(0x{sa_level:02X})')
            method.append(f'        resp = self.uds.routine_control(0x01, 0x{rid_int:04X}, [])')
            method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
            method.append(f'        self.add_result(')
            method.append(f'            service="$31", test_name="Routine {rid_num}无参数(期望{total_param_bytes}B)",')
            method.append(f'            did_rid="{rid_num}", session="{session_name}",')
            method.append(f'            expected="NRC 0x13(incorrectMessageLength)",')
            method.append(f'            actual=self.resp_to_hex(resp),')
            method.append(f'            status="PASS" if nrc in (0x13, 0x31, 0x22) else "FAIL")')
            method.append('')

            # 过长参数 (多3字节)
            over_len = total_param_bytes + 3
            method.append(f'        # Routine {rid_num} - 过长参数({over_len}B>期望{total_param_bytes}B)')
            method.append(f'        self.reset_to_default_session()')
            method.append(f'        self.switch_session(0x{target_session:02X})')
            method.append(f'        time.sleep(0.05)')
            if sa_level is not None:
                method.append(f'        self.unlock_security(0x{sa_level:02X})')
            method.append(f'        resp = self.uds.routine_control(0x01, 0x{rid_int:04X}, [0x00] * {over_len})')
            method.append(f'        nrc = self.get_nrc(resp) if self.is_negative_response(resp) else None')
            method.append(f'        self.add_result(')
            method.append(f'            service="$31", test_name="Routine {rid_num}过长参数({over_len}B>期望{total_param_bytes}B)",')
            method.append(f'            did_rid="{rid_num}", session="{session_name}",')
            method.append(f'            expected="NRC 0x13(incorrectMessageLength)",')
            method.append(f'            actual=self.resp_to_hex(resp),')
            method.append(f'            status="PASS" if nrc in (0x13, 0x31, 0x22) else "FAIL",')
            method.append(f'            detail="某些ECU可能忽略多余字节")')
            method.append('')

    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_routines()'


def generate_dtc_tests(dtcs):
    """生成DTC测试方法"""
    if not dtcs:
        return "", ""

    method = []
    method.append('    def test_dtc_services(self):')
    method.append('        """测试 $19/$14/$85 DTC相关服务"""')
    method.append('        print("\\n=== 测试 DTC相关服务 ===")')
    method.append('')

    # $19 ReadDTCInformation
    method.append('        # $19-01 读取DTC状态总览')
    method.append('        resp = self.uds.read_dtc_info(0x01, 0xFF)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=01",')
    method.append('                expected="正响应 0x59", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=01",')
    method.append('                expected="正响应 0x59", actual=self.resp_to_hex(resp), status="FAIL")')
    method.append('')

    # $19-02 读取DTC详细信息（按status mask）
    method.append('        # $19-02 读取DTC详细信息')
    method.append('        resp = self.uds.read_dtc_info(0x02, 0xFF)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=02 所有DTC",')
    method.append('                expected="正响应", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=02 所有DTC",')
    method.append('                expected="正响应", actual=self.resp_to_hex(resp), status="FAIL")')
    method.append('')

    # $19-0A 读取所有支持的DTC
    method.append('        # $19-0A 读取所有支持的DTC')
    method.append('        resp = self.uds.read_dtc_info(0x0A)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=0A",')
    method.append('                expected="正响应", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=0A",')
    method.append('                expected="正响应", actual=self.resp_to_hex(resp), status="FAIL")')
    method.append('')

    # $19 全部子功能覆盖 (ISO 14229-1 §11.3)
    # 0x03 reportDTCSnapshotIdentification
    method.append('        # $19-03 reportDTCSnapshotIdentification')
    method.append('        resp = self.uds.read_dtc_info(0x03)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=03 SnapshotIdentification",')
    method.append('                expected="正响应或NRC 0x12(不支持)", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=03 SnapshotIdentification",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # 0x04 reportDTCSnapshotRecordByDTCNumber (需要DTC参数)
    if dtcs:
        dtc0 = dtcs[0]
        dtc0_hex = dtc0["dtc_number_hex"]
        dtc0_int = int(dtc0_hex, 16)
        b1_0 = (dtc0_int >> 16) & 0xFF
        b2_0 = (dtc0_int >> 8) & 0xFF
        b3_0 = dtc0_int & 0xFF
        method.append(f'        # $19-04 reportDTCSnapshotRecordByDTCNumber (DTC={dtc0_hex})')
        method.append(f'        resp = self.uds.read_dtc_info(0x04, 0x{b1_0:02X}, 0x{b2_0:02X}, 0x{b3_0:02X}, 0xFF)')
        method.append(f'        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$19", test_name="ReadDTCInfo SubFunc=04 Snapshot DTC={dtc0_hex}",')
        method.append(f'                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$19", test_name="ReadDTCInfo SubFunc=04 Snapshot DTC={dtc0_hex}",')
        method.append(f'                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

    # 0x05 reportDTCStoredDataByRecordNumber
    method.append('        # $19-05 reportDTCStoredDataByRecordNumber')
    method.append('        resp = self.uds.read_dtc_info(0x05, 0xFF)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=05 StoredDataByRecordNumber",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=05 StoredDataByRecordNumber",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # 0x07 reportNumberOfDTCBySeverityMaskRecord
    method.append('        # $19-07 reportNumberOfDTCBySeverityMaskRecord')
    method.append('        resp = self.uds.read_dtc_info(0x07, 0xFF, 0xFF)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=07 NumberBySeverityMask",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=07 NumberBySeverityMask",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # 0x08 reportDTCBySeverityMaskRecord
    method.append('        # $19-08 reportDTCBySeverityMaskRecord')
    method.append('        resp = self.uds.read_dtc_info(0x08, 0xFF, 0xFF)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=08 DTCBySeverityMask",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=08 DTCBySeverityMask",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # 0x09 reportSeverityInformationOfDTC
    if dtcs:
        method.append(f'        # $19-09 reportSeverityInformationOfDTC (DTC={dtc0_hex})')
        method.append(f'        resp = self.uds.read_dtc_info(0x09, 0x{b1_0:02X}, 0x{b2_0:02X}, 0x{b3_0:02X})')
        method.append(f'        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$19", test_name="ReadDTCInfo SubFunc=09 SeverityOfDTC {dtc0_hex}",')
        method.append(f'                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$19", test_name="ReadDTCInfo SubFunc=09 SeverityOfDTC {dtc0_hex}",')
        method.append(f'                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

    # 0x0B-0x0E 各类DTC查询
    sub_func_names = {
        0x0B: "reportFirstTestFailedDTC",
        0x0C: "reportFirstConfirmedDTC",
        0x0D: "reportMostRecentTestFailedDTC",
        0x0E: "reportMostRecentConfirmedDTC",
    }
    for sf, sf_name in sub_func_names.items():
        method.append(f'        # $19-{sf:02X} {sf_name}')
        method.append(f'        resp = self.uds.read_dtc_info(0x{sf:02X})')
        method.append(f'        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$19", test_name="ReadDTCInfo SubFunc=0x{sf:02X} {sf_name}",')
        method.append(f'                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$19", test_name="ReadDTCInfo SubFunc=0x{sf:02X} {sf_name}",')
        method.append(f'                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

    # 0x0F reportMirrorMemoryDTCByStatusMask
    method.append('        # $19-0F reportMirrorMemoryDTCByStatusMask')
    method.append('        resp = self.uds.read_dtc_info(0x0F, 0xFF)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=0F MirrorMemory",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=0F MirrorMemory",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # 0x14 reportDTCFaultDetectionCounter
    method.append('        # $19-14 reportDTCFaultDetectionCounter')
    method.append('        resp = self.uds.read_dtc_info(0x14)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=14 FaultDetectionCounter",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=14 FaultDetectionCounter",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # 0x42 reportWWHOBDDTCWithPermanentStatus
    method.append('        # $19-42 reportWWHOBDDTCWithPermanentStatus')
    method.append('        resp = self.uds.read_dtc_info(0x42)')
    method.append('        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=42 WWHOBD Permanent",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=42 WWHOBD Permanent",')
    method.append('                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # 剩余11个$19子功能 (ISO 14229-1:2020 Table 272完整覆盖)
    remaining_19_subfuncs = [
        (0x10, "reportMirrorMemoryDTCExtDataRecordByDTCNumber", [0x00, 0x00, 0x01, 0xFF]),
        (0x11, "reportNumberOfMirrorMemoryDTCByStatusMask", [0xFF]),
        (0x12, "reportNumberOfEmissionsOBDDTCByStatusMask", [0xFF]),
        (0x13, "reportEmissionsOBDDTCByStatusMask", [0xFF]),
        (0x15, "reportDTCWithPermanentStatus", []),
        (0x16, "reportDTCExtDataRecordByRecordNumber", [0xFF]),
        (0x17, "reportUserDefMemoryDTCByStatusMask", [0xFF]),
        (0x18, "reportUserDefMemoryDTCSnapshotRecordByDTCNumber", [0x00, 0x00, 0x01, 0xFF]),
        (0x19, "reportUserDefMemoryDTCExtDataRecordByDTCNumber", [0x00, 0x00, 0x01, 0xFF]),
        (0x55, "reportWWHOBDDTCByMaskRecord", [0xFF, 0xFF]),
        (0x56, "reportWWHOBDDTCWithPermanentStatusV2", []),
    ]
    for sf, sf_name, extra_args in remaining_19_subfuncs:
        args_str = ', '.join([f'0x{a:02X}' for a in extra_args])
        call_args = f'0x{sf:02X}' + (f', {args_str}' if args_str else '')
        method.append(f'        # $19-{sf:02X} {sf_name}')
        method.append(f'        resp = self.uds.read_dtc_info({call_args})')
        method.append(f'        if self.is_positive_response(resp, SID_READ_DTC_INFO) or self.is_negative_response(resp, 0x12):')
        method.append(f'            self.add_result(')
        method.append(f'                service="$19", test_name="ReadDTCInfo SubFunc=0x{sf:02X} {sf_name}",')
        method.append(f'                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
        method.append(f'        else:')
        method.append(f'            self.add_result(')
        method.append(f'                service="$19", test_name="ReadDTCInfo SubFunc=0x{sf:02X} {sf_name}",')
        method.append(f'                expected="正响应或NRC 0x12", actual=self.resp_to_hex(resp),')
        method.append(f'                status="PASS" if self.is_negative_response(resp) else "FAIL")')
        method.append('')

    # $19 wrong-length test
    method.append('        # $19 错误长度(仅SID)')
    method.append('        resp = self.uds.send_request([SID_READ_DTC_INFO])')
    method.append('        if self.is_negative_response(resp, 0x13):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo 错误长度(仅SID)",')
    method.append('                expected="NRC 0x13", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo 错误长度(仅SID)",')
    method.append('                expected="NRC 0x13", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # $19-01 without statusMask (wrong length)
    method.append('        # $19-01 缺少statusMask参数')
    method.append('        resp = self.uds.send_request([SID_READ_DTC_INFO, 0x01])')
    method.append('        if self.is_negative_response(resp, 0x13):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=01 缺少statusMask",')
    method.append('                expected="NRC 0x13", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo SubFunc=01 缺少statusMask",')
    method.append('                expected="NRC 0x13", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # $19 session test - Extended session
    method.append('        # $19 扩展会话测试')
    method.append('        self.switch_session(SESSION_EXTENDED)')
    method.append('        time.sleep(0.05)')
    method.append('        resp = self.uds.read_dtc_info(0x01, 0xFF)')
    method.append('        self.add_result(')
    method.append('            service="$19", test_name="ReadDTCInfo SubFunc=01 扩展会话",')
    method.append('            session="Extended",')
    method.append('            expected="正响应",')
    method.append('            actual=self.resp_to_hex(resp),')
    method.append('            status="PASS" if self.is_positive_response(resp, SID_READ_DTC_INFO) else "FAIL")')
    method.append('        self.reset_to_default_session()')
    method.append('')

    # $19 suppressPositiveResponse 测试
    method.append('        # $19 suppressPositiveResponse (SubFunc=0x81)')
    method.append('        resp = self.uds.read_dtc_info(0x81, 0xFF)  # 0x01 + 0x80')
    method.append('        self.add_result(')
    method.append('            service="$19", test_name="ReadDTCInfo SubFunc=01 suppressPosRsp",')
    method.append('            expected="无响应(被抑制)", actual=self.resp_to_hex(resp),')
    method.append('            status="PASS" if resp is None else "FAIL")')
    method.append('')

    # 无效子功能
    method.append('        # $19 无效子功能')
    method.append('        resp = self.uds.read_dtc_info(0xFE)')
    method.append('        if self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo 无效子功能0xFE",')
    method.append('                expected="NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$19", test_name="ReadDTCInfo 无效子功能0xFE",')
    method.append('                expected="NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # 逐个DTC验证（通过$19-06读取特定DTC的snapshot）
    for dtc in dtcs:
        dtc_hex = dtc["dtc_number_hex"]
        dtc_name = dtc.get("dtc_name", "Unknown").replace("\n", " ")[:30]
        dtc_int = int(dtc_hex, 16)
        b1 = (dtc_int >> 16) & 0xFF
        b2 = (dtc_int >> 8) & 0xFF
        b3 = dtc_int & 0xFF

        method.append(f'        # 验证DTC {dtc_hex} ({dtc_name})')
        method.append(f'        resp = self.uds.read_dtc_info(0x06, 0x{b1:02X}, 0x{b2:02X}, 0x{b3:02X}, 0xFF)')
        method.append(f'        dtc_exists = self.is_positive_response(resp, SID_READ_DTC_INFO)')
        method.append(f'        self.add_result(')
        method.append(f'            service="$19", test_name="验证DTC {dtc_hex}存在",')
        method.append(f'            did_rid="{dtc_hex}",')
        method.append(f'            expected="正响应(DTC已注册)", actual=self.resp_to_hex(resp),')
        method.append(f'            status="PASS" if dtc_exists or self.is_negative_response(resp) else "FAIL")')
        method.append('')

    # $14 ClearDTC
    method.append('        # $14 ClearDiagnosticInformation - 默认会话')
    method.append('        self.reset_to_default_session()')
    method.append('        resp = self.uds.clear_dtc(0xFFFFFF)')
    method.append('        if self.is_positive_response(resp, SID_CLEAR_DTC):')
    method.append('            self.add_result(')
    method.append('                service="$14", test_name="清除所有DTC(默认会话,0xFFFFFF)",')
    method.append('                expected="正响应 0x54", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$14", test_name="清除所有DTC(默认会话,0xFFFFFF)",')
    method.append('                expected="正响应 0x54", actual=self.resp_to_hex(resp), status="FAIL")')
    method.append('')

    # $14 清除特定DTC组 (Powertrain/Body/Chassis/Network)
    method.append('        # $14 清除特定DTC组')
    dtc_groups = [
        ('0x000000', '动力系统DTC组'),
        ('0x400000', '底盘DTC组'),
        ('0x800000', '车身DTC组'),
        ('0xC00000', '网络DTC组'),
    ]
    for grp_hex, grp_name in dtc_groups:
        grp_val = int(grp_hex, 16)
        method.append(f'        resp = self.uds.clear_dtc({grp_hex})')
        method.append(f'        self.add_result(')
        method.append(f'            service="$14", test_name="清除{grp_name}({grp_hex})",')
        method.append(f'            expected="正响应0x54或NRC 0x31(无此组)",')
        method.append(f'            actual=self.resp_to_hex(resp),')
        method.append(f'            status="PASS" if (self.is_positive_response(resp, SID_CLEAR_DTC) or self.is_negative_response(resp, 0x31)) else "FAIL")')
        method.append('')

    # $14 编程会话清除(某些ECU不允许)
    method.append('        # $14 编程会话清除DTC(可能被拒绝)')
    method.append('        self.switch_session(SESSION_PROGRAMMING)')
    method.append('        time.sleep(0.05)')
    method.append('        resp = self.uds.clear_dtc(0xFFFFFF)')
    method.append('        self.add_result(')
    method.append('            service="$14", test_name="编程会话清除所有DTC",')
    method.append('            session="Programming",')
    method.append('            expected="正响应或NRC(0x7F/0x22)",')
    method.append('            actual=self.resp_to_hex(resp),')
    method.append('            status="PASS" if resp is not None else "FAIL",')
    method.append('            detail="ECU可能在编程会话拒绝ClearDTC")')
    method.append('        self.reset_to_default_session()')
    method.append('')

    # $14 错误长度
    method.append('        # $14 错误长度(仅2字节DTC)')
    method.append('        resp = self.uds.send_request([SID_CLEAR_DTC, 0xFF, 0xFF])')
    method.append('        if self.is_negative_response(resp, 0x13):')
    method.append('            self.add_result(')
    method.append('                service="$14", test_name="$14错误长度(2字节DTC)",')
    method.append('                expected="NRC 0x13", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$14", test_name="$14错误长度(2字节DTC)",')
    method.append('                expected="NRC 0x13", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    # $85 ControlDTCSetting
    method.append('        # $85 ControlDTCSetting OFF')
    method.append('        self.switch_session(SESSION_EXTENDED)')
    method.append('        time.sleep(0.05)')
    method.append('        resp = self.uds.control_dtc_setting(0x02)  # OFF')
    method.append('        if self.is_positive_response(resp, SID_CONTROL_DTC_SETTING):')
    method.append('            self.add_result(')
    method.append('                service="$85", test_name="ControlDTCSetting OFF",')
    method.append('                expected="正响应 0xC5", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$85", test_name="ControlDTCSetting OFF",')
    method.append('                expected="正响应 0xC5", actual=self.resp_to_hex(resp), status="FAIL")')
    method.append('')

    method.append('        # $85 ControlDTCSetting ON')
    method.append('        resp = self.uds.control_dtc_setting(0x01)  # ON')
    method.append('        if self.is_positive_response(resp, SID_CONTROL_DTC_SETTING):')
    method.append('            self.add_result(')
    method.append('                service="$85", test_name="ControlDTCSetting ON",')
    method.append('                expected="正响应 0xC5", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$85", test_name="ControlDTCSetting ON",')
    method.append('                expected="正响应 0xC5", actual=self.resp_to_hex(resp), status="FAIL")')
    method.append('')

    # $85 在默认会话中（应拒绝）
    method.append('        # $85 ControlDTCSetting 默认会话应拒绝')
    method.append('        self.reset_to_default_session()')
    method.append('        resp = self.uds.control_dtc_setting(0x02)')
    method.append('        if self.is_negative_response(resp):')
    method.append('            self.add_result(')
    method.append('                service="$85", test_name="ControlDTCSetting默认会话应拒绝",')
    method.append('                expected="NRC", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$85", test_name="ControlDTCSetting默认会话应拒绝",')
    method.append('                expected="NRC", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_positive_response(resp, SID_CONTROL_DTC_SETTING) else "FAIL",')
    method.append('                detail="某些ECU可能在默认会话也支持")')
    method.append('')

    # $85 suppressPositiveResponse
    method.append('        # $85 suppressPositiveResponse测试')
    method.append('        self.switch_session(SESSION_EXTENDED)')
    method.append('        time.sleep(0.05)')
    method.append('        resp = self.uds.control_dtc_setting(0x82)  # OFF + 0x80(suppress)')
    method.append('        self.add_result(')
    method.append('            service="$85", test_name="ControlDTCSetting OFF suppressPosRsp",')
    method.append('            expected="无响应(被抑制)", actual=self.resp_to_hex(resp),')
    method.append('            status="PASS" if resp is None else "FAIL")')
    method.append('        # 恢复ON')
    method.append('        self.uds.control_dtc_setting(0x01)')
    method.append('')

    # $85 无效子功能
    method.append('        # $85 ControlDTCSetting 无效子功能')
    method.append('        resp = self.uds.control_dtc_setting(0x00)')
    method.append('        if self.is_negative_response(resp, 0x12):')
    method.append('            self.add_result(')
    method.append('                service="$85", test_name="ControlDTCSetting 无效子功能0x00",')
    method.append('                expected="NRC 0x12", actual=self.resp_to_hex(resp), status="PASS")')
    method.append('        else:')
    method.append('            self.add_result(')
    method.append('                service="$85", test_name="ControlDTCSetting 无效子功能0x00",')
    method.append('                expected="NRC 0x12", actual=self.resp_to_hex(resp),')
    method.append('                status="PASS" if self.is_negative_response(resp) else "FAIL")')
    method.append('')

    method.append('        self.reset_to_default_session()')

    return '\n'.join(method), '            self.test_dtc_services()'


SESSION_NAMES_MAP = {
    0x01: "Default (0x01)",
    0x02: "Programming (0x02)",
    0x03: "Extended (0x03)",
}


def safe_int_gen(val, default=0):
    """生成器用安全int转换"""
    try:
        return int(float(str(val).strip()))
    except (ValueError, TypeError):
        return default


def _check_key_ready(key_file):
    """生成期密钥就绪检查：占位/缺失 → (False, reason)；就绪 → (True, '')
    复用 seedkey_gen2.SeedKeyGen2（全 0xFF 占位视为未就绪，问题 38/39 固化）"""
    if not key_file:
        return False, "未配置 --sa-key-file（且未确认 Vector 标准 SeedKey DLL）"
    try:
        from seedkey_gen2 import SeedKeyGen2
    except ImportError:
        return False, "seedkey_gen2 模块不可用"
    sk = SeedKeyGen2(key_file)
    if not sk.load():
        return False, sk.reason
    return True, ""


def generate_test_script(parsed_data, output_path, **kwargs):
    """生成完整的测试脚本"""

    channel = kwargs.get("channel", "")
    serial = kwargs.get("serial", "")
    can_if = kwargs.get("can_if", "auto")
    if not can_if or can_if == "auto":
        can_if = "vector"
    bitrate = kwargs.get("bitrate")
    sample_point = kwargs.get("sample_point")
    tx_id = kwargs.get("tx_id")
    rx_id = kwargs.get("rx_id")
    func_id = kwargs.get("func_id")
    confirmed = kwargs.get("confirmed", False)

    # 仅在CLI显式指定时覆盖调查表；否则优先使用调查表，再回退到硬编码默认值
    can_config = parsed_data.get("can_config", {})

    # 追踪哪些关键参数来自硬编码默认值
    _critical_defaults = []
    _HARDCODED = {"tx_id": "0x7E0", "rx_id": "0x7E8", "func_id": "0x7DF",
                   "bitrate": 500000, "sample_point": 0.8,
                   "can_fd": False, "fd_data_bitrate": 2000000, "fd_dsample_point": 0.8}

    def _track(key, cli_val, survey_val):
        from_cli = cli_val is not None
        from_survey = key in can_config
        used_hardcoded = not from_cli and not from_survey
        if used_hardcoded and key in _HARDCODED:
            _critical_defaults.append((key, _HARDCODED[key]))
        return survey_val if not from_cli else cli_val

    tx_id = _track("tx_id", tx_id, can_config.get("tx_id", "0x7E0"))
    rx_id = _track("rx_id", rx_id, can_config.get("rx_id", "0x7E8"))
    func_id = _track("func_id", func_id, can_config.get("func_id", "0x7DF"))
    bitrate = _track("bitrate", bitrate, can_config.get("bitrate", 500000))
    sample_point = _track("sample_point", sample_point, can_config.get("sample_point", 0.8))

    # 统一转为int, 保证类型安全 (模板注入和python-can都需要int)
    def _to_can_id(v, fallback=0x7E0):
        if isinstance(v, int):
            return v
        try:
            return int(str(v), 0)  # 支持 "0x7E0" 和 "2016"
        except (ValueError, TypeError):
            print(f"[WARN] CAN ID '{v}' 无法转为整数, 使用默认值 0x{fallback:X}")
            return fallback

    tx_id = _to_can_id(tx_id, 0x7E0)
    rx_id = _to_can_id(rx_id, 0x7E8)
    func_id = _to_can_id(func_id, 0x7DF)
    bitrate = int(bitrate)
    sample_point = float(sample_point)
    print(f"[INFO] 最终CAN配置: TX=0x{tx_id:X}, RX=0x{rx_id:X}, bitrate={bitrate}, sample_point={sample_point}")

    p2_timeout = kwargs.get("p2_timeout", 50)
    p2_star_timeout = kwargs.get("p2_star_timeout", 5000)
    s3_timeout = kwargs.get("s3_timeout", 5000)
    sa_delay = kwargs.get("sa_delay", 10000)
    can_fd = kwargs.get("can_fd", False)
    fd_data_bitrate = kwargs.get("fd_data_bitrate")
    fd_dsample_point = kwargs.get("fd_dsample_point")
    fd_max_dlc = kwargs.get("fd_max_dlc", 64)

    # CAN FD: CLI 显式传入则为 True/None，否则回退到调查表/默认值
    can_fd_cli = kwargs.get("can_fd_cli")  # None=CLI未指定, True=--can-fd
    can_fd = _track("can_fd", can_fd_cli, can_config.get("can_fd", False))
    fd_data_bitrate = _track("fd_data_bitrate", fd_data_bitrate, can_config.get("fd_data_bitrate", 2000000))
    fd_dsample_point = _track("fd_dsample_point", fd_dsample_point, can_config.get("fd_dsample_point", 0.8))
    if can_fd:
        print(f"[INFO] CAN FD配置: dbitrate={fd_data_bitrate}, dsample_point={fd_dsample_point}")

    # 检查关键参数是否使用了硬编码默认值
    _BLOCKING_KEYS = {"tx_id", "rx_id", "bitrate"}
    _blocking_defaults = [(k, v) for k, v in _critical_defaults if k in _BLOCKING_KEYS]
    _non_blocking = [(k, v) for k, v in _critical_defaults if k not in _BLOCKING_KEYS]

    if _critical_defaults:
        print(f"\n[WARNING] 以下关键参数在调查表和CLI中均未指定，已使用硬编码默认值：")
        print(f"  {'参数':<20} {'默认值':<15} {'是否阻断生成':<12}")
        print(f"  {'-'*20} {'-'*15} {'-'*12}")
        for key, val in _blocking_defaults:
            print(f"  {key:<20} {str(val):<15} {'是':<12}")
        for key, val in _non_blocking:
            print(f"  {key:<20} {str(val):<15} {'否（仅警告）':<12}")
        print()

        if _blocking_defaults and not confirmed:
            print("[ERROR] 关键CAN参数使用了硬编码默认值，拒绝生成测试脚本。")
            print("[ERROR] 请在调查表中补充缺失信息，或使用 --confirmed 标志确认使用默认值。")
            sys.exit(1)

    def _py_str(s):
        """Windows 路径等字符串安全嵌入生成脚本（转义反斜杠/引号/换行）"""
        return (s or "").replace("\\", "\\\\").replace('"', '\\"').replace("\r", "").replace("\n", "\\n")

    seedkey_dll_path = _py_str(kwargs.get("seedkey_dll_path", ""))
    seedkey_variant = _py_str(kwargs.get("seedkey_variant", ""))
    seedkey_options = _py_str(kwargs.get("seedkey_options", ""))
    seedkey_key_file = _py_str(kwargs.get("seedkey_key_file", ""))
    can_addr_mode = kwargs.get("can_addr_mode", "normal_11bit")
    can_addr_ext = kwargs.get("can_addr_ext", 0x00)

    source_file = _py_str(parsed_data.get("source_file", "unknown"))
    timing_did = select_timing_did(parsed_data.get("dids", []))

    # 从调查表中提取所有安全等级
    sa_levels_found = set()
    for did in parsed_data.get("dids", []):
        for sec_field in ("read_security", "write_security"):
            sec_dict = did.get(sec_field, {})
            for key, sa_val in [("level1", 0x01), ("level_fbl", 0x03), ("level_immo", 0x05)]:
                if sec_dict.get(key, "N").upper() == "Y":
                    sa_levels_found.add(sa_val)
    for routine in parsed_data.get("routines", []):
        sl = routine.get("security_level", "")
        if sl:
            s = sl.strip().lower()
            if "3" in s or "fbl" in s or "prog" in s:
                sa_levels_found.add(0x03)
            elif "5" in s or "immo" in s:
                sa_levels_found.add(0x05)
            elif "1" in s:
                sa_levels_found.add(0x01)
    for io in parsed_data.get("io_controls", []):
        sl = io.get("security_level", "")
        if sl:
            s = sl.strip().lower()
            if "3" in s or "fbl" in s:
                sa_levels_found.add(0x03)
            elif "5" in s or "immo" in s:
                sa_levels_found.add(0x05)
            elif "1" in s:
                sa_levels_found.add(0x01)
    if not sa_levels_found:
        sa_levels_found.add(0x01)  # 默认至少测试Level1

    # 生成期密钥就绪检查：0x27/刷写正例 BLOCKED 影响面统计（实测问题 38/39 固化）
    key_ready, key_reason = _check_key_ready(seedkey_key_file)
    if not key_ready:
        sa_routines = sum(1 for r in parsed_data.get("routines", []) if r.get("security_level"))
        flash_hint = any(k in str(r.get("name", "")).lower()
                         for r in parsed_data.get("routines", [])
                         for k in ("flash", "download", "program", "刷写"))
        print("[BLOCKED-STATS] 0x27 密钥未就绪：" + key_reason)
        print(f"[BLOCKED-STATS] 影响面：0x27 解锁等级 {len(sa_levels_found)} 个；需解锁例程 {sa_routines} 条"
              + ("（含刷写相关，需密钥解锁）" if flash_hint else ""))
        print("[BLOCKED-STATS] 这些正例执行时将标 BLOCKED 而非 FAIL；密钥就绪后重新生成/重跑即可")
    else:
        print(f"[INFO] 0x27 密钥就绪：正例可正常解锁（{seedkey_key_file}）")

    all_methods = []
    all_calls = []

    # DID读取测试
    m, c = generate_did_read_tests(parsed_data.get("dids", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # DID写入测试
    m, c = generate_did_write_tests(parsed_data.get("dids", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # 多DID单次读取测试
    m, c = generate_multi_did_read_tests(parsed_data.get("dids", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # 功能寻址写入拒绝测试
    m, c = generate_functional_write_reject_tests(parsed_data.get("dids", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # DID P2时间验证测试
    m, c = generate_did_timing_tests(parsed_data.get("dids", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # Routine P2时间验证测试
    m, c = generate_routine_timing_tests(parsed_data.get("routines", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # IOControl P2时间验证测试
    m, c = generate_io_control_timing_tests(parsed_data.get("io_controls", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # IOControl测试
    m, c = generate_io_control_tests(parsed_data.get("io_controls", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # Routine测试
    m, c = generate_routine_tests(parsed_data.get("routines", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    # DTC测试
    m, c = generate_dtc_tests(parsed_data.get("dtcs", []))
    if m:
        all_methods.append(m)
    if c:
        all_calls.append(c)

    test_methods_str = '\n\n'.join(all_methods)
    test_calls_str = '\n'.join(all_calls)

    script = SCRIPT_HEADER.format(
        generation_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        source_file=source_file,
        channel=channel,
        serial=serial,
        can_if=can_if,
        bitrate=bitrate,
        sample_point=sample_point,
        tx_id=f"0x{tx_id:X}",
        rx_id=f"0x{rx_id:X}",
        func_id=f"0x{func_id:X}",
        p2_timeout=p2_timeout,
        p2_star_timeout=p2_star_timeout,
        s3_timeout=s3_timeout,
        sa_delay=sa_delay,
        can_fd=can_fd,
        fd_data_bitrate=fd_data_bitrate,
        fd_dsample_point=fd_dsample_point,
        fd_max_dlc=fd_max_dlc,
        seedkey_dll_path=seedkey_dll_path,
        seedkey_variant=seedkey_variant,
        seedkey_options=seedkey_options,
        seedkey_key_file=seedkey_key_file,
        can_addr_mode=can_addr_mode,
        can_addr_ext=can_addr_ext,
        survey_sa_levels=repr(sa_levels_found),
        timing_did=repr(timing_did),
        test_methods=test_methods_str,
        test_calls=test_calls_str,
    )

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(script)

    # 统计
    total_cases = 0
    # ISO 14229通用测试: $10(3+5) + $3E(4) + $11(7) + $27(6) + $28(6) + unsupportedSID(20) + timing(3+1+4+3+2) + boundary(6) + SA_delay(3) + P2_extract(3) + P2_compliance(2)
    total_cases += 3 + 5 + 4 + 7 + 6 + 6 + 20 + 10 + 6 + 3 + 3 + 2
    for did in parsed_data.get("dids", []):
        rw = did.get("rw_state", "R").upper()
        if "R" in rw:
            total_cases += 3 + 1  # 3 sessions + wrong length
            if did.get("functional_addressing", "N") == "Y":
                total_cases += 1
        if "W" in rw:
            total_cases += 5  # sessions + no security + wrong length
    # Multi-DID tests
    readable_count = sum(1 for d in parsed_data.get("dids", []) if "R" in d.get("rw_state", "R").upper())
    if readable_count >= 2:
        total_cases += 3  # 2-DID + 3-DID + invalid
    # Functional write reject
    write_count = sum(1 for d in parsed_data.get("dids", []) if "W" in d.get("rw_state", "R").upper())
    if write_count > 0:
        total_cases += 1
    # DID timing tests
    total_cases += min(5, readable_count)
    # Routine/IO timing tests
    total_cases += len(parsed_data.get("routines", []))  # routine timing
    total_cases += len(parsed_data.get("io_controls", []))  # io timing
    for _ in parsed_data.get("io_controls", []):
        total_cases += 3  # wrong session + no security + return control
    for _ in parsed_data.get("routines", []):
        total_cases += 3  # wrong session + no security + invalid control type
    dtc_count = len(parsed_data.get("dtcs", []))
    # $19: 01+02+0A + 03+04+05+07+08+09+0B-0E(4)+0F+14+42 + suppress + invalid = ~19 base + per-dtc
    # $14: all + 4 groups + programming + wrong length = 7
    # $85: OFF + ON + default reject + suppress + invalid subfunc = 5
    total_cases += 19 + dtc_count + 7 + 5
    # $27 lockout + boundary levels: ~10 cases
    total_cases += 10
    # $23 ReadMemoryByAddress: 4 cases
    total_cases += 4
    # $34-$38 download/upload: ~9 cases
    total_cases += 9
    # Optional services NRC ($29/$2A/$2C/$3D/$83/$84/$86/$87): ~45 cases
    total_cases += 45
    # NRC priority: 4 cases
    total_cases += 4
    # ISO 14229-2 Session Layer + suppress ($10/$28/$2A/$2C/$83/$86/$87): ~20 cases
    total_cases += 20
    # ISO 15765-2 Transport Layer: ~11 cases
    total_cases += 11
    # ISO 14229-3 UDSonCAN: ~8 cases
    total_cases += 8
    # ISO 15031-5 OBD: ~22 services+PIDs
    total_cases += 22
    # ISO 15031-6 DTC format: 1 case
    total_cases += 1
    # Service depth compliance ($10/$11/$27/$28/$2F boundary tests): ~55 cases
    total_cases += 55
    # ISO 14229-2 functional NRC rules (suppress + non-suppress): ~10 cases
    total_cases += 10
    # ISO 15765-2 edge cases: ~4 cases
    total_cases += 4
    # $19 additional sub-functions: ~15 cases
    total_cases += 15
    # Multi-DID edge cases (5+ DIDs, echo verify): ~5 cases
    total_cases += 5

    print(f"\n[INFO] 测试脚本已生成: {output_path}")
    print(f"  预计测试用例数: ~{total_cases}")

    return total_cases


def main():
    parser = argparse.ArgumentParser(description="UDS测试脚本生成器")
    parser.add_argument("--input", "-i", required=True, help="解析后的JSON文件路径")
    parser.add_argument("--output", "-o", required=True, help="输出测试脚本路径")
    parser.add_argument("--channel", default="", help="CAN通道 (Vector: 0-3, 留空自动选择)")
    parser.add_argument("--serial", default="", help="Vector 设备序列号 (留空=自动; 多盒子时指定 VN1630A/VN1640A)")
    parser.add_argument("--can-if", default="vector", choices=["vector"],
                        help="CAN接口类型 (仅支持vector, Vector XL Driver Library)")
    parser.add_argument("--bitrate", type=int, default=None, help="显式覆盖CAN波特率；留空则使用调查表/默认值")
    parser.add_argument("--sample-point", type=float, default=None, help="显式覆盖CAN采样点 (0.0~1.0, 如0.8=80%%)")
    parser.add_argument("--tx-id", default=None, help="显式覆盖发送CAN ID")
    parser.add_argument("--rx-id", default=None, help="显式覆盖接收CAN ID")
    parser.add_argument("--func-id", default=None, help="显式覆盖功能寻址CAN ID")
    parser.add_argument("--p2-timeout", type=int, default=50, help="P2 timeout (ms)")
    parser.add_argument("--p2-star-timeout", type=int, default=5000, help="P2* timeout (ms)")
    parser.add_argument("--s3-timeout", type=int, default=5000, help="S3 server timeout (ms)")
    parser.add_argument("--sa-delay", type=int, default=10000, help="Security access delay (ms)")
    parser.add_argument("--can-fd", action="store_true", default=False, help="启用CAN FD模式")
    parser.add_argument("--fd-data-bitrate", type=int, default=None, help="显式覆盖CAN FD数据段波特率")
    parser.add_argument("--fd-dsample-point", type=float, default=None, help="显式覆盖CAN FD数据段采样点 (0.0~1.0, 留空=使用调查表/驱动默认值)")
    parser.add_argument("--fd-max-dlc", type=int, default=64, choices=[8,12,16,20,24,32,48,64], help="CAN FD最大DLC")
    parser.add_argument("--sa-dll", default="", help="$27 SecurityAccess SeedKey DLL路径 (Vector标准接口)")
    parser.add_argument("--sa-variant", default="", help="SeedKey DLL ECU变体标识")
    parser.add_argument("--sa-options", default="", help="SeedKey DLL扩展选项 (仅GenerateKeyExOpt)")
    parser.add_argument("--sa-key-file", default="", help="$27 Gen2 密钥 JSON 文件（VolvoKey.json 格式：aes_cmac_key_0102 等；全 0xFF 占位会标 BLOCKED）")
    parser.add_argument("--addr-mode", default="normal_11bit",
                        choices=["normal_11bit", "normal_29bit", "mixed_11bit", "mixed_29bit", "normal_fixed"],
                        help="CAN ID寻址模式")
    parser.add_argument("--addr-ext", type=lambda x: int(x, 0), default=0x00, help="混合寻址Address Extension字节")
    parser.add_argument("--confirmed", action="store_true", default=False,
                        help="确认使用硬编码默认值（调查表缺失的CAN参数不再需要手动确认阻断）")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"[ERROR] 输入文件不存在: {args.input}")
        sys.exit(1)

    with open(args.input, "r", encoding="utf-8") as f:
        parsed_data = json.load(f)

    generate_test_script(
        parsed_data, args.output,
        channel=args.channel,
        serial=args.serial,
        can_if=getattr(args, 'can_if', 'vector'),
        bitrate=args.bitrate,
        sample_point=args.sample_point,
        tx_id=args.tx_id,
        rx_id=args.rx_id,
        func_id=args.func_id,
        p2_timeout=args.p2_timeout,
        p2_star_timeout=args.p2_star_timeout,
        s3_timeout=args.s3_timeout,
        sa_delay=args.sa_delay,
        can_fd_cli=(True if '--can-fd' in sys.argv else None),
        can_fd=args.can_fd,
        fd_data_bitrate=args.fd_data_bitrate,
        fd_dsample_point=args.fd_dsample_point,
        fd_max_dlc=args.fd_max_dlc,
        seedkey_dll_path=args.sa_dll,
        seedkey_variant=args.sa_variant,
        seedkey_options=args.sa_options,
        seedkey_key_file=args.sa_key_file,
        can_addr_mode=args.addr_mode,
        can_addr_ext=args.addr_ext,
        confirmed=args.confirmed,
    )


if __name__ == "__main__":
    main()
