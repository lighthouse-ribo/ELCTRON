#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""分区模型离线回归测试。"""

import json
import os
import subprocess
import sys
import unittest

from partition_model import (
    MatrixExpectation,
    build_partition_model,
    infer_case_partition,
    normalize_did,
    normalize_partition,
    normalize_session,
)
from testsupport import WorkspaceTempDir


HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.path.join(HERE, "gen_case_scripts.py")


class TestPartitionModel(unittest.TestCase):
    def test_normalizes_partition_session_and_did(self):
        self.assertEqual(normalize_partition("Application Layer"), "APP")
        self.assertEqual(normalize_partition("secondary boot loader"), "SBL")
        self.assertEqual(normalize_session("编程会话"), "programming")
        self.assertEqual(normalize_session("0x03"), "extended")
        self.assertEqual(normalize_did("0xF18C"), "F18C")

    def test_matrix_value_keeps_undefined_negative_and_positive_distinct(self):
        undefined = MatrixExpectation.from_value("")
        negative = MatrixExpectation.from_value("NRC31")
        positive = MatrixExpectation.from_value("51 11 11 56")
        self.assertFalse(undefined.defined)
        self.assertEqual(undefined.kind, "undefined")
        self.assertTrue(negative.defined)
        self.assertFalse(negative.supported)
        self.assertEqual(negative.expected_nrc, (0x31,))
        self.assertTrue(positive.supported)
        self.assertEqual(positive.expected_value, "51 11 11 56")

    def test_case_partition_does_not_default_to_app(self):
        self.assertEqual(infer_case_partition({"target_partition": "PBL"}), "PBL")
        self.assertEqual(infer_case_partition({"test_point": "SBL 编程会话读取"}), "SBL")
        self.assertIsNone(infer_case_partition({"test_point": "APP/PBL 对比"}))
        self.assertIsNone(infer_case_partition({"test_point": "读取 DID"}))

    def test_model_combines_survey_attributes_and_partition_matrix(self):
        model = build_partition_model(
            did_matrix={
                "D09B": {"APP": "01 05 01", "PBL": "01 01 01", "SBL": "01 01 01"},
                "F190": {"APP": "", "PBL": "", "SBL": ""},
            },
            parsed={
                "source_file": "APP_diagnostic.xlsx",
                "dids": [{
                    "did_number": "0xD09B",
                    "did_name": "Software Version",
                    "rw_state": "R",
                    "read_sessions": {"default_0x01": "Y", "programming_0x02": "N", "extended_0x03": "Y"},
                }],
            },
            source_files=("APP_diagnostic.xlsx", "DID检查.xlsx"),
        )
        d09b = model.lookup("D09B", "APP")
        self.assertIsNotNone(d09b)
        self.assertEqual(d09b.name, "Software Version")
        self.assertTrue(model.expectation("D09B", "APP").supported)
        self.assertFalse(model.expectation("F190", "APP").defined)
        context = model.case_context(
            {"target_partition": "PBL", "test_point": "读取 DID"}, "D09B"
        )
        self.assertEqual(context["target_partition"], "PBL")
        self.assertEqual(context["matrix_expectation"]["raw"], "01 01 01")

    def test_unresolved_partition_keeps_global_did_definition(self):
        model = build_partition_model(did_matrix={
            "D09B": {"APP": "Y", "PBL": "NRC31", "SBL": "Y"},
        })
        context = model.case_context({"test_point": "读取 DID"}, "D09B")
        self.assertTrue(context["did_defined"])
        self.assertFalse(context["partition_resolved"])
        self.assertNotIn("matrix_expectation", context)

    def test_unknown_did_attributes_are_provisional_not_real_restrictions(self):
        model = build_partition_model(
            did_matrix={"D03A": {"APP": "Y", "PBL": "NRC31", "SBL": "NRC31"}},
            parsed={"dids": [{
                "did_number": "D03A",
                "did_name": "Unknown DID",
                "rw_state": "R",
                "read_sessions": {"default_0x01": "N", "extended_0x03": "N"},
            }]},
        )
        spec = model.lookup("D03A")
        self.assertTrue(spec.attributes_provisional)
        self.assertIsNone(spec.session_allowed("default"))

    def test_conditional_nrc_and_timing_parameters_are_serialized(self):
        model = build_partition_model(
            did_matrix={"D03A": {"APP": "Y", "PBL": "NRC31", "SBL": "NRC31"}},
            conditional_nrcs={"0xd03a": {"app": "0x22"}},
            timing_parameters={
                "APP": {"p2_ms": 50, "source": "app"},
                "PBL": {"p2_ms": 25, "source": "pbl"},
            },
        )
        self.assertEqual(model.expectation("D03A", "APP").conditional_nrc, (0x22,))
        self.assertEqual(model.p2_limit("PBL"), 25.0)
        serialized = model.to_dict()
        self.assertEqual(serialized["timing_parameters"]["PBL"]["p2_ms"], 25.0)
        self.assertEqual(serialized["dids"]["D03A"]["matrix"]["APP"]["conditional_nrc"], [0x22])

    def test_generator_writes_partition_context_to_manifest(self):
        with WorkspaceTempDir("partition") as td:
            cases_path = os.path.join(td, "cases.json")
            parsed_path = os.path.join(td, "parsed.json")
            matrix_path = os.path.join(td, "matrix.json")
            out_dir = os.path.join(td, "out")
            # Generator's xlsx reader is intentionally not exercised here; use an
            # empty matrix and verify that unresolved partition is explicitly kept.
            with open(cases_path, "w", encoding="utf-8") as f:
                json.dump({"cases": [{
                    "case_id": "UDS_0x22_TC_PARTITION",
                    "test_point": "读取 DID",
                    "procedure": "请求: 22 D0 9B",
                    "expected": "正响应",
                    "precondition": "默认会话",
                }]}, f, ensure_ascii=False)
            with open(parsed_path, "w", encoding="utf-8") as f:
                json.dump({"source_file": "APP_diagnostic.xlsx", "dids": []}, f)
            # Path is deliberately absent; parse_did_matrix returns an empty model.
            result = subprocess.run(
                [sys.executable, GEN, "--cases", cases_path, "--parsed", parsed_path,
                 "--did-check", matrix_path, "--out-dir", out_dir, "--confirmed"],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            with open(os.path.join(out_dir, "manifest.json"), encoding="utf-8") as f:
                manifest = json.load(f)
            context = manifest["cases"]["UDS_0x22_TC_PARTITION"]["partition_context"]
            self.assertIsNone(context["target_partition"])
            self.assertFalse(context["partition_resolved"])
            self.assertEqual(context["did"], "D09B")


if __name__ == "__main__":
    unittest.main()
