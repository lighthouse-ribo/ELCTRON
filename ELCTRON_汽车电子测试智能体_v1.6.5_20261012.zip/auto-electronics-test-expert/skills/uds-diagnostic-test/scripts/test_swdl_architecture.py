# -*- coding: utf-8 -*-
"""SWDL 可填充架构契约的行为测试。"""

import unittest

from swdl_architecture import (
    STATUS_BLOCKED,
    STATUS_DEGRADED,
    STATUS_READY,
    assess_swdl_capabilities,
    build_swdl_case_skeleton,
)


class TestSwdlArchitecture(unittest.TestCase):
    def test_missing_key_blocks_execution_but_keeps_design_and_report_available(self):
        result = assess_swdl_capabilities({
            "flash_flowchart": {"status": "confirmed"},
            "memory_map": {"status": "confirmed"},
            "image": {"status": "confirmed", "sha256": "a" * 64},
            "security_key_material": {"status": "blocked", "material": False},
            "check_memory": {"status": "pending"},
            "timing": {"status": "pending"},
        })

        self.assertEqual(result["overall_status"], STATUS_DEGRADED)
        self.assertEqual(result["capabilities"]["case_design"], STATUS_READY)
        self.assertEqual(result["capabilities"]["static_review"], STATUS_READY)
        self.assertEqual(result["capabilities"]["hardware_execution"], STATUS_BLOCKED)
        self.assertEqual(result["capabilities"]["report_generation"], STATUS_READY)
        self.assertTrue(any("0x27" in item for item in result["execution_blockers"]))

    def test_missing_flowchart_blocks_swdl_case_generation(self):
        result = assess_swdl_capabilities({
            "image": {"status": "confirmed", "sha256": "a" * 64},
            "security_key_material": {"status": "blocked", "material": False},
        })

        self.assertEqual(result["capabilities"]["case_design"], STATUS_BLOCKED)
        self.assertEqual(result["capabilities"]["static_review"], STATUS_BLOCKED)
        self.assertIn("flash_flowchart", result["missing_inputs"])

    def test_case_skeleton_has_fillable_stages_and_explicit_unknowns(self):
        case = build_swdl_case_skeleton("SBL", requirement_ids=["SWDL-FLOW-001"])

        self.assertEqual(case["case_id"], "SWDL-SBL-BASE-001")
        self.assertEqual(case["status"], "PLANNED")
        self.assertEqual(case["requirement_ids"], ["SWDL-FLOW-001"])
        self.assertEqual(
            [stage["stage_id"] for stage in case["stages"]],
            [
                "session-programming",
                "security-access",
                "request-download",
                "transfer-data",
                "transfer-exit",
                "check-memory",
                "reset",
                "version-confirmation",
            ],
        )
        security_stage = case["stages"][1]
        self.assertEqual(security_stage["status"], "BLOCKED")
        self.assertIn("0x27", security_stage["blocked_by"])
        self.assertEqual(case["expected_final_state"], "UNKNOWN")
        self.assertIn("request_response_trace", case["evidence_required"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
