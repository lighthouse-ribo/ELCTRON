#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ISO 14229 设计期望门禁回归测试。"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))

from expectation_check import check_cases


class TestExpectationCheck(unittest.TestCase):
    def test_suppressed_response_requires_explicit_expectation(self):
        report = check_cases([{
            "case_id": "UDS_0x10_TC_SUPPRESS",
            "procedure": "请求：51 02 10 82 FF FF FF FF",
            "expected": "正响应",
            "precondition": "默认会话",
        }])
        self.assertEqual(report["status"], "FAIL")
        self.assertTrue(any(item["rule"] == "ISO-SUPPRESS-001" for item in report["issues"]))

    def test_suppressed_response_with_session_evidence_is_allowed(self):
        report = check_cases([{
            "case_id": "UDS_0x10_TC_SUPPRESS_OK",
            "procedure": "请求：51 02 10 82 FF FF FF FF",
            "expected": "不发送正响应；保持编程会话",
            "precondition": "默认会话",
        }])
        self.assertNotEqual(report["status"], "FAIL")

    def test_default_session_s3_is_rejected(self):
        report = check_cases([{
            "case_id": "UDS_TimeParm_S3_DEFAULT",
            "procedure": "请求：51 02 22 F1 90 FF FF FF",
            "test_point": "S3 边界测量",
            "expected": "测量 S3Server",
            "precondition": "默认会话",
        }])
        self.assertTrue(any(item["rule"] == "ISO-S3-001" for item in report["issues"]))

    def test_did_high_byte_is_not_suppress_bit(self):
        report = check_cases([{
            "case_id": "UDS_0x22_F190",
            "procedure": "请求：51 03 22 F1 90 FF FF FF",
            "expected": "正响应",
            "precondition": "默认会话",
        }])
        self.assertFalse(any(item["rule"].startswith("ISO-SUPPRESS-")
                            for item in report["issues"]))

    def test_negative_case_requires_nrc(self):
        report = check_cases([{
            "case_id": "UDS_0x22_TC_NEG",
            "procedure": "请求：22 F1 90",
            "test_point": "负向读取",
            "expected": "返回负响应",
            "precondition": "默认会话",
        }])
        self.assertTrue(any(item["rule"] == "ISO-NRC-001" for item in report["issues"]))

    def test_forbidden_session_transition_requires_nrc_22(self):
        report = check_cases([{
            "case_id": "UDS_0x10_TC_FORBIDDEN",
            "procedure": "请求：10 03",
            "test_point": "会话切换",
            "expected": "正响应",
            "precondition": "编程会话",
        }], bus="can")
        self.assertTrue(any(item["rule"] == "ISO-SESSION-001" for item in report["issues"]))

    def test_custom_project_session_matrix_and_transition_nrc_are_used(self):
        config = {
            "sessions": {
                "supported": ["0x01", "0x04"],
                "names": {"0x01": "Normal", "0x04": "Diagnostic"},
                "default": "0x01",
                "allowed_transitions": {
                    "0x01": ["0x01", "0x04"],
                    "0x04": ["0x04"],
                },
                "transition_nrc": "0x24",
                "s3_required": ["0x04"],
            },
        }
        report = check_cases([{
            "case_id": "UDS_0x10_TC_CUSTOM_FORBIDDEN",
            "procedure": "请求：10 01",
            "test_point": "DENY session transition",
            "expected": "negative response NRC=0x24",
            "precondition": "Diagnostic",
        }], bus="can", project_config=config)
        self.assertFalse(any(item["rule"] == "ISO-SESSION-001" for item in report["issues"]))

    def test_custom_project_s3_session_is_used(self):
        config = {
            "sessions": {
                "supported": ["0x01", "0x04"],
                "names": {"0x01": "Normal", "0x04": "Diagnostic"},
                "default": "0x01",
                "allowed_transitions": {
                    "0x01": ["0x01", "0x04"],
                    "0x04": ["0x01", "0x04"],
                },
                "s3_required": ["0x04"],
            },
        }
        report = check_cases([{
            "case_id": "UDS_TimeParm_S3_CUSTOM",
            "procedure": "请求：22 F1 90",
            "test_point": "S3 边界测量",
            "expected": "测量 S3Server",
            "precondition": "Diagnostic",
        }], project_config=config)
        self.assertFalse(any(item["rule"] == "ISO-S3-001" for item in report["issues"]))


if __name__ == "__main__":
    unittest.main()
