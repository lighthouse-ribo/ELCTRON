# -*- coding: utf-8 -*-
"""第十一步：生成产物与 project_context 绑定测试。"""

from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from project_artifact_binding import (  # noqa: E402
    ProjectArtifactBindingError,
    build_project_context_binding,
    validate_artifact_binding,
    validate_project_context_binding,
)
from testsupport import WorkspaceTempDir  # noqa: E402


class TestProjectArtifactBinding(unittest.TestCase):
    def setUp(self):
        self.temp_dir = WorkspaceTempDir("artifact-binding")
        self.addCleanup(self.temp_dir.cleanup)
        self.root = Path(self.temp_dir.name)
        self.context = self.root / "project_context.json"
        self.context.write_text(json.dumps({
            "schema_version": "portable-contract/v0.1",
            "project": {"id": "binding-test"},
            "facts": [],
            "gaps": [],
        }), encoding="utf-8")
        self.artifact_dir = self.root / "case_scripts"
        self.artifact_dir.mkdir()

    def test_binding_is_relative_and_contains_only_identity_summary(self):
        binding = build_project_context_binding(self.context, self.artifact_dir)

        self.assertEqual(binding["project_context"]["path"], "../project_context.json")
        self.assertEqual(binding["project_id"], "binding-test")
        self.assertNotIn("facts", json.dumps(binding))
        self.assertEqual(
            validate_project_context_binding(binding, self.artifact_dir)["project_id"],
            "binding-test",
        )

    def test_modified_context_is_blocked(self):
        binding = build_project_context_binding(self.context, self.artifact_dir)
        self.context.write_text(self.context.read_text(encoding="utf-8") + "\n", encoding="utf-8")

        with self.assertRaises(ProjectArtifactBindingError):
            validate_project_context_binding(binding, self.artifact_dir)

    def test_artifact_must_match_current_context(self):
        binding = build_project_context_binding(self.context, self.artifact_dir)
        artifact = self.artifact_dir / "manifest.json"
        artifact.write_text(json.dumps({"project_context_binding": binding}), encoding="utf-8")
        other_context = self.root / "other_context.json"
        other_context.write_text(self.context.read_text(encoding="utf-8") + "\n", encoding="utf-8")

        with self.assertRaises(ProjectArtifactBindingError):
            validate_artifact_binding(artifact, expected_context_path=other_context)

    def test_generated_run_all_blocks_after_context_changes(self):
        cases = self.root / "cases.json"
        parsed = self.root / "parsed.json"
        out_dir = self.root / "generated"
        cases.write_text(json.dumps({"cases": [{
            "case_id": "C1",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "默认会话",
        }]}), encoding="utf-8")
        parsed.write_text("{}", encoding="utf-8")

        generated = subprocess.run(
            [sys.executable, str(HERE / "gen_case_scripts.py"),
             "--cases", str(cases), "--parsed", str(parsed),
             "--out-dir", str(out_dir), "--project-context", str(self.context),
             "--confirmed"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertEqual(generated.returncode, 0, generated.stderr)
        manifest = json.loads((out_dir / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["project_context_binding"]["project_id"], "binding-test")

        self.context.write_text(self.context.read_text(encoding="utf-8") + "\n", encoding="utf-8")
        run = subprocess.run(
            [sys.executable, str(out_dir / "run_all.py")],
            cwd=str(out_dir), capture_output=True, text=True,
            encoding="utf-8", errors="replace",
        )
        self.assertNotEqual(run.returncode, 0)
        self.assertIn("绑定校验失败", run.stdout + run.stderr)

    def test_incremental_generation_cannot_bind_old_unbound_manifest(self):
        cases = self.root / "cases.json"
        parsed = self.root / "parsed.json"
        out_dir = self.root / "incremental"
        cases.write_text(json.dumps({"cases": [{
            "case_id": "C1",
            "test_point": "读取 DID",
            "procedure": "请求: 22 F1 90",
            "expected": "正响应",
            "precondition": "默认会话",
        }]}), encoding="utf-8")
        parsed.write_text("{}", encoding="utf-8")
        base = [sys.executable, str(HERE / "gen_case_scripts.py"),
                "--cases", str(cases), "--parsed", str(parsed),
                "--out-dir", str(out_dir), "--confirmed"]
        generated = subprocess.run(base, capture_output=True, text=True,
                                   encoding="utf-8", errors="replace")
        self.assertEqual(generated.returncode, 0, generated.stderr)

        incremental = subprocess.run(
            base + ["--only", "C1", "--project-context", str(self.context)],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        self.assertNotEqual(incremental.returncode, 0)
        self.assertIn("旧 manifest 未绑定", incremental.stdout + incremental.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
