# -*- coding: utf-8 -*-
"""把内部生成模型映射为系统合格性测试用例表的公共字段。

该模块只负责写作逻辑与静态字段契约，不负责 XLSX 落盘、不连接硬件。
"""

from __future__ import annotations

from typing import Any, Mapping

REFERENCE_FIELDS = (
    "req_sources", "case_id", "priority", "auto_eval", "test_point",
    "test_method", "design_method", "env", "precondition", "procedure",
    "expected", "select",
)


def make_reference_case(
    *,
    req_sources: str,
    case_id: str,
    priority: str,
    auto_eval: str,
    test_point: str,
    test_method: str,
    design_method: str,
    env: str,
    precondition: str,
    procedure: str,
    expected: str,
    generation_status: str = "READY",
    execution_verdict: str = "NOT_EXECUTED",
    **extra: Any,
) -> dict[str, Any]:
    """创建与参考 XLSX B~N 列等价的内部用例对象。"""
    case = {
        "req_sources": str(req_sources).strip(),
        "case_id": str(case_id).strip(),
        "priority": str(priority).strip(),
        "auto_eval": str(auto_eval).strip(),
        "test_point": str(test_point).strip(),
        "test_method": str(test_method).strip(),
        "design_method": str(design_method).strip(),
        "env": str(env).strip(),
        "precondition": str(precondition).strip(),
        "procedure": str(procedure).strip(),
        "expected": str(expected).strip(),
        "select": "是",
        "generation_status": generation_status,
        "execution_verdict": execution_verdict,
        "test_result": "",
        "test_conclusion": "未执行",
    }
    case.update(extra)
    case["traceability_status"] = "READY" if case["req_sources"] else "BLOCKED"
    return case


def validate_reference_case(case: Mapping[str, Any] | None) -> dict[str, Any]:
    data = dict(case or {})
    errors = [f"缺少参考字段: {field}" for field in REFERENCE_FIELDS if not data.get(field)]
    if data.get("execution_verdict") == "PASS" and data.get("test_result") != "PASS":
        errors.append("未填入实测结果时不能宣称 PASS")
    if data.get("generation_status") == "BLOCKED" and data.get("test_result") == "PASS":
        errors.append("BLOCKED 用例不能标记 PASS")
    return {
        "schema_version": "reference-case-review/v0.1",
        "valid": not errors,
        "status": "PASS" if not errors else "BLOCKED",
        "errors": errors,
    }


__all__ = ["REFERENCE_FIELDS", "make_reference_case", "validate_reference_case"]
