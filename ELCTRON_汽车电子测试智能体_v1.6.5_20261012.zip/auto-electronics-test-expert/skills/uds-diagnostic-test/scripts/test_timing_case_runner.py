#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""逐用例时序 runner 离线回归，不连接 F1L1 硬件。"""

import json
import os
import unittest
from unittest.mock import patch

from timing_case_runner import (
    _establish_session,
    _match_request_response,
    _parse_can_frame,
    _reconcile_timing_measurement,
    build_timing_spec,
    evaluate_timing_case,
    run_timing_case,
)
from testsupport import WorkspaceTempDir
from lin_tp import pack_cf, pack_ff, pack_fc, pack_sf


class FakeTimingUDS:
    """离线验证专项 runner 的请求形态和流控参数，不模拟普通 P2 汇总。"""

    def __init__(self, response_payload):
        self.response_payload = list(response_payload)
        self.trace_calls = []

    def request(self, _nad, payload, timeout=3.0, retry=0):
        payload = list(payload)
        if payload == [0x10, 0x01]:
            return [0x50, 0x01]
        if payload == [0x22, 0xF1, 0x86]:
            return [0x62, 0xF1, 0x86, 0x01]
        raise AssertionError(f"unexpected setup request: {payload}")

    def request_with_trace(self, nad, payload, timeout=3.0, retry=0, flow_control=None):
        payload = list(payload)
        self.trace_calls.append({
            "nad": nad, "payload": payload, "timeout": timeout,
            "retry": retry, "flow_control": flow_control,
        })
        response = list(self.response_payload)
        ff, rest = pack_ff(nad, response)
        trace = [
            (1.000, "TX", 0x3C, list(pack_sf(nad, payload))),
            (1.010, "RX", 0x3D, list(ff)),
        ]
        if flow_control is not None:
            trace.append((1.020, "TX", 0x3C, list(pack_fc(nad, *flow_control))))
        if rest:
            for seq, offset in enumerate(range(0, len(rest), 6), 1):
                trace.append((1.020 + seq * 0.010, "RX", 0x3D,
                              list(pack_cf(nad, seq, rest[offset:offset + 6]))))
        return response, trace, 1.000, 1.100


class TestTimingSpecs(unittest.TestCase):
    def test_can_frame_parser_and_matching_use_configured_ids(self):
        spec = build_timing_spec(
            "UDS_TimeParm_TC_0001", [0x22, 0xF1, 0x90], "default", 0x51,
            bus="can", tx_frame_id=0x650, rx_frame_id=0x658,
        )
        events = [
            {"event_index": 0, "transaction_id": "can-t1", "direction": "TX",
             "frame_id": 0x650, "data": [0x03, 0x22, 0xF1, 0x90, 0xCC, 0xCC, 0xCC, 0xCC]},
            {"event_index": 1, "transaction_id": "can-t1", "direction": "RX",
             "frame_id": 0x658, "data": [0x04, 0x62, 0xF1, 0x90, 0x01, 0x00, 0x00, 0x00]},
        ]
        self.assertEqual(_parse_can_frame(events[0]["data"])[0], "sf")
        pair = _match_request_response(
            events, 0x51, spec["payload"], bus="can",
            tx_frame_id=spec["tx_frame_id"], rx_frame_id=spec["rx_frame_id"],
        )
        self.assertIsNotNone(pair)
        self.assertEqual(pair[0]["frame_id"], 0x650)

    def test_custom_session_id_is_used_for_timing_setup(self):
        class CustomSessionUDS:
            def __init__(self):
                self.requests = []

            def request(self, _nad, payload, timeout=3.0, retry=0):
                del timeout, retry
                payload = list(payload)
                self.requests.append(payload)
                if payload == [0x10, 0x01]:
                    return [0x50, 0x01]
                if payload == [0x10, 0x40]:
                    return [0x50, 0x40]
                if payload == [0x3E, 0x80]:
                    return None
                if payload == [0x22, 0xF1, 0x86]:
                    return [0x62, 0xF1, 0x86, 0x40]
                raise AssertionError(payload)

        uds = CustomSessionUDS()
        ok, reason = _establish_session(
            uds, 0x51, "boot", {"default": 0x01, "boot": 0x40}, 0x01,
        )
        self.assertTrue(ok, reason)
        self.assertEqual(uds.requests, [
            [0x10, 0x01], [0x10, 0x40], [0x3E, 0x80], [0x22, 0xF1, 0x86],
        ])

    def test_custom_session_ids_are_used_by_timing_spec_and_verdicts(self):
        spec = build_timing_spec(
            "UDS_TimeParm_TC_0010", [0x22, 0xF1, 0x86], "boot", 0x51,
            procedure="验证 S3 边界",
            default_session_id=0x40,
            session_id_by_name={"default": 0x40, "boot": 0x44},
        )
        self.assertEqual(spec["session_transition_ids"], [0x44, 0x40])
        self.assertEqual(spec["expected_sessions"], [[0x44], [0x40, 0x44], [0x40]])
        reset_spec = build_timing_spec(
            "UDS_TimeParm_TC_0014", [0x11, 0x01], "default", 0x51,
            default_session_id=0x40,
            session_id_by_name={"default": 0x40, "boot": 0x44},
        )
        self.assertEqual(
            evaluate_timing_case(reset_spec, {
                "recovery_ms": [100.0],
                "reset_response_ok": True,
                "recovered_session": 0x40,
            })["verdict"],
            "PASS",
        )

    def test_can_bs_stmin_uses_configured_tx_id(self):
        spec = build_timing_spec(
            "UDS_TimeParm_TC_0007", [0x22, 0xF1, 0x2E], "default", 0x51,
            procedure="解析 FF/CF 的 BS 与 STmin",
            expected="BS=0，STmin=0ms",
            bus="can", tx_frame_id=0x650, rx_frame_id=0x658,
        )
        result = evaluate_timing_case(spec, {
            "bs_stmin": {
                "bs": 0, "stmin": 0, "frame_id": 0x650,
                "direction": "TX", "payload": [0, 0],
            },
            "response_frame_count": 2,
            "response": [0x62, 0xF1, 0x2E],
        })
        self.assertEqual(result["verdict"], "PASS")

    def test_can_timing_uses_can_runtime_adapter(self):
        spec = build_timing_spec(
            "UDS_TimeParm_TC_0001", [0x22, 0xF1, 0x86], "default", 0x51,
            bus="can", tx_frame_id=0x650, rx_frame_id=0x658,
        )

        class FakeCanTimingUDS:
            def request(self, _nad, payload, timeout=3.0, retry=0):
                del timeout, retry
                if list(payload) == [0x10, 0x01]:
                    return [0x50, 0x01]
                if list(payload) == [0x22, 0xF1, 0x86]:
                    return [0x62, 0xF1, 0x86, 0x01]
                raise AssertionError(payload)

            def request_with_trace(self, _nad, payload, timeout=3.0, flow_control=None, transaction_id=None):
                del timeout, flow_control
                trace = [
                    (1.000, "TX", 0x650, [0x03, *list(payload), 0xCC, 0xCC, 0xCC, 0xCC]),
                    (1.020, "RX", 0x658, [0x04, 0x62, 0xF1, 0x86, 0x01, 0x00, 0x00, 0x00]),
                ]
                return [0x62, 0xF1, 0x86, 0x01], trace, 1.000, 1.020

        with WorkspaceTempDir("timing_can") as td:
            result_path = os.path.join(td, "UDS_TimeParm_TC_0001.json")
            with patch("timing_case_runner._create_can_timing_uds",
                       return_value=(FakeCanTimingUDS(), lambda: None)):
                result = run_timing_case(
                    spec, result_path, bus="can", can_runtime="runtime.py",
                    can_tx_id=0x650, can_rx_id=0x658,
                )
            self.assertEqual(result["verdict"], "PASS")
            self.assertTrue(os.path.isfile(result_path))

    def test_can_runtime_failure_is_blocked_not_ecu_fail(self):
        spec = build_timing_spec(
            "UDS_TimeParm_TC_0001", [0x22, 0xF1, 0x86], "default", 0x51,
            bus="can", tx_frame_id=0x650, rx_frame_id=0x658,
        )
        with WorkspaceTempDir("timing_can_runtime_error") as td:
            result_path = os.path.join(td, "UDS_TimeParm_TC_0001.json")
            with patch("timing_case_runner._create_can_timing_uds",
                       side_effect=RuntimeError("Vector 通道被占用")):
                result = run_timing_case(spec, result_path, bus="can")
            self.assertEqual(result["verdict"], "BLOCKED")
            self.assertEqual(result["failure_class"], "INFRA_ERROR")

    def test_p2_uses_exact_request_frame_and_following_response(self):
        events = [
            {"event_index": 0, "transaction_id": "t1", "direction": "TX",
             "frame_id": 0x3C, "data": [0x51, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
             "nad": 0x51},
            {"event_index": 1, "transaction_id": "t1", "direction": "TX",
             "frame_id": 0x3C, "data": [0x51, 0x03, 0x22, 0xF1, 0x90, 0xFF, 0xFF, 0xFF],
             "nad": 0x51},
            {"event_index": 2, "transaction_id": "t1", "direction": "RX",
             "frame_id": 0x3D, "data": [0x51, 0x03, 0x7F, 0x22, 0x31, 0xFF, 0xFF, 0xFF],
             "nad": 0x51, "ts": 1.020},
        ]
        events[1]["ts"] = 1.000
        pair = _match_request_response(events, 0x51, [0x22, 0xF1, 0x90])
        self.assertIsNotNone(pair)
        self.assertEqual(pair[0]["event_index"], 1)
        self.assertEqual(pair[1]["event_index"], 2)

    def test_p2_trace_reconciliation_rejects_mismatched_report(self):
        spec = build_timing_spec("UDS_TimeParm_TC_0001", [0x22, 0xF1, 0x90], "default", 0x51)
        traces = [
            {"event_index": 0, "transaction_id": "t1", "sample_index": 1,
             "request_payload": [0x22, 0xF1, 0x90], "direction": "TX", "frame_id": 0x3C,
             "data": [0x51, 0x03, 0x22, 0xF1, 0x90, 0xFF, 0xFF, 0xFF], "nad": 0x51, "ts": 1.000},
            {"event_index": 1, "transaction_id": "t1", "sample_index": 1,
             "request_payload": [0x22, 0xF1, 0x90], "direction": "RX", "frame_id": 0x3D,
             "data": [0x51, 0x03, 0x7F, 0x22, 0x31, 0xFF, 0xFF, 0xFF], "nad": 0x51, "ts": 1.020},
        ]
        measurement = _reconcile_timing_measurement(spec, {"p2_ms": [59.2], "traces": traces})
        self.assertEqual(measurement["trace_p2_ms"], [20.0])
        self.assertEqual(measurement["trace_integrity"]["status"], "INVALID")
        self.assertIn("结果与原始 trace 不一致", measurement["error"])

    def test_timing_spec_keeps_partition_specific_p2_limit(self):
        pbl = build_timing_spec(
            "UDS_TimeParm_TC_0001", [0x22, 0xF1, 0x86], "default", 0x51,
            target_partition="PBL", p2_limit=25.0,
        )
        self.assertEqual(pbl["target_partition"], "PBL")
        self.assertEqual(pbl["max_ms"], 25.0)
        self.assertEqual(pbl["p2_limit_source"], "PartitionModel")

    def test_allowed_conditional_nrc_is_not_response_fail(self):
        spec = build_timing_spec(
            "UDS_TimeParm_TC_0001", [0x22, 0xD0, 0x3A], "default", 0x51,
            allowed_response_nrcs=[0x22],
        )
        result = evaluate_timing_case(spec, {
            "p2_ms": [20.0] * 5,
            "response_verdict": "NA",
            "response_errors": [],
        })
        self.assertEqual(result["timing_verdict"], "PASS")
        self.assertEqual(result["verdict"], "PASS")

        from timing_case_runner import _response_verdict
        self.assertEqual(
            _response_verdict([0x7F, 0x22, 0x22], spec)[0], "NA"
        )

    def test_response_failure_is_separate_from_p2_timing(self):
        spec = build_timing_spec("UDS_TimeParm_TC_0001", [0x22, 0xF1, 0x90], "default", 0x51)
        result = evaluate_timing_case(spec, {
            "p2_ms": [20.0] * 5,
            "response_verdict": "FAIL",
            "response_errors": ["正向时序用例收到负响应，NRC=0x31"],
        })
        self.assertEqual(result["timing_verdict"], "PASS")
        self.assertEqual(result["response_verdict"], "FAIL")
        self.assertEqual(result["verdict"], "FAIL")

    def test_fifteen_timeparm_cases_have_independent_metrics(self):
        metrics = []
        for index in range(1, 16):
            spec = build_timing_spec(
                f"UDS_TimeParm_TC_{index:04d}", [0x22, 0xF1, 0x86],
                "default", 0x51, procedure="", expected="",
            )
            metrics.append(spec["metric"])
            self.assertEqual(spec["case_id"], f"UDS_TimeParm_TC_{index:04d}")
        self.assertEqual(metrics[0:4], ["p2", "p2", "p2_star", "s3"])
        self.assertEqual(metrics[4:9], ["n_as", "n_cr", "bs_stmin", "p4", "frame_jitter"])
        self.assertEqual(metrics[9:], ["s3_boundary", "frame_gap", "multi_frame",
                                       "session_transitions", "reset_recovery", "p2_distribution"])

    def test_non_timeparm_case_suffix_does_not_inherit_timeparm_metric(self):
        self.assertEqual(
            build_timing_spec(
                "UDS_0x11_TC_0008", [0x11, 0x01], "default", 0x51,
                procedure="测量请求到正响应时间",
                expected="P2Server_max=50ms",
            )["metric"],
            "p2",
        )
        self.assertEqual(
            build_timing_spec(
                "UDS_0x31_TC_0012", [0x31, 0x01, 0x02, 0x06], "default", 0x51,
                procedure="测量请求到正响应时间",
                expected="P4Server_max=50ms",
            )["metric"],
            "p4",
        )
        self.assertEqual(
            build_timing_spec(
                "UDS_0x3E_TC_0010", [0x3E, 0x00], "default", 0x51,
                procedure="测量响应时间",
                expected="P2Server_max=50ms",
            )["metric"],
            "p2",
        )
        self.assertEqual(
            build_timing_spec(
                "UDS_0x10_TC_0001", [0x10, 0x01], "default", 0x51,
                procedure="等待并解析响应，测量响应时间",
                expected="P2Server_max=50ms，P2*Server_max=5000ms",
            )["metric"],
            "p2",
        )

    def test_missing_measurement_is_fail_not_skip_or_error(self):
        spec = build_timing_spec("UDS_TimeParm_TC_0001", [0x22, 0xF1, 0x86], "default", 0x51)
        result = evaluate_timing_case(spec, {})
        self.assertEqual(result["verdict"], "FAIL")
        self.assertNotIn(result["verdict"], {"SKIP", "ERROR"})

    def test_bs_stmin_uses_its_own_evidence(self):
        spec = build_timing_spec(
            "UDS_TimeParm_TC_0007", [0x22, 0xF1, 0x2E], "default", 0x51,
            procedure="解析 FF/CF 的 BS 与 STmin",
            expected="BS=0，STmin=0ms",
        )
        self.assertEqual(spec["metric"], "bs_stmin")
        self.assertEqual(spec["expected_bs"], 0)
        self.assertEqual(spec["expected_stmin"], 0)
        result = evaluate_timing_case(spec, {"p2_ms": [5.0]})
        self.assertEqual(result["verdict"], "FAIL")

    def test_n_as_rejects_a_single_frame_p2_measurement(self):
        spec = build_timing_spec("UDS_TimeParm_TC_0005", [0x22, 0xF1, 0x86], "default", 0x51)
        result = evaluate_timing_case(spec, {"p2_ms": [5.0]})
        self.assertEqual(spec["metric"], "n_as")
        self.assertEqual(result["verdict"], "FAIL")

    def test_n_as_accepts_its_own_single_frame_request_response_measurement(self):
        spec = build_timing_spec("UDS_TimeParm_TC_0005", [0x22, 0xF1, 0x86], "default", 0x51)
        result = evaluate_timing_case(spec, {
            "n_as_ms": [20.0],
            "request_frame_count": 1,
            "response_frame_count": 1,
        })
        self.assertEqual(result["verdict"], "PASS")

    def test_bs_stmin_requires_master_tx_flow_control_frame(self):
        spec = build_timing_spec(
            "UDS_TimeParm_TC_0007", [0x22, 0xF1, 0x2E], "default", 0x51,
            procedure="解析 FF/CF 的 BS 与 STmin",
            expected="BS=0，STmin=0ms",
        )
        result = evaluate_timing_case(spec, {
            "bs_stmin": {
                "bs": 0, "stmin": 0, "frame_id": 0x3C,
                "direction": "TX", "payload": [0, 0],
            },
            "response_frame_count": 2,
            "response": [0x62, 0xF1, 0x2E],
        })
        self.assertEqual(result["verdict"], "PASS")
        wrong_direction = dict(result)
        wrong_direction = evaluate_timing_case(spec, {
            "bs_stmin": {
                "bs": 0, "stmin": 0, "frame_id": 0x3D,
                "direction": "RX", "payload": [0, 0],
            },
            "response_frame_count": 2,
            "response": [0x62, 0xF1, 0x2E],
        })
        self.assertEqual(wrong_direction["verdict"], "FAIL")

    def test_bs_stmin_accepts_single_frame_read_with_multiframe_response(self):
        """TC0007 的单帧请求不能被错误的请求长度门禁判成未测试。"""
        from timing_case_runner import _measure_case

        spec = build_timing_spec(
            "UDS_TimeParm_TC_0007", [0x22, 0xF1, 0x2E], "default", 0x51,
            procedure="多帧读 F12E（22 字节）并解析 FF/CF 的 BS 与 STmin",
            expected="BS=0，STmin=0ms",
        )
        uds = FakeTimingUDS([0x62, 0xF1, 0x2E] + list(range(19)))
        measurement = _measure_case(uds, spec, 0x51)
        self.assertEqual(uds.trace_calls[-1]["payload"], [0x22, 0xF1, 0x2E])
        self.assertEqual(uds.trace_calls[-1]["flow_control"], (0, 0))
        self.assertEqual(measurement["bs_stmin"]["frame_id"], 0x3C)
        self.assertEqual(measurement["bs_stmin"]["direction"], "TX")
        self.assertGreaterEqual(measurement["response_frame_count"], 2)
        self.assertEqual(evaluate_timing_case(spec, measurement)["verdict"], "PASS")

    def test_n_as_does_not_send_bs_stmin_flow_control(self):
        from timing_case_runner import _measure_case

        spec = build_timing_spec("UDS_TimeParm_TC_0005", [0x22, 0xF1, 0x86], "default", 0x51)
        uds = FakeTimingUDS([0x62, 0xF1, 0x86, 0x01])
        measurement = _measure_case(uds, spec, 0x51)
        self.assertIsNone(uds.trace_calls[-1]["flow_control"])
        self.assertEqual(measurement["request_frame_count"], 1)
        self.assertEqual(evaluate_timing_case(spec, measurement)["verdict"], "PASS")

    def test_n_cr_sends_explicit_flow_control_for_multiframe_response(self):
        from timing_case_runner import _measure_case

        spec = build_timing_spec("UDS_TimeParm_TC_0006", [0x22, 0xF1, 0x2E], "default", 0x51)
        uds = FakeTimingUDS([0x62, 0xF1, 0x2E] + list(range(19)))
        measurement = _measure_case(uds, spec, 0x51)
        self.assertEqual(uds.trace_calls[-1]["flow_control"], (0, 0))
        self.assertGreaterEqual(measurement["response_frame_count"], 2)
        self.assertEqual(evaluate_timing_case(spec, measurement)["verdict"], "PASS")

    def test_s3_uses_session_reversion_for_verdict_not_active_wait_duration(self):
        spec = build_timing_spec("UDS_TimeParm_TC_0004", [0x10, 0x03], "extended", 0x51)
        result = evaluate_timing_case(spec, {
            "s3_ms": [5394.813], "observed_session": 1, "expected_session": 1,
        })
        self.assertEqual(result["verdict"], "PASS")

    def test_reset_recovery_requires_reset_ack_and_default_session(self):
        spec = build_timing_spec("UDS_TimeParm_TC_0014", [0x11, 0x01], "default", 0x51)
        self.assertEqual(
            evaluate_timing_case(spec, {"recovery_ms": [100.0]})["verdict"],
            "FAIL",
        )
        self.assertEqual(
            evaluate_timing_case(spec, {
                "recovery_ms": [100.0], "reset_response_ok": True,
                "recovered_session": 3,
            })["verdict"],
            "FAIL",
        )


class TestTimingExecutionContract(unittest.TestCase):
    def test_hardware_exception_is_blocked_with_infrastructure_classification(self):
        spec = build_timing_spec("UDS_TimeParm_TC_0001", [0x22, 0xF1, 0x86], "default", 0x51)
        with WorkspaceTempDir("timing") as td:
            result_path = os.path.join(td, "UDS_TimeParm_TC_0001.json")
            result = run_timing_case(spec, result_path, bus="can")
            self.assertEqual(result["verdict"], "BLOCKED")
            self.assertEqual(result["failure_class"], "INFRA_ERROR")
            self.assertTrue(os.path.isfile(result_path))
            self.assertTrue(os.path.isfile(os.path.splitext(result_path)[0] + ".trace.json"))
            with open(result_path, encoding="utf-8") as handle:
                saved = json.load(handle)
            self.assertEqual(saved["case_id"], spec["case_id"])
            self.assertEqual(saved["verdict"], "BLOCKED")
            self.assertEqual(saved["failure_class"], "INFRA_ERROR")
            self.assertNotIn(saved["verdict"], {"SKIP", "ERROR"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
