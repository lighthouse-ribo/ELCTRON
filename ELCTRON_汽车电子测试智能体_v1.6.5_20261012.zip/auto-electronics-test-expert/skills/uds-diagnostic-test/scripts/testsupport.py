#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试专用工作区目录，避开透明加密环境对 tempfile 的权限处理。"""

import os
import shutil
import tempfile
import uuid


# 临时工作区放系统 TEMP（非 DLP 加密目录）：加密目录（仓库根/工程目录）下
# python 的 os.remove 会被安全删除拦截（实测 2026-08-28）：
#   OSError('[safe-delete][SAFE_DELETE_FAIL_CLOSED] {"reason": "windows-sandbox-recycle-bin-unavailable"}')
# 导致 run_all 清理 stale 结果、测试注入的删除全部失败。%TEMP% 下写/读/删均正常。
VERIFICATION_ROOT = os.path.join(tempfile.gettempdir(), "wb_verification_timing")
os.makedirs(VERIFICATION_ROOT, exist_ok=True)


class WorkspaceTempDir:
    """手工创建的可写测试目录；不调用 tempfile 的 chmod/回收逻辑。"""

    def __init__(self, prefix="test"):
        self.name = os.path.join(VERIFICATION_ROOT, "%s_%s" % (prefix, uuid.uuid4().hex))
        os.makedirs(self.name, exist_ok=False)

    def cleanup(self):
        shutil.rmtree(self.name, ignore_errors=True)

    def __enter__(self):
        return self.name

    def __exit__(self, exc_type, exc_value, traceback):
        self.cleanup()
        return False
