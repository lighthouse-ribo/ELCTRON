# -*- coding: utf-8 -*-
"""将 SWDL 计划/执行结果转换为统一报告输入契约。"""

from __future__ import annotations

from typing import Any, Mapping, Sequence


def swdl_report_to_results(report: Mapping[str, Any] | None) -> dict[str, Any]:
    """Normalize a swdl_report.json into report_to_html's results contract."""
    data = dict(report or {})
    overall = str(data.get("overall") or "BLOCKED").upper()
    steps = data.get("steps") if isinstance(data.get("steps"), list) else []
    results: list[dict[str, Any]] = []
    for index, step in enumerate(steps, 1):
        if not isinstance(step, Mapping):
            continue
        status = str(step.get("status") or "BLOCKED").upper()
        if status not in {"PASS", "FAIL", "BLOCKED", "NA", "SKIP"}:
            status = "FAIL"
        results.append({
            "case_id": "SWDL-%s" % str(step.get("step_id") or index),
            "service": str(step.get("service") or "SWDL"),
            "desc": str(step.get("step_id") or "SWDL stage"),
            "verdict": status,
            "actual": str(step.get("reason") or ""),
            "note": "SWDL stage evidence",
            "payload": [],
            "evidence": step.get("evidence") or "",
            "metrics": {"elapsed_ms": step.get("elapsed_ms", 0)},
        })

    if not results:
        results.append({
            "case_id": "SWDL-PLAN",
            "service": "SWDL",
            "desc": "SWDL execution plan",
            "verdict": "BLOCKED" if overall == "BLOCKED" else "SKIP",
            "actual": "未产生阶段执行记录",
            "note": "；".join(str(item) for item in data.get("blocked_reasons", [])),
            "payload": [],
            "evidence": "",
            "metrics": {},
        })

    extra = {
        "meta": {
            "title": "SWDL 测试报告",
            "notice": "SWDL overall=%s；未执行项目不得标记 PASS" % overall,
            "flow": "swdl",
            "target_partition": data.get("target_partition", ""),
        },
        "modules": [{
            "id": "swdl",
            "label": "SWDL 软件刷写",
            "status": "blocked" if overall == "BLOCKED" else "executed",
            "count": len(results),
            "description": "Software Download 测试阶段和阻断信息",
        }],
        "blocked": [
            {"category": "SWDL 前置缺口", "count": len(data.get("blocked_reasons", [])),
             "affected": "SWDL", "reason": str(item), "solution": "补充对应项目资料"}
            for item in data.get("blocked_reasons", [])
        ],
        "evidence": data.get("evidence", []),
    }
    return {"results": results, "extra": extra}
