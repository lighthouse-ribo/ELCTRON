#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""报告状态归一化回归测试。"""

import json
import os
import unittest

from report_to_html import build_html, _render_framework_html, load_results
from testsupport import WorkspaceTempDir


class TestReportStatusContract(unittest.TestCase):
    def test_error_is_fail_but_explicit_skip_style_is_preserved(self):
        with WorkspaceTempDir("report") as td:
            path = os.path.join(td, "results.json")
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"results": [
                    {"case_id": "A", "service": "0x22", "verdict": "SKIP"},
                    {"case_id": "B", "service": "0x22", "verdict": "ERROR"},
                    {"case_id": "C", "service": "0x22", "verdict": "UNKNOWN"},
                ]}, handle)
            data = load_results(path)
            self.assertEqual(data["summary"]["FAIL"], 2)
            self.assertEqual(data["summary"]["SKIP"], 1)
            self.assertEqual(data["summary"]["failure_classes"],
                             {"NONE": 1, "RESULT_INVALID": 2})
            self.assertEqual(data["summary"]["ecu_fail"], 0)
            self.assertIn("SKIP", json.dumps(data, ensure_ascii=False))
            html = _render_framework_html(data)
            self.assertIn('class="vchip SKIP"', html)
            self.assertIn('data-v="SKIP"', html)
            self.assertTrue("SKIP 本批明确排除" in html or "SKIP 本批排除/待测量" in html)
            self.assertIn("FAIL", html)

    def test_failure_class_is_only_rendered_for_fail_rows(self):
        with WorkspaceTempDir("report_failure_class_visibility") as td:
            path = os.path.join(td, "results.json")
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"results": [
                    {"case_id": "PASS-1", "service": "0x22", "verdict": "PASS",
                     "failure_class": "SCRIPT_ERROR", "note": "通过"},
                    {"case_id": "BLOCKED-1", "service": "0x27", "verdict": "BLOCKED",
                     "failure_class": "INFRA_ERROR", "note": "未执行"},
                    {"case_id": "FAIL-1", "service": "0x22", "verdict": "FAIL",
                     "failure_class": "SCRIPT_ERROR", "note": "脚本退出"},
                ]}, handle, ensure_ascii=False)
            data = load_results(path)

            framework_html = _render_framework_html(data)
            self.assertIn("SCRIPT_ERROR：脚本异常或崩溃", framework_html)
            self.assertNotIn("INFRA_ERROR：Vector、CAN、运行环境等基础设施异常", framework_html)

            v2_html = build_html(data)
            self.assertIn("SCRIPT_ERROR：脚本异常或崩溃", v2_html)
            self.assertNotIn("INFRA_ERROR：Vector、CAN、运行环境等基础设施异常", v2_html)

    def test_timing_report_is_rebuilt_one_row_per_case(self):
        with WorkspaceTempDir("report_timing") as td:
            path = os.path.join(td, "results.json")
            rows = []
            for index in range(1, 16):
                metric = "p2" if index in (1, 2) else "p2_star" if index == 3 else "s3" if index == 4 else "metric_%02d" % index
                rows.append({
                    "case_id": "UDS_TimeParm_TC_%04d" % index,
                    "service": "TimeParm",
                    "verdict": "FAIL",
                    "actual": "未采集",
                    "note": "独立证据不足",
                    "timing_metric": metric,
                    "timing_spec": {"case_id": "UDS_TimeParm_TC_%04d" % index, "metric": metric,
                                     "label": metric},
                    "metrics": {},
                    "evidence": "C:/trace/UDS_TimeParm_TC_%04d.trace.json" % index,
                })
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"results": rows}, handle, ensure_ascii=False)
            data = load_results(path)
            data["timing"] = [{"k": "旧版普通 P2 汇总", "v": "不应覆盖", "n": "legacy"}]
            html = _render_framework_html(data)
            for index in range(1, 16):
                self.assertIn("UDS_TimeParm_TC_%04d" % index, html)
            self.assertNotIn("旧版普通 P2 汇总", html)
            self.assertNotIn("legacy", html)


def _minimal_data():
    return {
        "meta": {"version": "V436", "title": "测试报告", "test_time": "2026-08-26",
                 "generated": "2026-08-26 21:00", "notice": "回归测试", "flag": "140 条 · 0 FAIL"},
        "summary": {"PASS": 93, "NA": 1, "BLOCKED": 31, "FAIL": 0,
                    "RETEST": 0, "DEVIATION": 0, "SKIP": 15,
                    "executed": 109, "judged": 94, "pass_rate": 100.0,
                    "total": 140},
        "versions": [{"version": "V436", "date": "2026-08-26", "note": "回归测试"}],
        "modules": [{"id": "uds", "label": "UDS 诊断", "status": "executed",
                     "total": 140, "pass": 93, "fail": 0,
                     "blocked": 31, "na": 1, "skipped": 15,
                     "RETEST": 0, "DEVIATION": 0, "color": "var(--blue)"}],
        "coverage": {"rows": [{"k": "用例总数", "v": "140", "pct": 100}]},
        "timing": [{"k": "P2Server", "v": "19.2ms", "sub": "样本 335", "n": "主动注入"}],
        "blocked": [{"category": "0x27 密钥缺失", "count": 31, "affected": "31 条",
                     "reason": "密钥缺失", "solution": "解锁复测"}],
        "services": [{"name": "0x22", "total": 2, "PASS": 1, "FAIL": 0, "NA": 0,
                       "BLOCKED": 1, "SKIP": 0, "RETEST": 0, "DEVIATION": 0, "note": ""}],
        "cases_detail": [
            {"case_id": "UDS_0x22_TC_0007", "service": "0x22", "desc": "读 F186",
             "session": "default", "verdict": "PASS", "actual": "62 F1 86 01", "note": ""},
            {"case_id": "UDS_0x27_TC_0001", "service": "0x27", "desc": "Seed",
             "session": "extended", "verdict": "BLOCKED", "actual": "未执行", "note": "密钥缺失"},
        ],
        "transport": "LIN 19.2K NAD=0x51",
    }


class TestKpiClickFilter(unittest.TestCase):
    def setUp(self):
        self.html = _render_framework_html(_minimal_data())

    def test_kpi_card_has_data_status(self):
        for status in ("PASS", "NA", "BLOCKED", "FAIL", "SKIP", "RETEST", "DEVIATION", "ALL"):
            self.assertIn('data-status="%s"' % status, self.html)

    def test_kpi_card_has_onclick_handler(self):
        self.assertIn('onclick="kpiFilter(', self.html)
        self.assertNotIn('style="cursor:pointer; style=', self.html)

    def test_kpifilter_js_function_declared(self):
        self.assertIn("function kpiFilter", self.html)

    def test_kpifilter_triggers_fbtn_click(self):
        self.assertIn("fbtn", self.html)
        self.assertIn(".click()", self.html)


if __name__ == "__main__":
    unittest.main(verbosity=2)
