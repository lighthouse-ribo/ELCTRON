#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""F1L1 UDS-LIN 诊断通信引擎（v3：完整 LIN TP，支持多帧收发 + 0x78 pending）
=====================================================================
实测来源：BBS (P519) 项目 F1L1 xcdevlay 排障最终版（2026-08-13 验证通过）。
依赖：xcdev_wrapper.py（基于 xcdevlay.h 的 ctypes 封装）+ 对应 DLL。
  xcdev_wrapper 目录通过环境变量 F1L1_XCWRAPPER_DIR 指定；缺省尝试当前目录/技能 scripts 目录。

用法:
  from f1l1_uds import F1L1UDS, NAD_PHYS, NAD_FUNC
  uds = F1L1UDS()
  uds.open()
  resp = uds.request(NAD_PHYS, [0x22, 0xF1, 0x2E], timeout=3)  # 返回应答数据或 None
  uds.close()

实测固化要点（详见 references/f1l1-lin-uds.md）：
  - outputV=1：内置 12V 输出（DB9 pin4=LIN-VBAT），默认 0 时 LIN 收发器无供电、总线 0 帧
  - 0x3C 请求 / 0x3D 应答双帧调度：从节点只在收到 0x3D 帧头时填充应答
  - 单帧 PCI=数据字节数（不含 NAD/PCI）；多帧 FF/CF 逐帧等 TX 回显再发下一帧，防覆盖丢失
  - **多帧应答必须由主节点发流控帧 FC（0x3C 载 PCI 0x30 + BS + STmin）**：收到 ECU 首帧后
    补发 FC，从机才继续发 CF。2026-09-14 实机修正：默认路径改为「先给宽限窗口判自动连发，
    没有 CF 就补发 FC」，此前"本 ECU 无需 FC"的假设会让所有 ≥6 字节应答全超时。
  - _drain 带 max_frames 保护，防止持续应答导致死循环
  - 结构体对齐用 C 编译器默认（8 字节），不要 _pack_=1（实测 152 vs 148 字节错位）
"""

import ctypes
import os
import sys
import time
from ctypes import byref, c_int, c_ubyte

NAD_PHYS = 0x51
NAD_FUNC = 0x7E


def _now():
    """单调时钟（perf_counter），不受系统时间调整影响，Windows 下分辨率 ms 级"""
    return time.perf_counter()


def _packet_timestamp(packet):
    """读取 Vector 驱动的硬件时间戳；xcdevlay 单位为微秒。"""
    try:
        raw = int(getattr(packet, "timestamp", 0))
    except (TypeError, ValueError):
        return None
    return raw / 1_000_000.0 if raw > 0 else None


LIN_FRAME_LEN = 8          # LIN 帧数据槽 8 字节


def _fc_grace_ms():
    """多帧应答的「自动连发 CF」宽限窗口（ms）。

    默认路径收到首帧后先等这么久，判从机是否无需流控帧就续发 CF（兼容旧 ECU）；
    窗口内没有连续帧就补发 FC(BS=0, STmin=0)。设为 0 表示总是先发 FC。
    可用环境变量 F1L1_FC_GRACE_MS 覆盖（排障/专项测量用）。
    """
    try:
        return max(0, int(os.environ.get("F1L1_FC_GRACE_MS", "150")))
    except (TypeError, ValueError):
        return 150


FC_GRACE_MS = _fc_grace_ms()


def _find_wrapper_dir():
    """定位 xcdev_wrapper.py：环境变量 F1L1_XCWRAPPER_DIR > 当前目录 > 本脚本目录"""
    cands = []
    env = os.environ.get("F1L1_XCWRAPPER_DIR", "").strip()
    if env:
        cands.append(env)
    cands.append(os.getcwd())
    cands.append(os.path.dirname(os.path.abspath(__file__)))
    for d in cands:
        if d and os.path.isfile(os.path.join(d, "xcdev_wrapper.py")):
            return d
    return None


_SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)
_WRAPPER_DIR = _find_wrapper_dir()
if _WRAPPER_DIR:
    sys.path.insert(0, _WRAPPER_DIR)
from lin_tp import (SF_MAX, FF_DATA, CF_DATA, pack_request, pack_fc,  # noqa: E402
                       analyze_trace, format_trace_report)
import xcdev_wrapper as xw  # noqa: E402
from win_timer import set_timer_resolution as _set_timer_resolution  # noqa: E402

_set_timer_resolution(1)


def _mk_appoint(lin_id, delay_ms):
    a = xw.xLinAppoint()
    a.ids[0] = lin_id
    a.delay = delay_ms
    return a


class F1L1UDS:
    """F1L1 (CANviex) 设备上的 UDS-over-LIN 客户端"""

    def __init__(self, brval=19200, *, output_voltage=1):
        if output_voltage not in (0, 1):
            raise ValueError("LIN output voltage flag must be 0 or 1")
        self.output_voltage = output_voltage
        self.brval = brval
        self.dev = None
        self._rx_buf = (xw.xNetpack * 64)()
        # 单次请求的原始 LIN 轨迹。时序用例必须把证据绑定到自己的
        # case_id，不能复用跨用例的 timing_trace 汇总。
        self._trace_capture = None
        self._trace_transaction_id = None
        self._trace_live_sink = None
        self._trace_live_error = None

    def _record_trace(self, direction, frame_id, data, timestamp=None):
        """记录一条原始帧；时序采集必须使用驱动硬件时间戳。"""
        if self._trace_capture is None:
            return
        if timestamp is None:
            raise RuntimeError("Vector 驱动未提供有效 LIN 硬件时间戳，拒绝生成时序结果")
        event = (
            float(timestamp),
            str(direction), int(frame_id), [int(b) for b in data],
        )
        if self._trace_transaction_id:
            # 保留旧的前四项 tuple 形态；第 5 项仅用于逐事务时序审计。
            event += (str(self._trace_transaction_id),)
        self._trace_capture.append(event)
        sink = self._trace_live_sink
        if sink is not None:
            # A logging failure must not change the hardware request outcome.
            try:
                sink(event)
            except Exception as exc:
                self._trace_live_error = "%s: %s" % (type(exc).__name__, exc)

    # ---------- 设备管理 ----------
    def open(self, retries=5, retry_interval=3.0):
        """打开并配置 F1L1（带重试，实测连续测试后 xcdev_open 会返回 err=2）"""
        last_err = None
        for _ in range(max(1, retries)):
            err = c_int(0)
            self.dev = xw.dll.xcdev_open(xw.XC_HARDTYPE_CANVIEX_F1L1, 0, byref(err))
            if self.dev:
                break
            last_err = err.value
            time.sleep(retry_interval)
        if not self.dev:
            raise RuntimeError(
                f"F1L1 打开失败 err={last_err}（重试 {retries} 次后仍失败）。\n"
                f"环境排查：1) F1L1 设备是否 USB 连接（xcdev_detect={xw.detect(3)} 台）；"
                f"2) 驱动是否安装；3) VickCAN.exe/CANoe 是否关闭（通道独占）；"
                f"4) outputV 供电（xcdev_wrapper.make_lin_opt 已默认 outputV=1）"
            )
        opt = xw.make_lin_opt(brval=self.brval)
        opt.outputV = self.output_voltage  # Explicit caller-selected LIN VBAT output policy
        r = xw.dll.xcdev_config_lin(0, byref(opt), self.dev)
        if r != 0:
            self.close()
            raise RuntimeError(f"config_lin 失败 {r}")
        r = xw.dll.xcdev_activity(self.dev)
        if r != 0:
            self.close()
            raise RuntimeError(f"activity 失败 {r}")
        time.sleep(0.2)
        e3c = xw.xLinEntry(); e3c.id = 0x3C; e3c.channel = 0; e3c.role = 1; e3c.rsp = 1; e3c.length = 8
        e3d = xw.xLinEntry(); e3d.id = 0x3D; e3d.channel = 0; e3d.role = 2; e3d.rsp = 0; e3d.length = 8
        entries = (xw.xLinEntry * 2)(e3c, e3d)
        r = xw.dll.xcdev_lin_set_entry(entries, 2, self.dev)
        if r != 0:
            self.close()
            raise RuntimeError(f"set_entry 失败 {r}")
        # 表 0: 正常调度（0x3C/0x3D 交替，用于单帧发送 + 响应轮询）
        a1 = _mk_appoint(0x3C, 20)
        a2 = _mk_appoint(0x3D, 20)
        arr = (xw.xLinAppoint * 2)(a1, a2)
        r = xw.dll.xcdev_lin_setup_scheduler(0, 0, arr, 2, self.dev)
        if r != 0:
            self.close()
            raise RuntimeError(f"setup_scheduler 失败 {r}")
        # 表 1: MasterReq（仅 0x3C 高频 5ms，用于多帧请求快速连发）
        a3 = _mk_appoint(0x3C, 5)
        arr1 = (xw.xLinAppoint * 1)(a3)
        r = xw.dll.xcdev_lin_setup_scheduler(0, 1, arr1, 1, self.dev)
        if r != 0:
            self.close()
            raise RuntimeError(f"setup_scheduler(1) 失败 {r}")
        r = xw.dll.xcdev_lin_start_scheduler(0, 0, self.dev)
        if r != 0:
            self.close()
            raise RuntimeError(f"start_scheduler 失败 {r}")
        self._drain()
        return True

    def close(self):
        """Stop and remove every scheduler before releasing the device handle.

        The DLL may keep scheduler state in the device after a host process is
        interrupted.  Cleanup is deliberately best-effort and idempotent: an
        unset scheduler returns an error from the DLL, which is harmless here.
        """
        dev = self.dev
        self.dev = None
        self._trace_capture = None
        self._trace_transaction_id = None
        self._trace_live_sink = None
        self._trace_live_error = None
        if not dev:
            return
        for scheduler in (0, 1):
            try:
                xw.dll.xcdev_lin_stop_scheduler(0, scheduler, dev)
            except Exception:
                pass
            try:
                xw.dll.xcdev_lin_remove_scheduler(0, scheduler, dev)
            except Exception:
                pass
        try:
            xw.dll.xcdev_close(dev)
        except Exception:
            pass

    def _drain(self, timeout=30, max_frames=256, record=False):
        """读取并丢弃缓存帧（带最大帧数保护，防止持续应答导致死循环）

        v3.9.1 修复（证据链完备性）：此前 drain 读到即丢、不经 _record_trace，
        request() 的重试/前后请求之间被清理的帧（TX 回显、迟到应答、调度表帧）
        在 trace 中永久缺失——冒烟实测曾误判为"ECU 唤醒错过首帧"，实为驱动层漏记。
        record=True 时被清理的帧先以真实硬件时间戳记入 trace 再丢弃。
        隔离语义场景（request_with_trace）不受影响：其 drain 在 _trace_capture
        重置之前执行，即使传 record=True 也不会写入该次隔离 trace。
        """
        total = 0
        while total < max_frames:
            n = xw.dll.xcdev_receive(64, self._rx_buf, timeout, self.dev)
            for i in range(max(0, n)):
                p = self._rx_buf[i]
                if p.type != xw.XC_NETPACK_TYPE_LIN:
                    continue
                if record and self._trace_capture is not None:
                    d = [b for b in p.data[:p.length]]
                    self._record_trace("TX" if (p.flag & xw.XC_NETPACK_FLAG_TX) else "RX",
                                       p.id, d, _packet_timestamp(p))
            if n <= 0:
                break
            total += n
        return total

    # ---------- LIN 帧级收发 ----------
    def _tx_0x3c(self, data8, hold_ms=70, fast=False, restore=True):
        """发送一帧 0x3C 数据：更新缓冲区 -> 保持 hold_ms -> 复位全 FF 停止重发
        fast=True 时用于 MasterReq 高频表（0x3C @5ms），hold 6ms 保证只发一次
        restore=False 时发完不复位 FF（多帧响应接收场景：中途复位会打断 ECU 的 TP 状态机，实测修复）"""
        tx = (c_ubyte * 8)(*data8)
        xw.dll.xcdev_lin_update_bytearray(0, 0x3C, 0, tx, 8, self.dev)
        # 不把“更新调度缓冲区”的时刻伪装成总线 TX。单帧时序证据只能
        # 来自 xcdev_receive 返回的实际 TX 回显；若驱动没有回显，调用方
        # 必须判 FAIL，而不是用主机写缓冲区时间替代总线时间。
        time.sleep(hold_ms / 1000.0)
        if restore and not fast:
            ff = (c_ubyte * 8)(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF)
            xw.dll.xcdev_lin_update_bytearray(0, 0x3C, 0, ff, 8, self.dev)

    def _recv_lin(self, timeout_ms=200):
        """接收一帧 0x3D 应答，返回 (data_bytes) 或 None"""
        deadline = _now() + timeout_ms / 1000.0
        while _now() < deadline:
            n = xw.dll.xcdev_receive(32, self._rx_buf, min(100, max(10, timeout_ms)), self.dev)
            for i in range(max(0, n)):
                p = self._rx_buf[i]
                if p.type != xw.XC_NETPACK_TYPE_LIN:
                    continue
                d = [b for b in p.data[:p.length]]
                direction = "TX" if (p.flag & xw.XC_NETPACK_FLAG_TX) else "RX"
                self._record_trace(direction, p.id, d, _packet_timestamp(p))
                if p.id == 0x3D and not (p.flag & xw.XC_NETPACK_FLAG_TX):
                    if d:
                        return d
            time.sleep(0.01)
        return None

    # ---------- LIN TP 组帧 ----------
    def _tx_wait_echo(self, data8, timeout=0.4):
        """更新 0x3C 数据并等待 TX 回显确认（确保调度表真实发出该帧）"""
        tx = (c_ubyte * 8)(*data8)
        xw.dll.xcdev_lin_update_bytearray(0, 0x3C, 0, tx, 8, self.dev)
        deadline = _now() + timeout
        while _now() < deadline:
            n = xw.dll.xcdev_receive(64, self._rx_buf, 50, self.dev)
            for i in range(max(0, n)):
                p = self._rx_buf[i]
                if p.type == xw.XC_NETPACK_TYPE_LIN and p.id == 0x3C and (p.flag & xw.XC_NETPACK_FLAG_TX):
                    d = [b for b in p.data[:p.length]]
                    self._record_trace("TX", p.id, d, _packet_timestamp(p))
                    if len(d) >= 2 and d[0] == data8[0] and d[1] == data8[1]:
                        return True  # 该帧已被调度表发出
            time.sleep(0.005)
        return False

    def _send_request(self, nad, payload):
        """发送诊断请求（自动单帧/多帧；组帧复用 lin_tp.pack_request，多帧逐帧确认发送）
        多帧逐帧确认（等 TX 回显再发下一帧）与发后复位 FF 为实测关键，保持原逻辑"""
        frames = pack_request(nad, list(payload))
        if len(frames) == 1:
            self._tx_0x3c(list(frames[0]), restore=False)  # 不复位：ECU 响应期间复位 FF 会打断多帧 CF
            return True
        for fr in frames:
            if not self._tx_wait_echo(list(fr)):  # FF 与每个 CF 都确认发出
                return False
        # 复位 FF 停止轮询
        ff = (c_ubyte * 8)(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF)
        xw.dll.xcdev_lin_update_bytearray(0, 0x3C, 0, ff, 8, self.dev)
        return True

    def _recv_response_frames(self, nad, timeout=2.0, flow_control=None):
        """接收完整应答（单帧或多帧组装），返回 payload 数据（不含 NAD/PCI）或 None
        处理 0x78 响应待定：持续等待直至最终应答或超时。

        flow_control 显式传参时按指定 BS/STmin 发流控帧（专项 BS/STmin 测量）。

        默认路径（2026-09-14 实机修正）：收到首帧后先给一个宽限窗口判"从机是否
        自动连发 CF"——
          - 窗口内已到 CF（旧行为 ECU）→ 不补发 FC，保持既有兼容；
          - 窗口内没有 CF（当前 BBS 样例实测行为）→ 必须补发主节点流控帧
            FC(BS=0, STmin=0)，否则从机停在首帧、永不发 CF，所有 ≥6 字节应答
            全超时（2026-09-14 实测：22 F120 无 FC 时 154 次重发全为首帧、0 个 CF，
            补 FC 后 0.19s 拼包成功）。
        两条路径的帧都进 trace，判定依据可回溯。
        """
        deadline = _now() + timeout
        while _now() < deadline:
            fr = self._recv_lin(timeout_ms=500)
            if not fr:
                continue
            if fr[0] != nad:
                continue
            pci = fr[1]
            hi = pci >> 4
            if hi == 0x0:  # 单帧
                n = pci & 0x0F
                data = fr[2:2 + n]
                if len(data) >= 2 and data[0] == 0x7F and data[2:3] == [0x78]:
                    continue  # 0x78 pending，继续等
                ff = (c_ubyte * 8)(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF)
                xw.dll.xcdev_lin_update_bytearray(0, 0x3C, 0, ff, 8, self.dev)  # 收完复位，停止 0x3C 重发
                return data
            if hi == 0x1:  # 首帧
                total = ((pci & 0x0F) << 8) | fr[2]
                body = fr[3:3 + FF_DATA]
                pending = None
                if flow_control is not None:
                    try:
                        bs, stmin = int(flow_control[0]), int(flow_control[1])
                    except (TypeError, ValueError, IndexError):
                        return None
                    # 专项 BS/STmin 测量：发送指定的 0x3C 主节点流控帧，
                    # 并等待 TX 回显确认已经上总线；后续由 _recv_lin 捕获 CF，
                    # 整条 FC 证据留在本次 trace。
                    if not self._tx_wait_echo(list(pack_fc(nad, bs=bs, stmin=stmin))):
                        return None
                else:
                    # 默认路径（2026-09-14 实机修正）：先取一帧判"从机是否自动
                    # 连发 CF"。只有拿到真正的连续帧才跳过 FC；拿到重复首帧、
                    # 非法帧或没有任何帧，都必须补发主节点流控帧
                    # FC(BS=0, STmin=0)，否则从机停在首帧、永远不发 CF。
                    grace = self._recv_lin(timeout_ms=FC_GRACE_MS)
                    if (grace is not None and len(grace) >= 2
                            and grace[0] == nad and (grace[1] >> 4) == 0x2):
                        pending = grace  # 旧行为 ECU：已自动连发，无需 FC
                    if pending is None:
                        if not self._tx_wait_echo(list(pack_fc(nad, bs=0, stmin=0))):
                            return None
                cf_deadline = _now() + timeout
                expected_seq = 1
                while len(body) < total and _now() < cf_deadline:
                    if pending is not None:
                        cf, pending = pending, None
                    else:
                        cf = self._recv_lin(timeout_ms=800)
                    if not cf or cf[0] != nad:
                        continue
                    cpi = cf[1]
                    if (cpi >> 4) == 0x2:
                        seq = cpi & 0x0F
                        if seq != expected_seq:
                            # 序号错乱时丢弃本次拼包，让 request() 走有限重试，
                            # 避免把截断响应当成成功结果写入测试日志。
                            body = []
                            break
                        body += cf[2:2 + CF_DATA]
                        expected_seq = (expected_seq + 1) & 0x0F
                    elif (cpi >> 4) == 0x0:
                        # 异常：收到新单帧（可能是 7F 78）
                        if len(cf) >= 4 and cf[2] == 0x7F and cf[4] == 0x78:
                            continue
                        return cf[2:2 + (cpi & 0x0F)]
                if len(body) > total:
                    body = body[:total]
                complete = len(body) == total
                ff = (c_ubyte * 8)(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF)
                xw.dll.xcdev_lin_update_bytearray(0, 0x3C, 0, ff, 8, self.dev)  # 收完统一复位
                return body if complete else None
            if hi == 0x2:  # 连续帧（无首帧直接收到，忽略）
                continue
            if hi == 0x3:  # 流控（请求方向，忽略）
                continue
        return None

    # ---------- 高层 API ----------
    def request(self, nad, payload, timeout=3.0, retry=2):
        """发送诊断请求并等待应答（失败自动重试）
        返回: 应答数据字节列表（含 SID+0x40 或 7F）或 None（超时）"""
        last = None
        for attempt in range(max(1, retry + 1)):
            self._drain(timeout=10, record=True)  # 清残留，避免旧帧干扰；v3.9.1 起被清帧也记入证据（防 trace 缺帧）
            if not self._send_request(nad, payload):
                continue
            last = self._recv_response_frames(nad, timeout=timeout)
            if last is not None:
                return last
        return last

    def request_with_trace(self, nad, payload, timeout=3.0, retry=0, flow_control=None, transaction_id=None):
        """执行一次独立 UDS 请求并返回原始 LIN 轨迹。

        返回 ``(response, trace, started, ended)``。trace 只覆盖本次请求，
        不包含调用前残留帧，也不读取其它用例的汇总报告。每条 trace tuple
        的第 5 项为 transaction_id，供上层严格关联请求与响应；硬件/解析
        异常由上层 timing runner 统一转成 FAIL。
        """
        self._drain(timeout=10, max_frames=256)
        self._trace_capture = []
        self._trace_transaction_id = transaction_id or f"lin-txn-{time.time_ns()}"
        started = _now()
        last = None
        try:
            for _ in range(max(1, retry + 1)):
                if not self._send_request(nad, payload):
                    continue
                last = self._recv_response_frames(nad, timeout=timeout, flow_control=flow_control)
                if last is not None:
                    break
            ended = _now()
            return last, list(self._trace_capture), started, ended
        finally:
            self._trace_capture = None
            self._trace_transaction_id = None

    def send_diag_request(self, nad, payload):
        """兼容旧接口：只发送不等待"""
        return self._send_request(nad, payload)

    def wait_response(self, nad=NAD_PHYS, timeout=2.0):
        """兼容旧接口：等待应答（单帧或多帧组装）"""
        return self._recv_response_frames(nad, timeout=timeout)

    # ---------- 高实时轨迹采集（采集-后处理，避免逐条在线往返污染测量） ----------
    def capture_trace(self, duration=5.0, max_frames=100000,
                      probe_payloads=None, probe_interval=1.0, nad=NAD_PHYS):
        """连续采集总线帧轨迹（含单调时间戳），供 analyze_trace 离线分析。
        前提：设备已 open（调度表已启动）。
        返回 [(ts_sec, direction, frame_id, data_bytes)]，direction 为 'TX'/'RX'。

        主动注入（probe_payloads 非空时启用）：按 probe_interval 周期调用
        _send_request 发送 0x3C 诊断请求（如 [0x3E, 0x00] / [0x22, 0xF1, 0x86]），
        请求 TX 回显与 0x3D 响应都会进入轨迹 → analyze_trace 即可离线算出
        P2/P2*（含 0x78 pending）。纯被动监听时 tx 恒空、P2 永远采不到，
        这是时序用例"未执行"的采集层根因（实测固化问题）。

        实测要点：高实时测量用 perf_counter + timeBeginPeriod(1)，不要用上位机/COM 逐条往返。"""
        self._drain(timeout=5, max_frames=256)
        trace = []
        probes = list(probe_payloads or [])
        deadline = _now() + duration
        next_probe = _now() + probe_interval
        pi = 0
        while _now() < deadline:
            now = _now()
            # 周期性主动注入诊断请求（fire-and-forget，不等待；响应由 receive 记录）
            if probes and now >= next_probe:
                payload = list(probes[pi % len(probes)])
                pi += 1
                self._send_request(nad, payload)
                next_probe = now + probe_interval
            wait_ms = min(100, max(10, int((deadline - now) * 1000)))
            n = xw.dll.xcdev_receive(64, self._rx_buf, wait_ms, self.dev)
            t = _now()
            for i in range(max(0, n)):
                p = self._rx_buf[i]
                if p.type != xw.XC_NETPACK_TYPE_LIN:
                    continue
                direction = "TX" if (p.flag & xw.XC_NETPACK_FLAG_TX) else "RX"
                packet_ts = _packet_timestamp(p)
                if packet_ts is None:
                    raise RuntimeError("Vector 驱动未提供有效 LIN 硬件时间戳，拒绝生成时序轨迹")
                trace.append((packet_ts, direction, p.id, [b for b in p.data[:p.length]]))
            if len(trace) >= max_frames:
                break
        return trace


    # ---------- 分区切换（BBS 三分区：APP/PBL/SBL，流程固化服务） ----------
    def current_partition(self, nad=NAD_PHYS, timeout=3.0):
        """读取 EDA0（Complete ECU Part/Serial Number）判断当前分区。
        实测依据（DID检查表 sheet303）：EDA0 返回数据含 F1 20→APP、F1 21→PBL、F1 22→SBL。
        返回 'APP'/'PBL'/'SBL'，无法判定返回 None。"""
        resp = self.request(nad, [0x22, 0xED, 0xA0], timeout=timeout)
        if not resp or resp[0] == 0x7F:
            return None
        data = bytes(resp)
        for tag, part in ((b"\xF1\x20", "APP"), (b"\xF1\x21", "PBL"), (b"\xF1\x22", "SBL")):
            if tag in data:
                return part
        return None

    def ensure_partition(self, target, nad=NAD_PHYS, rid_params=None, timeout=3.0):
        """确保 ECU 处于目标分区（APP/PBL/SBL），分区切换流程固化：
        - 读 EDA0 判当前分区，一致则直接返回
        - SBL：0x31 01 03 01（RID 0301 Activate Secondary Bootloader）
            调查表定义（PBL/SBL SDDB Control Routine 页）：
            * Request = 4 字节 memoryAdress（SBL 起始地址，大端 MSB 在前）
            * 会话 = 编程会话 0x10 02；安全 = Level 01 解锁（0x27 通过后才能执行）
            * P4Server_max = 5000ms
            故：真实参数须取 SWRS/Memory Map 中 SBL 起始地址；且依赖 0x27 真实密钥。
            参数未确认/未解锁时传入占位会被 ECU 拒（NRC 0x31/0x33），如实返回失败。
        - PBL：0x10 02 编程会话 + 0x11 01 复位（无有效 APP 时停留在 PBL）
        - APP：0x11 01 复位（前提：APP 已烧录）
        切换后回读 EDA0 确认。返回 (ok, msg)。"""
        target = str(target).upper()
        cur = self.current_partition(nad, timeout)
        if cur == target:
            return True, f"已是{target}分区（EDA0 实测 {cur}）"
        if cur is None:
            return False, "无法判定当前分区（EDA0 读取失败），跳过分区切换"
        if target == "SBL":
            params = rid_params if rid_params is not None else [0x00, 0x00, 0x00, 0x00]
            resp = self.request(nad, [0x31, 0x01, 0x03, 0x01] + list(params), timeout=timeout)
            if not resp:
                return False, "RID 0301 激活 SBL 无应答"
            if resp[0] == 0x7F:
                return False, f"RID 0301 激活 SBL 被拒 NRC=0x{resp[2]:02X}（参数待确认：{params}）"
        elif target == "PBL":
            self.request(nad, [0x10, 0x02], timeout=timeout)
            self.request(nad, [0x11, 0x01], timeout=timeout)
        elif target == "APP":
            self.request(nad, [0x11, 0x01], timeout=timeout)
        else:
            return False, f"未知目标分区 {target}"
        time.sleep(1.0)  # 复位/激活后等 ECU 重启
        cur2 = self.current_partition(nad, timeout)
        if cur2 == target:
            return True, f"已切到{target}分区（EDA0 回读确认）"
        return False, f"切换未生效：当前仍为 {cur2}（期望 {target}）"

# ============ 便捷解析 ============
def is_positive(resp):
    """判断应答是否正响应（SID+0x40）"""
    return bool(resp) and resp[0] != 0x7F


def get_nrc(resp):
    """负响应返回 NRC，正响应返回 None"""
    if resp and resp[0] == 0x7F and len(resp) >= 3:
        return resp[2]
    return None
