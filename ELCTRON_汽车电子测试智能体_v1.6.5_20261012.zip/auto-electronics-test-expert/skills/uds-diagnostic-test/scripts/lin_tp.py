#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LIN TP 纯函数参考实现（离线单测用，与 f1l1_uds.py 的传输层逻辑一致）
=========================================================================
用途：
  1) 脱离硬件固化 LIN TP 经验（PCI 长度 / FF+CF 多帧 / 校验和 / 0x78 pending）
  2) 供 test_lin_tp.py 离线回归，避免把 25~30 的问题重新踩一遍
  3) 需要报文级计算时可复用（PID / 校验和 / 组帧）

约定：payload 含 SID（如 [0x22, 0xF1, 0x2E]）；单帧消息最大 6 字节；
帧 = 8 字节数据槽（NAD + PCI + 消息），剩余补 0xFF。
"""

SF_MAX = 6
FF_DATA = 5   # 首帧数据（NAD+PCI+len 占 3）
CF_DATA = 6   # 连续帧数据（NAD+PCI 占 2）


def compute_pid(frame_id):
    """受保护 ID：6 位帧 ID + 2 位奇偶（P0=ID0^ID1^ID2^ID4，P1=¬(ID1^ID3^ID4^ID5)）"""
    fid = frame_id & 0x3F
    p0 = ((fid >> 0) ^ (fid >> 1) ^ (fid >> 2) ^ (fid >> 4)) & 1
    xor1 = ((fid >> 1) ^ (fid >> 3) ^ (fid >> 4) ^ (fid >> 5)) & 1
    return (((1 - xor1) & 1) << 7) | (p0 << 6) | fid


def compute_checksum(frame_id, data, enhanced=True):
    """LIN 校验和：带进位加法（≥256 减 255）逐位取反。
    经典=仅数据；增强=受保护ID+数据（LIN2.x 非诊断帧默认增强，诊断帧经典）"""
    total = compute_pid(frame_id) if enhanced else 0
    for b in data:
        total += b
        if total >= 256:
            total -= 255
    return (~total) & 0xFF


def pack_sf(nad, payload):
    """单帧：NAD + PCI(0x0|len) + 消息（≤6 字节），补 0xFF 到 8 字节"""
    assert len(payload) <= SF_MAX, f"单帧消息最多 {SF_MAX} 字节，实际 {len(payload)}"
    frame = [nad, len(payload)] + list(payload)
    frame += [0xFF] * (8 - len(frame))
    return bytes(frame)


def pack_ff(nad, payload):
    """首帧：NAD + PCI(0x1|len高4) + len低8 + 前 5 字节；返回 (帧, 剩余 payload)"""
    total = len(payload)
    frame = [nad, 0x10 | ((total >> 8) & 0x0F), total & 0xFF] + list(payload[:FF_DATA])
    frame += [0xFF] * (8 - len(frame))
    return bytes(frame), payload[FF_DATA:]


def pack_cf(nad, seq, chunk):
    """连续帧：NAD + PCI(0x2|seq) + 数据（≤6 字节）；seq 从 1 起、16 循环"""
    frame = [nad, 0x20 | (seq & 0x0F)] + list(chunk)
    frame += [0xFF] * (8 - len(frame))
    return bytes(frame)


def pack_fc(nad, bs=0, stmin=0):
    """流控：NAD + PCI(0x3) + BS + STmin（主机→从机方向）"""
    return bytes([nad, 0x30, bs & 0xFF, stmin & 0xFF, 0xFF, 0xFF, 0xFF, 0xFF])


def pack_request(nad, payload):
    """完整请求组帧：自动单帧/多帧，返回帧列表（多帧逐帧调用方需确认 TX 回显）"""
    if len(payload) <= SF_MAX:
        return [pack_sf(nad, payload)]
    ff, rest = pack_ff(nad, payload)
    frames = [ff]
    seq = 1
    off = 0
    while off < len(rest):
        frames.append(pack_cf(nad, seq, rest[off:off + CF_DATA]))
        off += CF_DATA
        seq = (seq + 1) & 0x0F
    return frames


def parse_frame(frame):
    """解析 8 字节 LIN 帧 → (kind, nad, pci, payload)
    kind: 'sf' / 'ff' / 'cf' / 'fc' / 'unknown'"""
    if len(frame) < 2:
        return ("unknown", 0, 0, b"")
    nad, pci = frame[0], frame[1]
    hi = pci >> 4
    if hi == 0x0:
        return ("sf", nad, pci, bytes(frame[2:2 + (pci & 0x0F)]))
    if hi == 0x1:
        total = ((pci & 0x0F) << 8) | frame[2]
        return ("ff", nad, pci, bytes(frame[3:3 + FF_DATA]), total)
    if hi == 0x2:
        return ("cf", nad, pci, bytes(frame[2:2 + CF_DATA]), pci & 0x0F)
    if hi == 0x3:
        return ("fc", nad, pci, bytes(frame[2:4]))
    return ("unknown", nad, pci, b"")


def assemble(frames):
    """应答重组：单帧直接返回；FF+CF 拼装返回完整 payload；
    0x78 pending 返回 b"PENDING"（调用方继续等待最终应答）"""
    if not frames:
        return None
    kind, nad, pci, payload = frames[0][0], frames[0][1], frames[0][2], frames[0][3]
    if kind == "sf":
        if len(payload) >= 3 and payload[0] == 0x7F and payload[2] == 0x78:
            return b"PENDING"
        return payload
    if kind != "ff":
        return None
    total = frames[0][4]
    body = bytearray(payload)
    expect_seq = 1
    for fr in frames[1:]:
        k2, _n2, p2, pay2 = fr[0], fr[1], fr[2], fr[3]
        if k2 == "cf":
            seq = p2 & 0x0F
            if seq != expect_seq:
                return None  # 序号不连续（顺序接收）
            body += pay2
            expect_seq = (expect_seq + 1) & 0x0F
        elif k2 == "sf":
            # 异常：多帧中收到新单帧（可能是 7F 78）
            if len(pay2) >= 3 and pay2[0] == 0x7F and pay2[2] == 0x78:
                return b"PENDING"
            return pay2
    return bytes(body[:total])


def is_pending(resp):
    return resp == b"PENDING"


# ============ 轨迹时序分析（采集-后处理，供 timing_trace / f1l1 引用） ============

def _is_request_frame(direction, frame_id, master_id):
    return direction == "TX" and frame_id == master_id


def analyze_trace(trace, master_id=0x3C, slave_id=0x3D, nad=0x51, window_ms=500):
    """离线时序分析（轨迹 → 时序指标）
    输入: [(ts, direction, frame_id, data_bytes)]（direction: TX/RX）
    输出 dict: duration_s / total_frames / frame_slot_ms{min,avg,max} /
               p2_ms[] / p2_star_ms[] / pending_count / nrc37_gaps_ms[] / warnings[]
    规则：P2=请求→首个应答；应答为 7F xx 78(pending) 时 P2*=请求→最终应答；
          0x27 请求遇 NRC 0x37 后记录到下一次 0x27 的间隔（延迟观测）。"""
    tx = [e for e in trace if _is_request_frame(e[1], e[2], master_id)]
    rx = [e for e in trace if e[1] == "RX" and e[2] == slave_id]
    frame_slot = [round((tx[i][0] - tx[i - 1][0]) * 1000, 3) for i in range(1, len(tx))]
    p2, p2_star, pending_count, nrc37_gaps = [], [], 0, []
    last_nrc37_ts = None
    for i, (t, _d, _fid, data) in enumerate(tx):
        sid = data[2] if len(data) >= 3 else None
        next_tx_ts = tx[i + 1][0] if i + 1 < len(tx) else t + window_ms / 1000.0
        resp_frames = [(rt, rdata) for rt, rdata in ((r[0], r[3]) for r in rx) if t <= rt < next_tx_ts]
        if not resp_frames:
            continue
        first_ts, first_data = resp_frames[0]
        if (len(first_data) >= 5 and first_data[0] == nad
                and (first_data[1] & 0xF0) == 0x00 and first_data[2] == 0x7F
                and first_data[4] == 0x78):
            pending_count += 1
            p2_star.append(round((resp_frames[-1][0] - t) * 1000, 3))
        else:
            p2.append(round((first_ts - t) * 1000, 3))
        if sid == 0x27:
            nrc = None
            for _rt, rdata in resp_frames:
                if len(rdata) >= 5 and rdata[0] == nad and rdata[2] == 0x7F:
                    nrc = rdata[4]
                    break
            if nrc == 0x37 and last_nrc37_ts is not None:
                nrc37_gaps.append(round((t - last_nrc37_ts) * 1000, 3))
            last_nrc37_ts = t if nrc == 0x37 else None
    stats = {
        "duration_s": round(trace[-1][0] - trace[0][0], 3) if len(trace) >= 2 else 0.0,
        "total_frames": len(trace),
        "frame_slot_ms": {"min": min(frame_slot), "avg": round(sum(frame_slot) / len(frame_slot), 3), "max": max(frame_slot)}
        if frame_slot else None,
        "p2_ms": p2,
        "p2_star_ms": p2_star,
        "pending_count": pending_count,
        "nrc37_gaps_ms": nrc37_gaps,
        "warnings": [],
    }
    if frame_slot and max(frame_slot) - min(frame_slot) > 5:
        stats["warnings"].append(f"帧隙抖动 >5ms（min={min(frame_slot)}ms max={max(frame_slot)}ms），调度或负载异常")
    if p2 and max(p2) > 50:
        stats["warnings"].append(f"P2 最大 {max(p2)}ms 超过诊断表 P2Server=50ms")
    return stats


def format_trace_report(stats, master_id=0x3C, slave_id=0x3D):
    """轨迹分析结果 → 可读报告文本"""
    L = ["# LIN 高实时时序测量报告（采集-后处理）", ""]
    L.append(f"- 主请求帧: 0x{master_id:02X} ｜ 应答帧: 0x{slave_id:02X} ｜ 采集时长: {stats['duration_s']}s ｜ 帧数: {stats['total_frames']}")
    L.append("")
    fs = stats["frame_slot_ms"]
    L.append("## 帧隙（主请求帧间隔）")
    L.append(f"- min={fs['min']}ms ｜ avg={fs['avg']}ms ｜ max={fs['max']}ms" if fs else "- 无主请求帧")
    L.append("")
    L.append("## P2 / P2*")
    L.append(f"- P2 样本 {len(stats['p2_ms'])} 个: min={min(stats['p2_ms']) if stats['p2_ms'] else '-'}ms ｜ max={max(stats['p2_ms']) if stats['p2_ms'] else '-'}ms")
    L.append(f"- P2*（含 0x78 pending）样本 {len(stats['p2_star_ms'])} 个: {stats['p2_star_ms'][:10]}")
    L.append(f"- pending 次数: {stats['pending_count']}")
    L.append("")
    if stats["nrc37_gaps_ms"]:
        L.append("## 0x37 延迟（失败后到下次 0x27 的间隔）")
        L.append(f"- {stats['nrc37_gaps_ms']}")
    if stats["warnings"]:
        L.append("")
        L.append("## 告警")
        for w in stats["warnings"]:
            L.append(f"- ⚠️ {w}")
    return "\n".join(L)
