# -*- coding: utf-8 -*-
"""参考 XLSX 写作逻辑适配器的行为测试。"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

# 允许从仓库根目录按绝对路径直接运行 unittest，不依赖外部 PYTHONPATH。
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from cybersecurity_case_generator import build_cybersecurity_cases
from reference_case_adapter import validate_reference_case
from swdl_case_generator import build_swdl_cases


class ReferenceCaseGeneratorTests(unittest.TestCase):
    def test_swdl_cases_follow_reference_columns_and_traceability(self):
        result = build_swdl_cases(
            requirement_ids=["REQ-6.15.1", "REQ-6.15.2"],
            flowchart_ready=False,
            key_material_ready=False,
        )
        self.assertEqual(result["schema_version"], "reference-case-bundle/v0.1")
        self.assertGreaterEqual(len(result["cases"]), 8)
        first = result["cases"][0]
        for field in (
            "req_sources", "case_id", "priority", "auto_eval", "test_point",
            "test_method", "design_method", "env", "precondition",
            "procedure", "expected", "select",
        ):
            self.assertTrue(first.get(field), field)
        self.assertTrue(first["case_id"].startswith("SWDL_TC_"))
        self.assertEqual(first["traceability_status"], "READY")
        self.assertEqual(result["generation_status"], "DEGRADED")
        self.assertTrue(any(c["generation_status"] == "BLOCKED" for c in result["cases"]))
        self.assertTrue(validate_reference_case(first)["valid"])

    def test_swdl_does_not_claim_pass_without_execution(self):
        result = build_swdl_cases(requirement_ids=["REQ-6.15.1"])
        self.assertTrue(all(c["execution_verdict"] == "NOT_EXECUTED" for c in result["cases"]))
        self.assertFalse(any(c.get("test_result") == "PASS" for c in result["cases"]))

    def test_cybersecurity_cases_have_security_metadata_and_style(self):
        result = build_cybersecurity_cases(
            requirement_ids=["REQ-9.1"],
            key_material_ready=False,
            bus="LIN",
        )
        self.assertGreaterEqual(len(result["cases"]), 6)
        ids = [c["case_id"] for c in result["cases"]]
        self.assertTrue(all(case_id.startswith("TG1_TC") for case_id in ids))
        self.assertTrue(all(c["auto_eval"] == "否" for c in result["cases"]))
        self.assertTrue(all(c["security_metadata"]["bus"] == "LIN" for c in result["cases"]))
        self.assertTrue(all("CS" in c["security_metadata"] for c in result["cases"]))
        self.assertTrue(any("0x27" in c["test_point"] for c in result["cases"]))
        self.assertTrue(any(c["generation_status"] == "BLOCKED" for c in result["cases"]))

    def test_security_cases_are_not_lin_signal_cases(self):
        result = build_cybersecurity_cases(requirement_ids=["REQ-9.1"], bus="LIN")
        self.assertFalse(any(c["case_id"].startswith("LIN-") for c in result["cases"]))
        self.assertFalse(any(c.get("category") == "lin-network" for c in result["cases"]))


if __name__ == "__main__":
    unittest.main()
