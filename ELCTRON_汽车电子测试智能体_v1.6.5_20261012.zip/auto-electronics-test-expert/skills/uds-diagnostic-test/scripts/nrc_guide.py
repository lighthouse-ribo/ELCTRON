#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NRC 快速查询：名称 / 常见场景 / 根因方向 / 处置
用法:
  python nrc_guide.py 0x37
  python nrc_guide.py 37
  python nrc_guide.py --list
详细知识库见 references/nrc-troubleshooting.md
"""

import sys


NRC_DB = {
    0x10: ("generalReject", "通用拒绝", "视具体请求", "按请求内容细分排查"),
    0x11: ("serviceNotSupported", "服务本身不支持", "服务未实现/未列调查表", "查调查表服务清单；未列服务按不支持负例"),
    0x12: ("subFunctionNotSupported", "0x11 非法复位子功能、0x31 非法子功能", "子功能值不在支持集",
           "核对 SWRS/调查表子功能；ISO 默认非法子功能回 0x12"),
    0x13: ("incorrectMessageLengthOrInvalidFormat", "请求长度与期望不符", "PCI 长度算错（单帧把 SID 重复计入/漏计）、数据长度错",
           "单帧 PCI=消息字节数（含 SID，不含 NAD/PCI）；按 LDF/DID 长度核对"),
    0x22: ("conditionsNotCorrect", "0x27 seed 请求被拒（密钥候选不符）、条件未满足", "密钥/算法参数、整车条件、会话前置",
           "先验密钥文件非占位；再验算法参数（IV/CMAC）；查前置条件"),
    0x31: ("requestOutOfRange", "F10A/F103 只读 DID 读取、密钥候选不符、SBL 分区属性", "DID 属性（22 读=No）、参数越界、密钥不符",
           "查诊断表 DID 属性；只读/条件受限标 NA 不标 FAIL"),
    0x33: ("securityAccessDenied", "未解锁访问 0x2E/0x31 受保护服务", "解锁前置缺失", "先完成 0x27 解锁再访问；用例前件必须写解锁"),
    0x35: ("invalidKey", "0x27 发送错误密钥", "密钥值错误/算法参数错", "核对密钥文件与算法（Gen2：CMAC/CTR 参数）"),
    0x36: ("exceedNumberOfAttempts", "连续错误密钥", "尝试次数超限锁定", "按 SWRS 延迟等待解锁计数重置；负例要控制次数"),
    0x37: ("requiredTimeDelayNotExpired", "0x27 频繁失败触发延迟（启动 5000ms/失败 10000ms）", "时间延迟未到期",
           "等待延迟后重试；测试流程加 0x3E 保活避免误判"),
    0x7E: ("subFunctionNotSupportedInActiveSession", "子功能在当前会话不支持", "会话归属错误",
           "核对服务×会话矩阵；如 0x27 等级 01 仅编程会话"),
    0x7F: ("serviceNotSupportedInActiveSession", "会话丢失（S3 超时）后请求、服务不在当前会话", "会话掉回默认、密钥=0xFF",
           "0x3E 每 3s 保活；请求前 F186 确认会话；密钥非占位"),
    0x78: ("responsePending", "长操作（刷写/例程）处理中", "正常 pending", "不重发，等 P2* 后最终应答（f1l1 引擎已处理）"),
}


def parse_nrc(s):
    t = s.strip().lower()
    try:
        return int(t, 16) if t.startswith("0x") else int(t, 16)
    except ValueError:
        return None


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        sys.exit(0)
    if args[0] == "--list":
        print(f"{'NRC':<6} {'名称':<38} 场景")
        for nrc in sorted(NRC_DB):
            name, scene, _r, _a = NRC_DB[nrc]
            print(f"0x{nrc:02X}   {name:<38} {scene}")
        sys.exit(0)
    nrc = parse_nrc(args[0])
    if nrc is None or nrc not in NRC_DB:
        print(f"[ERROR] 未知 NRC: {args[0]}（可用 --list 查看支持列表）")
        sys.exit(1)
    name, scene, root, action = NRC_DB[nrc]
    print(f"NRC 0x{nrc:02X}  {name}")
    print(f"  常见场景: {scene}")
    print(f"  根因方向: {root}")
    print(f"  处置    : {action}")
    if nrc in (0x22, 0x31, 0x7F, 0x37, 0x33):
        print("  [0x27 链] 按 references/nrc-troubleshooting.md 的 0x27 专属排查链逐项核对")


if __name__ == "__main__":
    main()
