# UDS 诊断测试技能 (Windows + Vector 版)

UDS（Unified Diagnostic Services）诊断自动化测试工具，Windows 定制版：
解析诊断调查表 → 生成测试脚本 → 通过 **Vector VN1630A / VN1640A**（XL Driver Library）执行测试并输出报告。

原版基于 Linux SocketCAN，本版已移植到 Windows + python-can `vector` 后端。

## 功能

- 解析诊断调查表（Excel/CSV/JSON），自动提取 DID、DTC、IOControl、Routine、CAN 配置
- 生成高覆盖率 UDS 测试脚本（会话验证/安全访问/边界值/NRC 验证）
- 通过 Vector 硬件执行测试，支持 Classic CAN 和 CAN FD
- 输出 Markdown 测试报告 + CAN 通信日志（.asc 格式，兼容 CANoe/CANalyzer）
- 输出统一单文件 HTML 报告：复用 `templates/uds_report_framework.html` 的原始页面框架，软件版本使用测试时间轴切换，同一版本内用模块页签切换 UDS、网络安全及后续测试块；数据采用真实执行结果，离线可打开。
- 支持 $27 SecurityAccess 自动解锁（Vector SeedKey DLL，64 位）
- 支持 $27 Gen2 纯 Python 解锁（`--sa-key-file` 密钥 JSON，占位 0xFF 自动标 BLOCKED）
- 执行前硬件预检（`can_init.py --preflight`：后端 + VickCAN/CANoe 进程占用 + 通道列表）
- 支持 F1L1 (CANviex) UDS-over-LIN 路线（`scripts/f1l1_uds.py`，见 `references/f1l1-lin-uds.md`）
- 支持 LDF（LIN 描述文件）解析（`scripts/ldf_parser.py`：帧/PID/信号/调度表/节点属性）
- 一键项目编排 `uds_runner.py project`（解析→LDF→审计→生成→预检→链路通探测→执行→覆盖率，门禁不过即中止）
- 执行前链路通探测 `uds_runner.py link-check` / `scripts/link_check.py`（总线活动 + ECU 0x3E 应答）
- 直接输出条件（2026-08-20 固化）：仅当 CANoe/VickCAN 占用进程、CANviex/F1L1、Vector 设备三类硬件探测全部成功且均为 0 时才允许直接输出设计产物；任一类探测失败/未知一律按存在硬件处理，不再提供无硬件可跳过的 generate-only 模式

## 硬件与软件要求

- **Vector 硬件**：VN1630A 或 VN1640A（均 4 通道、编号 0-3：VN1630A = 2 路板载 CAN/CAN FD + 2 路 Piggy 槽位（可配 CAN/LIN）；VN1640A = 4 路 Piggy 槽位（可配 CAN FD/LIN/J1708）。实际可用协议取决于所装收发器），或其它 Vector XL 兼容设备
- **Vector Driver Setup / XL Driver Library**：提供 `vxlapi64.dll`，一般随 CANoe 安装
- **Python 3.10+ x64**（必须 64 位，与 vxlapi64.dll 匹配）
- **python-can >= 4.0**（本技能要求的 CAN 库，安装脚本自动处理）
- CAN 总线：连接目标 ECU

## 通道占用（重要）

Vector 的 XL Driver Library 同一通道同一时间只允许一个程序占用。
执行 python 测试前，**必须先关闭 CANoe 和 VickCAN**，或使用不同的通道。

## 多盒子选择（VN1630A / VN1640A 同时连接）

两个盒子同时接到电脑时，用 `--serial <序列号>` 指定使用哪个设备。
序列号可通过以下命令查看：

```powershell
& $env:UDS_PYTHON .\scripts\can_init.py --check
```

例：指定 VN1640A 的通道 1：

```powershell
& $env:UDS_PYTHON $env:UDS_WORK\uds_test.py --channel 1 --serial <VN1640A序列号> --report ...
```

不指定 `--serial` 时自动选择可用设备。

## 安装

### 1. 确认 Vector 驱动

在设备管理器中确认 VN1630A 已识别，且系统能找到 `vxlapi64.dll`
（通常由 Vector Driver Setup 安装到 `C:\Windows\System32`）。
如果没有，请运行 CANoe 安装包中的 Vector Driver Setup，或从 Vector 官网下载 XL Driver Library。

### 2. 运行环境安装脚本

进入技能根目录，在 PowerShell 中执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup_env.ps1
```

脚本会：

- 自动寻找 64 位 Python（`py` 或 `python`）
- 创建虚拟环境 `%USERPROFILE%\.uds_venv`
- 按 `requirements.txt` 安装全部依赖：`python-can` / `openpyxl` / `cryptography` / `cantools` / `pymupdf`(fitz) / `pywin32`(win32com)
- 校验 Vector 后端是否可加载
- 校验可选能力 `fitz` / `win32com`（加密 PDF 深解析通道），缺失时给出 WARN
- 写入环境文件 `%USERPROFILE%\.uds_env`（`UDS_PYTHON` / `UDS_SKILL_DIR` / `UDS_WORK`）

### 3. 载入环境变量（每个新 PowerShell 会话一次）

**所有后续命令统一用 `$env:UDS_PYTHON` 调用解释器**，不要硬写 `.uds_venv\Scripts\python.exe`——
`UDS_PYTHON` 才是「唯一环境来源」，指向哪个解释器由 `.uds_env` 决定（换环境/换机器只需改这一处）。

```powershell
Get-Content "$env:USERPROFILE\.uds_env" | ForEach-Object {
    if ($_ -match '^([^=]+)=(.*)$') { Set-Item -Path "Env:$($matches[1])" -Value $matches[2] }
}
```

（与 `SKILL.md`「会话初始化」章节的装载片段一致，含缺失兜底与有效性校验。）

载入后 `$env:UDS_PYTHON` / `$env:UDS_SKILL_DIR` / `$env:UDS_WORK` 均可用。

> **双轨坑（2026-09-14 实测）**：`~/.uds_env` 的 `UDS_PYTHON` 曾指向另一个已装全依赖的解释器
> （如 `~/.workbuddy/binaries/python/envs/default`），而文档让你敲的 `~/.uds_venv` 缺 `fitz`/`win32com`，
> 按文档敲 `srs-doc-extract` 的加密 PDF 通道会直接 `ImportError`。以 `UDS_PYTHON` 为准即可规避；
> 若坚持用 `.uds_venv`，请确认它已按 `requirements.txt` 装全（重跑 `setup_env.ps1`）。

### 4. 验证硬件

```powershell
& $env:UDS_PYTHON .\scripts\can_init.py --check
```

## 使用流程

1. 解析调查表：

   ```powershell
   & $env:UDS_PYTHON .\scripts\uds_survey_parser.py --input <调查表> --output $env:UDS_WORK\uds_parsed.json
   ```

2. 检查解析结果（`can_config` / `defaults_used` / `missing_attributes`），与用户确认后生成（多盒子时加 `--serial`）：

   ```powershell
   & $env:UDS_PYTHON .\scripts\uds_test_generator.py --input $env:UDS_WORK\uds_parsed.json --output $env:UDS_WORK\uds_test.py --confirmed
   ```

3. 执行：

   ```powershell
   & $env:UDS_PYTHON $env:UDS_WORK\uds_test.py --report $env:UDS_WORK\uds_report.md --can-log $env:UDS_WORK\can_trace.asc
   ```

完整一键流水线（跳过中间确认，仅当用户明确要求）：

```powershell
& $env:UDS_PYTHON .\scripts\uds_runner.py pipeline --input <调查表> --output-dir $env:UDS_WORK\pipeline_output
```

## CAN FD 配置

- 仲裁段波特率：默认 500000（可由调查表或 `--bitrate` 覆盖）
- 数据段波特率：默认 2000000（`--fd-data-bitrate` 覆盖）
- 采样点：Vector 硬件的采样点由 Vector Hardware Config / CANoe 配置管理，脚本内仅记录，不直接下发

## SecurityAccess ($27) SeedKey DLL

- 使用 Vector 标准 SeedKey DLL（64 位，`GenerateKeyEx` / `GenerateKeyExOpt` 原型）
- 生成时指定：`--sa-dll <dll路径> --sa-variant <变体> --sa-options <选项>`
- 与 CANoe / VickCAN 中使用的 Vector 原型 A/B DLL 兼容（确认函数原型，避免崩溃）
- 生成脚本时自动做 DLL 预检：PE 位数（x86 在 64 位 Python 下无法加载）、同目录常见依赖缺失、接口签名（检测到 VickCAN 自定义接口如 `volvo_27_XX_hstreq/devrsp` 会明确提示替代方案）
- 无标准 DLL 时用纯 Python Gen2：`--sa-key-file <VolvoKey.json>`；`seedkey_gen2.py --check <key.json>` 可单独预校验密钥（退出码 0=就绪，2=占位/缺失）
- **结果分类**：PASS / FAIL / NA / BLOCKED / SKIP；0x27 密钥占位时正例标 BLOCKED（非 FAIL），报告单独列出阻塞用例，通过率排除 NA/BLOCKED

## 执行前预检（推荐）

```powershell
& $env:UDS_PYTHON .\scripts\can_init.py --preflight
```

一次性检查 Vector 后端、VickCAN/CANoe 占用进程、通道列表。流水线可加 `--preflight` 自动执行。

## 一键编排与链路通门禁（推荐）

```powershell
# 链路通探测（CAN/LIN 二选一；不通返回 1）
& $env:UDS_PYTHON .\scripts\uds_runner.py link-check --bus can --channel 0 --tx-id 0x7E0 --rx-id 0x7E8 --bitrate 19200
& $env:UDS_PYTHON .\scripts\uds_runner.py link-check --bus lin --nad 0x51

# 一键项目编排（目录输入自动选调查表；执行门禁自动决定直接输出或硬件执行，不再提供 --generate-only）
& $env:UDS_PYTHON .\scripts\uds_runner.py project --input <调查表或目录> --output-dir <输出> --ldf <cluster.ldf> --bus lin --sa-key-file <key.json>
```

## LIN / F1L1 路线

`scripts/f1l1_uds.py` 提供 F1L1 UDS-over-LIN 引擎（完整 LIN TP 多帧 + 0x78 pending）。使用前设置
`F1L1_XCWRAPPER_DIR` 指向 xcdev_wrapper.py 所在目录；实测排障要点（outputV 供电、0x3D 应答、
PCI 长度、多帧 TX 回显、会话保活、密钥占位）见 `references/f1l1-lin-uds.md`。

## LDF 解析（LIN 网络输入，对应 CAN 的 DBC）

```powershell
& $env:UDS_PYTHON .\scripts\ldf_parser.py --input cluster.ldf --output lin_db.json
```

输出帧 ID、受保护 ID（PID，奇偶位自动计算）、信号位偏移（LSB0）、调度表、节点 NAD 等，
供 LIN 帧级步骤生成与通信测试核对。协议细节见 `references/lin-protocol-cheatsheet.md`。

## 调查表

支持 Excel（.xlsx/.xls）、CSV、JSON。
关键属性清单见 `references/nrc-troubleshooting.md` 的"诊断调查表关键属性清单"（NRC/会话矩阵/调查表属性已合并至该文档）。
注意：被加密（如公司透明加密）的 Excel 文件无法直接解析，需提供解密副本。

## 常见问题

| 现象 | 处理 |
|------|------|
| `vxlapi64.dll` 找不到 | 安装 Vector Driver Setup；确认 Python 64 位 |
| 通道被占用 | 关闭 CANoe / VickCAN，或换通道 |
| 连错盒子（两个同时接） | 用 `--serial <序列号>` 指定，`can_init.py --check` 查序列号 |
| pip 装出 `can-0.0.0` / `python-can 1.5.x` | 包源/镜像问题，停止重试，检查 pip 源 |
| 未检测到硬件 | 检查 USB 连接、驱动、设备管理器；`can_init.py --check` |

## 版本

- 3.0.0-win：Windows + Vector (VN1630A) 定制版，替换 SocketCAN 后端
- 上游：TongLi0406/uds-diagnostic-test v2.9.0
