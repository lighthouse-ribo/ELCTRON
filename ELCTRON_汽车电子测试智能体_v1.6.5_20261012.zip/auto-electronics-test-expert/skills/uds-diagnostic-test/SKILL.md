---
name: uds-diagnostic-test
version: "3.8.1-win"
description: "UDS 诊断测试技能 (Windows + Vector VN1630A / VN1640A / F1L1 LIN)。Use when: 收到诊断调查表、UDS diagnostic survey table、生成 UDS 测试脚本、基于诊断资料生成测试、执行 UDS 诊断测试、CAN 测试、LIN 测试、DID 测试、DTC 测试、IOControl 测试、RoutineControl 测试、诊断服务测试、diagnostic test script generation and execution via Vector XL Driver Library；执行前硬件预检（进程占用/通道）、$27 密钥预校验（占位 0xFF 标 BLOCKED）、F1L1 UDS-over-LIN 排障"
argument-hint: "提供诊断调查表文件路径，或描述需要测试的诊断服务"
---

# UDS 诊断测试技能 (Windows + Vector)

## SWDL 分层架构（v0.1）

SWDL（Software Download，软件刷写）是一个独立能力域，不等同于把 0x34/0x36/0x37 几个 UDS 服务串起来。当前项目资料可能不完整，尤其是 0x27 SecurityAccess 的真实密钥材料可能尚未获得，因此采用“先搭架构、后按资料填充”的策略：

```text
输入资料体检 → 能力状态评估 → SWDL 用例骨架 → 独立静态审查
       → 执行适配器（VickCAN/F1L1 或 Vector）→ 原始证据 → 统一报告
```

配套文件：
- `schemas/swdl-architecture-v0.1.json`：输入、能力和状态契约，不保存密钥明文；
- `schemas/swdl-input-manifest.example.json`：按资料成熟度填充的 SWDL 输入清单示例；
- `templates/swdl-case-skeleton.json`：可填充的 SWDL 基线用例；
- `scripts/swdl_architecture.py`：能力评估和用例骨架生成接口；
- `scripts/test_swdl_architecture.py`：缺资料状态下的回归测试。
- `scripts/swdl_case_review.py`：校验阶段顺序、证据要求和 PASS/BLOCKED 语义；
- `scripts/reference_case_adapter.py`：复用系统合格性测试用例表的 B~N 列写作契约；
- `scripts/swdl_case_generator.py`：按 `SWDL_TC_####` 生成需求、主流程、故障注入和边界用例；
- `scripts/cybersecurity_case_generator.py`：按“网络安全”工作表生成 `TG1_TC*_SC1` 安全用例；LIN 只作为承载通道，不生成 LIN 帧/信号测试；
- `scripts/generate_reference_cases.py`：上述两类用例的 JSON CLI 入口；
- `scripts/swdl_report_adapter.py`：将 `swdl_report.json` 转成统一 HTML 报告输入；
- `scripts/swdl_trace_import.py`：离线导入 ASC 或**文本导出的** XCT，重组 LIN-TP 并提取 SWDL 阶段观察证据；二进制专有 XCT 以 `BLOCKED` 失败关闭，必须先由原厂工具导出 ASC/文本，不猜测字节布局；
- `scripts/test_swdl_architecture.py`、`test_swdl_case_review.py`、`test_swdl_report_adapter.py`：架构、用例和报告契约回归测试。

**SWDL 输入清单使用规则**：先复制 `schemas/swdl-input-manifest.example.json`，再按项目资料填写 `path/status/sha256`；密钥只填写受控引用或 `null`，禁止把密钥明文写入 manifest。每次资料补充后重新运行能力评估、用例校验和脚本审查。


| 资料状态 | 允许做什么 | 必须阻断什么 |
|---|---|---|
| 缺少刷写流程图 | 记录缺口、保留总体架构、输出输入体检报告 | SWDL 用例设计和脚本生成 |
| 缺少 0x27 真实密钥 | 设计非执行型用例骨架、静态规则审查、生成 BLOCKED 报告 | 0x27、0x34、0x36、0x37 实机刷写 |
| 缺少镜像或 SHA-256 | 生成阶段模板、检查字段完整性 | 镜像传输和 PASS 判定 |
| 缺少 Memory Map | 保留地址字段待填、输出边界缺口 | 地址确认、擦除和分区执行 |
| 仅缺少时序/CheckMemory细节 | 输出 DEGRADED 并列出待补项 | 未经确认的时序 PASS |

**未执行不能标记 PASS**。应使用 `PLANNED`、`NOT_EXECUTED`、`DEGRADED` 或 `BLOCKED`，待资料补齐并完成实机证据后再进入 PASS/FAIL 统计。密钥只通过本地安全 provider 或受控引用接入，不进入上下文、日志和报告。
### SWDL 记录文件回读（v3.10）

SWDL 完成后或收到外部实车记录时，先做**只读离线导入**，将报文重组成 LIN-TP 事务并输出可审计 JSON。导入结果固定为 `OBSERVED_ONLY`：它只说明日志中观察到了哪些服务和阶段，不能单独把用例或 SWDL 流程改判为 PASS。

```powershell
# VickCAN / CANoe / CANalyzer ASC，或已导出为文本的 XCT
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\swdl_trace_import.py" `
  --input "<run.asc 或 exported.xct>" `
  --out "$env:UDS_WORK\swdl_trace_evidence.json" `
  --master-id 0x3C --slave-id 0x3D
```

- 自动保留源文件绝对路径、SHA-256、源行号、时间戳、方向、LIN ID 与原始字节；重组 `0x10/0x27/0x31/0x34/0x36/0x37/0x11`，并将 `0x78` 当作 pending，而不是最终应答。
- `.xct` 只接受有明确时间戳、方向、ID、DLC、字节字段的文本导出（CSV/TSV/分号或空格列）。原始二进制 XCT 的厂商格式没有可验证的公开布局，插件必须拒绝解析并提示导出 ASC/文本，禁止凭猜测生成证据。
- 继续以本次硬件采集的 trace JSON ↔ ASC ↔ result JSON 作为正式执行证据；历史 ASC/XCT 导入用于复盘、时序分析和与 SWDL 报告人工对账。

## 参考系统合格性测试表写作逻辑

SWDL 与网络安全用例现在统一采用参考 XLSX 的字段组织：需求来源、用例 ID、优先级、自动化评估、测试点、测试方法、用例设计方法、测试环境、前提条件、操作步骤、预期结果和选择测试用例。生成器只写设计期字段，结果列留空，执行结论保持 `未执行`。

- SWDL：主流程覆盖 `0x10→0x27→0x34→0x36→0x37→CheckMemory→0x11→版本确认`，另含未解锁、块计数器、地址越界和中断恢复等异常/边界用例。
- 网络安全：覆盖 0x27 Gen2、未授权访问、随机数、重放、长度边界、错误 Key 锁定、会话权限和受控模糊测试；`FuSa?/CS?/ASIL/CAL` 作为独立 `security_metadata` 保存。
- 缺失流程图、真实密钥等资料时，仍可生成结构化用例，但对应条目标记 `BLOCKED`；不把缺资料写成 FAIL，也不生成虚构 PASS。
- 网络安全与 `lin-network-test` 分开：`bus=LIN` 仅说明安全测试经 LIN 承载，不能生成 `LIN-*` 帧/信号/调度用例。

CLI 示例：
```powershell
python .\\scripts\\generate_reference_cases.py --module swdl --requirement REQ-6.15.1 --out swdl_reference_cases.json
python .\\scripts\\generate_reference_cases.py --module cybersecurity --requirement REQ-9.1 --bus LIN --out cybersecurity_reference_cases.json
```

## 目标

这个 skill 只解决三件事：

1. 用固定 Python 环境解析调查表（支持 Excel/CSV/JSON/**CDD**）
2. 生成并验证 UDS 测试脚本
3. 通过 Vector 硬件 (VN1630A / VN1640A, XL Driver Library) 执行测试

本版本为 Windows 定制版：CAN 后端固定为 python-can 的 `vector` 接口，不再使用 SocketCAN。
驱动安装、通道占用、CAN FD 配置、SecurityAccess 替代方案、NRC 说明、调查表默认值参考，统一放在 `README.md`。

## 输入格式（v3.1 新增）

- **CDD (CANdela 诊断文件)**：`uds_survey_parser.py --input file.cdd --output uds_parsed.json`，走 cantools 适配器自动提取 DID（含信号级 sub_data）。CDD 不包含会话/安全权限信息 → 使用默认值并记录 `defaults_used`，在「强制确认」环节请用户补充。
- **DBC (CAN 数据库文件)**：`scripts/dbc_parser.py --input file.dbc --output can_db.json`，提取报文/信号定义（frame_id/start/length/scale/offset），供用例报文级步骤自动生成 hex（cantools encode_message/decode_message）。
- **LDF (LIN 描述文件，v3.3 新增)**：`scripts/ldf_parser.py --input cluster.ldf --output lin_db.json`，解析帧（含 **PID 受保护 ID 自动计算**：P0=ID0^ID1^ID2^ID4，P1=¬(ID1^ID3^ID4^ID5)）/信号（LSB0 位偏移）/调度表/节点属性（configured_NAD 等）/信号编码，供 LIN 帧级步骤生成与 LIN 通信测试；无第三方依赖。
- **用例报文自动生成**（配合 srs-uds-testcase-designer）：用例 JSON 中的占位符（`{{READ_DID:}}`/`{{WRITE_DID:}}`/`{{SESSION:}}`/`{{TP}}`/`{{MSG:}}`/`{{DECODE:}}`）由 `srs-uds-testcase-designer/scripts/steps_generator.py` 自动填充，`--cdd` 供 DID 长度、`--dbc` 供信号编解码；**v2.0 带审计审查**（PASS/WARN/FAIL 三态，FAIL 阻断交付并标「[审查失败]」，`--audit` 出审计报告），填充后再生成执行脚本，保证「用例设计 → 脚本执行」报文参数一致且可追溯。
- 依赖：`pip install cantools`（与 python-can 同环境，已有则跳过）。

## 唯一规则

- 唯一环境入口：先进入 skill 根目录，再执行 `powershell -ExecutionPolicy Bypass -File .\scripts\setup_env.ps1`
- 唯一环境来源：`%USERPROFILE%\.uds_env` 的 **`UDS_PYTHON`**（解释器路径的唯一真相）。它默认指向 `%USERPROFILE%\.uds_venv`，也可能指向其它已按 `requirements.txt` 装全依赖的解释器；命令一律写 `& $env:UDS_PYTHON <脚本>`，**不要硬写 venv 路径**，否则会踩「文档环境缺 fitz/win32com」的双轨坑
- 唯一 CAN 后端：`vector`（Vector VN1630A / VN1640A，依赖 vxlapi64.dll），4 通道 0-3；VN1630A 的 CH3/CH4 需装 CAN Piggy 才能用作 CAN
- 两个盒子同时连接时，用 `--serial <序列号>` 指定设备（`can_init.py --check` 可查看各盒子序列号）
- Python 必须为 **64 位**；唯一正确包名：`python-can`（>=4.0），不要执行 `pip install can`
- 执行测试前必须关闭 CANoe / VickCAN（同一通道同一时间只允许一个程序占用）
- **不走上位机/COM 串口执行测试（已舍弃 2026-08-14）**：自动化只走设备原生 DLL（F1L1 xcdevlay ctypes / Vector XL Driver Library）直调；上位机仅人工查看，不作为任何自动化环节（见 `references/test-path-guide.md`）
- **硬件路径选择（2026-08-20 固化）**：执行门禁先检测 CANoe/VickCAN 等占用进程和 CANviex/F1L1（`F1L1_DLL_PATH=<路径>/xcdevlay.dll` + `xw.detect(3)`）。只有两者都明确不存在时才允许直接输出设计产物；只要检测到任一项，必须走硬件执行路径，探测失败也不得按“无硬件”放行。F1L1 执行前关闭 VickCAN.exe/CANoe 释放通道
- 环境修复默认只允许重跑 `setup_env.ps1`；除非用户明确要求，否则不要手工执行 pip uninstall/install
- 默认工作目录：`%USERPROFILE%\.uds_workspace`
- **对外交付物根：`%LOCALAPPDATA%\AETEX\deliverables\<run_id>\`**（runtime 从 run 树的 `05_final/` 链接发布；可用 `AETEX_HOME` / `AETEX_DELIVERABLES_DIR` 覆盖）。**禁止把交付物写进专家包任何位置**（包根、`skills/*/deliverables/`）——专家包是受 git 管理与快照安装的主体，产物写进去会被索引污染、混入打包快照，并可能被 `git clean -x` 不可逆清除

## 高频错误快查

| 现象 | 处理 |
|------|------|
| `Vector 后端不可用` / `vxlapi64.dll` 找不到 | 安装 Vector Driver Setup (XL Driver Library)，确认 Python 为 64 位，关闭 CANoe/VickCAN |
| 通道被占用（XL 错误） | 关闭 CANoe / VickCAN，或换 `--channel`（4 通道 0-3；VN1630A CH3/4 需 CAN Piggy） |
| `No module named 'can'` / `can.interfaces.vector` 导入失败 | 先进入 skill 根目录，再执行 `.\scripts\setup_env.ps1` |
| pip 只能装出 `can-0.0.0` 或 `python-can 1.5.x` | 不要循环重装；这是包源/镜像问题。停止重试，把当前 pip 源异常报告给用户 |
| 未检测到 Vector 硬件 | 用 `can_init.py --check` 确认；LIN 项目检测 CANviex/F1L1，`xw.detect(3)>0` 即执行 F1L1 原生 DLL；只有 CANoe/VickCAN 和 CANviex/F1L1 都明确不存在时才允许直接输出，硬件路径失败则如实 BLOCKED |
| 两个盒子同时连接，连错设备 | 用 `--serial <序列号>` 指定；`can_init.py --check` 可查看 VN1630A / VN1640A 各自的序列号 |
| `Python 不是 64 位` | 安装 64 位 Python 3.10+ 后重跑 `setup_env.ps1` |
| `zipfile.BadZipFile` | 调查表文件损坏或加密，要求用户提供无密码/解密副本 |
| 生成器拒绝生成（关键CAN参数使用默认值） | 调查表缺少 TX/RX CAN ID 或波特率。向用户展示缺失参数表格，获取确认后使用 `--confirmed` 重新生成 |
| `0x27` 正例全部 BLOCKED | 密钥文件为全 0xFF 占位或未配置 DLL/密钥文件。先 `seedkey_gen2.py --check` 确认密钥；真实密钥需主机厂/供应商提供 |
| 总线 0 帧 / 无 TX 回显（F1L1 LIN） | 先查 `outputV=1`（LIN 收发器供电）、VickCAN/CANoe 占用、调度表是否含 0x3D；见 `references/f1l1-lin-uds.md` |
| `setup_env.ps1` 不存在 / `SKILL.md` 缺失 | 技能目录不完整。不要手工补目录或补文件，重新获取完整的 `uds-diagnostic-test` 目录 |

## 会话初始化

每次开始任务前，只做这一段（PowerShell）：

```powershell
$envMap = @{}
if (Test-Path "$env:USERPROFILE\.uds_env") {
  Get-Content "$env:USERPROFILE\.uds_env" | ForEach-Object {
    if ($_ -match '^([^=]+)=(.*)$') { $envMap[$matches[1]] = $matches[2] }
  }
}
$env:UDS_PYTHON    = if ($envMap['UDS_PYTHON'])    { $envMap['UDS_PYTHON'] }    else { Join-Path $env:USERPROFILE '.uds_venv\Scripts\python.exe' }
$env:UDS_SKILL_DIR = if ($envMap['UDS_SKILL_DIR']) { $envMap['UDS_SKILL_DIR'] } else { (Get-Location).Path }
$env:UDS_WORK      = if ($envMap['UDS_WORK'])      { $envMap['UDS_WORK'] }      else { Join-Path $env:USERPROFILE '.uds_workspace' }
New-Item -ItemType Directory -Force -Path $env:UDS_WORK | Out-Null
if (-not (Test-Path $env:UDS_PYTHON)) {
  Write-Error "[ERROR] UDS_PYTHON 无效: $env:UDS_PYTHON。请先执行 .\scripts\setup_env.ps1"
  exit 1
}
```

## 标准流程

### 1. 环境准备

前提：当前目录必须是包含 `SKILL.md` 和 `scripts/` 的 `uds-diagnostic-test` 目录。

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup_env.ps1
```

### 2. 解析调查表

```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_survey_parser.py" `
  --input "<调查表文件路径>" `
  --output "$env:UDS_WORK\uds_parsed.json"
```

> LIN 项目额外解析 LDF（对应 CAN 的 DBC）：
> ```powershell
> & $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\ldf_parser.py" --input "<cluster.ldf>" --output "$env:UDS_WORK\lin_db.json"
> ```
> 产物 `lin_db.json` 提供帧 ID/PID/信号偏移/调度表，用于核对用例的 LIN 帧级步骤与调度时隙，避免把 LIN 当 CAN 用（无 DLC、长度查 LDF）。

然后读取 `$env:UDS_WORK\uds_parsed.json`，检查以下三项并展示给用户：

- `can_config`: 调查表中的 CAN 配置（TX/RX ID、波特率、CAN FD 等）
- `defaults_used`: 使用了默认值的 DID/IO/Routine 字段
- `missing_attributes`: 调查表中完全缺失的属性

### 2a. 解析缓存（v3.9.2 新增，重复解析对策）

Excel/LDF/SDDB/PDF 在多阶段与多会话中**禁止重复全量解析**：用 `scripts/parse_cache.py`
的 `cached_parse` 包住解析器，键 = 源文件 SHA-256 + 解析器版本（文件变/解析器升级自动失效）：

```python
from parse_cache import cached_parse
model, meta = cached_parse("BBS1LIN.ldf", parse_ldf, parser_name="ldf_parser", parser_version="1.0")
```

- 解析逻辑变更时**必须递增 parser_version**（旧缓存自动失效，防污染）；
- 缓存 JSON 含溯源头（源哈希/解析器版本/时间），位于源文件旁 `.parse_cache/`；
- **上下文压缩对策**：解析产物落盘即单一事实源——长会话压缩或换会话后，需求一律从盘上
  缓存/需求索引文件恢复（键含源哈希，文件未变即有效），不依赖对话记忆；配合输入
  manifest（路径+sha256）可无损续跑。

### 2b. 帧结构口径（v3.9.2，CAN/LIN 防混用）

涉及帧级判读/抽查/审计时**禁止手写偏移**：一律用 `scripts/tp_layout.py` 的
`parse_tp_frame`（返回 type/payload_off/sid_off）与 `find_sid`（SID 子功能检索）。
核心差异：LIN TP 有 NAD（d[0]）→ 偏移全体 +1，FF PCI 2 字节 → SID@d[3]；
CAN TP 无 NAD → FF SID@d[2]。对照速查与事故记录：`references/lin-can-tp-offsets.md`。

### 2.5 强制确认（阻断点）



在生成脚本之前，必须执行以下检查，缺一不可：

1. 如果 `can_config` 缺少 `tx_id`、`rx_id` 或 `bitrate`，**必须**询问用户提供真实值
2. 如果 `defaults_used` 非空，**必须**以表格展示给用户确认
3. 如果 `missing_attributes` 非空，**必须**告知用户哪些属性缺失

确认表格必须包含：

| 参数 | 调查表值 | 将使用的值 | 来源 |
|------|---------|-----------|------|
| TX CAN ID | 0x671 / 缺失 | 0x7E0 | 调查表 / 硬编码默认 |
| RX CAN ID | 0x679 / 缺失 | 0x7E8 | 调查表 / 硬编码默认 |
| Vector 通道 | 0 / 缺失 | 0 | 调查表 / 默认（4 通道 0-3；VN1630A CH3/4 需 CAN Piggy） |
| Vector 设备 | 自动 / 缺失 | 自动 | 多盒子时用 `--serial` 指定 VN1630A / VN1640A |
| CAN FD | Y/N / 未指定 | Classic CAN | 调查表 / 默认 |
| 仲裁域波特率 | 500000 / 未指定 | 500000 | 调查表 / 硬编码默认 |
| CAN FD 数据段波特率 | 2000000 / 未指定 | 2000000 | 调查表 / 默认 |
| 是否需要 $27 | Y/N | Y/N | 调查表 |
| 安全日志输出 | 路径 / 无 | 路径 / 无 | 调查表 |

用户明确确认后，生成命令必须带上 `--confirmed` 标志。未确认禁止跳过此步骤直接生成。

### 3. 生成脚本

**生成路径选择（默认 = 1:1 逐用例脚本）**：
- 有设计用例（`--cases`）：默认走「用例 ↔ 脚本 一一对应（铁律，v3.7）」的 `gen-scripts`，产出逐用例脚本 `case_scripts/` + `manifest.json` + `run_all.py`，**这是正式全量执行的唯一路径**。
- 无 `--cases`：下方 `uds_test_generator.py` 产出代表脚本 `uds_test.py`，仅用于 CAN 代表脚本冒烟 / 链路探测兜底，**不是**正式全量执行路径。
- `project` 已按上述规则自动选择（提供 `--cases` 即 1:1）；两条路径的产物都必须过「生成后脚本审查」门禁。

### 项目配置化

`project_config.json` 是用例设计、门禁和脚本生成共享的配置契约。用例来源于其它项目时，
建议在所有相关命令中传入同一份 `--project-config`：

```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_runner.py" gen-scripts `
  --cases "<设计用例.json>" --parsed "<uds_parsed.json>" `
  --project-config "<项目配置.json>" --project-context "<project_context.json>" `
  --bus lin --out-dir "<case_scripts>"
```

配置模板为 `skills/project_config.example.json`。不传配置时保留历史兼容默认值；
新项目应显式配置物理/功能 NAD、会话 ID/名称/跳转矩阵/S3、0x27 等级会话、安全保护服务、
非法子功能 NRC，以及探针 DID、代表性写入 DID 和写入 DID 数量。探针 DID、安全常量 DID、
代表性写入 DID 不适用时使用 `null` 或 `{}`；安全常量键使用连续字节格式，例如 `0x0506`；
`max_write_dids: null` 表示生成全部 DID。
未配置 `unsupported_did` 时，未支持 DID 负例会标为待项目确认，不擅自沿用示例 DID。

```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_test_generator.py" `
  --input "$env:UDS_WORK\uds_parsed.json" `
  --output "$env:UDS_WORK\uds_test.py" `
  --confirmed

& $env:UDS_PYTHON -m py_compile "$env:UDS_WORK\uds_test.py"
```

### 3b. 生成后脚本审查（强制门禁，差分审查 v2）

生成成功不等于脚本正确。执行硬件前必须对生成脚本做离线审查；审查器不导入
执行脚本、不打开 Vector/CANviex，也不向 ECU 发送报文。**审查与生成不是
同一套推导逻辑**（差分审查）：审查器不再复用 `gen_case_scripts` 的"需求→
期望"推导函数，而是由独立真值层 `scripts/review_truth.py` 提供第二套实现：

- **防漂移层**：从需求文本（procedure/precondition/expected/test_point）用
  独立实现提取证据候选集，脚本最终常量（PAYLOAD/SESSION/PRE_ACTIONS/EXPECT）
  必须命中证据，防止"脚本生成成功但请求/期望已漂移"进入硬件执行和 FAIL
  统计；blocked/needs_data/timing/skip 用例不产生可判定结果，跳过证据检查；
- **协议真值层**（ISO 14229 不变量，独立于需求文本）：合法请求 SID、
  正响应 SID = 请求 SID + 0x40、负响应帧 `7F <请求SID> <NRC>` 的 SID 一致、
  NRC 值域 0x10~0x7F；
- **项目数据层**：与 `uds_parsed.json` 交叉校验（DID/RID 存在性、0x2E 写入
  正例与只读 DID 冲突），parsed 缺失 DID/Routine 数据时不阻断。

同时保留原有结构审查：
- 每条需求用例与唯一脚本、`manifest.json` 双向映射，数量相等且无孤儿；
- `py_compile`、`run_all.py` 和代表脚本语法有效；
- 必需元数据常量存在、统一 CAN 配置（通道/波特率/TX/RX/序列号/CAN FD）一致；
- 需求未明确正/负/无响应、参数仍为占位或会话/寻址存在歧义时标
  `REVIEW_REQUIRED`，不得进入正式 FAIL/BLOCKED 统计；
- 缺少真实 0x27 密钥只允许对应 0x27 用例标 `BLOCKED`，不能扩散到其他服务。

独立运行：

```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_runner.py" script-review `
  --cases "<设计用例.json>" --parsed "<uds_parsed.json>" `
  --scripts-dir "<case_scripts>" --script "<uds_test.py>" `
  --bus lin --project-config "<项目配置.json>" --out "<script_review.json>"
```

退出码 `0=通过`、`2=脚本/映射/协议元数据错误`、`3=需要人工复核`。`project`
会自动执行同一审查；审查不通过时不做硬件预检、不执行全量用例、不生成正式测试统计。
`project`/`script-review` 支持两个分级开关（2026-09-03 反馈落地，默认维持既有行为）：
- `--review-policy block|report`（默认 `block`）：歧义/待确认 `REVIEW_REQUIRED` 默认整轮阻断；`report` 只输出待人工确认清单、不阻断轮次，ERROR（退出码 2）任何策略都阻断。治"深而疑用例卡死整轮导致设计者自我删减"的副作用；
- `--depth-policy report|block`（默认 `report`）：`scripts/review_depth.py` 输出**深度完备性核对表**（每服务已测对象/正反成对/子功能/目标会话 + 缺口 gaps，如 "DID F190 有正例无负例"、"0x31 RID 0206 结果读取无启动来源"、"0x10 仅覆盖单一非默认目标"），治"浅而一致全绿"盲区；`block` 时缺口升级为 REVIEW_REQUIRED（退出码 3）。

### 4. 硬件检测与执行策略（强制门禁）

```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\can_init.py" --check
```

**执行前预检（推荐，取代仅 --check）**：后端 + 进程占用（VickCAN/CANoe）+ 通道列表一次完成：
```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\can_init.py" --preflight
# 或经执行器：& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_runner.py" preflight
```
> 实测：VickCAN.exe 后台运行会让所有收发 0 帧；CANoe 未彻底退出会占用 Vector 总线。预检检测到占用进程必须先关闭。

**直接输出仅在三类硬件探测全部成功且均为 0 时允许**：CANoe/VickCAN 占用进程、CANviex/F1L1、Vector XL 设备；任一类探测失败或未知一律按“存在硬件”处理，强制进入硬件执行路径，不再提供无硬件可跳过的 generate-only 模式。

硬件连接且未被占用时：

```powershell
& $env:UDS_PYTHON "$env:UDS_WORK\uds_test.py" --test-connection
```

### 5. 执行测试

```powershell
& $env:UDS_PYTHON "$env:UDS_WORK\uds_test.py" `
  --report "$env:UDS_WORK\uds_report.md" `
  --can-log "$env:UDS_WORK\can_trace_$(Get-Date -Format yyyyMMdd_HHmmss).asc"
```

### 5b. ASC 证据链自动采集与历史日志导入（v3.10）

正式执行的用例**必须自动产出 ASC 标准证据**。`trace_begin()` 默认在收到**首个真实硬件帧**时创建 `traces/SWDL/loop_YYYYMMDD_HHMMSS/part01.asc`，此后每帧追加并 flush；单个分片达到 100 MiB 自动切换 `partNN.asc`。`trace_flush()` 继续生成 trace JSON/传统 ASC，并收尾 `runlog_part01.txt` 与 `loop_rounds.csv`。调用方可传 `session_id` 将同一 SWDL 轮次归入同一目录。已有 ASC 或文本 XCT 则只做离线回读，不能替代本次执行取证。组件化两件套（单文件可移植、不绑定项目）：
`scripts/asc_evidence.py`（转写）+ `scripts/trace_env_mixin.py`（编排，混入即得）：

```python
class MyEnv(EvidenceTraceMixin):
    def open(self):  ...; self.trace_begin(); return ok
    def close(self): self.trace_flush(result_file="results/result_%s.json" % self.case_id); ...
```

红线与细则（真实性保证/溯源对账/探针隔离/DLP 特性/坑清单）**只维护一份**：
`references/asc-evidence-pipeline.md`。环境封装类必须混入 EvidenceTraceMixin，禁止手写捕获编排。

### 结果分类（v3.2 新增）
执行结果状态统一为 **PASS / FAIL / NA / BLOCKED / SKIP**：
- **BLOCKED**：前置条件不满足（如 0x27 密钥为占位 0xFF、无有效 SeedKey DLL/密钥文件），不是测试失败，报告单独列出「阻塞用例详情」，通过率排除 NA/BLOCKED；
- **NA**：条件受限（如只读 DID 读取、需解锁的 DID 当前密钥状态不允许），按记录判 NA。

### $27 密钥管理（v3.2 新增）
两种解锁路径，优先可用者：
1. **Vector 标准 SeedKey DLL**：`--sa-dll <dll> --sa-variant <变体> --sa-options <选项>`，生成脚本时自动做 DLL 预检（PE 位数 / 同目录常见依赖 / 接口签名；VickCAN 自定义接口如 `volvo_27_XX_hstreq/devrsp` 会明确报「非 Vector 标准接口」并提示替代方案）；
2. **纯 Python Gen2 密钥文件**：`--sa-key-file <VolvoKey.json>`（字段 `aes_cmac_key_0102 / aes_ctr_key_0102 / aes_cmac_key_0506 / aes_ctr_key_0506`，16B hex）。字段名**大小写不敏感**，兼容 VolvoKey.json 原始大写（`AES_cmac_key_0102` 等），也接受别名 `cmac_0102 / ctr_0102 / key_cmac_0102`。密钥全 0xFF → 默认按占位处理（`ready=False`，0x27 正例标 **BLOCKED** 而非 FAIL）；**例外（v3.9 实测修正）**：全 FF 也可能是样件约定密钥本身（本项目 27 Gen2 双组解锁用全 FF 密钥计算 PASS，经用户确认），遇全 FF 密钥材料必须**请用户确认口径**后再定 BLOCKED 或执行，确认结论写入证据链登记，不得自行判定。单独预校验：
   ```powershell
   & $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\seedkey_gen2.py" --check <VolvoKey.json>
   ```
> 红线：模块不硬编码任何密钥；真实密钥由主机厂/供应商提供后填入项目本地 JSON。

### 会话状态机（v3.2 新增，生成脚本内建）
生成脚本的 TestRunner 已内建 `ensure_session`（先回项目默认会话再切目标）/
`confirm_session`（配置的会话探针；未配置时不注入隐式 DID 请求）/ `keep_alive`
（0x3E 保活），解决实测中的会话漂移与 S3 超时误判。

### 0x27 标准编排（v3.8.1 实测固化）
0x27（Gen2/等级制）用例编排遵循以下防护语义，细则见
`references/nrc-troubleshooting.md`「0x27 延迟窗口与种子生命周期标准编排」与
`references/security-key-mechanism.md` §5/§9：

- **跨延迟窗口**：触发延迟后在当前会话内 0x3E 80 周期保活等窗口到期再请求；纯等待掉 S3（0x7F）、重进会话重新武装窗口，两者都无法跨窗；
- **种子配对**：有效 sendKey 配对最后一次被 ECU 接受的种子；过期/作废种子按 0x24 预期（防重放）；
- **违规后作废**：频次/延迟违规后未使用种子全部作废（旧种子 sendKey → 0x24），解锁恢复 = 跨窗后重新请求种子再 sendKey；
- **探测前置**：内容校验类探测（篡改/越界参数）先跨窗再发探测帧，使判定命中内容校验层（0x31/0x22）而非被 0x37 挡在门外；
- **sendKey 子功能 = seed 子功能 + 1**；响应长度规格按字段累加 + 逐帧抓帧确认（如 Gen2 seed 响应 68B）；随机性统计判据按样本量换算置信区间（§9）。

### LIN / F1L1 路线（v3.2 新增）
Vector 路线之外，`scripts/f1l1_uds.py` 提供 F1L1 (CANviex) UDS-over-LIN 引擎（完整 LIN TP 多帧收发 + 0x78 pending），实测排障要点见 `references/f1l1-lin-uds.md`（outputV=1 / 0x3D 帧头应答 / PCI 长度 / 多帧逐帧 TX 回显确认 / _drain 保护 / 结构体对齐）。

### 高实时时序测量（v3.6 新增：采集-后处理，COM/上位机路径已舍弃）
上位机/COM 逐条测量会混入 PC 往返延迟，P2=50ms 这类高实时指标测不准（该路径已舍弃，禁止用于测试执行）。统一用**连续采集轨迹 + 离线分析**：
```powershell
# LIN（F1L1）
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\timing_trace.py" --bus lin --duration 10 --out timing_report.md
# CAN（Vector）
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\timing_trace.py" --bus can --channel 0 --tx-id 0x7E0 --rx-id 0x7E8 --bitrate 500000 --duration 10
# 或经执行器：uds_runner.py timing --bus lin ...
```
输出帧隙 / P2 / P2*（含 0x78 pending）/ 0x37 延迟，并自动告警（帧隙抖动 >5ms、P2>50ms）。计时用 `perf_counter + timeBeginPeriod(1)`（毫秒级），采集期间不要开上位机。路径选择见 `references/test-path-guide.md`（COM/上位机已舍弃）。

## 何时使用 pipeline

只有在用户明确要求"直接生成并执行，不需要中间确认"时，才使用：

```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_runner.py" pipeline `
  --input "<调查表文件路径>" `
  --output-dir "$env:UDS_WORK\pipeline_output"
```

默认不要直接走 pipeline。默认流程始终是：解析 → 用户确认（阻断点）→ 生成（带 `--confirmed`）→ 生成后脚本审查 → 硬件执行资格判断 → 硬件预检/链路探测 → 按服务最小硬件复测 → 全量执行。

## 一键项目编排 project（v3.4 推荐，含执行前门禁）

`uds_runner.py project` 把「解析调查表 → 解析 LDF → 用例审计 → 规则 lint → 生成脚本 → **生成后脚本审查** → 硬件预检 → **链路通探测** → 执行 → 报告/错误日志 → 覆盖率(可选)」串成一条命令。审计生成的 `cases_filled_*.json` 会统一作为 lint、逐用例脚本和覆盖率输入；任一门禁不过即中止，执行阶段的失败会在报告完成后通过最终退出码传播：

```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_runner.py" project `
  --input "<调查表文件或目录>" `
  --output-dir "$env:UDS_WORK\project_output" `
  --ldf "<cluster.ldf>" `
  --cases "<设计用例.json>" `
  --srs "<srs.txt>" `
  --project-config "<项目配置.json>" `
  --ro-dids "<DID列表>" `
  --sa-session-map "<等级>:<会话>" `
  --bus lin --nad <物理NAD> --brval <LIN波特率> `
  --sa-key-file "<VolvoKey.json>"
```

其中 `--ldf`、`--cases`、`--srs`、`--ro-dids`、`--sa-session-map` 和 `--sa-key-file` 均为可选参数；
LIN 项目未显式传入 `--nad` 时使用项目配置中的 `transport.physical_nad`，未显式传入 `--brval` 时使用 19200。

> **全量执行（用例↔脚本一一对应）**：提供 `--cases` 即默认按设计用例清单生成每用例唯一脚本（`case_scripts/`），跳过代表脚本直接 `run_all` 全量执行，渲染 HTML 报告（`report_*.html`，含可筛选/搜索的用例明细）并生成错误处理日志（`error_handling_log.md` + `error_journal.jsonl`）：
> ```powershell
> & $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_runner.py" project `
>   --input "<调查表或目录>" `
>   --output-dir "<输出>" `
>   --ldf "<cluster.ldf>" `
>   --cases "<设计用例.json>" `
>   --bus lin --project-config "<项目配置.json>" `
>   --sa-key-file "<项目Key.json>"
> ```
> 占位参数用例（needs_data）执行时如实标 BLOCKED（参数待补），时序类走 timing 测量，不编造。

门禁说明（实测固化 [16][17][24]）：
- **硬件预检**：后端 + VickCAN/CANoe 进程占用 + 通道列表（`can_init.py --preflight`）；
- **链路通探测**：`link_check.py` 先确认「总线有活动 + ECU 0x3E 应答」再执行——通道未映射/无供电/outputV=0 时直接中止，避免整轮假失败；
- **最小硬件复测**：脚本审查通过、链路连通后，每个可执行服务先抽取 1 条用例硬件复测；任何新结果不是 PASS 都阻断 1:1 全量执行，输出 `hardware_smoke_*.json`；仅有 BLOCKED/timing 的服务不伪造冒烟用例；
- **用例审计与规则 lint**：先由 `steps_generator.py` 生成 `cases_filled_*.json`，再由 `case_lint.py` 检查 R1~R5；0x27 缺少真实 Key 的正确解锁用例保持 `BLOCKED`，不伪造 PASS；
- **生成后脚本审查**：`script_review.py` 重新解析需求并比对实际脚本常量、NAD/PCI、响应/NRC、会话和 manifest；`ERROR` 或 `REVIEW_REQUIRED` 均阻断后续硬件路径；
- **执行后处理**：`run_all.py` 返回失败时仍继续生成 `report_*.html`、错误处理日志和覆盖率，最后以综合退出码报告本轮失败；
- 单独使用：`uds_runner.py link-check --bus can --channel 0 --tx-id 0x7E0 --rx-id 0x7E8 --bitrate 500000` 或 `--bus lin --nad 0x51`。

## 用例 ↔ 脚本 一一对应（铁律，v3.7，正式执行默认路径）

设计清单中的**每一条用例都必须有唯一可执行脚本**：脚本总数 = 用例总数，用例 ID ↔ 脚本文件双向映射、不漏不重。禁止只生成代表用例脚本、禁止一条脚本对应多条用例。**有 `--cases` 时正式执行一律走本路径（`gen-scripts`），`uds_test.py` 代表脚本仅作无 `--cases` 的 CAN 冒烟兜底。**

```powershell
& $env:UDS_PYTHON "$env:UDS_SKILL_DIR\scripts\uds_runner.py" gen-scripts `
  --cases "<设计用例.json>" --parsed "<uds_parsed.json>" --bus lin --out-dir ".\case_scripts" `
  --project-config "<项目配置.json>" --project-context "<project_context.json>" `
  [--sa-key-file "<项目Key.json>"]
```

产出：`case_<用例ID>.py`（每用例一个）+ `manifest.json`（双向映射及 project_context 绑定摘要）+ `run_all.py`（顺序执行全部并汇总 `results_all.json`）。
带绑定的 `run_all.py` 会在清理旧结果和执行用例前校验 context SHA-256；context 缺失或发生变化时阻断执行。
每条脚本状态如实标注，不编造：

| 状态 | 含义 |
|---|---|
| executable | procedure 含具体请求 hex，可直接执行（PASS/FAIL/NA 按实测判定） |
| needs_data | 请求含占位参数（"+ 参数"等无长度），执行返回 BLOCKED（参数待补），不硬造；**显式长度（"+ N字节数据"）自动填充 N×0x00；例程（0x31）按调查表 Control Routine 的 Request 长度自动补全（`--survey`，无参数例程直接可执行）**，均标注「内容执行前确认」 |
| timing | TimeParm 时序测量类，走 `timing_trace.py` 采集-后处理 |
| blocked | 0x27/刷写/需授权/密钥占位，前置满足前标 BLOCKED |

交付前核对 manifest：无孤儿脚本、无漏脚本用例。

生成后必须执行 `script_review.py`；不能以“脚本已经生成”替代审查，也不能把审查失败转换为用例 `FAIL` 或 `BLOCKED`。

## 直接输出条件

只有在执行前同时确认没有 CANoe/VickCAN 等占用进程、且 CANviex/F1L1 设备数量为 0 时，才可以在生成脚本后直接输出设计产物；不能由调用方通过参数跳过该门禁。只要检测到任一项，必须进行硬件预检、链路探测和硬件执行。

## 对外接口约定（供后续 skill 适配）

后续开发的 skill 与本技能集成时，按以下稳定接口对接：

- 环境文件：`%USERPROFILE%\.uds_env`（key=value：`UDS_PYTHON` / `UDS_SKILL_DIR` / `UDS_WORK`）
- 解析器输出：`uds_parsed.json`（含 `can_config` / `defaults_used` / `missing_attributes` / `dids` / `dtcs` / `io_controls` / `routines` / `security_access`）
- 生成器 CLI：`uds_test_generator.py --input <parsed.json> --output <test.py> [--channel N --serial <序列号> --bitrate N --can-fd --sa-dll <dll> ...]`
- 执行器 CLI：`uds_runner.py {parse|generate|run|pipeline|project|gen-scripts|script-review|expectation-check|link-check|timing|preflight|sddb-extract|error-log|swdl} ... [--serial <序列号>]`；常规执行退出码 0=成功、1=运行失败，`case_lint`/`expectation-check`/`script-review` 等门禁命令按各自约定返回 2/3；`project` 不再接受 `--generate-only` 或 `--case-exec`
- 预检 CLI：`can_init.py --preflight` / `uds_runner.py preflight`（后端 + 进程占用 + 通道）
- 密钥预检：`seedkey_gen2.py --check <key.json>`（退出码 0=就绪，2=未就绪）
- LIN 引擎：`f1l1_uds.py`（`F1L1_XCWRAPPER_DIR` 指定 xcdev_wrapper 目录）
- LDF 解析：`ldf_parser.py --input <cluster.ldf> --output <lin_db.json>`（PID/信号/调度表/节点属性，无第三方依赖）
- 用例↔脚本一一对应：`gen_case_scripts.py` / `uds_runner.py gen-scripts`（每用例唯一脚本 + manifest + run_all；状态 executable/needs_data/timing/blocked 如实标注，不编造；CAN 项目由 `project` 自动传入代表脚本作为运行时）
- 用例规则 lint：`case_lint.py --cases <cases_filled.json> --project-config <项目配置.json> [--disable-rule R5] --out lint.md`
- 生成后脚本审查：`script_review.py --cases <cases.json> --parsed <uds_parsed.json> --scripts-dir <case_scripts> [--script <uds_test.py>] --out script_review.json`（差分审查：独立真值层 `review_truth.py`，不 import 生成器推导函数；单测 `test_review_truth.py`）
- LIN TP 单测：`test_lin_tp.py`（离线，PID/校验和/SF/FF+CF 多帧/0x78/坏序号回归，脱离硬件）
- NRC 查询：`nrc_guide.py <NRC>`（如 `0x37`）或 `--list`；知识库见 `references/nrc-troubleshooting.md`
- 一致性判定：`consistency_check.py --reports run1.md run2.md run3.md --rule 3/3`（不稳定项标 NA/重测，不混判 FAIL）
- 高实时时序：`timing_trace.py --bus lin|can --duration N [--out x.md]`（采集-后处理：帧隙/P2/P2*/0x37）
- 报告页：`report_to_html.py --results exec_results.json [--extra extra.json] --out report.html`（执行结果 → 单文件 HTML 页面，展示框架固定复用 `templates/uds_report_framework.html`；保留原始 Hero、版本时间轴、报告头、模块导航、覆盖率/时序卡片、阻塞清单、关键参数、服务分布和用例明细布局，只替换真实数据；按软件版本时间轴切换报告，点击当前版本内的模块页签切换测试块；网络安全及后续模块归入同一版本报告，离线可用。`meta` 可选传入 `version`、`test_time`、`notice`、`flag`；`versions[]` 表示软件版本时间轴，`modules[]` 表示当前版本的报告模块；设计规范见插件根目录 `DESIGN.md`）
- 错误处理日志：`error_log.py` / `uds_runner.py error-log`（非 PASS 用例归纳为 检测→分类→处置→状态 流程，输出 error_handling_log.json/.md，可追加 journal 累积每一次执行；`project` 全量执行自动生成）
- RSA-4096 刷写签名（开发测试用）：`rsa_4096.py sign/verify/check-key/parse-json`（RSASSA-PSS/SHA-256，盐长 32，依据 SWRS 4.2.3.8/4.2.3.9；`check-key` 可校验私钥与 VolvoKey.json 公钥一致；工具本身不携带任何密钥）
- 产物约定：`uds_test.py` / `uds_report.md` / `can_trace_*.asc`（CANoe/CANalyzer 兼容）

## 详细资料

以下内容统一放在 `README.md` 和 `references/`：

- Vector 驱动安装（XL Driver Library）、64 位要求、通道占用处理
- CAN FD 配置、SeedKey DLL（$27 SecurityAccess，Vector 标准接口，64 位）
- NRC 说明、调查表属性默认值表
- `references/VickCAN-help-重点.md` —— VickCAN 总线工具帮助文档**精简文字版**（概述/硬件支持/界面操作/程序刷写/诊断控件/数据文件/操作专题，由 15MB 含截图 HTML 提取，操作步骤文字完整）。需要 CAN 报文收发、记录回放、LIN 调度表、UDS 诊断请求、DLL 调用等操作指引时查阅；界面截图请参考 VickCAN 软件；注意执行测试前必须关闭 VickCAN 释放通道
- `references/f1l1-lin-uds.md` —— **F1L1 UDS-over-LIN 实测排障要点**（outputV 供电/0x3D 应答/PCI 长度/多帧 TX 回显/会话保活/密钥占位），使用 `f1l1_uds.py` 前必读
- `references/lin-protocol-cheatsheet.md` —— **LIN 总线协议重点速查**（帧结构/PID 奇偶/经典与增强校验和/帧类型/调度表/休眠唤醒/物理层参数/传输层 PDU/配置识别诊断服务/LDF 关键字），由《LIN 规范 V1.2》+《LIN 入门(LIN2.1)》提炼并经 LIN 2.2 LDF 实测核对，头部含 **LIN 2.2 对齐要点表**；涉及 LIN 帧/信号/调度/传输层/应用层细节时查阅；**与主机厂规范或项目 LDF 冲突时以项目资料为准**
- `references/iso-tp-cheatsheet.md` —— **ISO-TP 多帧传输细节速查**（SF/FF/CF/FC 与 PCI 编码、经典 CAN vs CAN FD 边界、BS/STmin 编码、N_As/N_Bs/N_Cs/N_Cr 网络层时序、CAN ID 物理/功能寻址、与 LIN TP 对照、测试要点），写多帧报文级步骤、抓包分析或流控/超时排障时查阅
- `references/lin-test-methodology.md` —— **LIN 通信测试方法论**（帧结构/PID 与校验和错误注入/信号打包/调度表/从机无响应/休眠唤醒/波特率同步/UDS-over-LIN 传输层/配置识别服务/结果判定），设计 LIN 通信测试用例时对照
- `references/nrc-troubleshooting.md` —— **NRC → 根因 → 处置速查**（含 0x27 专属排查链、补充 NRC、UDS 服务会话矩阵、通用安全等级表、诊断调查表关键属性清单；已合并旧 uds_nrc_reference.md），看到 NRC 先查本表再怀疑 ECU
- `references/test-path-guide.md` —— **测试路径选择指南**（自动化只走设备原生 DLL / Vector；**COM/上位机串口路径已舍弃**，禁止用于测试执行；高实时用例必须采集-后处理）
- `references/security-key-mechanism.md` —— **0x27 密钥机制（BBS 示例项目 SWRS 依据）**：Gen2 密钥结构与 VolvoKey.json 字段对照、密钥来源与初始全 0xFF、0x2E 编程格式（双 AES+CRC16-CCITT）、示例项目等级→DID 表（01→F103、05→F10A，仅供参考）、延迟参数、D09B 密钥状态探针、RSA-4096 签名；新项目以自身 SRS/项目配置为准
