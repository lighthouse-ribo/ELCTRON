# 0x27 安全访问密钥机制（SWRS 依据）

> 来源：NOTE-SWRS-34088390-01-15（BBS）4.2.8 Vehicle Cybersecurity、4.2.8.4 Security Access Generation2、4.2.3.8/4.2.3.9 RSA 签名，以及 REQ-894xx 系列。用于核对密钥来源/格式/编程方式，指导 0x27 阻塞的恢复路径。

## 1. Gen2 算法与密钥结构（authentication method 0x0001）

- 算法：**AES-128-CTR**（加解密，REQ-89413）+ **AES-128-CMAC**（认证，REQ-89412），NIST SP 800-38A / FIPS 197。
- 消息结构（REQ-89414）：clientRequestSeed / serverResponseSeed / clientSendKey / serverResponseKey，含 `iv[16] + encrypted_data_record + authentication_data`。
- **每个安全等级两把 AES-128 密钥**（REQ-89425）：
  - **proof of ownership key**（所有权证明）→ VolvoKey.json 的 `AES_cmac_key_xxxx`
  - **encryption and authentication key**（加密认证）→ VolvoKey.json 的 `AES_ctr_key_xxxx`

> 命名对照：SWRS 用概念名，VolvoKey.json/CAPL 用 `AES_cmac_key_0102/0506`、`AES_ctr_key_0102/0506`，同一物。解析器（`seedkey_gen2.py` / `uds_test_generator.py` 内嵌同款）字段名**大小写不敏感**，也接受 `cmac_0102 / ctr_0102 / key_cmac_0102` 等别名，可直接读取原始大写字段。

**报文长度规格 = 字段累加（不凭记忆记总数）**：例 serverResponseSeed = `67 level 00 02`(4B) + iv16 + EDR32 + auth16 = **68B**；任何报文长度规格都按「字段累加计算 + 逐帧抓帧复核」双重确认后再固化为测试常量。

**sendKey 子功能 = seed 子功能 + 1**（01→02、05→06）：构造 sendKey 请求时填的是 key 子功能字节，不是 seed 等级；两值混用会被 ECU 固定长度校验先拦截（0x13），到不了密钥校验层。

## 2. 密钥来源与初始值（解释“全 0xFF”）

- **密钥由 OEM 提供**，在 Global Master Reference Database 生成并导出给 ECU 供应商；供应商不得自选（REQ-89427）。
- **初始密钥数据记录默认全 0xFF**（除非项目另行约定）——VolvoKey.json 4 个 AES 全 `FF…FF` 即此默认值，**不是“忘填”**。
- 生产密钥最迟在 **vehicle prototype 里程碑**前编程完成（REQ-89427 Note）。

## 3. 密钥编程（0x2E 写 DID，写一次）

- 方式：`writeDataByIdentifier` 0x2E，在已解锁的对应安全等级下执行（REQ-89426）。
- 格式（REQ-89428）：**两个 AES-128 密钥（32 字节）拼接 + CRC16-CCITT（2 字节）**。
  - CRC16-CCITT：初值 **0xFFFF**，多项式 **0x1021**，正常表示。
  - ECU 校验 CRC 通过后才存入 NVM；DID **不可读**。
- 一次性可编程（OTP），无法回退；重复写返回条件不满足（0x22），CRC 失败返回 0x31（REQ-89428）。

## 4. 等级 → DID 映射（REQ-89433 / REQ-90173）

| Security Access Level（requestSeed） | 用途 | 写密钥 DID |
|---|---|---|
| 01 | 编程会话诊断服务（如软件下载） | **0xF103**（Security Constant Level 01/02） |
| 03 | Car mode transition | 0xF109 |
| 05 | 扩展会话诊断（OEM 默认，无需修车厂） | **0xF10A**（Security Constant Level 05/06） |
| 11 | Immobilizer / 防盗 | 0xF10B |
| 15 / 17 | Central Diagnostic gateway | 0xF10C / 0xF10D |
| 1B | Third party partner function | 0xF10E |

- Security Constant（F103/F10A）**任何诊断会话都不可读**（REQ-90173）；写一次，仅编程会话/对应等级。
- 会话归属（REQ-90448）：requestSeed 01/02 仅 **programmingSession**（主/次 bootloader）；03~41（sendKey 04~42）仅 **extendedDiagnosticSession**。

## 5. 延迟与失败参数（0x37 依据）

- 错误尝试触发延迟：**10 秒**；
- 每次启动（boot）延迟：**5 秒**；
- 触发延迟前的错误次数：**2 次**。
（与 BBS 实测完全一致：等级 01 连续请求 → 0x37。）

**窗口武装语义（实测固化）**：
- 延迟窗口由「进入对应会话」的动作武装——错误计数达到阈值后，**每次进入该会话都会重新启动完整延迟窗口**；
- 窗口跨 0x11 复位持续（计数保存在 NVM），且**错误计数按密钥组/等级独立维护**；
- 仅**解锁成功**（sendKey 正响应）清零对应组计数；纯等待、复位、重新请求种子均不清零；
- 跨窗标准做法 = 当前会话内 0x3E 80 周期保活等待窗口到期（编排细则见 `nrc-troubleshooting.md`「0x27 延迟窗口与种子生命周期标准编排」）。

## 6. 密钥状态 DID 0xD09B（“是否已编程”）

- 读 `Security Access Key Status`：每等级返回 `数量 + 等级 + 状态`，0x00=已编程，0x01=未编程（REQ-89429）。
- **BBS 实测**：`22 D0 9B → 62 D0 9B 01 05 01` = 1 个等级、等级 **05**、状态 **01（未编程）**——佐证 ECU 仍在使用初始密钥（0xFF），生产密钥未写入。

## 7. RSA-4096 刷写签名（4.2.3.8 / 4.2.3.9）

- 方案：PKCS#1 v2.2 **RSASSA-PSS**，哈希 **SHA-256**，**盐长 = 哈希长度（32B）**（REQ-89920/89919）。
- 开发私钥：SWRS 4.2.3.9（REQ-137011）明文给出 **RSA-4096 开发私钥**（PKCS#8 PEM）；公钥模数与 VolvoKey.json `RSA_public_key_modulus` 一致。
- 私钥格式：未加密 PKCS#8 PrivateKeyInfo，PEM base64（REQ-89909）；生产签名由 **OEM Trust Centre** 执行。
- 工具：`rsa_4096.py sign/verify/check-key`（开发/测试用）。

## 8. 对测试的意义

1. **0x27 阻塞判定**：VolvoKey.json AES 全 0xFF = SWRS 规定的初始值，而非缺失——真正缺的是 OEM 导出的**生产/开发 AES 密钥**；
2. **恢复路径**：OEM 提供 4 个 AES（0102/0506 cmac+ctr）→ 填入 VolvoKey.json → `seedkey_gen2.py --check` 就绪 → 重跑解锁；或由 OEM 产线用 0x2E 写 F103/F10A（需先解锁对应等级，属 OEM 产线操作）；
3. **不要尝试**：随机生成新 RSA 对或猜测 AES 值（ECU 公钥固定，无法匹配；属破解红线）；
4. **D09B 作为快速探针**：先读 D09B，状态 01=未编程 → 0x27 必锁，不必重复跑 seed/key 试错。

## 9. 随机性统计判据要点（TRNG/随机数用例）

- **Monte Carlo（求 π）单位圆判定**：n 位坐标 x、y ∈ [0, 2ⁿ) 的命中条件是 **x²+y² ≤ 2^(2n)**（半径 = 坐标满量程）；判定常数写小会使误差出现远超统计涨落的系统性偏移——先核对分析脚本判定常数，再怀疑随机源。
- **判据按样本量换算置信区间**：固定阈值（如误差 ≤0.5%）通常基于 MB 级数据；N 组落点时改用 99% 置信上限（2.576 × 4√(p(1−p)/N)/π × 100，p = π/4），结果同时记录实测值、置信上限与 N。
- **扩样验证收敛**：样本量翻倍后误差应同向收敛（如 1.96% → 1.74%）；不收敛即系统性偏差，回查分析脚本而非随机源。
- **长采集会话维持**：同一会话内多次请求种子的采集用例，请求间隔避开 S3 边界；间隔超 S3 时用 0x3E 80 周期保活维持会话。
