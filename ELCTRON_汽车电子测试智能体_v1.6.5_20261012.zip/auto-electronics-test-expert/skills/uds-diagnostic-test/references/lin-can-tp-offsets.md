# CAN / LIN 诊断帧结构对照速查（防混用，v3.9.2 定稿）

> **铁律：判"帧缺失/偏移"前，先用 `scripts/tp_layout.py` 的 `parse_tp_frame`/`find_sid`，
> 禁止手写魔法偏移。** 2026-09-11 实际事故：审计抽查把 CAN-TP 口径用在 LIN 帧上，
> 两轮误报 0x27 认证链帧缺失——帧都在，是解析口径错了。

## 两套口径核心差异

| 维度 | LIN TP (ISO 17987 / LIN 2.x) | CAN TP (ISO 15765-2) |
|---|---|---|
| 帧载体 | **固定 8 字节**，诊断帧 ID **0x3C(主→从)/0x3D(从→主)** | CAN 数据场 ≤8B，**11/29 位 CAN ID** 寻址 |
| **NAD** | **有，在 d[0]** → 所有数据偏移 **+1** | **无**（靠 CAN ID 寻址）→ 偏移从 d[0] 起 |
| SF | `[NAD, 0x0L, SID@d[2], ...]` PCI 1B=L | `[0x0L, SID@d[1], ...]` PCI 1B=L |
| FF | `[NAD, 0x1H, len_lo, SID@d[3], ...]` **PCI 2B**（len_hi 4位+lo 8位=12位长度） | `[0x1H, FF_DL, SID@d[2], ...]`（FF_DL 12 位） |
| CF | `[NAD, 0x2S, data@d[2]...]` seq 从 1 | `[0x2S, data@d[1]...]` seq 从 1 |
| FC | **有，且只由主节点发**：`[NAD, 0x30, BS, STmin, FF…]` 挂在 **0x3C**；从机收到后才续发 CF | `[0x3S, BS, STmin, ...]` 挂在诊断 CAN ID |
| 诊断帧校验和 | **classic**（0x3C/0x3D）；其余 LIN 帧 enhanced | 无（CAN CRC 由控制器处理，ASC 不写 checksum） |

## SID 位置速记

```
LIN:  [NAD][PCI][payload...]      ← 一切从 d[2] 算（FF 因 PCI 2B 从 d[3]）
CAN:  [PCI][payload...]           ← 一切从 d[1] 算（FF 因 FF_DL 从 d[2]）
      差一个 NAD → 同一 SID 偏移 LIN 恒比 CAN 大 1
```

## 常见混淆陷阱（每次都从这里查）

1. **把 LIN FF 的 SID 当 d[4:] 查**：CAN-TP 习惯 `FF_DL` 占 d[1]，LIN 的 FF PCI 也是
   2 字节（0x1H + len_lo）但**没有独立的 FF_DL 字节**——len_lo 就是 PCI 第二字节，
   payload 从 d[3] 起。本次事故根源。
2. **LIN SF 顺手查 d[1]**：那是 PCI 字节，SID 在 d[2]（NAD 在 d[0]）。
3. **CAN FC (0x3X) 当 LIN 帧判**：LIN 的 FC 同样是 PCI 0x3X，但**带 NAD 且挂在 0x3C**（`[NAD, 0x30, BS, STmin, FF…]`）；判帧先看 ID 是不是 0x3C/0x3D，再看 d[0] 是不是 NAD，别只按 PCI 判。
4. **多帧请求的 SID 只在 FF**：CF 里是纯数据，按 seq 顺序拼装后再搜子功能。
5. **调度表帧不是 TP 帧**：LIN 0x3C 全 FF / 空 0x3D 是主节点轮询，`parse_tp_frame`
   返回 `SCHED`，审计统计单独归类，不要当异常帧。
6. **帧 ID 定总线**：0x3C/0x3D 必为 LIN；但 LIN 应用帧（0x00-0x3B）与 CAN 11 位 ID
   数值上重叠——**拿不准就显式传 bus 参数**，不要让 detect_bus 猜。
7. **多帧应答只收到首帧、等不到 CF（最高频坑）**：从机发完 FF 后**必须由主节点补一帧 FC(PCI 0x30)** 才继续发 CF。
   2026-09-14 实机实测（BBS 样例，NAD 0x51）：不发 FC 时 5 s 内 154 帧响应**全是首帧**、0 个 CF → 全部超时；
   补一帧 `51 30 00 00 FF FF FF FF` 后 0.19 s 拼包成功。**"多字节 DID 读不到 ≠ ECU 不支持"**，先看 FF 之后有没有 FC。
   注意兼容性：部分老固件收到请求即自动连发 CF（无需 FC），故 `f1l1_uds.py` 默认路径先给
   `FC_GRACE_MS`（默认 150 ms，可用 `F1L1_FC_GRACE_MS` 覆盖，取 0 = 总是先发 FC）宽限窗口再决定是否补发。

## 抽查/审计脚本标准写法

```python
from tp_layout import find_sid
hits = find_sid("lin", frames, [0x27, 0x05])   # 返回 [("FF", frame), ...]
# 禁止: if d[2:4] == [0x27, 0x05]  ← 手写偏移，SF 对 FF 错，CAN/LIN 更容易混
```
