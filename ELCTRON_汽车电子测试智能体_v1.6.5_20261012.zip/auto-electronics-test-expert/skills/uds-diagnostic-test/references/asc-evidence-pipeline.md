# ASC 证据链自动采集管线（v3.9 固定口径）

> 定稿口径（v3.10）：**新执行证据格式 = ASC 标准格式（python 转写）**；
> 新执行中，EvidenceTraceMixin.trace_begin() 由驱动回调逐帧追加 ASC、每帧 flush，分片阈值默认 100 MiB；trace_flush() 写运行日志和轮次汇总。既有 ASC 与文本导出的 XCT 均可通过 swdl_trace_import.py 只读回读。二进制专有 XCT
> 没有经过验证的公开布局，必须要求原厂工具导出 ASC/文本，不能猜测或转写。红线：**禁止编造**——帧字节与时间戳均为实测，
> 转写必须可溯源（trace JSON ↔ result JSON ↔ ASC 三向对账）。

## 1. 管线全链路

```
用例脚本（env = SecEnv / TestRunner）
  → env.open() 后启用 uds._trace_capture = []   # 逐帧捕获开启
  → 收发全程 f1l1_uds._record_trace 强制记录     # 驱动硬件时间戳，无有效时间戳拒绝记录
  → env.close() 自动落盘：
      results/trace_<case>.json                  # 原始帧源件（时间戳来源声明 + 墙钟锚点）
      results/asc/<case>.asc                     # LIN-ASC 转写件（VickCAN 方言）
  → sec_evidence_audit / script_review 审计闭环
  → python 打包 zip（包内 ASC 为明文，可直接交付）
```

宿主侧最小集成（环境封装类，通用模式）：

```python
from asc_evidence import save_case_evidence
import time

class Env:
    def open(self):
        ...
        self.uds._trace_capture = []      # 开捕获
        self._wall0 = time.time()          # 墙钟锚点（时间语义对齐用）
        return True

    def close(self):
        frames = getattr(self.uds, "_trace_capture", None)
        try:
            if frames:
                save_case_evidence(self.case_id, frames, wall0=self._wall0,
                                   out_dir="results", result_file="results/result_<case>.json")
        except Exception as e:
            # 落盘失败不得吞掉用例本身的状态，记录进 steps 后继续收尾
            ...
        finally:
            self.uds._trace_capture = None
```

## 2. 真实性设计（为什么"转写"可接受）

| 环节 | 保证 |
|---|---|
| 帧字节 | `_record_trace` 在收发时刻从驱动缓冲原样记录，不经任何重构 |
| 时间戳 | xNetpack 硬件时间戳（微秒→秒），**无有效时间戳直接拒绝记录**（真实性硬保证） |
| 校验和 | 不抄显示值，按 LIN 规范由帧内容实算（`lin_tp.compute_checksum`；0x3C/0x3D 经典，其余增强） |
| 溯源 | ASC 头部注释声明 source trace / result / 时间戳语义 / 墙钟锚点；trace JSON 保存原始帧 |
| 格式 | 与 VickCAN 自产 ASC 实物样例**逐字段比对**（date/base/base/timestamps/UUID/帧行） |

## 3. 已踩坑清单（回归必查）

1. **双 `Li Li` 前缀 bug**：帧行格式 `"… Li %-19s …"` 中 ID 字段曾写成 `("Li %02x")` 导致行内双 Li。
   **规则**：任何 ASC 行格式改动，必须用 VickCAN 实物样例帧（含已知校验和）做逐字节回归。
2. **格式校验件与证据隔离**：用参考样例帧做的 FORMAT_CHECK / 冒烟 SMOKE 产物**不是测试证据**，
   result JSON 若混进 `results/` 会污染 summary 重建与审计（实测发生过：审计对账多出未知用例）。
   **规则**：探针/校验产物放 `results/_probe_artifacts/` 隔离目录，或落盘前就分开目录。
3. **tamper 探测与判据语义一致**（"tamper=iv" 教训）：篡改 IV 后若**重算 AUTH**，报文自洽 →
   DUT 接受属**正确行为**，不能判安全缺陷；真篡改必须**保留原 AUTH** 只改载荷。
   探测构造必须先想清楚判据期望的是什么失败。
4. **NRC 判据不硬编码单一值**：服务 NRC 集合取自 SDDB Service 表记载（诊断数据库为最高判据），
   冲突时按 SDDB 判定；xlsx 语义差异必须显式登记进证据链字段，不得静默取舍。
5. **"ECU 唤醒后错过首帧"（v3.9.1 重新定性）**：该现象当时主要归因 ECU，真机回归证明
   **主因是 drain 漏记**（见 #9）——帧实际上了总线，只是被 `_drain` 静默清理未记录。
   修复后同一探针 F1 86 请求/应答帧完整入证。唤醒期仍建议先跑会话复位序列，但判读时
   **帧缺失必须先查采集侧（drain/缓冲/回显路径），再归因 ECU 行为**。
6. **0xFF 密钥字段 ≠ 一定是占位**：全 FF 既可能是占位符，也可能是样件约定密钥本身
   （实测：27 Gen2 双组解锁用全 FF 密钥计算 PASS，用户确认即密钥本身）。
   **规则**：遇到全 FF 密钥材料，**必须请用户确认口径**后写入证据链登记，不得自行判定。
7. **DLP 环境特性**（本机透明加密）：工程目录内 python 写出的 `.asc` 在非受信视图下是密文，
   但 trace JSON（.json 不进加密范围）明文可读；**python 打包的 zip 内 ASC 为明文**，交付无碍；
   需要单独明文 ASC 时从 trace JSON 用 `--trace` 重转写即可。校验文件真态用 python 裸读魔数。
8. **长用例的捕获开销**：逐帧捕获会给高频率采样用例增加耗时（实测 400 次采样用例明显超时延长），
   排期按"捕获开启"后的实测耗时估算，不按裸执行估算。

## 4. 审计对账要点

- 每条台架用例 ↔ 1 个 trace JSON ↔ 1 个 ASC：帧数一致、首末帧时间合理；
- ASC 中 RX 帧的 SID/子功能必须与 result JSON steps 中的"接收"记录对得上；
- 判据文件优先级：**SDDB（诊断数据库）> xlsx 用例表 > 实现侧状态机文档 > ISO 14229/17987**；
- 离线用例（不上总线）ASC 不适用：在证据索引中显式列"ASC 不适用"清单 + 原因，不留空缺。
9. **drain 丢帧陷阱（v3.9.1 已修复）**：`f1l1_uds._drain` 原先读到即丢、不经 `_record_trace`——
   `request()` 重试之间/前后请求之间被清理的帧（TX 回显、迟到应答、调度表帧）在 trace 中永久缺失。
   冒烟实测"首条 22 F1 86 的 TX/RX 全不在 ASC"当时误判为"ECU 唤醒错过首帧"，事后排查定性为
   **驱动层漏记（专家级 bug）**。修复：`_drain` 增加 `record` 参数，`request()` 传 `record=True`
   （被清帧以真实硬件时间戳先记录再丢弃）；`request_with_trace` 隔离语义不变（其 drain 在
   `_trace_capture` 重置前执行）。**教训：帧"消失"先查采集侧漏记，再归因 ECU 行为。**
10. **CAN/LIN 帧结构混用（v3.9.2 已工具化）**：帧级判读禁止手写偏移，一律用
   `scripts/tp_layout.py`；对照速查与 6 条混淆陷阱**只维护一份**：
   `references/lin-can-tp-offsets.md`（2026-09-11 审计抽查两轮误报"帧缺失"的事故记录在内）。
