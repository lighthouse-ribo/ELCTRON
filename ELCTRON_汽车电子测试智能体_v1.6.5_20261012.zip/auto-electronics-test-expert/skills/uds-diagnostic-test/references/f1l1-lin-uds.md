# F1L1 (CANviex) UDS-over-LIN 实测排障要点

> 来源：BBS (P519) 项目 F1L1 xcdevlay 路线 B 实测记录（2026-08-13），已固化为 `../scripts/f1l1_uds.py`。
> 使用前先读本页，90% 的“总线无帧/无应答”问题都能在这里找到答案。

## 前置条件

- `xcdev_wrapper.py`（基于 `xcdevlay.h` 手写 ctypes 封装）：**已内置专家包 scripts/ 目录**（2026-08-18 补入），`f1l1_uds.py` 缺省可自动找到；自定义 SDK 目录时设置 `F1L1_XCWRAPPER_DIR` 覆盖，DLL 路径可用 `F1L1_DLL_PATH` 显式指定；
- CANviex-F1L1 设备驱动与 DLL（`dll_path` 在 wrapper 中显式传入，不要依赖默认拼接）；
- **执行前关闭 VickCAN.exe / CANoe**：同一通道独占，VickCAN 后台运行时所有收发 0 帧（连 TX 回显都没有）。

## 高频问题速查（按出现频率排序）

| # | 现象 | 根因 | 正确做法 |
|---|---|---|---|
| 1 | 所有 API 返回 OK 但总线上 0 帧 | `xLinOpt.outputV=0`：内置 12V 输出关闭，LIN 收发器无供电 | `opt.outputV = 1`（DB9 pin4=LIN-VBAT） |
| 2 | 只发 0x3C 无应答 | LIN 诊断协议中从节点只在收到 **0x3D 帧头**时填充应答 | 调度表交替 `0x3C(20ms) + 0x3D(20ms)` |
| 3 | 应答解析错位（id=0x0/len=65537） | ctypes 结构体 `_pack_=1` 与 C 默认 8 字节对齐不一致 | 去掉 `_pack_=1`（xNetpack 148→152 字节） |
| 4 | 应答 `7F 22 13`（incorrectLength） | PCI 把 SID 重复计入数据长度 | 单帧 PCI=数据字节数（不含 NAD/PCI） |
| 5 | 多帧（FF+CF）无响应 | ① 调度 40ms 轮一次时序不可靠 ② 复位 FF（PCI=0xFF 无效）在 CF 之间发出打断 TP 状态机 ③ 快更新覆盖 CF | 每帧 `lin_update_bytearray` 后**等 TX 回显确认（NAD+PCI 匹配）再发下一帧**；发完再复位 FF |
| 6 | 进程段错误退出（_drain） | 0x3C 持续重发 → 从节点持续应答 → 缓存永远有帧 → 死循环 | `_drain` 加 `max_frames=256` 保护 + 发送后复位 FF 停止重发 |
| 7 | 连续测试后 `xcdev_open` 返回 err=2 | 句柄未释放 | 打开失败重试（最多 5 次，间隔 3s） |
| 8 | 编程会话→扩展会话切换被拒 `7F 10 7E` | 跨会话直接切换 | 先回默认会话再切目标会话（`ensure_session`） |
| 9 | 0x27 NRC 不稳定（0x31/0x22/0x7F/0x37 交替） | 0x31/0x22=密钥候选不符；0x7F=会话丢失(S3 超时)或密钥 0xFF；0x37=时间延迟 | 0x3E 每 3s 保活；延迟后重试；请求前 F186 确认会话 |
| 10 | sleep 12s 后 0x27 返回 0x7F | S3 超时已回默认会话 | 全程 0x3E 保活 + 请求前 F186 确认会话 |
| 11 | 0x27 正例全部失败 | 真实 AES 密钥缺失（VolvoKey.json 全 0xFF 占位） | 主机厂/供应商提供真实 16B 密钥填入密钥文件；占位时正例标 **BLOCKED** 而非 FAIL |

## LIN TP 组帧规则（本引擎实现）

- 单帧：`[NAD, len] + payload`（len ≤ 6），剩余补 0xFF
- 首帧：`[NAD, 0x10|(len>>8), len&0xFF] + 前5字节`
- 连续帧：`[NAD, 0x20|seq] + 6字节`
- 流控：`[NAD, 0x30, BS, STmin]`
- 应答超时重试：`request(nad, payload, timeout, retry)` 自动清残留 + 重发

## 与 uds-diagnostic-test 的衔接

- Vector 路线（CAN）用 `uds_test_generator.py` 生成的脚本；F1L1 路线（LIN）用 `f1l1_uds.py` 做底层收发，上层按本技能标准流程生成用例/报告。
- 0x27 密钥统一走 `--sa-key-file`（Gen2 纯 Python 实现见 `seedkey_gen2.py`），DLL 预检与占位检测规则一致。

## 高实时时序测量（采集-后处理；COM/上位机路径已舍弃）

- 计时用 `time.perf_counter()` + `timeBeginPeriod(1)`（模块已内建，毫秒级；`time.time()` 在 Windows 默认 ~15.6ms 分辨率，不能用于 P2=50ms 测量）；
- `F1L1UDS.capture_trace(duration)` 连续采集轨迹（含单调时间戳），`lin_tp.analyze_trace()` 离线计算帧隙 / P2 / P2*（含 0x78）/ 0x37 延迟；
- 一键 CLI：`timing_trace.py --bus lin --duration 10 --out timing.md`；
- 采集期间不要开上位机/VickCAN，避免通道争用与往返延迟污染；
- **COM/上位机串口路径已舍弃**：自动化只走 xcdevlay DLL 直调，上位机仅人工查看（见 `test-path-guide.md`）。
