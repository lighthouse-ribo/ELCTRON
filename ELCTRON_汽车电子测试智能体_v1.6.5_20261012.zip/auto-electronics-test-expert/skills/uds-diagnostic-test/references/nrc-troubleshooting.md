# NRC → 根因 → 处置速查（UDS-over-CAN/LIN 实测固化）

> 来源：BBS 全流程实测记录（问题 32/33/36/37 等）+ ISO 14229。
> 用法：看到 NRC 先按「处置」逐条排查，不要直接怀疑 ECU；`../scripts/nrc_guide.py <NRC>` 可快速查。

## 排查总顺序（从易到难）

1. **环境/链路**：总线有活动？通道/供电正常？VickCAN/CANoe 占用？（先跑 `link_check.py`）
2. **会话状态**：当前会话是什么？是否已 S3 超时掉回默认？（先 `confirm_session`/F186）
3. **密钥/解锁状态**：0x27 密钥是否占位 0xFF？是否已解锁？延迟是否到期？（`seedkey_gen2.py --check`）
4. **请求参数**：PCI 长度、DID/子功能/数据与 LDF/调查表一致？（`case_lint.py` + `steps_generator` 审计）

## NRC 速查表

| NRC | 名称 | 常见场景（实测） | 根因方向 | 处置 |
|---|---|---|---|---|
| 0x12 | subFunctionNotSupported | 0x11 非法复位子功能、0x31 非法子功能 | 子功能值不在支持集 | 核对 SWRS/调查表子功能；ISO 默认非法子功能回 0x12 |
| 0x13 | incorrectMessageLengthOrInvalidFormat | 请求长度与期望不符 | **PCI 长度算错（单帧把 SID 重复计入/漏计）**、数据长度错 | 单帧 PCI=消息字节数（含 SID，不含 NAD/PCI）；按 LDF/DID 长度核对 |
| 0x22 | conditionsNotCorrect | **0x27 seed 请求被拒（密钥候选不符）**、条件未满足 | 密钥/算法参数、整车条件、会话前置 | 先验密钥文件非占位；再验算法参数（IV/CMAC）；查前置条件 |
| 0x24 | requestSequenceError | **0x27 使用过期/已作废种子发送 Key**、刷写块序错误 | 种子已失效（防重放/防枚举语义） | 有效 sendKey 配对**最后一次被 ECU 接受的种子**；频次/延迟违规后未用种子全部作废，跨窗后重新请求（见下方标准编排） |
| 0x31 | requestOutOfRange | **F10A/F103 只读 DID 读取**、密钥候选不符、SBL 分区属性 | DID 属性（22 读=No）、参数越界、密钥不符 | 查诊断表 DID 属性；只读/条件受限标 NA 不标 FAIL |
| 0x33 | securityAccessDenied | 未解锁访问 0x2E/0x31 受保护服务 | 解锁前置缺失 | 先完成 0x27 解锁再访问；用例前件必须写解锁 |
| 0x35 | invalidKey | 0x27 发送错误密钥 | 密钥值错误/算法参数错 | 核对密钥文件与算法（Gen2：CMAC/CTR 参数） |
| 0x36 | exceedNumberOfAttempts | 连续错误密钥 | 尝试次数超限锁定 | 按 SWRS 延迟等待解锁计数重置；负例要控制次数 |
| 0x37 | requiredTimeDelayNotExpired | **0x27 频繁失败触发延迟**（启动 5000ms/失败 10000ms；SWRS：失败延迟 10s、启动延迟 5s、失败 2 次触发） | 时间延迟未到期；**窗口按「进入会话」重新武装、跨复位持续** | **会话内 0x3E 80 保活跨窗后重试**（勿纯等待——掉 S3 得 0x7F；勿重进会话——重新武装窗口）；细则见下方标准编排 |
| 0x7E | subFunctionNotSupportedInActiveSession | 子功能在当前会话不支持 | 会话归属错误 | 核对服务×会话矩阵；如 0x27 等级 01 仅编程会话 |
| 0x7F | serviceNotSupportedInActiveSession | **会话丢失（S3 超时）后请求**、服务不在当前会话 | 会话掉回默认、密钥=0xFF | 0x3E 每 3s 保活；请求前 F186 确认会话；密钥非占位 |
| 0x78 | responsePending | 长操作（刷写/例程）处理中 | 正常 pending | 不重发，等 P2\* 后最终应答（f1l1 引擎已处理） |
| 0x10 | generalReject | 通用拒绝 | 视具体请求 | 按请求内容细分排查 |
| 0x11 | serviceNotSupported | 服务本身不支持 | 服务未实现/未列调查表 | 查调查表服务清单；未列服务按“不支持”负例 |

## 0x27 专属排查链（实测最重要）

0x27 相关 NRC 出现时，按此链排查（对应问题 32~39）：

1. `0x7F`：先查**会话**（S3 超时掉回默认？）→ 再查**密钥占位**（VolvoKey.json 全 0xFF？）；
2. `0x31 / 0x22`：**密钥候选不符**（Cus/占位密钥被 ECU 拒绝）→ 换真实密钥；
3. `0x37`：**时间延迟**（失败 10000ms）→ 会话内 0x3E 80 保活跨窗后重试（标准编排见下节）；
4. `0x33`：未解锁访问受保护服务 → 用例前件补齐解锁；
5. 全部失败且密钥确认真实 → 验算法参数（Gen2：AES-128-CTR/CMAC、IV/随机数、CMAC 覆盖范围）。

### 0x27 延迟窗口与种子生命周期标准编排（实测固化）

写 0x27 相关用例/脚本时按以下防护语义编排（正向规则，作为标准前置而非排错补救）：

1. **跨延迟窗口的唯一方式 = 会话内 0x3E 80 保活**：延迟窗口由「进入对应会话」动作武装，错误计数达到阈值后每次进入会话都重新启动完整窗口，且跨 0x11 复位持续（计数在 NVM）。纯等待会因 S3 超时掉回默认会话（后续请求 0x7F），掉会话后重进会话又重新武装窗口——两者都无法跨窗。保活周期取 S3 的 60%（如 S3=5s → 每 3s 一次），总等待 ≥ 窗口时长（如 10s 窗口 → 保活等待 12s）后重试；重试用全新随机数/IV，旧值作废。
2. **错误计数按密钥组/等级独立**：一组解锁成功只清零该组计数，其他组可能仍带延迟窗口。前置「计数 = 0」的用例需先用有效 sendKey 清零目标组，再建立测试基线。
3. **有效 sendKey 配对最后一次被 ECU 接受的种子**：对过期/旧种子 sendKey 按防重放语义预期 0x24。同一会话内多次请求种子后做解锁验证时，取最后一次 `67 xx` 响应对应的种子与随机数。
4. **频次/延迟违规后未使用种子全部作废**：违规后的旧种子 sendKey 预期 0x24（防枚举语义）；解锁恢复路径 = 保活跨窗 → 重新请求种子 → 有效 sendKey → 正响应后计数清零。
5. **内容校验类探测先跨窗再发帧**：篡改 message_id/method/IV、越界参数等探测帧的判定目标是内容校验层（0x31/0x22 等）；在延迟窗口内直接发会被 0x37 挡在门外，测不到内容校验。标准前置 = 按规则 1 跨窗后发探测帧；窗口残余以「保活 + 重试一次」兜底。
6. **判据例外**：预期 0x37/0x36/0x35 的判据步（延迟定时器验证、错误密钥锁定用例）使用裸请求，不套自动恢复编排，避免把预期防护响应当成异常恢复掉。

## 判定口径（不混判）

- 条件受限（只读 DID、需解锁但密钥未就绪、分区属性）→ **NA / BLOCKED**，不标 FAIL；
- 不稳定项（如 F12C）→ N 次执行一致性判定后再下结论；
- 报告自动解释 NRC 英文名（生成脚本内建 `describe_nrc`），处置按本表。

## 补充 NRC（刷写/传输层场景）

| NRC | 名称 | 说明 | 测试场景 |
|---|---|---|---|
| 0x14 | responseTooLong | 响应过长 | 多 DID 读取超单帧/多帧容量 |
| 0x25 | noResponseFromSubnetComponent | 子网组件无响应 | 网关转发场景 |
| 0x70 | uploadDownloadNotAccepted | 上传下载不被接受 | 刷写前置条件不满足 |
| 0x72 | generalProgrammingFailure | 通用编程失败 | Flash 写入错误 |
| 0x73 | wrongBlockSequenceCounter | 块序列计数器错误 | 刷写数据块顺序错误 |

## UDS 服务与会话矩阵（通用参考，以调查表为准）

| 服务 | SID | Default | Programming | Extended |
|---|---|:---:|:---:|:---:|
| DiagnosticSessionControl | 0x10 | ✓ | ✓ | ✓ |
| ECUReset | 0x11 | ✓ | ✓ | ✓ |
| ClearDTC | 0x14 | ✓ | ✗ | ✓ |
| ReadDTCInfo | 0x19 | ✓ | ✗ | ✓ |
| ReadDataByIdentifier | 0x22 | 按DID | 按DID | 按DID |
| SecurityAccess | 0x27 | ✗ | 01/02 | 03~41 |
| CommunicationControl | 0x28 | ✗ | ✗ | ✓ |
| WriteDataByIdentifier | 0x2E | 按DID | 按DID | 按DID |
| IOControlByIdentifier | 0x2F | ✗ | ✗ | ✓ |
| RoutineControl | 0x31 | ✗ | ✓ | ✓ |
| RequestDownload | 0x34 | ✗ | ✓ | ✗ |
| TransferData | 0x36 | ✗ | ✓ | ✗ |
| RequestTransferExit | 0x37 | ✗ | ✓ | ✗ |
| TesterPresent | 0x3E | ✓ | ✓ | ✓ |
| ControlDTCSetting | 0x85 | ✗ | ✗ | ✓ |

## 通用安全访问等级参考（与 BBS 实际等级 01/05 的差异见 security-key-mechanism.md）

| 等级 | Seed 请求 | Key 发送 | 典型用途 |
|---|---|---|---|
| Level 1 | 0x01 | 0x02 | 常规解锁（写 DID/IOControl） |
| Level 3 | 0x05 | 0x06 | 编程/扩展解锁 |
| Level FBL | 0x11 | 0x12 | Bootloader 解锁 |
| Level IMMO | 0x41 | 0x42 | 防盗解锁 |

## 诊断调查表关键属性清单（解析/补参时核对）

- **DID 属性**：DID Number / Name(中英) / CVT(M·C·S·U) / R-W State(R·W·R/W) / Size Bytes / 子数据 Byte·Bit Position / Range Min·Max / Unit / MethodType(identical·BCD·Linear·texttable) / Data Type / Default Value / Storage Position / Functional Addressing / 会话矩阵 / 安全等级矩阵。
- **IOControl 属性**：IOControlParam / DID / Parameters / Security Level / Conditions。
- **Routine 属性**：RID / ControlType(01 Start·02 Stop·03 RequestResults) / Parameters / Security Level / Conditions。
- **DTC 属性**：DTC Number(3B) / Failure Type Byte / Name / Priority / Monitor Enable Criteria / Monitor Type / Test Failed·Pass Criteria / Aging / Snapshot Record。
