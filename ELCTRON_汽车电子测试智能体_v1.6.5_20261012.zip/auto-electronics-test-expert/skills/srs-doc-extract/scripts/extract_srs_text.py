# -*- coding: utf-8 -*-
"""
DLP 加密 SRS PDF 全文提取脚本（自动分流 fitz / Acrobat COM）
================================================================
适用：公司透明加密（TsdEncrypt/TsdEncryptMF）环境下的需求文档 PDF。

流程：
  1. 用受信任 rg 拿明文视图头部字节，判断加密深度：
     - %TSD-Header-###%  → 深层加密 → Acrobat COM 通道（--mode acrobat）
     - %PDF              → 普通加密/明文 → fitz 内存解析（--mode fitz）
  2. 逐页提取文本，落盘为 UTF-8 明文 txt（每页以 "===== PAGE n =====" 分隔）
  3. 打印 RESULT ok=True PAGES=x CHARS=y TIME=z 供校验

用法：
  python extract_srs_text.py <PDF绝对路径> --mode auto|fitz|acrobat --out <输出txt路径> [--maxpages N]

前置条件：
  - venv 已装 PyMuPDF（fitz）、pywin32（Acrobat COM 通道需要）
  - 本机 Acrobat（11/DC）已注册 COM（AcroExch.App）
  - rg（受信任程序）路径：脚本自动发现（SRS_RG_PATH 环境变量 / PATH / Codex bin 目录），可用 --rg-path 显式指定
"""
import sys, time, os, argparse, subprocess

def discover_rg():
    """自动发现受信任 rg 路径（DLP 白名单程序），避免硬编码跨机器失效。
    优先级：环境变量 SRS_RG_PATH > PATH 中的 rg > %LOCALAPPDATA%/OpenAI/Codex/bin 下最新版 rg。
    分享脚本到其他机器时无需改代码：设置 SRS_RG_PATH 或保证 PATH 中有受信任 rg 即可。
    """
    env_rg = os.environ.get("SRS_RG_PATH", "").strip()
    if env_rg and os.path.isfile(env_rg):
        return env_rg
    from shutil import which
    p = which("rg")
    if p:
        return p
    base = os.path.join(os.environ.get("LOCALAPPDATA", ""), "OpenAI", "Codex", "bin")
    best = None
    if base and os.path.isdir(base):
        for root, _dirs, files in os.walk(base):
            for f in files:
                if f.lower() == "rg.exe":
                    cand = os.path.join(root, f)
                    if best is None or os.path.getmtime(cand) > os.path.getmtime(best):
                        best = cand
    if best:
        return best
    return "rg"  # 最后兜底：让 subprocess 按 PATH 解析，失败时会有清晰报错

RG = discover_rg()


def probe_head(pdf_path):
    """用受信任 rg 拿明文视图头部，返回 (head_hex, head_ascii, is_deep_encrypted)"""
    p = subprocess.run([RG, "-a", "--passthru", ".", pdf_path], capture_output=True)
    data = p.stdout
    head = data[:32]
    head_hex = head.hex()
    head_ascii = "".join(chr(b) if 32 <= b <= 126 else "." for b in head)
    is_pdf = data[:4] == b"%PDF"
    is_deep = head_ascii.startswith("%TSD-Header")
    return head_hex, head_ascii, is_pdf, is_deep


def extract_fitz(pdf_path, out_txt, maxpages=None):
    """fitz 内存解析：rg 拿明文字节流 → fitz.open(stream=...) → 逐页 get_text()"""
    import fitz

    p = subprocess.run([RG, "-a", "--passthru", ".", pdf_path], capture_output=True)
    data = p.stdout
    doc = fitz.open(stream=data, filetype="pdf")
    n = doc.page_count
    if maxpages:
        n = min(n, maxpages)

    lines = []
    t0 = time.time()
    for i in range(n):
        page = doc[i]
        text = page.get_text()
        lines.append("===== PAGE %d =====\n%s" % (i + 1, text))
        if (i + 1) % 50 == 0:
            print("PAGE %d/%d elapsed=%.1fs" % (i + 1, n, time.time() - t0), flush=True)

    full = "\n".join(lines)
    with open(out_txt, "w", encoding="utf-8") as f:
        f.write(full)
    return True, "PAGES=%d CHARS=%d TIME=%.1fs" % (n, len(full), time.time() - t0)


def extract_acrobat(pdf_path, out_txt, maxpages=None):
    """Acrobat COM 通道：适用于 rg 拿不到明文（%TSD-Header 深层加密）"""
    import win32com.client

    app = win32com.client.Dispatch("AcroExch.App")
    avdoc = win32com.client.Dispatch("AcroExch.AVDoc")
    ok = avdoc.Open(pdf_path, "")
    if not ok:
        return False, "OPEN_FAIL（Acrobat 未打开该文件，可能不在白名单或路径错误）"
    pdDoc = avdoc.GetPDDoc()
    n = pdDoc.GetNumPages()
    if maxpages:
        n = min(n, maxpages)

    # 用大矩形覆盖整页（页面尺寸 GetSize 返回 COM 对象不可枚举，直接给大值）
    rect = win32com.client.Dispatch("AcroExch.Rect")
    rect.Left = 0
    rect.Top = 5000
    rect.right = 4000
    rect.bottom = 0

    lines = []
    t0 = time.time()
    for p in range(n):
        try:
            ts = pdDoc.CreateTextSelect(p, rect)
            nb = ts.GetNumText()
            page_blocks = []
            for i in range(nb):
                try:
                    t = ts.GetText(i)
                    if t:
                        page_blocks.append(str(t))
                except Exception:
                    pass
            ts.Destroy()
            page_text = "".join(page_blocks)
            lines.append("===== PAGE %d =====\n%s" % (p + 1, page_text))
        except Exception as e:
            lines.append("===== PAGE %d ERROR %r =====" % (p + 1, e))
        if (p + 1) % 25 == 0:
            print("PAGE %d/%d elapsed=%.1fs" % (p + 1, n, time.time() - t0), flush=True)

    full = "\n".join(lines)
    with open(out_txt, "w", encoding="utf-8") as f:
        f.write(full)
    avdoc.Close(True)
    app.Exit()
    return True, "PAGES=%d CHARS=%d TIME=%.1fs" % (n, len(full), time.time() - t0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf", help="PDF 绝对路径")
    ap.add_argument("--mode", choices=["auto", "fitz", "acrobat"], default="auto",
                    help="auto=探测后自动分流（默认）；fitz=强制内存解析；acrobat=强制 Acrobat COM")
    ap.add_argument("--out", required=True, help="输出 txt 路径（UTF-8 明文，rg 可读）")
    ap.add_argument("--maxpages", type=int, default=None, help="只提取前 N 页（调试用）")
    ap.add_argument("--rg-path", default=None, help="受信任 rg 路径（覆盖自动发现，跨机器部署用）")
    args = ap.parse_args()
    global RG
    if args.rg_path:
        RG = args.rg_path

    try:
        head_hex, head_ascii, is_pdf, is_deep = probe_head(args.pdf)
        print("PROBE head_hex=%s head_ascii=%s is_pdf=%s is_deep=%s" % (head_hex, head_ascii, is_pdf, is_deep), flush=True)

        if args.mode == "acrobat" or (args.mode == "auto" and is_deep):
            ok, msg = extract_acrobat(args.pdf, args.out, args.maxpages)
        else:
            if not is_pdf:
                print("WARN: 头部非 %PDF（%s），尝试 fitz 解析；若失败改用 --mode acrobat" % head_ascii, flush=True)
            ok, msg = extract_fitz(args.pdf, args.out, args.maxpages)
    except Exception as e:
        import traceback
        traceback.print_exc()
        sys.exit("RESULT ok=False ERR=%r" % (e,))
    print("RESULT ok=%s %s" % (ok, msg), flush=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
