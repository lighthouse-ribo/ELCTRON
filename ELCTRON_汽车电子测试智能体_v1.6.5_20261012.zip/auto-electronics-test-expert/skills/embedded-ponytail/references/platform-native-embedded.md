# 芯片/SDK/协议栈原生能力目录

**嵌入式懒资深开发的第一个问题永远是：芯片/SDK/协议栈是不是本来就能做这件事？**

这份文档回答常见场景下的这个问题。**在伸手写解析、写驱动、手搓算法之前，先扫一遍这里。** 优先级：**配置层（LDF/DBC/lcfg/宏）> SDK/协议栈/芯片外设 > 三方 Python 库 > 手写**。平台能力随固件免费发布、经过芯片厂商验证、不会因为你升级而挂掉。

表里没有的：先翻 SDK 头文件目录、协议栈文档、Python 标准库索引，再动手写。写之前再问一句：专家包 `scripts/` 里是不是已经有（见 SKILL.md 复用清单）。

---

## 校验与数据完整性

| 你以为要手写 | 平台/SDK 本来就有 |
|---|---|
| CRC 计算函数 | 芯片硬件 CRC 外设（S32K CRC / STM32 CRC 单元），一次配置自动算；Python 侧 `binascii.crc_hqx` / `crcmod` |
| LIN 校验和生成/校验 | LIN 协议栈自动处理（经典/增强校验和），别在应用层手拼 |
| CAN 信号位打包/拆包 | DBC + `cantools`（Python）；协议栈信号封装（C 侧） |
| 字节序转换 | SDK 宏 / `struct`（Python），别手写位移拼接（最易错的地方） |
| 报文长度/ID 合法性 | 协议栈接收过滤 + DBC 定义，配置层解决 |

## 时序与调度

| 你以为要手写 | 平台/SDK 本来就有 |
|---|---|
| 微秒/毫秒延时 | OS tick / GPT 定时器 / systick——绝不用空转循环占 CPU |
| 周期任务调度 | RTOS 任务 + 软定时器；LIN 用协议栈 schedule table（LDF 配置层），别应用层手工发帧 |
| 临界区保护 | RTOS 原生 `taskENTER_CRITICAL` 等 API，别自写关中断封装 |
| 高精度时序测量 | DWT cycle counter / GPT 输入捕获（C 侧）；`time.perf_counter()`（Python，别用 `time.time()`） |
| 看门狗 | WDG 驱动模块：配置超时 + 统一喂狗点，别在多处随手喂 |

## 通信与存储外设

| 你以为要手写 | 平台/SDK 本来就有 |
|---|---|
| CAN 报文过滤 | CAN 控制器硬件过滤器 + Mailbox，配置一次，别软件逐帧 if |
| Flash 擦写 | SDK flash driver / Fee / NvM——别裸写 flash 寄存器 |
| EEPROM 模拟 | Fee/Eep 模块 |
| DMA 搬运 | SDK DMA 驱动，大块数据别 CPU 拷 |

## Python 工具侧（专家包脚本）

| 你以为要手写 | 标准库/既有库本来就有 |
|---|---|
| Excel/CSV 读取 | `openpyxl` / `pandas`——别手写字符串切分 |
| CAN 通道收发 | `python-can`（`bus.send/recv`、`Notifier` 别手写线程循环） |
| DBC 解析 | `cantools` |
| PDF 提取 | `fitz` (PyMuPDF)；加密 PDF 走既有 srs-doc-extract 通道 |
| 命令行参数 | `argparse`——别 `sys.argv` 手切 |
| JSON 配置 | `json` 标准库 |
| 路径/文件遍历 | `pathlib` / `glob` |
