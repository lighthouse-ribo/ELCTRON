# 测试用例 JSON 结构定义（build_testcase_xlsx.py 输入）

## 顶层结构

```json
{
  "cover": {
    "customer": "Volvo",
    "product_model": "TRM_V436",
    "test_target": "TRM",
    "created_date": "2026年8月11日",
    "srs_version": "33139542-001（PRELIMINARY）"
  },
  "cases": [
    {
      "req_sources": "REQ-90441v4",
      "case_id": "UDS_0x10_TC_0002",
      "priority": "L1",
      "auto_eval": "是",
      "test_point": "基于需求的测试",
      "test_method": "需求分析法",
      "design_method": "需求分析法",
      "env": "台架测试",
      "precondition": "1. 供电电压12V\n2. 应用模式\n3. 默认会话",
      "procedure": "1.测试仪请求：51 02 10 02 FF FF FF FF；",
      "expected": "1. DUT正响应：51 06 50 02 00 19 13 88；\n（编程会话：P2server_max=25ms；P2*server_max字节以SWRS为准）",
      "select": "是"
    }
  ]
}
```

## 字段说明（与 xlsx 列一一对应）

| JSON 字段 | xlsx 列 | 必填 | 说明 |
|---|---|---|---|
| `req_sources` | B 需求来源 | ✅ | REQ 编号，多 REQ 用 `\n` 分隔 |
| `case_id` | D 用例ID | ✅ | `UDS_<服务>_TC_<序号>`，全局唯一 |
| `priority` | E 优先级 | ✅ | L1/L2/L3 |
| `auto_eval` | F 自动化评估 | ✅ | 是/否 |
| `test_point` | G 测试点 | ✅ | 基于需求的测试 |
| `test_method` | H 测试方法 | ✅ | 需求分析法/等价类/边界值/场景法/错误推断 |
| `design_method` | I 用例设计方法 | ✅ | 通常与 test_method 相同 |
| `env` | J 测试环境 | ✅ | 台架测试/HIL/实车 |
| `precondition` | K 前提条件 | ✅ | 多行 `\n`，如供电/模式/会话/工具 |
| `procedure` | L 操作步骤 | ✅ | 多行 `\n`，报文级步骤 |
| `expected` | M 预期结果 | ✅ | 多行 `\n`，正/负响应+NRC+判定 |
| `select` | N 选择测试用例 | ✅ | 是 |
| — | C 需求ID | — | **不填**，生成脚本自动从 req_sources 首行取 |
| — | O~T 结果列 | — | **不填**，执行阶段才填写（P/NR 等） |

## 用例设计规则（每条用例必须满足）

1. **req_sources 必须来自 SRS 原文** REQ 编号（如 `REQ-90441v4`），不可编造
2. **case_id 命名**：`UDS_<服务>_TC_<序号>`（服务类）或 `UDS_<主题>_TC_<序号>`（时序/安全类）
3. **procedure 的报文格式**：`服务ID 长度 SID 子功能 参数...`，长度字节=后续字节数（如 `51 02 10 02` 长度 02=10 02）
4. **expected 必须有断言**：正例写具体正响应报文；负例写 NRC（0x12/0x13/0x22/0x31/0x33/0x35/0x78 等）
5. **时序值来自 SRS**：P2/P2*/S3 等以 SWRS 章节为准，不确定写「以 SWRS 为准」
6. **优先级**：L1=核心/安全关键；L2=边界/异常/恢复；L3=可选

## 示例（可直接套用，摘自用户参考模板风格）

```json
{
  "cover": {
    "customer": "Volvo",
    "product_model": "TRM_V436",
    "test_target": "TRM",
    "created_date": "2026年8月11日",
    "srs_version": "33139542-001（PRELIMINARY）"
  },
  "cases": [
    {
      "req_sources": "REQ-90442v4",
      "case_id": "UDS_0x10_TC_0003",
      "priority": "L1",
      "auto_eval": "是",
      "test_point": "基于需求的测试",
      "test_method": "需求分析法",
      "design_method": "需求分析法",
      "env": "台架测试",
      "precondition": "1. 供电电压12V\n2. 应用模式\n3. 默认会话",
      "procedure": "1.测试仪请求：51 02 10 03 FF FF FF FF；",
      "expected": "1. DUT正响应：51 06 50 03 00 32 13 88；",
      "select": "是"
    },
    {
      "req_sources": "REQ-90432v4",
      "case_id": "UDS_0x27_TC_0002",
      "priority": "L1",
      "auto_eval": "是",
      "test_point": "基于需求的测试",
      "test_method": "需求分析法",
      "design_method": "需求分析法",
      "env": "台架测试",
      "precondition": "1. 供电电压12V\n2. 扩展诊断会话\n3. 未执行安全解锁",
      "procedure": "1.测试仪请求：0x2E写受保护DID（或0x31受保护例程）；",
      "expected": "1. DUT负响应：NRC=0x33 securityAccessDenied；",
      "select": "是"
    }
  ]
}
```
