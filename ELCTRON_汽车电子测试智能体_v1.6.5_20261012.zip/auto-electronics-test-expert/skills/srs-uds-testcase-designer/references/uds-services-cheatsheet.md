# UDS 服务 / NRC / 时序参数速查表

> 用途：设计测试用例时对照写请求报文、预期响应、NRC 断言和时序值。
> **所有具体参数（支持会话、时序值、DID 值）一律以 SRS 原文为准，本表仅提供通用背景。**

## 常用 UDS 服务

| 服务 | SID | 子功能/用途 | 典型会话 | 用例分组名 |
|---|---|---|---|---|
| DiagnosticSessionControl | 0x10 | 01 default / 02 programming / 03 extended | 任意 | UDS_0x10 |
| ECUReset | 0x11 | 01 hardReset / 02 keyOffOn / 03 softReset | 扩展 | UDS_0x11 |
| ReadDataByIdentifier | 0x22 | 读 DID（0xF190 活动会话等） | 默认/扩展 | UDS_0x22 |
| SecurityAccess | 0x27 | 01 requestSeed / 02 sendKey（认证方法 0x0001 AES-CMAC/CTR） | 扩展 | UDS_0x27 |
| WriteDataByIdentifier | 0x2E | 写 DID（受保护 DID 需解锁） | 扩展+解锁 | UDS_0x2E |
| RoutineControl | 0x31 | 01 start / 02 stop / 03 requestResult | 扩展(+解锁) | UDS_0x31 |
| TesterPresent | 0x3E | 00 保持会话 | 任意 | UDS_0x3E |
| ReadMemoryByAddress | 0x23 | 按地址读内存 | 扩展 | UDS_0x23 |
| RequestDownload | 0x34 | 请求下载（SWDL） | 编程 | UDS_0x34 |
| TransferData | 0x36 | 传输数据（blockSequenceCounter） | 编程 | UDS_0x36 |
| RequestTransferExit | 0x37 | 结束传输 | 编程 | UDS_0x37 |

## 常用 NRC（负响应码）

| NRC | 含义 | 触发场景示例 |
|---|---|---|
| 0x11 | serviceNotSupported | 未支持的服务 ID |
| 0x12 | subFunctionNotSupported | 不支持的子功能（如 0x10 04） |
| 0x13 | incorrectMessageLengthOrInvalidFormat | 长度/格式错 |
| 0x22 | conditionsNotCorrect | 前置条件不满足 |
| 0x31 | requestOutOfRange | 参数越界 |
| 0x33 | securityAccessDenied | 未解锁访问受保护服务 |
| 0x35 | invalidKey | 0x27 key 错误 |
| 0x36 | exceededNumberOfAttempts | 错误尝试超限 |
| 0x37 | requiredTimeDelayNotExpired | 延迟锁定中 |
| 0x78 | responsePending | 长时间处理（例程擦除等） |
| 0x7E | subFunctionNotSupportedInActiveSession | 当前会话不支持该子功能 |
| 0x7F | serviceNotSupportedInActiveSession | 当前会话不支持该服务 |

**负响应报文格式**：`7F <SID> <NRC>`（如 `7F 10 12`）

## 时序参数（ISO 14229-1 + SRS 覆盖）

| 参数 | 含义 | 典型值（以 SWRS 为准） |
|---|---|---|
| P2Server_max | 正响应最大开始时间 | 非编程会话 50ms |
| P2*Server_max | 0x78 后最终响应时间 | 编程会话 25ms / 非编程 5000ms（SWRS 定） |
| P4Server_max | 服务器收到请求到最终响应（正/负，不含 0x78）的最大时限；=P2Server_max 表示该服务不允许 0x78 | = P2Server_max（不允许 0x78 时） |
| S3Server | 会话超时 | 默认 5s（SWRS 4.1.7 定义） |
| N_As/N_Ar | 发送/接收确认超时 | CAN 传输层 |
| N_Bs | BS 块间超时 | 传输层 |
| N_Cr | CF 接收超时 | 传输层 |
| N_WFTmax | FC.Wait 最大次数 | 传输层 |

## 多帧传输（ISO-TP）参数

| 参数 | 含义 | 说明 |
|---|---|---|
| BS (BlockSize) | 块大小 | FC 帧中的块限制，SWRS 4.1.6.1.2 |
| STmin | 帧间最小间隔 | FC 帧中的分离时间，SWRS 4.1.6.1.3 |
| FF/CF/FC | 首帧/连续帧/流控帧 | 多帧传输三要素 |

## 安全认证（0x27 Gen2，SWRS 4.1.10.4 类章节）

- 认证方法 `0x0001`：AES-CMAC（种子验证）+ AES-CTR（数据解密）
- 流程：`0x27 01` 取 seed → 用 key 计算 → `0x27 02` 送 key → 成功解锁
- 安全相关测试重点：成功解锁、错误 key（0x35）、尝试次数锁定（0x36/0x37）、未解锁访问受保护功能（0x33）、解锁状态与会话切换的保持/失效

## 报文格式速记（经典 CAN 诊断）

- **单帧**：`<PCI(1B)> <SID> <数据...>`，PCI 高 4 位 0x0，低 4 位=数据长度
  - 例：`02 10 02` = 请求（len=2，SID=10，子功能=02）
- **首帧**：`<PCI=0x1L> <L2> <SID> <数据...>`（L=长度高 8 位，L2=低 8 位）
- **连续帧**：`<PCI=0x2N> <数据...>`（N=序号 1~15 循环）
- **流控帧**：`<PCI=0x3F> <BS> <STmin>`
- **测试仪物理寻址**：`51` 是 CAN 帧标识/地址格式前缀（用户模板习惯），具体以 SRS 4.1.9.1.1 ECU address 为准
