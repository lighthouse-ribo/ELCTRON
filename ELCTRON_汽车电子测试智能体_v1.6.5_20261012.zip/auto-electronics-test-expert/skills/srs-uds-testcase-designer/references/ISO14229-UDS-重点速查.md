# ISO 14229-1 UDS 重点速查（精简版）

> 替代 `ISO14229-2020-UDS-zh-full.pdf`（7.8MB 全文）的重点版，覆盖日常测试设计所需：服务定义、子功能、NRC、时序参数、多帧传输、会话与安全。
> **与 SRS/SWRS 或主机厂规范冲突时，以客户规范为准。**

## 一、服务总表（SID + 子功能 + 正响应）

| 服务 | SID | 子功能 | 正响应 | 用途 |
|---|---|---|---|---|
| DiagnosticSessionControl | 0x10 | 01 默认/02 编程/03 扩展/04 安全/0x40+ 自定义 | 50 | 会话切换（LIN 从节点支持 01/03 居多） |
| ECUReset | 0x11 | 01 硬复位/02 钥匙关复位/03 软复位/04 使能快下电/05 禁止快下电（04/05 为 2020 新增） | 51 | 复位；子功能\|0x80 抑制正响应 |
| ClearDiagnosticInformation | 0x14 | 无子功能字节；groupOfDTC=FFFFFF 全清/指定组 | 54 | 清 DTC |
| ReadDTCInformation | 0x19 | 02 按状态掩码/04 快照/06 扩展/0A 支持DTC | 59 | 读故障码 |
| ReadDataByIdentifier | 0x22 | — | 62 | 读 DID（VIN F190、软硬件版本 F187 等） |
| ReadMemoryByAddress | 0x23 | — | 63 | 读内存（刷写/研发用） |
| SecurityAccess | 0x27 | 01/03/05/07… 请求种子，02/04/06/08… 发送密钥 | 67 | 安全解锁（奇数=种子，偶数=密钥） |
| CommunicationControl | 0x28 | 00 使能Rx+Tx/01 使能Rx禁Tx/02 禁Rx使能Tx/03 禁Rx+Tx；类型 01 常规/02 网络管理/03 两者 | 68 | 通信控制（网络唤醒测试） |
| Authentication | 0x29 | 新安全机制 | 69 | 高级安全（2020 新增） |
| ReadDataByPeriodicIdentifier | 0x2A | — | 6A | 周期读 DID |
| DynamicallyDefineDataIdentifier | 0x2C | — | 6C | 动态 DID |
| WriteDataByIdentifier | 0x2E | — | 6E | 写 DID（受保护服务，需 0x27 解锁） |
| InputOutputControlByIdentifier | 0x2F | 00 返回/01 复位/02 冻结/03 短时控制 | 6F | IO 控制（测试执行器/灯） |
| RoutineControl | 0x31 | 01 启动/02 停止/03 请求结果 | 71 | 例程（擦除、刷写检查、测试例程） |
| RequestDownload | 0x34 | — | 74 | 请求下载（返回内存地址+大小） |
| RequestUpload | 0x35 | — | 75 | 请求上传 |
| TransferData | 0x36 | 01 首帧/02 后续帧 | 76 | 传输数据（按块） |
| RequestTransferExit | 0x37 | — | 77 | 结束传输 |
| TesterPresent | 0x3E | 00/80（抑制位） | 7E | 保活（防 S3 超时回默认会话） |
| ControlDTCSetting | 0x85 | 01 开启/02 关闭 | C5 | 关 DTC（测试环境用） |
| ResponseOnEvent | 0x86 | 00 停止/01 事件/02 清除事件/03 周期事件/04 清除全部（03/04 为 2020 新增） | C6 | 事件响应（ROE） |
| LinkControl | 0x87 | 01 波特率切换等 | C7 | 波特率切换（LIN 刷写常见） |

## 二、常用 NRC（负响应码，格式 7F + SID + NRC）

| NRC | 名称 | 典型场景 |
|---|---|---|
| 0x10 | generalReject | 一般拒绝 |
| 0x11 | serviceNotSupported | 服务不支持 |
| 0x12 | subFunctionNotSupported | 子功能不支持 |
| 0x13 | incorrectMessageLengthOrInvalidFormat | 长度错误/格式无效（多帧 SF_DL/FF_DL 边界常用） |
| 0x14 | responseTooLong | 响应超长 |
| 0x21 | busyRepeatRequest | 忙，稍后重试 |
| 0x22 | conditionsNotCorrect | 条件不满足（会话不对等） |
| 0x24 | requestSequenceError | 请求顺序错误（未请求种子直接发密钥） |
| 0x31 | requestOutOfRange | 参数越界（DID/RID 不支持） |
| 0x33 | securityAccessDenied | 安全访问被拒（未解锁访问受保护服务） |
| 0x34 | authenticationRequired | 需要认证 |
| 0x35 | invalidKey | 密钥错误 |
| 0x36 | exceedNumberOfAttempts | 尝试次数超限（失败锁定） |
| 0x37 | requiredTimeDelayNotExpired | 延迟未到期（安全访问延迟） |
| 0x70 | uploadDownloadNotAccepted | 上传/下载不接受 |
| 0x71 | transferDataSuspended | 传输挂起 |
| 0x72 | generalProgrammingFailure | 编程失败 |
| 0x73 | wrongBlockSequenceCounter | 块序列号错误 |
| 0x78 | requestCorrectlyReceived-ResponsePending | 已接收，处理中（P2\* 窗口标志） |
| 0x7E | subFunctionNotSupportedInActiveSession | 当前会话不支持该子功能 |
| 0x7F | serviceNotSupportedInActiveSession | 当前会话不支持该服务 |

## 三、时序参数（服务器侧）

| 参数 | 含义 | 典型值 | 测量方法 |
|---|---|---|---|
| P2Server | 正常响应时间上限 | 25~50ms | 请求末帧 → 响应首帧 |
| P2\*Server | 增强窗口（P2 超时后） | 5000ms | 超过 P2 后仍在 P2\* 内响应 |
| S3Server | 会话超时（无请求回默认会话） | 5000ms | 边界测试：4900ms 有效 / 5100ms 失效 |
| P4Server | 例程/IO 响应时间 | 50ms（按例程） | RID × 子功能测量 |
| N_As | 发送超时 | 1000ms | 网络层 |
| N_Cr | 接收超时 | 1000ms | 网络层 |

## 四、多帧传输（LIN/CAN ISO-TP）

- 首帧 FF：`10 长度高 长度低 ...`（12bit 长度）；连续帧 CF：`2x 数据`；流控 FC：`30 块大小 BS STmin`
- **SF_DL**（单帧数据长度）：SF 的 DLC 字段，0~7（经典 CAN）/0~63（CAN FD）
- **FF_DL**（首帧数据长度）：12 位，总长度
- 关键边界用例：`length.total 刚好 / −1 / +1`、`SF_DL 有效 vs 无效` → 常见 NRC 0x13
- **BS**（BlockSize）：块大小，0=连续发送；**STmin**：最小发送间隔（0x00~0x7F ms）

## 五、会话与安全

- 会话：**01 默认**（上电默认）/ **02 编程**（刷写用）/ **03 扩展**（诊断/写/例程用）；S3 超时回默认
- 0x27 流程：请求种子（奇数子功能）→ ECU 返回种子 → 计算密钥（SeedKey DLL）→ 发送密钥（偶数子功能）→ 解锁成功
- 失败策略：连续 N 次错误密钥 → 锁定（NRC 0x36）；需等待延迟（NRC 0x37）
- **受保护服务**（0x2E 写 / 0x31 例程 / 刷写）：必须扩展/编程会话 + 解锁，否则 NRC 0x33

## 六、示例报文（LIN 从节点 8 字节帧）

```
读 DID F12E：  请求 51 03 22 F1 2E FF FF FF → 响应 51 03 62 F1 2E + 数据
切扩展会话：   请求 51 02 10 03 FF FF FF FF → 响应 51 06 50 03 00 P2_hi P2_lo 88
安全解锁级5：  请求 51 02 27 05 FF FF FF FF → 响应 51 06 67 05 + 种子
TesterPresent：请求 51 02 3E 00 FF FF FF FF → 响应 51 01 7E 00
```
