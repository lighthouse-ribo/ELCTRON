# -*- coding: utf-8 -*-
"""test_srs_focus_extractor.py — 分层精读抽取的单元测试（合成文档，不依赖真实项目资料）"""

import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import srs_focus_extractor as fe

REQ_DOC = """===== PAGE 1 =====
NOTE-SWRS Base Electronics
Body Control Module Specification
1. Overview
This document describes body control functions such as window lift and lighting.
===== PAGE 2 =====
2. Diagnostics
2.1 UDS Session
REQ-90441v4 DiagnosticSessionControl (10) programmingSession (02, 82)
ASIL class: Change
Purpose: It shall be possible to re-program any ECU.
The ECU shall support the service diagnosticSessionControl in programmingSession.
P2Server_max=50ms
S3Server=5s
2.2 Read Data By Identifier
Tester request: 51 03 22 F1 2E FF FF FF
Positive response contains the DID F12E value.
NRC=0x31 for unsupported DID in current session.
===== PAGE 3 =====
3. Body Control
Window lift behavior and interior lighting. No diagnostics in this chapter.
"""

PLAIN_DOC = """DiagcForSlaveNodBBS
The tester sends the diagnostic frame 0x3C: 51 03 22 F1 2E FF FF FF.
The node shall respond with the DID F12E value.
===== PAGE 1 =====
UDS on LIN section with diagnostic frame 51 03 22 F1 2E.
"""

EMPTY_DOC = """1. Introduction
This document only describes mechanical packaging and thermal design.
2. Assembly
Screw torque and cable routing. Nothing diagnostic here.
"""


class TestFocusExtractor(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix=".test_focus_")

    def test_pages_and_sections(self):
        txt = os.path.join(self.tmp, "req.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(REQ_DOC)
        lines, pages, extra = fe.load_txt_lines(txt)
        self.assertEqual(extra["has_page_marks"], True)
        self.assertTrue(any(p == 2 for p in pages))
        heads = fe.detect_headings(lines)
        ids = [h[1] for h in heads]
        for expect in ("1", "2", "2.1", "2.2", "3"):
            self.assertIn(expect, ids)
        sections, owner = fe.build_sections(lines, pages, heads)
        sec21 = next(s for s in sections if s["id"] == "2.1")
        self.assertEqual(sec21["page_start"], 2)

    def test_facts_extraction(self):
        txt = os.path.join(self.tmp, "req.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(REQ_DOC)
        lines, pages, _ = fe.load_txt_lines(txt)
        heads = fe.detect_headings(lines)
        sections, owner = fe.build_sections(lines, pages, heads)
        fe.score_sections(lines, owner, sections)
        facts = fe.extract_facts(lines, pages, owner, sections)

        self.assertEqual(len(facts["req_blocks"]), 1)
        req = facts["req_blocks"][0]
        self.assertEqual(req["req_id"], "REQ-90441v4")
        self.assertEqual(req["asil"], "Change")
        self.assertIn("re-program", req["purpose"])
        self.assertTrue(any("shall support" in s for s in req["shall_lines"]))
        self.assertIn(2, req["pages"])

        frames = facts["frames"]
        self.assertTrue(any(f["frame"].startswith("51 03 22 F1 2E") for f in frames))
        f0 = next(f for f in frames if f["frame"].startswith("51 03 22 F1 2E"))
        self.assertEqual(f0["sid"], "0x22")
        self.assertEqual(f0["did"], "0xF12E")
        self.assertEqual(f0["page"], 2)

        dids = [d["did"] for d in facts["dids"]]
        self.assertIn("0xF12E", dids)

        params = {(t["param"].upper(), t["value"]) for t in facts["timing"]}
        self.assertIn(("P2SERVER_MAX", "50"), params)
        self.assertIn(("S3SERVER", "5"), params)

        self.assertIn("0x31", facts["nrc_values"])
        self.assertTrue(any("programming" in s.lower() for s in facts["sessions_detected"]))

        top = [s["id"] for s in sorted(sections, key=lambda s: (-s["score"], s["line_start"]))[:3]]
        self.assertIn("2.1", top)
        self.assertNotIn("3", top)  # 无诊断内容的章节分数应低于诊断章节

    def test_run_extract_outputs(self):
        txt = os.path.join(self.tmp, "req.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(REQ_DOC)
        out = os.path.join(self.tmp, "out")
        rc = fe.run_extract(txt, out)
        self.assertEqual(rc, 0)
        for name in ("srs_map.json", "srs_facts.json", "FOCUS_REPORT.md"):
            self.assertTrue(os.path.exists(os.path.join(out, name)), name)
        with open(os.path.join(out, "srs_map.json"), encoding="utf-8") as f:
            mmap = json.load(f)
        self.assertTrue(mmap["top_sections"])
        sec_files = os.listdir(os.path.join(out, "sections"))
        self.assertTrue(sec_files)
        with open(os.path.join(out, "FOCUS_REPORT.md"), encoding="utf-8") as f:
            rep = f.read()
        self.assertIn("精读顺序", rep)
        self.assertIn("REQ-90441v4", rep)

    def test_functional_style_fallback(self):
        txt = os.path.join(self.tmp, "plain.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(PLAIN_DOC)
        lines, pages, _ = fe.load_txt_lines(txt)
        heads = fe.detect_headings(lines)
        sections, owner = fe.build_sections(lines, pages, heads)
        fe.score_sections(lines, owner, sections)
        facts = fe.extract_facts(lines, pages, owner, sections)
        self.assertTrue(facts["req_blocks"])
        self.assertTrue(all(r["auto_generated"] for r in facts["req_blocks"]))
        self.assertTrue(all(r["req_id"].startswith("REQ-") for r in facts["req_blocks"]))
        dids = [d["did"] for d in facts["dids"]]
        self.assertIn("0xF12E", dids)

    def test_no_relevant_content_rc2(self):
        txt = os.path.join(self.tmp, "empty.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(EMPTY_DOC)
        out = os.path.join(self.tmp, "out_empty")
        rc = fe.run_extract(txt, out)
        self.assertEqual(rc, 2)

    def test_dump_section(self):
        txt = os.path.join(self.tmp, "req.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(REQ_DOC)
        out = os.path.join(self.tmp, "out_dump")
        fe.run_extract(txt, out)
        rc = fe.dump_section(txt, os.path.join(out, "srs_map.json"), out, "2.1")
        self.assertEqual(rc, 0)
        dumps = [n for n in os.listdir(os.path.join(out, "sections")) if n.startswith("FULL_")]
        self.assertTrue(dumps)
        with open(os.path.join(out, "sections", dumps[0]), encoding="utf-8") as f:
            body = f.read()
        self.assertIn("diagnosticSessionControl", body)
        self.assertIn("P2Server_max=50ms", body)

    def test_table_rows_not_headings_and_unique_ids(self):
        """真实文档实测回归：docx 表格行（" | " 连接）不得伪装成编号标题；重复编号 id 加 #n 去重"""
        doc = """1. Overview
Body functions.
| 1 | NOTE-SWRS-34088390-01-1 | SPA3 SWRS |
| 2 | Beep | Sound types |
1. Overview Again
Duplicate heading number.
| 0x3C | LIN | UF | |
2. Diagnostics
REQ-90001v1 Read DID
Tester request: 51 03 22 F1 2E FF FF FF
"""
        txt = os.path.join(self.tmp, "tbl.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(doc)
        lines, pages, _ = fe.load_txt_lines(txt)
        heads = fe.detect_headings(lines)
        titles = [t for _, _, t in heads]
        self.assertIn("Overview", titles)
        self.assertIn("Overview Again", titles)
        self.assertNotIn("NOTE-SWRS-34088390-01-1 | SPA3 SWRS", titles)
        sections, _owner = fe.build_sections(lines, pages, heads)
        ids = [s["id"] for s in sections if s["id"] != "PRE"]
        self.assertEqual(len(ids), len(set(ids)), "章节 id 必须唯一")
        self.assertIn("1", ids)
        self.assertIn("1#2", ids)
        self.assertIn("2", ids)
        # 表格行归入最近章节而不是自成章节
        tbl_sec = next(s for s in sections if "NOTE-SWRS" in "\n".join(
            lines[s["line_start"]:s["line_end"] + 1]) or True)
        self.assertTrue(any("|" in l for l in lines))  # 样本确实含表格行

    def test_two_line_headings_and_bad_titles(self):
        """真实 542 页 ISO 实测回归：两行式标题（纯编号行+下行标题）要合并；示例行不得伪装标题"""
        doc = """===== PAGE 1 =====
ISO 14229 demo
6.4
A_Data type definition with diagNostic details
7.2
诊断会话控制服务
15 = 120％
1011 1100 0101 1000b = 0xBC58
7.2.1
Service description with shall requirements
===== PAGE 2 =====
7.3
Diagnostic service echo test with frame 02 10 02 FF FF FF
"""
        txt = os.path.join(self.tmp, "iso.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(doc)
        lines, pages, _ = fe.load_txt_lines(txt)
        heads = fe.detect_headings(lines)
        ids = [h[1] for h in heads]
        self.assertIn("6.4", ids)
        self.assertIn("7.2", ids)
        self.assertIn("7.2.1", ids)
        t72 = dict((h[1], h[2]) for h in heads)["7.2"]
        self.assertIn("诊断会话控制", t72)
        # 示例行/位串行不得成为标题
        self.assertNotIn("15", ids)
        self.assertNotIn("1011", ids)
        self.assertNotIn("350", ids)
        sections, _ = fe.build_sections(lines, pages, heads)
        sec72 = next(s for s in sections if s["id"] == "7.2")
        self.assertEqual(sec72["page_start"], 1)
        # 7.2 章节体应包含其标题行与正文
        body = "\n".join(lines[sec72["line_start"]:sec72["line_end"] + 1])
        self.assertIn("诊断会话控制服务", body)

    def test_footer_toc_noise_not_headings(self):
        """ISO 542 页实测回归②：页脚裸页码/水印行/TOC 点线行不得成为标题。
        曾因假标题 "41+水印" + heads[:400] 上限截断，吞掉 61 页后全部真实章节。"""
        doc = """===== PAGE 60 =====
9.2.3
响应消息数据参数定义
===== PAGE 61 =====
版权所有
41

Provided by IHS under license with ISO
===== PAGE 62 =====
9.2.1 诊断会话描述.......54
10.1
服务定义前提 the server shall support it
1.6964 秒
"""
        txt = os.path.join(self.tmp, "iso_noise.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write(doc)
        lines, pages, _ = fe.load_txt_lines(txt)
        heads = fe.detect_headings(lines)
        ids = [h[1] for h in heads]
        self.assertIn("9.2.3", ids)          # 两行式带点编号正常合并
        self.assertIn("10.1", ids)           # 多级带点编号正常合并
        self.assertNotIn("41", ids)          # 裸页码：无点不参与两行式合并
        self.assertNotIn("9.2.1", ids)       # 点线 TOC 行被拒
        self.assertNotIn("1.6964", ids)      # 超长段数值行不是章节号
        self.assertFalse(any("IHS" in h[2] or "版权" in h[2] for h in heads))
        # 截断标记：小文档应为 0
        self.assertEqual(getattr(fe.detect_headings, "truncated", -1), 0)

    def test_docx_ordered_tables(self):
        try:
            import docx  # noqa: F401
        except ImportError:
            self.skipTest("python-docx 未安装，跳过 docx 顺序测试")
        from docx import Document
        d = Document()
        d.add_paragraph("4.1.8 UDS Data", style="Heading 2")
        d.add_paragraph("Before table line about DID F12E.")
        t = d.add_table(rows=2, cols=2)
        t.cell(0, 0).text = "DID"
        t.cell(0, 1).text = "Name"
        t.cell(1, 0).text = "0xF12E"
        t.cell(1, 1).text = "PartNumber"
        d.add_paragraph("After table line.")
        p = os.path.join(self.tmp, "t.docx")
        d.save(p)
        lines, pages, extra = fe.load_docx_lines(p)
        joined = "\n".join(lines)
        self.assertLess(joined.index("Before table"), joined.index("DID | Name"))
        self.assertLess(joined.index("DID | Name"), joined.index("After table"))
        self.assertTrue(extra["style_headings"])


if __name__ == "__main__":
    unittest.main()
