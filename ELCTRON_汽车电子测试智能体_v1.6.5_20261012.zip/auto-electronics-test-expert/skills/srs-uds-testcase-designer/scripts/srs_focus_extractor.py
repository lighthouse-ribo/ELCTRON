# -*- coding: utf-8 -*-
"""
srs_focus_extractor.py — SRS 全文精读分层抽取（骨架 → 聚焦 → 事实 → 证据）
==========================================================================
解决什么问题：
  解密后的 SRS 全文 txt 动辄几十万字符（实测 418 页 / 92.6 万字符），
  LLM 直接通读会截断、丢重点、反复重读浪费上下文。本脚本把
  「LLM 啃原文」改为「脚本结构化抽取 + LLM 只读精简产物」：

  1. 骨架层  解析 ===== PAGE n ===== 页码标记 → 行级页码索引 → 章节树
             （编号标题 / docx 样式标题 / 无编号时按块分段），输出 srs_map.json
  2. 聚焦层  每章节按 UDS 相关性打分（关键词/SID/DID/REQ/帧/时序/NRC 加权），
             排序给出「精读顺序」
  3. 事实层  全文结构化抽取：REQ 块、诊断帧、DID、时序参数、NRC、会话、安全，
             每条事实带 **页码 + 所属章节** 证据，输出 srs_facts.json
  4. 裁剪层  只把 Top-N 高分章节原文落盘 sections/*.md（超长截断标注），
             LLM 按需读取；需要某章节全文时用 --dump-section 按需钻取

输入：
  - 明文 txt（srs-doc-extract 产物，含 ===== PAGE n ===== 标记；无标记也能处理）
  - .docx（python-docx，段落与表格按文档顺序交织提取——修复"表格堆到末尾"的失真）
  - 明文/普通加密 .pdf（fitz；%TSD-Header 深层加密请先走 srs-doc-extract）

输出（--out-dir 目录）：
  srs_map.json      文档骨架 + 章节相关性排序（LLM 第一个读，通常 <50KB）
  srs_facts.json    结构化事实（REQ/帧/DID/时序/NRC/会话/安全，带页码证据）
  sections/*.md     Top-N 高分章节原文裁剪（截断处标注，可 --dump-section 补全）
  FOCUS_REPORT.md   人类可读的精读报告（骨架表 + 事实摘要 + 精读指引）

用法：
  python srs_focus_extractor.py <input.txt|.docx|.pdf> --out-dir <目录> [--top 12] [--max-section-chars 20000]
  python srs_focus_extractor.py <input> --out-dir <目录> --dump-section "2.1"   # 钻取某章节全文

退出码：0=成功；2=全文未发现 UDS 相关内容；3=解析失败；4=参数/文件错误
"""

import sys
import os
import re
import json
import argparse
import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

__version__ = "1.0.0"

# ---------------- 页码标记（srs-doc-extract 产物格式） ----------------
PAGE_MARK_RE = re.compile(r"^\s*===== PAGE (\d+) =====\s*$")

# ---------------- 章节标题 ----------------
# 编号标题：4.1.6 UDS Transport / 2. Diagnostics / 3.1 Body Control
HEAD_RE = re.compile(r"^\s*(\d+(?:\.\d+){0,4})[.、\)]?\s+(\S.{1,120})$")
# 标题里出现连续 hex 字节对视为报文行，不是标题
HEX_PAIR_RE = re.compile(r"\b[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\b")
# 纯编号行（两行式标题的上行，PDF 排版常见）：如 "7.2"、"11.3.1"
NUM_ONLY_RE = re.compile(r"^\s*(\d+(?:\.\d+){0,4})\.?\s*$")
# 标题不能以数字/等号/破折号等开头（示例行、位串行、表格碎片伪装）
BAD_TITLE_START_RE = re.compile(r"^[0-9=\-–—+#%％)）.、,，:：;；]")
# 标题正文含页眉/页脚水印或版权行（ISO 542 页实测：页脚裸页码 + "Provided by IHS" 水印拼成假标题）
BAD_TITLE_TEXT_RE = re.compile(r"provided by ihs|版权所有|all rights reserved|copyright|license with iso|©", re.I)
# 目录点线（"9.2.1 诊断会话.......54"）——TOC 行不是章节标题本体
DOT_LEADER_RE = re.compile(r"\.{3,}|…{2,}")
# 标题以计量单位开头（"GB - 1"＝闪存表行"4 GB - 1"）不是章节标题
UNIT_TITLE_RE = re.compile(r"^(?:kilo|mega|giga|tera)?(?:byte|bit)s?\b|^(?:KB|MB|GB|TB|ms|us|µs|Hz|kbps)\b", re.I)


def plausible_sec_id(num):
    """章节号合理性：每段 1~99 的整数（"1.6964"表格数值行/"0"不存在章节号，ISO 542 页实测）"""
    return all(seg.isdigit() and 1 <= int(seg) <= 99 for seg in num.split("."))

# ---------------- 相关性关键词（与 srs_input_analyzer 同源） ----------------
DIAG_KEYWORDS = {
    "UDS": ["UDS", "unified diagnostic"],
    "Diagnostic": ["diagnostic", "诊断"],
    "LIN": ["LIN", "lin bus"],
    "DID": ["DID", "data identifier"],
    "DTC": ["DTC", "trouble code"],
    "Session": ["session", "会话"],
    "SecurityAccess": ["security access", "SecurityAccess", "seed", "key"],
    "NRC": ["NRC", "negative response", "0x7F"],
    "Download": ["download", "flash", "reprogram", "刷写"],
    "Timing": ["P2Server", "S3Server", "P2", "STmin", "timeout"],
}

SID_RE = re.compile(r"\b0x(10|11|14|19|22|23|27|28|2E|31|34|36|37|3E|85)\b", re.I)
DID_RE = re.compile(r"\b(?:0x)?F1[0-9A-F]{2}\b", re.I)
FRAME_RE = re.compile(r"(?:0x3C\s*[:：]\s*)?([0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2}){4,9})")
REQ_START_RE = re.compile(r"^(REQ-[\w.\-]{2,60})\s*[::]?\s*(.*)$")
SHALL_RE = re.compile(r"\bshall\b|\bmay\b|\bshall not\b", re.I)
ASIL_RE = re.compile(r"ASIL\s*class\s*[:：]?\s*(\S+)", re.I)
PURPOSE_RE = re.compile(r"Purpose\s*[:：]\s*(.*)", re.I)
NRC_RE = re.compile(r"\bNRC\s*=?\s*0x([0-9A-Fa-f]{2})\b")
NEGFMT_RE = re.compile(r"\b7F\s+[0-9A-Fa-f]{2}\s+([0-9A-Fa-f]{2})\b")
TIMING_RE = re.compile(
    r"\b(P2(?:Server)?(?:_max|_star|\*)?|S3(?:Server)?"
    r"|STmin|N_As|N_Cr|N_Cs|P4(?:Server)?)\s*[:=＝≈]\s*"
    r"([0-9]+(?:\.[0-9]+)?)\s*(ms|s|秒|毫秒)?", re.I)
SESSION_KWS = ["defaultSession", "extendedDiagnosticSession", "programmingSession",
               "nonDefaultSession", "default session", "extended diagnostic",
               "programming session"]
SECURITY_RE = re.compile(r"security.?access|seed|密钥|0x27", re.I)
KEYSRC_RE = re.compile(r"\b(?:cmac|aes|ctr)\b|seed[\s_\-]?key|密钥值|proofofownership|encryptionauthentication", re.I)

SID_NAMES = {
    0x10: "DiagnosticSessionControl", 0x11: "ECUReset", 0x14: "ClearDTC",
    0x19: "ReadDTC", 0x22: "ReadDataByID", 0x23: "ReadMemByAddr",
    0x27: "SecurityAccess", 0x28: "CommControl", 0x2E: "WriteDataByID",
    0x31: "RoutineControl", 0x34: "RequestDownload", 0x36: "TransferData",
    0x37: "RequestExitTransfer", 0x3E: "TesterPresent", 0x85: "ControlDTCSetting",
}

SCORE_WEIGHTS = {"kw": 1, "sid": 3, "did": 3, "req": 5, "shall": 2,
                 "frame": 4, "timing": 3, "nrc": 2}


# ======================================================================
# 输入解析：行 + 行级页码
# ======================================================================
def load_txt_lines(path):
    """txt/md（含 srs-doc-extract 的 PAGE 标记）→ (lines, pages, extra)"""
    lines, pages = [], []
    cur = 0
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for raw in f:
            m = PAGE_MARK_RE.match(raw.rstrip("\r\n"))
            if m:
                cur = int(m.group(1))
                continue
            lines.append(raw.rstrip("\r\n"))
            pages.append(cur)
    return lines, pages, {"has_page_marks": cur > 0}


def load_docx_lines(path):
    """docx → 段落与表格**按文档顺序**交织为行（页码未知置 0）"""
    try:
        import docx
        from docx.table import Table
        from docx.text.paragraph import Paragraph
        from docx.oxml.ns import qn
    except ImportError:
        sys.exit("[ERROR] 解析 docx 需要 python-docx：pip install python-docx")
    d = docx.Document(path)
    lines, headings = [], []
    n_para = n_tbl = 0
    for child in d.element.body.iterchildren():
        if child.tag == qn("w:p"):
            p = Paragraph(child, d)
            t = p.text.strip()
            if not t:
                continue
            lines.append(t)
            n_para += 1
            st = (p.style.name or "") if p.style else ""
            if "heading" in st.lower():
                headings.append(t)
        elif child.tag == qn("w:tbl"):
            tb = Table(child, d)
            for row in tb.rows:
                cells = [c.text.strip() for c in row.cells]
                if any(cells):
                    lines.append(" | ".join(cells))
            n_tbl += 1
    return lines, [0] * len(lines), {"paras": n_para, "tables": n_tbl,
                                     "style_headings": headings[:200]}


def load_pdf_lines(path):
    """明文/普通加密 PDF → fitz 逐页（深层加密先走 srs-doc-extract）"""
    raw_head = open(path, "rb").read(32)
    if raw_head.startswith(b"%TSD-Header"):
        sys.exit("[ERROR] 该 PDF 是 DLP 深层加密文件（%TSD-Header）。"
                 "请先走 srs-doc-extract 技能解密为明文 txt，再传入本脚本。")
    try:
        import fitz
    except ImportError:
        sys.exit("[ERROR] 解析 PDF 需要 PyMuPDF：pip install PyMuPDF")
    doc = fitz.open(path)
    if doc.is_encrypted:
        try:
            doc.authenticate("")
        except Exception:
            sys.exit("[ERROR] PDF 带密码且空密码无法打开，请提供无密码副本。")
    lines, pages = [], []
    for i, page in enumerate(doc):
        for t in page.get_text().splitlines():
            if t.strip():
                lines.append(t.rstrip())
                pages.append(i + 1)
    return lines, pages, {"pdf_pages": len(doc)}


def load_input(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".txt", ".md"):
        return load_txt_lines(path)
    if ext == ".docx":
        return load_docx_lines(path)
    if ext == ".pdf":
        return load_pdf_lines(path)
    sys.exit("[ERROR] 不支持的文件类型 %s（支持 .txt/.md/.docx/.pdf）" % ext)


# ======================================================================
# 骨架层：章节树
# ======================================================================
def detect_headings(lines, style_headings=None):
    """返回 [(line_idx, sec_id, title)]；编号标题 + docx 样式标题兜底

    docx 样式标题 ≥5 个时进入 style_mode：单级编号行（"1. xxx"）大概率是
    功能块内的列表项，不再当章节（多级编号如 "4.1.6" 仍保留）；
    样式标题不足时回退全量识别（txt/PDF 无样式信息，行为不变）。
    """
    style_mode = bool(style_headings) and len(style_headings) >= 5
    num_re = re.compile(r"^\s*\d+\.\d+" ) if style_mode else None
    heads = []
    n = len(lines)
    for i, ln in enumerate(lines):
        s = ln.strip()
        # 含 "|" 的行是表格行（docx 表格按 " | " 连接），绝不当标题——否则
        # 首格为数字的表格行会伪装成编号标题，把骨架撕成几百个碎片
        if len(s) > 130 or HEX_PAIR_RE.search(s) or "|" in s:
            continue
        m = HEAD_RE.match(s)
        if not m and NUM_ONLY_RE.match(s):
            # 两行式标题：本行只有编号，标题取下一个非空行（PDF 排版常见）
            num = NUM_ONLY_RE.match(s).group(1)
            # 仅带点编号（"7.2"/"11.3.1"）参与合并：裸数字行几乎都是页脚页码，
            # "0.x"/超长段（"1.6964"）是表格数值行，不是章节号
            if "." not in num or not plausible_sec_id(num):
                continue
            for j in range(i + 1, min(i + 4, n)):
                t = lines[j].strip()
                if not t:
                    continue
                if (len(t) <= 130 and "|" not in t and not HEX_PAIR_RE.search(t)
                        and not BAD_TITLE_START_RE.match(t) and len(t) >= 2
                        and not NUM_ONLY_RE.match(t) and not DOT_LEADER_RE.search(t)
                        and not BAD_TITLE_TEXT_RE.search(t) and not UNIT_TITLE_RE.match(t)):
                    m2 = HEAD_RE.match(t)
                    if m2:  # 下一行自己就是完整标题，不合并
                        break
                    heads.append((i, num, t))
            continue
        if m:
            if num_re and not num_re.match(s):
                continue  # style_mode：单级编号行视为列表项
            if not plausible_sec_id(m.group(1)):
                continue  # "1.6964"/"0.9996"类表格数值行，不是章节号（ISO 542 页实测）
            title = m.group(2).strip()
            # 纯 ASCII 超短标题（"GB"＝闪存表行"4 GB"）不是标题；中文短标题（"概观"）合法
            if len(title) < 5 and not re.search(r"[\u4e00-\u9fff]", title):
                continue
            if (len(title) >= 2 and not BAD_TITLE_START_RE.match(title)
                    and not DOT_LEADER_RE.search(title)
                    and not BAD_TITLE_TEXT_RE.search(title)
                    and not UNIT_TITLE_RE.match(title)):
                heads.append((i, m.group(1).rstrip("."), title))
    # docx 样式标题兜底：样式标题文本与某行相同则登记（无编号也能建骨架）
    if style_headings:
        known = {h[1] for h in heads}
        for sh in style_headings:
            if sh in known:
                continue
            for i, ln in enumerate(lines):
                if ln.strip() == sh:
                    heads.append((i, "", sh))
                    break
    heads.sort(key=lambda x: x[0])
    # 大文档（542 页 ISO）TOC+正文标题候选远超 400，旧上限把 61 页后的真实章节
    # 全部截掉（Top-1 变成 47 万字符的吞噬章节）——上限提到 2000 并暴露截断标记
    detect_headings.truncated = max(0, len(heads) - 2000)
    return heads[:2000]


def build_sections(lines, pages, heads, fallback_block=400):
    """把行归入章节；返回 sections 列表（含 line_start/line_end 行区间）"""
    if not heads:
        # 无编号标题 → 按块分段，保证骨架可用（功能风格文档兜底）
        heads = []
        for start in range(0, len(lines), fallback_block):
            end = min(start + fallback_block, len(lines))
            pg = pages[start] if start < len(pages) else 0
            heads.append((start, "BLOCK-%03d" % (start // fallback_block + 1),
                          "分段 %d（页 %d 起）" % (start // fallback_block + 1, pg)))
        if not heads:
            heads = [(0, "BLOCK-001", "全文")]
    sections = []
    for k, (li, sid, title) in enumerate(heads):
        nxt = heads[k + 1][0] if k + 1 < len(heads) else len(lines)
        sections.append({
            "id": sid or "H%03d" % (k + 1),
            "title": title,
            "line_start": li,
            "line_end": nxt - 1,
            "page_start": pages[li] if li < len(pages) else 0,
            "page_end": pages[nxt - 1] if nxt - 1 < len(pages) and nxt - 1 >= li else 0,
        })
    # 前置页（第一个标题之前的行）
    if sections and sections[0]["line_start"] > 0:
        pre = {"id": "PRE", "title": "（封面/前置页）", "line_start": 0,
               "line_end": sections[0]["line_start"] - 1,
               "page_start": pages[0] if pages else 0,
               "page_end": pages[sections[0]["line_start"] - 1] if sections[0]["line_start"] - 1 < len(pages) else 0}
        sections.insert(0, pre)
    # id 去重：多张表格/多级文档会出现重复编号（1、2、3…），加 #n 后缀保证唯一
    seen = {}
    for sec in sections:
        base = sec["id"]
        if base in seen:
            seen[base] += 1
            sec["id"] = "%s#%d" % (base, seen[base])
        else:
            seen[base] = 1
    # 行 → 章节映射
    owner = [None] * len(lines)
    si = -1
    for i in range(len(lines)):
        while si + 1 < len(sections) and sections[si + 1]["line_start"] <= i:
            si += 1
        owner[i] = si if si >= 0 else 0
    return sections, owner


# ======================================================================
# 聚焦层：相关性打分
# ======================================================================
def score_sections(lines, owner, sections):
    text_per_sec = ["" for _ in sections]
    for i, ln in enumerate(lines):
        o = owner[i] if owner[i] is not None else 0
        if 0 <= o < len(text_per_sec):
            text_per_sec[o] += ln + "\n"
    for idx, sec in enumerate(sections):
        t = text_per_sec[idx]
        low = t.lower()
        kw_hits = {}
        for k, kws in DIAG_KEYWORDS.items():
            c = sum(low.count(kw.lower()) for kw in kws)
            if c:
                kw_hits[k] = min(c, 50)
        sids = len(SID_RE.findall(t))
        dids = len(set(DID_RE.findall(t)))
        reqs = len(re.findall(r"\bREQ-[\w.\-]+", t))
        shall = len(SHALL_RE.findall(t))
        frames = len(FRAME_RE.findall(t))
        timing = len(TIMING_RE.findall(t))
        nrc = len(NRC_RE.findall(t)) + len(NEGFMT_RE.findall(t))
        score = (sum(kw_hits.values()) * SCORE_WEIGHTS["kw"]
                 + sids * SCORE_WEIGHTS["sid"] + dids * SCORE_WEIGHTS["did"]
                 + reqs * SCORE_WEIGHTS["req"] + shall * SCORE_WEIGHTS["shall"]
                 + frames * SCORE_WEIGHTS["frame"] + timing * SCORE_WEIGHTS["timing"]
                 + nrc * SCORE_WEIGHTS["nrc"])
        sec["chars"] = len(t)
        sec["score"] = score
        sec["signals"] = {"keyword_hits": kw_hits, "sid": sids, "did": dids,
                          "req": reqs, "shall": shall, "frame": frames,
                          "timing": timing, "nrc": nrc}


# ======================================================================
# 事实层：结构化抽取（每条带页码证据）
# ======================================================================
def extract_facts(lines, pages, owner, sections):
    facts = {"req_blocks": [], "frames": [], "dids": [], "timing": [],
             "nrc_values": [], "sessions_detected": [], "security": {}}
    sec_id = lambda o: sections[o]["id"] if o is not None and 0 <= o < len(sections) else "?"

    # --- REQ 块 ---
    cur = None
    def close_req():
        nonlocal cur
        if cur:
            if len(facts["req_blocks"]) < 500:
                facts["req_blocks"].append(cur)
            cur = None
    for i, ln in enumerate(lines):
        s = ln.strip()
        m = REQ_START_RE.match(s)
        if m:
            close_req()
            cur = {"req_id": m.group(1), "title": (m.group(2) or "").strip()[:120],
                   "asil": "", "purpose": "", "shall_lines": [], "pages": [],
                   "section_id": sec_id(owner[i]), "auto_generated": False}
        elif cur is not None:
            if HEAD_RE.match(s) and not SHALL_RE.search(s):
                close_req()
                continue
            am = ASIL_RE.search(s)
            if am and not cur["asil"]:
                cur["asil"] = am.group(1)
            pm = PURPOSE_RE.search(s)
            if pm and not cur["purpose"]:
                cur["purpose"] = pm.group(1).strip()[:300]
            if SHALL_RE.search(s) and len(cur["shall_lines"]) < 12:
                cur["shall_lines"].append(s[:240])
        if cur is not None and i < len(pages):
            pg = pages[i]
            if pg and pg not in cur["pages"]:
                cur["pages"].append(pg)
    close_req()

    # --- 功能风格兜底：无 REQ 块时按相关章节自动生成追溯 ID ---
    if not facts["req_blocks"]:
        seq = {}
        for idx, sec in enumerate(sections):
            sig = sec.get("signals") or {}
            if (sig.get("sid", 0) + sig.get("frame", 0) + sig.get("did", 0)) > 0 or "Diagnostic" in (sig.get("keyword_hits") or {}):
                slug = re.sub(r"[^A-Za-z0-9]", "", sec["id"])[:10] or "S%02d" % (idx + 1)
                seq[slug] = seq.get(slug, 0) + 1
                facts["req_blocks"].append({
                    "req_id": "REQ-%s.%02d" % (slug, seq[slug]),
                    "title": sec["title"][:120], "asil": "", "purpose": "",
                    "shall_lines": [], "pages": [sec["page_start"]] if sec["page_start"] else [],
                    "section_id": sec["id"], "auto_generated": True})
                if len(facts["req_blocks"]) >= 200:
                    break

    # --- 诊断帧（含 NAD 前缀 LIN 帧的 SID/DID 识别） ---
    seen_frames = set()
    for i, ln in enumerate(lines):
        for m in FRAME_RE.finditer(ln):
            hexs = re.sub(r"[^0-9A-Fa-f]", "", m.group(1))
            if len(hexs) < 10:
                continue
            frame = " ".join(hexs[j:j + 2] for j in range(0, len(hexs), 2))
            if frame in seen_frames:
                continue
            seen_frames.add(frame)
            sid, did = None, None
            for pos in (0, 2, 4):  # 0=SID开头；2=CAN PCI开头；4=LIN NAD+PCI开头
                if pos + 2 <= len(hexs) and int(hexs[pos:pos + 2], 16) in SID_NAMES:
                    sid = int(hexs[pos:pos + 2], 16)
                    if sid in (0x22, 0x2E) and len(hexs) >= pos + 6:
                        cand = hexs[pos + 2:pos + 6].upper()
                        if re.fullmatch(r"[0-9A-F]{4}", cand):
                            did = cand
                    break
            if len(facts["frames"]) < 300:
                facts["frames"].append({
                    "frame": frame, "sid": ("0x%02X" % sid) if sid is not None else None,
                    "sid_name": SID_NAMES.get(sid), "did": ("0x" + did) if did else None,
                    "page": pages[i] if i < len(pages) else 0,
                    "section_id": sec_id(owner[i])})
    # --- DID（F1xx 形态 + 帧内提取） ---
    did_pages = {}
    did_ctx = {}
    for i, ln in enumerate(lines):
        for m in DID_RE.finditer(ln):
            d = m.group(0).upper().replace("0X", "")
            d = d[-4:]
            did_pages.setdefault(d, [])
            if pages[i] and pages[i] not in did_pages[d] and len(did_pages[d]) < 8:
                did_pages[d].append(pages[i])
            did_ctx.setdefault(d, ln.strip()[:100])
    for f in facts["frames"]:
        if f.get("did"):
            d = f["did"][2:]
            did_pages.setdefault(d, [])
            if f["page"] and f["page"] not in did_pages[d] and len(did_pages[d]) < 8:
                did_pages[d].append(f["page"])
    for d, pgs in did_pages.items():
        if len(facts["dids"]) < 100:
            facts["dids"].append({"did": "0x" + d, "pages": pgs,
                                  "context": did_ctx.get(d, "")})
    facts["dids"].sort(key=lambda x: x["did"])

    # --- 时序参数 ---
    for i, ln in enumerate(lines):
        for m in TIMING_RE.finditer(ln):
            if len(facts["timing"]) < 200:
                facts["timing"].append({
                    "param": m.group(1), "value": m.group(2),
                    "unit": m.group(3) or "", "page": pages[i] if i < len(pages) else 0,
                    "snippet": ln.strip()[:120]})
    # --- NRC ---
    nrcs = []
    for i, ln in enumerate(lines):
        for m in NRC_RE.finditer(ln):
            v = "0x" + m.group(1).upper()
            if v not in nrcs:
                nrcs.append(v)
        for m in NEGFMT_RE.finditer(ln):
            v = "0x" + m.group(1).upper()
            if v not in nrcs:
                nrcs.append(v)
    facts["nrc_values"] = nrcs[:40]
    # --- 会话 ---
    sess_pages = {}
    low_lines = [ln.lower() for ln in lines]
    for kw in SESSION_KWS:
        pgs = []
        for i, low in enumerate(low_lines):
            if kw.lower() in low:
                pg = pages[i] if i < len(pages) else 0
                if pg and pg not in pgs and len(pgs) < 10:
                    pgs.append(pg)
        if pgs:
            sess_pages[kw] = pgs
    facts["sessions_detected"] = sorted(sess_pages.keys())
    facts["sessions_pages"] = sess_pages
    # --- 安全 ---
    sec_pgs, key_src = [], False
    for i, low in enumerate(low_lines):
        if SECURITY_RE.search(low):
            pg = pages[i] if i < len(pages) else 0
            if pg and pg not in sec_pgs and len(sec_pgs) < 15:
                sec_pgs.append(pg)
        if not key_src and KEYSRC_RE.search(low):
            key_src = True
    facts["security"] = {"mentioned": bool(sec_pgs), "pages": sec_pgs,
                         "key_source_hint": key_src}
    return facts


# ======================================================================
# 裁剪层：Top-N 章节原文落盘
# ======================================================================
def safe_slug(text, limit=40):
    s = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_")
    return s[:limit] if s else ""


def write_section_files(lines, sections, out_dir, top_n, max_chars):
    os.makedirs(os.path.join(out_dir, "sections"), exist_ok=True)
    eligible = [s for s in sections if s.get("score", 0) > 0 and s.get("chars", 0) >= 80]
    # 插图/表格标题块降权（NOTE-SWRS 实测："Figure: Software Signing Tool" 等插图块
    # 因密钥/哈希关键词密集霸榜 Top，需求正文应排在前面；图/表仍保留在 sections 全集中）
    figure_re = re.compile(r"^\s*(figure|fig\.|table|图|表)\b", re.I)
    eligible.sort(key=lambda s: (-s["score"] * (0.3 if figure_re.match(s.get("title") or "") else 1.0),
                                 s["line_start"]))
    chosen = eligible[:top_n]
    written = {}
    for k, sec in enumerate(chosen, 1):
        chunk = lines[sec["line_start"]:sec["line_end"] + 1]
        body = "\n".join(chunk)
        truncated = False
        if len(body) > max_chars:
            body = body[:max_chars]
            truncated = True
        sid = re.sub(r"[^A-Za-z0-9]", "_", sec["id"]) or "S%02d" % k
        fname = "S%02d_%s_%s.md" % (k, sid, safe_slug(sec["title"]) or "sec")
        pg = "页 %s-%s" % (sec["page_start"], sec["page_end"]) if sec["page_start"] else "无页码（docx）"
        header = ("<!-- section %s %s | %s | score=%s | chars=%d -->\n"
                  % (sec["id"], sec["title"], pg, sec["score"], sec["chars"]))
        if truncated:
            body += "\n\n[TRUNCATED: 章节共 %d 字符，仅展示前 %d；用 --dump-section \"%s\" 取全文]\n" % (
                sec["chars"], max_chars, sec["id"])
        with open(os.path.join(out_dir, "sections", fname), "w", encoding="utf-8", newline="\n") as f:
            f.write(header + body + "\n")
        written[sec["id"]] = {"file": "sections/" + fname, "truncated": truncated}
    return written, [s["id"] for s in chosen]


def dump_section(input_path, map_path, out_dir, sec_id):
    """按需钻取：从 srs_map.json 找到章节行区间，输出全文"""
    with open(map_path, encoding="utf-8") as f:
        m = json.load(f)
    sec = None
    for s in m["sections"]:
        if s["id"] == sec_id or s["title"].strip() == sec_id.strip():
            sec = s
            break
    if not sec:
        print("[ERROR] 章节未找到: %s（可先查看 srs_map.json 的 sections 列表）" % sec_id)
        return 4
    lines, pages, _ = load_input(input_path)
    chunk = lines[sec["line_start"]:sec["line_end"] + 1]
    os.makedirs(os.path.join(out_dir, "sections"), exist_ok=True)
    fname = "FULL_%s_%s.md" % (re.sub(r"[^A-Za-z0-9]", "_", sec["id"]) or "S", safe_slug(sec["title"]) or "sec")
    out = os.path.join(out_dir, "sections", fname)
    pg = "页 %s-%s" % (sec["page_start"], sec["page_end"]) if sec["page_start"] else "无页码（docx）"
    with open(out, "w", encoding="utf-8", newline="\n") as f:
        f.write("<!-- section %s %s | %s | FULL DUMP -->\n" % (sec["id"], sec["title"], pg))
        f.write("\n".join(chunk) + "\n")
    print("DUMP ok=True section=%s file=%s lines=%d" % (sec["id"], out, len(chunk)))
    return 0


# ======================================================================
# 报告
# ======================================================================
def render_report(doc_meta, sections, top_ids, facts, written):
    L = []
    L.append("# SRS 精读报告（srs_focus_extractor）\n")
    L.append("## 文档总览")
    L.append("- 文件：%s" % doc_meta["path"])
    L.append("- 篇幅：%s ｜ 字符数：%d ｜ 章节数：%d" % (
        doc_meta.get("pages_str", "?"), doc_meta["total_chars"], len(sections)))
    style = doc_meta.get("style", "?")
    L.append("- 文档风格：**%s**" % {"req": "Volvo REQ 编号风格（REQ-xxxx 提取就绪）",
                              "functional": "功能风格（无 REQ 编号，已自动生成追溯 ID）",
                              "mixed": "混合风格（原始 REQ + 自动生成并存）",
                              "none": "未发现 UDS 相关内容"}.get(style, style))
    L.append("")
    L.append("## 精读顺序（按 UDS 相关性打分 Top-%d，先读这些章节）" % len(top_ids))
    L.append("| 顺序 | 章节 | 标题 | 页码 | 分数 | REQ | DID | 帧 | 时序 | NRC |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    sec_by_id = {s["id"]: s for s in sections}
    for rank, sid in enumerate(top_ids, 1):
        s = sec_by_id.get(sid, {})
        sig = s.get("signals", {})
        pg = ("%s-%s" % (s.get("page_start"), s.get("page_end"))) if s.get("page_start") else "-"
        L.append("| %d | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
            rank, sid, (s.get("title") or "")[:40], pg, s.get("score", 0),
            sig.get("req", 0), sig.get("did", 0), sig.get("frame", 0),
            sig.get("timing", 0), sig.get("nrc", 0)))
    L.append("")
    L.append("## 事实摘要（全文结构化证据，页码见 srs_facts.json）")
    reqs = facts["req_blocks"]
    auto = sum(1 for r in reqs if r["auto_generated"])
    L.append("- REQ 块：**%d 条**（%s）" % (
        len(reqs), "其中 %d 条为功能风格自动生成" % auto if auto else "全部带原始 REQ 编号"))
    for r in reqs[:10]:
        pg = ("页 " + ",".join(map(str, r["pages"][:4]))) if r["pages"] else "-"
        L.append("  - `%s` %s（%s%s）" % (r["req_id"], r["title"][:60], pg,
                                   "，ASIL %s" % r["asil"] if r["asil"] else ""))
    if len(reqs) > 10:
        L.append("  - …其余 %d 条见 srs_facts.json" % (len(reqs) - 10))
    L.append("- 诊断帧：%d 种（含 SID/DID 识别）｜ DID：%s" % (
        len(facts["frames"]),
        ", ".join(d["did"] for d in facts["dids"][:12]) + ("…" if len(facts["dids"]) > 12 else "") or "未发现"))
    if facts["timing"]:
        L.append("- 时序参数：")
        seen = set()
        for t in facts["timing"]:
            key = (t["param"].upper(), t["value"])
            if key in seen:
                continue
            seen.add(key)
            L.append("  - %s = %s %s（页 %s）" % (t["param"], t["value"], t["unit"], t["page"]))
            if len(seen) >= 10:
                break
    if facts["nrc_values"]:
        L.append("- NRC 值：%s" % ", ".join(facts["nrc_values"]))
    if facts["sessions_detected"]:
        L.append("- 会话：%s" % ", ".join(facts["sessions_detected"]))
    L.append("- 安全访问：%s（密钥/算法线索：%s）" % (
        "有提及，页 " + ",".join(map(str, facts["security"]["pages"][:6])) if facts["security"]["mentioned"] else "未提及",
        "有" if facts["security"]["key_source_hint"] else "未发现 → 0x27 正例执行前需补密钥资料"))
    L.append("")
    L.append("## 精读指引（给 LLM 的使用说明）")
    L.append("1. 先读 `srs_map.json`（骨架与排序），再读 `srs_facts.json`（结构化事实）——**不要通读原文 txt**")
    L.append("2. 深入分析时只读 `sections/` 下的高分章节裁剪；发现截断或需要某章节全文：")
    L.append("   `python srs_focus_extractor.py <原文> --out-dir <同目录> --dump-section \"章节号\"`")
    L.append("3. 每条事实均带页码/章节证据，写用例「需求来源/时序引用」时直接引用，不要凭记忆改写数值")
    if written:
        L.append("")
        L.append("## 已落盘章节裁剪")
        for sid, info in written.items():
            L.append("- %s → `%s`%s" % (sid, info["file"], "（截断）" if info["truncated"] else ""))
    return "\n".join(L)


# ======================================================================
# 主流程
# ======================================================================
def run_extract(input_path, out_dir, top_n=12, max_section_chars=20000):
    if not os.path.exists(input_path):
        print("[ERROR] 文件不存在: %s" % input_path)
        return 4
    os.makedirs(out_dir, exist_ok=True)
    lines, pages, extra = load_input(input_path)
    if not lines:
        print("[ERROR] 未解析到任何文本行")
        return 3
    style_headings = extra.get("style_headings")
    heads = detect_headings(lines, style_headings)
    heading_truncated = getattr(detect_headings, "truncated", 0)
    sections, owner = build_sections(lines, pages, heads)
    score_sections(lines, owner, sections)
    facts = extract_facts(lines, pages, owner, sections)

    total_score = sum(s["score"] for s in sections)
    orig_reqs = [r for r in facts["req_blocks"] if not r["auto_generated"]]
    auto_reqs = [r for r in facts["req_blocks"] if r["auto_generated"]]
    if orig_reqs and auto_reqs:
        style = "mixed"
    elif orig_reqs:
        style = "req"
    elif auto_reqs:
        style = "functional"
    else:
        style = "none"
    # 有无「强证据」（结构化事实），决定退出码：弱关键词命中不算发现
    strong = bool(facts["frames"] or facts["dids"] or facts["timing"]
                  or facts["nrc_values"] or facts["sessions_detected"]
                  or facts["security"]["mentioned"] or orig_reqs)
    pages_str = ("页 %d" % max([p for p in pages if p] or [0])) if any(pages) else "docx 无页码"
    doc_meta = {"path": os.path.abspath(input_path), "total_chars": sum(len(l) for l in lines),
                "pages_str": pages_str, "style": style,
                "skeleton_truncated": heading_truncated,
                "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
                "extra": {k: v for k, v in extra.items() if k != "style_headings"}}

    written, top_ids = write_section_files(lines, sections, out_dir, top_n, max_section_chars)
    for sid, info in written.items():
        for s in sections:
            if s["id"] == sid:
                s["file"] = info["file"]
                s["truncated"] = info["truncated"]

    # map（含行区间，供 --dump-section 复用）
    mmap = {"doc": doc_meta, "top_sections": top_ids, "sections": sections}
    with open(os.path.join(out_dir, "srs_map.json"), "w", encoding="utf-8") as f:
        json.dump(mmap, f, ensure_ascii=False, indent=2)
    with open(os.path.join(out_dir, "srs_facts.json"), "w", encoding="utf-8") as f:
        json.dump(facts, f, ensure_ascii=False, indent=2)
    report = render_report(doc_meta, sections, top_ids, facts, written)
    with open(os.path.join(out_dir, "FOCUS_REPORT.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write(report + "\n")

    print(report)
    print("\nRESULT ok=%s style=%s sections=%d top=%s facts_req=%d frames=%d dids=%d out=%s" % (
        strong, style, len(sections), ",".join(top_ids[:5]),
        len(facts["req_blocks"]), len(facts["frames"]), len(facts["dids"]), out_dir))
    return 0 if strong else 2


def main():
    ap = argparse.ArgumentParser(description="SRS 全文精读分层抽取：骨架→聚焦→事实→裁剪")
    ap.add_argument("input", help="输入文件（.txt/.md/.docx/.pdf；加密 PDF 先走 srs-doc-extract）")
    ap.add_argument("--out-dir", required=True, help="输出目录（srs_map.json / srs_facts.json / sections/ / FOCUS_REPORT.md）")
    ap.add_argument("--top", type=int, default=12, help="落盘原文裁剪的高分章节数（默认 12）")
    ap.add_argument("--max-section-chars", type=int, default=20000, help="单章节裁剪最大字符数（默认 20000）")
    ap.add_argument("--dump-section", default=None, help="钻取指定章节全文（按章节号或标题），写入 sections/FULL_*.md")
    args = ap.parse_args()

    if args.dump_section:
        map_path = os.path.join(args.out_dir, "srs_map.json")
        if not os.path.exists(map_path):
            print("[ERROR] 未找到 %s，请先不带 --dump-section 运行一次完整抽取" % map_path)
            sys.exit(4)
        sys.exit(dump_section(args.input, map_path, args.out_dir, args.dump_section))
    sys.exit(run_extract(args.input, args.out_dir, args.top, args.max_section_chars))


if __name__ == "__main__":
    main()
