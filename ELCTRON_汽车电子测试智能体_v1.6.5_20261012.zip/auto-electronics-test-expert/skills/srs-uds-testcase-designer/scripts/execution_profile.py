# -*- coding: utf-8 -*-
"""Validate the machine-local execution profile without importing project facts."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

try:
    from portable_pack_reader import load_json, sha256_file
except ImportError:  # pragma: no cover - package import fallback
    from .portable_pack_reader import load_json, sha256_file


SCHEMA = "portable-contract/v0.1"
SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")
DRIVE_RE = re.compile(r"^[A-Za-z]:")
SECRET_FIELDS = {
    "key",
    "key_bytes",
    "key_value",
    "private_key",
    "secret",
    "secret_value",
    "password",
    "token",
}


class ExecutionProfileError(ValueError):
    """Raised when an execution profile cannot be safely bound to a project."""


def _required_text(value: Any, name: str) -> str:
    result = str(value or "").strip()
    if not result:
        raise ExecutionProfileError(f"执行 profile 缺少 {name}")
    return result


def _walk_secret_fields(value: Any, path: str = "") -> None:
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_text = str(key)
            if key_text.lower() in SECRET_FIELDS:
                raise ExecutionProfileError(f"执行 profile 禁止包含密钥字段: {path}{key_text}")
            _walk_secret_fields(child, f"{path}{key_text}.")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _walk_secret_fields(child, f"{path}[{index}].")


def _resolve_profile_reference(profile_file: Path, raw_path: Any) -> Path:
    """Resolve a profile-local POSIX path; unlike pack paths, ``..`` is allowed."""
    value = _required_text(raw_path, "project_context.path")
    if "\x00" in value or "\\" in value or value.startswith("/") or DRIVE_RE.match(value):
        raise ExecutionProfileError("执行 profile 的 project_context.path 必须是使用 / 的相对路径")
    parts = PurePosixPath(value).parts
    if not parts or any(part in ("", ".") for part in parts):
        raise ExecutionProfileError("执行 profile 的 project_context.path 含有非法路径段")
    return (profile_file.parent / Path(*parts)).resolve()


def _validate_profile_shape(profile: Mapping[str, Any]) -> None:
    if profile.get("$schema") not in (None, SCHEMA):
        raise ExecutionProfileError("执行 profile $schema 必须为 portable-contract/v0.1")
    if profile.get("schema_version") != SCHEMA:
        raise ExecutionProfileError("执行 profile schema_version 必须为 portable-contract/v0.1")
    _required_text(profile.get("profile_id"), "profile_id")

    context = profile.get("project_context")
    if not isinstance(context, Mapping):
        raise ExecutionProfileError("执行 profile 缺少 project_context 对象")
    _required_text(context.get("path"), "project_context.path")
    expected = _required_text(context.get("sha256"), "project_context.sha256")
    if not SHA256_RE.fullmatch(expected):
        raise ExecutionProfileError("project_context.sha256 必须是 64 位 SHA-256")

    runtime = profile.get("runtime")
    if not isinstance(runtime, Mapping):
        raise ExecutionProfileError("执行 profile 缺少 runtime 对象")
    _required_text(runtime.get("python"), "runtime.python")
    _required_text(runtime.get("working_directory"), "runtime.working_directory")

    transport = profile.get("transport")
    if not isinstance(transport, Mapping):
        raise ExecutionProfileError("执行 profile 缺少 transport 对象")
    _required_text(transport.get("adapter"), "transport.adapter")
    _required_text(transport.get("channel"), "transport.channel")
    _required_text(transport.get("library_path"), "transport.library_path")

    references = profile.get("secure_key_references")
    if not isinstance(references, list):
        raise ExecutionProfileError("执行 profile 缺少 secure_key_references 数组")
    for index, item in enumerate(references):
        if not isinstance(item, Mapping):
            raise ExecutionProfileError(f"secure_key_references[{index}] 必须是对象")
        for key in ("purpose", "provider", "reference"):
            _required_text(item.get(key), f"secure_key_references[{index}].{key}")
        if item.get("material_in_context") is not False:
            raise ExecutionProfileError(
                f"secure_key_references[{index}].material_in_context 必须为 false"
            )

    _walk_secret_fields(profile)


def validate_execution_profile(
    source: str | Path | Mapping[str, Any],
    *,
    project_context_path: str | Path | None = None,
    require_files: bool = False,
) -> dict[str, Any]:
    """Validate a profile and return a value-minimal binding summary.

    ``project_context_path`` lets a runner bind the profile to the selected
    project pack while keeping the profile itself machine-local. The returned
    summary intentionally excludes runtime paths and secret references.
    """
    profile_file: Path | None = None
    if isinstance(source, Mapping):
        profile = dict(source)
    else:
        profile_file = Path(source).expanduser().resolve()
        profile = load_json(profile_file)
    if not isinstance(profile, Mapping):
        raise ExecutionProfileError("执行 profile 根节点必须是对象")
    _validate_profile_shape(profile)

    context_spec = profile["project_context"]
    declared_context_file = None
    if profile_file is not None:
        # Validate the declared reference even when the runner supplies the
        # selected pack context as an explicit binding target.
        declared_context_file = _resolve_profile_reference(profile_file, context_spec.get("path"))
    if project_context_path is not None:
        context_file = Path(project_context_path).expanduser().resolve()
    elif declared_context_file is not None:
        context_file = declared_context_file
    else:
        raise ExecutionProfileError("内存 profile 必须显式提供 project_context_path")
    if not context_file.is_file():
        raise ExecutionProfileError(f"project_context 不存在: {context_file}")
    actual_sha256 = sha256_file(context_file)
    expected_sha256 = str(context_spec["sha256"]).lower()
    if actual_sha256.lower() != expected_sha256:
        raise ExecutionProfileError("project_context SHA-256 不匹配，拒绝绑定执行 profile")

    files_checked = []
    if require_files:
        runtime = profile["runtime"]
        transport = profile["transport"]
        for label, raw_path in (
            ("runtime.python", runtime["python"]),
            ("transport.library_path", transport["library_path"]),
        ):
            path = Path(str(raw_path).strip()).expanduser()
            if not path.is_file():
                raise ExecutionProfileError(f"{label} 不存在或不是文件: {raw_path}")
            files_checked.append(label)

    return {
        "$schema": SCHEMA,
        "schema_version": SCHEMA,
        "profile_id": str(profile["profile_id"]).strip(),
        "project_context": {"sha256": actual_sha256},
        "secure_key_reference_count": len(profile["secure_key_references"]),
        "files_checked": files_checked,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="校验机器本地 execution profile")
    parser.add_argument("--profile", required=True, help="execution_profile.local.json")
    parser.add_argument("--project-context", help="覆盖 profile 中 path 的 project_context.json")
    parser.add_argument("--require-files", action="store_true", help="同时检查 Python 和传输 DLL 文件")
    parser.add_argument("--out", help="输出脱敏后的绑定摘要 JSON")
    args = parser.parse_args(argv)
    try:
        result = validate_execution_profile(
            args.profile,
            project_context_path=args.project_context,
            require_files=args.require_files,
        )
    except (OSError, ExecutionProfileError, ValueError) as exc:
        print(f"[ERROR] execution profile 校验失败: {exc}")
        return 1
    if args.out:
        output = Path(args.out)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[OK] execution profile: {result['profile_id']} ({result['project_context']['sha256']})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["ExecutionProfileError", "SCHEMA", "validate_execution_profile"]
