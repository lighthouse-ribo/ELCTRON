#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""系统合格性测试用例模板生成器：对齐成熟 TRM 文件（14 sheet）结构"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from testcase_headers import HEADERS  # B5: 19 列表头唯一权威来源（xlsx 版文案，2026-09-04 用户决策）

HDR_FILL = PatternFill("solid", fgColor="4472C4")
SUB_FILL = PatternFill("solid", fgColor="D9E2F3")
HDR_FONT = Font(name="微软雅黑", size=9, bold=True, color="FFFFFF")
BODY_FONT = Font(name="微软雅黑", size=9)
TITLE_FONT = Font(name="微软雅黑", size=14, bold=True)
LBL_FONT = Font(name="微软雅黑", size=9, bold=True)
THIN = Side(style="thin", color="B0B0B0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="center")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)

COL_W = [14, 16, 18, 8, 10, 30, 12, 12, 10, 22, 34, 34, 10, 10, 10, 10, 10, 12, 12]
STATUS = ["P", "F", "NT", "NA"]
MODULES = ["UDS", "功能测试", "SWDL", "LIN网络", "网络安全", "环温稳定", "Module A"]


def sheet_meta(ws, module):
    """封面信息行 + 小统计"""
    ws.merge_cells("B2:T2")
    c = ws["B2"]; c.value = "客户名称: _________    产品型号: _________    测试对象: _________    用例日期: _________    用例作者: _________"
    c.font = LBL_FONT; c.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells("B3:T3")
    c = ws["B3"]; c.value = f"模块: {module}    测试版本: 软件版本_________ 硬件版本_________    SRS版本: _________"
    c.font = BODY_FONT; c.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[2].height = 22
    ws.row_dimensions[3].height = 22
    # 小统计区（R4~R6）
    ws["B4"] = "测试用例数据统计"; ws["B4"].font = TITLE_FONT
    ws.merge_cells("B4:T4")
    labels = [("B5", "状态"), ("C5", "P(PASS)"), ("D5", "F(FAIL)"), ("E5", "NT(未测试)"), ("F5", "NA(不适用)"),
              ("G5", "选择YES"), ("H5", "选择NO"), ("I5", "总用例数")]
    for pos, t in labels:
        ws[pos] = t; ws[pos].font = LBL_FONT; ws[pos].fill = SUB_FILL; ws[pos].alignment = CENTER; ws[pos].border = BORDER
    ws["B6"] = "统计"
    for pos, col in [("C6", "O"), ("D6", "O"), ("E6", "O"), ("F6", "O"), ("G6", "N"), ("H6", "N")]:
        status = {"C6": "P", "D6": "F", "E6": "NT", "F6": "NA"}.get(pos, "")
        ws[pos] = (f'=COUNTIF($O$8:$O$500,"{status}")' if status
                   else f'=COUNTIF($N$8:$N$500,"是")' if pos == "G6"
                   else f'=COUNTIF($N$8:$N$500,"否")')
        ws[pos].font = BODY_FONT; ws[pos].alignment = CENTER; ws[pos].border = BORDER
    ws["I6"] = "=COUNTA($D$8:$D$500)"
    ws["I6"].font = BODY_FONT; ws["I6"].alignment = CENTER; ws["I6"].border = BORDER
    ws["B6"].font = LBL_FONT; ws["B6"].fill = SUB_FILL; ws["B6"].alignment = CENTER; ws["B6"].border = BORDER
    for r in (5, 6):
        ws.row_dimensions[r].height = 18


def sheet_header(ws, row=7):
    for i, h in enumerate(HEADERS):
        col = get_column_letter(i + 2)
        c = ws[f"{col}{row}"]
        c.value = h; c.font = HDR_FONT; c.fill = HDR_FILL; c.alignment = CENTER; c.border = BORDER
        ws.column_dimensions[col].width = COL_W[i]
    ws.row_dimensions[row].height = 50


def sheet_body(ws, n_rows=40, row0=8):
    for r in range(row0, row0 + n_rows):
        for i in range(len(HEADERS)):
            col = get_column_letter(i + 2)
            c = ws[f"{col}{r}"]
            c.font = BODY_FONT; c.border = BORDER
            c.alignment = WRAP if i in (9, 10, 11, 5) else CENTER
        # 需求来源列（B 列，i=0）预填"系统规格书"
        ws[f"B{r}"] = "系统规格书"
        ws[f"B{r}"].alignment = CENTER
    ws.row_dimensions[r].height = 42


def data_validation(ws, row0=8, rowN=500):
    from openpyxl.worksheet.datavalidation import DataValidation
    dv_r = DataValidation(type="list", formula1='"P,F,NT,NA"', allow_blank=True, showDropDown=False)
    dv_n = DataValidation(type="list", formula1='"是,否"', allow_blank=True, showDropDown=False)
    dv_p = DataValidation(type="list", formula1='"L1,L2,L3"', allow_blank=True, showDropDown=False)
    ws.add_data_validation(dv_r); ws.add_data_validation(dv_n); ws.add_data_validation(dv_p)
    dv_r.add(f"O{row0}:O{rowN}"); dv_n.add(f"N{row0}:N{rowN}"); dv_p.add(f"E{row0}:E{rowN}")


def build(path):
    wb = openpyxl.Workbook()
    # 1) 封面
    ws = wb.active; ws.title = "封面Cover"
    ws.merge_cells("B2:T2"); ws["B2"] = "系统合格性测试用例"; ws["B2"].font = TITLE_FONT
    ws.merge_cells("B4:C4"); ws["B4"] = "客户名称 Customer Name"; ws["B4"].fill = SUB_FILL; ws["B4"].font = LBL_FONT; ws["B4"].border = BORDER
    ws.merge_cells("D4:G4"); ws["D4"] = ""; ws["D4"].border = BORDER
    ws.merge_cells("H4:I4"); ws["H4"] = "产品型号 Product Model"; ws["H4"].fill = SUB_FILL; ws["H4"].font = LBL_FONT; ws["H4"].border = BORDER
    ws.merge_cells("J4:M4"); ws["J4"] = ""; ws["J4"].border = BORDER
    ws.merge_cells("B5:C5"); ws["B5"] = "测试对象 Test Target"; ws["B5"].fill = SUB_FILL; ws["B5"].font = LBL_FONT; ws["B5"].border = BORDER
    ws.merge_cells("D5:G5"); ws["D5"] = ""; ws["D5"].border = BORDER
    ws.merge_cells("H5:I5"); ws["H5"] = "用例日期 创建日期"; ws["H5"].fill = SUB_FILL; ws["H5"].font = LBL_FONT; ws["H5"].border = BORDER
    ws.merge_cells("J5:M5"); ws["J5"] = ""; ws["J5"].border = BORDER
    ws.merge_cells("B6:C6"); ws["B6"] = "用例作者 Created By"; ws["B6"].fill = SUB_FILL; ws["B6"].font = LBL_FONT; ws["B6"].border = BORDER
    ws.merge_cells("D6:G6"); ws["D6"] = ""; ws["D6"].border = BORDER
    ws.merge_cells("H6:I6"); ws["H6"] = "SRS版本 SRS Version"; ws["H6"].fill = SUB_FILL; ws["H6"].font = LBL_FONT; ws["H6"].border = BORDER
    ws.merge_cells("J6:M6"); ws["J6"] = ""; ws["J6"].border = BORDER
    ws.merge_cells("B7:C7"); ws["B7"] = "测试版本 Test Version"; ws["B7"].fill = SUB_FILL; ws["B7"].font = LBL_FONT; ws["B7"].border = BORDER
    ws.merge_cells("D7:M7"); ws["D7"] = "软件版本：__________  硬件版本：__________"; ws["D7"].border = BORDER
    ws.merge_cells("B2:T2"); ws["B2"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 36
    for r in (4, 5, 6, 7):
        ws.row_dimensions[r].height = 20
    # 2) 模板修订记录
    ws = wb.create_sheet("模板修订记录")
    ws["B2"] = "版本"; ws["C2"] = "修订日期"; ws["D2"] = "修订内容"; ws["E2"] = "修订人"
    for pos in ("B2", "C2", "D2", "E2"):
        ws[pos].font = HDR_FONT; ws[pos].fill = HDR_FILL; ws[pos].border = BORDER; ws[pos].alignment = CENTER
    for r in range(3, 8):
        for col in ("B", "C", "D", "E"):
            ws[f"{col}{r}"].border = BORDER
    for i, w in zip("BCDE", (8, 14, 60, 12)):
        ws.column_dimensions[i].width = w
    # 3) 变更履历
    ws = wb.create_sheet("测试用例变更履历")
    ws["B2"] = "序号"; ws["C2"] = "变更日期"; ws["D2"] = "变更用例ID"; ws["E2"] = "变更内容"; ws["F2"] = "变更人"
    for pos in ("B2", "C2", "D2", "E2", "F2"):
        ws[pos].font = HDR_FONT; ws[pos].fill = HDR_FILL; ws[pos].border = BORDER; ws[pos].alignment = CENTER
    for r in range(3, 12):
        for col in ("B", "C", "D", "E", "F"):
            ws[f"{col}{r}"].border = BORDER
    for i, w in zip("BCDEF", (8, 14, 18, 60, 12)):
        ws.column_dimensions[i].width = w
    # 4) 测试说明
    ws = wb.create_sheet("测试说明")
    notes = [
        "1. 测试目的：验证 ECU 满足 SRS/SWRS 需求，覆盖 UDS 服务、LIN 通信、功能逻辑、刷写与网络安全。",
        "2. 用例设计方法：需求分析 / 等价类 / 边界值 / 错误推测；负例必须断言 NRC（0x12/0x13/0x22/0x31/0x33/0x35/0x7E）。",
        "3. 粒度选择：全量矩阵（对象驱动 200-300 条）/ 需求驱动 10 维（含 TimeParm 时序组，系统验收推荐）。",
        "4. 前置条件必填：受保护服务（0x27/0x2E/0x31/刷写）必须写清会话 + 安全解锁状态。",
        "5. 预期结果必填：正例写具体正响应报文；负例写 NRC。时序值以 SWRS 为准。",
        "6. 测试结果填写：P（PASS）/ F（FAIL）/ NT（未测试）/ NA（不适用），与数据汇总自动联动。",
        "7. 缺陷：F 用例必须填写缺陷编号并链接缺陷单。",
    ]
    for i, t in enumerate(notes):
        r = i + 2
        ws.merge_cells(f"B{r}:T{r}")
        ws[f"B{r}"] = t; ws[f"B{r}"].font = BODY_FONT; ws[f"B{r}"].alignment = WRAP
    ws.column_dimensions["B"].width = 120
    # 5) 数据汇总
    ws = wb.create_sheet("数据汇总")
    ws["B2"] = "1. 测试用例数据统计"; ws["B2"].font = TITLE_FONT
    ws.merge_cells("B3:D3"); ws["B3"] = "模块/状态"; ws["B3"].fill = SUB_FILL; ws["B3"].font = LBL_FONT; ws["B3"].border = BORDER; ws["B3"].alignment = CENTER
    for j, st in enumerate(STATUS):
        col = get_column_letter(5 + j)
        ws[f"{col}3"] = st; ws[f"{col}3"].fill = SUB_FILL; ws[f"{col}3"].font = LBL_FONT; ws[f"{col}3"].border = BORDER; ws[f"{col}3"].alignment = CENTER
    ws["I3"] = "选择YES"; ws["J3"] = "总用例数"; ws["K3"] = "需求数(去重)"
    for pos in ("I3", "J3", "K3"):
        ws[pos].fill = SUB_FILL; ws[pos].font = LBL_FONT; ws[pos].border = BORDER; ws[pos].alignment = CENTER
    for i, mod in enumerate(MODULES):
        r = 4 + i
        ws[f"B{r}"] = mod; ws[f"B{r}"].border = BORDER; ws[f"B{r}"].font = BODY_FONT
        ws[f"B{r}"].alignment = Alignment(horizontal="center", vertical="center")
        for j, st in enumerate(STATUS):
            col = get_column_letter(5 + j)
            ws[f"{col}{r}"] = f'=COUNTIF({mod}!$O$8:$O$500,"{st}")'
            ws[f"{col}{r}"].border = BORDER; ws[f"{col}{r}"].alignment = CENTER
        ws[f"I{r}"] = f'=COUNTIF({mod}!$N$8:$N$500,"是")'
        ws[f"J{r}"] = f'=COUNTA({mod}!$D$8:$D$500)'
        ws[f"I{r}"].border = BORDER; ws[f"J{r}"].border = BORDER
        ws[f"I{r}"].alignment = CENTER; ws[f"J{r}"].alignment = CENTER
        ws[f"K{r}"] = ""; ws[f"K{r}"].border = BORDER; ws[f"K{r}"].alignment = CENTER
    r = 4 + len(MODULES)
    ws[f"B{r}"] = "合计"; ws[f"B{r}"].font = LBL_FONT; ws[f"B{r}"].fill = SUB_FILL; ws[f"B{r}"].border = BORDER
    for j in range(len(STATUS)):
        col = get_column_letter(5 + j)
        ws[f"{col}{r}"] = f"=SUM({get_column_letter(5+j)}4:{get_column_letter(5+j)}{r-1})"
        ws[f"{col}{r}"].font = LBL_FONT; ws[f"{col}{r}"].fill = SUB_FILL; ws[f"{col}{r}"].border = BORDER; ws[f"{col}{r}"].alignment = CENTER
    ws[f"I{r}"] = f"=SUM(I4:I{r-1})"; ws[f"J{r}"] = f"=SUM(J4:J{r-1})"
    ws[f"I{r}"].font = LBL_FONT; ws[f"J{r}"].font = LBL_FONT
    ws[f"I{r}"].fill = SUB_FILL; ws[f"J{r}"].fill = SUB_FILL
    ws[f"I{r}"].border = BORDER; ws[f"J{r}"].border = BORDER
    ws[f"I{r}"].alignment = CENTER; ws[f"J{r}"].alignment = CENTER
    for col in "BCDEFGHIJK":
        ws.column_dimensions[col].width = 12
    ws.column_dimensions["B"].width = 18
    # 6) 各测试模块 sheet
    for mod in MODULES:
        ws = wb.create_sheet(mod)
        sheet_meta(ws, mod)
        sheet_header(ws)
        sheet_body(ws)
        data_validation(ws)
    # 7) 填写说明
    ws = wb.create_sheet("填写说明")
    tips = [
        ("需求来源", "需求文档名称（如：BBS_P519_V436_System Requirement_V3.1）"),
        ("需求ID", "SRS 需求编号或章节级 ID（如 REQ-ReadDID.01）；无编号项目按 章节+序号 自动生成"),
        ("用例ID", "UDS_<服务>_TC_<序号>（如 UDS_0x22_TC_0001）/ LN_TC_ / TC-BBS-STATE- / SWDL_"),
        ("优先级", "L1=核心/安全关键（0x27/0x2E 写/0x31/刷写必须 L1）；L2=边界/异常/恢复；L3=可选"),
        ("自动化评估", "是否可自动化执行：是/否"),
        ("测试点", "本条测什么（正向/负向/边界/时序/安全/恢复 + 场景描述）"),
        ("测试方法", "基于需求的测试 / 等价类 / 边界值 / 错误推测"),
        ("用例设计方法", "与测试方法一致或补充"),
        ("测试环境", "台架测试 / HIL / 实车"),
        ("前提条件", "供电电压/工作模式/会话状态/安全解锁状态（受保护服务必填）"),
        ("操作步骤", "报文级：测试仪请求 hex → 预期响应 hex → 时序/等待（如：51 03 22 F1 2E FF FF FF FF）"),
        ("预期结果", "正例写正响应报文；负例写 NRC（0x12/0x13/0x22/0x31/0x33/0x35/0x7E）；时序值以 SWRS 为准"),
        ("选择测试用例", "是否执行：是/否（下拉）"),
        ("测试结果", "P/F/NT/NA（下拉），自动联动数据汇总"),
        ("测试结论", "PASS / FAIL / 备注"),
        ("缺陷编号", "FAIL 时必填"),
        ("测试者/测试日期", "执行人 + 日期（YYYY.MM.DD）"),
        ("备注", "额外说明/截图引用"),
    ]
    ws["B2"] = "填写说明（各列含义）"; ws["B2"].font = TITLE_FONT
    for i, (k, v) in enumerate(tips):
        r = 3 + i
        ws[f"B{r}"] = k; ws[f"B{r}"].font = LBL_FONT; ws[f"B{r}"].fill = SUB_FILL; ws[f"B{r}"].border = BORDER
        ws.merge_cells(f"C{r}:H{r}")
        ws[f"C{r}"] = v; ws[f"C{r}"].font = BODY_FONT; ws[f"C{r}"].border = BORDER; ws[f"C{r}"].alignment = WRAP
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 90
    wb.save(path)
    print(f"OK 模板已生成: {path}")
    print(f"Sheet 数: {len(wb.sheetnames)} -> {wb.sheetnames}")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="重建/定制系统合格性测试用例模板 xlsx（13 sheet）")
    ap.add_argument("--out", "-o", required=True, help="输出模板 xlsx 路径（如 系统合格性测试用例模板.xlsx）")
    args = ap.parse_args()
    build(args.out)
