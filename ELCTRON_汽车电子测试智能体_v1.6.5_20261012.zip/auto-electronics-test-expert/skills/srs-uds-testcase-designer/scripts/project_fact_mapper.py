# -*- coding: utf-8 -*-
"""Map project-pack files to normalized fact IDs without parsing documents."""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Mapping


ROLE_FACT_DOMAINS = {
    "diag_survey": [
        "diagnostic.did_definition",
        "diagnostic.service_definition",
        "diagnostic.session_security",
        "diagnostic.timing",
    ],
    "did_checklist": ["diagnostic.did_evidence", "diagnostic.partition_support"],
    "project_config": ["diagnostic.session_config", "transport.config", "lint.rules"],
    "swrs": ["requirements.traceability"],
    "srs": ["requirements.system_context"],
    "lin_matrix": ["transport.physical_nad", "transport.bitrate", "transport.timing", "transport.frames"],
    "ldf": ["transport.frames", "transport.functional_nad", "transport.schedule"],
    "dbc": ["transport.frames", "transport.signals"],
    "security_key_doc": ["security.algorithm", "security.key_material"],
    "security_key_store": ["security.key_reference"],
    "flash_flowchart": ["swdl.sequence", "swdl.timing", "swdl.block_size"],
    "security_req_list": ["security.requirements"],
    "cdd": ["diagnostic.did_signal_definition"],
}


def build_project_fact_map(manifest: Mapping[str, Any], context: Mapping[str, Any]) -> dict[str, Any]:
    """Build a source index for later parsers; never copy fact values."""

    errors: list[str] = []
    entries = manifest.get("files") or []
    files_by_id: dict[str, Mapping[str, Any]] = {}
    for entry in entries:
        if not isinstance(entry, Mapping):
            errors.append("manifest files contains a non-object entry")
            continue
        file_id = entry.get("id")
        if not file_id:
            errors.append("manifest file is missing id")
            continue
        if file_id in files_by_id:
            errors.append(f"duplicate manifest file id: {file_id}")
        files_by_id[file_id] = entry

    facts_by_source: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    unattributed_facts: list[str] = []
    for fact in context.get("facts") or []:
        if not isinstance(fact, Mapping):
            errors.append("project context facts contains a non-object entry")
            continue
        fact_id = fact.get("id", "")
        source = fact.get("source")
        source_id = source.get("file_id") if isinstance(source, Mapping) else None
        if not source_id:
            unattributed_facts.append(fact_id)
            continue
        if source_id not in files_by_id:
            errors.append(f"fact {fact_id} references unknown file id: {source_id}")
            continue
        facts_by_source[source_id].append(fact)

    file_rows: list[dict[str, Any]] = []
    unmapped_files: list[str] = []
    for entry in entries:
        if not isinstance(entry, Mapping) or not entry.get("id"):
            continue
        file_id = entry["id"]
        role = entry.get("role", "other")
        fact_rows = facts_by_source.get(file_id, [])
        sensitivity = entry.get("sensitivity", "internal")
        if sensitivity == "secret":
            status = "metadata_only"
        elif fact_rows:
            status = "mapped"
        else:
            status = "unmapped"
            unmapped_files.append(file_id)
        file_rows.append({
            "file_id": file_id,
            "role": role,
            "partition": entry.get("partition", "shared"),
            "path": entry.get("path"),
            "sha256": entry.get("sha256"),
            "sensitivity": sensitivity,
            "expected_fact_domains": list(ROLE_FACT_DOMAINS.get(role, [])),
            "fact_ids": [fact.get("id") for fact in fact_rows],
            "status": status,
        })

    fact_rows = []
    for fact in context.get("facts") or []:
        if not isinstance(fact, Mapping):
            continue
        source = fact.get("source")
        source_id = source.get("file_id") if isinstance(source, Mapping) else None
        fact_rows.append({
            "fact_id": fact.get("id"),
            "partition": fact.get("partition"),
            "status": fact.get("status"),
            "source_file_id": source_id,
            "locator": source.get("locator") if isinstance(source, Mapping) else None,
        })

    return {
        "schema": "project-fact-map/v0.1",
        "files": file_rows,
        "facts": fact_rows,
        "unmapped_files": unmapped_files,
        "unattributed_facts": unattributed_facts,
        "errors": errors,
    }


__all__ = ["ROLE_FACT_DOMAINS", "build_project_fact_map"]
