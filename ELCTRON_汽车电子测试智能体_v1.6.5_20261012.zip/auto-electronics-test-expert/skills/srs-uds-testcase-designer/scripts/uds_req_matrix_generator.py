#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UDS 需求驱动 × 10 维展开生成器（对齐成熟 TRM 粒度，可跨项目移植）
================================================================
依据 references/uds-trm-expansion-rules.md 实现：
  对象 × 会话 × 寻址 × 正反 × 子功能 × 边界 × 安全 × 时序 × 恢复 × 抑制位

用法:
  python uds_req_matrix_generator.py "<调查表文件或目录(*_diagnostic.xlsx)>" \
      --out "<用例.json>" [--req-map "<服务->需求ID映射.json>"] [--sf-traverse]
      [--ro-dids F10A,F103] [--sa-session-map "<0x27等级会话映射.json>"]
  python uds_req_matrix_generator.py "<目录>" --out out.json   # 目录自动合并全部调查表

输出: case-schema 兼容 JSON（可直接喂 build_testcase_xlsx.py）
"""
import argparse, glob, json, os, re, sys
from collections import OrderedDict

SESS_NAME = {0x01: "默认会话", 0x02: "编程会话", 0x03: "扩展会话"}
NRC_NAMES = {"12": "subFunctionNotSupported", "13": "incorrectMessageLengthOrInvalidFormat",
             "22": "conditionsNotCorrect", "31": "requestOutOfRange", "33": "securityAccessDenied",
             "7E": "subFunctionNotSupportedInActiveSession", "7F": "serviceNotSupportedInActiveSession"}
DEFAULT_P2, DEFAULT_P2S, DEFAULT_S3 = 50, 5000, 5000
SA_SESSION_DEFAULT = {
    # 0x27 等级 -> 允许的正例会话（常见 SWRS 规则，如 REQ-90448：01/02 仅编程会话、05/06 仅扩展会话）
    0x01: [0x02], 0x02: [0x02],
    0x05: [0x03], 0x06: [0x03],
}


def _norm_rid(v):
    """规范化 RID：兼容整数单元格（206 -> '0206'）、hex 字符串（'0x0206'/'206'）"""
    if v is None:
        return None
    if isinstance(v, int):
        return "%04X" % (v & 0xFFFF)
    s = str(v).strip().upper().replace(" ", "")
    if s.startswith("0X"):
        s = s[2:]
    if re.fullmatch(r"[0-9A-F]{1,4}", s):
        return s.zfill(4)
    return None



def find_col(headers, *keys):
    for i, h in enumerate(headers):
        hs = (h or "").lower()
        if any(k.lower() in hs for k in keys):
            return i
    return None


def cv(row, idx):
    """安全取单元格文本（兼容 int/float/str/None）"""
    if idx is None or idx >= len(row) or row[idx] is None:
        return ""
    return str(row[idx]).strip()


def sheet_rows(ws, start_row):
    for i, row in enumerate(ws.iter_rows(min_row=start_row, values_only=True), start_row):
        if row and any(v is not None and str(v).strip() for v in row):
            yield i, row


def parse_sessions(s):
    out = []
    for tok in re.findall(r"[0-9A-Fa-f]{2}", str(s or "")):
        try:
            v = int(tok, 16)
            if v in (1, 2, 3):
                out.append(v)
        except ValueError:
            pass
    return sorted(set(out))


class Survey:
    def __init__(self, path):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        self.sheets = {sn: wb[sn] for sn in wb.sheetnames}
        self.protocol = self._protocol()
        self.services = self._services()
        self.dids = self._dids()
        self.rids = self._rids()
        self.timing = self._timing()
        wb.close()

    def _protocol(self):
        p = {}
        ws = self.sheets.get("Protocol")
        if ws:
            for _, row in sheet_rows(ws, 1):
                for a, b in zip(row, row[1:]):
                    if a and b and str(a).strip() and str(b).strip():
                        k = str(a).strip().lower()
                        if k in ("net type:", "bus rate:"):
                            p[k] = str(b).strip()
        return p

    def _services(self):
        svc = {}
        ws = self.sheets.get("Service")
        if not ws:
            return svc
        rows = list(sheet_rows(ws, 1))
        if not rows:
            return svc
        header_row = rows[0][0] + 1 if rows[0][0] == 1 else rows[0][0]
        headers = next(ws.iter_rows(min_row=header_row, max_row=header_row, values_only=True))
        c_svc = find_col(headers, "service")
        c_sub = find_col(headers, "sub-function")
        c_sess = find_col(headers, "session reference")
        c_addr = find_col(headers, "addressing support")
        c_sec = find_col(headers, "security access se")
        c_delay = find_col(headers, "delay time for ser")
        c_att = find_col(headers, "number of attempts")
        c_nrc = find_col(headers, "negative respo")
        cur = None
        for _, row in sheet_rows(ws, header_row + 1):
            sid = cv(row, c_svc)
            if re.fullmatch(r"[0-9A-Fa-f]{2}", sid):
                cur = int(sid, 16)
                svc.setdefault(cur, {"subs": [], "sessions": set(), "addr": set(), "nrc": set(),
                                     "sec": None, "delay": None, "attempts": None})
            if cur is None or cur not in svc:
                continue
            sub = cv(row, c_sub)
            m = re.match(r"([0-9A-Fa-f]{2})(?:/([0-9A-Fa-f]{2}))?", sub)
            if m:
                svc[cur]["subs"].append(int(m.group(1), 16))
            s = cv(row, c_sess)
            svc[cur]["sessions"] |= set(parse_sessions(s))
            a = cv(row, c_addr)
            svc[cur]["addr"] |= {t.strip() for t in a.replace(";", ",").split(",") if t.strip()}
            n = cv(row, c_nrc)
            svc[cur]["nrc"] |= set(re.findall(r"[0-9A-Fa-f]{2}", n))
            sec = cv(row, c_sec)
            if sec and sec.upper() != "NA":
                svc[cur]["sec"] = sec
            if c_delay is not None and row[c_delay] is not None:
                svc[cur]["delay"] = cv(row, c_delay)
            if c_att is not None and row[c_att] is not None:
                svc[cur]["attempts"] = cv(row, c_att)
        for k in svc:
            svc[k]["subs"] = sorted(set(svc[k]["subs"]))
        return svc

    def _dids(self):
        out = []
        ws = self.sheets.get("DID")
        if not ws:
            return out
        rows = list(sheet_rows(ws, 1))
        if not rows:
            return out
        header_row = rows[0][0] + 1 if rows[0][0] == 1 else rows[0][0]
        headers = next(ws.iter_rows(min_row=header_row, max_row=header_row, values_only=True))
        c_id = find_col(headers, "identifier")
        c_name = find_col(headers, "did name")
        c_len = find_col(headers, "total no. of bytes")
        c_rw = find_col(headers, "access read/writ")
        c_sess = find_col(headers, "sessions support")
        cur = None
        for _, row in sheet_rows(ws, header_row + 2):
            vid = cv(row, c_id)
            if re.fullmatch(r"[0-9A-Fa-f]{2,4}", vid):
                cur = {"did": vid.upper(), "name": "", "len": 0, "rw": "R", "sessions": set()}
                out.append(cur)
            if cur is None:
                continue
            if c_name is not None and not cur["name"]:
                cur["name"] = cv(row, c_name)
            if c_len is not None and row[c_len] is not None:
                try:
                    cur["len"] = max(cur["len"], int(row[c_len]))
                except (TypeError, ValueError):
                    pass
            if c_rw is not None and cv(row, c_rw):
                cur["rw"] = cv(row, c_rw).upper()
            if c_sess is not None:
                cur["sessions"] |= set(parse_sessions(cv(row, c_sess)))
        for d in out:
            if not d["sessions"]:
                d["sessions"] = {1, 3}
        return out

    def _rids(self):
        out = []
        ws = self.sheets.get("Control Routine")
        if not ws:
            return out
        rows = list(sheet_rows(ws, 1))
        if not rows:
            return out
        header_row = rows[0][0] + 1 if rows[0][0] == 1 else rows[0][0]
        headers = next(ws.iter_rows(min_row=header_row, max_row=header_row, values_only=True))
        # 兼容表头 "Identifier" 与 "Data identification"（实测 PBL 调查表用后者，旧实现漏配导致 RID=0）
        c_id = find_col(headers, "identifier", "identification")
        c_name = find_col(headers, "description")
        c_len = find_col(headers, "total no. of bytes")
        seen = set()
        for _, row in sheet_rows(ws, header_row + 2):
            vid = _norm_rid(cv(row, c_id))
            if vid and vid not in seen:
                seen.add(vid)
                mlen = re.search(r"\d+", cv(row, c_len))
                out.append({"rid": vid, "name": cv(row, c_name),
                            "len": int(mlen.group()) if mlen else 0})
        return out

    def _timing(self):
        t = {"p2": DEFAULT_P2, "p2s": DEFAULT_P2S, "s3": DEFAULT_S3, "p4": 50}
        ws = self.sheets.get("Timing parameters")
        if not ws:
            return t
        for _, row in sheet_rows(ws, 1):
            cells = [str(v).strip() for v in row[:4] if v is not None]
            if len(cells) >= 2:
                key = cells[0].lower()
                # 取 Max/Timeout 列（cells[2]），NA 时回退 Min 列（cells[1]）
                m = re.search(r"\d+", cells[2]) if len(cells) > 2 and re.search(r"\d+", cells[2]) else re.search(r"\d+", cells[1])
                if not m:
                    continue
                val = int(m.group())
                if "p2server" in key:
                    t["p2"] = val
                elif "p2*server" in key or "p2star" in key:
                    t["p2s"] = val
                elif "s3server" in key:
                    t["s3"] = val
        return t


class CaseGen:
    """按 10 维规则展开，输出 case-schema 兼容 JSON"""

    def __init__(self, survey, req_map=None, sf_traverse=False, product="", target="",
                 ro_dids=None, sa_session_map=None):
        self.sv = survey
        self.req_map = req_map or {}
        self.req_map_did = self.req_map.get("did") or {}
        self.req_map_rid = self.req_map.get("rid") or {}
        self.sf_traverse = sf_traverse
        self.ro_dids = [str(x).strip().upper() for x in (ro_dids or [])]
        sa_map = dict(SA_SESSION_DEFAULT)
        for k, v in (sa_session_map or {}).items():
            try:
                key = int(k, 16) if isinstance(k, str) else int(k)
            except (ValueError, TypeError):
                key = k
            sa_map[key] = [int(x, 16) if isinstance(x, str) else int(x) for x in v]
        self.sa_session_map = sa_map
        self.cases = []
        self.cover = {"customer": "", "product_model": product, "test_target": target,
                      "created_date": "", "srs_version": ""}
        self._cnt = {}

    def _readable_dids(self):
        """Return only DIDs declared as readable by the diagnostic database."""
        out = []
        for d in self.sv.dids:
            did = str(d.get("did") or "").strip().upper()
            rw = str(d.get("rw") or "").strip().upper()
            if not did:
                continue
            # The survey column is read/write access in forms such as
            # ``Always/No``, ``R``, ``Read/Write`` and ``No/Once``.  Inspect
            # the read side before the slash; substring checks would wrongly
            # classify ``W``/``Write``/``N`` as readable.
            read_access = re.split(r"[/,;]", rw, maxsplit=1)[0].strip()
            if read_access in {"R", "READ", "Y", "YES", "ALWAYS", "RW", "READONLY"}:
                out.append(d)
        return out

    def _session_probe_did(self):
        """Use F186 only when it is explicitly defined as a readable DID."""
        for d in self._readable_dids():
            if str(d.get("did") or "").upper() == "F186":
                return d
        return None

    def _timing_probe_did(self):
        """Choose a defined readable DID for generic 0x22 timing measurement."""
        readable = self._readable_dids()
        for d in readable:
            if str(d.get("did") or "").upper() == "F186":
                return d
        return readable[0] if readable else None

    def _id(self, grp):
        self._cnt[grp] = self._cnt.get(grp, 0) + 1
        return f"UDS_{grp}_TC_{self._cnt[grp]:04d}"

    def _reqs(self, svc_key, n=4, req_extra=None):
        """需求 ID 固定映射：req_extra（场景级，如 DID/RID）优先，再加服务级公共需求"""
        if req_extra:
            base = [req_extra]
        elif isinstance(svc_key, str):
            ids = self.req_map.get(svc_key) or []
            return "\n".join(ids[:n]) if ids else f"REQ-{svc_key}"
        else:
            base = []
        ids = self.req_map.get(str(svc_key)) or self.req_map.get(f"0x{svc_key:02X}") or []
        pool = base + ids
        return "\n".join(pool[:n]) if pool else f"REQ-{svc_key:02X}.{self._cnt.get(f'{svc_key:02X}', 0) + 1}"

    def add(self, grp, svc_key, priority, tp, design, pre, proc, exp, req_extra=None):
        if req_extra is None:
            req_extra = getattr(self, "_cur_req_extra", None)
        self.cases.append({
            "req_sources": self._reqs(svc_key, req_extra=req_extra),
            "case_id": self._id(grp),
            "priority": priority,
            "auto_eval": "是",
            "test_point": tp,
            "test_method": "需求分析法" if design == "需求分析法" else "等价类",
            "design_method": design,
            "env": "台架测试",
            "precondition": pre,
            "procedure": proc,
            "expected": exp,
            "select": "是",
        })

    def run(self):
        sv = self.sv
        self._sessions = sorted(sv.services.get(0x10, {}).get("sessions") or [1, 3])
        self._gen_10()
        self._gen_11()
        self._gen_22()
        self._gen_2e()
        self._gen_27()
        self._gen_31()
        self._gen_3e()
        self._gen_timeparm()
        return self.cases

    # ---------- 0x10 会话控制：来源×目标全切换矩阵 + 非法/恢复/寻址 ----------
    def _gen_10(self):
        S = self._sessions
        p2 = self.sv.timing["p2"]
        probe = self._session_probe_did()
        for src in S:
            for dst in S:
                self.add("0x10", 0x10, "L1",
                         f"基于需求分析：正向测试用例：{SESS_NAME[src]}切换到{SESS_NAME[dst]}（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[src]}",
                         f"1.测试仪请求：51 02 10 {dst:02X} FF FF FF FF；",
                         f"1. DUT正响应：51 06 50 {dst:02X} 00 {p2//256:02X} {p2%256:02X} 88；\n（P2Server_max={p2}ms，以SWRS为准）")
                # 切换后探针验证：请求 0x22 确认会话生效
                if probe:
                    probe_did = probe["did"]
                    probe_name = probe.get("name") or "Active Diagnostic Session"
                    self.add("0x10", 0x10, "L2",
                             f"基于需求分析：正向测试用例：{SESS_NAME[src]}切换到{SESS_NAME[dst]}后通过 DID {probe_did} 探针验证会话生效（NAD_Phys）",
                             "需求分析法",
                             f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[src]}",
                             f"1.测试仪请求：51 02 10 {dst:02X} FF FF FF FF；\n2. 请求 0x22 {probe_did[:2]} {probe_did[2:4]} 读取{probe_name}；",
                             f"1. DUT正响应 0x10；\n2. DID {probe_did} 返回活动会话 = 0x{dst:02X}；")
                # P2* 增强窗口时序
                self.add("0x10", 0x10, "L2",
                         f"基于需求分析：时序测试用例：{SESS_NAME[src]}切换到{SESS_NAME[dst]}的 P2*Server={self.sv.timing['p2s']}ms 增强窗口（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[src]}",
                         f"1.测试仪请求：51 02 10 {dst:02X} FF FF FF FF；\n2. 若响应超 P2，验证 P2* 窗口内收到；",
                         f"1. 响应 ≤ P2*Server_max={self.sv.timing['p2s']}ms（若超 P2Server={p2}ms）；")
        # 功能寻址变体（SPRMIB / NAD_Func）：每个切换对 × 1
        for src in S:
            for dst in S:
                self.add("0x10", 0x10, "L2",
                         f"基于需求分析：正向测试用例：通过SPRMIB设置（NAD_Func）从{SESS_NAME[src]}切换到{SESS_NAME[dst]}",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[src]}（SPRMIB 功能寻址）",
                         f"1.测试仪请求：51 02 10 {dst:02X} FF FF FF FF；",
                         f"1. DUT正响应：51 06 50 {dst:02X} 00 {p2//256:02X} {p2%256:02X} 88；")
        # 抑制位变体：每个切换对 × 1（子功能|0x80）
        for src in S:
            for dst in S:
                self.add("0x10", 0x10, "L2",
                         f"基于需求分析：正向测试用例：{SESS_NAME[src]}切换到{SESS_NAME[dst]} 带抑制肯定响应位 0x{dst|0x80:02X}（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[src]}",
                         f"1.测试仪请求：51 02 10 {dst|0x80:02X} FF FF FF FF；",
                         "1. DUT 无正响应（抑制位有效）；\n2. 会话切换行为按 SWRS 验证；")
        # 时序变体：每切换对 P2 响应时间验证 × 1
        for src in S:
            for dst in S:
                self.add("0x10", 0x10, "L2",
                         f"基于需求分析：时序测试用例：{SESS_NAME[src]}切换到{SESS_NAME[dst]} 的 P2Server={p2}ms 响应时间（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[src]}",
                         f"1.测试仪请求：51 02 10 {dst:02X} FF FF FF FF；\n2. 记录请求到响应时间；",
                         f"1. 响应时间 ≤ P2Server_max={p2}ms；")
        # 负例：非法子功能
        for sf, nrc in [(0x00, "12"), (0x7F, "12")]:
            self.add("0x10", 0x10, "L1",
                     f"基于需求分析：负向测试用例：默认会话中请求未定义子功能 0x{sf:02X}（NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 默认会话",
                     f"1.测试仪请求：51 02 10 {sf:02X} FF FF FF FF；",
                     f"1. DUT负响应：51 03 7F 10 {nrc}（{NRC_NAMES[nrc]}）；")
        # 恢复：S3 超时回默认
        s3 = self.sv.timing["s3"]
        self.add("0x10", 0x10, "L2",
                 "基于需求分析：恢复测试用例：扩展会话 S3Server 超时后回默认会话（NAD_Phys）",
                 "需求分析法",
                 f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话（S3Server={s3}ms）",
                 "1.测试仪请求：51 02 10 03 FF FF FF FF；\n2. 停止发送3E超过S3Server后，再次请求 0x22",
                 f"1. 超过{s3}ms 无诊断请求后 DUT 回默认会话；\n2. 再次 0x22 请求返回默认会话行为；")
        self.add("0x10", 0x10, "L2",
                 "基于需求分析：恢复测试用例：重新上电并初始化后返回默认会话（NAD_Phys）",
                 "需求分析法",
                 "1. 供电电压12V\n2. 应用模式\n3. 任意会话",
                 "1. 切换到扩展会话后，重新上电；\n2. 等待初始化完成后请求 0x22",
                 "1. DUT 上电初始化后处于默认会话；")

    # ---------- 0x11 ECU 复位：类型×会话 + 抑制位 + 子功能遍历 + 复位后恢复 ----------
    def _gen_11(self):
        info = self.sv.services.get(0x11, {})
        subs = info.get("subs") or [0x01]
        sess = sorted(info.get("sessions") or self._sessions)
        nrcs = sorted(info.get("nrc") or ["13"])
        for s in sess:
            for sf in subs:
                self.add("0x11", 0x11, "L1",
                         f"基于需求分析：正向测试用例：{SESS_NAME[s]}中支持 ECU 复位 子功能0x{sf:02X}（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                         f"1.测试仪请求：51 02 11 {sf:02X} FF FF FF FF；",
                         f"1. DUT正响应：51 01 51 {sf:02X}；\n2. ECU 复位后回默认会话（若SWRS要求）；")
                # 抑制位
                self.add("0x11", 0x11, "L2",
                         f"基于需求分析：正向测试用例：{SESS_NAME[s]}中 ECU 复位带抑制肯定响应位 0x{sf|0x80:02X}（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                         f"1.测试仪请求：51 02 11 {sf|0x80:02X} FF FF FF FF；",
                         "1. DUT 无正响应（抑制位有效）；\n2. 复位后会话状态按 SWRS 验证；")
        # 子功能遍历（负例）
        tvals = [0x00, 0x04, 0x05, 0x10, 0x20, 0x40, 0x7F, 0xFF] if not self.sf_traverse else list(range(0, 256, 1))
        for s in sess:
            for sf in tvals:
                if sf in subs or (sf | 0x80) in subs:
                    continue
                self.add("0x11", 0x11, "L2",
                         f"基于需求分析：负向测试用例：{SESS_NAME[s]}中非法复位子功能 0x{sf:02X}（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                         f"1.测试仪请求：51 02 11 {sf:02X} FF FF FF FF；",
                         "1. DUT负响应：51 03 7F 11 12（subFunctionNotSupported）；")
        # 复位后恢复验证
        self.add("0x11", 0x11, "L2",
                 "基于需求分析：恢复测试用例：复位完成后 DUT 返回默认会话（NAD_Phys）",
                 "需求分析法",
                 "1. 供电电压12V\n2. 应用模式\n3. 扩展会话",
                 "1.测试仪请求：51 02 11 01 FF FF FF FF；\n2. 等待复位完成后请求 0x10 01",
                 "1. DUT 复位后处于默认会话；")

    # ---------- 0x22 读 DID：每 DID ~12 条（会话×寻址×正反 + 非法/未实现 + 长度边界 + 时序 + 内容校验）----------
    def _gen_22(self):
        info = self.sv.services.get(0x22, {})
        sess_all = sorted(info.get("sessions") or [1, 3])
        dids = self._readable_dids()
        p2 = self.sv.timing["p2"]
        for d in dids:
            self._cur_req_extra = self.req_map_did.get(d["did"])
            sup = sorted(d.get("sessions") or sess_all)
            for s in sup:
                # 正例：每支持会话 × Phys
                self.add("0x22", 0x22, "L1",
                         f"基于需求分析：正向测试用例：{SESS_NAME[s]}中读取 DID {d['did']}（{d['name']}，NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                         f"1.测试仪请求：51 03 22 {d['did'][:2]} {d['did'][2:4]} FF FF FF FF；",
                         f"1. DUT正响应：51 03 62 {d['did'][:2]} {d['did'][2:4]} + {d['len']}字节数据；\n（P2Server_max={p2}ms，以SWRS为准）")
                # 正例：每支持会话 × Func（SPRMIB）
                self.add("0x22", 0x22, "L2",
                         f"基于需求分析：正向测试用例：{SESS_NAME[s]}中通过SPRMIB设置（NAD_Func）读取 DID {d['did']}",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}（SPRMIB 功能寻址）",
                         f"1.测试仪请求：51 03 22 {d['did'][:2]} {d['did'][2:4]} FF FF FF FF；",
                         f"1. DUT正响应：51 03 62 {d['did'][:2]} {d['did'][2:4]} + {d['len']}字节数据；")
            for s in sess_all:
                if s in sup:
                    continue
                self.add("0x22", 0x22, "L1",
                         f"基于需求分析：负向测试用例：{SESS_NAME[s]}中不支持读取 DID {d['did']}（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                         f"1.测试仪请求：51 03 22 {d['did'][:2]} {d['did'][2:4]} FF FF FF FF；",
                         "1. DUT负响应：51 03 7F 22 31（requestOutOfRange）；")
            # 负例：非法 DID
            self.add("0x22", 0x22, "L1",
                     "基于需求分析：负向测试用例：读取非法 DID 0xFFFF（NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 扩展会话",
                     "1.测试仪请求：51 03 22 FF FF FF FF FF FF；",
                     "1. DUT负响应：51 03 7F 22 31（requestOutOfRange）；")
            # 长度边界（每 DID 3 档：刚好/+1/-1）
            ln = d["len"] or 4
            for tag, plen, ok in [("刚好", ln, True), ("+1(无效)", ln + 1, False), ("-1(无效)", max(0, ln - 1), False)]:
                self.add("0x22", 0x22, "L2",
                         f"等价类：读取 DID {d['did']} 长度{tag}（总长{ln}字节，长度边界，NAD_Phys）",
                         "等价类",
                         "1. 供电电压12V\n2. 应用模式\n3. 扩展会话",
                         f"1.测试仪请求：0x22 {d['did'][:2]} {d['did'][2:4]}（请求长度{plen}）；",
                         f"1. DUT{'正响应完整数据' if ok else '负响应 NRC=0x13（长度无效）'}；")
            # P2 时序测量
            self.add("0x22", 0x22, "L2",
                     f"基于需求分析：时序测试用例：读取 DID {d['did']} 的 P2Server={p2}ms 响应时间（NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 默认会话",
                     f"1. 发送 0x22 {d['did'][:2]} {d['did'][2:4]}；\n2. 记录请求到响应时间；",
                     f"1. 响应时间 ≤ P2Server_max={p2}ms；")
            # 数据内容校验
            self.add("0x22", 0x22, "L2",
                     f"基于需求分析：正向测试用例：读取 DID {d['did']} 并校验返回数据内容（NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 默认会话",
                     f"1. 发送 0x22 {d['did'][:2]} {d['did'][2:4]}；\n2. 比对返回字节与预期值；",
                     f"1. 返回 {d['len']} 字节且内容与预期一致（关键字节逐位比对）；")

    # ---------- 0x2E 写 DID：可写DID×会话×正反 + 0x33 + 长度边界 ----------
    def _gen_2e(self):
        info = self.sv.services.get(0x2E, {})
        sess_all = sorted(info.get("sessions") or [1, 3])
        wdids = []
        for d in self.sv.dids:
            did = str(d.get("did") or "").upper()
            rw = (d.get("rw") or "").upper()
            if did in self.ro_dids:
                continue  # 项目明确只读，禁止生成写入正例
            if "ONLY ONE TIME" in rw or "/ONCE" in rw:
                wdids.append(d)  # 可写但仅一次（前置条件写清）
                continue
            if "W" in rw or "WRITE" in rw:
                wdids.append(d)
                continue
            # 只读/未知：保守处理，不当作可写 DID（避免只读 DID 误生成写入正例）
        if not wdids:
            return
        for d in wdids:
            self._cur_req_extra = self.req_map_did.get(d["did"])
            sup = sorted(d.get("sessions") or [3])
            for s in sup:
                self.add("0x2E", 0x2E, "L1",
                         f"基于需求分析：正向测试用例：{SESS_NAME[s]}中通过 DID {d['did']} 写入数据（已解锁，NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]} + 安全访问解锁成功",
                         f"1.测试仪请求：2E {d['did'][:2]} {d['did'][2:4]} + {d['len']}字节数据；",
                         f"1. DUT正响应：6E {d['did'][:2]} {d['did'][2:4]}；")
            for s in sess_all:
                if s in sup:
                    continue
                self.add("0x2E", 0x2E, "L1",
                         f"基于需求分析：负向测试用例：{SESS_NAME[s]}中不支持通过 DID {d['did']} 写入（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                         f"1.测试仪请求：2E {d['did'][:2]} {d['did'][2:4]} + 数据；",
                         "1. DUT负响应：51 03 7F 2E 31（requestOutOfRange）；")
            # 未解锁
            self.add("0x2E", 0x2E, "L1",
                     f"基于需求分析：安全测试用例：未解锁时通过 DID {d['did']} 写入被拒绝（NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 扩展会话（未执行安全解锁）",
                     f"1.测试仪请求：2E {d['did'][:2]} {d['did'][2:4]} + 数据；",
                     "1. DUT负响应：51 03 7F 2E 33（securityAccessDenied）；")
        # 长度边界
        d = wdids[0]
        ln = d["len"] or 4
        for tag, plen in [("刚好", ln), ("-1(无效)", ln - 1), ("+1(无效)", ln + 1)]:
            ok = plen == ln
            self.add("0x2E", 0x2E, "L2",
                     f"等价类：写 DID {d['did']} 长度{tag}（length.total={plen}，NRC=13 最小长度检查）",
                     "等价类",
                     "1. 供电电压12V\n2. 应用模式\n3. 扩展会话 + 已解锁",
                     f"1.测试仪请求：2E {d['did'][:2]} {d['did'][2:4]} + {plen}字节数据；",
                     f"1. DUT{'正响应' if ok else '负响应 NRC=0x13'}；")

    # ---------- 0x27 安全访问：等级×会话×密钥状态×延迟边界 + 锁定/0x33 ----------
    def _gen_27(self):
        info = self.sv.services.get(0x27, {})
        sess_all = sorted(info.get("sessions") or self._sessions)
        subs = info.get("subs") or [0x05, 0x06]
        pairs = sorted(set((s, s + 1) for s in subs if s % 2 == 1))
        if not pairs:
            pairs = [(subs[0], subs[1] if len(subs) > 1 else subs[0])]
        delay = int(re.search(r"\d+", info.get("delay") or "10000").group() or 10000)
        att = int(re.search(r"\d+", info.get("attempts") or "2").group() or 2)
        for seed_sf, key_sf in pairs:
            lvl = seed_sf
            allowed = self.sa_session_map.get(lvl, [0x03])
            for s in sess_all:
                name = SESS_NAME[s]
                if s in allowed:
                    self.add("0x27", 0x27, "L1",
                             f"基于需求分析：正向测试用例：{name}中支持 SID 0x27 安全访问等级0x{lvl:02X}（Seed/Key，延迟{delay}ms）",
                             "需求分析法",
                             f"1. 供电电压12V\n2. 应用模式\n3. {name}",
                             f"1.测试仪请求：27 {seed_sf:02X}（请求种子）；\n2. 计算密钥后请求：27 {key_sf:02X} + 密钥；",
                             f"1. DUT正响应种子：67 {seed_sf:02X} + 种子数据；\n2. DUT正响应：67 {key_sf:02X} + 0x00 00；")
                    # 密钥状态
                    self.add("0x27", 0x27, "L2",
                             f"基于需求分析：安全测试用例：{name}中等级0x{lvl:02X} 非初始密钥写入后解锁成功（NAD_Phys）",
                             "需求分析法",
                             f"1. 供电电压12V\n2. 应用模式\n3. {name}，已通过 DID F10A 写入非初始密钥",
                             f"1.测试仪请求：27 {seed_sf:02X}；2. 发送对应非初始密钥；",
                             "1. DUT正响应：67 xx 00 00（解锁成功）；")
                else:
                    self.add("0x27", 0x27, "L1",
                             f"基于需求分析：负向测试用例：{name}中不支持 SID 0x27 等级0x{lvl:02X}（NAD_Phys）",
                             "需求分析法",
                             f"1. 供电电压12V\n2. 应用模式\n3. {name}",
                             f"1.测试仪请求：27 {seed_sf:02X}；",
                             "1. DUT负响应：51 03 7F 27 7F（serviceNotSupportedInActiveSession）；")
            # 延迟边界：到期前/后
            self.add("0x27", 0x27, "L2",
                     f"基于需求分析：时序测试用例：等级0x{lvl:02X} 在服务启动延迟（{delay}ms）到期后再请求种子（NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话，等待 {delay}ms 延迟到期",
                     f"1.测试仪请求：27 {seed_sf:02X}（延迟已到期）；",
                     "1. DUT正响应：67 xx + 种子；")
            self.add("0x27", 0x27, "L2",
                     f"基于需求分析：时序测试用例：等级0x{lvl:02X} 在服务启动延迟未到期时请求被延迟处理（NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话，延迟未到期",
                     f"1.测试仪请求：27 {seed_sf:02X}（延迟未到期）；",
                     "1. DUT 按 SWRS 延迟策略响应（延迟时间内不响应或负响应 0x22）；")
            # 失败锁定
            self.add("0x27", 0x27, "L1",
                     f"基于需求分析：安全测试用例：等级0x{lvl:02X} 连续{att}次错误密钥后锁定（NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话",
                     f"1. 重复 {att} 次：请求种子 + 发送错误密钥；",
                     f"1. 前{att-1}次负响应 NRC=0x35（invalidKey）；\n2. 第{att}次后锁定，后续请求 NRC=0x37（exceedNumberOfAttempts，以SWRS为准）；")
            # 序列错误（对齐成熟写法：仅种子/仅密钥）
            self.add("0x27", 0x27, "L1",
                     f"基于需求分析：负向测试用例：安全访问序列错误——仅请求种子不发密钥（等级0x{lvl:02X}，NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话",
                     f"1.测试仪请求：27 {seed_sf:02X}（请求种子）；\n2. 不再发送密钥，直接访问受保护服务；",
                     "1. DUT正响应种子；\n2. 未解锁时访问受保护服务被拒：NRC=0x33（securityAccessDenied，以SWRS为准）；")
            self.add("0x27", 0x27, "L1",
                     f"基于需求分析：负向测试用例：安全访问序列错误——未请求种子直接发送密钥（等级0x{lvl:02X}，NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话",
                     f"1.测试仪请求：27 {key_sf:02X} + 密钥（未先请求种子）；",
                     "1. DUT负响应：51 03 7F 27 24（requestSequenceError，以SWRS为准）；")
            # 锁定后恢复：延迟等待后可再次尝试
            self.add("0x27", 0x27, "L2",
                     f"基于需求分析：恢复测试用例：等级0x{lvl:02X} 锁定后等待延迟（{delay}ms）可再次尝试（NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话（已锁定）",
                     f"1. 等待 {delay}ms 延迟后重新请求种子；",
                     "1. DUT 恢复响应种子（解锁计数重置，以SWRS为准）；")
            # 等级 × 会话 × Func 变体（会话跟随等级映射，避免等级 01 误挂扩展会话）
            if allowed:
                sa_sess = allowed[0]
                self.add("0x27", 0x27, "L2",
                         f"基于需求分析：正向测试用例：{SESS_NAME[sa_sess]}中通过SPRMIB设置（NAD_Func）请求等级0x{lvl:02X} 种子",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[sa_sess]}（SPRMIB 功能寻址）",
                         f"1.测试仪请求：27 {seed_sf:02X}；",
                         f"1. DUT正响应：67 {seed_sf:02X} + 种子数据；")
        # 未解锁访问受保护服务
        for svc, sid in [(0x2E, "2E"), (0x31, "31")]:
            self.add("0x27", 0x27, "L1",
                     f"基于需求分析：安全测试用例：未解锁时访问受保护服务 0x{sid} 被拒绝（NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 扩展会话（未解锁）",
                     f"1.测试仪请求：{sid} + 受保护参数；",
                     "1. DUT负响应：51 03 7F " + sid + " 33（securityAccessDenied）；")

    # ---------- 0x31 例程控制：每RID×启停结果×会话×正反 + 0x33 + 恢复 ----------
    def _gen_31(self):
        info = self.sv.services.get(0x31, {})
        sess = sorted(info.get("sessions") or self._sessions)
        subfns = sorted(info.get("subs") or [1, 2, 3])
        for r in self.sv.rids:
            self._cur_req_extra = self.req_map_rid.get(r["rid"])
            for sf in subfns:
                sfname = {1: "启动", 2: "停止", 3: "请求结果"}.get(sf, f"0x{sf:02X}")
                for s in sess:
                    self.add("0x31", 0x31, "L1",
                             f"基于需求分析：正向测试用例：{SESS_NAME[s]}中 RID {r['rid']}（{r['name']}）{sfname}（NAD_Phys）",
                             "需求分析法",
                             f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}" + (" + 已解锁" if sf in (1, 2) else ""),
                             f"1.测试仪请求：31 {sf:02X} {r['rid'][:2]} {r['rid'][2:4]} + 参数；",
                             f"1. DUT正响应：71 {sf:02X} {r['rid'][:2]} {r['rid'][2:4]} + 结果；\n（P4Server_max={self.sv.timing['p4']}ms，以SWRS为准）")
                # Func（SPRMIB）变体：每子功能 1 条（代表会话）
                self.add("0x31", 0x31, "L2",
                         f"基于需求分析：正向测试用例：扩展会话中通过SPRMIB设置（NAD_Func）对 RID {r['rid']} 执行{sfname}",
                         "需求分析法",
                         "1. 供电电压12V\n2. 应用模式\n3. 扩展会话（SPRMIB 功能寻址）" + (" + 已解锁" if sf in (1, 2) else ""),
                         f"1.测试仪请求：31 {sf:02X} {r['rid'][:2]} {r['rid'][2:4]} + 参数；",
                         f"1. DUT正响应：71 {sf:02X} {r['rid'][:2]} {r['rid'][2:4]} + 结果；")
            # 非法子功能负例
            self.add("0x31", 0x31, "L1",
                     f"基于需求分析：负向测试用例：RID {r['rid']} 非法子功能 0x04（NRC 0x12，NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 扩展会话",
                     f"1.测试仪请求：31 04 {r['rid'][:2]} {r['rid'][2:4]} FF FF FF FF；",
                     "1. DUT负响应：51 03 7F 31 12（subFunctionNotSupported）；")
            # 未解锁
            self.add("0x31", 0x31, "L1",
                     f"基于需求分析：安全测试用例：未解锁时启动 RID {r['rid']} 被拒绝（NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 扩展会话（未解锁）",
                     f"1.测试仪请求：31 01 {r['rid'][:2]} {r['rid'][2:4]} + 参数；",
                     "1. DUT负响应：51 03 7F 31 33（securityAccessDenied）；")
            # 恢复：运行中断后可重新启动
            self.add("0x31", 0x31, "L2",
                     f"基于需求分析：恢复测试用例：RID {r['rid']} 运行中断后可重新启动（NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话 + 已解锁",
                     f"1. 启动 RID {r['rid']}；2. 例程运行中断（断电/复位）；3. 重新启动 RID；",
                     "1. RID 重新启动成功（中断恢复）；")
        self._cur_req_extra = None
        # NRC=13 最小长度
        if self.sv.rids:
            r = self.sv.rids[0]
            self.add("0x31", 0x31, "L2",
                     f"等价类：RID {r['rid']} 最小长度检查（NRC=13，选择最小长度=3，NAD_Phys）",
                     "等价类",
                     "1. 供电电压12V\n2. 应用模式\n3. 扩展会话 + 已解锁",
                     f"1.测试仪请求：31 01 {r['rid'][:2]} {r['rid'][2:4]} 03（长度不足）；",
                     "1. DUT负响应：51 03 7F 31 13（incorrectMessageLengthOrInvalidFormat）；")

    # ---------- 0x3E 会话保持：子功能×会话×正反 + S3边界 + 非法 ----------
    def _gen_3e(self):
        info = self.sv.services.get(0x3E, {})
        sess = sorted(info.get("sessions") or self._sessions)
        subs = sorted(info.get("subs") or [0x00, 0x80])
        s3 = self.sv.timing["s3"]
        for s in sess:
            for sf in subs:
                self.add("0x3E", 0x3E, "L1",
                         f"基于需求分析：正向测试用例：{SESS_NAME[s]}中 SID 0x3E 子功能0x{sf:02X} 有效（NAD_Phys）",
                         "需求分析法",
                         f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                         f"1.测试仪请求：51 02 3E {sf:02X} FF FF FF FF；",
                         f"1. DUT正响应：51 01 7E {sf:02X}（若抑制位0x80则无响应）；")
            # SPRMIB 功能寻址变体
            self.add("0x3E", 0x3E, "L2",
                     f"基于需求分析：正向测试用例：{SESS_NAME[s]}中通过SPRMIB设置（NAD_Func）的 3E 00 有效",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}（SPRMIB 功能寻址）",
                     "1.测试仪请求：51 02 3E 00 FF FF FF FF；",
                     "1. DUT正响应：51 01 7E 00；")
        # S3 边界对
        for s in sess:
            self.add("0x3E", 0x3E, "L2",
                     f"等价类：{SESS_NAME[s]}中 S3Server={s3}ms，测试仪以{s3-100}ms 周期请求 3E 保持会话（NAD_Func）",
                     "等价类",
                     f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                     f"1. 每 {s3-100}ms 发送 3E 00（周期小于S3Server）；",
                     f"1. DUT 会话保持（{s3-100}ms < S3Server={s3}ms，不超时）；")
            self.add("0x3E", 0x3E, "L2",
                     f"等价类：{SESS_NAME[s]}中停止发送 3E 超过 S3Server={s3}ms 后会话超时回默认（NAD_Func）",
                     "等价类",
                     f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                     f"1. 发送 3E 后停止超过 {s3}ms；\n2. 请求 0x22 验证会话；",
                     f"1. 超过 S3Server={s3}ms 后 DUT 回默认会话；")
        # 每会话：P2 时序 + 非法子功能 0x7F
        for s in sess:
            self.add("0x3E", 0x3E, "L2",
                     f"基于需求分析：时序测试用例：{SESS_NAME[s]}中 3E 的 P2Server 响应时间（NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                     "1.测试仪请求：51 02 3E 00 FF FF FF FF；\n2. 记录请求到响应时间；",
                     f"1. 响应时间 ≤ P2Server_max={self.sv.timing['p2']}ms；")
            self.add("0x3E", 0x3E, "L2",
                     f"基于需求分析：负向测试用例：{SESS_NAME[s]}中 3E 非法子功能 0x7F（NAD_Phys）",
                     "需求分析法",
                     f"1. 供电电压12V\n2. 应用模式\n3. {SESS_NAME[s]}",
                     "1.测试仪请求：51 02 3E 7F FF FF FF FF；",
                     "1. DUT负响应：51 03 7F 3E 12（subFunctionNotSupported）；")
        self.add("0x3E", 0x3E, "L1",
                 "基于需求分析：负向测试用例：0x3E 未定义子功能 0x01（NAD_Phys）",
                 "需求分析法",
                 "1. 供电电压12V\n2. 应用模式\n3. 默认会话",
                 "1.测试仪请求：51 02 3E 01 FF FF FF FF；",
                 "1. DUT负响应：51 03 7F 3E 12（subFunctionNotSupported）；")

    # ---------- TimeParm 时序组：P2/P2*/S3/P4 独立测量 ----------
    def _gen_timeparm(self):
        t = self.sv.timing
        # P2Server 测量（代表服务 0x22）
        probe = self._timing_probe_did()
        if probe:
            probe_did = probe["did"]
            probe_name = probe.get("name") or "defined readable DID"
            self.add("TimeParm", "T", "L2",
                     f"基于需求分析：正向测试用例：P2Server_max={t['p2']}ms（0x22 读取 DID {probe_did} 响应时间测量，NAD_Phys）",
                     "需求分析法",
                     "1. 供电电压12V\n2. 应用模式\n3. 默认会话",
                     f"1. 发送 0x22 读取 DID {probe_did}（{probe_name}）；\n2. 记录请求末帧到响应首帧时间；",
                     f"1. 响应时间 ≤ P2Server_max={t['p2']}ms；\n2. 返回 DID {probe_did} 的定义数据；")
        self.add("TimeParm", "T", "L2",
                 f"基于需求分析：正向测试用例：P2*Server_max={t['p2s']}ms（响应超 P2 后的增强窗口，NAD_Phys）",
                 "需求分析法",
                 "1. 供电电压12V\n2. 应用模式\n3. 扩展会话",
                 "1. 发送耗时服务（如 0x31 例程）；\n2. 记录响应时间；",
                 f"1. 若响应超过 P2={t['p2']}ms，P2* 窗口内收到响应，且 ≤ {t['p2s']}ms；")
        self.add("TimeParm", "T", "L2",
                 f"基于需求分析：正向测试用例：S3Server={t['s3']}ms 会话超时测量（NAD_Phys）",
                 "需求分析法",
                 f"1. 供电电压12V\n2. 应用模式\n3. 扩展会话（S3Server={t['s3']}ms）",
                 "1. 进入扩展会话后停止诊断请求；\n2. 记录回默认会话时间；",
                 f"1. 回默认会话时间 = S3Server={t['s3']}ms（±容差，以SWRS为准）；")
        # P4Server 每 RID × 子功能
        for r in self.sv.rids:
            for sf in (1, 3):
                self.add("TimeParm", "T", "L2",
                         f"基于需求分析：正向测试用例：RID {r['rid']} 子功能0x{sf:02X} P4Server_max={t['p4']}ms",
                         "需求分析法",
                         "1. 供电电压12V\n2. 应用模式\n3. 扩展会话 + 已解锁",
                         f"1. 发送 31 {sf:02X} {r['rid'][:2]} {r['rid'][2:4]}；\n2. 记录响应时间；",
                         f"1. 响应时间 ≤ P4Server_max={t['p4']}ms；")


def merge_surveys(paths):
    import openpyxl
    merged = None
    for p in paths:
        s = Survey(p)
        if merged is None:
            merged = s
        else:
            for k, v in s.services.items():
                if k not in merged.services:
                    merged.services[k] = {"subs": [], "sessions": set(), "addr": set(), "nrc": set(),
                                          "sec": None, "delay": None, "attempts": None}
                t = merged.services[k]
                t["subs"] = sorted(set(t["subs"]) | set(v["subs"]))
                t["sessions"] |= v["sessions"]
                t["addr"] |= v["addr"]
                t["nrc"] |= v["nrc"]
                t["delay"] = t["delay"] or v["delay"]
                t["attempts"] = t["attempts"] or v["attempts"]
            seen = {d["did"] for d in merged.dids}
            for d in s.dids:
                if d["did"] not in seen:
                    merged.dids.append(d)
                    seen.add(d["did"])
            seen_r = {r["rid"] for r in merged.rids}
            for r in s.rids:
                if r["rid"] not in seen_r:
                    merged.rids.append(r)
                    seen_r.add(r["rid"])
    return merged


def main():
    ap = argparse.ArgumentParser(description="UDS 需求驱动 × 10 维展开生成器（对齐成熟 TRM）")
    ap.add_argument("input", help="调查表文件或目录（*_diagnostic.xlsx，目录自动合并）")
    ap.add_argument("--out", required=True, help="输出用例 JSON 路径")
    ap.add_argument("--req-map", default="", help="服务->需求ID映射 JSON（{服务hex: [REQ...]}）")
    ap.add_argument("--sf-traverse", action="store_true", help="0x11 子功能 0x00~0xFF 全遍历（默认取代表值）")
    ap.add_argument("--ro-dids", default="", help="强制只读 DID 列表（逗号分隔，如 F10A,F103；这些 DID 不生成 0x2E 写入正例）")
    ap.add_argument("--sa-session-map", default="", help="0x27 等级->允许会话 JSON 文件（如 {\"01\": [2], \"05\": [3]}，覆盖默认 01/02=编程、05/06=扩展）")
    ap.add_argument("--product", default="", help="产品型号")
    ap.add_argument("--target", default="", help="测试对象")
    args = ap.parse_args()

    if args.sf_traverse:
        print("[WARNING] --sf-traverse 会把 0x11 非法子功能负例展开到 0x00~0xFF（约 256×会话 条），")
        print("[WARNING] 实测经验：全遍历易导致用例爆炸（如 772 条 vs 成熟 TRM ~63 条）。")
        print("[WARNING] 除非主机厂明确要求子功能全遍历，否则建议去掉该参数使用默认代表值模式。")

    paths = []
    if os.path.isdir(args.input):
        paths = sorted(glob.glob(os.path.join(args.input, "*_diagnostic.xlsx")))
    elif os.path.isfile(args.input):
        paths = [args.input]
    if not paths:
        print(f"[ERROR] 未找到调查表: {args.input}")
        sys.exit(1)
    print(f"[1/{len(paths)+2}] 解析调查表 ...")
    sv = merge_surveys(paths)
    for p in paths:
        s = Survey(p)
        print(f"      {os.path.basename(p)}: DID {len(s.dids)} | RID {len(s.rids)} | 服务 {sorted(f'0x{x:02X}' for x in s.services)}")

    req_map = {}
    if args.req_map and os.path.isfile(args.req_map):
        with open(args.req_map, encoding="utf-8") as f:
            req_map = json.load(f)

    ro_dids = [x.strip().upper() for x in args.ro_dids.split(",") if x.strip()]
    sa_session_map = {}
    if args.sa_session_map and os.path.isfile(args.sa_session_map):
        with open(args.sa_session_map, encoding="utf-8") as f:
            sa_session_map = json.load(f)
    print("[2/%d] 10 维展开 ..." % (len(paths) + 2))
    gen = CaseGen(sv, req_map, args.sf_traverse, args.product, args.target,
                  ro_dids=ro_dids, sa_session_map=sa_session_map)
    cases = gen.run()

    out = {"cover": gen.cover, "cases": cases}
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    from collections import Counter
    svc = Counter(c["case_id"].split("_TC_")[0] for c in cases)
    print(f"[3/3] 完成：共 {len(cases)} 条用例 -> {args.out}")
    print("      服务分布:", dict(svc))


if __name__ == "__main__":
    main()
