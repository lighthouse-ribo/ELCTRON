#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
需求覆盖率自动化分析 —— 用例 ↔ 需求 双向追溯矩阵
=============================================================
输入用例（case-schema JSON 或 build_testcase_xlsx 产出的 xlsx）与需求清单，
自动输出：
  1. 双向追溯矩阵：每条 REQ 覆盖的用例列表（REQ → 用例）
  2. 覆盖率统计：总 REQ 数、已覆盖 REQ 数、覆盖率百分比
  3. 漏测 REQ 清单：需求清单中有、但没有任何用例覆盖的 REQ
  4. 孤儿用例检测：用例挂了需求清单里不存在的 REQ（提示疑似编造/笔误）

需求清单来源（二选一）：
  --reqs <file.txt>   手工需求清单，每行一个 REQ 编号（可带标题，只取 REQ-\\d+v\\d+）
  --srs <srs.txt>     SRS 明文全文，自动正则提取所有 REQ-\\d+v\\d+

用法：
  python req_coverage.py --cases cases.json --reqs reqs.txt --out coverage.md
  python req_coverage.py --cases cases.xlsx --srs srs.txt --out coverage.md
  python req_coverage.py --cases cases.json --reqs reqs.txt   # 仅控制台输出

输出：控制台摘要 + --out 指定的 Markdown 报告（含追溯矩阵表）
"""

__version__ = "1.0.0"

import argparse
import json
import os
import re
import sys
from collections import defaultdict

# REQ 编号模式：REQ-90441v4 / REQ-ReadDID.01 / REQ-Diagc.SN-01
REQ_PATTERN = re.compile(r"REQ-[\w.\-]+(?:v\d+)?", re.IGNORECASE)


# ============================================================================
# 用例加载
# ============================================================================
def extract_reqs(text):
    """从任意文本中提取所有 REQ 编号（去重保序）"""
    found = REQ_PATTERN.findall(text or "")
    seen = set()
    out = []
    for r in found:
        if r.upper() not in seen:
            seen.add(r.upper())
            out.append(r)
    return out


def load_cases_from_json(path):
    """从 case-schema JSON 加载 [(case_id, [reqs])]"""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    cases = []
    for c in data.get("cases", []):
        case_id = c.get("case_id", "?")
        reqs = extract_reqs(c.get("req_sources", ""))
        cases.append((case_id, reqs))
    return cases


def load_cases_from_xlsx(path):
    """从 build_testcase_xlsx 产出的 xlsx 加载 [(case_id, [reqs])]

    列约定（19 列表头）：B=需求来源、C=需求ID(首REQ)、D=用例ID
    数据从第 8 行开始。
    """
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    cases = []
    for row in ws.iter_rows(min_row=8, values_only=True):
        # row: A..T → index 0..19；B=1, D=3
        req_src = row[1] if len(row) > 1 else None
        case_id = row[3] if len(row) > 3 else None
        if not case_id:
            continue
        reqs = extract_reqs(str(req_src) if req_src else "")
        cases.append((str(case_id).strip(), reqs))
    wb.close()
    return cases


def load_cases(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        return load_cases_from_xlsx(path)
    elif ext == ".json":
        return load_cases_from_json(path)
    else:
        sys.exit("[ERROR] 不支持的用例格式 %s（支持 .json / .xlsx）" % ext)


# ============================================================================
# 需求清单加载
# ============================================================================
def load_reqs_from_list(path):
    """每行一个 REQ（可带标题）"""
    reqs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            found = extract_reqs(line)
            if found:
                reqs.append(found[0])
    # 去重保序
    seen, out = set(), []
    for r in reqs:
        if r.upper() not in seen:
            seen.add(r.upper())
            out.append(r)
    return out


def load_reqs_from_srs(path):
    """SRS 全文正则提取"""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    found = extract_reqs(text)
    # 按出现顺序去重
    seen, out = set(), []
    for r in found:
        if r.upper() not in seen:
            seen.add(r.upper())
            out.append(r)
    return out


# ============================================================================
# 覆盖率分析
# ============================================================================
def analyze(cases, req_list):
    """核心分析：双向追溯矩阵 + 覆盖率 + 漏测 + 孤儿"""
    # 1. REQ → [case_ids]（追溯矩阵，key 保留原始大小写）
    req_to_cases = defaultdict(list)
    for case_id, reqs in cases:
        for r in reqs:
            req_to_cases[r].append(case_id)

    # 2. 大小写不敏感去重映射：canonical(大写) → 原始写法
    canon = {}
    for r in list(req_to_cases.keys()) + list(req_list):
        canon.setdefault(r.upper(), r)

    # 3. 统一 REQ 全集（canonical 排序，显示原始大小写）
    all_reqs = sorted(canon[r.upper()] for r in set(canon.keys()))

    # 4. 漏测 REQ：需求清单有、无用例覆盖
    req_set = set(r.upper() for r in req_list)
    covered_canon = req_set & set(r.upper() for r in req_to_cases)
    uncovered = sorted(canon[c] for c in req_set - covered_canon)

    # 5. 孤儿 REQ：用例挂了、但不在需求清单（疑似编造/笔误）
    case_canon = set(r.upper() for r in req_to_cases)
    orphans = sorted(canon[c] for c in case_canon - req_set)

    # 6. 覆盖率
    total = len(req_set)
    rate = (len(covered_canon) / total * 100.0) if total else 0.0

    # 7. 无用例挂载的用例（裸用例）
    bare_cases = [cid for cid, reqs in cases if not reqs]

    return {
        "req_to_cases": dict(req_to_cases),
        "all_reqs": all_reqs,
        "uncovered": uncovered,
        "orphans": orphans,
        "covered_count": len(covered_canon),
        "total_reqs": total,
        "rate": rate,
        "bare_cases": bare_cases,
        "total_cases": len(cases),
    }


# ============================================================================
# 报告输出
# ============================================================================
def format_report(cases, req_list, result, src_desc=""):
    """生成 Markdown 报告"""
    L = []
    L.append("# 需求覆盖率分析报告")
    L.append("")
    L.append("- 用例来源：%s" % src_desc or "-")
    L.append("- 需求清单：%d 条" % result["total_reqs"])
    L.append("- 用例总数：%d 条" % result["total_cases"])
    L.append("")
    L.append("## 覆盖率统计")
    L.append("")
    L.append("| 指标 | 数值 |")
    L.append("|---|---|")
    L.append("| 需求总数 | %d |" % result["total_reqs"])
    L.append("| 已覆盖需求 | %d |" % result["covered_count"])
    L.append("| **覆盖率** | **%.1f%%** |" % result["rate"])
    L.append("| 漏测需求 | %d |" % len(result["uncovered"]))
    L.append("| 孤儿REQ（疑似编造） | %d |" % len(result["orphans"]))
    L.append("| 裸用例（无REQ挂载） | %d |" % len(result["bare_cases"]))
    L.append("")

    if result["uncovered"]:
        L.append("## ❌ 漏测需求（需求清单有、无用例覆盖）")
        L.append("")
        for r in result["uncovered"]:
            L.append("- %s" % r)
        L.append("")

    if result["orphans"]:
        L.append("## ⚠️ 孤儿 REQ（用例挂了、但需求清单中不存在——疑似编造或笔误）")
        L.append("")
        for r in result["orphans"]:
            L.append("- %s → 用例: %s" % (r, ", ".join(result["req_to_cases"][r])))
        L.append("")

    if result["bare_cases"]:
        L.append("## ⚠️ 裸用例（未挂载任何 REQ）")
        L.append("")
        for c in result["bare_cases"]:
            L.append("- %s" % c)
        L.append("")

    L.append("## 追溯矩阵（REQ → 用例）")
    L.append("")
    L.append("| 需求ID | 覆盖用例数 | 用例ID |")
    L.append("|---|---|---|")
    for r in result["all_reqs"]:
        cids = result["req_to_cases"].get(r, [])
        L.append("| %s | %d | %s |" % (r, len(cids), "<br>".join(cids) if cids else "—"))
    L.append("")
    return "\n".join(L)


def main():
    parser = argparse.ArgumentParser(description="需求覆盖率自动化分析 v%s" % __version__)
    parser.add_argument("--cases", "-c", required=True, help="用例文件（case-schema JSON 或 xlsx）")
    parser.add_argument("--reqs", "-r", help="需求清单 txt（每行一个 REQ，可带标题）")
    parser.add_argument("--srs", help="SRS 明文 txt（自动提取 REQ）")
    parser.add_argument("--out", "-o", help="Markdown 报告输出路径（可选，默认仅控制台）")
    args = parser.parse_args()

    if not os.path.exists(args.cases):
        sys.exit("[ERROR] 用例文件不存在: %s" % args.cases)
    if not args.reqs and not args.srs:
        sys.exit("[ERROR] 必须提供 --reqs 需求清单 或 --srs SRS 全文（二选一）")
    if args.reqs and not os.path.exists(args.reqs):
        sys.exit("[ERROR] 需求清单不存在: %s" % args.reqs)
    if args.srs and not os.path.exists(args.srs):
        sys.exit("[ERROR] SRS 文件不存在: %s" % args.srs)

    # 加载
    cases = load_cases(args.cases)
    if args.reqs:
        req_list = load_reqs_from_list(args.reqs)
        req_desc = "手动清单 %s（%d 条）" % (os.path.basename(args.reqs), len(req_list))
    else:
        req_list = load_reqs_from_srs(args.srs)
        req_desc = "SRS 自动提取 %s（%d 条）" % (os.path.basename(args.srs), len(req_list))

    print("[INFO] 用例: %d 条" % len(cases))
    print("[INFO] 需求: %d 条（%s）" % (len(req_list), req_desc))

    # 分析
    result = analyze(cases, req_list)

    # 控制台摘要
    print("\n[覆盖率] 统计:")
    print("  - 需求总数: %d" % result["total_reqs"])
    print("  - 已覆盖: %d" % result["covered_count"])
    print("  - **覆盖率: %.1f%%**" % result["rate"])
    if result["uncovered"]:
        print("  - ❌ 漏测需求 %d 条: %s" % (len(result["uncovered"]), ", ".join(result["uncovered"][:10])))
    if result["orphans"]:
        print("  - ⚠️ 孤儿REQ %d 条（疑似编造）: %s" % (len(result["orphans"]), ", ".join(result["orphans"][:10])))
    if result["bare_cases"]:
        print("  - ⚠️ 裸用例 %d 条: %s" % (len(result["bare_cases"]), ", ".join(result["bare_cases"][:10])))

    # 输出报告
    if args.out:
        report = format_report(cases, req_list, result, req_desc)
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(report)
        print("\n[INFO] 报告输出: %s" % args.out)

    # 退出码：有漏测或孤儿时非零（提示但允许 --force 场景由人工判断）
    if result["uncovered"] or result["orphans"]:
        print("\n[WARN] 存在漏测/孤儿，建议补用例或核对 REQ 后再交付")
        sys.exit(1)


if __name__ == "__main__":
    main()
