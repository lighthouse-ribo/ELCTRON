# -*- coding: utf-8 -*-
"""
uds_full_matrix_generator.py — UDS 用例全量矩阵生成器（系统合格性测试粒度）

用法：
  python uds_full_matrix_generator.py "<调查表目录或单文件>" --out "<用例.json>" [--product "产品型号"] [--target "测试对象"] [--cover "客户=..."]

与「手动挑几条代表」不同，本脚本按系统合格性测试的**全量矩阵**展开：
  服务 × 对象（DID/子功能/例程）× 会话 × 前置状态 的笛卡尔积 + 全局负例/时序/安全场景，
  对齐主机厂 TRM 用例粒度（如 UDS_0x22 覆盖全部 DID，每 DID 多场景）。

自动从 ODX 风格诊断调查表（Protocol/Service/DID/Control Routine/Timing 等 sheet）提取：
  - can_config / 网络参数
  - 服务范围与子功能、允许会话、安全要求
  - 全量 DID（含 Composite DID 如 EDA0）
  - 例程 ID 清单
  - 时序参数（P2/P2*/S3/N_As/N_Cr）

输出：符合 srs-uds-testcase-designer/references/case-schema.md 的用例 JSON（可直接喂 build_testcase_xlsx.py）。

场景矩阵（每个服务）：
  0x10 会话控制  目标会话 × {来源切换 + 重复切换 + 项目探针验证 + 非法子功能 + 长度错误 + P2 时序}
  0x22 读 DID    每个 DID × {允许会话逐个读 + P2 时序 + 长 DID 多帧边界} + 全局 {未支持 DID / 长度错误}
  0x31 例程控制  每个例程 × {启动 + 停止 + 请求结果 + 非法例程 + 时序} + 全局
  0x27 安全访问  种子/密钥 × {正例 + 错误 key + 连续错误锁定 + 未解锁访问受保护服务}
  0x2E 写 DID    每个 DID × {解锁写正例 + 未解锁 0x33 + 默认会话 0x7F + 长度错误}
  0x3E 会话保持  00/80 × {允许会话保持 + S3 边界 + 超时回退}
  0x11 复位      01/81 × {允许会话复位 + 复位后回默认 + 非法子功能 + 时序}
  全局           服务不支持 / 负响应 NRC 断言 / 时序锚定调查表
"""

import os
import re
import sys
import json
import glob
import argparse
from pathlib import Path
from datetime import date
import openpyxl

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))
from project_config import canonical_did, load_project_config, parse_int  # noqa: E402

# ---------- 默认值（可被调查表覆盖） ----------
DEFAULT_TIMING = {"P2Server": "50", "P2StarServer": "5000", "S3Server": "5000",
                  "N_As": "1000", "N_Cr": "1000"}
DEFAULT_PROTOCOL = {"net": "LIN", "bus_rate": "19.2Kbps", "protocol": "ISO-14229"}

SID_NAMES = {
    0x10: "DiagnosticSessionControl", 0x11: "ECUReset", 0x22: "ReadDataByID",
    0x27: "SecurityAccess", 0x2E: "WriteDataByID", 0x31: "RoutineControl",
    0x3E: "TesterPresent",
}
SID_TXT = {0x10: "0x10 会话控制", 0x11: "0x11 ECU复位", 0x22: "0x22 读DID",
           0x27: "0x27 安全访问", 0x2E: "0x2E 写DID", 0x31: "0x31 例程控制",
           0x3E: "0x3E 会话保持"}


# ---------- 调查表解析 ----------
def parse_sheet_value(ws, key):
    """在 sheet 中找 key: value 形式的第一行。"""
    for r in ws.iter_rows(values_only=True):
        if r and r[0] and str(r[0]).strip().rstrip(':') == key:
            return str(r[1]).strip() if len(r) > 1 and r[1] else ""
    return ""


def parse_diag_xlsx(path):
    """解析一份 ODX 风格诊断调查表，返回结构化数据。"""
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    names = set(wb.sheetnames)
    d = {"protocol": dict(DEFAULT_PROTOCOL), "timing": dict(DEFAULT_TIMING),
         "services": {}, "dids": {}, "routines": {}, "composite": {}}

    if "Protocol" in names:
        ws = wb["Protocol"]
        d["protocol"] = {
            "net": parse_sheet_value(ws, "Net type") or d["protocol"]["net"],
            "bus_rate": parse_sheet_value(ws, "Bus rate") or d["protocol"]["bus_rate"],
            "protocol": parse_sheet_value(ws, "Protocol:") or d["protocol"]["protocol"],
        }
    if "Timing parameters" in names:
        ws = wb["Timing parameters"]
        for r in ws.iter_rows(values_only=True):
            if r and r[0]:
                sym = str(r[0]).strip()
                if sym in ("P2Server", "S3Server") and len(r) > 2 and r[2]:
                    d["timing"][sym] = re.sub(r"[^0-9]", "", str(r[2]))
                elif sym == "P2*Server" and len(r) > 2 and r[2]:
                    d["timing"]["P2StarServer"] = re.sub(r"[^0-9]", "", str(r[2]))
                elif sym in ("N_As", "N_Cr") and len(r) > 1 and r[1]:
                    d["timing"][sym] = re.sub(r"[^0-9]", "", str(r[1]))
    # Service
    if "Service" in names:
        ws = wb["Service"]
        cur_sid = None
        for r in ws.iter_rows(values_only=True):
            if not r or not r[0]:
                continue
            v0 = str(r[0]).strip()
            if re.fullmatch(r"(0x)?[0-9A-F]{2}", v0, re.I):
                cur_sid = int(v0, 16)
                d["services"].setdefault(cur_sid, {"subs": [], "sessions": "", "security": ""})
            elif cur_sid and v0:
                # 子功能行
                d["services"][cur_sid]["subs"].append(v0.upper())
    # DID（含 Composite）
    if "DID" in names:
        ws = wb["DID"]
        for r in ws.iter_rows(values_only=True):
            if r and r[0] and re.fullmatch(r"[0-9A-F]{4}", str(r[0]).strip(), re.I):
                did = str(r[0]).strip().upper()
                d["dids"][did] = str(r[1]).strip() if r[1] else ""
    if "Composite DID" in names:
        ws = wb["Composite DID"]
        for r in ws.iter_rows(values_only=True):
            if r and r[0] and re.fullmatch(r"[0-9A-F]{4}", str(r[0]).strip(), re.I):
                cid = str(r[0]).strip().upper()
                d["composite"][cid] = {
                    "desc": str(r[1]).strip() if len(r) > 1 and r[1] else "",
                    "len": str(r[2]).strip() if len(r) > 2 and r[2] else "?",
                }
    # Control Routine
    if "Control Routine" in names:
        ws = wb["Control Routine"]
        for r in ws.iter_rows(values_only=True):
            if r and r[0] and re.fullmatch(r"[0-9A-F]{4}", str(r[0]).strip(), re.I):
                rid = str(r[0]).strip().upper()
                desc = str(r[3]).strip() if len(r) > 3 and r[3] else ""
                d["routines"][rid] = desc
    wb.close()
    return d


def collect_from_dir(path):
    """解析目录下所有 *_diagnostic.xlsx，合并（按分区标记）。"""
    if os.path.isfile(path):
        files = [path]
    else:
        files = sorted(glob.glob(os.path.join(path, "*_diagnostic.xlsx")) +
                       glob.glob(os.path.join(path, "**", "*_diagnostic.xlsx"), recursive=True))
    parts = {}
    for f in files:
        tag = os.path.basename(f).split("_diag")[0]
        parts[tag] = parse_diag_xlsx(f)
    if not parts:
        sys.exit(f"[ERROR] 未在 {path} 找到 *_diagnostic.xlsx 调查表")
    return parts


# ---------- 用例组装 ----------
class CaseBuilder:
    def __init__(self, parts, product, target, req_prefix="REQ", project_config=None):
        self.parts = parts
        self.product = product
        self.target = target
        self.req_prefix = req_prefix
        self.project_config = load_project_config(project_config)
        transport = self.project_config.get("transport", {})
        self.physical_nad = int(transport.get("physical_nad", 0x51))
        self.functional_nad = int(transport.get("functional_nad", 0x82))
        sessions = self.project_config.get("sessions", {})
        generation = self.project_config.get("generation", {})
        self.default_session = int(sessions.get("default", 0x01))
        self.session_names = sessions.get("names", {})
        security_sessions = generation.get("security_sessions")
        if security_sessions is None:
            security_sessions = sessions.get("supported", [self.default_session])
        self.security_session = int(security_sessions[0]) if security_sessions else self.default_session
        self.session_probe_did = canonical_did(generation.get("session_probe_did")) or "会话状态"
        self.security_constant_text = "、".join(
            str(value) for value in (generation.get("security_constant_dids") or {}).values()
        ) or "项目配置的安全常量"
        self.cases = []
        self._seq = {}

    def _session_text(self, session_id, fallback):
        return str(self.session_names.get(int(session_id), fallback))

    def _rewrite_transport(self, value):
        """将历史模板中的帧首 NAD 替换为项目配置值。

        只匹配帧开头/冒号后的第一个字节，不修改 payload 中恰好出现的
        0x51，避免把数据内容误当成 NAD。
        """
        text = str(value or "")
        physical = f"{self.physical_nad:02X}"
        functional = f"{self.functional_nad:02X}"
        text = re.sub(r"(^|[：:(])(?:51|53)(?=\s+(?:[0-9A-Fa-f]{2}|XX)\b)", rf"\g<1>{physical}", text, flags=re.I)
        # 响应模板常用 ``51 XX`` 表示 NAD+未知 PCI；XX 不是 hex，上一条
        # 规则无法命中，导致自定义项目仍泄漏旧物理 NAD。
        text = re.sub(r"(^|[：:(])(?:51|53)(?=\s+XX\b)", rf"\g<1>{physical}", text, flags=re.I)
        text = re.sub(r"(^|[：:(])82(?=\s+[0-9A-Fa-f]{2})", rf"\g<1>{functional}", text)
        # 旧模板中的角色名称/示例 DID 只作为兼容输入，输出必须反映项目
        # 配置；项目不提供探针或安全常量时明确写“未配置”，不伪造 DID。
        default_name = self._session_text(self.default_session, f"会话 0x{self.default_session:02X}")
        security_name = self._session_text(self.security_session, f"会话 0x{self.security_session:02X}")
        text = text.replace("默认会话", default_name)
        text = text.replace("扩展诊断会话", security_name)
        text = text.replace("Session reference 01 03", "以项目会话配置为准")
        text = text.replace("F10A/F103", self.security_constant_text)
        text = text.replace("F186", self.session_probe_did)
        return text

    def _next_id(self, service):
        svc = service.replace("0x", "0X") if service.startswith("0x") else service
        self._seq[svc] = self._seq.get(svc, 0) + 1
        return f"UDS_{svc}_TC_{self._seq[svc]:04d}"

    def _req(self, grp, no, note=""):
        return f"{self.req_prefix}-{grp}.{no:02d}（自动生成，{note}）"

    def add(self, service, grp, no, priority, test_method, design_method,
            precondition, procedure, expected, req_note, test_point="基于需求的测试"):
        precondition = self._rewrite_transport(precondition)
        procedure = self._rewrite_transport(procedure)
        expected = self._rewrite_transport(expected)
        req_note = self._rewrite_transport(req_note)
        case = {
            "req_sources": self._req(grp, no, req_note),
            "case_id": self._next_id(service),
            "priority": priority,
            "auto_eval": "是",
            "test_point": test_point,
            "test_method": test_method,
            "design_method": design_method,
            "env": "台架测试",
            "precondition": precondition,
            "procedure": procedure,
            "expected": expected,
            "select": "是",
        }
        self.cases.append(case)

    def timing_note(self):
        t = self.parts[list(self.parts.keys())[0]]["timing"]
        return (f"（P2Server≤{t['P2Server']}ms、S3Server={t['S3Server']}ms，"
                f"以调查表 Timing 为准）")


# ---------- 场景矩阵展开 ----------
def build_cases(builder):
    parts = builder.parts
    config = builder.project_config
    generation = config.get("generation", {})
    sessions_config = config.get("sessions", {})
    transport = config.get("transport", {})
    physical_nad = int(transport.get("physical_nad", 0x51))
    functional_nad = int(transport.get("functional_nad", 0x82))
    default_session = int(sessions_config.get("default", 0x01))

    def session_ids(key, fallback):
        values = generation.get(key)
        if values is None:
            values = fallback
        return [int(value) for value in values]

    def session_token(value):
        return f"{int(value):02X}"

    def session_text(value):
        names = sessions_config.get("names", {})
        return str(names.get(int(value), f"会话 0x{int(value):02X}"))

    default_session_text = session_text(default_session)

    def illegal_nrc(service):
        configured = config.get("nrc", {}).get("illegal_subfunction", {}).get(
            f"0x{int(service):02X}"
        )
        return int(configured) & 0xFF if configured is not None else None

    def illegal_nrc_text(service):
        code = illegal_nrc(service)
        # This helper is embedded in a UDS frame.  Keep the byte token as
        # plain hex (``11``), so lint and downstream parsers see a valid
        # ``7F <SID> <NRC>`` sequence rather than ``7F <SID> 0x11``.
        return f"{code:02X}" if code is not None else "以项目配置为准"

    def illegal_nrc_source(service):
        code = illegal_nrc(service)
        return (f"项目配置 illegal_subfunction NRC 0x{code:02X}"
                if code is not None else "项目配置 illegal_subfunction NRC 待确认")

    def probe_text(did, action="读取"):
        return f"{action} {did}" if did else f"{action}当前会话状态（以 ECU 响应为准）"

    session_probe_did = canonical_did(generation.get("session_probe_did")) or None
    reset_probe_did = canonical_did(generation.get("reset_probe_did")) or None
    physical_hex = f"{physical_nad:02X}"
    functional_hex = f"{functional_nad:02X}"
    default_token = session_token(default_session)
    SESSION_TXT = {
        session_token(session_id): session_text(session_id)
        for session_id in sessions_config.get("supported", [default_session])
    }
    security_sessions = [session_token(value) for value in session_ids(
        "security_sessions", sessions_config.get("supported", [default_session])
    )]
    tester_present_sessions = [session_token(value) for value in session_ids(
        "tester_present_sessions", sessions_config.get("supported", [default_session])
    )]
    reset_sessions = [session_token(value) for value in session_ids(
        "reset_sessions", sessions_config.get("supported", [default_session])
    )]
    security_session_token = security_sessions[0] if security_sessions else default_token
    security_session_text = SESSION_TXT.get(security_session_token, f"会话 {security_session_token}")
    reset_from_session = next(
        (token for token in reset_sessions if token != default_token), default_token
    )
    reset_from_session_text = SESSION_TXT.get(reset_from_session, f"会话 {reset_from_session}")
    security_subfunctions = [int(value) for value in generation.get(
        "security_access_subfunctions", [0x05, 0x06]
    )]
    seed_subfunction = next((value for value in security_subfunctions if value % 2), security_subfunctions[0] if security_subfunctions else 0x05)
    key_subfunction = next((value for value in security_subfunctions if value % 2 == 0), security_subfunctions[-1] if security_subfunctions else 0x06)
    first = parts[list(parts.keys())[0]]
    timing = first["timing"]
    p2 = f"P2Server≤{timing['P2Server']}ms"
    s3 = f"S3Server={timing['S3Server']}ms"
    s3_before_ms = int(generation.get("s3_boundary_before_ms", 100))
    s3_after_ms = int(generation.get("s3_boundary_after_ms", 100))
    s3_before_label = f"{s3_before_ms / 1000:g}s"
    s3_after_label = f"{s3_after_ms / 1000:g}s"

    # 汇总全部 DID / 例程（跨分区去重，记录来源分区）
    all_dids = {}
    for tag, d in parts.items():
        for did, name in d["dids"].items():
            all_dids.setdefault(did, {"name": name, "parts": []})["parts"].append(tag)
    for tag, d in parts.items():
        for cid, info in d["composite"].items():
            all_dids.setdefault(cid, {"name": info["desc"], "parts": []})["parts"].append(tag)
    all_routines = {}
    for tag, d in parts.items():
        for rid, desc in d["routines"].items():
            all_routines.setdefault(rid, {"desc": desc, "parts": []})["parts"].append(tag)

    # The negative read-DID case must not use a DID that happens to be valid
    # in another project. Only an explicitly configured value is executable;
    # without one, keep an honest project-confirmation placeholder.
    configured_unsupported_did = canonical_did(generation.get("unsupported_did"))
    if configured_unsupported_did and configured_unsupported_did not in all_dids:
        unsupported_did = configured_unsupported_did
    else:
        unsupported_did = None
    unsupported_did_token = (
        f"{unsupported_did[:2]} {unsupported_did[2:]}"
        if unsupported_did else "<项目未配置DID>"
    )

    # ============ 0x10 会话控制 ============
    targets = [session_token(value) for value in session_ids(
        "session_targets", sessions_config.get("supported", [default_session])
    )]
    g = 0
    for tgt in targets:
        g += 1
        tgt_txt = SESSION_TXT[tgt]
        # 从各来源会话切换（正例，含编程会话来源）
        for src in [session_token(value) for value in session_ids(
                "session_sources", sessions_config.get("supported", [default_session]))]:
            src_txt = SESSION_TXT[src]
            if src == tgt:
                continue
            g += 1
            builder.add("0x10", "Session", g, "L1", "需求分析法", "需求分析法",
                        f"1. 供电电压12V\n2. LIN通信正常\n3. {src_txt}",
                    f"1.测试仪请求（0x3C）：{physical_hex} 02 10 {tgt} FF FF FF FF",
                    f"1. DUT正响应（0x3D）：{physical_hex} 02 50 {tgt} FF FF FF FF\n2. 会话切换至{tgt_txt}，响应时间 {p2}",
                        f"SRS 诊断需求 + SDDB Service 0x10 {tgt_txt}")
        # 重复切换同会话
        g += 1
        builder.add("0x10", "Session", g, "L2", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {tgt_txt}",
                    f"1.测试仪请求：{physical_hex} 02 10 {tgt} FF FF FF FF\n2.再次请求：{physical_hex} 02 10 {tgt} FF FF FF FF",
                    f"1. 两次均正响应 50 {tgt}，会话保持{tgt_txt}",
                    f"SDDB Service 0x10 {tgt_txt}")
        # 项目探针验证会话生效
        g += 1
        builder.add("0x10", "Session", g, "L1", "需求分析法", "需求分析法",
                    f"1. 供电电压12V\n2. {default_session_text}",
                    f"1.测试仪请求：{physical_hex} 02 10 {tgt} FF FF FF FF\n2.测试仪请求：{physical_hex} 03 22 {session_probe_did[:2]} {session_probe_did[2:]} FF FF FF" if session_probe_did else f"1.测试仪请求：{physical_hex} 02 10 {tgt} FF FF FF FF\n2.读取当前会话状态",
                    f"1. 0x10 正响应 50 {tgt}\n2. {session_probe_did} 返回 {tgt}，确认会话生效" if session_probe_did else f"1. 0x10 正响应 50 {tgt}\n2. ECU 提供当前会话证据，确认会话生效",
                     f"SDDB 项目会话状态探针")
        # 广播/功能寻址切换
        g += 1
        builder.add("0x10", "Session", g, "L2", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}\n3. 支持功能寻址（广播）",
                    f"1.测试仪广播请求（功能寻址）：{functional_hex} 02 10 {tgt} FF FF FF FF",
                    f"1. DUT正响应：50 {tgt}（会话切换生效）",
                    f"SDDB Service 0x10 {tgt_txt} 功能寻址")
        # P2 时序
        g += 1
        builder.add("0x10", "Session", g, "L2", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}\n3. 抓取请求/响应帧",
                    f"1.发送 10 {tgt} 切换会话\n2.测量请求末帧到响应首帧时间",
                    f"1. 响应时间 ≤{p2}（P2Server）",
                    f"SDDB Timing P2Server={timing['P2Server']}ms")
        # 非法子功能（每目标）
        g += 1
        builder.add("0x10", "Session", g, "L2", "错误推断法", "错误推断法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}",
                    f"1.测试仪请求：{physical_hex} 02 10 FF FF FF FF FF（非法子功能，目标 {tgt}）",
                     f"1. DUT负响应：7F 10 {illegal_nrc_text(0x10)}（subFunctionNotSupported）",
                    illegal_nrc_source(0x10))
        # 长度错误（每目标）
        g += 1
        builder.add("0x10", "Session", g, "L2", "边界值法", "边界值法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}",
                    f"1.测试仪请求：{physical_hex} 04 10 {tgt} 00 FF FF FF（多余字节）",
                    "1. DUT负响应：7F 10 13（incorrectMessageLengthOrInvalidFormat）",
                    "ISO 14229-1 NRC 0x13")
    # 非法子功能
    g += 1
    builder.add("0x10", "Session", g, "L2", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}",
                f"1.测试仪请求：{physical_hex} 02 10 FF FF FF FF FF（非法子功能）",
                 f"1. DUT负响应：7F 10 {illegal_nrc_text(0x10)}（subFunctionNotSupported）",
                illegal_nrc_source(0x10))
    # 长度错误
    g += 1
    builder.add("0x10", "Session", g, "L2", "边界值法", "边界值法",
                f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}",
                f"1.测试仪请求：{physical_hex} 04 10 {default_token} 00 FF FF FF（多余字节）",
                "1. DUT负响应：7F 10 13（incorrectMessageLengthOrInvalidFormat）",
                "ISO 14229-1 NRC 0x13")
    # S3 超时回退（时序，全局一次）
    g += 1
    builder.add("0x10", "Session", g, "L2", "边界值法", "边界值法",
                f"1. 供电电压12V\n2. {SESSION_TXT.get(next((token for token in targets if token != default_token), default_token), default_token)}",
                f"1.切换非默认会话后停止发送诊断请求\n2.等待 {timing['S3Server']}ms（S3Server）后" + (f"发送 0x22 {session_probe_did}" if session_probe_did else "读取当前会话状态"),
                f"1. 超时后会话应回 {SESSION_TXT[default_token]}（S3 超时判定以 SWRS 为准）\n2. " + (f"{session_probe_did} 返回 {default_token} 证明回退生效（{s3}）" if session_probe_did else f"获得默认会话证据证明回退生效（{s3}）"),
                f"SDDB Timing S3Server={timing['S3Server']}ms")

    # ============ 0x22 读 DID ============
    allowed_sessions = [session_token(value) for value in session_ids(
        "read_sessions", sessions_config.get("supported", [default_session])
    )]
    g = 0
    for did, info in all_dids.items():
        g += 1
        did_txt = f"0x22 {did}（{info['name'][:20]}）"
        parts_txt = "/".join(info["parts"])
        # 允许会话读（正例）
        for sess in allowed_sessions:
            g += 1
            builder.add("0x22", "ReadDID", g, "L1", "需求分析法", "需求分析法",
                        f"1. 供电电压12V\n2. {SESSION_TXT[sess]}\n3. LIN通信正常",
                    f"1.测试仪请求（0x3C）：{physical_hex} 03 22 {did[:2]} {did[2:]} FF FF FF",
                        f"1. DUT正响应（0x3D）：{physical_hex} XX 62 {did[:2]} {did[2:]} <数据>\n2. 响应时间 {p2}",
                        f"SRS 触发帧 + SDDB_{parts_txt} DID {did}")
        # 长 DID 多帧边界（>6 字节）
        g += 1
        builder.add("0x22", "ReadDID", g, "L2", "边界值法", "边界值法",
                    f"1. 供电电压12V\n2. {default_session_text}",
                    f"1.测试仪请求：{physical_hex} 03 22 {did[:2]} {did[2:]} FF FF FF\n2.抓取响应帧序列",
                    f"1. 若 DID 数据 >6B（长度以调查表为准），响应按传输层分包（N_As≤1000ms）\n2. 全帧数据完整，无丢包",
                    f"SDDB_{parts_txt} DID {did} 长数据多帧")
        # 会话切换后立即读（验证会话状态与 DID 可用性联动）
        g += 1
        builder.add("0x22", "ReadDID", g, "L2", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}",
                    f"1.切换至{SESSION_TXT.get(next((token for token in allowed_sessions if token != default_token), default_token), default_token)}（10 {next((token for token in allowed_sessions if token != default_token), default_token)}）\n2.立即读 {did}：{physical_hex} 03 22 {did[:2]} {did[2:]} FF FF FF",
                    f"1. {SESSION_TXT.get(next((token for token in allowed_sessions if token != default_token), default_token), default_token)}下读 {did} 正常响应（以项目会话配置为准）\n2. 响应时间 {p2}",
                    f"SDDB_{parts_txt} DID {did} 会话联动")
        g += 1
        builder.add("0x22", "ReadDID", g, "L2", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {SESSION_TXT.get(next((token for token in allowed_sessions if token != default_token), default_token), default_token)}",
                    f"1.切换回{SESSION_TXT[default_token]}（10 {default_token}）\n2.立即读 {did}：{physical_hex} 03 22 {did[:2]} {did[2:]} FF FF FF",
                    f"1. {SESSION_TXT[default_token]}下读 {did} 正常响应\n2. 数据与前一会话读取一致",
                    f"SDDB_{parts_txt} DID {did} 会话回切")
        # 数据内容校验
        g += 1
        builder.add("0x22", "ReadDID", g, "L1", "需求分析法", "需求分析法",
                    f"1. 供电电压12V\n2. {default_session_text}",
                    f"1.读 {did}：{physical_hex} 03 22 {did[:2]} {did[2:]} FF FF FF\n2.记录返回数据并与 LIN Matrix/烧录值比对",
                    f"1. 返回数据与烧录的 {info['name'][:24]} 一致\n2. 长度、内容无错位",
                    f"SDDB_{parts_txt} DID {did} 内容校验")
    # 全局负例
    g += 1
    builder.add("0x22", "ReadDID", g, "L2", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {default_session_text}",
                f"1.测试仪请求：{physical_hex} 03 22 {unsupported_did_token} FF FF FF（未支持DID）",
                "1. DUT负响应：7F 22 31（requestOutOfRange）",
                "ISO 14229-1 NRC 0x31（未支持 DID；需项目配置确认）")
    g += 1
    builder.add("0x22", "ReadDID", g, "L2", "边界值法", "边界值法",
                f"1. 供电电压12V\n2. {default_session_text}",
                f"1.测试仪请求：{physical_hex} 04 22 {unsupported_did_token} 00 FF FF（多余字节）",
                "1. DUT负响应：7F 22 13（incorrectMessageLengthOrInvalidFormat）",
                "ISO 14229-1 NRC 0x13")

    # ============ 0x31 例程控制 ============
    g = 0
    for rid, info in all_routines.items():
        g += 1
        r_txt = f"0x31 {rid}（{info['desc'][:24]}）"
        parts_txt = "/".join(info["parts"])
        # 启动
        g += 1
        builder.add("0x31", "Routine", g, "L1", "需求分析法", "需求分析法",
                    f"1. 供电电压12V\n2. {security_session_text}",
                    f"1.测试仪请求：{physical_hex} 05 31 01 {rid[:2]} {rid[2:]} FF FF",
                    f"1. DUT正响应：{physical_hex} 05 71 01 {rid[:2]} {rid[2:]} <结果>\n2. 响应时间 {p2}",
                    f"SDDB_{parts_txt} Control Routine {rid}")
        # 停止
        g += 1
        builder.add("0x31", "Routine", g, "L2", "需求分析法", "需求分析法",
                    f"1. 供电电压12V\n2. {security_session_text}\n3. 例程已启动",
                    f"1.测试仪请求：{physical_hex} 05 31 02 {rid[:2]} {rid[2:]} FF FF",
                    f"1. DUT正响应：{physical_hex} 05 71 02 {rid[:2]} {rid[2:]} <结果>",
                    f"SDDB_{parts_txt} Control Routine {rid} 停止")
        # 请求结果
        g += 1
        builder.add("0x31", "Routine", g, "L2", "需求分析法", "需求分析法",
                    f"1. 供电电压12V\n2. {security_session_text}",
                    f"1.测试仪请求：{physical_hex} 05 31 03 {rid[:2]} {rid[2:]} FF FF",
                    f"1. DUT正响应：{physical_hex} 05 71 03 {rid[:2]} {rid[2:]} <结果>",
                    f"SDDB_{parts_txt} Control Routine {rid} 请求结果")
        # 未解锁启动（受保护例程，如 0231 CheckSecurityAccessMethod）
        g += 1
        builder.add("0x31", "Routine", g, "L1", "错误推断法", "错误推断法",
                    f"1. 供电电压12V\n2. {security_session_text}\n3. 未执行 0x27 安全解锁",
                    f"1.测试仪请求：{physical_hex} 05 31 01 {rid[:2]} {rid[2:]} FF FF（未解锁启动 {rid}）",
                    "1. 若例程受保护（如 0231）：DUT负响应 7F 31 33（securityAccessDenied）\n2. 若例程不受保护：正常响应（以调查表为准）",
                    f"SDDB_{parts_txt} Control Routine {rid} 安全前置")
        # 时序
        g += 1
        builder.add("0x31", "Routine", g, "L2", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {security_session_text}",
                    f"1.启动例程 {rid}：{physical_hex} 05 31 01 {rid[:2]} {rid[2:]} FF FF\n2.测量响应时间",
                    f"1. 响应时间 ≤{p2}\n2. 若为长时例程，首响应后 P2* 内给终响应",
                    f"SDDB_{parts_txt} Control Routine {rid} 时序")
    # 非法例程
    g += 1
    builder.add("0x31", "Routine", g, "L2", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {security_session_text}",
                f"1.测试仪请求：{physical_hex} 05 31 01 FF FF FF FF（未支持例程）",
                "1. DUT负响应：7F 31 31（requestOutOfRange）",
                "ISO 14229-1 NRC 0x31")

    # ============ 0x27 安全访问 ============
    g = 0
    for sess in security_sessions:
        for sub_value in security_subfunctions:
            sub = session_token(sub_value)
            sub_txt = "请求种子" if int(sub_value) % 2 else "发送密钥"
            g += 1
            builder.add("0x27", "Security", g, "L1", "需求分析法", "需求分析法",
                        f"1. 供电电压12V\n2. {SESSION_TXT[sess]}",
                        f"1.测试仪请求：{physical_hex} 02 27 {sub} FF FF FF FF（{sub_txt}）",
                        f"1. DUT正响应：{physical_hex} 06 67 {sub} <seed/key>\n2. 安全等级与项目配置安全常量一致",
                        f"SDDB Service 0x27 {sub_txt} + {SESSION_TXT[sess]}")
    # 安全等级校验：仅当项目配置声明了“等级→常量 DID”时生成，避免
    # 不将示例项目安全常量 DID 当成所有项目的事实。
    for levels, constant_did in generation.get("security_constant_dids", {}).items():
        level_text = str(levels)
        level_values = [level_text[i:i + 2] for i in range(0, len(level_text), 2)]
        level_values = [value for value in level_values if len(value) == 2]
        g += 1
        builder.add(
            "0x27", "Security", g, "L1", "需求分析法", "需求分析法",
            f"1. 供电电压12V\n2. {security_session_text}",
            f"1.读 {constant_did}（安全等级常量）确认等级\n2.请求 27 {'/'.join(level_values) or '目标等级'} 种子",
            f"1. {constant_did} 返回安全等级与配置的 0x27 等级匹配\n2. 种子长度以调查表为准",
            f"SDDB DID {constant_did} 安全常量",
        )
    g += 1  # 非法子功能
    builder.add("0x27", "Security", g, "L2", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {security_session_text}",
                f"1.测试仪请求：{physical_hex} 02 27 00 FF FF FF FF（非法子功能）",
                 f"1. DUT负响应：7F 27 {illegal_nrc_text(0x27)}（subFunctionNotSupported）",
                illegal_nrc_source(0x27))
    g += 1  # 种子后无 key 直接重复请求种子
    builder.add("0x27", "Security", g, "L2", "场景法", "场景法",
                f"1. 供电电压12V\n2. {security_session_text}",
                f"1.请求种子 27 {seed_subfunction:02X}\n2.未发送 key，再次请求 27 {seed_subfunction:02X}",
                "1. 可正常再次获取新种子（或返回原种子，以调查表为准）",
                "SDDB Service 0x27 种子重取")
    g += 1  # 错误 key
    builder.add("0x27", "Security", g, "L1", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {security_session_text}\n3. 已获取种子",
                f"1.测试仪请求：{physical_hex} 06 27 {key_subfunction:02X} 00 00 00 00（错误密钥）",
                "1. DUT负响应：7F 27 35（invalidKey）",
                "ISO 14229-1 NRC 0x35")
    g += 1  # 连续错误锁定
    builder.add("0x27", "Security", g, "L2", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {security_session_text}",
                f"1.连续 3 次发送错误密钥（27 {key_subfunction:02X}）\n2.再次请求 27 {seed_subfunction:02X} 种子",
                "1. 尝试次数超限：NRC=0x36（exceedNumberOfAttempts）或 0x37（requiredTimeDelayNotExpired）\n2. 延时后可恢复",
                "ISO 14229-1 NRC 0x36/0x37")
    g += 1  # 锁定后恢复
    builder.add("0x27", "Security", g, "L2", "恢复法", "恢复法",
                f"1. 供电电压12V\n2. {security_session_text}\n3. 已触发错误锁定（0x36/0x37）",
                f"1.等待延时结束（requiredTimeDelayNotExpired）\n2.重新请求 27 {seed_subfunction:02X} 种子",
                f"1. 延时结束后可正常获取种子（0x67 {seed_subfunction:02X}）\n2. 解锁功能恢复正常（恢复验证）",
                "ISO 14229-1 恢复场景")
    g += 1  # key 长度错误
    builder.add("0x27", "Security", g, "L2", "边界值法", "边界值法",
                f"1. 供电电压12V\n2. {security_session_text}",
                f"1.测试仪请求：{physical_hex} 03 27 {key_subfunction:02X} 00 FF FF FF（密钥长度错误）",
                "1. DUT负响应：7F 27 13（incorrectMessageLengthOrInvalidFormat）",
                "ISO 14229-1 NRC 0x13")
    g += 1  # 未解锁访问受保护服务（0x2E）
    builder.add("0x27", "Security", g, "L1", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {security_session_text}\n3. 未解锁",
                "1.直接发送 0x2E 写受保护 DID（绕过 0x27）",
                "1. DUT负响应：7F 2E 33（securityAccessDenied）\n2. 证明 0x2E 依赖 0x27 解锁（前置联动）",
                "SDDB Service 0x27→0x2E 联动")

    # ============ 0x2E 写 DID ============
    g = 0
    write_dids = list(all_dids.items())
    max_write_dids = generation.get("max_write_dids")
    if max_write_dids is not None:
        write_dids = write_dids[:int(max_write_dids)]
    for did, info in write_dids:
        g += 1
        parts_txt = "/".join(info["parts"])
        # 未解锁写（负）
        g += 1
        builder.add("0x2E", "WriteDID", g, "L1", "错误推断法", "错误推断法",
                    f"1. 供电电压12V\n2. {security_session_text}\n3. 未执行 0x27 安全解锁",
                    f"1.测试仪请求：{physical_hex} 05 2E {did[:2]} {did[2:]} 00 FF FF FF（未解锁写 {did}）",
                    "1. DUT负响应：7F 2E 33（securityAccessDenied）",
                    f"SDDB_{parts_txt} DID {did} 受保护写")
        # 默认会话写（负）
        g += 1
        builder.add("0x2E", "WriteDID", g, "L2", "错误推断法", "错误推断法",
                    f"1. 供电电压12V\n2. {default_session_text}",
                    f"1.测试仪请求：{physical_hex} 05 2E {did[:2]} {did[2:]} 00 FF FF FF（{default_session_text}写 {did}）",
                    "1. DUT负响应：7F 2E 7F（serviceNotSupportedInActiveSession）或 0x13",
                    f"SDDB_{parts_txt} DID {did} 会话约束")
        # 长度错误（负）
        g += 1
        builder.add("0x2E", "WriteDID", g, "L2", "边界值法", "边界值法",
                    f"1. 供电电压12V\n2. {security_session_text}\n3. 已解锁",
                    f"1.测试仪请求：{physical_hex} 04 2E {did[:2]} {did[2:]} FF FF FF（数据长度错误写 {did}）",
                    "1. DUT负响应：7F 2E 13（incorrectMessageLengthOrInvalidFormat）",
                    f"SDDB_{parts_txt} DID {did} 长度校验")
    # 解锁后写（正例，代表性 DID）。没有配置代表性 DID 时不造造一个
    # 项目 DID；配置值不在调查表汇总中也跳过该附加场景。
    representative_did = canonical_did(generation.get("representative_write_did"))
    if representative_did and representative_did in all_dids:
        g += 1
        builder.add("0x2E", "WriteDID", g, "L1", "需求分析法", "需求分析法",
                    f"1. 供电电压12V\n2. {security_session_text}\n3. 0x27 解锁成功（关键前置）",
                    f"1.测试仪请求：{physical_hex} 16 2E {representative_did[:2]} {representative_did[2:]} <数据>（写 {representative_did}）",
                    f"1. DUT正响应：{physical_hex} 03 6E {representative_did[:2]} {representative_did[2:]} FF FF FF\n2. 0x22 {representative_did} 回读数据一致",
                    f"SDDB DID {representative_did} 解锁后写")

    # ============ 0x3E 会话保持 ============
    g = 0
    for sub in ["00", "80"]:
        for sess in tester_present_sessions:
            g += 1
            builder.add("0x3E", "TesterPresent", g, "L2", "需求分析法", "需求分析法",
                        f"1. 供电电压12V\n2. {SESSION_TXT[sess]}",
                        f"1.测试仪请求：{physical_hex} 02 3E {sub} FF FF FF FF\n2.间隔 4s 重复发送（S3 内）",
                        f"1. DUT正响应：{physical_hex} 02 7E {sub} FF FF FF FF\n2. 会话保持在{SESSION_TXT[sess]}（{s3}）",
                        f"SDDB Service 0x3E {sub} + {SESSION_TXT[sess]}")
            # S3 边界 4.9s（临界内）
            g += 1
            builder.add("0x3E", "TesterPresent", g, "L2", "边界值法", "边界值法",
                        f"1. 供电电压12V\n2. {SESSION_TXT[sess]}",
                        f"1.发送 0x3E {sub} 后等待 S3-{s3_before_label}（{s3_before_ms}ms）再发送",
                        f"1. S3-{s3_before_label}（{s3_before_ms}ms）内会话未超时，正响应 7E {sub}\n2. 会话仍保持（{s3} 边界内，以 SWRS 判定为准）",
                        f"SDDB Timing S3Server={timing['S3Server']}ms 边界")
            # S3 超时 5.1s（临界外）
            g += 1
            builder.add("0x3E", "TesterPresent", g, "L2", "边界值法", "边界值法",
                        f"1. 供电电压12V\n2. {SESSION_TXT[sess]}",
                        f"1.发送 0x3E {sub} 后停止发送，等待 S3+{s3_after_label}（{s3_after_ms}ms）再" + (f"发送 0x22 {session_probe_did}" if session_probe_did else "读取当前会话状态"),
                        f"1. S3+{s3_after_label}（{s3_after_ms}ms）后会话回{default_session_text}（超时判定以 SWRS 为准）\n2. " + (f"0x22 {session_probe_did} 返回 {default_token}（{s3} 边界外）" if session_probe_did else f"获得{default_session_text}证据（{s3} 边界外）"),
                        f"SDDB Timing S3Server={timing['S3Server']}ms 超时")
    # 非法子功能
    g += 1
    builder.add("0x3E", "TesterPresent", g, "L2", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}",
                f"1.测试仪请求：{physical_hex} 02 3E 01 FF FF FF FF（非法子功能）",
                 f"1. DUT负响应：7F 3E {illegal_nrc_text(0x3E)}（subFunctionNotSupported）",
                illegal_nrc_source(0x3E))
    g += 1  # 超时回退
    builder.add("0x3E", "TesterPresent", g, "L2", "边界值法", "边界值法",
                f"1. 供电电压12V\n2. {security_session_text}",
                f"1.停止发送 0x3E，等待 {timing['S3Server']}ms 后" + (f"发送 0x22 {session_probe_did}" if session_probe_did else "读取当前会话状态"),
                f"1. 无 0x3E 保持时，S3 超时后回{SESSION_TXT[default_token]}（{s3}）",
                f"SDDB Timing S3Server={timing['S3Server']}ms")

    # ============ 0x11 复位 ============
    g = 0
    for sess in reset_sessions:
        g += 1
        builder.add("0x11", "Reset", g, "L1", "需求分析法", "需求分析法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[sess]}",
                    f"1.测试仪请求：{physical_hex} 02 11 01 FF FF FF FF（硬复位）",
                    f"1. DUT正响应：{physical_hex} 02 51 01 FF FF FF FF\n2. 复位后进入{SESSION_TXT[default_token]}",
                    f"SDDB Service 0x11 硬复位 + {SESSION_TXT[sess]}")
        # 复位后状态验证；项目未提供探针 DID 时只要求留下 ECU 状态证据。
        g += 1
        builder.add("0x11", "Reset", g, "L1", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[sess]}",
                    f"1.发送 11 01 硬复位\n2.等待复位完成，" + (f"发送 22 {reset_probe_did} 读会话" if reset_probe_did else "读取当前会话状态"),
                    f"1. 复位后会话回{SESSION_TXT[default_token]}（" + (f"{reset_probe_did}={default_token}" if reset_probe_did else "状态证据") + f"）\n2. ECU 可正常响应诊断",
                    f"SDDB Service 0x11 复位后状态")
        # P2 时序
        g += 1
        builder.add("0x11", "Reset", g, "L2", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[sess]}",
                    f"1.发送 11 01 硬复位\n2.测量复位响应时间",
                    f"1. 复位响应 ≤{p2}",
                    f"SDDB Timing P2Server={timing['P2Server']}ms")
        # 广播复位
        g += 1
        builder.add("0x11", "Reset", g, "L2", "场景法", "场景法",
                    f"1. 供电电压12V\n2. {SESSION_TXT[sess]}",
                    f"1.测试仪广播请求：{functional_hex} 02 11 01 FF FF FF FF",
                    f"1. DUT正响应：{physical_hex} 02 51 01 FF FF FF FF，复位执行",
                    f"SDDB Service 0x11 功能寻址")
    # 编程会话复位（负例）
    g += 1
    builder.add("0x11", "Reset", g, "L2", "错误推断法", "错误推断法",
                    f"1. 供电电压12V\n2. {reset_from_session_text}",
                    f"1.测试仪请求：{physical_hex} 02 11 01 FF FF FF FF（{reset_from_session_text}下复位）",
                "1. DUT负响应：7F 11 7F（serviceNotSupportedInActiveSession，以项目会话配置为准）",
                "SDDB Service 0x11 会话约束")
    g += 1  # 非法子功能
    builder.add("0x11", "Reset", g, "L2", "错误推断法", "错误推断法",
                f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}",
                f"1.测试仪请求：{physical_hex} 02 11 00 FF FF FF FF（非法子功能）",
                 f"1. DUT负响应：7F 11 {illegal_nrc_text(0x11)}（subFunctionNotSupported）",
                illegal_nrc_source(0x11))
    g += 1  # 长度错误
    builder.add("0x11", "Reset", g, "L2", "边界值法", "边界值法",
                f"1. 供电电压12V\n2. {SESSION_TXT[default_token]}",
                f"1.测试仪请求：{physical_hex} 04 11 01 00 FF FF FF（多余字节）",
                "1. DUT负响应：7F 11 13（incorrectMessageLengthOrInvalidFormat）",
                "ISO 14229-1 NRC 0x13")

    # ============ 全局：服务不支持（取调查表未列服务，避免硬编码项目结论） ============
    g = 1
    svc_list = set()
    for _d in parts.values():
        svc_list |= set(_d.get("services", {}))
    unsup = next((s for s in (0x19, 0x14, 0x28, 0x85, 0x23, 0x2A) if s not in svc_list), None)
    if unsup is not None:
        builder.add("0x7F", "Global", g, "L2", "错误推断法", "错误推断法",
                    f"1. 供电电压12V\n2. {default_session_text}",
                    f"1.测试仪请求：{physical_hex} 02 %02X 01 FF FF FF FF（0x%02X 未在调查表服务范围）" % (unsup, unsup),
                    "1. DUT负响应：7F %02X 11（serviceNotSupported）" % unsup,
                    "SDDB Service 范围：0x%02X 未实现" % unsup)


def main():
    ap = argparse.ArgumentParser(description="UDS 用例全量矩阵生成器（系统合格性测试粒度）")
    ap.add_argument("input", help="调查表文件或目录（*_diagnostic.xlsx）")
    ap.add_argument("--out", required=True, help="输出用例 JSON 路径")
    ap.add_argument("--product", default="", help="产品型号（跨项目必传，勿用示例默认值）")
    ap.add_argument("--target", default="", help="测试对象（跨项目必传，勿用示例默认值）")
    ap.add_argument("--cover", nargs="*", default=[], help="额外封面信息 键=值")
    ap.add_argument("--req-prefix", default="REQ", help="自动生成需求 ID 前缀")
    ap.add_argument("--project-config", default="", help="项目配置 JSON；不传时使用兼容默认值")
    args = ap.parse_args()

    try:
        project_config = load_project_config(args.project_config or None)
    except ValueError as exc:
        print(f"[ERROR] 项目配置读取失败: {exc}")
        sys.exit(1)

    print("[1/3] 解析调查表 ...")
    parts = collect_from_dir(args.input)
    for tag, d in parts.items():
        print(f"      {tag}: DID {len(d['dids'])} + 复合 {len(d['composite'])} | "
              f"例程 {len(d['routines'])} | 服务 {sorted(hex(s) for s in d['services'])}")

    print("[2/3] 全量矩阵展开 ...")
    builder = CaseBuilder(parts, args.product, args.target, args.req_prefix, project_config)
    build_cases(builder)

    cover = {
        "project": project_config.get("project", "legacy-default"),
        "product_model": args.product,
        "test_target": args.target,
        "created_date": date.today().isoformat(),
        "srs_version": "SDDB APP/PBL/SBL 诊断调查表（全量矩阵展开）",
        "project_config": args.project_config or "兼容默认配置",
    }
    for kv in args.cover:
        if "=" in kv:
            k, v = kv.split("=", 1)
            cover[k] = v

    out = {"cover": cover, "cases": builder.cases}
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"[3/3] 完成：共 {len(builder.cases)} 条用例 -> {args.out}")
    from collections import Counter
    svc = Counter(c["case_id"].split("_")[1] for c in builder.cases)
    print("      服务分布:", dict(svc))


if __name__ == "__main__":
    main()
