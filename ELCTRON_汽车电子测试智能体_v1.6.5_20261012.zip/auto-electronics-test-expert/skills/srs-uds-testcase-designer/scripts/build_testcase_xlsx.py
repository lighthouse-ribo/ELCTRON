# -*- coding: utf-8 -*-
"""
UDS 测试用例 JSON → 模板 xlsx 生成脚本
================================================================
读取用例 JSON（结构见 references/case-schema.md），生成符合用户模板
（TRM_UDS_Security_系统合格性测试用例.xlsx UDS sheet）格式的 xlsx：
  - 封面 6 行（B1:J2 关键信息：客户/产品型号/测试对象/日期/SRS版本/需求数）
  - 表头 B7:T7（19 列：需求来源/需求ID/用例ID/优先级/.../备注）
  - 用例数据 B8 起，多行单元格自动换行，边框/列宽/对齐
  - 落盘后自校验：用例数、必填字段、case_id 唯一性

用法：
  python build_testcase_xlsx.py <用例.json> --out <输出.xlsx> [--cover k=v k2=v2 ...]
  - --cover 覆盖封面字段：customer/product_model/test_target/created_date/srs_version

前置：venv 已装 openpyxl（3.1.5 实测可用）
"""
import sys, os, json, argparse, datetime
from testcase_headers import HEADERS  # B5: 19 列表头唯一权威来源（xlsx 版文案，2026-09-04 用户决策）



def build(cases_json, out_xlsx, cover_ovr=None, template_path=None):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    from openpyxl.utils import get_column_letter

    with open(cases_json, encoding="utf-8") as f:
        data = json.load(f)

    cover = dict(data.get("cover", {}))
    if cover_ovr:
        cover.update(cover_ovr)
    cases = data.get("cases", [])

    # ---- 自校验（先校验再生成） ----
    ids = [c.get("case_id", "") for c in cases]
    dup = [x for x in set(ids) if ids.count(x) > 1]
    if dup:
        sys.exit("VALIDATION_FAIL: 用例ID重复 %s" % dup)
    for c in cases:
        for k in ("req_sources", "case_id", "priority", "precondition", "procedure", "expected"):
            if not c.get(k):
                sys.exit("VALIDATION_FAIL: 用例 %s 缺少必填字段 %s" % (c.get("case_id"), k))

    if template_path and os.path.isfile(template_path):
        # 完整模板模式：写入 13-sheet 模板的 UDS 页（对齐 BBS_P519_V436-系统合格性测试用例）
        from openpyxl import load_workbook
        wb = load_workbook(template_path)
        ws = wb["UDS"]
        if ws.max_row >= 8:
            ws.delete_rows(8, ws.max_row - 7)  # 清空模板样例数据，保留表头/封面/汇总公式
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "UDS"

    thin = Side(style="thin", color="999999")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    hdr_fill = PatternFill("solid", fgColor="DDEBF7")
    hdr_font = Font(bold=True, size=10)
    wrap = Alignment(wrap_text=True, vertical="top", horizontal="left")
    center = Alignment(wrap_text=True, vertical="center", horizontal="center")

    # ---- 封面 1~2 行（仅独立模式；模板模式保留模板封面/合并单元格） ----
    if not template_path:
        ws["B1"] = "客户名称\nCustomer Name"; ws["C1"] = cover.get("customer", "")
        ws["D1"] = "产品型号\nProduct Model"; ws["E1"] = cover.get("product_model", "")
        ws["F1"] = "测试对象\nTest Target"; ws["G1"] = cover.get("test_target", "")
        ws["H1"] = "用例日期\n创建日期"; ws["I1"] = cover.get("created_date", "")
        ws["J1"] = "用例作者\nCreated By"
        ws["B2"] = "测试版本\nTest Version"
        ws["C2"] = "软件版本：\n硬件版本："
        ws["D2"] = "系统需求规格说明书版本\nSRS Version"; ws["E2"] = cover.get("srs_version", "")
        ws["F2"] = "测试需求数\nRequirements to Test"; ws["G2"] = len(cases)

    # ---- 表头（第 7 行 B~T） ----
    for i, h in enumerate(HEADERS):
        cell = ws.cell(row=7, column=2 + i, value=h)
        cell.font = hdr_font
        cell.alignment = center
        cell.fill = hdr_fill
        cell.border = border

    # ---- 用例数据（B8 起），格式对齐 BBS_P519_V436-系统合格性测试用例 UDS sheet ----
    def _test_type(design, test_method):
        """H 测试方法：需求分析法→基于需求的测试（对齐参考文件口径）"""
        if design == "需求分析法":
            return "基于需求的测试"
        return test_method or design or "需求分析法"

    for r, c in enumerate(cases, start=8):
        vals = [
            c.get("req_source_name", "系统需求规格书"),  # B 需求来源（来源文档名）
            c.get("req_sources", ""),               # C 需求ID（全部 REQ 换行列出）
            c.get("case_id", ""),                   # D 用例ID
            c.get("priority", ""),                  # E 优先级
            c.get("auto_eval", "是"),               # F 自动化评估
            c.get("test_point", "基于需求的测试"),  # G 测试点
            _test_type(c.get("design_method", ""), c.get("test_method", "")),  # H 测试方法
            c.get("design_method", "需求分析法"),   # I 用例设计方法
            c.get("env", "台架测试"),               # J 测试环境
            c.get("precondition", ""),              # K 前提条件
            c.get("procedure", ""),                 # L 操作步骤
            c.get("expected", ""),                  # M 预期结果
            c.get("select", "是"),                  # N 选择测试用例
            "", "", "", "", "", "", ""              # O~T 结果列留空
        ]
        for i, v in enumerate(vals):
            cell = ws.cell(row=r, column=2 + i, value=v)
            cell.alignment = wrap
            cell.border = border
            cell.font = Font(size=10)

    # ---- 列宽（B~T） ----
    widths = {1: 6, 2: 22, 3: 16, 4: 16, 5: 8, 6: 10, 7: 14, 8: 14, 9: 16,
              10: 10, 11: 28, 12: 40, 13: 40, 14: 8, 15: 10, 16: 10, 17: 14, 18: 10, 19: 12, 20: 16}
    for col, w in widths.items():
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.row_dimensions[7].height = 30
    for r in range(8, 8 + len(cases)):
        ws.row_dimensions[r].height = 90

    # ---- 冻结表头 ----
    ws.freeze_panes = "B8"

    out_dir = os.path.dirname(os.path.abspath(out_xlsx))
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    wb.save(out_xlsx)

    # ---- 落盘后自校验 ----
    from openpyxl import load_workbook
    wb2 = load_workbook(out_xlsx)
    ws2 = wb2["UDS"]
    n_cases = sum(1 for r in range(8, 8 + len(cases) + 10) if ws2.cell(row=r, column=4).value)
    if n_cases != len(cases):
        sys.exit("VALIDATION_FAIL: 落盘用例数 %d != JSON %d" % (n_cases, len(cases)))
    print("RESULT ok=True CASES=%d COVER_SRS=%s OUT=%s" % (len(cases), cover.get("srs_version", ""), out_xlsx), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cases_json", help="用例 JSON 路径（结构见 references/case-schema.md）")
    ap.add_argument("--out", required=True, help="输出 xlsx 路径")
    ap.add_argument("--cover", nargs="*", default=[], help="封面覆盖 k=v（customer/product_model/test_target/created_date/srs_version）")
    ap.add_argument("--template", default="", help="13-sheet 完整模板路径（默认输出单 UDS sheet；提供后写入模板 UDS 页并保留汇总公式）")
    args = ap.parse_args()

    cover_ovr = {}
    for kv in args.cover:
        if "=" in kv:
            k, v = kv.split("=", 1)
            cover_ovr[k.strip()] = v.strip()

    try:
        build(args.cases_json, args.out, cover_ovr, template_path=args.template)
    except Exception as e:
        import traceback
        traceback.print_exc()
        sys.exit("RESULT ok=False ERR=%r" % (e,))


if __name__ == "__main__":
    main()
