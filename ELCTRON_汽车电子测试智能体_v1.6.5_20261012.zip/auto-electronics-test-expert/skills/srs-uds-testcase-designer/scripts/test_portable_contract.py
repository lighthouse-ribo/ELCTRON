# -*- coding: utf-8 -*-
"""Minimal v0.1 portable contract checks; standard library only."""

from __future__ import annotations

import json
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
SCHEMA = ROOT / "schemas" / "portable-contract-v0.1.json"
PACK = ROOT / "examples" / "portable-project-pack"
PROFILE = ROOT / "examples" / "execution-profile.local.example.json"
SHA = re.compile(r"^[0-9a-fA-F]{64}$")
SECRET_FIELDS = {"key_bytes", "key_value", "private_key", "secret_value", "password", "token"}


def read_json(path):
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise AssertionError(f"object expected: {path}")
    return value


def walk(value, key=""):
    yield key, value
    if isinstance(value, dict):
        for child_key, child in value.items():
            yield from walk(child, str(child_key))
    elif isinstance(value, list):
        for child in value:
            yield from walk(child, key)


class TestPortableContract(unittest.TestCase):
    def test_contract_and_examples_are_versioned(self):
        contract = read_json(SCHEMA)
        self.assertEqual(contract["schema_version"], "portable-contract/v0.1")
        for path in (PACK / "input_manifest.json", PACK / "project_context.json", PROFILE):
            self.assertEqual(read_json(path)["schema_version"], "portable-contract/v0.1")

    def test_manifest_paths_hashes_and_partitions(self):
        manifest = read_json(PACK / "input_manifest.json")
        self.assertTrue({"APP", "PBL", "SBL", "shared"}.issubset(manifest["partitions"]))
        ids = set()
        for item in manifest["files"]:
            self.assertNotIn(item["id"], ids)
            ids.add(item["id"])
            path = item["path"]
            self.assertNotIn("\\", path)
            self.assertFalse(path.startswith("/"))
            self.assertFalse(re.match(r"^[A-Za-z]:", path))
            self.assertNotIn("..", Path(path).parts)
            self.assertTrue((PACK / Path(path).parent).is_dir(), path)
            self.assertRegex(item["sha256"], SHA)
            self.assertIn(item["partition"], manifest["partitions"])
        self.assertTrue({"APP", "PBL", "SBL"}.issubset({x["partition"] for x in manifest["files"]}))

    def test_context_keeps_evidence_and_explicit_gaps(self):
        manifest = read_json(PACK / "input_manifest.json")
        context = read_json(PACK / "project_context.json")
        file_ids = {item["id"] for item in manifest["files"]}
        partition_ids = {item["id"] for item in context["partitions"]}
        self.assertTrue({"APP", "PBL", "SBL"}.issubset(partition_ids))
        for fact in context["facts"]:
            self.assertIn(fact["partition"], partition_ids)
            self.assertIn(fact["status"], {"confirmed", "derived", "pending", "conflict", "blocked"})
            if fact["status"] in {"confirmed", "derived"}:
                self.assertIsNotNone(fact["source"])
                self.assertIn(fact["source"]["file_id"], file_ids)
            if fact["status"] in {"pending", "conflict", "blocked"}:
                self.assertIsNone(fact["value"])
        self.assertEqual(next(x for x in context["facts"] if x["id"] == "transport.functional_nad")["status"], "pending")
        self.assertEqual(next(x for x in context["facts"] if x["id"] == "security.key_material")["status"], "blocked")

    def test_execution_profile_references_only_machine_and_secret_handles(self):
        profile = read_json(PROFILE)
        self.assertTrue(profile["runtime"]["python"])
        self.assertTrue(profile["transport"]["library_path"])
        for item in profile["secure_key_references"]:
            self.assertFalse(item["material_in_context"])
            self.assertTrue(item["reference"])

    def test_no_secret_material_is_checked_in_as_a_value(self):
        for path in (PACK / "input_manifest.json", PACK / "project_context.json", PROFILE):
            for key, value in walk(read_json(path)):
                self.assertNotIn(key.lower(), SECRET_FIELDS, f"secret field in {path}: {key}")
                if isinstance(value, str):
                    self.assertNotRegex(value, r"(?i)2b7e151628aed2a6abf7158809cf4f3c")
                    self.assertNotRegex(value, r"(?i)0f1571c947d9e8590cb7add6af7f6798")


if __name__ == "__main__":
    unittest.main(verbosity=2)
