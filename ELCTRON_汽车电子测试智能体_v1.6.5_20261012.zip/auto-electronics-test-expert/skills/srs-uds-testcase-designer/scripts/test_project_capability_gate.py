# -*- coding: utf-8 -*-
"""Tests for project-context capability decisions."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent))

from project_capability_gate import evaluate_project_capability  # noqa: E402


class TestProjectCapabilityGate(unittest.TestCase):
    def test_pending_is_degraded_for_generation_but_blocks_hardware(self):
        context = {"facts": [{
            "id": "transport.shared.lin-matrix.status",
            "status": "pending",
            "required_for": ["transport.frames"],
            "source": {"file_id": "lin-matrix", "locator": "adapter"},
        }]}

        generation = evaluate_project_capability(context, "generation")
        hardware = evaluate_project_capability(context, "hardware_execution")

        self.assertEqual(generation["state"], "DEGRADED")
        self.assertEqual(generation["decision"], "allow")
        self.assertEqual(hardware["state"], "BLOCKED")
        self.assertEqual(hardware["decision"], "block")

    def test_blocked_fact_blocks_generation(self):
        context = {"gaps": [{
            "id": "parser.APP.survey.status",
            "status": "blocked",
            "required_for": ["diagnostic.did_definition"],
        }]}

        result = evaluate_project_capability(context, "generation")

        self.assertEqual(result["state"], "BLOCKED")
        self.assertEqual(result["blocking_gaps"][0]["id"], "parser.APP.survey.status")

    def test_validated_project_config_acknowledges_its_pending_adapter_row(self):
        context = {"gaps": [{
            "id": "parser.shared.project-config.status",
            "status": "pending",
            "required_for": ["diagnostic.session_config", "transport.config", "lint.rules"],
        }]}

        result = evaluate_project_capability(
            context,
            "hardware_execution",
            satisfied_domains={"diagnostic.session_config", "transport.config", "lint.rules"},
        )

        self.assertEqual(result["state"], "READY")
        self.assertEqual(result["blocking_gaps"], [])
        self.assertEqual(result["acknowledged_gaps"][0]["id"], "parser.shared.project-config.status")

    def test_conflict_is_always_blocking(self):
        context = {"conflicts": [{"fact_id": "transport.physical_nad"}]}

        result = evaluate_project_capability(context, "generation")

        self.assertEqual(result["state"], "BLOCKED")
        self.assertEqual(result["blocking_gaps"][0]["status"], "conflict")


if __name__ == "__main__":
    unittest.main(verbosity=2)
