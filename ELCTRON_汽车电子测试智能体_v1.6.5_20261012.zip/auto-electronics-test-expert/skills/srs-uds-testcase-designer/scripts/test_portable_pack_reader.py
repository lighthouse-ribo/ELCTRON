# -*- coding: utf-8 -*-
"""Offline tests for the dependency-free portable pack reader."""

from __future__ import annotations

import hashlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from portable_pack_reader import (  # noqa: E402
    PortablePackError,
    inspect_file,
    read_text_excerpt,
    resolve_pack_path,
)


class TestPortablePackReader(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="portable_pack_reader_")
        os.makedirs(os.path.join(self.tmp, "docs"), exist_ok=True)
        self.file_path = os.path.join(self.tmp, "docs", "facts.txt")
        with open(self.file_path, "wb") as stream:
            stream.write(b"physical_nad=0x51\n" + b"x" * 20)

    def test_resolve_relative_path_and_reject_escape(self):
        self.assertEqual(resolve_pack_path(self.tmp, "docs/facts.txt"), Path(self.file_path).resolve())
        for unsafe in ("../facts.txt", "/tmp/facts.txt", "C:/facts.txt", "docs\\facts.txt"):
            with self.subTest(path=unsafe), self.assertRaises(PortablePackError):
                resolve_pack_path(self.tmp, unsafe)

    def test_inspect_file_reports_full_hash_and_match(self):
        expected = hashlib.sha256(b"physical_nad=0x51\n" + b"x" * 20).hexdigest()
        result = inspect_file(self.tmp, "docs/facts.txt", expected_sha256=expected)
        self.assertTrue(result["exists"])
        self.assertTrue(result["is_file"])
        self.assertEqual(result["sha256"], expected)
        self.assertTrue(result["hash_ok"])
        self.assertNotIn(self.tmp, json.dumps(result))

    def test_hash_mismatch_and_missing_file_are_explicit(self):
        mismatch = inspect_file(self.tmp, "docs/facts.txt", expected_sha256="0" * 64)
        self.assertFalse(mismatch["hash_ok"])
        missing = inspect_file(self.tmp, "docs/missing.txt")
        self.assertFalse(missing["exists"])
        self.assertIsNone(missing["hash_ok"])

    def test_excerpt_is_bounded(self):
        self.assertEqual(len(read_text_excerpt(self.file_path, max_chars=8)), 8)


if __name__ == "__main__":
    unittest.main(verbosity=2)
