# -*- coding: utf-8 -*-
"""case_lint 规则校验纯逻辑单元测试（离线，无硬件依赖）。

覆盖 R1~R5 五条规则 + 会话映射/字段提取辅助函数。
默认配置下的期望值依据 SKILL.md 与专家包兼容规则（0x11 非法子功能 NRC=0x12、负例必须断言 NRC、
0x27 受保护服务必须声明会话前置、只读 DID 不得生成 0x2E 写入正例）。
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))  # noqa: E402

from case_lint import (  # noqa: E402
    check_case,
    extract_did_from_procedure,
    extract_sa_level,
    parse_sa_session_map,
)


CUSTOM_CONFIG = {
    "sessions": {
        "supported": ["0x01", "0x04"],
        "names": {"0x01": "Normal", "0x04": "Diag"},
        "allowed_transitions": {"0x01": ["0x01"], "0x04": ["0x01", "0x04"]},
        "default": "0x01",
        "transition_nrc": "0x24",
    },
    "security": {
        "level_to_sessions": {"0x07": ["0x04"]},
        "default_level_sessions": ["0x04"],
    },
    "nrc": {"illegal_subfunction": {"0x11": "0x13"}},
    "lint": {
        "read_only_dids": ["A001"],
        "negative_keywords": ["DENY"],
        "require_nrc_for_negative": True,
        "require_session_for_security": True,
        "enabled_rules": ["R1", "R2", "R3", "R4", "R5"],
    },
}


def _case(**kw):
    base = {
        "case_id": "?",
        "test_point": "",
        "procedure": "",
        "expected": "",
        "precondition": "",
    }
    base.update(kw)
    return base


class TestParseSaSessionMap(unittest.TestCase):
    """--sa-session-map '01:02,05:03' -> {0x01:[0x02], 0x05:[0x03]}"""

    def test_override(self):
        m = parse_sa_session_map("01:02,05:03")
        self.assertEqual(m[0x01], [0x02])
        self.assertEqual(m[0x05], [0x03])

    def test_default_kept_for_unlisted(self):
        # 未覆盖的等级保留默认（01/02->编程会话 0x02）
        m = parse_sa_session_map("05:03")
        self.assertEqual(m[0x01], [0x02])

    def test_empty_returns_default(self):
        m = parse_sa_session_map("")
        self.assertEqual(m[0x01], [0x02])
        self.assertEqual(m[0x05], [0x03])

    def test_multi_session_with_semicolon(self):
        m = parse_sa_session_map("01:02;03")
        self.assertEqual(m[0x01], [0x02, 0x03])

    def test_invalid_pair_ignored(self):
        m = parse_sa_session_map("garbage,05:03")
        self.assertEqual(m[0x05], [0x03])


class TestExtractors(unittest.TestCase):
    def test_did_from_2e(self):
        self.assertEqual(extract_did_from_procedure("2E F1 2C + 数据"), "F12C")

    def test_did_none_for_other_service(self):
        self.assertIsNone(extract_did_from_procedure("22 F1 2C"))

    def test_sa_level(self):
        self.assertEqual(extract_sa_level("安全访问 等级0x01 正向"), 0x01)

    def test_sa_level_none(self):
        self.assertIsNone(extract_sa_level("安全访问正例"))


class TestCheckCaseR1(unittest.TestCase):
    """R1: 0x2E 写入正例不得含只读 DID"""

    def test_ro_did_fail(self):
        c = _case(case_id="UDS_0x2E_TC_0001",
                  test_point="0x2E 写入 正向",
                  procedure="2E F1 0A 01")
        checks = check_case(c, ro_dids={"F10A"}, sa_session_map={})
        self.assertTrue(any(r == "R1" and s == "FAIL" for r, s, _ in checks))

    def test_normal_did_pass(self):
        c = _case(case_id="UDS_0x2E_TC_0002",
                  test_point="0x2E 写入 正向",
                  procedure="2E F1 2C 01")
        checks = check_case(c, ro_dids={"F10A"}, sa_session_map={})
        self.assertTrue(any(r == "R1" and s == "PASS" for r, s, _ in checks))


class TestCheckCaseR2(unittest.TestCase):
    """R2: 0x27 等级会话归属（01->编程会话 0x02）"""

    def test_correct_session_pass(self):
        c = _case(case_id="UDS_0x27_TC_0001",
                  test_point="安全访问 等级0x01 正向",
                  precondition="编程会话（0x10 02）")
        checks = check_case(c, ro_dids=set(), sa_session_map={0x01: [0x02]})
        self.assertTrue(any(r == "R2" and s == "PASS" for r, s, _ in checks))

    def test_wrong_session_fail(self):
        c = _case(case_id="UDS_0x27_TC_0001",
                  test_point="安全访问 等级0x01 正向",
                  precondition="扩展会话（0x10 03）")
        checks = check_case(c, ro_dids=set(), sa_session_map={0x01: [0x02]})
        self.assertTrue(any(r == "R2" and s == "FAIL" for r, s, _ in checks))


class TestCheckCaseR3(unittest.TestCase):
    """R3: 0x11 非法子功能负例 NRC 必须为 0x12"""

    def test_nrc_present_pass(self):
        c = _case(case_id="UDS_0x11_TC_0003",
                  test_point="0x11 非法子功能 负例",
                  expected="7F 11 12 subFunctionNotSupported")
        checks = check_case(c, ro_dids=set(), sa_session_map={})
        self.assertTrue(any(r == "R3" and s == "PASS" for r, s, _ in checks))

    def test_nrc_missing_fail(self):
        c = _case(case_id="UDS_0x11_TC_0003",
                  test_point="0x11 非法子功能 负例",
                  expected="DUT 返回负响应")
        checks = check_case(c, ro_dids=set(), sa_session_map={})
        self.assertTrue(any(r == "R3" and s == "FAIL" for r, s, _ in checks))

    def test_other_negative_case_does_not_trigger_illegal_subfunction_rule(self):
        c = _case(case_id="UDS_0x27_TC_0004",
                  test_point="安全访问 错误密钥 负例",
                  expected="7F 27 35 invalidKey")
        checks = check_case(
            c, ro_dids=set(), sa_session_map={},
            project_config={"nrc": {"illegal_subfunction": {"0x27": "0x14"}}},
        )
        self.assertFalse(any(r == "R3" for r, _s, _ in checks))


class TestCheckCaseR4(unittest.TestCase):
    """R4: 负例必须断言具体 NRC"""

    def test_negative_with_nrc_pass(self):
        c = _case(case_id="UDS_0x22_TC_0004",
                  test_point="未解锁 拒绝 负例",
                  expected="NRC=0x33")
        checks = check_case(c, ro_dids=set(), sa_session_map={})
        self.assertTrue(any(r == "R4" and s == "PASS" for r, s, _ in checks))

    def test_negative_without_nrc_fail(self):
        c = _case(case_id="UDS_0x22_TC_0004",
                  test_point="未解锁 拒绝 负例",
                  expected="DUT 无响应")
        checks = check_case(c, ro_dids=set(), sa_session_map={})
        self.assertTrue(any(r == "R4" and s == "FAIL" for r, s, _ in checks))


class TestCheckCaseR5(unittest.TestCase):
    """R5: 0x27 相关用例必须声明会话前置"""

    def test_session_declared_pass(self):
        c = _case(case_id="UDS_0x27_TC_0001",
                  test_point="0x27 正向",
                  precondition="默认会话 + 扩展会话")
        checks = check_case(c, ro_dids=set(), sa_session_map={})
        self.assertTrue(any(r == "R5" and s == "PASS" for r, s, _ in checks))

    def test_session_missing_fail(self):
        c = _case(case_id="UDS_0x27_TC_0001",
                  test_point="0x27 正向",
                  precondition="供电 12V")
        checks = check_case(c, ro_dids=set(), sa_session_map={})
        self.assertTrue(any(r == "R5" and s == "FAIL" for r, s, _ in checks))


class TestProjectConfigRules(unittest.TestCase):
    def test_custom_read_only_did_and_security_session_mapping(self):
        read_only = _case(case_id="UDS_0x2E_TC_A001", test_point="0x2E 写入 正向",
                          procedure="2E A0 01 00")
        checks = check_case(read_only, project_config=CUSTOM_CONFIG)
        self.assertTrue(any(r == "R1" and s == "FAIL" for r, s, _ in checks))

        security = _case(case_id="UDS_0x27_TC_0007", test_point="安全访问 等级0x07 正向",
                         precondition="Diag")
        checks = check_case(security, project_config=CUSTOM_CONFIG)
        self.assertTrue(any(r == "R2" and s == "PASS" for r, s, _ in checks))

    def test_custom_illegal_subfunction_nrc_and_bare_nrc_syntax(self):
        case = _case(case_id="UDS_0x11_TC_0003", test_point="非法子功能",
                     expected="NRC 0x13")
        checks = check_case(case, project_config=CUSTOM_CONFIG)
        self.assertTrue(any(r == "R3" and s == "PASS" for r, s, _ in checks))

    def test_custom_negative_keyword_and_rule_disable(self):
        case = _case(case_id="UDS_0x22_TC_DENY", test_point="DENY",
                     expected="DUT 返回负响应")
        checks = check_case(case, project_config=CUSTOM_CONFIG)
        self.assertTrue(any(r == "R4" and s == "FAIL" for r, s, _ in checks))

        # The project's keyword list replaces the default text classifier.
        non_negative = _case(case_id="UDS_0x22_TC_CN", test_point="拒绝",
                             expected="DUT 返回负响应")
        checks = check_case(non_negative, project_config=CUSTOM_CONFIG)
        self.assertFalse(any(r == "R4" for r, _, _ in checks))

        disabled = dict(CUSTOM_CONFIG)
        disabled["lint"] = dict(CUSTOM_CONFIG["lint"], enabled_rules=["R1", "R2", "R3", "R4"])
        security = _case(case_id="UDS_0x27_TC_NO_SESSION", test_point="安全访问 等级0x07 正向",
                         precondition="供电 12V")
        checks = check_case(security, project_config=disabled)
        self.assertFalse(any(r == "R5" for r, _, _ in checks))


if __name__ == "__main__":
    unittest.main()
