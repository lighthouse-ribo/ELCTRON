#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""系统合格性测试用例表头共享常量（19 列，B~T）。

唯一权威文案：build_testcase_xlsx.py 原版表头（2026-09-04 用户决策「xlsx 版为准」）。
build_testcase_template.py 与 build_testcase_xlsx.py 统一从这里导入 HEADERS，
禁止再各自维护本地副本（B5 冗余合并，见 deliverables/2026-09-04_模块冗余审计_RedundancyAudit.md 第 11 节）。
"""

HEADERS = [
    "需求来源\nRequirement Sources", "需求ID\nRequirement ID", "用例ID\nTest case ID",
    "优先级\n优先级级别", "自动化评估\nAutomatic evaluation", "测试点",
    "测试方法Test Type", "用例设计方法\nDesign method", "测试环境",
    "前提条件\nPrecondition", "操作步骤\nProcedure", "预期结果",
    "选择测试用例", "测试结果\nTest Results", "测试结论\nTest conclusion",
    "缺陷编号Defect ID", "测试者\nTester", "测试日期\nTest data",
    "备注(其他信息填写)\nComment",
]

assert len(HEADERS) == 19, "表头必须为 19 列（B~T）"
