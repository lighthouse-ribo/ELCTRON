# -*- coding: utf-8 -*-
"""Turn portable project-context gaps into explicit execution decisions."""

from __future__ import annotations

from typing import Any, Mapping


SCHEMA = "project-capability-gate/v0.1"
VALID_CAPABILITIES = {"generation", "hardware_execution", "swdl_execution"}
BLOCKING_STATUSES = {
    "generation": {"blocked", "conflict"},
    "hardware_execution": {"pending", "blocked", "conflict"},
    "swdl_execution": {"pending", "blocked", "conflict"},
}
STATUS_PRIORITY = {"pending": 1, "blocked": 2, "conflict": 3}


def _source_ref(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    return {
        key: value[key]
        for key in ("file_id", "locator")
        if key in value
    } or None


def _gap_rows(context: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Collect gap evidence without copying fact values into the gate result."""
    rows: dict[str, dict[str, Any]] = {}
    for source_name in ("facts", "gaps"):
        for item in context.get(source_name) or []:
            if not isinstance(item, Mapping):
                continue
            status = str(item.get("status", ""))
            if status not in STATUS_PRIORITY:
                continue
            item_id = str(item.get("id", ""))
            if not item_id:
                continue
            candidate = {
                "id": item_id,
                "status": status,
                "required_for": list(item.get("required_for") or []),
                "source": _source_ref(item.get("source")),
            }
            current = rows.get(item_id)
            if (
                current is None
                or STATUS_PRIORITY[status] > STATUS_PRIORITY[current["status"]]
                or (
                    STATUS_PRIORITY[status] == STATUS_PRIORITY[current["status"]]
                    and not current.get("required_for")
                    and candidate.get("required_for")
                )
            ):
                rows[item_id] = candidate

    for item in context.get("conflicts") or []:
        if not isinstance(item, Mapping) or not item.get("fact_id"):
            continue
        item_id = str(item["fact_id"])
        rows[item_id] = {
            "id": item_id,
            "status": "conflict",
            "required_for": [],
            "source": _source_ref(item.get("incoming_source") or item.get("existing_source")),
        }
    return list(rows.values())


def evaluate_project_capability(
    context: Mapping[str, Any],
    capability: str,
    *,
    satisfied_domains: set[str] | frozenset[str] = frozenset(),
) -> dict[str, Any]:
    """Evaluate one stage; no project values or raw documents enter the result."""
    if capability not in VALID_CAPABILITIES:
        raise ValueError(f"未知项目能力: {capability}")

    acknowledged: list[dict[str, Any]] = []
    pending: list[dict[str, Any]] = []
    blocking: list[dict[str, Any]] = []
    blocking_statuses = BLOCKING_STATUSES[capability]
    domains = set(satisfied_domains or ())

    for row in _gap_rows(context):
        required_for = set(row.get("required_for") or ())
        if row["status"] == "pending" and required_for and required_for <= domains:
            acknowledged.append({
                "id": row["id"],
                "status": row["status"],
                "required_for": sorted(required_for),
                "reason": "required domain supplied by validated execution input",
            })
            continue
        if row["status"] in blocking_statuses:
            blocking.append(row)
        elif row["status"] == "pending":
            pending.append(row)

    if blocking:
        state = "BLOCKED"
        decision = "block"
    elif pending:
        state = "DEGRADED"
        decision = "allow"
    else:
        state = "READY"
        decision = "allow"

    return {
        "$schema": SCHEMA,
        "capability": capability,
        "state": state,
        "decision": decision,
        "blocking_gaps": blocking,
        "pending_gaps": pending,
        "acknowledged_gaps": acknowledged,
        "satisfied_domains": sorted(domains),
    }


__all__ = ["SCHEMA", "VALID_CAPABILITIES", "evaluate_project_capability"]
