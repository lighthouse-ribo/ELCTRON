# -*- coding: utf-8 -*-
"""
input_pack_validator.py — UDS 测试输入文件包校验器（可移植性核心）
====================================================================
目的：
  把「一次 UDS 测试任务需要的全部输入」打包为一个可搬运的目录
  （input_manifest.json + 各输入文件 + project_config.json），
  本脚本对包做一键体检，输出「每个文件的状态 + 每个用例模块的
  READY / DEGRADED / BLOCKED 判定 + 下一步动作」，做到：
  - 换机器 / 换专家 / 交接项目时，包拷走即可恢复全部输入上下文
  - 用例设计前就知道哪些模块会被阻塞，避免"文件不够就硬生成"

manifest 格式（模板见 skills/input_manifest.example.json）：
  {
    "$schema": "input-pack-manifest/v1",
    "project": {"name": "...", "customer": "...", "target_ecu": "...", "sw_version": "...", "bus": "LIN|CAN", "notes": ""},
    "files": [ {"role": "diag_survey", "path": "survey/xxx_diagnostic.xlsx", "notes": "..."}, ... ]
  }
  path 相对于 manifest 所在目录。

角色契约（与 references/input-file-spec.md §5 一致）：
  P0 核心  diag_survey / did_checklist / project_config
  P1 高价值 swrs / ldf(LIN) / dbc(CAN)
  P2 有用  srs / lin_matrix / security_key_doc
  P3 按需  flash_flowchart / security_req_list / cdd
  other    其他补充文件（只做存在性校验）

深度校验（尽力而为，失败不阻断）：
  - swrs/srs(txt/md/pdf) → 调 srs_input_analyzer.analyze()：DID/服务/REQ/缺口
  - diag_survey(xlsx/csv/json/cdd) → 调 uds_survey_parser.parse_survey_table()：对象计数
  - project_config(json) → 校验 sessions/transport 关键节点
  - ldf/dbc → 文本特征嗅探（LIN_description_file / BO_ 段）

用法：
  python input_pack_validator.py --pack <包目录>            # 读 <包目录>/input_manifest.json
  python input_pack_validator.py --manifest <path.json>     # 显式指定 manifest
  选项：--out-prefix pack_readiness（默认）｜--no-deep 跳过深度校验

输出：
  控制台摘要 + <包目录>/pack_readiness.json + pack_readiness.md
退出码：0=READY；1=PARTIAL（P1 缺失，可继续但记录缺口）；2=NOT_READY（P0 缺失，停止）
"""

import sys
import os
import re
import json
import hashlib
import argparse
import datetime

try:
    from portable_pack_reader import (
        PortablePackError,
        SHA256_RE,
        inspect_file,
        load_json,
        resolve_pack_path,
        sha256_file,
    )
except ImportError:  # pragma: no cover - supports package-style imports
    from .portable_pack_reader import (
        PortablePackError,
        SHA256_RE,
        inspect_file,
        load_json,
        resolve_pack_path,
        sha256_file,
    )

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

__version__ = "1.1.0"

# ---------------- 角色契约 ----------------
ROLES = {
    "diag_survey":     {"label": "诊断调查表", "priority": "P0", "desc": "DID/服务/例程/时序/会话/安全约束的权威来源"},
    "did_checklist":   {"label": "DID 检查表", "priority": "P0", "desc": "真实抓帧 + DID×APP/PBL/SBL 支持矩阵（条件受限判定证据）"},
    "project_config":  {"label": "项目配置", "priority": "P0", "desc": "会话/NAD/安全等级/NRC/lint 项目参数"},
    "swrs":            {"label": "SWRS 软件需求规范", "priority": "P1", "desc": "真实需求 ID（REQ-xxxx），追溯权威源"},
    "ldf":             {"label": "LDF 描述文件", "priority": "P1", "desc": "LIN 帧/PID/信号/调度表/functional_id"},
    "dbc":             {"label": "DBC 通信矩阵", "priority": "P1", "desc": "CAN 报文/信号编解码（CAN 节点）"},
    "srs":             {"label": "SRS 系统需求规范", "priority": "P2", "desc": "功能概述/诊断帧样例/章节"},
    "lin_matrix":      {"label": "LIN Matrix", "priority": "P2", "desc": "NAD/波特率/调度表/信号名（LDF 兜底）"},
    "security_key_doc": {"label": "0x27 密钥/算法文档", "priority": "P2", "desc": "SeedKey 算法与真实密钥值来源"},
    "flash_flowchart": {"label": "刷写流程图", "priority": "P3", "desc": "0x34/0x36/0x37 块大小/地址/时序/异常分支"},
    "security_req_list": {"label": "网络安全需求清单", "priority": "P3", "desc": "安全用例依据"},
    "cdd":             {"label": "CDD 诊断文件", "priority": "P3", "desc": "DID 信号级定义（调查表替代）"},
    "other":           {"label": "其他补充文件", "priority": "-", "desc": "只做存在性校验"},
}

# 缺失角色 → 用例模块影响（与 input-file-spec.md 优先级总表一致）
MISSING_IMPACT = {
    "diag_survey":      [("UDS 用例参数化设计", "BLOCKED", "P0 缺失：无法设计参数化用例，按规范应停止并向用户索要")],
    "did_checklist":    [("条件受限场景判定", "DEGRADED", "P0 缺失：分层受限（NRC31/NRC22）与公钥/常量场景无法判定，用调查表兜底")],
    "project_config":   [("项目参数一致性", "DEGRADED", "P0 缺失：会话/NAD/安全等级回退兼容默认，生成前必须走强制确认")],
    "swrs":             [("需求追溯", "DEGRADED", "P1 缺失：REQ ID 自动生成（REQ-<章节>.<序号>），追溯降级")],
    "ldf":              [("LIN 帧级步骤 hex", "DEGRADED", "P1 缺失（LIN 节点）：帧级步骤写「按 LIN Matrix」，功能寻址 NAD 无法从 functional_id 确认")],
    "dbc":              [("CAN 报文级步骤 hex", "DEGRADED", "P1 缺失（CAN 节点）：报文级步骤无法自动生成 hex")],
    "lin_matrix":       [("LIN 帧定义兜底", "DEGRADED", "P2 缺失：LDF 也缺失时 LIN 用例帧级步骤无法落地")],
    "security_key_doc": [("0x27 正例与受保护服务执行", "BLOCKED", "P2 缺失：无真实密钥值 → 0x27 全部 BLOCKED，不伪造 PASS")],
    "flash_flowchart":  [("SWDL 刷写用例", "BLOCKED", "P3 缺失：刷写时序/块大小未知 → 刷写模块 BLOCKED")],
    "security_req_list": [("网络安全用例依据", "DEGRADED", "P3 缺失：安全用例缺需求锚点")],
    "cdd":              [("DID 信号级定义", "DEGRADED", "P3 缺失：回退调查表手工定义")],
    "srs":              [("功能概览输入", "DEGRADED", "P2 缺失：仅以 SWRS/调查表为准")],
}

DOC_KINDS = (".txt", ".md", ".pdf", ".docx")


def sha256_of(path, cap=200 * 1024 * 1024):
    try:
        return sha256_file(path, cap_bytes=cap)[:16] + "…"
    except (OSError, PortablePackError):
        return "(不可读)"


def _is_portable_manifest(manifest):
    return manifest.get("$schema") == "portable-contract/v0.1" or manifest.get("schema_version") == "portable-contract/v0.1"


def validate_manifest_structure(manifest):
    """Validate cheap, format-independent manifest references."""

    errors = []
    entries = manifest.get("files")
    if not isinstance(entries, list):
        return ["manifest 缺少 files 数组（格式见 skills/input_manifest.example.json）"]

    portable = _is_portable_manifest(manifest)
    if portable:
        for field in ("schema_version", "project", "partitions"):
            if field not in manifest:
                errors.append("portable manifest 缺少字段：%s" % field)
        if manifest.get("schema_version") != "portable-contract/v0.1":
            errors.append("portable manifest schema_version 必须为 portable-contract/v0.1")
        if not isinstance(manifest.get("partitions"), list) or not manifest.get("partitions"):
            errors.append("portable manifest partitions 必须是非空数组")

    seen_ids = set()
    seen_paths = set()
    partitions = set(manifest.get("partitions") or []) if portable else None
    for index, ent in enumerate(entries):
        if not isinstance(ent, dict):
            errors.append("files[%d] 必须是对象" % index)
            continue
        file_id = ent.get("id")
        if file_id:
            if file_id in seen_ids:
                errors.append("重复的文件 id：%s" % file_id)
            seen_ids.add(file_id)
        elif portable:
            errors.append("portable files[%d] 缺少 id" % index)

        rel = ent.get("path")
        if not isinstance(rel, str) or not rel.strip():
            errors.append("files[%d] 缺少 path" % index)
        else:
            normalized = rel.strip()
            if normalized in seen_paths:
                errors.append("重复的文件 path：%s" % normalized)
            seen_paths.add(normalized)

        if portable:
            for field in ("role", "partition", "sha256", "sensitivity", "authority"):
                if field not in ent:
                    errors.append("portable files[%d] 缺少 %s" % (index, field))
            if ent.get("partition") not in partitions:
                errors.append("files[%d] 的 partition 未声明：%s" % (index, ent.get("partition")))
            digest = str(ent.get("sha256", ""))
            if not SHA256_RE.fullmatch(digest):
                errors.append("files[%d] 的 sha256 格式无效" % index)
    return errors


def validate_project_context(pack_dir, manifest):
    """Check only context references; content parsers remain outside this step."""

    result = {"present": False, "ok": True, "errors": []}
    context_path = os.path.join(pack_dir, "project_context.json")
    if not os.path.isfile(context_path):
        if _is_portable_manifest(manifest):
            result["ok"] = False
            result["errors"].append("portable pack 缺少 project_context.json")
        return result
    result["present"] = True
    try:
        context = load_json(context_path)
    except PortablePackError as exc:
        result["ok"] = False
        result["errors"].append(str(exc))
        return result
    if not isinstance(context, dict) or context.get("schema_version") != "portable-contract/v0.1":
        result["ok"] = False
        result["errors"].append("project_context.json schema_version 必须为 portable-contract/v0.1")
        return result

    manifest_ids = {ent.get("id") for ent in manifest.get("files", []) if isinstance(ent, dict)}
    partition_ids = {
        item if isinstance(item, str) else item.get("id")
        for item in (context.get("partitions") or [])
    }
    if not partition_ids:
        result["ok"] = False
        result["errors"].append("project_context.json 缺少 partitions")
    for fact in context.get("facts") or []:
        if not isinstance(fact, dict):
            result["ok"] = False
            result["errors"].append("project_context facts 必须是对象")
            continue
        if fact.get("partition") not in partition_ids:
            result["ok"] = False
            result["errors"].append("fact 分区未声明：%s" % fact.get("partition"))
        status = fact.get("status")
        source = fact.get("source")
        if status in ("confirmed", "derived"):
            if not isinstance(source, dict) or source.get("file_id") not in manifest_ids:
                result["ok"] = False
                result["errors"].append("fact %s 的 source.file_id 未在 manifest 中声明" % fact.get("id"))
        if status in ("pending", "conflict", "blocked") and fact.get("value") is not None:
            result["ok"] = False
            result["errors"].append("fact %s 的缺口状态必须使用 null value" % fact.get("id"))
    return result


# ---------------- 深度校验（尽力而为） ----------------
def _import_from(path, name):
    import importlib.util
    # realpath 归一化 ".." 段：DLP/沙箱环境下未归一化路径的 open 可能 FileNotFoundError
    # （2026-09-04 真实包实测踩中：scripts\..\uds-diagnostic-test\... 报 FileNotFoundError）
    path = os.path.realpath(path)
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ---------------- 0x27 密钥文档内容级检查 ----------------
# 实测教训（2026-09-04，BBS 项目）：27SecurityAccess秘钥.docx 有完整 AES-CTR/CMAC
# 流程和密钥名（AES_ctr_key_0102），但全文 0 个实际密钥字节 → 存在性检查会误放行。
# 原则（input-file-spec.md §"0x27 密钥文档 ≠ 密钥值"）：算法流程 ≠ 密钥值。
KEY_VALUE_RE = re.compile(r"\b[0-9A-Fa-f]{16,}\b")  # ≥8 字节连续 hex（候选密钥材料）
KEY_DEF_RE = re.compile(
    r"(?:key|密钥|secret|private|modulus|种子|seed)[^\n]{0,60}?[=:：]\s*\"?"
    r"([0-9A-Fa-f]{16,}|[A-Za-z0-9+/]{24,}={0,2})\"?", re.I)
KEY_ALGO_HINT_RE = re.compile(r"AES|CMAC|CTR|seed.?key|securityaccess|0x27|27服务|密钥", re.I)


def _keydoc_text(path):
    """密钥文档 → 全文文本（docx 含表格；pdf/txt/md/json/xlsx 均支持）"""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".txt", ".md", ".json"):
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    if ext == ".docx":
        import docx
        d = docx.Document(path)
        parts = [p.text for p in d.paragraphs]
        for t in d.tables:
            for r in t.rows:
                parts.append(" | ".join(c.text for c in r.cells))
        return "\n".join(parts)
    if ext == ".pdf":
        import fitz
        return "\n".join(p.get_text() for p in fitz.open(path))
    if ext in (".xlsx", ".xls"):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        return "\n".join(str(c.value) for ws in wb.worksheets
                         for row in ws.iter_rows() for c in row if c.value is not None)
    raise ValueError("不支持的扩展名 %s" % ext)


def deep_check_keydoc(path):
    """内容级判定三级：
    ① 发现密钥材料（定义/候选值）→ keycheck=True
    ② 有算法/密钥名但无值 → keycheck=False（0x27 仍 BLOCKED）
    ③ 连算法描述都没有 → keycheck=False
    注意：RSA 公钥（非对称）不等于 0x27 AES 对称密钥，msg 会带出字段名供人工核对。
    """
    try:
        text = _keydoc_text(path)
    except Exception as e:
        return {"ok": False, "keycheck": None, "msg": "密钥文档读取失败 %r" % e}
    if not text.strip():
        return {"ok": False, "keycheck": False, "msg": "密钥文档内容为空"}
    defs = [m.group(1) for m in KEY_DEF_RE.finditer(text)]
    # 独立候选值要求含 a-f 字母，降低把长数字编号误判成密钥的概率
    values = [m.group(0) for m in KEY_VALUE_RE.finditer(text) if re.search(r"[A-Fa-f]", m.group(0))]
    has_algo = bool(KEY_ALGO_HINT_RE.search(text))
    if defs or values:
        sample = (defs or values)[0]
        return {"ok": True, "keycheck": True,
                "msg": "发现密钥材料：定义 %d 处 / 候选值 %d 处（样例 %s…）——注意核对是否为 0x27 所需对称密钥" % (
                    len(defs), len(values), sample[:16])}
    if has_algo:
        return {"ok": False, "keycheck": False,
                "msg": "有算法流程/密钥名描述，但未发现实际密钥值 → 0x27 无法实测"}
    return {"ok": False, "keycheck": False, "msg": "未识别出 SeedKey 算法描述或密钥材料"}


def deep_check_doc(path):
    """swrs/srs 文档 → 复用 srs_input_analyzer 的解析与体检"""
    here = os.path.dirname(os.path.abspath(__file__))
    analyzer = _import_from(os.path.join(here, "srs_input_analyzer.py"), "srs_input_analyzer_for_pack")
    ext = os.path.splitext(path)[1].lower()
    if ext in (".txt", ".md"):
        with open(path, encoding="utf-8", errors="replace") as f:
            text = f.read()
        extra = {"chars": len(text)}
    elif ext == ".docx":
        parse_info, _t = analyzer.parse_file(path)
        text, _h, extra = parse_info
    elif ext == ".pdf":
        import fitz
        doc = fitz.open(path)
        text = "\n".join(p.get_text() for p in doc)
        extra = {"pages": len(doc)}
    else:
        return {"ok": False, "msg": "不支持的扩展名 %s" % ext}
    analysis = analyzer.analyze(text, [], extra)
    v = analysis["verdict"]
    return {"ok": True, "msg": "体检结论=%s｜DID=%d 帧=%d 服务=%d 外部引用=%d" % (
        v["can_generate"], len(analysis["dids"]), len(analysis["frames"]),
        len(analysis["services"]), len(analysis["ext_files"]) + len(analysis["other_refs"]))}


def deep_check_survey(path):
    # 注意两级上跳：here=skills/<本技能>/scripts，uds_survey_parser 在兄弟技能
    # skills/uds-diagnostic-test/scripts 下（一级上跳是 2026-09-04 真实包实测踩中的 bug）
    here = os.path.dirname(os.path.abspath(__file__))
    parser = _import_from(os.path.join(here, "..", "..", "uds-diagnostic-test", "scripts", "uds_survey_parser.py"),
                          "uds_survey_parser_for_pack")
    data = parser.parse_survey_table(path)
    n_did = len(data.get("dids") or [])
    n_rid = len(data.get("routines") or [])
    n_dtcs = len(data.get("dtcs") or [])
    return {"ok": n_did > 0, "msg": "解析成功：DID=%d 例程=%d DTC=%d%s" % (
        n_did, n_rid, n_dtcs, "" if n_did else "（DID=0，表头可能不被识别，用例设计阶段用 sddb_extract 适配）")}


def deep_check_config(path):
    with open(path, encoding="utf-8") as f:
        cfg = json.load(f)
    missing = [k for k in ("sessions", "transport") if k not in cfg]
    if missing:
        return {"ok": False, "msg": "缺少关键节点：%s（对照 skills/project_config.example.json）" % ",".join(missing)}
    return {"ok": True, "msg": "关键节点齐全（sessions/transport）"}


def sniff_text(path, patterns):
    try:
        with open(path, "rb") as f:
            head = f.read(65536)
        text = head.decode("utf-8", errors="replace")
        for p in patterns:
            if p.lower() in text.lower():
                return {"ok": True, "msg": "特征嗅探通过（%s…）" % p}
        return {"ok": False, "msg": "未嗅探到特征（%s），请确认文件格式" % "/".join(patterns[:2])}
    except OSError as e:
        return {"ok": False, "msg": "读取失败 %r" % e}


def deep_check(path, role):
    ext = os.path.splitext(path)[1].lower()
    try:
        if role in ("swrs", "srs") and ext in DOC_KINDS:
            return deep_check_doc(path)
        if role == "diag_survey" and ext in (".xlsx", ".xls", ".csv", ".json", ".cdd"):
            return deep_check_survey(path)
        if role == "project_config" and ext == ".json":
            return deep_check_config(path)
        if role == "ldf" and ext == ".ldf":
            return sniff_text(path, ["LIN_description_file", "frames {", "nodes {"])
        if role == "dbc" and ext == ".dbc":
            return sniff_text(path, ["VERSION", "BO_ "])
        if role == "security_key_doc":
            return deep_check_keydoc(path)
    except SystemExit:
        return {"ok": False, "msg": "解析器主动中止（如深层加密 PDF，请先走 srs-doc-extract）"}
    except Exception as e:  # 深度校验失败不阻断
        return {"ok": False, "msg": "深度校验异常 %r（不阻断，用例设计阶段实测）" % e}
    return {"ok": None, "msg": "该角色/扩展名组合未配置深度校验"}


# ---------------- 主流程 ----------------
def validate_pack(manifest_path, do_deep=True):
    pack_dir = os.path.dirname(os.path.abspath(manifest_path))
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict):
        raise ValueError("manifest 根节点必须是对象")
    if not isinstance(manifest.get("files"), list):
        raise ValueError("manifest 缺少 files 数组（格式见 skills/input_manifest.example.json）")

    manifest_errors = validate_manifest_structure(manifest)
    context_result = validate_project_context(pack_dir, manifest)
    if _is_portable_manifest(manifest) and not context_result["ok"]:
        manifest_errors.extend("context: " + item for item in context_result["errors"])

    file_rows = []
    present_roles = set()
    for ent in manifest["files"]:
        role = ent.get("role", "other")
        rel = ent.get("path", "")
        expected_sha256 = ent.get("sha256")
        metadata = inspect_file(pack_dir, rel, expected_sha256=expected_sha256)
        if metadata["path_error"]:
            manifest_errors.append("文件 %s: %s" % (rel, metadata["path_error"]))
        if metadata["read_error"]:
            manifest_errors.append("文件 %s: %s" % (rel, metadata["read_error"]))
        if metadata["hash_ok"] is False:
            manifest_errors.append("文件 SHA-256 不匹配：%s" % rel)

        p = None
        if metadata["exists"] and metadata["is_file"]:
            try:
                p = resolve_pack_path(pack_dir, rel)
            except PortablePackError:
                p = None
        row = {"id": ent.get("id"), "role": role, "label": ROLES.get(role, {}).get("label", role),
               "priority": ROLES.get(role, {}).get("priority", "-"),
               "partition": ent.get("partition", "shared"), "path": rel,
               "exists": bool(metadata["exists"] and metadata["is_file"]),
               "size_kb": None, "sha256_16": None, "sha256": metadata["sha256"],
               "expected_sha256": expected_sha256, "hash_ok": metadata["hash_ok"],
               "path_error": metadata["path_error"], "type_ok": None, "deep": None}
        kinds = {"diag_survey": (".xlsx", ".xls", ".csv", ".json", ".cdd"),
                 "did_checklist": (".xlsx", ".xls", ".csv", ".pdf", ".docx"),
                 "project_config": (".json",), "swrs": DOC_KINDS, "srs": DOC_KINDS,
                 "ldf": (".ldf",), "dbc": (".dbc",), "cdd": (".cdd", ".xlsx"),
                 "lin_matrix": (".xlsx", ".xls"), "security_key_doc": DOC_KINDS + (".json", ".xlsx"),
                 "flash_flowchart": (".pdf", ".docx", ".png", ".jpg", ".vsdx", ".html"),
                 "security_req_list": (".xlsx", ".xls", ".pdf", ".docx")}.get(role)
        if row["exists"]:
            row["size_kb"] = round(metadata["size_bytes"] / 1024, 1)
            row["sha256_16"] = metadata["sha256"][:16] + "…" if metadata["sha256"] else None
            row["type_ok"] = True if not kinds or ext_ok(p, kinds) else False
            if row["type_ok"] and row["hash_ok"] is not False:
                present_roles.add(role)
            if do_deep and row["type_ok"] and row["hash_ok"] is not False:
                row["deep"] = deep_check(p, role)
        file_rows.append(row)

    # 模块级判定（P1 按总线过滤：LIN 项目不要求 dbc，CAN 项目不要求 ldf/lin_matrix）
    bus = str((manifest.get("project") or {}).get("bus", "") or "").lower()
    modules = {}
    for role, impacts in MISSING_IMPACT.items():
        if role in present_roles:
            continue
        if role in ("ldf", "lin_matrix") and bus == "can":
            continue
        if role == "dbc" and bus == "lin":
            continue
        if role == "lin_matrix" and "ldf" in present_roles:
            continue  # LDF 已随包，LIN Matrix 缺失有兜底，不降级
        for name, state, reason in impacts:
            prev = modules.get(name)
            if prev is None or (prev[0] == "DEGRADED" and state == "BLOCKED"):
                modules[name] = (state, reason)
    module_rows = [{"module": k, "state": v[0], "reason": v[1]}
                   for k, v in sorted(modules.items())]
    # 内容级降级：密钥文档存在但无实际密钥值 → 存在性检查的盲区，0x27 仍 BLOCKED
    keydoc_no_values = False
    for r in file_rows:
        if (r["role"] == "security_key_doc" and r["exists"]
                and isinstance(r["deep"], dict) and r["deep"].get("keycheck") is False):
            keydoc_no_values = True
            modules["0x27 正例与受保护服务执行"] = (
                "BLOCKED", "密钥文档存在但未发现实际密钥值（仅算法流程/密钥名）→ 0x27 全部 BLOCKED，不伪造 PASS")
    if keydoc_no_values:
        module_rows.append({"module": "0x27 正例与受保护服务执行", "state": "BLOCKED",
                            "reason": modules["0x27 正例与受保护服务执行"][1]})
    # 已齐备模块
    if {"diag_survey", "did_checklist"} <= present_roles and "UDS 用例参数化设计" not in modules:
        module_rows.append({"module": "UDS 用例设计", "state": "READY",
                            "reason": "P0 输入齐备（调查表 + DID 检查表）"})

    invalid_p0 = [r["role"] for r in file_rows
                  if r["priority"] == "P0" and r["exists"]
                  and (r["type_ok"] is False or r["hash_ok"] is False)
                  and r["role"] not in present_roles]
    invalid_p1 = [r["role"] for r in file_rows
                  if r["priority"] == "P1" and r["exists"]
                  and (r["type_ok"] is False or r["hash_ok"] is False)
                  and r["role"] not in present_roles]
    p0_missing = sorted(set(
        [r["role"] for r in file_rows if r["priority"] == "P0" and not r["exists"]]
        + invalid_p0))
    p1_missing = sorted(set(
        [r["role"] for r in file_rows if r["priority"] == "P1" and not r["exists"]]
        + invalid_p1))
    declared = {r["role"] for r in file_rows}
    p0_roles = ("diag_survey", "did_checklist") if _is_portable_manifest(manifest) else (
        "diag_survey", "did_checklist", "project_config")
    p0_undeclared = [k for k in p0_roles if k not in declared]
    # P1 相关角色未随包（按总线过滤后）→ PARTIAL
    p1_relevant = (["swrs"] + (["ldf"] if bus != "can" else []) + (["dbc"] if bus != "lin" else []))
    p1_undeclared = [k for k in p1_relevant if k not in declared]
    if manifest_errors:
        verdict = "NOT_READY"
        verdict_reason = "manifest/context 无效：%s" % "; ".join(manifest_errors)
    elif p0_missing or p0_undeclared:
        verdict = "NOT_READY"
        verdict_reason = "P0 缺失/未声明：%s" % ", ".join(p0_missing + p0_undeclared)
    elif p1_missing or p1_undeclared:
        miss = sorted(set(p1_missing + p1_undeclared))
        verdict = "PARTIAL"
        verdict_reason = "P1 缺失/未随包：%s（可继续，缺口已记录）" % ", ".join(miss)
    else:
        verdict = "READY"
        verdict_reason = "P0/P1 齐备，可进入用例设计"

    blocked = [m["module"] for m in module_rows if m["state"] == "BLOCKED"]
    next_actions = []
    if "diag_survey" in p0_missing + p0_undeclared:
        next_actions.append("提供诊断调查表（SDDB/ODX *_diagnostic.xlsx）——P0，缺失不得硬生成")
    if "did_checklist" in p0_missing + p0_undeclared:
        next_actions.append("提供 DID 检查表（真实抓帧 + 分层矩阵）——条件受限判定证据，常被低估")
    if "project_config" in p0_missing + p0_undeclared:
        next_actions.append("复制 skills/project_config.example.json 为 project_config.json 并按本项目填写")
    if _is_portable_manifest(manifest) and not context_result["present"]:
        next_actions.append("补充 project_context.json：只写规范化事实、证据定位和 pending/blocked 缺口")
    if "security_key_doc" not in present_roles:
        next_actions.append("0x27 密钥/算法资料未随包 → 安全用例将标 BLOCKED；能拿到真实密钥值再补")
    if keydoc_no_values:
        next_actions.append("0x27 密钥文档有算法流程但无实际密钥值（内容级检查命中）→ 向客户/软件组索要密钥字节（如 AES_ctr/AES_cmac key），拿到前安全用例标 BLOCKED")
    if "flash_flowchart" not in declared:
        next_actions.append("刷写流程图未随包 → SWDL 模块将标 BLOCKED")
    if not next_actions:
        next_actions.append("包齐备：直接进入 srs-uds-testcase-designer Step 0 体检 → 精读 → 用例设计")

    result = {
        "schema": "input-pack-readiness/v1",
        "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "manifest": os.path.abspath(manifest_path),
        "project": manifest.get("project", {}),
        "manifest_errors": manifest_errors,
        "context": context_result,
        "verdict": {"state": verdict, "reason": verdict_reason},
        "blocked_modules": blocked,
        "files": file_rows,
        "modules": module_rows,
        "next_actions": next_actions,
    }
    return result


def ext_ok(path, kinds):
    return os.path.splitext(path)[1].lower() in kinds


def render_md(res):
    L = []
    L.append("# 输入文件包就绪报告（input_pack_validator）\n")
    proj = res.get("project", {})
    L.append("- 项目：%s ｜ 被测：%s %s ｜ 总线：%s" % (
        proj.get("name", "?"), proj.get("target_ecu", "?"),
        proj.get("sw_version", ""), proj.get("bus", "?")))
    v = res["verdict"]
    L.append("- **结论：%s**（%s）" % (v["state"], v["reason"]))
    if res["blocked_modules"]:
        L.append("- 阻塞模块：%s" % ", ".join(res["blocked_modules"]))
    if res.get("manifest_errors"):
        L.append("- manifest/context 错误：%s" % "；".join(res["manifest_errors"]))
    L.append("")
    L.append("## 文件清单校验")
    L.append("| 角色 | 分区 | 优先级 | 路径 | 存在 | 哈希 | 大小KB | 类型 | 深度校验 |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for r in res["files"]:
        deep = r["deep"]
        deep_str = "-" if deep is None else ("✅ %s" % deep["msg"] if deep.get("ok") else
                                             ("⚠️ %s" % deep["msg"] if deep.get("ok") is False else deep["msg"]))
        hash_str = "-" if r["hash_ok"] is None else ("✅" if r["hash_ok"] else "❌")
        L.append("| %s（%s） | %s | %s | `%s` | %s | %s | %s | %s | %s |" % (
            r["label"], r["role"], r["partition"], r["priority"], r["path"],
            "✅" if r["exists"] else "❌",
            hash_str,
            r["size_kb"] if r["size_kb"] is not None else "-",
            ("✅" if r["type_ok"] else "❌ 扩展名不符") if r["exists"] else "-",
            deep_str))
    L.append("")
    L.append("## 模块级判定")
    L.append("| 模块 | 状态 | 原因 |")
    L.append("|---|---|---|")
    for m in res["modules"]:
        L.append("| %s | **%s** | %s |" % (m["module"], m["state"], m["reason"]))
    L.append("")
    L.append("## 下一步动作")
    for i, a in enumerate(res["next_actions"], 1):
        L.append("%d. %s" % (i, a))
    L.append("")
    L.append("> 可移植性说明：本包（manifest + 文件 + project_config.json）拷贝到其他机器/专家后，")
    L.append("> 重跑本校验器即可恢复全部输入上下文；哈希列可用于核对搬运前后文件一致。")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="UDS 测试输入文件包一键校验（manifest → 就绪报告）")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--pack", help="包目录（读取其中 input_manifest.json）")
    g.add_argument("--manifest", help="manifest JSON 路径")
    ap.add_argument("--out-prefix", default="pack_readiness", help="输出文件前缀（默认 pack_readiness）")
    ap.add_argument("--no-deep", action="store_true", help="跳过深度校验（只做存在性/类型/哈希）")
    args = ap.parse_args()

    manifest_path = args.manifest or os.path.join(args.pack, "input_manifest.json")
    if not os.path.isfile(manifest_path):
        print("[ERROR] 未找到 manifest: %s（模板见 skills/input_manifest.example.json）" % manifest_path)
        sys.exit(4)
    try:
        res = validate_pack(manifest_path, do_deep=not args.no_deep)
    except (ValueError, json.JSONDecodeError) as e:
        print("[ERROR] manifest 无效：%r" % e)
        sys.exit(4)

    pack_dir = os.path.dirname(os.path.abspath(manifest_path))
    jpath = os.path.join(pack_dir, args.out_prefix + ".json")
    mpath = os.path.join(pack_dir, args.out_prefix + ".md")
    with open(jpath, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    with open(mpath, "w", encoding="utf-8", newline="\n") as f:
        f.write(render_md(res) + "\n")

    print(render_md(res))
    print("\nRESULT verdict=%s files=%d blocked=%d out=%s" % (
        res["verdict"]["state"], len(res["files"]), len(res["blocked_modules"]), mpath))
    sys.exit({"READY": 0, "PARTIAL": 1, "NOT_READY": 2}[res["verdict"]["state"]])


if __name__ == "__main__":
    main()
