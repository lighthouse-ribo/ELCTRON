# -*- coding: utf-8 -*-
"""Tests for the portable project parser adapter."""

from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from project_parser_adapter import adapt_manifest  # noqa: E402


def write_file(path: Path, data: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding="utf-8")
    return hashlib.sha256(path.read_bytes()).hexdigest()


class TestProjectParserAdapter(unittest.TestCase):
    def test_diag_survey_emits_bounded_partition_facts(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            survey = '{"dids":[{"did_number":"F190"}],"io_controls":[],"routines":[{"rid":"0201"}],"dtcs":[{"dtc":"123456"}],"can_config":{},"defaults_used":[],"missing_attributes":[]}'
            rel = "diagnostic/APP/survey.json"
            digest = write_file(root / rel, survey)
            manifest = {"project": {"id": "test"}, "files": [{
                "id": "survey-app", "role": "diag_survey", "path": rel,
                "partition": "APP", "sha256": digest, "sensitivity": "internal",
            }]}

            (root / "input_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            result = adapt_manifest(root / "input_manifest.json")

            self.assertEqual(result["errors"], [])
            facts = {item["id"]: item for item in result["facts"]}
            self.assertEqual(facts["diagnostic.APP.survey-app.did_count"]["value"], 1)
            self.assertEqual(facts["diagnostic.APP.survey-app.routine_count"]["partition"], "APP")
            self.assertEqual(facts["parser.APP.survey-app.status"]["value"], "parsed")
            self.assertNotIn('"dids":', json.dumps(result, ensure_ascii=False))

    def test_ldf_emits_transport_summary_without_raw_frames(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ldf = """LIN_protocol_version = '2.2';
LIN_language_version = '2.2';
LIN_speed = 19.2 kbps;
Nodes {
Master: M, 5 ms, 0.1 ms;
Slaves: S1, S2;
}
Signals { Sig: 8, 0, S1; }
Frames {
Frame: 0x10, S1, 8 {
Sig, 0;
}
}
Diagnostic_frames {
DiagReq: 60 {
}
DiagResp: 61 {
}
}
Schedule_tables {
Main {
Frame delay 5 ms;
}
}
"""
            rel = "shared/communication/test.ldf"
            digest = write_file(root / rel, ldf)
            manifest = {"project": {"id": "test"}, "files": [{
                "id": "ldf-shared", "role": "ldf", "path": rel,
                "partition": "shared", "sha256": digest, "sensitivity": "internal",
            }]}
            manifest_path = root / "input_manifest.json"
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

            result = adapt_manifest(manifest_path)
            facts = {item["id"]: item for item in result["facts"]}
            self.assertEqual(result["errors"], [])
            self.assertEqual(facts["transport.shared.ldf-shared.lin_speed_bps"]["value"], 19200)
            self.assertEqual(facts["transport.shared.ldf-shared.frame_count"]["value"], 3)
            self.assertNotIn('"frames"', json.dumps(result, ensure_ascii=False))

    def test_unsupported_role_is_pending_and_not_promoted(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            rel = "shared/communication/matrix.xlsx"
            digest = write_file(root / rel, "placeholder")
            manifest = {"project": {"id": "test"}, "files": [{
                "id": "lin-matrix", "role": "lin_matrix", "path": rel,
                "partition": "shared", "sha256": digest, "sensitivity": "internal",
            }]}
            manifest_path = root / "input_manifest.json"
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

            result = adapt_manifest(manifest_path)
            self.assertEqual(result["pending_roles"], ["lin_matrix"])
            self.assertEqual(result["files"][0]["status"], "pending")
            self.assertEqual(result["files"][0]["fact_ids"], ["parser.shared.lin-matrix.status"])
            self.assertEqual(result["facts"][0]["status"], "pending")
            self.assertIsNone(result["facts"][0]["value"])

    def test_hash_mismatch_blocks_parser(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            rel = "diagnostic/APP/survey.json"
            write_file(root / rel, '{"dids": []}')
            manifest = {"project": {"id": "test"}, "files": [{
                "id": "survey-app", "role": "diag_survey", "path": rel,
                "partition": "APP", "sha256": "0" * 64, "sensitivity": "internal",
            }]}
            manifest_path = root / "input_manifest.json"
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

            result = adapt_manifest(manifest_path)
            self.assertEqual(result["files"][0]["status"], "blocked")
            self.assertEqual(result["files"][0]["fact_ids"], ["parser.APP.survey-app.status"])
            self.assertEqual(result["facts"][0]["status"], "blocked")
            self.assertIsNone(result["facts"][0]["value"])
            self.assertTrue(any("sha256 mismatch" in error for error in result["errors"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
