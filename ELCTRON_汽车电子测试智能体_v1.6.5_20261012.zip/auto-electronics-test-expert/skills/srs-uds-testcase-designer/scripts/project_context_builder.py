# -*- coding: utf-8 -*-
"""Build the single portable project context from manifest-backed facts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping

from portable_pack_reader import load_json, sha256_file
from project_fact_mapper import ROLE_FACT_DOMAINS
from project_parser_adapter import adapt_project_files


SCHEMA = "portable-contract/v0.1"
VALID_STATUSES = {"confirmed", "derived", "pending", "conflict", "blocked"}
GAP_STATUSES = {"pending", "conflict", "blocked"}
DEFAULT_POLICY = {
    "raw_documents": "file_backed",
    "include": ["facts", "source", "hashes", "selected_snippets"],
    "exclude": ["raw_text", "secret_values", "machine_paths"],
}


def _partition_ids(manifest: Mapping[str, Any]) -> list[str]:
    ids = []
    for item in manifest.get("partitions") or []:
        value = item if isinstance(item, str) else item.get("id")
        if value and value not in ids:
            ids.append(str(value))
    for entry in manifest.get("files") or []:
        if isinstance(entry, Mapping) and entry.get("partition") and entry["partition"] not in ids:
            ids.append(str(entry["partition"]))
    return ids or ["APP", "PBL", "SBL", "shared"]


def _copy_fact(fact: Mapping[str, Any], manifest_ids: set[str], partition_ids: set[str]) -> dict[str, Any]:
    required = ("id", "partition", "value", "status", "source")
    missing = [key for key in required if key not in fact]
    if missing:
        raise ValueError(f"fact 缺少字段: {', '.join(missing)}")
    fact_id = str(fact["id"])
    partition = str(fact["partition"])
    status = str(fact["status"])
    if not fact_id or partition not in partition_ids or status not in VALID_STATUSES:
        raise ValueError(f"fact 字段无效: {fact_id}")
    source = fact.get("source")
    if status in {"confirmed", "derived"}:
        if not isinstance(source, Mapping) or source.get("file_id") not in manifest_ids:
            raise ValueError(f"fact {fact_id} 的 source.file_id 未在 manifest 中声明")
        if not source.get("locator"):
            raise ValueError(f"fact {fact_id} 缺少 source.locator")
    if status in GAP_STATUSES and fact.get("value") is not None:
        raise ValueError(f"fact {fact_id} 的缺口状态必须使用 null value")
    result = dict(fact)
    result["id"] = fact_id
    result["partition"] = partition
    result["status"] = status
    result["source"] = dict(source) if isinstance(source, Mapping) else source
    if status in GAP_STATUSES:
        result["value"] = None
    return result


def _merge_facts(base_facts: list[Any], incoming_facts: list[Any],
                 manifest: Mapping[str, Any], partition_ids: set[str]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    manifest_ids = {str(item.get("id")) for item in manifest.get("files") or [] if isinstance(item, Mapping)}
    merged: dict[str, dict[str, Any]] = {}
    conflicts: list[dict[str, Any]] = []

    for raw in base_facts:
        if not isinstance(raw, Mapping):
            raise ValueError("base context facts 必须是对象")
        fact = _copy_fact(raw, manifest_ids, partition_ids)
        if fact["id"] in merged:
            raise ValueError(f"base context 存在重复 fact id: {fact['id']}")
        merged[fact["id"]] = fact

    for raw in incoming_facts:
        if not isinstance(raw, Mapping):
            raise ValueError("adapter facts 必须是对象")
        fact = _copy_fact(raw, manifest_ids, partition_ids)
        old = merged.get(fact["id"])
        if old is None:
            merged[fact["id"]] = fact
        elif old["status"] == "confirmed" and old.get("value") != fact.get("value"):
            conflicts.append({
                "fact_id": fact["id"],
                "existing_source": old.get("source"),
                "incoming_source": fact.get("source"),
                "reason": "confirmed fact differs from parser result",
            })
        elif old["status"] == "confirmed":
            continue
        else:
            merged[fact["id"]] = fact
    return list(merged.values()), conflicts


def _partition_rows(manifest: Mapping[str, Any], base: Mapping[str, Any], partition_ids: list[str]) -> list[dict[str, Any]]:
    old_rows = {
        str(item.get("id")): dict(item)
        for item in base.get("partitions") or []
        if isinstance(item, Mapping) and item.get("id")
    }
    source_files: dict[str, list[str]] = {partition: [] for partition in partition_ids}
    for entry in manifest.get("files") or []:
        if not isinstance(entry, Mapping) or not entry.get("id"):
            continue
        partition = str(entry.get("partition", "shared"))
        source_files.setdefault(partition, []).append(str(entry["id"]))

    rows = []
    for partition in partition_ids:
        row = old_rows.get(partition, {"id": partition})
        row["id"] = partition
        row["source_files"] = sorted(set(source_files.get(partition, [])))
        row.setdefault("state", "available" if row["source_files"] else "pending")
        rows.append(row)
    return rows


def _gap_for_fact(fact: Mapping[str, Any], role_by_file: Mapping[str, str]) -> dict[str, Any]:
    source = fact.get("source") or {}
    file_id = source.get("file_id") if isinstance(source, Mapping) else None
    role = role_by_file.get(file_id, "")
    required_for = list(ROLE_FACT_DOMAINS.get(role, [])) or [str(fact["id"])]
    return {
        "id": fact["id"],
        "status": fact["status"],
        "required_for": required_for,
        "source": source if source else None,
    }


def _merge_gaps(base_gaps: list[Any], facts: list[Mapping[str, Any]],
                adapter_result: Mapping[str, Any], manifest: Mapping[str, Any]) -> list[dict[str, Any]]:
    gaps: dict[str, dict[str, Any]] = {}
    for raw in base_gaps:
        if isinstance(raw, Mapping) and raw.get("id"):
            gaps[str(raw["id"])] = dict(raw)

    role_by_file = {
        str(entry["id"]): str(entry.get("role", "other"))
        for entry in manifest.get("files") or []
        if isinstance(entry, Mapping) and entry.get("id")
    }
    for fact in facts:
        fact_id = str(fact["id"])
        if fact.get("status") in GAP_STATUSES:
            gaps[fact_id] = _gap_for_fact(fact, role_by_file)
        else:
            gaps.pop(fact_id, None)

    for row in adapter_result.get("files") or []:
        if not isinstance(row, Mapping) or row.get("status") not in GAP_STATUSES:
            continue
        file_id = str(row.get("file_id"))
        gap_id = (row.get("fact_ids") or [f"parser.{row.get('partition', 'shared')}.{file_id}.status"])[0]
        gaps[gap_id] = {
            "id": gap_id,
            "status": row["status"],
            "required_for": list(ROLE_FACT_DOMAINS.get(str(row.get("role")), [])) or [str(row.get("role", "other"))],
            "source": {"file_id": file_id, "locator": "adapter"},
        }
    return list(gaps.values())


def build_project_context(pack_dir: str | Path, manifest: Mapping[str, Any],
                          adapter_result: Mapping[str, Any] | None = None,
                          base_context: Mapping[str, Any] | None = None,
                          manifest_path: str | Path | None = None) -> dict[str, Any]:
    """Merge portable inputs into the only context object consumed downstream."""

    root = Path(pack_dir).resolve()
    base = dict(base_context or {})
    adapter = adapter_result if adapter_result is not None else adapt_project_files(root, manifest)
    partition_list = _partition_ids(manifest)
    partition_set = set(partition_list)
    facts, conflicts = _merge_facts(base.get("facts") or [], adapter.get("facts") or [], manifest, partition_set)
    manifest_file = Path(manifest_path or root / "input_manifest.json").resolve()
    try:
        manifest_rel = manifest_file.relative_to(root).as_posix()
    except ValueError as exc:
        raise ValueError("manifest_path 必须位于 project-pack 内") from exc

    project = dict(base.get("project") or {})
    project.update(dict(manifest.get("project") or {}))
    policy = dict(DEFAULT_POLICY)
    policy.update(dict(base.get("policy") or {}))
    context = {
        "$schema": SCHEMA,
        "schema_version": SCHEMA,
        "project": project,
        "manifest": {"path": manifest_rel, "sha256": sha256_file(manifest_file)},
        "partitions": _partition_rows(manifest, base, partition_list),
        "facts": facts,
        "gaps": _merge_gaps(base.get("gaps") or [], facts, adapter, manifest),
        "policy": policy,
    }
    if conflicts:
        context["conflicts"] = conflicts
    return context


def build_context_from_manifest(manifest_path: str | Path,
                                adapter_result: Mapping[str, Any] | None = None,
                                base_context_path: str | Path | None = None) -> dict[str, Any]:
    manifest_file = Path(manifest_path).resolve()
    manifest = load_json(manifest_file)
    if not isinstance(manifest, Mapping):
        raise ValueError("manifest 根节点必须是对象")
    base_file = Path(base_context_path).resolve() if base_context_path else manifest_file.parent / "project_context.json"
    base = load_json(base_file) if base_file.is_file() else {}
    return build_project_context(manifest_file.parent, manifest, adapter_result, base, manifest_file)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="生成统一可移植 project_context.json")
    parser.add_argument("--manifest", required=True, help="project-pack/input_manifest.json")
    parser.add_argument("--output", required=True, help="project_context.json 输出路径")
    parser.add_argument("--adapter-result", help="已生成的 project-fact-adapter JSON（可选）")
    parser.add_argument("--base-context", help="已有 project_context.json（可选）")
    args = parser.parse_args(argv)
    adapter = load_json(args.adapter_result) if args.adapter_result else None
    context = build_context_from_manifest(args.manifest, adapter, args.base_context)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(context, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[OK] project context: facts={len(context['facts'])} gaps={len(context['gaps'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["SCHEMA", "build_context_from_manifest", "build_project_context"]
