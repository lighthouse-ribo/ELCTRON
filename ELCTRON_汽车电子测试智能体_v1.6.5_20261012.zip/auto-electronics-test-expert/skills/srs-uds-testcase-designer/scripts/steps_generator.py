#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UDS / CAN 报文级步骤自动生成器 v2.0 —— 消灭手抄 hex + 审计审查
=============================================================
输入用例 JSON（case-schema 格式），识别 procedure/expected 中的占位符
（如 {{READ_DID:F12E}} / {{WRITE_DID:F12E:0102}} / {{MSG:0x1F0:Enable=1}}），
用 cantools（CDD/DBC）自动计算并填充真实的报文字节流。

v2.0 新增「审计审查」：每条填充都记录
  - source：数据来源（CDD / DBC / ISO 14229 标准 / 用户输入 / 推断）
  - checks：协议校验结果（帧长度一致性 / 正响应SID / 子功能合法性 / DID存在性 / 长度匹配 / DBC信号与范围）
  - status：PASS（全部通过）/ WARN（有推断或数据源缺失，需人工确认）/ FAIL（校验失败，禁止静默使用）
FAIL 的填充会在文本中标注「⚠️审查失败」，并输出 audit.json 供人工复核，杜绝虚假报文。

对齐用户模板报文格式：`51 <len> <SID> <参数> FF FF FF FF`
  - 字节0 = 51（固定帧标记，对齐用户模板/LIN 诊断 NAD 物理寻址）
  - 字节1 = 后续字节数
  - 后续 = SID + 子功能/参数，FF 填充到 8 字节
  - ⚠️ 仅 LIN/模板样式适用；CAN 诊断帧无 0x51 字节（CAN ID + ISO-TP PCI），CAN 项目请按 CAN 帧格式改写

用法：
  python steps_generator.py --cases cases.json --out cases_filled.json \
      --cdd diag.cdd --dbc can.dbc --audit audit.json
  # 填充后走原有 xlsx 流程
  python build_testcase_xlsx.py cases_filled.json --out cases.xlsx

支持的占位符（在 procedure / expected 字段中写）：
  {{READ_DID:<DID>}}           → 0x22 读 DID（DID 长度取 CDD，缺失标 WARN）
  {{WRITE_DID:<DID>:<hex>}}    → 0x2E 写 DID（数据长度超 DID 长度标 FAIL）
  {{SESSION:<sub>}}            → 0x10 会话切换（非法子功能标 FAIL）
  {{RESET:<sub>}}              → 0x11 ECU 复位（非法子功能标 FAIL）
  {{TP}} / {{TP:80}}           → 0x3E 测试仪保持（可带抑制位 0x80）
  {{MSG:<帧名或ID>:<sig=值,...>}} → DBC 信号编码（信号不存在/超范围标 FAIL）
  {{DECODE:<帧名或ID>:<hex>}}     → DBC 解码报文 hex 为信号断言
  {{LIN_MSG:<帧名或ID>:<sig=值,...>}} → LDF 信号编码（LSB0 打包 + 校验和自动计算；诊断帧经典、其余增强）
  {{LIN_DECODE:<帧名或ID>:<hex>}}     → LDF 解码 LIN 帧 hex（可带末尾校验和）为信号断言

边界：
  - LIN 占位符需 --ldf（ldf_parser.py 产物 lin_db.json）；未提供时标待补（WARN），不编造
  - CDD/DBC 缺失或参数非法 → 输出「待补」标注并计入 WARN，不硬造
"""

__version__ = "2.1.0"

import argparse
import json
import os
import re
import sys

# 报文数据域长度（CAN classic 单帧 8 字节）
DATA_LEN = 8
FILL = 0xFF

# ISO 14229-1 已知服务（用于 SID 合法性校验）
KNOWN_SIDS = {
    0x10: "DiagnosticSessionControl",
    0x11: "ECUReset",
    0x14: "ClearDiagnosticInformation",
    0x19: "ReadDTCInformation",
    0x22: "ReadDataByIdentifier",
    0x23: "ReadMemoryByAddress",
    0x27: "SecurityAccess",
    0x28: "CommunicationControl",
    0x2E: "WriteDataByIdentifier",
    0x31: "RoutineControl",
    0x34: "RequestDownload",
    0x36: "TransferData",
    0x37: "RequestTransferExit",
    0x3E: "TesterPresent",
    0x85: "ControlDTCSetting",
}

# 各服务合法子功能（用于子功能校验）
# ============================================================================
# 子功能合法性（ISO 14229-1；0x80 = suppressPosRspMsgIndicationBit，先掩掉再判）
# ============================================================================
def is_valid_subfunction(service, sub):
    """0x10: 01-04 标准会话 + 0x40-0x5F 厂商 + 0x60-0x7E 供应商（含抑制位变体）
    0x11: 01-05 复位类型（04/05 为 2020 新增，含抑制位变体）
    0x3E: 00 保活 / 80 抑制正响应保活"""
    base = sub & 0x7F
    if service == 0x10:
        return base in (0x01, 0x02, 0x03, 0x04) or 0x40 <= base <= 0x5F or 0x60 <= base <= 0x7E
    if service == 0x11:
        return base in (0x01, 0x02, 0x03, 0x04, 0x05)
    if service == 0x3E:
        return sub in (0x00, 0x80)
    return False


# ============================================================================
# 报文构造（对齐用户模板/LIN 诊断：51 <len> <SID> <参数...> FF FF FF FF；CAN 无 0x51 字节）
# ============================================================================
def uds_frame(sid, params=None):
    """构造 UDS 帧文本，返回 '51 03 22 00 90 FF FF FF' 格式。

    Args:
        sid: 服务 ID（int），响应时传 SID+0x40
        params: 参数列表（list[int]）
    Returns:
        str: 帧文本；body 超长时返回 None（调用方按多帧处理）
    """
    params = params or []
    body = [sid] + list(params)
    if len(body) > DATA_LEN - 2:
        return None
    length = len(body)
    frame = [0x51, length] + body
    frame += [FILL] * (DATA_LEN - len(frame))
    return " ".join("%02X" % b for b in frame)


def req_text(sid, params=None, label="1.测试仪请求："):
    text = uds_frame(sid, params)
    if text is None:
        return None
    return "%s%s；" % (label, text)


def rsp_text(sid, params=None, label="1. DUT正响应："):
    text = uds_frame(sid, params)
    if text is None:
        return None
    return "%s%s；" % (label, text)


# ============================================================================
# 审计审查（v2.0 核心）
# ============================================================================
class AuditEntry:
    """单条填充的审计记录"""

    def __init__(self, case_id, field, placeholder):
        self.case_id = case_id
        self.field = field
        self.placeholder = placeholder
        self.source = ""          # CDD / DBC / ISO14229 / 用户输入 / 推断
        self.generated = ""       # 生成的文本
        self.checks = []          # [(rule, status, detail)]
        self.status = "PASS"      # PASS / WARN / FAIL

    def add_check(self, rule, ok, detail):
        status = "PASS" if ok else "FAIL"
        self.checks.append((rule, status, detail))
        if not ok:
            self.status = "FAIL"

    def add_warn(self, rule, detail):
        self.checks.append((rule, "WARN", detail))
        if self.status == "PASS":
            self.status = "WARN"

    def to_dict(self):
        return {
            "case_id": self.case_id,
            "field": self.field,
            "placeholder": self.placeholder,
            "source": self.source,
            "generated": self.generated,
            "status": self.status,
            "checks": [{"rule": r, "status": s, "detail": d} for r, s, d in self.checks],
        }


# ============================================================================
# 占位符处理
# ============================================================================
PLACEHOLDER_RE = re.compile(r"\{\{([A-Z_]+)(?::([^}]*))?\}\}")


class StepGenerator:
    """占位符 → 真实报文 的替换引擎（按字段语义输出 + 审计审查）"""

    def __init__(self, cdd_path=None, dbc_path=None, ldf_path=None):
        self.cdd = None          # cantools diagnostics.Database
        self.dbc = None          # cantools can.Database
        self.lin_db = None       # ldf_parser.py 输出的 lin_db.json
        self.lin_frames = {}     # 帧名 / "0xID" / "ID" -> 帧
        self.lin_signals = {}    # 信号名 -> 信号（含诊断信号）
        self.did_lengths = {}    # "0xF12E" -> int（来自 CDD）
        self.stats = {"filled": 0, "missing": 0, "lin_skip": 0,
                      "pass": 0, "warn": 0, "fail": 0}
        self.audit = []          # list[AuditEntry]
        self._load_cdd(cdd_path)
        self._load_dbc(dbc_path)
        self._load_ldf(ldf_path)

    # ---- 数据源加载 ----
    def _load_cdd(self, path):
        if not path:
            return
        try:
            import cantools
            self.cdd = cantools.database.load_file(path)
            for did in self.cdd.dids:
                self.did_lengths["0x%04X" % did.identifier] = did.length
            print("[INFO] CDD 加载成功: %d 个 DID（含长度定义）" % len(self.cdd.dids))
        except Exception as e:
            print("[WARN] CDD 加载失败（相关 DID 长度标注待补）: %s" % e)

    def _load_dbc(self, path):
        if not path:
            return
        try:
            import cantools
            self.dbc = cantools.database.load_file(path)
            print("[INFO] DBC 加载成功: %d 个报文" % len(self.dbc.messages))
        except Exception as e:
            print("[WARN] DBC 加载失败（MSG 占位符无法填充）: %s" % e)

    def _load_ldf(self, path):
        if not path:
            return
        try:
            with open(path, encoding="utf-8") as f:
                self.lin_db = json.load(f)
            self.lin_signals = {s["name"]: s for s in self.lin_db.get("signals", [])}
            self.lin_signals.update({s["name"]: s for s in self.lin_db.get("diagnostic_signals", [])})
            for fr in self.lin_db.get("frames", []):
                self.lin_frames[fr["name"]] = fr
                self.lin_frames["0x%02X" % fr["frame_id"]] = fr
                self.lin_frames["%d" % fr["frame_id"]] = fr
                self.lin_frames[fr["pid_hex"]] = fr
            print("[INFO] LDF 加载成功: %d 个 LIN 帧（含 PID/信号偏移）" % len(self.lin_db.get("frames", [])))
        except Exception as e:
            print("[WARN] LDF 加载失败（LIN_MSG/LIN_DECODE 占位符无法填充）: %s" % e)

    def _get_lin_frame(self, key):
        """按帧名 / ID(0x28 或 40) / PID(0xA8) 查找 LIN 帧"""
        if self.lin_frames:
            return self.lin_frames.get(key)
        return None

    def _lin_checksum(self, frame_id, data_bytes, enhanced=True):
        """LIN 校验和：带进位加法（≥256 减 255）逐位取反。
        经典=仅数据；增强=受保护ID+数据（LIN2.x 非诊断帧默认增强，诊断帧经典）"""
        pid = 0
        if enhanced:
            fid = frame_id & 0x3F
            p0 = ((fid >> 0) ^ (fid >> 1) ^ (fid >> 2) ^ (fid >> 4)) & 1
            xor1 = ((fid >> 1) ^ (fid >> 3) ^ (fid >> 4) ^ (fid >> 5)) & 1
            pid = (((1 - xor1) & 1) << 7) | (p0 << 6) | fid
        total = pid
        for b in data_bytes:
            total += b
            if total >= 256:
                total -= 255
        return (~total) & 0xFF

    def _lin_encode(self, key, sig_str, case_id, field):
        """LDF 信号编码 → LIN 帧数据字节（LSB0 打包 + 校验和），仅 procedure"""
        entry = self._new_entry(case_id, field, "{{LIN_MSG:%s:%s}}" % (key, sig_str))
        entry.source = "LDF"
        frame = self._get_lin_frame(key)
        if frame is None:
            entry.add_check("帧存在性", False, "LDF 中找不到帧 %s（或未提供 --ldf）" % key)
            return self._finish_entry(entry, "待补：LDF 中找不到帧 %s（或未提供 --ldf）" % key, filled=False)
        entry.add_check("帧存在性", True, "帧 %s (ID %s / PID %s, %d 字节)" % (
            frame["name"], frame["frame_id_hex"], frame["pid_hex"], frame["length"]))
        try:
            raw = bytearray(frame["length"])
            signals = {}
            for pair in sig_str.split(","):
                if "=" not in pair:
                    continue
                name, _, val = pair.strip().partition("=")
                try:
                    signals[name] = int(val, 0)
                except ValueError:
                    entry.add_check("信号值格式", False, "信号 %s 值 %s 非整数（LIN 信号按整数打包）" % (name, val))
                    continue
            for name, val in signals.items():
                sig = next((s for s in frame["signals"] if s["name"] == name), None)
                if sig is None:
                    entry.add_check("信号存在性", False, "帧 %s 无信号 %s" % (frame["name"], name))
                    continue
                size = self.lin_signals.get(name, {}).get("size")
                if size is None:
                    entry.add_check("信号尺寸", False, "LDF 信号 %s 无尺寸定义" % name)
                    continue
                if val < 0 or val >= (1 << size):
                    entry.add_check("信号范围", False, "%s=%s 超出 %d bit 范围" % (name, val, size))
                    continue
                offset = sig["offset"]
                for i in range(size):
                    bit = (val >> i) & 1
                    pos = offset + i
                    if bit:
                        raw[pos // 8] |= (1 << (pos % 8))
            # 校验和：诊断帧经典、其余增强（LIN2.x）
            enhanced = frame["frame_type"] != "diagnostic"
            cs = self._lin_checksum(frame["frame_id"], bytes(raw), enhanced=enhanced)
            entry.add_check("校验和", True, "%s校验和 = 0x%02X" % ("增强" if enhanced else "经典", cs))
            hex_str = " ".join("%02X" % b for b in raw)
            return self._finish_entry(entry,
                "1.发送LIN帧：%s (ID %s / PID %s)：%s + 校验和 %02X；" % (
                    frame["name"], frame["frame_id_hex"], frame["pid_hex"], hex_str, cs))
        except Exception as e:
            entry.add_check("编码执行", False, "LIN 编码失败: %s" % e)
            return self._finish_entry(entry, "待补：帧 %s 编码失败（%s），信号名/值以 LDF 为准" % (key, e), filled=False)

    def _lin_decode(self, key, data_hex, case_id, field):
        """LDF 解码 LIN 帧数据字节 → 信号断言（可带末尾校验和），仅 expected"""
        entry = self._new_entry(case_id, field, "{{LIN_DECODE:%s:%s}}" % (key, data_hex))
        entry.source = "LDF"
        frame = self._get_lin_frame(key)
        if frame is None:
            entry.add_check("帧存在性", False, "LDF 中找不到帧 %s（或未提供 --ldf）" % key)
            return self._finish_entry(entry, "待补：LDF 中找不到帧 %s（或未提供 --ldf）" % key, filled=False)
        entry.add_check("帧存在性", True, "帧 %s (ID %s / PID %s)" % (frame["name"], frame["frame_id_hex"], frame["pid_hex"]))
        try:
            raw = bytes.fromhex(data_hex.replace(" ", ""))
            if len(raw) == frame["length"] + 1:
                enhanced = frame["frame_type"] != "diagnostic"
                expect_cs = self._lin_checksum(frame["frame_id"], raw[:-1], enhanced=enhanced)
                entry.add_check("校验和", expect_cs == raw[-1],
                                "期望%s校验和 0x%02X == 实际 0x%02X" % ("增强" if enhanced else "经典", expect_cs, raw[-1]))
                raw = raw[:-1]
            elif len(raw) != frame["length"]:
                entry.add_check("数据长度", False, "hex %d 字节 != LDF 帧长 %d" % (len(raw), frame["length"]))
            decoded = {}
            for sig in frame["signals"]:
                size = self.lin_signals.get(sig["name"], {}).get("size")
                if size is None:
                    continue
                val = 0
                offset = sig["offset"]
                for i in range(size):
                    pos = offset + i
                    if pos // 8 < len(raw):
                        val |= (((raw[pos // 8] >> (pos % 8)) & 1) << i)
                decoded[sig["name"]] = val
            pairs = ", ".join("%s=%d" % (k, v) for k, v in decoded.items())
            return self._finish_entry(entry, "1.DUT回复LIN帧：%s：%s\n2.信号解码断言：%s" % (frame["name"], data_hex, pairs))
        except Exception as e:
            entry.add_check("解码执行", False, "LIN 解码失败: %s" % e)
            return self._finish_entry(entry, "待补：帧 %s 解码失败（%s）" % (key, e), filled=False)

    def _get_message(self, key):
        """按帧名或 frame_id 查找 DBC 报文"""
        if self.dbc is None:
            return None
        for msg in self.dbc.messages:
            if msg.name == key:
                return msg
        try:
            fid = int(key, 16)
        except ValueError:
            return None
        for msg in self.dbc.messages:
            if msg.frame_id == fid:
                return msg
        return None

    # ---- 审计辅助 ----
    def _new_entry(self, case_id, field, placeholder):
        entry = AuditEntry(case_id, field, placeholder)
        self.audit.append(entry)
        return entry

    def _finish_entry(self, entry, req, exp=None, filled=True):
        """记录生成文本、统计状态；FAIL/WARN 时在文本中加可见标注（杜绝虚假报文被静默使用）。

        Args:
            entry: AuditEntry
            req: 请求文本（procedure 用）
            exp: 响应文本（expected 用，可 None）
            filled: 是否成功填充
        Returns:
            (req, exp) 或单独文本（exp 为 None 时）
        """
        texts = [req] if exp is None else [req, exp]
        if entry.status == "FAIL":
            mark = "[审查失败] "
        elif entry.status == "WARN":
            mark = "[需确认] "
        else:
            mark = ""
        if mark:
            texts = [mark + t if t else t for t in texts]
        entry.generated = " || ".join(t for t in texts if t)
        if filled:
            self.stats["filled"] += 1
        else:
            self.stats["missing"] += 1
        self.stats[entry.status.lower()] += 1
        if exp is None:
            return texts[0]
        return texts[0], texts[1]

    # ---- 各占位符实现（返回 procedure 文本 / expected 文本） ----
    def _read_did(self, did, case_id, field):
        """0x22 读 DID → (procedure, expected)，审计 DID 存在性与长度"""
        entry = self._new_entry(case_id, field, "{{READ_DID:%s}}" % did)
        try:
            did_int = int(did, 16)
        except ValueError:
            entry.source = "推断"
            entry.add_check("DID格式", False, "DID %s 非十六进制" % did)
            return None, self._finish_entry(entry, "待补：DID %s 格式非法（应为 F12E）" % did, filled=False)

        did_bytes = [(did_int >> 8) & 0xFF, did_int & 0xFF]
        length = self.did_lengths.get("0x%04X" % did_int)

        if length is None:
            entry.source = "推断（CDD 无此 DID）"
            entry.add_warn("DID存在性", "0x%04X 不在 CDD 中，长度按 SWRS 推断" % did_int)
            req = req_text(0x22, did_bytes)
            exp = "1. DUT正响应：62 %02X %02X + 数据（长度以 SWRS 为准）；" % (did_bytes[0], did_bytes[1])
            return self._finish_entry(entry, req, exp)
        else:
            entry.source = "CDD"
            entry.add_check("DID存在性", True, "0x%04X 在 CDD 中，长度=%d" % (did_int, length))
            req = req_text(0x22, did_bytes)
            if req is None:
                req = "1.测试仪请求：22 %02X %02X（多帧，见 SWRS）；" % (did_bytes[0], did_bytes[1])
            if length <= DATA_LEN - 3:
                exp = "1. DUT正响应：62 %02X %02X + %d 字节数据（具体值以 SWRS 为准）；" % (
                    did_bytes[0], did_bytes[1], length)
            else:
                exp = "1. DUT正响应：62 %02X %02X + %d 字节数据（多帧 ISO-TP 分帧，FF_DL 见 SWRS）；" % (
                    did_bytes[0], did_bytes[1], length)
            # 正响应 SID 校验
            entry.add_check("正响应SID", True, "0x62 == 0x22+0x40")
            return self._finish_entry(entry, req, exp)

    def _write_did(self, did, data_hex, case_id, field):
        """0x2E 写 DID → (procedure, expected)，审计数据长度"""
        entry = self._new_entry(case_id, field, "{{WRITE_DID:%s:%s}}" % (did, data_hex))
        try:
            did_int = int(did, 16)
            data = [int(data_hex[i:i+2], 16) for i in range(0, len(data_hex), 2)]
        except ValueError:
            entry.source = "推断"
            entry.add_check("参数格式", False, "WRITE_DID 参数非法")
            return None, self._finish_entry(entry, "待补：WRITE_DID 参数非法（应为 {{WRITE_DID:F12E:010203}}）", filled=False)

        did_bytes = [(did_int >> 8) & 0xFF, did_int & 0xFF]
        length = self.did_lengths.get("0x%04X" % did_int)

        if length is None:
            entry.source = "推断（CDD 无此 DID）"
            entry.add_warn("DID存在性", "0x%04X 不在 CDD 中，长度未校验" % did_int)
        else:
            entry.source = "CDD"
            entry.add_check("DID存在性", True, "0x%04X 在 CDD 中，长度=%d" % (did_int, length))
            entry.add_check("数据长度", len(data) <= length,
                            "写入 %d 字节 ≤ DID 长度 %d" % (len(data), length))

        req = req_text(0x2E, did_bytes + data)
        if req is None:
            req = "1.测试仪请求：2E %02X %02X + %d 字节数据（多帧 ISO-TP 分帧，FF_DL 见 SWRS）；" % (
                did_bytes[0], did_bytes[1], len(data))
        exp = rsp_text(0x6E, did_bytes)
        if exp is None:
            exp = "1. DUT正响应：6E %02X %02X；" % (did_bytes[0], did_bytes[1])
        entry.add_check("正响应SID", True, "0x6E == 0x2E+0x40")
        return self._finish_entry(entry, req, exp)

    def _session(self, sub, case_id, field):
        """0x10 会话切换 → (procedure, expected)，审计子功能合法性"""
        entry = self._new_entry(case_id, field, "{{SESSION:%s}}" % sub)
        entry.source = "ISO 14229"
        try:
            sub_int = int(sub, 16)
        except ValueError:
            entry.add_check("子功能格式", False, "SESSION 参数非法")
            return None, self._finish_entry(entry, "待补：SESSION 参数非法（应为 01/02/03/04/40-5F/60-7E 等）", filled=False)
        valid = is_valid_subfunction(0x10, sub_int)
        entry.add_check("子功能合法性", valid,
                        "0x10 子功能 0x%02X %s" % (sub_int, "合法" if valid else "非法"))
        req = req_text(0x10, [sub_int])
        exp = rsp_text(0x50, [sub_int])
        entry.add_check("正响应SID", True, "0x50 == 0x10+0x40")
        return self._finish_entry(entry, req, exp)

    def _reset(self, sub, case_id, field):
        """0x11 ECU 复位 → (procedure, expected)，审计子功能合法性"""
        entry = self._new_entry(case_id, field, "{{RESET:%s}}" % sub)
        entry.source = "ISO 14229"
        try:
            sub_int = int(sub, 16)
        except ValueError:
            entry.add_check("子功能格式", False, "RESET 参数非法")
            return None, self._finish_entry(entry, "待补：RESET 参数非法（应为 01/02/03/04/05 等）", filled=False)
        valid = is_valid_subfunction(0x11, sub_int)
        entry.add_check("子功能合法性", valid,
                        "0x11 子功能 0x%02X %s" % (sub_int, "合法" if valid else "非法"))
        req = req_text(0x11, [sub_int])
        exp = rsp_text(0x51, [sub_int])
        entry.add_check("正响应SID", True, "0x51 == 0x11+0x40")
        return self._finish_entry(entry, req, exp)

    def _tester_present(self, args, case_id, field):
        """0x3E 保活 → (procedure, expected)"""
        entry = self._new_entry(case_id, field, "{{TP%s}}" % (":%s" % args if args.strip() else ""))
        entry.source = "ISO 14229"
        sub = 0x00
        if args and args.strip():
            try:
                sub = int(args.strip(), 16)
            except ValueError:
                pass
        valid = is_valid_subfunction(0x3E, sub)
        entry.add_check("子功能合法性", valid,
                        "0x3E 子功能 0x%02X %s" % (sub, "合法" if valid else "非法"))
        req = req_text(0x3E, [sub])
        if sub == 0x80:
            exp = "1. DUT无正响应（suppressPosRspMsgIndicationBit=1，抑制正响应）；"
        else:
            exp = rsp_text(0x7E, [sub])
            entry.add_check("正响应SID", True, "0x7E == 0x3E+0x40")
        return self._finish_entry(entry, req, exp)

    def _msg_encode(self, key, sig_str, case_id, field):
        """DBC 信号编码 → CAN 报文 hex（仅 procedure），审计信号存在与范围"""
        entry = self._new_entry(case_id, field, "{{MSG:%s:%s}}" % (key, sig_str))
        entry.source = "DBC"
        msg = self._get_message(key)
        if msg is None:
            entry.add_check("报文存在性", False, "DBC 中找不到报文 %s" % key)
            return self._finish_entry(entry, "待补：DBC 中找不到报文 %s（或未提供 --dbc）" % key, filled=False)
        entry.add_check("报文存在性", True, "报文 %s (0x%X)" % (msg.name, msg.frame_id))

        try:
            signals = {}
            for pair in sig_str.split(","):
                if "=" not in pair:
                    continue
                name, _, val = pair.strip().partition("=")
                try:
                    signals[name] = float(val) if "." in val else int(val, 0)
                except ValueError:
                    signals[name] = val
            # 校验信号存在性与范围
            for name, val in signals.items():
                sig = next((s for s in msg.signals if s.name == name), None)
                if sig is None:
                    entry.add_check("信号存在性", False, "报文 %s 无信号 %s" % (msg.name, name))
                    continue
                if isinstance(val, (int, float)) and sig.minimum is not None and sig.maximum is not None:
                    entry.add_check("信号范围", sig.minimum <= val <= sig.maximum,
                                    "%s=%s ∈ [%s, %s]" % (name, val, sig.minimum, sig.maximum))
            raw = msg.encode(signals)
            hex_str = " ".join("%02X" % b for b in raw)
            return self._finish_entry(entry,
                "1.发送报文：%s#%s（0x%X: %s）；" % (msg.name, hex_str, msg.frame_id, sig_str))
        except Exception as e:
            entry.add_check("编码执行", False, "编码失败: %s" % e)
            return self._finish_entry(entry, "待补：报文 %s 编码失败（%s），信号名/值以 DBC 为准" % (key, e), filled=False)

    def _msg_decode(self, key, data_hex, case_id, field):
        """DBC 解码报文 hex → 信号断言（仅 expected），审计报文存在性"""
        entry = self._new_entry(case_id, field, "{{DECODE:%s:%s}}" % (key, data_hex))
        entry.source = "DBC"
        msg = self._get_message(key)
        if msg is None:
            entry.add_check("报文存在性", False, "DBC 中找不到报文 %s" % key)
            return self._finish_entry(entry, "待补：DBC 中找不到报文 %s（或未提供 --dbc）" % key, filled=False)
        entry.add_check("报文存在性", True, "报文 %s (0x%X)" % (msg.name, msg.frame_id))
        try:
            raw = bytes.fromhex(data_hex)
            entry.add_check("数据长度", len(raw) == msg.length, "hex %d 字节 == DLC %d" % (len(raw), msg.length))
            decoded = msg.decode(raw)
            pairs = ", ".join("%s=%s" % (k, v) for k, v in decoded.items())
            return self._finish_entry(entry, "1.DUT回复：%s#%s\n2.信号解码断言：%s" % (msg.name, data_hex, pairs))
        except Exception as e:
            entry.add_check("解码执行", False, "解码失败: %s" % e)
            return self._finish_entry(entry, "待补：报文 %s 解码失败（%s）" % (key, e), filled=False)

    # ---- 主替换逻辑 ----
    def fill(self, case):
        """处理单个用例，按字段语义替换占位符"""
        case_id = case.get("case_id", "?")
        for field in ("procedure", "expected"):
            text = case.get(field, "")
            if not text:
                continue

            def repl(m, _field=field):
                kind, arg = m.group(1), m.group(2)
                arg = (arg or "").strip()
                if kind == "READ_DID":
                    p, e = self._read_did(arg, case_id, _field)
                    return (p or "待补") if _field == "procedure" else (e or "待补")
                elif kind == "WRITE_DID":
                    parts = arg.split(":")
                    if len(parts) == 2:
                        p, e = self._write_did(parts[0].strip(), parts[1].strip(), case_id, _field)
                        return (p or "待补") if _field == "procedure" else (e or "待补")
                    return "待补：WRITE_DID 格式应为 {{WRITE_DID:F12E:010203}}"
                elif kind == "SESSION":
                    p, e = self._session(arg, case_id, _field)
                    return (p or "待补") if _field == "procedure" else (e or "待补")
                elif kind == "RESET":
                    p, e = self._reset(arg, case_id, _field)
                    return (p or "待补") if _field == "procedure" else (e or "待补")
                elif kind == "TP":
                    p, e = self._tester_present(arg, case_id, _field)
                    return (p or "待补") if _field == "procedure" else (e or "待补")
                elif kind == "MSG":
                    parts = arg.split(":")
                    if len(parts) == 2:
                        return self._msg_encode(parts[0].strip(), parts[1].strip(), case_id, _field)
                    return "待补：MSG 格式应为 {{MSG:0x1F0:Enable=1,AverageRadius=3.2}}"
                elif kind == "DECODE":
                    parts = arg.split(":")
                    if len(parts) == 2:
                        return self._msg_decode(parts[0].strip(), parts[1].strip(), case_id, _field)
                    return "待补：DECODE 格式应为 {{DECODE:0x1F0:804A0F0000000000}}"
                elif kind == "LIN_MSG":
                    parts = arg.split(":", 1)
                    if len(parts) == 2:
                        return self._lin_encode(parts[0].strip(), parts[1].strip(), case_id, _field)
                    return "待补：LIN_MSG 格式应为 {{LIN_MSG:BBS1LinFr03:SoundrBattBackedDiag=1234}}"
                elif kind == "LIN_DECODE":
                    parts = arg.split(":", 1)
                    if len(parts) == 2:
                        return self._lin_decode(parts[0].strip(), parts[1].strip(), case_id, _field)
                    return "待补：LIN_DECODE 格式应为 {{LIN_DECODE:BBS1LinFr03:0011223344556600}}"
                else:
                    entry = self._new_entry(case_id, _field, m.group(0))
                    entry.source = "未知"
                    entry.add_warn("占位符支持", "未知占位符 %s，保持原样" % kind)
                    self.stats["lin_skip"] += 1
                    return m.group(0) + "（占位符 %s 暂不支持）" % kind

            case[field] = PLACEHOLDER_RE.sub(repl, text)
        return case

    # ---- 审计报告 ----
    def audit_report(self):
        """生成审计报告 dict"""
        return {
            "tool": "steps_generator.py",
            "version": __version__,
            "summary": {
                "total_placeholders": len(self.audit),
                "filled": self.stats["filled"],
                "missing": self.stats["missing"],
                "pass": self.stats["pass"],
                "warn": self.stats["warn"],
                "fail": self.stats["fail"],
            },
            "entries": [e.to_dict() for e in self.audit],
        }


def main():
    parser = argparse.ArgumentParser(description="UDS/CAN/LIN 报文级步骤自动生成器 v2.1（含审计审查）")
    parser.add_argument("--cases", "-c", required=True, help="用例 JSON 路径（case-schema 格式）")
    parser.add_argument("--out", "-o", required=True, help="输出 JSON 路径（填充后）")
    parser.add_argument("--cdd", help="CDD 诊断文件（提供 DID 长度）")
    parser.add_argument("--dbc", help="DBC CAN 数据库（提供报文信号编解码）")
    parser.add_argument("--ldf", help="LDF 解析产物 lin_db.json（提供 LIN 帧/PID/信号偏移，供 LIN_MSG/LIN_DECODE）")
    parser.add_argument("--audit", "-a", help="审计报告 JSON 输出路径（建议必填，用于人工复核）")
    args = parser.parse_args()

    if not os.path.exists(args.cases):
        print("[ERROR] 用例 JSON 不存在: %s" % args.cases)
        sys.exit(1)

    with open(args.cases, encoding="utf-8") as f:
        data = json.load(f)

    gen = StepGenerator(cdd_path=args.cdd, dbc_path=args.dbc, ldf_path=args.ldf)
    cases = data.get("cases", [])
    print("[INFO] 处理 %d 条用例..." % len(cases))
    for case in cases:
        gen.fill(case)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    report = gen.audit_report()

    # ---- 审计结果汇总 ----
    print("\n[INFO] 统计:")
    print("  - 成功填充: %d 处" % gen.stats["filled"])
    print("  - 待补/失败: %d 处" % gen.stats["missing"])
    print("  - 未知占位符跳过: %d 处" % gen.stats["lin_skip"])
    print("\n[审查] 审计结果:")
    print("  - ✅ PASS: %d 处" % report["summary"]["pass"])
    print("  - ⚠️ WARN: %d 处（有推断或数据源缺失，需人工确认）" % report["summary"]["warn"])
    print("  - ❌ FAIL: %d 处（校验失败，禁止静默使用）" % report["summary"]["fail"])

    for e in report["entries"]:
        if e["status"] == "FAIL":
            print("  ❌ %s [%s] %s" % (e["case_id"], e["field"], e["placeholder"]))
            for c in e["checks"]:
                if c["status"] == "FAIL":
                    print("      - %s: %s" % (c["rule"], c["detail"]))

    if args.audit:
        os.makedirs(os.path.dirname(os.path.abspath(args.audit)), exist_ok=True)
        with open(args.audit, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        print("\n[INFO] 审计报告: %s" % args.audit)

    print("\n[INFO] 输出: %s" % args.out)
    print("[HINT] 下一步: python build_testcase_xlsx.py %s --out cases.xlsx" % args.out)

    # FAIL 时返回非零退出码，阻断交付：必须按审计报告逐条修复后重跑
    if report["summary"]["fail"] > 0:
        print("\n[ERROR] 存在 %d 处 FAIL，阻断交付：请按审计报告逐条修复后重跑" % report["summary"]["fail"])
        sys.exit(2)


if __name__ == "__main__":
    main()
