#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""全量矩阵生成器项目配置化回归。"""

import re
import unittest

from uds_full_matrix_generator import CaseBuilder, build_cases
from case_lint import lint


def _parts(did_count=15):
    dids = {
        f"A{index:03X}": f"项目 DID {index}"
        for index in range(did_count)
    }
    return {
        "APP": {
            "protocol": {"net": "LIN", "bus_rate": "19.2Kbps", "protocol": "ISO-14229"},
            "timing": {
                "P2Server": "50",
                "P2StarServer": "5000",
                "S3Server": "5000",
                "N_As": "1000",
                "N_Cr": "1000",
            },
            "services": {0x10: {"subs": ["01", "04"]}},
            "dids": dids,
            "composite": {},
            "routines": {},
        }
    }


def _config(**generation):
    return {
        "project": "matrix-review",
        "transport": {"physical_nad": "0x60", "functional_nad": "0x70"},
        "sessions": {
            "supported": ["0x01", "0x04"],
            "names": {"0x01": "Normal", "0x04": "Diag"},
            "default": "0x01",
            "allowed_transitions": {
                "0x01": ["0x01", "0x04"],
                "0x04": ["0x01"],
            },
            "s3_required": ["0x04"],
        },
        "nrc": {
            "illegal_subfunction": {
                "0x10": "0x11",
                "0x11": "0x13",
                "0x27": "0x14",
                "0x3E": "0x15",
            }
        },
        "generation": {
            "session_targets": [0x01, 0x04],
            "session_sources": [0x01, 0x04],
            "read_sessions": [0x01, 0x04],
            "security_sessions": [0x04],
            "tester_present_sessions": [0x01, 0x04],
            "reset_sessions": [0x01, 0x04],
            "security_access_subfunctions": [0x07, 0x08],
            "session_probe_did": None,
            "reset_probe_did": None,
            "unsupported_did": None,
            "security_constant_dids": {},
            "representative_write_did": None,
            "max_write_dids": None,
            **generation,
        },
    }


def _generate(config):
    builder = CaseBuilder(_parts(), "review", "bench", project_config=config)
    build_cases(builder)
    return builder.cases


class TestFullMatrixProjectConfiguration(unittest.TestCase):
    def test_custom_matrix_has_expected_size_and_zero_lint_failures(self):
        config = _config()
        cases = _generate(config)
        _results, summary = lint(cases, project_config=config)
        self.assertEqual(len(cases), 190)
        self.assertEqual(sum(summary.values()), 0, summary)

    def test_reset_expected_response_keeps_uds_service_byte(self):
        cases = _generate(_config())
        reset_cases = [case for case in cases if case["case_id"].startswith("UDS_0X11_")]
        physical = [case for case in reset_cases if "60 02 11 01" in case["procedure"]]
        functional = [case for case in reset_cases if "70 02 11 01" in case["procedure"]]
        self.assertTrue(physical)
        self.assertTrue(functional)
        self.assertTrue(any("60 02 51 01" in case["expected"] for case in physical))
        self.assertTrue(any("60 02 51 01" in case["expected"] for case in functional))
        self.assertFalse(any("60 02 60 01" in case["expected"] for case in physical))

    def test_custom_nads_and_unconfigured_example_dids_do_not_leak(self):
        cases = _generate(_config())
        text = "\n".join(
            str(case.get(field, ""))
            for case in cases
            for field in ("precondition", "procedure", "expected", "req_sources")
        )
        self.assertNotRegex(text, r"(?im)(?:^|[\n：:])\s*(?:51|53|82)\s+(?:[0-9A-F]{2}|XX)\b")
        for legacy_did in ("F186", "F10A", "F103", "F12E"):
            self.assertNotIn(legacy_did, text)
        unsupported = [case for case in cases if "未支持DID" in case["procedure"]]
        self.assertEqual(len(unsupported), 1)
        self.assertIn("<项目未配置DID>", unsupported[0]["procedure"])

    def test_null_write_limit_covers_all_dids_and_custom_subfunctions_nrc(self):
        cases = _generate(_config())
        read_dids = {
            match.group(1) + match.group(2)
            for case in cases
            if case["case_id"].startswith("UDS_0X22_")
            for match in [re.search(r"\b22 ([0-9A-F]{2}) ([0-9A-F]{2})\b", case["procedure"])]
            if match
        }
        self.assertEqual(len(read_dids), 15)
        self.assertEqual(
            sum(1 for case in cases if case["case_id"].startswith("UDS_0X2E_")),
            45,
        )
        security = [case for case in cases if case["case_id"].startswith("UDS_0X27_")]
        self.assertTrue(any("27 07" in case["procedure"] for case in security))
        self.assertTrue(any("27 08" in case["procedure"] for case in security))
        illegal_session = [case for case in cases if "7F 10 11" in case["expected"]]
        illegal_security = [case for case in cases if "7F 27 14" in case["expected"]]
        self.assertTrue(illegal_session)
        self.assertTrue(illegal_security)


if __name__ == "__main__":
    unittest.main(verbosity=2)
