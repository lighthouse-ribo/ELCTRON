# -*- coding: utf-8 -*-
"""Small, dependency-free reader for portable project packs.

This layer owns path safety and file-level facts. It deliberately does not
parse DOCX/XLSX/PDF content; role-specific parsers remain above it.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path, PurePosixPath
from typing import Any


SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")
DRIVE_RE = re.compile(r"^[A-Za-z]:")


class PortablePackError(ValueError):
    """Raised when a pack reference is unsafe or structurally unreadable."""


def load_json(path: str | Path) -> Any:
    try:
        with Path(path).open(encoding="utf-8") as stream:
            return json.load(stream)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise PortablePackError(f"无法读取 JSON: {path}: {exc}") from exc


def resolve_pack_path(pack_dir: str | Path, relative_path: str) -> Path:
    """Resolve a portable `/` path and reject absolute/traversal references."""

    if not isinstance(relative_path, str) or not relative_path.strip():
        raise PortablePackError("文件 path 不能为空")
    raw = relative_path.strip()
    if "\x00" in raw or "\\" in raw or raw.startswith("/") or DRIVE_RE.match(raw):
        raise PortablePackError(f"path 必须是使用 / 的相对路径: {relative_path!r}")

    parts = PurePosixPath(raw).parts
    if not parts or any(part in ("", ".", "..") for part in parts):
        raise PortablePackError(f"path 不允许 . 或 .. 段: {relative_path!r}")

    root = Path(pack_dir).resolve()
    candidate = root.joinpath(*parts).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise PortablePackError(f"path 越出输入包目录: {relative_path!r}") from exc
    return candidate


def sha256_file(path: str | Path, *, cap_bytes: int | None = None) -> str:
    file_path = Path(path)
    if cap_bytes is not None and file_path.stat().st_size > cap_bytes:
        raise PortablePackError(f"文件超过哈希上限: {file_path}")
    digest = hashlib.sha256()
    with file_path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_text_excerpt(path: str | Path, *, max_chars: int = 4000) -> str:
    """Read a bounded UTF-8 excerpt; callers must not use this for full context."""

    if max_chars < 0:
        raise ValueError("max_chars 不能为负数")
    with Path(path).open(encoding="utf-8", errors="replace") as stream:
        return stream.read(max_chars)


def inspect_file(
    pack_dir: str | Path,
    relative_path: str,
    *,
    expected_sha256: str | None = None,
    cap_bytes: int = 200 * 1024 * 1024,
) -> dict[str, Any]:
    """Return file metadata without exposing its absolute path in the result."""

    result: dict[str, Any] = {
        "path": relative_path,
        "exists": False,
        "is_file": False,
        "size_bytes": None,
        "sha256": None,
        "hash_ok": None,
        "path_error": None,
        "read_error": None,
    }
    try:
        path = resolve_pack_path(pack_dir, relative_path)
    except PortablePackError as exc:
        result["path_error"] = str(exc)
        return result

    if not path.exists():
        return result
    result["exists"] = True
    if not path.is_file():
        result["read_error"] = "引用对象不是普通文件"
        return result
    result["is_file"] = True
    result["size_bytes"] = path.stat().st_size
    try:
        result["sha256"] = sha256_file(path, cap_bytes=cap_bytes)
    except (OSError, PortablePackError) as exc:
        result["read_error"] = str(exc)
        return result

    if expected_sha256 is not None:
        expected = str(expected_sha256).strip()
        result["hash_ok"] = bool(SHA256_RE.fullmatch(expected)) and result["sha256"].lower() == expected.lower()
    return result


__all__ = [
    "PortablePackError",
    "SHA256_RE",
    "inspect_file",
    "load_json",
    "read_text_excerpt",
    "resolve_pack_path",
    "sha256_file",
]
