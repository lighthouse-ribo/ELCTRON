# -*- coding: utf-8 -*-
"""Tests for the lightweight project file to fact mapping layer."""

from __future__ import annotations

import json
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from project_fact_mapper import build_project_fact_map  # noqa: E402


ROOT = Path(__file__).resolve().parents[3]
PACK = ROOT / "examples" / "portable-project-pack"


def load_json(path):
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


class TestProjectFactMapper(unittest.TestCase):
    def setUp(self):
        self.manifest = load_json(PACK / "input_manifest.json")
        self.context = load_json(PACK / "project_context.json")
        self.mapping = build_project_fact_map(self.manifest, self.context)

    def test_mapping_is_versioned_and_keeps_partitions(self):
        self.assertEqual(self.mapping["schema"], "project-fact-map/v0.1")
        rows = {row["file_id"]: row for row in self.mapping["files"]}
        self.assertEqual(rows["sddb-app"]["partition"], "APP")
        self.assertEqual(rows["sddb-pbl"]["partition"], "PBL")
        self.assertEqual(rows["sddb-sbl"]["partition"], "SBL")
        self.assertNotEqual(rows["sddb-app"]["partition"], rows["sddb-pbl"]["partition"])

    def test_current_project_facts_map_to_expected_sources(self):
        rows = {row["file_id"]: row for row in self.mapping["files"]}
        self.assertIn("transport.physical_nad", rows["lin-matrix"]["fact_ids"])
        self.assertIn("transport.bitrate_kbps", rows["lin-matrix"]["fact_ids"])
        self.assertIn("transport.timing", rows["lin-matrix"]["fact_ids"])
        self.assertIn("security.key_material", rows["security-doc"]["fact_ids"])
        self.assertEqual(rows["security-store"]["status"], "metadata_only")

    def test_unmapped_sources_are_explicit_not_promoted_to_facts(self):
        self.assertIn("did-checklist", self.mapping["unmapped_files"])
        self.assertIn("swrs", self.mapping["unmapped_files"])
        self.assertNotIn("value", json.dumps(self.mapping, ensure_ascii=False))

    def test_unknown_source_is_reported_without_copying_fact_value(self):
        context = json.loads(json.dumps(self.context))
        context["facts"][0]["source"]["file_id"] = "missing-file"
        mapping = build_project_fact_map(self.manifest, context)
        self.assertTrue(any("unknown file id" in error for error in mapping["errors"]))
        self.assertNotIn("value", json.dumps(mapping, ensure_ascii=False))


if __name__ == "__main__":
    unittest.main(verbosity=2)
