# -*- coding: utf-8 -*-
"""Adapt existing project-file parsers to portable project facts.

The adapter is intentionally small: parser-specific result objects stay at the
parser boundary, while this module emits only bounded facts with stable source
references.  It does not modify the existing parsers or copy raw documents.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any, Callable, Mapping

from portable_pack_reader import PortablePackError, inspect_file, load_json, resolve_pack_path


SCHEMA = "project-fact-adapter/v0.1"
SUPPORTED_ROLES = {"diag_survey", "ldf"}


def _load_parser(module_name: str, filename: str):
    parser_dir = Path(__file__).resolve().parents[2] / "uds-diagnostic-test" / "scripts"
    path = parser_dir / filename
    parser_dir_text = str(parser_dir)
    if parser_dir_text not in sys.path:
        sys.path.insert(0, parser_dir_text)
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"无法加载解析器: {filename}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _source(file_id: str, locator: str) -> dict[str, str]:
    return {"file_id": file_id, "locator": locator}


def _fact(fact_id: str, partition: str, value: Any, status: str,
          file_id: str, locator: str) -> dict[str, Any]:
    if status in {"pending", "conflict", "blocked"}:
        value = None
    return {
        "id": fact_id,
        "partition": partition,
        "value": value,
        "status": status,
        "source": _source(file_id, locator),
    }


def _derived_or_pending(value: Any) -> tuple[Any, str]:
    if value is None or value == "":
        return None, "pending"
    return value, "derived"


def _fact_prefix(namespace: str, partition: str, file_id: str) -> str:
    return f"{namespace}.{partition}.{file_id}"


def _diag_facts(entry: Mapping[str, Any], parsed: Mapping[str, Any]) -> list[dict[str, Any]]:
    file_id = str(entry["id"])
    partition = str(entry.get("partition", "shared"))
    prefix = _fact_prefix("diagnostic", partition, file_id)
    fields = (
        ("did_count", len(parsed.get("dids") or []), "counts.dids"),
        ("io_control_count", len(parsed.get("io_controls") or []), "counts.io_controls"),
        ("routine_count", len(parsed.get("routines") or []), "counts.routines"),
        ("dtc_count", len(parsed.get("dtcs") or []), "counts.dtcs"),
        ("defaulted_field_count", len(parsed.get("defaults_used") or []), "quality.defaults_used"),
        ("missing_attribute_count", len(parsed.get("missing_attributes") or []), "quality.missing_attributes"),
    )
    facts = [
        _fact(f"{prefix}.{name}", partition, value, "derived", file_id,
              f"uds_survey_parser.parse_survey_table/{locator}")
        for name, value, locator in fields
    ]
    return facts


def _ldf_facts(entry: Mapping[str, Any], parsed: Mapping[str, Any]) -> list[dict[str, Any]]:
    file_id = str(entry["id"])
    partition = str(entry.get("partition", "shared"))
    prefix = _fact_prefix("transport", partition, file_id)
    frames = parsed.get("frames") or []
    diag_frames = [frame for frame in frames if frame.get("frame_type") == "diagnostic"]
    master = parsed.get("master") or {}
    values = (
        ("lin_speed_bps", parsed.get("lin_speed_bps") or None, "lin_speed_bps"),
        ("master_name", master.get("name"), "master.name"),
        ("slave_count", len(parsed.get("slaves") or []), "nodes.slaves"),
        ("signal_count", len(parsed.get("signals") or []), "counts.signals"),
        ("diagnostic_signal_count", len(parsed.get("diagnostic_signals") or []), "counts.diagnostic_signals"),
        ("frame_count", len(frames), "counts.frames"),
        ("diagnostic_frame_count", len(diag_frames), "counts.diagnostic_frames"),
        ("schedule_count", len(parsed.get("schedule_tables") or {}), "counts.schedule_tables"),
        ("warning_count", len(parsed.get("warnings") or []), "quality.warnings"),
    )
    facts = []
    for name, value, locator in values:
        normalized, status = _derived_or_pending(value)
        facts.append(_fact(f"{prefix}.{name}", partition, normalized, status, file_id,
                           f"ldf_parser.parse_ldf/{locator}"))
    return facts


def _parser_for_role(role: str) -> tuple[str, Callable[[str], Mapping[str, Any]]] | None:
    if role == "diag_survey":
        module = _load_parser("portable_uds_survey_parser", "uds_survey_parser.py")
        return "uds_survey_parser.parse_survey_table", module.parse_survey_table
    if role == "ldf":
        module = _load_parser("portable_ldf_parser", "ldf_parser.py")
        return "ldf_parser.parse_ldf", module.parse_ldf
    return None


def _portable_error(exc: BaseException, path: Path, pack_dir: Path) -> str:
    message = str(exc).replace(str(path), "<project-file>").replace(str(pack_dir), "<project-pack>")
    return f"{type(exc).__name__}: {message}"[:500]


def adapt_project_files(pack_dir: str | Path, manifest: Mapping[str, Any],
                        roles: set[str] | None = None) -> dict[str, Any]:
    """Parse supported manifest entries and return portable summary facts."""

    root = Path(pack_dir).resolve()
    selected = set(roles) if roles is not None else None
    facts: list[dict[str, Any]] = []
    files: list[dict[str, Any]] = []
    errors: list[str] = []
    pending_roles: set[str] = set()

    for entry in manifest.get("files") or []:
        if not isinstance(entry, Mapping) or not entry.get("id"):
            continue
        role = str(entry.get("role", "other"))
        if selected is not None and role not in selected:
            continue
        file_id = str(entry["id"])
        partition = str(entry.get("partition", "shared"))
        rel_path = entry.get("path", "")
        file_row: dict[str, Any] = {
            "file_id": file_id,
            "role": role,
            "partition": partition,
            "path": rel_path,
            "status": "pending",
            "parser": None,
            "fact_ids": [],
            "error": None,
        }

        try:
            path = resolve_pack_path(root, rel_path)
            metadata = inspect_file(root, rel_path, expected_sha256=entry.get("sha256"))
            if not metadata["exists"] or not metadata["is_file"]:
                file_row["status"] = "blocked"
                file_row["error"] = "project file is missing"
            elif metadata["hash_ok"] is False:
                file_row["status"] = "blocked"
                file_row["error"] = "sha256 mismatch"
            elif role not in SUPPORTED_ROLES:
                pending_roles.add(role)
                file_row["error"] = "no adapter registered for this role"
                status_fact = _fact(f"parser.{partition}.{file_id}.status", partition, None,
                                    "pending", file_id, "adapter")
                facts.append(status_fact)
                file_row["fact_ids"] = [status_fact["id"]]
            elif entry.get("sensitivity") == "secret":
                file_row["status"] = "blocked"
                file_row["error"] = "secret source is metadata-only"
            else:
                parser_info = _parser_for_role(role)
                assert parser_info is not None
                parser_name, parser = parser_info
                parsed = parser(str(path))
                if not isinstance(parsed, Mapping):
                    raise TypeError("parser result must be an object")
                parser_facts = _diag_facts(entry, parsed) if role == "diag_survey" else _ldf_facts(entry, parsed)
                facts.extend(parser_facts)
                status_fact = _fact(f"parser.{partition}.{file_id}.status", partition, "parsed",
                                    "derived", file_id, "adapter")
                facts.append(status_fact)
                file_row["status"] = "mapped"
                file_row["parser"] = parser_name
                file_row["fact_ids"] = [fact["id"] for fact in parser_facts] + [status_fact["id"]]
        except Exception as exc:
            file_row["status"] = "blocked"
            file_row["error"] = _portable_error(exc, Path(str(rel_path)), root)

        if file_row["status"] == "blocked":
            status_fact = _fact(f"parser.{partition}.{file_id}.status", partition, None,
                                "blocked", file_id, "adapter")
            facts.append(status_fact)
            file_row["fact_ids"] = [status_fact["id"]]
            errors.append(f"{file_id}: {file_row['error']}")
        files.append(file_row)

    return {
        "schema": SCHEMA,
        "project": dict(manifest.get("project") or {}),
        "facts": facts,
        "files": files,
        "pending_roles": sorted(pending_roles),
        "errors": errors,
    }


def adapt_manifest(manifest_path: str | Path, roles: set[str] | None = None) -> dict[str, Any]:
    path = Path(manifest_path).resolve()
    manifest = load_json(path)
    if not isinstance(manifest, Mapping):
        raise ValueError("manifest 根节点必须是对象")
    return adapt_project_files(path.parent, manifest, roles=roles)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="将项目文件解析结果适配为可移植事实摘要")
    parser.add_argument("--manifest", required=True, help="project-pack/input_manifest.json")
    parser.add_argument("--output", required=True, help="适配结果 JSON")
    parser.add_argument("--role", action="append", help="只处理指定 role，可重复传入")
    args = parser.parse_args(argv)
    result = adapt_manifest(args.manifest, set(args.role) if args.role else None)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[OK] 项目事实适配: files={len(result['files'])} facts={len(result['facts'])}")
    return 0 if not result["errors"] else 1


if __name__ == "__main__":
    sys.exit(main())


__all__ = ["SCHEMA", "SUPPORTED_ROLES", "adapt_manifest", "adapt_project_files"]
