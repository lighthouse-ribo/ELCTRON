# -*- coding: utf-8 -*-
"""test_input_pack_validator.py — 输入文件包校验器单元测试（临时包目录，不依赖真实项目资料）"""

import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import input_pack_validator as pv

SWRS_TXT = """SWRS demo
2. Diagnostics
REQ-90001v1 ReadDataByIdentifier
The ECU shall support 0x22 read of DID F12E.
Tester request: 51 03 22 F1 2E FF FF FF
NRC=0x31 when session unsupported.
"""


def write(path, content, mode="w"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if "b" in mode:
        with open(path, mode) as f:
            f.write(content if isinstance(content, bytes) else content.encode("utf-8"))
    else:
        with open(path, mode, encoding="utf-8") as f:
            f.write(content)


def make_manifest(pack, files):
    m = {"$schema": "input-pack-manifest/v1",
         "project": {"name": "demo", "target_ecu": "BBS", "sw_version": "V1", "bus": "LIN"},
         "files": files}
    p = os.path.join(pack, "input_manifest.json")
    write(p, json.dumps(m, ensure_ascii=False, indent=2))
    return p


class TestInputPackValidator(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix=".test_pack_")

    def test_ready_pack(self):
        pack = os.path.join(self.tmp, "ready")
        write(os.path.join(pack, "survey", "demo_diagnostic.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "survey", "did_checklist.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "project_config.json"),
              json.dumps({"sessions": {}, "transport": {}}))
        write(os.path.join(pack, "SWRS.txt"), SWRS_TXT)
        write(os.path.join(pack, "demo.ldf"), "LIN_description_file;\nnodes {\n}")
        mf = make_manifest(pack, [
            {"role": "diag_survey", "path": "survey/demo_diagnostic.xlsx"},
            {"role": "did_checklist", "path": "survey/did_checklist.xlsx"},
            {"role": "project_config", "path": "project_config.json"},
            {"role": "swrs", "path": "SWRS.txt"},
            {"role": "ldf", "path": "demo.ldf"},
        ])
        res = pv.validate_pack(mf)
        self.assertEqual(res["verdict"]["state"], "READY")
        rows = {r["role"]: r for r in res["files"]}
        self.assertTrue(rows["swrs"]["deep"]["ok"])
        self.assertIn("体检结论", rows["swrs"]["deep"]["msg"])
        self.assertTrue(rows["project_config"]["deep"]["ok"])
        self.assertTrue(rows["ldf"]["deep"]["ok"])
        self.assertNotIn("UDS 用例参数化设计", [m["module"] for m in res["modules"] if m["state"] == "BLOCKED"])

    def test_not_ready_missing_p0(self):
        pack = os.path.join(self.tmp, "nop0")
        write(os.path.join(pack, "SWRS.txt"), SWRS_TXT)
        mf = make_manifest(pack, [
            {"role": "swrs", "path": "SWRS.txt"},
            {"role": "diag_survey", "path": "survey/missing.xlsx"},  # 声明了但缺失
        ])
        res = pv.validate_pack(mf)
        self.assertEqual(res["verdict"]["state"], "NOT_READY")
        self.assertIn("UDS 用例参数化设计", res["blocked_modules"])
        self.assertIn("SWDL 刷写用例", res["blocked_modules"])  # 刷写流程图未随包
        self.assertTrue(any("诊断调查表" in a for a in res["next_actions"]))

    def test_p0_undeclared(self):
        pack = os.path.join(self.tmp, "undeclared")
        write(os.path.join(pack, "SWRS.txt"), SWRS_TXT)
        mf = make_manifest(pack, [{"role": "swrs", "path": "SWRS.txt"}])
        res = pv.validate_pack(mf)
        self.assertEqual(res["verdict"]["state"], "NOT_READY")
        self.assertIn("diag_survey", res["verdict"]["reason"])

    def test_partial_missing_p1(self):
        pack = os.path.join(self.tmp, "partial")
        write(os.path.join(pack, "survey", "demo_diagnostic.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "survey", "did_checklist.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "project_config.json"),
              json.dumps({"sessions": {}, "transport": {}}))
        # P1 的 swrs/ldf 均未随包
        mf = make_manifest(pack, [
            {"role": "diag_survey", "path": "survey/demo_diagnostic.xlsx"},
            {"role": "did_checklist", "path": "survey/did_checklist.xlsx"},
            {"role": "project_config", "path": "project_config.json"},
        ])
        res = pv.validate_pack(mf)
        self.assertEqual(res["verdict"]["state"], "PARTIAL")
        mods = {m["module"]: m["state"] for m in res["modules"]}
        self.assertEqual(mods.get("需求追溯"), "DEGRADED")
        self.assertIn("SWDL 刷写用例", res["blocked_modules"])  # flash_flowchart 未随包 → BLOCKED

    def test_deep_failure_non_blocking(self):
        pack = os.path.join(self.tmp, "deepfail")
        write(os.path.join(pack, "survey", "bad.xlsx"), "this is not a real xlsx", "wb")
        write(os.path.join(pack, "survey", "did_checklist.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "project_config.json"),
              json.dumps({"sessions": {}, "transport": {}}))
        mf = make_manifest(pack, [
            {"role": "diag_survey", "path": "survey/bad.xlsx"},
            {"role": "did_checklist", "path": "survey/did_checklist.xlsx"},
            {"role": "project_config", "path": "project_config.json"},
            {"role": "swrs", "path": "missing_swrs.txt"},  # P1 缺失 → PARTIAL
        ])
        res = pv.validate_pack(mf)
        row = next(r for r in res["files"] if r["role"] == "diag_survey")
        self.assertTrue(row["exists"])
        self.assertIsNotNone(row["deep"])
        self.assertFalse(row["deep"]["ok"])  # 解析失败但不阻断判定
        self.assertEqual(res["verdict"]["state"], "PARTIAL")

    def test_invalid_manifest(self):
        pack = os.path.join(self.tmp, "invalid")
        p = os.path.join(pack, "input_manifest.json")
        write(p, json.dumps({"project": {}}))  # 无 files
        with self.assertRaises(ValueError):
            pv.validate_pack(p)

    # ---- 0x27 密钥文档内容级检查（算法流程 ≠ 密钥值，BBS 项目实测教训） ----

    KEY_ALGO_DOC = ("""客户端：Request seed
27 01 0001 0001 iv[16] 加密数据记录[16] 认证数据[16]
Key-CTR：客户端随机数[16], iv[16] -> AES-CTR -> 加密数据记录[16]
Key-CMAC：认证数据[16]
服务器：Response seed
生成服务器所有权证明[16]
AES_ctr_key_0102：encryption and authentication key
AES_cmac_key_0102：proof of ownership key
""")

    def test_keydoc_algo_without_values_blocked(self):
        """有算法流程+密钥名、无密钥值 → 深度校验 ok=False，0x27 模块仍 BLOCKED"""
        pack = os.path.join(self.tmp, "keydoc_noval")
        write(os.path.join(pack, "survey", "demo_diagnostic.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "survey", "did_checklist.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "project_config.json"),
              json.dumps({"sessions": {}, "transport": {}}))
        write(os.path.join(pack, "27SecurityAccess秘钥.txt"), self.KEY_ALGO_DOC)
        mf = make_manifest(pack, [
            {"role": "diag_survey", "path": "survey/demo_diagnostic.xlsx"},
            {"role": "did_checklist", "path": "survey/did_checklist.xlsx"},
            {"role": "project_config", "path": "project_config.json"},
            {"role": "security_key_doc", "path": "27SecurityAccess秘钥.txt"},
        ])
        res = pv.validate_pack(mf)
        row = next(r for r in res["files"] if r["role"] == "security_key_doc")
        self.assertTrue(row["exists"])
        self.assertFalse(row["deep"]["keycheck"])  # 内容级：无实际密钥值
        mod = next(m for m in res["modules"] if "0x27" in m["module"])
        self.assertEqual(mod["state"], "BLOCKED")
        self.assertIn("未发现实际密钥值", mod["reason"])
        self.assertTrue(any("密钥" in a for a in res["next_actions"]))

    def test_keydoc_with_real_values_ok(self):
        """有真实密钥值 → keycheck=True，0x27 不因此 BLOCKED"""
        pack = os.path.join(self.tmp, "keydoc_val")
        write(os.path.join(pack, "survey", "demo_diagnostic.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "survey", "did_checklist.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "project_config.json"),
              json.dumps({"sessions": {}, "transport": {}}))
        write(os.path.join(pack, "sec", "27SecurityAccess.txt"),
              "AES_ctr_key_0102 = 2B7E151628AED2A6ABF7158809CF4F3C\n"
              "AES_cmac_key_0102 = 0F1571C947D9E8590CB7ADD6AF7F6798\n")
        mf = make_manifest(pack, [
            {"role": "diag_survey", "path": "survey/demo_diagnostic.xlsx"},
            {"role": "did_checklist", "path": "survey/did_checklist.xlsx"},
            {"role": "project_config", "path": "project_config.json"},
            {"role": "security_key_doc", "path": "sec/27SecurityAccess.txt"},
        ])
        res = pv.validate_pack(mf)
        row = next(r for r in res["files"] if r["role"] == "security_key_doc")
        self.assertTrue(row["deep"]["keycheck"])
        self.assertFalse(any("0x27" in m["module"] and m["state"] == "BLOCKED"
                             for m in res["modules"]))

    def test_keydoc_rsa_pubkey_flagged_not_confused(self):
        """JSON 里的 RSA 公钥（非对称）能被识别为密钥材料，但 msg 提示需核对是否 0x27 所需"""
        pack = os.path.join(self.tmp, "keydoc_rsa")
        rsa_json = json.dumps({"RSA_public_key_modulus":
                               "A77CB31DE85402FAB2E055483CFEC4A9626A0768C26470E8"})
        write(os.path.join(pack, "sec", "VolvoKey.json"), rsa_json)
        r = pv.deep_check_keydoc(os.path.join(pack, "sec", "VolvoKey.json"))
        self.assertTrue(r["keycheck"])
        self.assertIn("核对", r["msg"])

    def test_survey_deep_check_reaches_parser(self):
        """真 xlsx → 深度校验必须真正跑到解析器（回归 2026-09-04 两级上跳路径 bug：
        假字节测试里解析失败被"不阻断"吞掉，掩盖了解析器模块加载失败）"""
        import openpyxl
        pack = os.path.join(self.tmp, "survey_real")
        xlsx = os.path.join(pack, "survey", "demo_diagnostic.xlsx")
        write(xlsx, "dummy", "wb")
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["DID", "名称", "支持"])
        ws.append(["0xF12E", "零件号", "APP/PBL/SBL"])
        wb.save(xlsx)
        r = pv.deep_check(xlsx, "diag_survey")
        self.assertNotIn("深度校验异常", r["msg"])


    def test_declared_security_key_missing_action(self):
        pack = os.path.join(self.tmp, "key_missing")
        write(os.path.join(pack, "survey", "demo_diagnostic.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "survey", "did_checklist.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "project_config.json"),
              json.dumps({"sessions": {}, "transport": {}}))
        write(os.path.join(pack, "SWRS.txt"), SWRS_TXT)
        write(os.path.join(pack, "demo.ldf"), "LIN_description_file;")
        mf = make_manifest(pack, [
            {"role": "diag_survey", "path": "survey/demo_diagnostic.xlsx"},
            {"role": "did_checklist", "path": "survey/did_checklist.xlsx"},
            {"role": "project_config", "path": "project_config.json"},
            {"role": "swrs", "path": "SWRS.txt"},
            {"role": "ldf", "path": "demo.ldf"},
            {"role": "security_key_doc", "path": "sec/missing.docx"},
        ])
        res = pv.validate_pack(mf)
        self.assertTrue(any("0x27" in a for a in res["next_actions"]))

    def test_wrong_extension_does_not_count_as_present(self):
        pack = os.path.join(self.tmp, "wrong_type")
        write(os.path.join(pack, "survey", "demo_diagnostic.txt"), "not an xlsx")
        write(os.path.join(pack, "survey", "did_checklist.xlsx"), "dummy", "wb")
        write(os.path.join(pack, "project_config.json"),
              json.dumps({"sessions": {}, "transport": {}}))
        write(os.path.join(pack, "SWRS.txt"), SWRS_TXT)
        write(os.path.join(pack, "demo.ldf"), "LIN_description_file;")
        mf = make_manifest(pack, [
            {"role": "diag_survey", "path": "survey/demo_diagnostic.txt"},
            {"role": "did_checklist", "path": "survey/did_checklist.xlsx"},
            {"role": "project_config", "path": "project_config.json"},
            {"role": "swrs", "path": "SWRS.txt"},
            {"role": "ldf", "path": "demo.ldf"},
        ])
        res = pv.validate_pack(mf)
        row = next(r for r in res["files"] if r["role"] == "diag_survey")
        self.assertFalse(row["type_ok"])
        self.assertEqual(res["verdict"]["state"], "NOT_READY")
        self.assertIn("UDS 用例参数化设计", res["blocked_modules"])

    def test_path_escape_is_rejected_by_pack_reader(self):
        pack = os.path.join(self.tmp, "path_escape")
        mf = make_manifest(pack, [{"role": "other", "path": "../outside.txt"}])
        res = pv.validate_pack(mf, do_deep=False)
        row = res["files"][0]
        self.assertFalse(row["exists"])
        self.assertTrue(row["path_error"])
        self.assertEqual(res["verdict"]["state"], "NOT_READY")
        self.assertTrue(res["manifest_errors"])

    def test_declared_hash_mismatch_is_not_usable(self):
        pack = os.path.join(self.tmp, "hash_mismatch")
        path = os.path.join(pack, "survey", "demo_diagnostic.xlsx")
        write(path, b"not a real xlsx", "wb")
        mf = make_manifest(pack, [{
            "role": "diag_survey",
            "path": "survey/demo_diagnostic.xlsx",
            "sha256": "0" * 64,
        }])
        res = pv.validate_pack(mf, do_deep=False)
        row = res["files"][0]
        self.assertFalse(row["hash_ok"])
        self.assertIn("SHA-256 不匹配", res["verdict"]["reason"])
        self.assertEqual(res["verdict"]["state"], "NOT_READY")


if __name__ == "__main__":
    unittest.main()
