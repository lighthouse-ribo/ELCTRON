# -*- coding: utf-8 -*-
"""第十步：execution profile 与项目上下文绑定测试。"""

from __future__ import annotations

import hashlib
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1] / "uds-diagnostic-test" / "scripts"))

from execution_profile import ExecutionProfileError, validate_execution_profile
from testsupport import WorkspaceTempDir


class TestExecutionProfile(unittest.TestCase):
    def setUp(self):
        self.temp_dir = WorkspaceTempDir("execution-profile")
        self.addCleanup(self.temp_dir.cleanup)
        self.tmp = Path(self.temp_dir.name)
        self.context = self.tmp / "project_context.json"
        self.context.write_text('{"schema_version":"portable-contract/v0.1"}\n', encoding="utf-8")
        digest = hashlib.sha256(self.context.read_bytes()).hexdigest()
        self.profile = {
            "$schema": "portable-contract/v0.1",
            "schema_version": "portable-contract/v0.1",
            "profile_id": "test-local",
            "project_context": {"path": "project_context.json", "sha256": digest},
            "runtime": {"python": "C:/python.exe", "working_directory": "C:/workspace"},
            "transport": {"adapter": "vector", "channel": "0", "library_path": "C:/vxlapi64.dll"},
            "secure_key_references": [{
                "purpose": "UDS 0x27",
                "provider": "credential-store",
                "reference": "credential://test/uds-0x27",
                "material_in_context": False,
            }],
        }

    def test_profile_binds_to_context_hash(self):
        result = validate_execution_profile(self.profile, project_context_path=self.context)
        self.assertEqual(result["profile_id"], "test-local")
        self.assertEqual(result["secure_key_reference_count"], 1)
        self.assertNotIn("python", json.dumps(result))

    def test_context_hash_mismatch_is_blocked(self):
        self.profile["project_context"]["sha256"] = "0" * 64
        with self.assertRaises(ExecutionProfileError):
            validate_execution_profile(self.profile, project_context_path=self.context)

    def test_secret_material_is_blocked(self):
        self.profile["secure_key_references"][0]["key_value"] = "deadbeef"
        with self.assertRaises(ExecutionProfileError):
            validate_execution_profile(self.profile, project_context_path=self.context)

    def test_key_reference_must_not_claim_material(self):
        self.profile["secure_key_references"][0]["material_in_context"] = True
        with self.assertRaises(ExecutionProfileError):
            validate_execution_profile(self.profile, project_context_path=self.context)


if __name__ == "__main__":
    unittest.main(verbosity=2)
