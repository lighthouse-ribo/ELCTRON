#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用例生成后规则 lint —— 与生成器规则修复配套的独立校验门禁
=========================================================================
对 uds_req_matrix_generator / uds_full_matrix_generator 输出的用例 JSON
做规则级校验（生成器内部规则之外的“生成后检查”），FAIL 阻断交付。

规则参数来自项目配置的 ``lint``、``security``、``nrc`` 和 ``sessions``
节点。未传项目配置时仍使用历史 BBS 兼容默认值；项目可通过配置关闭
不适用规则、替换只读 DID、0x27 等级会话映射、非法子功能 NRC 和负例关键词。

退出码: 0=通过, 1=参数错误, 2=存在 FAIL（阻断交付）
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import sys
from typing import Any, Mapping

for _stream in (sys.stdout, sys.stderr):
    _reconfigure = getattr(_stream, "reconfigure", None)
    if _reconfigure:
        try:
            _reconfigure(encoding="utf-8", errors="replace")
        except (OSError, ValueError):
            pass


_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))

from project_config import canonical_did, load_project_config, parse_int  # noqa: E402


RULES = ("R1", "R2", "R3", "R4", "R5")


def parse_sa_session_map(
    text: str | None,
    default: Mapping[int, list[int]] | None = None,
    project_config: Mapping[str, Any] | str | None = None,
) -> dict[int, list[int]]:
    """解析 ``01:02,05:03``，支持一个等级对应多个会话。

    ``default`` 保留旧调用方的覆盖方式；未提供时从项目配置读取。空参数
    不会清空配置，而是返回配置中的完整映射，这样 CLI 不会意外恢复硬编码。
    """
    config = load_project_config(project_config)
    if default is None:
        configured = config.get("security", {}).get("level_to_sessions", {})
        out = {int(level): list(sessions) for level, sessions in configured.items()}
    else:
        out = {int(level): list(sessions) for level, sessions in default.items()}
    if not text:
        return out
    for pair in str(text).split(","):
        pair = pair.strip()
        if ":" not in pair:
            continue
        level_text, sessions_text = pair.split(":", 1)
        level = parse_int(level_text)
        sessions = []
        for value in re.split(r"[;|/]+", sessions_text):
            session = parse_int(value.strip())
            if session is not None:
                sessions.append(session)
        if level is not None and sessions:
            out[level] = list(dict.fromkeys(sessions))
    return out


def extract_did_from_procedure(proc: Any) -> str | None:
    """从 ``2E F1 2C + 数据`` 提取 DID（4 hex）。"""
    m = re.search(r"\b2E\s+([0-9A-Fa-f]{2})\s+([0-9A-Fa-f]{2})", str(proc or ""))
    return (m.group(1) + m.group(2)).upper() if m else None


def extract_sa_level(test_point: Any) -> int | None:
    """从 ``等级0x01``/``level 01`` 提取安全等级。"""
    text = str(test_point or "")
    m = re.search(r"(?:等级|level)\s*0?x?([0-9A-Fa-f]{2})", text, re.I)
    return int(m.group(1), 16) if m else None


def _session_labels(session_id: int, config: Mapping[str, Any]) -> tuple[str, ...]:
    names = config.get("sessions", {}).get("names", {})
    labels = {
        str(names.get(session_id, "")).strip(),
        f"0x{session_id:02X}",
        f"{session_id:02X}",
    }
    return tuple(label.lower() for label in labels if label)


def _session_declared(precondition: str, config: Mapping[str, Any]) -> bool:
    text = str(precondition or "").lower()
    if "会话" in text or "session" in text:
        return True
    return any(label in text for session_id in config.get("sessions", {}).get("supported", [])
               for label in _session_labels(session_id, config))


def _is_negative_text(text: str, keywords: list[str]) -> bool:
    return any(str(keyword) and str(keyword) in text for keyword in keywords)


def _explicit_nrc(text: str) -> bool:
    """只接受带具体值的 NRC，不把单独出现的“NRC”当成断言。"""
    return bool(
        re.search(r"NRC\s*(?:=|:|为|是)?\s*0?x?[0-9A-Fa-f]{2}\b", text, re.I)
        or re.search(r"\b7F\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\b", text, re.I)
    )


def _nrc_asserted(text: str, code: int, service_hex: str | None = None) -> bool:
    """判断文本是否给出具体 NRC，允许 ``NRC 0x33`` 等常见写法。"""
    if service_hex and re.search(
            rf"\b7F\s+{service_hex}\s+(?:0x)?{code:02X}\b", text, re.I):
        return True
    return bool(re.search(
        rf"NRC\s*(?:=|:|为|是)?\s*0?x?{code:02X}\b", text, re.I
    ))


def check_case(
    case: Mapping[str, Any],
    ro_dids: set[str] | None = None,
    sa_session_map: Mapping[int, list[int]] | None = None,
    project_config: Mapping[str, Any] | str | None = None,
) -> list[tuple[str, str, str]]:
    """单条用例规则校验，返回 ``[(rule, status, detail)]``。

    ``ro_dids``/``sa_session_map`` 为显式传入时优先于项目配置，保持旧 API
    兼容；传 ``None`` 才表示由配置决定。
    """
    config = load_project_config(project_config)
    lint_config = config.get("lint", {})
    configured_rules = lint_config.get("enabled_rules")
    enabled = set(RULES if configured_rules is None else configured_rules)
    cid = str(case.get("case_id", "?"))
    service_match = re.search(r"^UDS_(0x[0-9A-Fa-f]{2})", cid, re.I)
    service = service_match.group(1).lower() if service_match else ""
    tp = str(case.get("test_point", "") or "")
    proc = str(case.get("procedure", "") or "")
    exp = str(case.get("expected", "") or "")
    pre = str(case.get("precondition", "") or "")
    checks: list[tuple[str, str, str]] = []

    configured_ro = {
        canonical_did(value)
        for value in lint_config.get("read_only_dids", [])
        if canonical_did(value)
    }
    ro_dids = configured_ro if ro_dids is None else {
        canonical_did(value) for value in ro_dids if canonical_did(value)
    }
    sa_map = parse_sa_session_map("", project_config=config) if sa_session_map is None else {
        int(level): list(sessions) for level, sessions in sa_session_map.items()
    }
    negative_keywords = [str(value) for value in lint_config.get("negative_keywords", [])]
    negative = _is_negative_text(" ".join((tp, proc, exp)), negative_keywords)

    # R1: 0x2E 写入正例不得含只读 DID。
    if "R1" in enabled and service == "0x2e" and "正向" in tp and "写入" in tp:
        did = extract_did_from_procedure(proc)
        if did and did in ro_dids:
            checks.append(("R1", "FAIL", f"{cid}: 只读 DID {did} 生成了 0x2E 写入正例"))
        else:
            checks.append(("R1", "PASS", f"{cid}: 写入正例 DID={did or '?'} 不在只读列表"))

    # R2: 0x27 等级会话归属。
    if "R2" in enabled and service == "0x27" and "正向" in tp:
        level = extract_sa_level(tp)
        if level is not None:
            allowed = sa_map.get(level)
            if allowed is None:
                allowed = config.get("security", {}).get("default_level_sessions", [])
            labels = tuple(
                label for session_id in allowed
                for label in _session_labels(int(session_id), config)
            )
            if any(label in pre.lower() for label in labels):
                checks.append(("R2", "PASS", f"{cid}: 等级0x{level:02X} 前置会话匹配配置"))
            else:
                display = [config.get("sessions", {}).get("names", {}).get(int(session_id),
                           f"0x{int(session_id):02X}") for session_id in allowed]
                checks.append(("R2", "FAIL", f"{cid}: 等级0x{level:02X} 正例前置缺少允许会话 {display}"))

    # R3: 非法子功能 NRC 来自 nrc.illegal_subfunction；按服务逐项校验，
    # 不把 0x11/0x12 当成所有项目和所有服务的固定结论。
    illegal_map = config.get("nrc", {}).get("illegal_subfunction", {})
    service_match = re.search(r"UDS_(0x[0-9A-Fa-f]{2})", cid, re.I)
    service = service_match.group(1).lower() if service_match else ""
    illegal_nrc = illegal_map.get(service)
    illegal_subfunction_markers = ("非法子功能", "illegal subfunction", "invalid subfunction")
    if ("R3" in enabled and illegal_nrc is not None
            and any(marker.lower() in " ".join((tp, proc, exp)).lower()
                    for marker in illegal_subfunction_markers)):
        code = int(illegal_nrc) & 0xFF
        service_hex = service[2:].upper()
        if _nrc_asserted(exp, code, service_hex):
            checks.append(("R3", "PASS", f"{cid}: 非法子功能 NRC=0x{code:02X}"))
        else:
            checks.append(("R3", "FAIL", f"{cid}: 非法子功能负例未断言 NRC=0x{code:02X}"))

    # R4: 负例必须断言具体 NRC，可通过配置关闭。
    if "R4" in enabled and negative and lint_config.get("require_nrc_for_negative", True):
        if _explicit_nrc(exp):
            checks.append(("R4", "PASS", f"{cid}: 负例断言了具体 NRC"))
        else:
            checks.append(("R4", "FAIL", f"{cid}: 负例未断言具体 NRC（expected: {exp[:60]}）"))

    # R5: 0x27 相关用例必须声明会话前置，可通过配置关闭。
    if ("R5" in enabled and service == "0x27"
            and lint_config.get("require_session_for_security", True)):
        if _session_declared(pre, config):
            checks.append(("R5", "PASS", f"{cid}: 声明了项目配置中的会话前置"))
        else:
            checks.append(("R5", "FAIL", f"{cid}: 0x27 用例前置缺会话声明（precondition: {pre[:60]}）"))

    return checks


def lint(
    cases: list[Mapping[str, Any]],
    ro_dids: set[str] | None = None,
    sa_session_map: Mapping[int, list[int]] | None = None,
    project_config: Mapping[str, Any] | str | None = None,
) -> tuple[list[tuple[str, str, str]], dict[str, int]]:
    results: list[tuple[str, str, str]] = []
    for case in cases:
        results.extend(check_case(case, ro_dids, sa_session_map, project_config))
    summary = {rule: 0 for rule in RULES}
    for rule, status, _detail in results:
        if status == "FAIL":
            summary[rule] += 1
    return results, summary


def render_markdown(results, summary, path):
    lines = ["# 用例规则 lint 报告\n", "| 规则 | 检查数 | FAIL |", "|---|---|---|"]
    for rule in RULES:
        count = sum(1 for item_rule, _status, _detail in results if item_rule == rule)
        lines.append(f"| {rule} | {count} | {summary.get(rule, 0)} |")
    failures = [detail for _rule, status, detail in results if status == "FAIL"]
    lines.append("")
    if failures:
        lines.append("## FAIL 明细")
        lines.extend(f"- {failure}" for failure in failures)
    else:
        lines.append("无 FAIL，全部通过。")
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description="用例生成后规则 lint（R1~R5）")
    parser.add_argument("--cases", "-c", required=True, help="用例 JSON（case-schema 格式）")
    parser.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    parser.add_argument("--ro-dids", default=None, help="显式覆盖只读 DID 列表（逗号分隔）")
    parser.add_argument("--sa-session-map", default="", help="显式覆盖 0x27 等级会话映射，如 01:02,05:03")
    parser.add_argument("--disable-rule", action="append", default=[],
                        help="关闭配置中的一条规则，可重复指定，如 --disable-rule R5")
    parser.add_argument("--out", "-o", help="Markdown 报告输出路径（可选）")
    args = parser.parse_args()

    if not os.path.exists(args.cases):
        print(f"[ERROR] 用例文件不存在: {args.cases}")
        sys.exit(1)
    try:
        config = load_project_config(args.project_config or None)
        with open(args.cases, encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, ValueError, TypeError) as exc:
        print(f"[ERROR] 输入或项目配置读取失败: {exc}")
        sys.exit(1)
    cases = data if isinstance(data, list) else data.get("cases", []) if isinstance(data, dict) else []
    if not isinstance(cases, list):
        print("[ERROR] 用例 JSON 必须是数组或包含 cases 数组")
        sys.exit(1)
    ro_dids = None
    if args.ro_dids is not None:
        ro_dids = {canonical_did(value) for value in args.ro_dids.split(",") if canonical_did(value)}
    sa_map = parse_sa_session_map(args.sa_session_map, project_config=config)
    if args.disable_rule:
        config = json.loads(json.dumps(config))
        configured_rules = config.get("lint", {}).get("enabled_rules")
        enabled = set(RULES if configured_rules is None else configured_rules)
        enabled.difference_update(str(rule).upper() for rule in args.disable_rule)
        config.setdefault("lint", {})["enabled_rules"] = sorted(enabled)

    results, summary = lint(cases, ro_dids, sa_map, config)
    total_fail = sum(summary.values())
    print(f"[INFO] 检查 {len(cases)} 条用例，规则检查 {len(results)} 项，FAIL {total_fail} 项")
    for rule in RULES:
        if summary.get(rule):
            print(f"  ❌ {rule}: {summary[rule]} 项")
    for _rule, status, detail in results:
        if status == "FAIL":
            print(f"  - {detail}")
    if args.out:
        render_markdown(results, summary, args.out)
        print(f"[INFO] 报告: {args.out}")
    if total_fail:
        print("[WARN] 存在规则 FAIL，阻断交付（修复用例或调整项目配置后重跑）")
        sys.exit(2)
    print("[OK] 全部规则通过")
    sys.exit(0)


if __name__ == "__main__":
    main()
