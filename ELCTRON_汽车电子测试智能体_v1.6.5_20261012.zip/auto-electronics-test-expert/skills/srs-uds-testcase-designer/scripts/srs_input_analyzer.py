# -*- coding: utf-8 -*-
"""
srs_input_analyzer.py — SRS 输入体检脚本

用途：在设计 UDS 测试用例之前，先"体检"一份 SRS 系统需求规范文档，
回答三个问题：
  1. 这份 SRS 里已经给了哪些可用的诊断信息（章节 / DID / 诊断帧 / 服务）？
  2. 它引用了哪些外部配套文件（诊断调查表 / 刷写流程图 / 安全需求清单）？
  3. 仅凭这份 SRS，能否生成"可验证"的合格用例？缺什么？

支持输入：
  - .docx（明文 OpenXML，python-docx 解析）
  - .pdf（明文/普通加密，fitz 解析；%TSD-Header 深层加密 → 提示先走 srs-doc-extract）
  - .txt / .md（明文）
  - 其他类型报错并给出建议

用法：
  python srs_input_analyzer.py "<SRS文件>" [--out report.json] [--report report.md]
  （不带参数时输出到 stdout，人类可读 + 末尾 JSON）

输出：
  - input_summary  文档基本情况
  - discovered     已发现的诊断信息（章节/DID/诊断帧/服务）
  - external_refs  引用的外部文件清单
  - gaps           缺失项（含建议来源）
  - verdict        结论：能否仅凭本文档生成用例 + 建议

依赖：python-docx（docx）、PyMuPDF/fitz（pdf）、标准库（txt）。
"""

import sys
import os
import re
import json
import argparse

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# ---------- 诊断关键词表（用于命中统计） ----------
DIAG_KEYWORDS = {
    "UDS": ["UDS", "unified diagnostic"],
    "Diagnostic": ["diagnostic", "Diagnostic"],
    "LIN": ["LIN", "lin bus"],
    "DID": ["DID", "data identifier"],
    "DTC": ["DTC", "trouble code"],
    "Session": ["session", "Session"],
    "SecurityAccess": ["security access", "SecurityAccess", "seed", "key"],
    "NRC": ["NRC", "negative response", "0x7F"],
    "Download": ["download", "Download", "flash", "reprogram"],
    "Timing": ["P2Server", "S3Server", "P2", "STmin", "timeout"],
}

FRAME_RE = re.compile(r"(?:0x3C\s*[:：]\s*)?([0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2}){4,9})")
DID_RE = re.compile(r"\b(?:0x)?F1[0-9A-F]{2}\b|\b(?:0x)?F1[0-9A-F]{2}(?!\w)", re.I)
SERVICE_RE = re.compile(r"0x(10|11|14|19|22|23|27|28|2E|31|34|36|37|3E|85)\b", re.I)
EXTFILE_RE = re.compile(
    r"([A-Za-z0-9_][A-Za-z0-9_\-\. ]{4,100}\.(?:xlsx|xls|docx|doc|pdf|pptx|ppt|vsdx|png|jpg|html|htm|sws))",
    re.I,
)
REFER_RE = re.compile(
    r"(?:refer(?:s|ring|ence)?\s+(?:to|ence)|see\s+(?:also\s+)?|see\s+the|in\s+accordance\s+with|based\s+on)"
    r"\s*(?:the\s+)?(?:document|section|file|flowchart|flow\s+chart|appendix|annex)?\s*[:：]?\s*"
    r"([A-Za-z0-9_\-][A-Za-z0-9_\-\. ]{3,90})",
    re.I,
)

# UDS 服务 SID 名称表（用于把帧里的 SID 翻译成人话）
SID_NAMES = {
    0x10: "DiagnosticSessionControl", 0x11: "ECUReset", 0x14: "ClearDTC",
    0x19: "ReadDTC", 0x22: "ReadDataByID", 0x23: "ReadMemByAddr",
    0x27: "SecurityAccess", 0x28: "CommControl", 0x2E: "WriteDataByID",
    0x31: "RoutineControl", 0x34: "RequestDownload", 0x36: "TransferData",
    0x37: "RequestExitTransfer", 0x3E: "TesterPresent", 0x85: "ControlDTCSetting",
}


def log(msg):
    print(msg)


# ---------- 各格式解析器 ----------
def parse_docx(path):
    """返回 (text, headings, extra)。docx 用 python-docx。"""
    try:
        import docx
    except ImportError:
        sys.exit("[ERROR] 解析 docx 需要 python-docx，请安装：pip install python-docx")
    d = docx.Document(path)
    paras = d.paragraphs
    lines = []
    headings = []
    for p in paras:
        t = p.text.strip()
        if not t:
            continue
        lines.append(t)
        st = (p.style.name or "") if p.style else ""
        if "heading" in st.lower():
            headings.append(t)
    # 表格内容也要纳入（需求常放在表格里）
    table_texts = []
    for tb in d.tables:
        for row in tb.rows:
            cells = [c.text.strip() for c in row.cells]
            if any(cells):
                table_texts.append(" | ".join(cells))
    text = "\n".join(lines + table_texts)
    return text, headings, {"paras": len(paras), "tables": len(d.tables)}


def parse_pdf(path):
    """返回 (text, headings, extra)。明文/普通加密 PDF 用 fitz。"""
    raw_head = open(path, "rb").read(32)
    if raw_head.startswith(b"%TSD-Header"):
        sys.exit(
            "[ERROR] 该 PDF 是 DLP 深层加密文件（%TSD-Header）。\n"
            "  请先走 srs-doc-extract 技能解密为明文 txt 后再传入本脚本。"
        )
    try:
        import fitz
    except ImportError:
        sys.exit("[ERROR] 解析 PDF 需要 PyMuPDF，请安装：pip install PyMuPDF")
    doc = fitz.open(path)
    if doc.is_encrypted:
        try:
            doc.authenticate("")
        except Exception:
            sys.exit("[ERROR] PDF 带密码且空密码无法打开，请提供无密码副本。")
    texts = []
    for page in doc:
        texts.append(page.get_text())
    text = "\n".join(texts)
    headings = [
        l for l in text.splitlines()
        if re.match(r"^\s*\d+\.\d+(\.\d+)*\s+\S", l.strip())
    ][:200]
    return text, headings, {"pages": len(doc)}


def parse_txt(path):
    """返回 (text, headings, extra)。txt/md 直接读。"""
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    headings = [
        l for l in text.splitlines()
        if re.match(r"^\s*\d+\.\d+(\.\d+)*\s+\S", l.strip())
    ][:200]
    return text, headings, {"chars": len(text)}


def parse_file(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".docx":
        return parse_docx(path), "docx"
    if ext == ".pdf":
        return parse_pdf(path), "pdf"
    if ext in (".txt", ".md"):
        return parse_txt(path), "txt"
    sys.exit(f"[ERROR] 不支持的文件类型 {ext}。支持：.docx / .pdf / .txt / .md\n"
             f"  若是加密 PDF，请先走 srs-doc-extract 解密。")


# ---------- 分析 ----------
def analyze(text, headings, extra):
    hits = {}
    for k, kws in DIAG_KEYWORDS.items():
        hits[k] = sum(text.lower().count(kw.lower()) for kw in kws)

    # 收集诊断帧（含 SID/DID 提取）
    frames = []
    dids = []
    services = set()
    for m in FRAME_RE.finditer(text):
        frame_hex = re.sub(r"[^0-9A-Fa-f]", "", m.group(1))
        if len(frame_hex) < 10:
            continue
        frame = " ".join(frame_hex[i : i + 2] for i in range(0, len(frame_hex), 2))
        if frame not in frames:
            frames.append(frame)
        # 提取服务 SID（首字节）
        sid = int(frame_hex[0:2], 16)
        if sid in SID_NAMES:
            services.add(sid)
        # 0x22/0x2E 后跟 DID（2 字节）
        if sid in (0x22, 0x2E) and len(frame_hex) >= 8:
            did = frame_hex[4:8].upper()
            if did not in dids and re.match(r"^[0-9A-F]{4}$", did):
                dids.append(did)
    # 补充：直接搜 F1xx 形态 DID
    for m in DID_RE.finditer(text):
        d = re.sub(r"[^0-9A-Fa-f]", "", m.group(0)).upper()
        d = d[2:] if d.startswith("0X") or d[:2] in ("F1",) else d
        d = d[-4:] if len(d) >= 4 else d
        if len(d) == 4 and d not in dids:
            dids.append(d)
    for m in SERVICE_RE.finditer(text):
        services.add(int(m.group(1), 16))

    # 外部引用：分为「外部文件」(带扩展名) / 「章节引用」(纯数字) / 「其他引用」(文本)
    ext_files = []
    section_refs = []
    other_refs = []
    NOISE = {
        "internal trigger", "external trigger", "detection requirements",
        "application parameters", "predefined procedure", "manufacturing",
        "operation parameters", "test conditions", "for r163 part i",
        "system", "the ecu", "section", "document", "appendix", "annex",
        "service and aftermarket", "others", "general", "overview",
    }
    for m in EXTFILE_RE.finditer(text):
        fname = m.group(1).strip()
        if fname not in ext_files:
            ext_files.append(fname)
    for m in REFER_RE.finditer(text):
        ref = m.group(1).strip()
        ref = re.sub(r"^(?:the|a|an|see|to)\s+", "", ref, flags=re.I).strip()
        low = ref.lower()
        if not ref or len(ref) < 4 or low in NOISE:
            continue
        if re.fullmatch(r"\d+(?:\.\d+)+", ref):
            if ref not in section_refs:
                section_refs.append(ref)
        elif re.search(r"\.(xlsx|xls|docx|doc|pdf|pptx|ppt|vsdx|png|jpg|html|htm)$", low):
            if ref not in ext_files:
                ext_files.append(ref)
        else:
            if ref not in other_refs:
                other_refs.append(ref)

    # 判断缺口
    gaps = []
    requirement_ids = list(dict.fromkeys(
        match.upper() for match in re.findall(r"\bREQ-[A-Za-z0-9][A-Za-z0-9._-]{0,79}\b", text, re.I)))[:4096]
    has_req_id = bool(requirement_ids)
    has_nrc = bool(re.search(r"NRC|negative response|0x7F", text, re.I))
    has_session = bool(re.search(r"session|0x10", text, re.I))
    has_security = bool(re.search(r"security access|seed|0x27", text, re.I))
    if not has_req_id:
        gaps.append({
            "item": "SRS 无 REQ 编号",
            "impact": "用例无法直接追溯需求条目",
            "source": "自动兜底：按「章节号+功能名」生成 REQ-<章节>.<序号> 追溯 ID",
            "required": False,
        })
    if not has_nrc:
        gaps.append({
            "item": "无 NRC/负响应约束",
            "impact": "负例用例的预期结果无法断言",
            "source": "诊断调查表 / 主机厂诊断规范 / ISO 14229 内置速查表",
            "required": True,
        })
    if not has_session:
        gaps.append({
            "item": "无会话管理信息（0x10/0x3E）",
            "impact": "前置条件（会话状态）无法确定",
            "source": "诊断调查表 / 主机厂诊断规范",
            "required": True,
        })
    if not has_security:
        gaps.append({
            "item": "无安全访问信息（0x27）",
            "impact": "受保护服务（写/例程/刷写）前置条件缺失",
            "source": "SWRS-BT-Cybersecurity-REQ-LIST.xlsx 等安全需求文档",
            "required": False,
        })
    # 0x27 密钥/算法资料缺失：文本提到安全访问但无密钥来源时，正例将无法执行（占位 0xFF 不算有效）
    has_key_source = bool(re.search(r"cmac|ctr|aes|seed.?key|密钥值|proofofownership|encryptionauthentication",
                                    text, re.I))
    if has_security and not has_key_source:
        gaps.append({
            "item": "0x27 密钥/算法资料缺失（SeedKey 算法或密钥来源）",
            "impact": "0x27 正例无法执行、受保护服务（0x2E/0x31/刷写）前置解锁被阻塞",
            "source": "Cybersecurity REQ LIST / 27SecurityAccess.docx（Gen2 算法 + 真实密钥；全 0xFF 占位不算有效）",
            "required": False,
            "exec_blocking": True,
        })

    # 配套文件核对：输入依赖矩阵落库（文本引用/服务暗示 -> 需要用户提供）
    low = text.lower()
    services_set = {s for s in services}
    companion_defs = [
        {"name": "诊断调查表（DID/DTC/Routine 定义）", "needed": True,
         "detected": bool(re.search(r"diagnostic (survey|table)|调查表|诊断调查", low)),
         "reason": "DID/NRC/会话/安全权限的权威来源"},
        {"name": "Cybersecurity REQ LIST / 27SecurityAccess（SeedKey 算法与密钥）",
         "needed": (0x27 in services_set) or has_security,
         "detected": bool(re.search(r"cybersecurity|security.?access|27securityaccess|seed|密钥", low)),
         "reason": "0x27 正例与受保护服务解锁的密钥来源"},
        {"name": "SoftwareDownload FlowChart（刷写流程图）",
         "needed": bool({0x34, 0x36, 0x37} & services_set) or "software download" in low or "刷写" in low or "flow chart" in low,
         "detected": bool(re.search(r"software.?download|flow.?chart|刷写流程", low)),
         "reason": "0x34/0x36/0x37 刷写时序与流程细节"},
        {"name": "LIN Matrix / 通信矩阵",
         "needed": "lin" in low or "0x3c" in low or "调度表" in low,
         "detected": bool(re.search(r"lin.?matrix|通信矩阵|调度表|\blin\b", low)),
         "reason": "LIN 帧 ID/调度表/信号位定义"},
        {"name": "CDD 诊断文件（CANdela）",
         "needed": not bool(re.search(r"\blin\b|0x3c", low)),
         "detected": ".cdd" in low or "candela" in low,
         "reason": "DID/信号级定义自动提取（替代手工调查表）"},
        {"name": "DBC 通信矩阵（CAN 数据库）",
         "needed": bool(re.search(r"\bcan\b|0x7e0|0x7e8", low)),
         "detected": ".dbc" in low,
         "reason": "报文/信号编解码（报文级步骤生成）"},
    ]
    companion = []
    for c in companion_defs:
        if c["needed"] and c["detected"]:
            status = "已引用，需确认提供"
        elif c["needed"]:
            status = "建议提供（文本未引用但服务/对象暗示需要）"
        else:
            status = "本次不需要"
        companion.append({
            "name": c["name"], "needed": c["needed"],
            "referenced_in_srs": c["detected"], "reason": c["reason"], "status": status,
        })

    # 结论
    diag_info_ok = len(dids) > 0 or len(frames) > 0 or len(services) > 0
    ext_count = len(ext_files) + len(other_refs)
    if not diag_info_ok:
        verdict = {
            "can_generate": False,
            "reason": "SRS 中未发现可用的诊断信息（无 DID/诊断帧/服务），仅凭本文档无法设计 UDS 用例",
            "recommendation": "请提供诊断调查表（DID/DTC/Routine 定义）或主机厂诊断规范作为主输入",
        }
    elif ext_count >= 2 and len(gaps) >= 2:
        verdict = {
            "can_generate": "partial",
            "reason": f"SRS 提供了部分诊断信息，但引用了 {ext_count} 个外部文件/章节且关键约束缺失，直接生成用例可能无法落到脚本执行",
            "recommendation": "先补齐以下配套文件，再进入用例设计：" + "；".join(
                f"{g['item']}（{g['source']}）" for g in gaps
            ),
        }
    else:
        verdict = {
            "can_generate": True,
            "reason": "SRS 提供了足够的诊断信息，可直接进入用例设计",
            "recommendation": "对照 gaps 补充可选项后生成用例，并在 SKILL.md 输入依赖矩阵中记录本文档",
        }

    return {
        "keyword_hits": hits,
        "headings": headings,
        "frames": frames,
        "dids": dids,
        "services": sorted(services),
        "ext_files": ext_files,
        "section_refs": section_refs,
        "other_refs": other_refs,
        "has_req_id": has_req_id,
        "requirement_ids": requirement_ids,
        "has_nrc": has_nrc,
        "has_session": has_session,
        "has_security": has_security,
        "gaps": gaps,
        "companion_check": companion,
        "verdict": verdict,
    }


def build_report(path, parse_info, atype, analysis):
    text, headings, extra = parse_info
    rep = {
        "input_summary": {
            "path": path,
            "type": atype,
            "size_kb": round(os.path.getsize(path) / 1024, 1),
            **extra,
        },
        "discovered": {
            "headings": analysis["headings"][:60],
            "dids": analysis["dids"],
            "requirement_ids": analysis["requirement_ids"],
            "diagnostic_frames": analysis["frames"][:30],
            "services": [
                {"sid": hex(s), "name": SID_NAMES.get(s, "?")}
                for s in analysis["services"]
            ],
            "keyword_hits": {
                k: v for k, v in analysis["keyword_hits"].items() if v > 0
            },
        },
        "external_refs": {
            "files": analysis["ext_files"],
            "sections": analysis["section_refs"],
            "others": analysis["other_refs"],
        },
        "gaps": analysis["gaps"],
        "companion_check": analysis.get("companion_check", []),
        "verdict": analysis["verdict"],
    }
    return rep


def render_markdown(rep, path):
    L = []
    L.append(f"# SRS 输入体检报告：{os.path.basename(path)}\n")
    s = rep["input_summary"]
    L.append(f"- 类型：{s['type']} ｜ 大小：{s['size_kb']} KB")
    if "pages" in s:
        L.append(f"- 页数：{s['pages']}")
    if "paras" in s:
        L.append(f"- 段落：{s['paras']} ｜ 表格：{s['tables']}")
    if "chars" in s:
        L.append(f"- 字符数：{s['chars']}")
    L.append("")
    d = rep["discovered"]
    L.append("## 已发现的诊断信息")
    L.append(f"- 章节结构：{len(d['headings'])} 个编号标题，含：")
    for h in d["headings"][:12]:
        L.append(f"  - {h}")
    if d["dids"]:
        L.append(f"- DID：{', '.join('0x' + x for x in d['dids'])}")
    if d["diagnostic_frames"]:
        L.append("- 诊断帧样例：")
        for f in d["diagnostic_frames"][:8]:
            L.append(f"  - `{f}`")
    if d["services"]:
        svc_str = ", ".join(f"{x['sid']} {x['name']}" for x in d["services"])
        L.append(f"- 服务：{svc_str}")
    if d["keyword_hits"]:
        L.append(f"- 关键词命中：{', '.join(f'{k}={v}' for k, v in d['keyword_hits'].items())}")
    L.append("")
    L.append("## 引用的外部文件")
    er = rep["external_refs"]
    if er["files"]:
        for f in er["files"]:
            L.append(f"- {f}")
    else:
        L.append("- 未发现外部文件引用")
    if er["sections"]:
        L.append(f"- 章节引用：{', '.join(er['sections'][:15])}")
    if er["others"]:
        L.append(f"- 其他引用：{', '.join(er['others'][:10])}")
    L.append("")
    L.append("## 配套文件核对（输入依赖矩阵）")
    L.append("| 配套文件 | 本次是否需要 | 文本是否引用 | 状态 | 用途 |")
    L.append("|---|---|---|---|---|")
    for c in rep.get("companion_check", []):
        need = "是" if c["needed"] else "否"
        ref = "是" if c["referenced_in_srs"] else "否"
        L.append(f"| {c['name']} | {need} | {ref} | {c['status']} | {c['reason']} |")
    L.append("")
    L.append("## 缺口与建议来源")
    if rep["gaps"]:
        for g in rep["gaps"]:
            tag = "执行阻塞" if g.get("exec_blocking") else ("必需" if g["required"] else "可选")
            L.append(f"- [{tag}] **{g['item']}**：{g['impact']} → 来源：{g['source']}")
    else:
        L.append("- 无关键缺口")
    L.append("")
    v = rep["verdict"]
    L.append("## 结论")
    L.append(f"- **能否仅凭本文档生成合格用例：{v['can_generate']}**")
    L.append(f"- 原因：{v['reason']}")
    L.append(f"- 建议：{v['recommendation']}")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="SRS 输入体检：判断能否生成合格 UDS 用例、缺什么")
    ap.add_argument("input", help="SRS 文件路径（.docx/.pdf/.txt/.md）")
    ap.add_argument("--out", help="输出 JSON 报告路径（可选）")
    ap.add_argument("--report", help="输出 Markdown 报告路径（可选）")
    args = ap.parse_args()

    if not os.path.exists(args.input):
        sys.exit(f"[ERROR] 文件不存在: {args.input}")

    log(f"[1/3] 解析文档: {args.input}")
    parse_info, atype = parse_file(args.input)
    text, headings, extra = parse_info
    log(f"      → 段落/页数: {extra}")

    log("[2/3] 扫描诊断信息与外部引用 ...")
    analysis = analyze(text, headings, extra)

    log("[3/3] 汇总报告")
    rep = build_report(args.input, parse_info, atype, analysis)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(rep, f, ensure_ascii=False, indent=2)
        log(f"      → JSON 已写入: {args.out}")
    if args.report:
        md = render_markdown(rep, args.input)
        with open(args.report, "w", encoding="utf-8") as f:
            f.write(md)
        log(f"      → Markdown 已写入: {args.report}")

    # stdout 始终打印人类可读摘要
    print("\n" + render_markdown(rep, args.input))
    print("\n===== RAW JSON =====")
    print(json.dumps(rep, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
