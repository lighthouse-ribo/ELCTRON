# -*- coding: utf-8 -*-
"""Tests for the unified portable project context builder."""

from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "uds-diagnostic-test" / "scripts"))
from project_context_builder import build_context_from_manifest  # noqa: E402
from input_pack_validator import validate_project_context  # noqa: E402


def write_file(path: Path, data: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding="utf-8")
    return hashlib.sha256(path.read_bytes()).hexdigest()


class TestProjectContextBuilder(unittest.TestCase):
    def make_pack(self):
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        root = Path(temp_dir.name)
        survey = '{"dids":[{"did_number":"F190"}],"io_controls":[],"routines":[],"dtcs":[],"defaults_used":[],"missing_attributes":[]}'
        survey_rel = "diagnostic/APP/survey.json"
        survey_sha = write_file(root / survey_rel, survey)
        matrix_rel = "shared/communication/matrix.xlsx"
        matrix_sha = write_file(root / matrix_rel, "placeholder")
        manifest = {
            "$schema": "portable-contract/v0.1",
            "schema_version": "portable-contract/v0.1",
            "project": {"id": "portable-test", "bus": "LIN"},
            "partitions": ["APP", "PBL", "SBL", "shared"],
            "files": [
                {"id": "survey-app", "role": "diag_survey", "path": survey_rel, "partition": "APP", "sha256": survey_sha, "sensitivity": "internal", "authority": "project"},
                {"id": "lin-matrix", "role": "lin_matrix", "path": matrix_rel, "partition": "shared", "sha256": matrix_sha, "sensitivity": "internal", "authority": "project"},
            ],
        }
        manifest_path = root / "input_manifest.json"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
        return root, manifest_path

    def test_context_merges_facts_and_gaps_without_raw_parser_objects(self):
        root, manifest_path = self.make_pack()
        base = {
            "project": {"owner": "test"},
            "facts": [{
                "id": "transport.physical_nad", "partition": "shared", "value": "0x51",
                "status": "confirmed", "source": {"file_id": "lin-matrix", "locator": "LIN Matrix / NAD"},
            }],
            "gaps": [{"id": "execution_profile", "status": "pending", "required_for": ["hardware_execution"]}],
            "policy": {"selected_snippets_max_chars": 1200},
        }
        (root / "base_context.json").write_text(json.dumps(base, ensure_ascii=False), encoding="utf-8")

        context = build_context_from_manifest(manifest_path, base_context_path=root / "base_context.json")
        facts = {fact["id"]: fact for fact in context["facts"]}
        gaps = {gap["id"]: gap for gap in context["gaps"]}

        self.assertEqual(context["schema_version"], "portable-contract/v0.1")
        self.assertEqual(context["project"]["owner"], "test")
        self.assertEqual(facts["transport.physical_nad"]["status"], "confirmed")
        self.assertEqual(facts["diagnostic.APP.survey-app.did_count"]["value"], 1)
        self.assertEqual(facts["parser.shared.lin-matrix.status"]["status"], "pending")
        self.assertIsNone(facts["parser.shared.lin-matrix.status"]["value"])
        self.assertIn("parser.shared.lin-matrix.status", gaps)
        self.assertIn("execution_profile", gaps)
        self.assertNotIn('"dids":', json.dumps(context, ensure_ascii=False))
        self.assertEqual(len(context["facts"]), len(facts))
        self.assertEqual(len(context["partitions"]), 4)
        self.assertRegex(context["manifest"]["sha256"], r"^[0-9a-f]{64}$")

        (root / "project_context.json").write_text(json.dumps(context, ensure_ascii=False), encoding="utf-8")
        validation = validate_project_context(str(root), json.loads(manifest_path.read_text(encoding="utf-8")))
        self.assertTrue(validation["ok"], validation["errors"])

    def test_rebuild_is_idempotent_and_refreshes_derived_facts(self):
        root, manifest_path = self.make_pack()
        first = build_context_from_manifest(manifest_path)
        first_path = root / "first_context.json"
        first_path.write_text(json.dumps(first, ensure_ascii=False), encoding="utf-8")
        second = build_context_from_manifest(manifest_path, base_context_path=first_path)

        self.assertEqual(first["facts"], second["facts"])
        self.assertEqual(first["gaps"], second["gaps"])
        self.assertEqual(len({fact["id"] for fact in second["facts"]}), len(second["facts"]))

    def test_confirmed_fact_wins_and_conflict_is_recorded(self):
        root, manifest_path = self.make_pack()
        base = {
            "facts": [{
                "id": "diagnostic.APP.survey-app.did_count", "partition": "APP", "value": 99,
                "status": "confirmed", "source": {"file_id": "survey-app", "locator": "manual"},
            }],
        }
        base_path = root / "base_context.json"
        base_path.write_text(json.dumps(base), encoding="utf-8")
        context = build_context_from_manifest(manifest_path, base_context_path=base_path)

        fact = next(item for item in context["facts"] if item["id"] == "diagnostic.APP.survey-app.did_count")
        self.assertEqual(fact["value"], 99)
        self.assertEqual(context["conflicts"][0]["fact_id"], fact["id"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
