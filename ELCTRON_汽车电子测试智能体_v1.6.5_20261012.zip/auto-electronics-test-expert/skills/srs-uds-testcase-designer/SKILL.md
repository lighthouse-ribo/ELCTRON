---
name: srs-uds-testcase-designer
agent_created: true
description: "读取 SRS 系统需求规范文档（加密 PDF、明文 PDF、docx、txt），先做「输入体检」（srs_input_analyzer.py：自动提取章节/DID/诊断帧/外部文件引用，判断仅凭本文档能否生成合格用例、缺什么配套文件），再做「全文精读」（srs_focus_extractor.py：章节骨架→相关性聚焦→结构化事实抽取→高分章节裁剪，全部带页码证据，避免 LLM 通读大文档导致信息损耗），再按精读排序定位 UDS 相关章节（典型 4.1.6~4.1.9 或 DiagcForSlaveNodBBS/UDS on LIN 等），按汽车电子资深测试工程师视角做需求分析，设计系统级 UDS 测试用例（正例/负例/边界/时序/安全/恢复），输出符合用户模板（需求来源/需求ID/用例ID/优先级/前提条件/操作步骤/预期结果等 19 列）的 xlsx 测试用例表，并可桥接 uds-diagnostic-test 生成执行脚本。支持「输入文件包」manifest（input_pack_validator.py 一键校验齐备度，可移植）。当用户要求基于 SRS/SWRS 需求文档设计 UDS 诊断测试用例、或对加密需求文档做测试设计时使用本技能。输入支持：加密 PDF（自动走 srs-doc-extract 解密）、明文 PDF/txt、docx。"
read_when:
  - 基于 SRS/SWRS 需求文档设计 UDS 诊断测试用例
  - 用户给出 NOTE-SWRS/需求规范文档（PDF/docx，可能加密），要求做 UDS 需求分析和测试设计
  - 需要先判断一份 SRS 能否生成用例、缺哪些配套文件（诊断调查表/LIN矩阵/刷写流程图等）
  - 需要按汽车电子资深测试工程师视角生成系统合格性测试用例（正例/负例/边界/时序/安全）
  - 需要把测试用例输出为符合公司模板的 xlsx（需求ID/用例ID/优先级/步骤/预期结果等列）
---

# SRS 需求分析 + UDS 测试用例设计

## 触发场景

用户提供 SRS 系统需求规范文档（如 Volvo NOTE-SWRS_BASETECH 系列 418 页加密 PDF，或 BBS_P519_V436_System Requirement_V3.1 docx 等），要求根据其中的 UDS 要求设计系统合格性测试用例。典型产出与用户参考模板一致：`TRM_UDS_Security_系统合格性测试用例.xlsx` 的 UDS sheet。

**输入形态**：
- 加密 PDF（`%TSD-Header`）→ 先走 `srs-doc-extract` 技能解密为明文 txt
- 明文 PDF / txt → 直接解析（fitz / 文本）
- **docx（明文 OpenXML）→ 直接解析（python-docx），注意同时提取表格内容（需求常在表格里）**

## 输入依赖矩阵（先看这个，避免"文件不够就硬生成"）

> 跨项目输入文件规范（优先级/用途/缺失处置/实测经验）见专家包根 `references/input-file-spec.md`。要点：SWRS（带 REQ 编号）优先于 System Requirement；DID 检查表（真实抓帧+分层矩阵）是条件受限判定关键证据；功能寻址 NAD 从 LDF `functional_id` 取；缺刷写流程图/0x27 密钥值对应模块标 BLOCKED 不补造。
> **输入文件包模式（推荐，可移植）**：把全部输入按 `input_manifest.json` 清单打包（模板 `skills/input_manifest.example.json`，角色=diag_survey/did_checklist/swrs/ldf/dbc/…），用 `scripts/input_pack_validator.py --pack <包目录>` 一键校验齐备度（逐文件哈希 + 深度体检 + 模块级 READY/DEGRADED/BLOCKED + 下一步动作），规范见 `references/input-file-spec.md` §5；包拷到其他机器/专家即可恢复输入上下文。

不同 SRS 提供的信息量差异很大。生成合格用例前，对照此矩阵确认输入齐备度：

| 输入文件 | 必需性 | 提供什么 | 缺失时的处理 |
|---|---|---|---|
| SRS/SWRS 需求文档 | **必需** | 功能描述、触发帧、DID 线索、章节 | 无此文件无法开始 |
| 诊断调查表（DID/DTC/Routine 定义） | 强烈建议 | DID 明细、NRC、会话/安全约束、波特率/CAN ID | 标注「以 SWRS 为准」，负例 NRC 用 ISO 14229 默认 |
| **CDD 诊断文件（.cdd，新增）** | 强烈建议 | 用 `uds_survey_parser --input x.cdd` 自动提取 DID/信号（cantools 适配器），替代手工转 Excel | 无 CDD 时回退 Excel 调查表 |
| **DBC 通信矩阵（.dbc，新增）** | 强烈建议（CAN 节点） | 用 `dbc_parser.py` 提取报文/信号定义，报文级步骤自动生成 hex | 无 DBC 时帧级步骤写「按 LIN Matrix」 |
| **LDF 描述文件（.ldf，新增）** | 强烈建议（LIN 节点） | 用 `ldf_parser.py` 解析帧/PID/信号偏移/调度表为 lin_db.json，`steps_generator --ldf` 自动生成 LIN 帧 hex（LSB0 打包 + 校验和） | 无 LDF 时帧级步骤写「按 LIN Matrix」 |
| LIN Matrix / 通信矩阵（.xlsx） | 强烈建议（LIN 节点） | 帧 ID、调度表、信号位定义（如 BBSLin2Fr03） | 帧级步骤只能写「按 LIN Matrix」 |
| 刷写流程图（SoftwareDownload FlowChart） | 刷写用例必需 | 刷写时序、0x34/0x36/0x37 流程细节 | 只设计可确认的部分，其余标注待补 |
| Cybersecurity REQ LIST（.xlsx） | 安全用例必需 | 0x27 SeedKey、安全访问策略 | 安全类用例标注「需安全需求文档」 |
| 主机厂诊断规范 | 可选 | NRC 细则、P2/S3 时序值 | 用 ISO 14229 默认值并标注 |
| ISO 14229 中文版（专家包内置） | 内置兜底 | 服务定义、NRC、时序参数 | 无需用户提供 |

> **核心原则：信息不足时先列缺失清单（用 Step 0 体检），不要硬造参数**。用户补一个文件、用例质量上一个台阶。

## 核心流程（七步：体检 → 明文 → 精读 → 定位 → 提取 → 分析 → 设计；Step 4/5 内嵌「用例设计七步法」）

### Step 0：输入体检（新增，必须第一步做）

先用 `srs_input_analyzer.py` 扫描 SRS，得到「输入依赖报告」，再决定走哪条路：

```powershell
$vpy = "$env:USERPROFILE\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if (-not (Test-Path $vpy)) { $vpy = "python" }
& $vpy ".\scripts\srs_input_analyzer.py" "<SRS文件(docx/pdf/txt)>" --report "<输出报告.md>"
```

报告自动给出四件事（**先展示给用户，缺失文件必须向用户确认补齐或标注待补**）：

1. **已发现的诊断信息**：章节结构、DID 列表（如 F12E/F120/F12A，仅作输入识别示例）、诊断帧样例（`51 03 22 F1 2E FF FF FF`）、服务（0x10/0x11/0x22/0x27...）
2. **引用的外部文件**：`SWRS-BT-Cybersecurity-REQ-LIST.xlsx`、`LIN_Matrix.xlsx`、`SoftwareDownloadFlowChart` 等（按「输入依赖矩阵」逐项核对）
3. **配套文件核对表**：诊断调查表 / Cybersecurity REQ LIST / 刷写流程图 / LIN Matrix / CDD / DBC 逐项给出「是否需要 + 文本是否引用 + 状态」，执行前对照补齐
4. **缺口清单**：无 REQ 编号（可选，自动兜底）/ 无 NRC 约束（必需）/ 无会话信息（必需）/ 无安全访问（可选）/ **0x27 密钥与算法资料缺失（执行阻塞级）**，只有占位 0xFF 密钥时正例无法执行）
5. **结论**：`true`（可直接生成）/ `partial`（补齐关键文件）/ `false`（需以诊断调查表为主输入）

**分诊规则**：
- 结论 `false` → 停止，请用户提供诊断调查表或主机厂诊断规范，不要硬生成
- 结论 `partial` → 把缺口清单给用户，能补的补，不能补的标注「以 SWRS 为准」继续
- 结论 `true` → 进入 Step 1

### Step 1：获取 SRS 明文

- 输入是 **docx** → 直接用 python-docx 解析（脚本已内置），注意**表格里的需求也要提取**
- 输入是加密 PDF → 调用 `srs-doc-extract` 技能（`..\srs-doc-extract\scripts\extract_srs_text.py`，auto 模式自动分流）：
  ```powershell
  $vpy = "$env:USERPROFILE\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
  if (-not (Test-Path $vpy)) { $vpy = "python" }
  & $vpy "..\srs-doc-extract\scripts\extract_srs_text.py" "<PDF>" --out "<srs.txt>" 2>&1 | Select-Object -Last 3
  ```
- 输入是明文 PDF/txt → 直接解析
- 校验：首页出现 `===== PAGE 1 =====` + 文档标题，无乱码（`寮€`/`锛?`/U+FFFD）

### Step 1.5：全文精读（srs_focus_extractor.py，防信息损耗的核心，大文档必做）

> **为什么必须有这一步**：解密后的全文 txt 动辄几十万字符（实测 418 页 / 92.6 万字符）。LLM 直接通读原文会截断、丢重点、反复重读浪费上下文——这就是"上传文件文字过多导致信息损耗/抓不住重点"的根源。精读层把「LLM 啃原文」改为「脚本结构化抽取 + LLM 只读精简产物」。

```powershell
$vpy = "$env:USERPROFILE\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if (-not (Test-Path $vpy)) { $vpy = "python" }
& $vpy ".\scripts\srs_focus_extractor.py" "<明文txt/docx/pdf>" --out-dir "<精读输出目录>" --top 12
```

产出四类文件（`--out-dir` 目录）：

| 产物 | 内容 | LLM 怎么用 |
|---|---|---|
| `srs_map.json` | 文档骨架：章节树（编号/docx 样式/块分段兜底）+ 每章节相关性分数 + 页码区间 + 精读顺序 top_sections | **第一个读**（通常 <50KB），据此知道全文结构和先读哪里 |
| `srs_facts.json` | 结构化事实：REQ 块（编号/ASIL/Purpose/shall 条款）、诊断帧（SID/DID 识别，兼容 CAN 三种帧头与 LIN NAD+PCI 帧头）、DID、时序参数（P2/S3/STmin…）、NRC、会话、安全 | 直接作为用例设计的事实来源，**每条带页码+章节证据** |
| `sections/S*.md` | 仅 Top-N 高分章节的原文裁剪（默认 12 个，单章节超 2 万字符截断并标注） | 深入分析时只读这些；截断了就 `--dump-section "章节号"` 按需钻取全文 |
| `FOCUS_REPORT.md` | 人类可读精读报告：精读顺序表 + 事实摘要 + 阅读指引 | 展示给用户，作为"文档里有什么、重点在哪"的交代 |

**铁律**：
- 精读跑完后 **禁止再通读原文 txt**；需要某章节全文一律走 `--dump-section`
- 事实层每条带页码/章节证据 → 写用例「需求来源/时序引用」直接引用，不要凭记忆改写数值
- 退出码 2 = 全文无强证据（REQ/帧/DID/时序/NRC/会话/安全均无）→ 提示用户该文档不适合作为 UDS 用例主输入
- docx 输入按文档顺序交织提取段落与表格（修复"表格堆到末尾"的失真）；功能风格 SRS 自动生成 `REQ-<章节>.<序号>` 追溯块

### Step 2：定位 UDS 相关章节

在明文全文（含表格）中检索章节标题（正则 `^\s*\d+\.\d+(\.\d+)*\s+\S`），聚焦 UDS 相关。**Step 1.5 已跑过精读时，直接消费 `srs_map.json` 的章节树与 top_sections 排序，不要重新扫全文**。章节命名风格因文档而异，不要只认一种模式：

| 章节模式 | 内容 | 测试重点 |
|---|---|---|
| `4.1.4 Diagnostics` / `4.1.6~4.1.9` | Volvo 风格：Transport/Session/Data/Services | BS/STmin、S3 超时、DID、各服务 |
| `DiagcForSlaveNodBBS` / `UDS on LIN` | 功能风格：触发帧 + 动作（发送某信号帧） | 按触发帧反推服务/DID，测信号输出 |
| `Software Download` / `SoftwareDownload` | 刷写章节（常引用外部流程图） | 0x34/0x36/0x37、异常场景 |
| `Cybersecurity` / `SecurityAccess` | 安全章节 | 0x27、SeedKey |

> 章节号因文档而异，不要硬编码；用关键词搜索（`Service 0x`、`Session`、`SecurityAccess`、`TesterPresent`、`Diagnostic frame`、`0x3C` 等）辅助定位。**功能风格 SRS（无标准章节号）直接按功能名定位**。

### Step 3：提取需求正文（含无 REQ 编号的兜底）

**风格 A（Volvo 风格，有 REQ 编号）**——逐条提取：
```
REQ-90441v4 DiagnosticSessionControl (10) programmingSession (02, 82)
ASIL class: Change
Purpose: It shall be possible to re-program any ECU...
The ECU shall support the service diagnosticSessionControl – programmingSession in:
· defaultSession / · extendedDiagnosticSession / · programmingSession
```
提取要点：
- **REQ 编号**（`REQ-\d+v\d+`）+ 标题 → 用例的「需求ID」来源
- **shall/may 动词** → 区分强制（shall，必须测）/可选（may，边界测）
- **约束值**（P2=50ms、S3=5s、BS、STmin、NRC）→ 时序/参数类用例的预期值来源

**风格 B（功能风格，无 REQ 编号，如 BBS 系列 SRS）**——兜底策略：
- 从「功能描述 + 触发条件 + 动作」提取测试意图（如触发帧 `0x3C:51 03 22 F1 2E` → 0x22 读 DID F12E，动作 = 发送 BBSLin2Fr03 等信号）
- **自动生成追溯 ID**：`REQ-<章节号或功能缩写>.<序号>`，如 `REQ-Diagc.SN-01`、`REQ-UDSoL.01`，并在「需求ID」列标注「自动生成，对应 SRS 章节 X」
- 触发器里的 DID/帧即用例输入；动作里的信号名（如 BBSLin2Fr03）即预期输出——**先核对 LIN Matrix 确认信号位定义**

### Step 4：需求分析（资深测试工程师视角）

对每条 UDS 需求，按以下维度生成测试意图：

1. **功能正例**（happy path）：服务在允许会话/条件下正常响应
2. **功能负例**：不允许的会话/子功能/参数 → 期望 NRC
3. **边界值**：参数边界（长度、值域、计数器、超时阈值±）
4. **时序类**：P2/P2*/S3 超时、响应时间、BS/STmin 一致性
5. **安全类**：0x27 认证成功/失败/锁定、未解锁访问受保护服务 → 0x33
6. **恢复类**：异常后回到正常（超时回默认会话、传输中断后可重发）

每条需求至少覆盖**正例 + 一个负例或边界**；安全关键需求（0x27/0x2E 写/0x31 例程）必须测未授权拒绝。

#### 用例粒度策略（重要：先确认用户要哪种，再设计）

**默认问用户一句**："这份用例要『全量矩阵』还是『需求驱动 × 10 维』？"（量产系统合格性验收推荐需求驱动 10 维，对齐成熟主机厂 TRM）

| 模式 | 粒度 | 用例量级 | 适用场景 |
|---|---|---|---|
| **全量矩阵模式**（对齐主机厂 TRM） | **服务 × 全部对象（DID/子功能/例程）× 会话 × 前置状态** 笛卡尔积展开 | 约 200-300 条（以调查表对象数为准） | **系统合格性测试、量产验收**（同事模板粒度） |
| **需求驱动 × 10 维模式**（推荐验收） | 需求驱动 × 10 维（对象/会话/寻址/正反/子功能遍历/长度与S3边界/安全矩阵/时序/恢复/抑制位） | 约 400~900 条（BBS 实测 ~470 条，成熟 TRM 814 条） | **系统合格性验收、对齐成熟主机厂 TRM** |

**全量矩阵模式必须用生成器**（`scripts/uds_full_matrix_generator.py`），不要手工逐条写：

```powershell
# 输入：诊断调查表目录（*_diagnostic.xlsx）→ 输出：全量用例 JSON → xlsx
$vpy = "$env:USERPROFILE\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if (-not (Test-Path $vpy)) { $vpy = "python" }
& $vpy ".\scripts\uds_full_matrix_generator.py" "<调查表目录>" --out "<用例.json>" --product "产品型号"
& $vpy ".\scripts\build_testcase_xlsx.py" "<用例.json>" --out "<用例.xlsx>" --cover "customer=..." "product_model=..."
```

#### 项目配置化（跨项目使用时必须关注）

全量矩阵生成器、用例 lint、会话门禁和逐用例脚本生成都支持同一份项目配置：

```powershell
& $vpy ".\scripts\uds_full_matrix_generator.py" "<调查表目录>" `
  --out "<用例.json>" --product "产品型号" --target "测试对象" `
  --project-config "<项目配置.json>"
& $vpy ".\scripts\case_lint.py" --cases "<用例.json>" `
  --project-config "<项目配置.json>" --out "<lint.md>"
```

配置模板见 `skills/project_config.example.json`。不传 `--project-config` 时保留历史兼容默认值；
新项目应显式填写 `sessions`、`transport`、`generation` 和适用的 `security`/`lint` 节点，
不要依赖示例项目的会话、NAD 或 DID。`session_probe_did`、`reset_probe_did`、
`security_constant_dids`、`representative_write_did` 不适用时分别使用 `null` 或 `{}`；
`security_constant_dids` 的键使用连续的安全访问子功能字节，例如 `0x0506` 表示 `05 06`；
`max_write_dids: null` 表示处理全部 DID。未配置 `unsupported_did` 时，未支持 DID 负例保留
为待项目确认的占位，不会擅自选用示例 DID。

**对齐成熟 TRM 粒度用需求驱动生成器**（`scripts/uds_req_matrix_generator.py`，10 维展开，推荐系统合格性验收）：

```powershell
# 输入：调查表目录 → 输出：需求驱动用例 JSON → xlsx（无 --req-map 时需求 ID 自动生成）
& $vpy ".\scripts\uds_req_matrix_generator.py" "<调查表目录>" --out "<用例.json>" --product "产品型号" --target "测试对象"
# 可选：--req-map "<服务->需求ID映射.json>"（挂真实需求 ID）；--sf-traverse（0x11 子功能 0x00~0xFF 全遍历）
# 可选：--ro-dids <DID_A>,<DID_B>（按本项目填写，强制只读 DID，禁止生成 0x2E 写入正例）；--sa-session-map "<0x27等级会话映射.json>"（覆盖兼容默认等级会话归属）
& $vpy ".\scripts\build_testcase_xlsx.py" "<用例.json>" --out "<用例.xlsx>" --cover "customer=..." "product_model=..."
```

> **完整模板模式（推荐，对齐 `BBS_P519_V436-系统合格性测试用例` 13-sheet 结构）**：加 `--template "<模板.xlsx>"` 直接写入模板的 UDS 页（B8 起，自动清空模板样例数据，保留封面/数据汇总公式），产出与参考文件同构：
> ```powershell
> & $vpy ".\scripts\build_testcase_xlsx.py" "<用例.json>" --out "<用例.xlsx>" --template ".\references\系统合格性测试用例模板.xlsx"
> ```

> 两个生成器分工：`uds_full_matrix_generator`（对象驱动，快速 200~300 条）；`uds_req_matrix_generator`（需求驱动 × 10 维，含时序组/安全矩阵/S3 边界，接近成熟 TRM 粒度）。具体展开规则见 `references/uds-trm-expansion-rules.md`。

> **安全等级、会话和非法子功能 NRC 均以项目配置为准**：可用 `security.level_to_sessions`、
> `sessions` 和 `nrc.illegal_subfunction` 配置；命令行 `--sa-session-map` 仍可作为单次覆盖。
> `--sf-traverse` 会把子功能负例大规模展开，除非主机厂明确要求全遍历，否则用默认代表值模式。

生成器自动展开：0x22 全部 DID（含 Composite EDA0）多会话/多帧/内容校验；0x10 会话切换矩阵（来源×目标+广播+时序+非法）；0x31 全部例程×启停/结果/未解锁/时序；0x27 种子/密钥×会话/等级/锁定/恢复；0x2E 全 DID×未解锁/会话/长度；0x3E 00/80×会话×S3 边界；0x11 会话×复位后验证/时序/非法。

> 全量矩阵的 NRC/时序/DID 全部来自调查表（P2/S3、Session reference、安全要求），不会凭空编造；对**调查表未列的服务**（如 0x14/0x19）默认不展开，也不把“未列出”推断为“不支持”。只有调查表/主机厂规范明确标注不支持，或用户明确要求兼容性探测时，才设计服务不支持负例，并把依据写入需求来源。

#### 成熟 TRM 展开规则（对齐主机厂合格性粒度，系统验收推荐）

> **生成器（对象驱动）默认产出约 200-300 条（BBS 实测 238 条，不同项目随对象数浮动）；要对齐成熟文件粒度（UDS 800+ 条），须按「需求驱动 × 10 维展开」**。完整规则见 `references/uds-trm-expansion-rules.md`（从 Volvo BBS 成熟用例 814 条反推，可跨项目移植）。

**十个展开维度**（每服务用例 = 以下维度笛卡尔积，取调查表/SWRS 支持项）：

1. 对象（DID / RID / 子功能清单）→ 2. 会话（默认/扩展/编程）→ 3. 寻址（Phys / Func）→ 4. 正反（每交叉点正例+负例，负例必须断言 NRC）→ 5. 子功能（合法逐个 + 非法 0x00~0xFF 遍历）→ 6. 边界（长度 −1/刚好/+1、多帧 SF_DL/FF_DL、S3 超时 ±）→ 7. 安全（未解锁 0x33、等级×会话×密钥状态×延迟边界、失败锁定）→ 8. 时序（P2/P2\*/S3/P4 独立测量）→ 9. 恢复（上电/复位回默认、S3 回退、例程中断）→ 10. 抑制位（suppressPosRspMsgIndicationBit 0x80）

**执行要点**：
- **时序组 `UDS_TimeParm` 必须独立成组**（P2/P2\*/S3/P4 每参数 2~3 条测量用例）——旧生成器最大缺口；
- 0x10 做**来源×目标会话全切换矩阵**；0x22/0x2E 每 DID×会话×寻址 正反成对；0x27 按**等级×会话×密钥状态×延迟**矩阵；0x31 每 RID×启停结果×会话；
- 每条用例挂 **3~5 条需求 ID**（交叉追溯）；
- **具体值（P2/S3/会话/安全等级）一律取本项目 SWRS/调查表，禁止照抄规则文档中的示例值**（红线）。

#### 用例设计七步法（通用方法论，覆盖 UDS/LIN/功能三类对象）

> 与上面的「六类测试意图」互补：六类意图管**测什么类型**，七步法管**怎么组织成用例集**。
> 口诀：**先分组 → 列维度做组合 → 正反成对 → 边界异常时序单独拆 → 一条一判定点。**

**第 1 步｜拆对象，建分组**（对应 Step 5 命名规范，先于命名做）
按类型分组并定命名规则：UDS 按服务（`UDS_0x10_TC_xxxx`）、LIN 按帧/信号（`LN_TC_xxxx`）、功能按模块（`TC-BBS-STATE`、`TC-BBS-TRIG`）。**分组就是后面的文件结构**——先定分组再写用例，避免用例满天飞、后期迁移改 ID。

**第 2 步｜列放大维度**（对应 Step 4 六类意图 + 全量矩阵笛卡尔积）
对每个对象列出影响行为的维度，用例数量和质量的关键：
- 会话/模式（默认/扩展/编程，正常/运输/休眠）
- 寻址（物理/功能/特殊配置）
- 子功能与参数（01/02/03、级别、DID/RID 清单）
- 数据边界（长度 −1 / 刚好 / +1）
- 状态（每个状态 + 迁移）
- 时序（P2/P2\*/S3/超时阈值）

> 检查点：这步做完应能画出「维度组合表」，用例数量大致 = 组合数。漏维度 = 漏用例。

**第 3 步｜正反成对**
每个交叉点至少两条：正向（请求 → 肯定响应）、负向（请求 → 否定响应码）。负向按 NRC 细分（0x12/0x13/0x22/0x24/0x31/0x35/0x7E），关键场景加「NRC 优先级」用例（多 NRC 可发生时，验证按优先级返回哪个）。

**第 4 步｜补边界、异常、时序**
用等价类 + 边界值 + 错误猜测补齐：无效值（0xFFFF/0x7F）、错误顺序（先发密钥后要种子）、重复指令、上电/复位恢复、失败计数锁定、超时边界。**一条一例，别合并**（合并后无法定位失败原因）。

**第 5 步｜单点化 + 报文级步骤**
坚持「一条用例 = 一个可判定点」。操作步骤写到报文/信号级：`测试仪请求 hex → 预期响应 hex → 时序/等待`。预期结果必须可判定——能不能过，一眼就清楚。

**第 6 步｜挂需求 + 填属性**
每条用例挂需求 ID（可多挂，如 `REQ-90438v4\nREQ-90439v4`，形成交叉点），填优先级（L1/L2/L3）、自动化评估（是/否）、用例设计方法（需求分析/等价类/边界值/错误推测）→ 对应 xlsx 的 C 需求ID / E 优先级 / F 自动化评估 / I 设计方法 列。

**第 7 步｜追溯矩阵 + 评审**
建需求↔用例**双向追溯矩阵**，统计覆盖率；跑一遍「写完后自查清单」（见 Step 5 末尾），再评审发布。

### Step 5：设计测试用例并输出 xlsx

#### 用例 ID 命名规范（与用户模板一致）

```
UDS_<服务>_TC_<序号>      例：UDS_0x10_TC_0002（服务类）
UDS_<主题>_TC_<序号>      例：UDS_TimeParm_TC_0001（时序类）、UDS_Security_TC_0001
```

#### 优先级定义

- **L1**：核心功能、安全关键、影响合格判定（会话切换、0x27 认证、0x2E 受保护写、时序 P2）
- **L2**：边界/异常/恢复/低风险（超时回退、多帧 BS/STmin、错误 key 计数、传输中断恢复）
- **L3**：可选（may 需求、组合场景）

#### xlsx 模板（19 列，表头在第 7 行 B~T，与用户参考一致）

```
B=需求来源 C=需求ID D=用例ID E=优先级 F=自动化评估 G=测试点
H=测试方法Test Type I=用例设计方法 J=测试环境 K=前提条件 L=操作步骤
M=预期结果 N=选择测试用例 O=测试结果 P=测试结论 Q=缺陷编号 R=测试者
S=测试日期 T=备注
```

- 表头前 6 行：封面信息（客户名称/产品型号/SRS 版本/需求数等）
- 单元格多行内容用换行（`\n`）分隔，序号 `1.`/`2.` 开头
- 报文格式：`服务ID 长度 SID 子功能 参数...`（如 `51 02 10 02 FF FF FF FF`），DUT 响应/请求各一行

#### 生成 xlsx（直接用资产脚本）

```powershell
$vpy = "$env:USERPROFILE\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if (-not (Test-Path $vpy)) { $vpy = "python" }
$script = ".\scripts\build_testcase_xlsx.py"
# 1) 先把设计好的用例写成 JSON（结构见 references/case-schema.md）
& $vpy $script "<用例.json>" --out "<输出.xlsx>" --cover "customer=Volvo" "product_model=TRM_V436" "srs_version=33139542-001（PRELIMINARY）"
```

脚本自动：写封面 6 行 → 表头（B7:T7）→ 用例数据（B8 起）→ 列宽/换行/边框 → 校验用例数与 JSON 一致。

> **正式交付对齐模板**：`references/系统合格性测试用例模板.xlsx`（13 sheet：封面Cover / 模板修订记录 / 变更履历 / 测试说明 / 数据汇总（COUNTIF 自动联动）/ UDS、功能测试、SWDL、LIN网络、网络安全、环温稳定、Module A（每页双行表头 B7:T7 + **需求来源默认「系统规格书」** + P/F/NT/NA、是/否、L1/L2/L3 下拉）/ 填写说明）。用 `scripts/build_testcase_template.py` 可重建或定制模板；生成的用例数据（19 列）直接写入模板对应模块页（B8 起），数据汇总自动统计。

### 写完后自查清单（七步法第 7 步，输出前强制检查，一条不过就返工）

- [ ] 每个对象都有正反用例，负向 NRC 是否覆盖全
- [ ] 边界值 −1 / 刚好 / +1 三档都有
- [ ] 会话/寻址维度是否每个交叉点都覆盖
- [ ] 时序类（超时/等待/恢复）是否单独成例
- [ ] 每条用例只有一个判定点，步骤可执行、预期可判定
- [ ] 每条都挂了需求 ID，追溯矩阵无孤儿（无用例的 REQ）、无漏测（无 REQ 的用例）
- [ ] **跑一遍覆盖率自动化**：`python scripts/req_coverage.py --cases <用例.json> --srs <srs.txt> --out coverage.md`，确认覆盖率达标、无漏测、无孤儿 REQ（孤儿=疑似编造需求 ID，必须核对）
- [ ] **跑一遍规则 lint**：`python scripts/case_lint.py --cases <用例.json> --project-config <项目配置.json> [--disable-rule R5]`，R1~R5 按项目配置检查；不适用的规则通过配置或 `--disable-rule` 关闭，FAIL 阻断交付
- [ ] 自动化评估、优先级、设计方法列已填
- [ ] 按成熟 TRM 规则（references/uds-trm-expansion-rules.md）：时序组独立、子功能遍历、长度/S3 边界、安全矩阵已展开

### Step 6：桥接 uds-diagnostic-test（可选，让用例能直接执行）

> ⚠️ **先纠正一个易错点**：本技能的用例 JSON（case-schema：req_sources/case_id/procedure/expected）与 `uds_parsed.json`（can_config/dids/dtcs/io_controls/routines/security_access）**不是同构结构**——前者是「设计产物」，后者是「执行输入」。**正确的桥接路径是：直接对原始调查表跑 `uds_survey_parser` 生成 `uds_parsed.json`**（用例 xlsx 中 select=是 的测试项仅作为筛选参考，用于核对执行的服务/DID 与设计一致），再交给 uds-diagnostic-test 生成脚本。

只有在**没有调查表、但有确定的执行参数**时，才手工整理 `uds_parsed.json`（结构如下，交给 uds-diagnostic-test）。下方 DID/CAN 值仅演示结构，不能直接作为新项目默认值：

```json
{
  "can_config": {"tx_id": "0x7E0", "rx_id": "0x7E8", "bitrate": 19200, "lin": true},
  "dids": [{"did": "0xF12E", "name": "PartNumber", "length": 4, "readable": true}],
  "dtcs": [],
  "io_controls": [],
  "routines": [],
  "security_access": {"needed": true, "seed_did": "0xF1A0"}
}
```

- 桥接要点：**DID/CAN ID/波特率等参数来自输入依赖矩阵中的调查表或 LIN Matrix**，缺失项留空并标注，交给 uds-diagnostic-test 的「强制确认」环节由用户补
- 不要跳过该确认环节：uds-diagnostic-test 会在生成脚本前展示默认值/缺失参数表，用户确认后才带 `--confirmed` 生成
- 这样「用例设计 → 脚本生成 → 硬件执行」三个环节参数一致，不会脱节

## 与参考文件的对应关系（用户模板示例解读）

用户参考 `BBS_P519_V436-系统合格性测试用例System qualification test.xlsx` UDS sheet 的关键模式（**已核对：模板/生成器与此文件格式一致**，19 列 B~T、表头第 7 行；新用例必须对齐）：

| 模式 | 示例 | 含义 |
|---|---|---|
| B 需求来源 | `系统需求规格书` | 来源文档名（默认「系统需求规格书」，对齐参考文件） |
| C 需求ID 多 REQ | `REQ-90438v4\nREQ-90439v4` | 一条用例的全部需求 ID 在 C 列换行列出 |
| 用例 ID 按服务分组 | `UDS_0x10_TC_0002~0005` | 0x10 会话控制一组 |
| 前提条件 3 项 | 供电12V/应用模式/默认会话 | 前置状态固定化 |
| 操作步骤=测试仪请求 | `1.测试仪请求：51 02 10 02 FF FF FF FF；` | 报文级步骤 |
| 预期结果=正/负响应 | `DUT正响应：51 06 50 02 00 19 13 88；` / `NRC=0x12` | 含响应报文+判定 |
| 优先级 L1/L2 | L1 核心、L2 边界 | 分级 |
| 时序引用 SWRS | `P2Server_max=25ms（以SWRS为准）` | 预期值锚定 SRS 章节 |

## 关键坑点

1. **不要凭空造报文/参数**：所有服务 ID、子功能、NRC、时序值必须来自 SRS 原文；SRS 未明确的（如 P2* 具体值）标注「以 SWRS 为准」。
2. **会话和安全前置必须写清并以本项目 SRS/项目配置为准**：0x27/0x2E/0x31 等受保护服务是否需要特定会话、解锁等级或其它前置必须有依据；不要把“扩展会话+已解锁”当成所有项目的固定规则，漏写实际前置会导致用例无法执行。
3. **负例必须有 NRC 断言**：负响应用例预期结果必须写 NRC（0x12/0x13/0x22/0x31/0x33/0x35 等），不能只写「返回负响应」。
4. **L1/L2 分级别凭感觉**：安全关键（0x27、0x2E 写、刷写相关）必须 L1。
5. **多帧/时序类用例要写明测量方法**：如「抓取 FC 帧解析 BS/STmin」「测量请求末帧到响应首帧时间」。
6. **用例不可覆盖需求盲区**：每条 REQ 至少对应一条用例；同一 REQ 的不同子功能（如编程会话/扩展会话）分开测。
7. **DID 具体值从本项目 SRS 的 DID 表取**（活动会话、软件版本等 DID 的编号以项目资料为准），不要把示例项目编号带入新项目，也不要用占位符 xx xx 代替可确定的 DID。
8. **先体检、后设计**：收到 SRS 先跑 `srs_input_analyzer.py`，把外部文件缺口清单给用户，**信息不足不要硬生成**——这是本技能最容易翻车的点（SRS 常引用 LIN Matrix/调查表/刷写流程图/安全清单，缺哪个，哪类用例就标注「待补」）。
9. **功能风格 SRS 别硬套 REQ 格式**：无 REQ 编号时自动生成 `REQ-<章节>.<序号>` 追溯 ID 并标注章节出处，不要因为找不到 REQ 就卡住或编造。
10. **docx 表格别漏**：需求常写在表格里（python-docx 提取时表格也要纳入分析）。
11. **单点化**：一条用例只写一个判定点，多个断言拆成多条用例——否则执行失败时无法定位是哪一步出的问题。
12. **先建组再命名**：用例 ID 分组即文件结构（七步法第 1 步），先分组后写用例；临时拼的 ID 后期迁移成本高。
13. **追溯矩阵不能省**：设计完成必须跑一遍自查清单（Step 5 末尾），「无孤儿、无漏测」是评审的第一道门槛。
14. **大文档禁止 LLM 通读原文**：精读（Step 1.5）跑完后只读 srs_map.json / srs_facts.json / sections/*.md；需要某章节全文用 `--dump-section` 钻取。直接通读几十万字符的 txt 是信息损耗和漏抓重点的最大来源。

## 资源说明

- `scripts/srs_input_analyzer.py` —— **SRS 输入体检**：自动提取章节/DID/诊断帧/外部文件引用，输出「能否生成用例 + 缺什么」报告（docx/pdf/txt/加密 PDF 均支持）
- `scripts/srs_focus_extractor.py` —— **SRS 全文精读分层抽取（v1.0，防信息损耗核心）**：骨架（章节树+页码索引+相关性打分）→ 聚焦（top_sections 精读顺序）→ 事实（REQ 块/诊断帧 CAN+LIN 双制式/DID/时序/NRC/会话/安全，全部带页码证据）→ 裁剪（Top-N 高分章节原文 + `--dump-section` 按需钻取）。产物 srs_map.json / srs_facts.json / sections/*.md / FOCUS_REPORT.md；退出码 0/2（无强证据）/3（解析失败）。测试 `test_srs_focus_extractor.py`（7 例）
- `scripts/input_pack_validator.py` —— **输入文件包一键校验（可移植性）**：读包内 `input_manifest.json`，逐文件存在/类型/哈希 + 深度体检（doc 体检/调查表解析/config 关键节点/LDF·DBC 嗅探）→ 输出 pack_readiness.md/.json（模块级 READY/DEGRADED/BLOCKED + 下一步动作）；退出码 0/1/2。P1 相关性按总线过滤（LIN 不要求 dbc，CAN 不要求 ldf）。模板 `skills/input_manifest.example.json`；测试 `test_input_pack_validator.py`（6 例）
- `scripts/uds_full_matrix_generator.py` —— **UDS 用例全量矩阵生成器（对象驱动）**：解析 ODX 风格诊断调查表（Protocol/Service/DID/Composite DID/Control Routine/Timing），按「服务 × 全量对象 × 会话 × 前置状态」展开系统合格性用例（对齐主机厂 TRM 粒度），输出 case-schema 兼容 JSON
- `scripts/uds_req_matrix_generator.py` —— **UDS 需求驱动 × 10 维展开生成器**：实现 references/uds-trm-expansion-rules.md 规则（会话切换矩阵/子功能遍历/长度与S3边界/安全矩阵/时序组TimeParm/恢复/抑制位），输出 case-schema 兼容 JSON；支持 `--req-map` 挂真实需求 ID、`--ro-dids` 强制只读 DID、`--sa-session-map` 等级会话映射；`--sf-traverse` 全遍历带用例爆炸告警
- `scripts/req_map_v31.json` —— **固定需求 ID 映射（BBS V3.1 示例，可替换）**：`did`/`rid` 字段实现**场景级精确绑定**（如 F12E → REQ-ReadDID.01、0206 → REQ-Routine.01），`0xXX`/`T` 字段为服务级公共需求；生成器通过 `_cur_req_extra` 上下文绑定，保证**同一场景永远挂同一需求 ID**（可复现、可追溯）。移植新项目时**必须**按本项目 SRS/调查表重建此文件（REQ ID 与 DID/RID 均为项目相关，勿沿用示例）
- `references/系统合格性测试用例模板.xlsx` —— **正式输出模板**（13 sheet，对齐主机厂 TRM）：封面/修订/变更/说明/数据汇总（自动公式）/7 个测试模块（双行表头 + 需求来源默认「系统规格书」+ 下拉验证）/填写说明
- `scripts/build_testcase_template.py` —— 模板生成/重建脚本（openpyxl），可定制列名、模块、公式
- `scripts/build_testcase_xlsx.py` —— 用例 JSON → 模板 xlsx（封面+表头+数据+样式+校验），直接复用；**默认输出单 UDS sheet**，加 `--template` 写入 13-sheet 完整模板（对齐 BBS_P519_V436-系统合格性测试用例 UDS 页：19 列 B~T、B=系统需求规格书、C=全部 REQ 换行、H=测试方法）
- `scripts/steps_generator.py` —— **报文级步骤自动生成器（v2.1，消灭手抄 hex + 审计审查）**：识别用例 JSON 中的占位符（`{{READ_DID:F12E}}` / `{{WRITE_DID:F12E:0102}}` / `{{SESSION:03}}` / `{{RESET:01}}` / `{{TP}}` / `{{TP:80}}` / `{{MSG:0x1F0:Enable=1}}` / `{{DECODE:0x1F0:804A...}}` / `{{LIN_MSG:BBS1LinFr03:Sig=1}}` / `{{LIN_DECODE:BBS1LinFr03:0011223344556600}}`），用 cantools 自动算 CAN 报文字节流、用 lin_db.json 做 LIN 信号打包（LSB0 + 校验和自动计算：诊断帧经典、其余增强）；`--cdd` 提供 DID 长度、`--dbc` 提供 CAN 报文信号编解码、`--ldf` 提供 LIN 帧/PID/信号偏移（ldf_parser.py 产物）；procedure 字段只填请求、expected 只填响应；多帧/缺参数输出「待补」不硬造。**审计审查**：每条填充记录来源（CDD/DBC/LDF/ISO 14229/推断）+ 协议校验（帧长度/正响应SID/子功能合法性/DID存在性/数据长度/信号范围/校验和），输出 PASS/WARN/FAIL 三态——FAIL 在用例文本标「[审查失败]」且退出码=2 阻断交付，WARN 标「[需确认]」；`--audit audit.json` 输出完整审计报告供人工复核，杜绝虚假报文。用法：`python steps_generator.py --cases cases.json --out cases_filled.json --cdd diag.cdd --dbc can.dbc --ldf lin_db.json --audit audit.json`，再走 build_testcase_xlsx.py
- `scripts/req_coverage.py` —— **需求覆盖率自动化（v1.0）**：输入用例（JSON 或 xlsx）+ 需求清单（`--reqs` 手动清单或 `--srs` SRS 全文自动提取 `REQ-\d+v\d+`），自动输出 ① REQ→用例双向追溯矩阵 ② 覆盖率统计（已覆盖/总数/百分比）③ 漏测 REQ 清单（需求有、无用例）④ 孤儿 REQ 检测（用例挂了清单中不存在的 REQ → 疑似编造/笔误）⑤ 裸用例检测（无 REQ 挂载）。`--out coverage.md` 出 Markdown 报告；有漏测/孤儿时退出码=1 提示。用法：`python req_coverage.py --cases cases.json --reqs reqs.txt --out coverage.md` 或 `--cases cases.xlsx --srs srs.txt`
- `scripts/case_lint.py` —— **用例生成后规则 lint（v1.0）**：对生成器输出的用例 JSON 做规则校验（R1 只读 DID / R2 安全等级会话 / R3 非法子功能 NRC / R4 负例断言 NRC / R5 0x27 会话前置），规则参数来自 `project_config.json`；支持 `--project-config`、`--disable-rule`，命令行 `--ro-dids`/`--sa-session-map` 可单次覆盖；FAIL 退出码=2 阻断交付
- `skills/project_config.py` + `skills/project_config.example.json` —— **跨项目配置契约**：统一 transport/NAD、会话/跳转/S3、安全等级、NRC、lint 开关、探针 DID、代表性写入 DID 和 DID 数量上限；不适用值使用 `null` 或 `{}`，`max_write_dids: null` 表示全量
- `references/case-schema.md` —— 用例 JSON 结构定义（字段/格式/示例），设计用例时按此组织
- `references/uds-services-cheatsheet.md` —— UDS 服务/NRC/时序参数速查表（0x10/0x11/0x22/0x27/0x2E/0x31/0x3E/0x23/0x34/0x36/0x37 + 常用 NRC），写报文和预期值时对照
- `references/uds-trm-expansion-rules.md` —— **成熟 TRM 展开规则**（从 Volvo BBS 成熟用例 814 条反推）：需求驱动 × 10 维展开公式、各服务规模估算、时序组独立要求、需求挂载规则、移植新项目步骤
- `references/ISO14229-UDS-重点速查.md` —— ISO 14229-1:2013 **重点速查版**（服务总表/子功能/NRC 全表/时序参数 P2·P2\*·S3·P4/多帧传输 BS·STmin/会话与安全/示例报文），替代 542 页全文 PDF；与 SRS/SWRS 或主机厂规范冲突时以客户规范为准

## 红线

- 不修改 SRS 原文；提取内容仅用于测试设计
- 不编造 SRS 未定义的协议参数；不确定处标注「以 SWRS 为准」
- **信息不足先列缺失清单，不硬生成**：体检结论 `false` 时必须请用户补输入（调查表/规范），不得凭想象补全参数
- 解密明文仅临时使用，用完清理（与 srs-doc-extract 一致）
