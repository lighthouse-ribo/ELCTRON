# -*- coding: utf-8 -*-
"""Scan deliverables for likely secret material without returning secret values."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

PATTERNS = (
    ("private_key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", re.I)),
    ("certificate_private_key", re.compile(r"(?:private[_ -]?key|secret[_ -]?key|aes[_ -]?key)\s*[:=]", re.I)),
    ("hex_secret", re.compile(r"(?<![0-9a-f])(?:[0-9a-f]{32}|[0-9a-f]{64})(?![0-9a-f])", re.I)),
    ("access_token", re.compile(r"(?:api[_ -]?key|access[_ -]?token|client[_ -]?secret)\s*[:=]", re.I)),
)
SKIP_SUFFIXES = {".png", ".jpg", ".jpeg", ".xlsx", ".xls", ".docx", ".pdf", ".zip", ".pyc"}


def _iter_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() not in SKIP_SUFFIXES:
            yield path


def scan_path(root: str | Path) -> dict:
    base = Path(root)
    findings = []
    scanned = 0
    for path in _iter_files(base):
        scanned += 1
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for name, pattern in PATTERNS:
            if pattern.search(text):
                findings.append({"file": str(path.relative_to(base)), "pattern": name})
    return {
        "schema_version": "security-scan/v0.1",
        "status": "PASS" if not findings else "BLOCKED",
        "scanned_files": scanned,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "never include matched secret values",
    }
