# -*- coding: utf-8 -*-
"""Network-security framework contracts and state gates."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Mapping

HERE = Path(__file__).resolve().parents[1]
_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))

from project_config import project_identity  # noqa: E402

CATALOG_PATH = HERE / "data" / "cybersecurity_catalog.json"
VALID_STATUSES = ("PASS", "FAIL", "BLOCKED", "PLANNED", "NT", "NA")


def load_catalog(path: str | Path = CATALOG_PATH) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def evaluate_inputs(inputs: Mapping[str, Any] | None) -> dict[str, Any]:
    data = dict(inputs or {})
    blockers: list[str] = []
    required = {
        "security_requirements": "缺少网络安全需求/安全目标",
        "test_authorization": "缺少安全测试授权",
        "hardware": "缺少硬件接口与调试状态资料",
        "key_material": "缺少受控密钥引用，0x27/密钥保护执行阻断",
        "certificate_material": "缺少证书链资料，证书场景执行阻断",
        "image_material": "缺少签名镜像资料，安全启动/刷写执行阻断",
    }
    for role, message in required.items():
        value = data.get(role)
        if not isinstance(value, Mapping) or str(value.get("status", "")).upper() not in {"READY", "AVAILABLE", "CONFIRMED"}:
            blockers.append(message)
    return {
        "overall_status": "READY" if not blockers else "DEGRADED",
        "execution_ready": not blockers,
        "blockers": blockers,
        "policy": {
            "source_workbook_read_only": True,
            "secret_values_in_context": False,
            "missing_material_status": "BLOCKED",
            "unexecuted_status": "PLANNED",
        },
    }


def gate_status(
    requested: str,
    *,
    evidence_complete: bool,
    executed: bool,
    prerequisites_ready: bool = True,
) -> str:
    status = str(requested or "PLANNED").upper()
    if status not in VALID_STATUSES:
        raise ValueError(f"未知网络安全状态: {requested}")
    if status == "PASS" and (not executed or not evidence_complete or not prerequisites_ready):
        return "PLANNED" if prerequisites_ready else "BLOCKED"
    if status == "FAIL" and not executed:
        return "PLANNED"
    return status


def build_framework(*, source_cases: int = 50, inputs: Mapping[str, Any] | None = None,
                    project_config: Mapping[str, Any] | str | None = None) -> dict[str, Any]:
    """构建网络安全框架契约；项目号来自项目配置，不在代码里写项目字面量。"""
    catalog = load_catalog()
    return {
        "schema_version": "cybersecurity-framework/v0.1",
        "project": project_identity(project_config)["project"],
        "catalog": catalog,
        "source_cases": {"count": source_cases, "selected_count": source_cases, "read_only": True},
        "readiness": evaluate_inputs(inputs),
        "status_vocabulary": list(VALID_STATUSES),
    }
