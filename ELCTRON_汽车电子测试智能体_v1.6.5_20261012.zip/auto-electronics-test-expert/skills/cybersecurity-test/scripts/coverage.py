# -*- coding: utf-8 -*-
"""网络安全框架设计期覆盖度与质量分析。

纯设计期工具：不连接硬件、不判定实测结果。基于需求锚点、派生映射与场景
目录，输出“域/场景覆盖矩阵、未覆盖缺口、锚点可测性提示”，供框架迭代优化。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Iterable, Mapping

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from security_framework import load_catalog

LOW_TESTABILITY_KINDS = {"section-title"}


def analyze_coverage(
    catalog: Mapping[str, Any],
    cases: Iterable[Mapping[str, Any]],
    mapping: Iterable[Mapping[str, Any]],
    requirements: Iterable[Mapping[str, Any]] = (),
) -> dict[str, Any]:
    catalog = dict(catalog or {})
    reqs = [dict(r) for r in requirements]
    req_by_id = {str(r.get("id", "")).strip(): r for r in reqs if str(r.get("id", "")).strip()}
    case_list = list(cases or [])
    mapping_list = list(mapping or [])
    req_of_case: dict[str, str] = {}
    for case in case_list:
        rid = str((case.get("requirement_ids") or [""])[0])
        if rid:
            req_of_case[str(case.get("case_id", ""))] = rid

    scenarios = {str(s["id"]): dict(s) for s in catalog.get("scenarios", [])}
    domains = {str(d["id"]): dict(d) for d in catalog.get("domains", [])}
    scenario_stats = {
        sid: {"id": sid, "domain": s.get("domain"), "name": s.get("name"), "requirement_ids": [], "case_ids": [], "status": "UNCOVERED"}
        for sid, s in scenarios.items()
    }
    for case in case_list:
        sid = str(case.get("scenario_id", ""))
        if sid in scenario_stats:
            scenario_stats[sid]["case_ids"].append(str(case.get("case_id", "")))
    for entry in mapping_list:
        sid = str(entry.get("scenario_id", ""))
        rid = str(entry.get("requirement_id", ""))
        if sid in scenario_stats and rid:
            if rid not in scenario_stats[sid]["requirement_ids"]:
                scenario_stats[sid]["requirement_ids"].append(rid)
    for stat in scenario_stats.values():
        if stat["case_ids"]:
            stat["status"] = "COVERED"

    domain_stats = []
    for did, dom in domains.items():
        sc_ids = [sid for sid, s in scenario_stats.items() if s["domain"] == did]
        covered = [sid for sid in sc_ids if scenario_stats[sid]["status"] == "COVERED"]
        req_ids = sorted({r for sid in covered for r in scenario_stats[sid]["requirement_ids"]})
        case_ids = sorted({c for sid in covered for c in scenario_stats[sid]["case_ids"]})
        domain_stats.append({
            "id": did, "name": dom.get("name"), "scenario_count": len(sc_ids),
            "covered_scenario_count": len(covered),
            "requirement_ids": req_ids, "case_ids": case_ids,
            "status": "COVERED" if covered else "UNCOVERED",
        })

    anchor_stats = []
    for rid, req in sorted(req_by_id.items()):
        entry = next((m for m in mapping_list if str(m.get("requirement_id")) == rid), None)
        case_ids = [c["case_id"] for c in case_list if rid in (c.get("requirement_ids") or [])]
        claim = str(req.get("claim") or "").strip()
        claim_kind = str(req.get("claim_kind") or "user-provided").strip()
        # section-title 类锚点即使带占位文本也视为低可测性（无行为级判定点）。
        testable = claim_kind not in LOW_TESTABILITY_KINDS and bool(claim)
        anchor_stats.append({
            "requirement_id": rid,
            "title": req.get("title", rid),
            "domain": req.get("domain"),
            "scenario_id": (entry or {}).get("scenario_id"),
            "derived_case_count": len(case_ids),
            "claim_kind": claim_kind,
            "testable": testable,
            "note": req.get("note", ""),
        })

    uncovered_scenarios = [s for s in scenario_stats.values() if s["status"] == "UNCOVERED"]
    low_testability = [a for a in anchor_stats if not a["testable"]]
    total_scenarios = len(scenario_stats)
    covered_scenarios = total_scenarios - len(uncovered_scenarios)
    return {
        "schema_version": "cybersecurity-coverage/v0.1",
        "domains": domain_stats,
        "scenarios": sorted(scenario_stats.values(), key=lambda s: s["id"]),
        "requirement_anchors": anchor_stats,
        "summary": {
            "domain_total": len(domain_stats),
            "domain_covered": sum(1 for d in domain_stats if d["status"] == "COVERED"),
            "scenario_total": total_scenarios,
            "scenario_covered": covered_scenarios,
            "scenario_uncovered": len(uncovered_scenarios),
            "requirement_count": len(req_by_id),
            "low_testability_anchor_count": len(low_testability),
        },
        "uncovered_scenarios": uncovered_scenarios,
        "optimization_notes": [
            *(f"场景 {s['id']}（{s['name']}）无需求锚点与派生用例" for s in uncovered_scenarios),
            *(f"需求 {a['requirement_id']} 为章节标题级锚点，可测性低：需用 REQ-LIST 细化行为条目" for a in low_testability),
        ],
        "policy": {"design_time_only": True, "no_hardware_verification": True},
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="网络安全框架覆盖度与质量分析")
    parser.add_argument("--catalog", default=None, help="cybersecurity_catalog.json 路径（缺省用技能内置目录）")
    parser.add_argument("--cases", required=True, help="generated_security_cases.json")
    parser.add_argument("--requirements", required=True, help="安全需求锚点 JSON")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    catalog = load_catalog() if not args.catalog else json.loads(Path(args.catalog).read_text(encoding="utf-8"))
    cases = json.loads(Path(args.cases).read_text(encoding="utf-8"))
    requirements = json.loads(Path(args.requirements).read_text(encoding="utf-8"))
    result = analyze_coverage(catalog, cases.get("cases", []), cases.get("mapping", []), requirements.get("requirements", []))
    Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    s = result["summary"]
    print(f"域 {s['domain_covered']}/{s['domain_total']} 覆盖 | 场景 {s['scenario_covered']}/{s['scenario_total']} 覆盖 | 缺口 {s['scenario_uncovered']} | 低可测性锚点 {s['low_testability_anchor_count']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
