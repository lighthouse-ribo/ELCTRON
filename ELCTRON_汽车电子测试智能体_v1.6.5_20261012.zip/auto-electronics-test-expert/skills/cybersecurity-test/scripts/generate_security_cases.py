# -*- coding: utf-8 -*-
"""需求锚点 + 参考模式 + 变异派生的网络安全用例生成。

不照搬参考 Excel 的既有用例：参考 Excel 只提供“写作模式”（正向功能、
错误推测/重放/过期、边界、扫描、模糊、恢复、证据）与方法学词汇。生成器
逐条绑定真实安全需求 ID，按需求文本命中的风险轴派生用例，并在每条用例的
derivation 中记录来源需求、参考模式、变异轴和推导理由。
"""
from __future__ import annotations

import re
from typing import Any, Iterable, Mapping, Sequence

from security_framework import load_catalog

REQUIREMENT_STATUS_READY = "READY"
_WORD_RE_CACHE: dict[str, re.Pattern] = {}


def _kw_hits(lower_text: str, keyword: str) -> int:
    """英文关键词按词边界匹配（避免 lock 命中 block cipher），中文按子串匹配。"""
    token = str(keyword).lower()
    if token.isascii():
        pattern = _WORD_RE_CACHE.get(token)
        if pattern is None:
            pattern = re.compile(r"(?<![0-9a-z])" + re.escape(token) + r"(?![0-9a-z])")
            _WORD_RE_CACHE[token] = pattern
        return len(pattern.findall(lower_text))
    return lower_text.count(token)


class _Pattern:
    __slots__ = ("axis", "kind", "test_type", "design_method", "keywords", "procedure", "expected", "evidence")

    def __init__(self, axis, kind, test_type, design_method, keywords, procedure, expected, evidence):
        self.axis = axis
        self.kind = kind
        self.test_type = test_type
        self.design_method = design_method
        self.keywords = keywords
        self.procedure = procedure
        self.expected = expected
        self.evidence = evidence


# 参考 Excel「网络安全」工作表的写作模式库（来源：source_cases.json 覆盖摘要，
# 仅描述“怎么写”，不携带任何具体用例内容）。
REFERENCE_PATTERNS = (
    _Pattern("authentication", "positive", "功能测试", "需求分析法",
             ("认证", "安全访问", "seed", "0x27", "authentication", "request seed", "send key"),
             "按需求流程完成安全访问认证请求并采集响应",
             "认证流程满足需求约束；Seed/Key 只记录长度、哈希或受控引用",
             ("request_response_trace", "timestamp", "session")),
    _Pattern("authentication", "negative", "漏洞扫描", "错误推测法",
             ("错误密钥", "错误 key", "锁定", "次数限制", "延迟", "false attempt", "delay", "lock", "negative response"),
             "连续/间隔发送错误密钥或触发计数阈值，观察锁定与延迟行为",
             "达到阈值后进入需求定义的延迟或锁定，未授权状态不产生越权副作用",
             ("attempt_count", "nrc_or_status", "lockout_timing")),
    _Pattern("authentication", "negative", "漏洞扫描", "错误推测法",
             ("重放", "跨会话", "回放", "replay", "reuse"),
             "重放历史认证消息或跨会话认证数据",
             "重放被拒绝，会话/计数器失效并留下可追溯记录",
             ("replay_log", "session_counter", "timestamp")),
    _Pattern("authentication", "boundary", "漏洞扫描", "边界值",
             ("过期", "时效", "nonce", "时间戳", "validity", "expire", "expired", "timeout"),
             "在有效期边界前后发送认证消息或携带旧 nonce/时间戳",
             "过期或陈旧消息被拒绝，边界行为与安全需求一致",
             ("boundary_trace", "timestamp")),
    _Pattern("cryptography", "positive", "功能测试", "需求分析法",
             ("密钥", "hsm", "aes", "cmac", "ctr", "rsa", "sha", "签名", "key protection", "公钥", "私钥", "symmetric", "key storage", "confidential"),
             "通过受控 provider 使用密钥/算法完成目标操作",
             "操作成功且密钥不可明文导出；调用和审计记录完整",
             ("operation_result", "audit_log", "secret_handling")),
    _Pattern("cryptography", "boundary", "漏洞扫描", "边界值",
             ("公钥", "私钥", "密钥泄露", "导出", "明文"),
             "尝试导出/读取/回显受保护密钥或私钥",
             "导出被拒绝，敏感材料不以明文出现在日志或交付物",
             ("scan_result", "leakage_check")),
    _Pattern("secure_boot", "positive", "功能测试", "功能相关性分析",
             ("启动", "sbl", "pbl", "app", "验签", "完整性"),
             "按启动链顺序采集逐级验签与跳转证据",
             "每一级仅接受授权的下一级，链路完整才进入运行",
             ("boot_trace", "signature_result", "jump_log")),
    _Pattern("secure_boot", "negative", "漏洞扫描", "错误推测法",
             ("篡改", "拒绝启动", "完整性破坏"),
             "篡改启动镜像或签名关联数据后重新上电",
             "启动被拒绝或进入安全恢复，不运行被篡改软件",
             ("tamper_log", "boot_result", "recovery_state")),
    _Pattern("secure_update", "positive", "功能测试", "需求分析法",
             ("刷写", "下载", "更新", "镜像", "哈希", "签名", "swdl", "vbf"),
             "对目标镜像执行签名/哈希校验后再进入更新流程",
             "校验通过才允许更新；校验算法与镜像标识可追溯",
             ("image_hash", "signature_result", "update_trace")),
    _Pattern("secure_update", "negative", "漏洞扫描", "错误推测法",
             ("防回滚", "旧版本", "版本计数器", "降级", "rollback", "version counter", "lower version"),
             "尝试刷写版本计数器更低或旧的镜像",
             "旧镜像被拒绝且不改变当前有效版本",
             ("version_counter", "update_result")),
    _Pattern("secure_update", "boundary", "漏洞扫描", "边界值",
             ("计数器边界", "溢出", "回绕", "版本边界"),
             "验证版本计数器最小值、最大值、溢出与跳变",
             "边界处理符合需求，不发生绕过或回绕",
             ("counter_trace", "boundary_result")),
    _Pattern("debug", "positive", "功能测试", "需求分析法",
             ("调试", "jtag", "swd", "量产", "锁止", "debug"),
             "在量产/目标状态下核对调试接口状态与访问认证",
             "未授权调试访问被锁止，接口状态读数符合制造状态",
             ("debug_state", "access_result")),
    _Pattern("robustness", "negative", "漏洞扫描", "错误推测法",
             ("非指定", "扫描", "未声明服务", "非法子功能", "异常长度"),
             "发送未声明服务、非法子功能或异常长度请求",
             "服务不越权、不崩溃，返回受控响应",
             ("scan_trace", "responses", "no_crash_evidence")),
    _Pattern("robustness", "fuzz", "模糊测试", "等价类",
             ("模糊", "变异", "拒绝服务", "高频", "异常输入"),
             "对目标字段做受控变异或高频/异常请求注入",
             "ECU 不失控复位、不泄露敏感信息，且能在规定时间恢复",
             ("fuzz_inputs", "crash_log", "recovery_time")),
    _Pattern("evidence", "positive", "功能测试", "需求分析法",
             ("泄露", "自检", "审计", "日志", "事件", "供应链"),
             "对交付物执行敏感信息与密钥泄露自检",
             "命中项可追溯，真实秘密不进入源码/日志/报告/压缩包",
             ("scan_result", "finding_list", "disposition")),
)


SCENARIO_AXIS = {
    "CS-01": "authentication", "CS-02": "authentication", "CS-03": "authentication", "CS-04": "authentication",
    "CS-05": "cryptography", "CS-06": "cryptography", "CS-07": "cryptography",
    "CS-08": "secure_boot", "CS-09": "secure_boot",
    "CS-10": "secure_update", "CS-11": "secure_update", "CS-12": "secure_update",
    "CS-13": "debug",
    "CS-14": "robustness", "CS-15": "robustness", "CS-16": "robustness",
    "CS-17": "evidence", "CS-18": "evidence",
}


def _axis_for_domain(domain: str, scenario_names: Mapping[str, str], scenario_id: str | None = None) -> tuple[str, str, str]:
    if scenario_id and scenario_id in scenario_names:
        sid = scenario_id
        return SCENARIO_AXIS.get(sid, "robustness"), sid, scenario_names[sid]
    mapping = {
        "WD-01": ("attack_surface", "CS-01", "资产边界与攻击面"),
        "WD-02": ("authentication", "CS-01", "安全访问与诊断授权"),
        "WD-03": ("cryptography", "CS-06", "密钥、证书与信任根"),
        "WD-04": ("secure_boot", "CS-08", "安全启动与运行时完整性"),
        "WD-05": ("secure_update", "CS-10", "安全刷写与软件更新"),
        "WD-06": ("debug", "CS-13", "调试接口与制造状态"),
        "WD-07": ("authentication", "CS-03", "随机数、重放与时效性"),
        "WD-08": ("robustness", "CS-15", "鲁棒性、可用性与恢复"),
        "WD-09": ("evidence", "CS-17", "供应链、运营与事件证据"),
    }
    axis, scenario_id_default, _ = mapping.get(domain, ("robustness", "CS-15", "鲁棒性、可用性与恢复"))
    return axis, scenario_id_default, scenario_names.get(scenario_id_default, scenario_id_default)


def _match_patterns(text: str) -> tuple[_Pattern, ...]:
    """参考模式库按（需求文本+标题）关键字命中；未命中返回空（由调用方走语义轴兜底）。"""
    lower = (text or "").lower()
    hits = [p for p in REFERENCE_PATTERNS if any(_kw_hits(lower, k) > 0 for k in p.keywords)]
    return tuple(hits)


def _fallback_pattern(axis: str) -> _Pattern:
    if axis in {"cryptography", "secure_boot", "secure_update", "debug"}:
        fallback = ("功能测试", "需求分析法", "按需求核对受保护属性的访问控制与状态", "未授权或不符合需求的行为被拒绝且可追溯")
    else:
        fallback = ("功能测试", "需求分析法", "按需求执行目标安全功能", "结果满足需求并可追溯；未执行不宣称 PASS")
    return _Pattern(axis, "positive", fallback[0], fallback[1], (), fallback[2], fallback[3], ("trace", "timestamp"))


def _norm_requirement(item: Mapping[str, Any]) -> dict[str, Any]:
    rid = str(item.get("id") or item.get("requirement_id") or "").strip()
    return {
        "id": rid,
        "title": str(item.get("title") or rid).strip(),
        "claim": str(item.get("claim") or item.get("text") or item.get("description") or "").strip(),
        "domain": str(item.get("domain") or "").strip() or "WD-08",
        "scenario_id": str(item.get("scenario_id") or "").strip() or None,
    }


def build_cases(
    *,
    requirements: Iterable[Mapping[str, Any]] = (),
    bus: str = "LIN",
    env: str = "台架测试",
) -> dict:
    """逐条绑定真实安全需求，按参考模式派生正例与变异用例。

    requirements 为空或含无 id 需求时返回 BLOCKED，不生成任何“无锚点”用例。
    """
    catalog = load_catalog()
    scenario_names = {s["id"]: s["name"] for s in catalog["scenarios"]}
    reqs = [_norm_requirement(r) for r in requirements]
    invalid = [r for r in reqs if not r["id"]]
    reqs = [r for r in reqs if r["id"]]
    if not reqs:
        return {
            "schema_version": "cybersecurity-case-bundle/v0.1",
            "module": "网络安全",
            "generation_status": "BLOCKED",
            "errors": ["缺少真实安全需求（需求清单为空或全部无 ID）：不得生成无需求锚点的安全用例"],
            "cases": [],
            "mapping": [],
        }

    cases: list[dict[str, Any]] = []
    mapping: list[dict[str, Any]] = []
    seq = 0
    for req in reqs:
        axis, scenario_id, scenario_name = _axis_for_domain(req["domain"], scenario_names, req.get("scenario_id"))
        text = " ".join(filter(None, (req["claim"], req["title"])))
        lower = text.lower()
        patterns = list(_match_patterns(text) or (_fallback_pattern(axis),))
        # 同一需求只保留一条正向：按关键词命中数择优（更贴合需求语义轴）。
        positives = [p for p in patterns if p.kind == "positive"]
        negatives = [p for p in patterns if p.kind != "positive"]
        if positives:
            best = max(positives, key=lambda p: sum(_kw_hits(lower, k) for k in p.keywords))
            patterns = [best] + negatives
        has_positive = False
        for pattern in patterns:
            kind = pattern.kind
            if kind == "positive":
                if has_positive:
                    continue
                has_positive = True
            seq += 1
            if kind == "positive":
                test_point = f"{req['title']}：正向验证"
                procedure = f"{pattern.procedure}（需求：{req['id']}）"
                expected = f"{pattern.expected}；以需求 {req['id']} 的判定条件为准"
                status = "PLANNED"
            else:
                test_point = f"{req['title']}：{kind}（{pattern.axis} 轴）"
                procedure = f"{pattern.procedure}（对需求 {req['id']} 的变异输入）"
                expected = f"{pattern.expected}；判定锚点：{scenario_name}"
                status = "PLANNED"
            derivation = [{
                "kind": "requirement-to-reference-mapping",
                "source_requirement": req["id"],
                "domain": req["domain"],
                "scenario_id": scenario_id,
                "base_pattern": f"{pattern.axis}/{kind}",
                "axis": pattern.axis,
                "reason": f"需求文本/标题命中参考模式关键词；按参考 Excel「网络安全」工作表写作逻辑派生为{kind}用例，不照搬参考用例内容",
            }]
            cases.append({
                "case_id": f"TG1_TC{seq:02d}_SC1",
                "scenario_id": scenario_id,
                "scenario": scenario_name,
                "requirement_ids": [req["id"]],
                "priority": "L1" if kind == "positive" else "L2",
                "auto_eval": "否",
                "test_point": test_point,
                "test_method": pattern.test_type,
                "design_method": pattern.design_method,
                "bus": bus,
                "env": env,
                "precondition": (
                    f"1. 已确认需求 {req['id']} 与安全测试授权；\n"
                    "2. 真实密钥/证书/镜像仅通过受控引用提供；\n"
                    "3. 未授权或材料缺失时禁止实机执行。"
                ),
                "procedure": procedure,
                "expected": expected,
                "status": status,
                "execution_verdict": "NOT_EXECUTED",
                "evidence_required": list(pattern.evidence),
                "derivation": derivation,
            })
        mapping.append({
            "requirement_id": req["id"],
            "domain": req["domain"],
            "scenario_id": scenario_id,
            "axis": axis,
            "derived_case_ids": [c["case_id"] for c in cases if req["id"] in c["requirement_ids"]],
        })
    return {
        "schema_version": "cybersecurity-case-bundle/v0.1",
        "module": "网络安全",
        "generation_status": REQUIREMENT_STATUS_READY,
        "errors": [],
        "cases": cases,
        "mapping": mapping,
        "policy": {
            "lin_means_transport_only": True,
            "unexecuted_verdict": "NOT_EXECUTED",
            "source_workbook_read_only": True,
        },
    }
