# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from coverage import analyze_coverage
from generate_security_cases import build_cases
from security_framework import build_framework, evaluate_inputs, gate_status, load_catalog
from security_scan import scan_path

SAMPLE_REQUIREMENTS = (
    {"id": "REQ-9.1", "title": "SecurityAccess Gen2 认证", "claim": "ECU 通过 0x27 Gen2 完成安全访问认证，Seed/Key 满足 AES-128-CTR 与 AES-CMAC 算法约束。", "domain": "WD-02"},
    {"id": "REQ-9.2", "title": "刷写镜像签名与防回滚", "claim": "ECU 仅接受签名有效的 SWDL/VBF 镜像，并拒绝低于当前版本计数器的镜像。", "domain": "WD-05"},
    {"id": "REQ-9.3", "title": "量产态调试接口锁止", "claim": "量产状态下 JTAG/SWD 调试接口必须锁止，未授权访问被拒绝。", "domain": "WD-06"},
)


class CybersecurityFrameworkTests(unittest.TestCase):
    def test_catalog_has_nine_domains_and_eighteen_scenarios(self):
        catalog = load_catalog()
        self.assertEqual(len(catalog["domains"]), 9)
        self.assertEqual(len(catalog["scenarios"]), 18)

    def test_missing_inputs_never_become_execution_ready(self):
        readiness = evaluate_inputs({})
        self.assertEqual(readiness["overall_status"], "DEGRADED")
        self.assertTrue(readiness["blockers"])
        self.assertEqual(gate_status("PASS", evidence_complete=False, executed=False), "PLANNED")

    def test_empty_requirements_are_blocked_without_anchorless_cases(self):
        result = build_cases()
        self.assertEqual(result["generation_status"], "BLOCKED")
        self.assertEqual(result["cases"], [])
        self.assertTrue(result["errors"])

    def test_cases_are_logical_mapping_not_copy(self):
        result = build_cases(requirements=SAMPLE_REQUIREMENTS, bus="LIN")
        self.assertEqual(result["generation_status"], "READY")
        self.assertTrue(result["cases"])
        scenario_ids = {s["id"] for s in load_catalog()["scenarios"]}
        for case in result["cases"]:
            self.assertTrue(case["case_id"].startswith("TG1_TC"))
            self.assertFalse(case["case_id"].startswith("LIN-"))
            self.assertEqual(case["requirement_ids"], [case["derivation"][0]["source_requirement"]])
            self.assertIn(case["scenario_id"], scenario_ids)
            self.assertEqual(case["status"], "PLANNED")
            derivation = case["derivation"][0]
            self.assertEqual(derivation["kind"], "requirement-to-reference-mapping")
            self.assertTrue(derivation["base_pattern"])
            self.assertTrue(derivation["axis"])
            self.assertIn("派生", derivation["reason"])
        mapped = {item["requirement_id"]: item["derived_case_ids"] for item in result["mapping"]}
        self.assertEqual(set(mapped), {r["id"] for r in SAMPLE_REQUIREMENTS})
        self.assertTrue(all(mapped[rid] for rid in mapped))

    def test_no_duplicate_positive_or_test_point_per_requirement(self):
        result = build_cases(requirements=SAMPLE_REQUIREMENTS, bus="LIN")
        by_req: dict[str, list] = {}
        for case in result["cases"]:
            by_req.setdefault(case["requirement_ids"][0], []).append(case)
        for rid, items in by_req.items():
            positives = [c for c in items if c["derivation"][0]["base_pattern"].endswith("/positive")]
            self.assertLessEqual(len(positives), 1, f"{rid} 存在重复正向用例")
            test_points = [c["test_point"] for c in items]
            self.assertEqual(len(test_points), len(set(test_points)), f"{rid} 存在重复测试点")

    def test_coverage_reports_scenario_gaps_and_anchor_testability(self):
        catalog = load_catalog()
        requirements = [
            {"id": "REQ-9.4", "title": "量产态调试锁止", "claim": "量产状态下 JTAG/SWD 调试接口必须锁止。", "domain": "WD-06"},
            {"id": "REQ-9.5", "title": "刷写防回滚", "claim": "ECU 拒绝版本计数器更低的镜像。", "domain": "WD-05", "claim_kind": "section-title"},
        ]
        cases = build_cases(requirements=requirements, bus="LIN")
        coverage = analyze_coverage(catalog, cases["cases"], cases["mapping"], requirements)
        self.assertEqual(coverage["summary"]["scenario_total"], 18)
        self.assertGreaterEqual(coverage["summary"]["scenario_uncovered"], 1)
        self.assertEqual(coverage["summary"]["requirement_count"], 2)
        anchors = {a["requirement_id"]: a for a in coverage["requirement_anchors"]}
        self.assertTrue(anchors["REQ-9.4"]["testable"])
        self.assertFalse(anchors["REQ-9.5"]["testable"])
        self.assertTrue(coverage["optimization_notes"])
        self.assertTrue(coverage["policy"]["design_time_only"])

    def test_scan_reports_pattern_without_secret_value(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.py"
            path.write_text("private_key = 'not-a-real-key-value'\n", encoding="utf-8")
            result = scan_path(tmp)
            self.assertEqual(result["status"], "BLOCKED")
            self.assertNotIn("not-a-real-key-value", json.dumps(result))


if __name__ == "__main__":
    unittest.main()
