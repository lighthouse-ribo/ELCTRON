# -*- coding: utf-8 -*-
"""Build a self-contained, read-only cybersecurity framework report (design-time)."""
from __future__ import annotations

import argparse
import html
import json
import sys
from pathlib import Path

_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))

from project_config import project_identity  # noqa: E402


def _rows(rows):
    return "".join(rows)


def _scenario_rows(coverage: dict) -> str:
    cells = []
    for s in coverage["scenarios"]:
        status_class = "status-covered" if s["status"] == "COVERED" else "status-gap"
        cells.append(
            f"<tr><td>{html.escape(s['id'])}</td><td>{html.escape(s['name'])}</td>"
            f"<td>{html.escape(s['domain'])}</td><td>{len(s['requirement_ids'])}</td>"
            f"<td>{len(s['case_ids'])}</td><td><b class='{status_class}'>{s['status']}</b></td></tr>"
        )
    return _rows(cells)


def _anchor_rows(coverage: dict) -> str:
    cells = []
    for a in coverage["requirement_anchors"]:
        mark = "<b class='status-ok'>可测</b>" if a["testable"] else "<b class='status-low'>低可测性</b>"
        cells.append(
            f"<tr><td>{html.escape(a['requirement_id'])}</td><td>{html.escape(str(a['title'])[:44])}</td>"
            f"<td>{html.escape(a['domain'] or '')}</td><td>{html.escape(a['scenario_id'] or '')}</td>"
            f"<td>{a['derived_case_count']}</td><td>{mark}</td></tr>"
        )
    return _rows(cells)


def _selective_rows(coverage: dict, source_map: dict) -> tuple[str, str, str]:
    wb = source_map["scenario_totals"]
    sw = {s["id"]: len(s["case_ids"]) for s in coverage["scenarios"]}
    rows = []
    in_scope = set()
    for s in coverage["scenarios"]:
        sid = s["id"]
        w = wb.get(sid, 0)
        c = sw.get(sid, 0)
        if w and c:
            origin, cls = "工作簿 + SWRS", "status-covered"
        elif w:
            origin, cls = "参考工作簿", "status-covered"
        elif c:
            origin, cls = "SWRS 锚定", "status-covered"
        else:
            origin, cls = "未覆盖（不在范围）", "status-gap"
        if w or c:
            in_scope.add(sid)
        rows.append(
            f"<tr><td>{html.escape(sid)}</td><td>{html.escape(s['name'])}</td><td>{html.escape(s['domain'])}</td>"
            f"<td>{w}</td><td>{c}</td><td><b class='{cls}'>{origin}</b></td></tr>"
        )
    scope_sorted = sorted(in_scope)
    excluded = [s["id"] for s in coverage["scenarios"] if s["id"] not in in_scope]
    statement = (
        f"选择性覆盖结论：框架最终覆盖 {len(scope_sorted)} 个场景（{', '.join(scope_sorted)}），"
        f"范围 = 参考工作簿实际覆盖 ∪ SWRS 锚定派生；目录其余场景（{', '.join(excluded)}）当前不进入交付范围。"
    )
    return _rows(rows), statement, f"<div class='notice'>{html.escape(statement)}</div>"


def build_report(framework: dict, cases: dict, scan: dict, coverage: dict | None = None, source_map: dict | None = None, project_config=None) -> str:
    identity = project_identity(project_config)
    project_id = identity["project"]
    display_name = identity["display_name"]
    page_title = f"{display_name} 网络安全测试框架"
    domains = framework["catalog"]["domains"]
    scenarios = framework["catalog"]["scenarios"]
    case_rows = "".join(
        f"<tr><td>{html.escape(c['case_id'])}</td><td>{html.escape(c['scenario_id'])}</td><td>{html.escape(c['test_point'])}</td><td><b class='status-{c['status'].lower()}'>{c['status']}</b></td></tr>"
        for c in cases["cases"]
    )
    domain_cards = "".join(f"<article><span>{d['id']}</span><h3>{html.escape(d['name'])}</h3></article>" for d in domains)

    coverage_html = ""
    if coverage:
        s = coverage["summary"]
        notes = "".join(f"<li>{html.escape(n)}</li>" for n in coverage["optimization_notes"])
        selective_rows = ""
        selective_statement = ""
        if source_map:
            selective_rows, _, selective_statement = _selective_rows(coverage, source_map)
        coverage_html = f"""
<h2>覆盖度分析（设计期）</h2>
<div class="kpis" style="grid-template-columns:repeat(5,1fr)">
<div class="kpi"><strong>{s['domain_covered']}/{s['domain_total']}</strong><small>工作域覆盖(SWRS)</small></div>
<div class="kpi"><strong>{s['scenario_covered']}/{s['scenario_total']}</strong><small>场景覆盖(SWRS)</small></div>
<div class="kpi"><strong>{source_map['total_cases'] if source_map else '-'}</strong><small>工作簿参考用例</small></div>
<div class="kpi"><strong>{sum(1 for v in (source_map['scenario_totals'] if source_map else {}).values() if v) if source_map else '-'}</strong><small>工作簿覆盖场景</small></div>
<div class="kpi"><strong>{s['low_testability_anchor_count']}</strong><small>低可测性锚点</small></div>
</div>"""
        if source_map:
            coverage_html += f"""
<h3>选择性覆盖收敛（参考工作簿 ∩ SWRS 锚定）</h3>
{selective_statement}
<section class="panel"><table><thead><tr><th>场景</th><th>名称</th><th>域</th><th>工作簿命中</th><th>SWRS派生</th><th>覆盖来源</th></tr></thead><tbody>{selective_rows}</tbody></table></section>"""
        coverage_html += f"""
<h3>场景覆盖矩阵（SWRS 派生）</h3>
<section class="panel"><table><thead><tr><th>场景</th><th>名称</th><th>域</th><th>需求数</th><th>用例数</th><th>状态</th></tr></thead><tbody>{_scenario_rows(coverage)}</tbody></table></section>
<h3>需求锚点可测性</h3>
<section class="panel"><table><thead><tr><th>需求</th><th>标题</th><th>域</th><th>场景</th><th>派生用例</th><th>可测性</th></tr></thead><tbody>{_anchor_rows(coverage)}</tbody></table></section>
<section class="panel"><h3>优化提示</h3><ul>{notes or '<li>暂无缺口，可直接进入用例细化</li>'}</ul></section>"""

    return f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>{html.escape(page_title)}</title>
<style>
:root{{--bg:#f5f7fb;--ink:#182230;--muted:#64748b;--line:#dbe3ef;--blue:#1456d9;--teal:#087f73;--amber:#a15c00;--red:#b42318}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:14px/1.6 Segoe UI,Microsoft YaHei,sans-serif}}main{{max-width:1240px;margin:0 auto;padding:34px}}header{{background:#10254a;color:#fff;border-radius:22px;padding:32px 36px;box-shadow:0 14px 34px #10254a24}}h1{{margin:0 0 8px;font-size:30px}}h2{{margin:34px 0 14px}}h3{{margin:20px 0 10px;font-size:15px}}.sub{{color:#c9d7ef}}.kpis{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:22px}}.kpi,.panel,article{{background:#fff;border:1px solid var(--line);border-radius:14px;padding:16px}}.kpi strong{{display:block;font-size:27px;color:var(--blue)}}.kpi small,.muted{{color:var(--muted)}}.grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}}article span{{font-size:12px;color:var(--blue);font-weight:700}}table{{width:100%;border-collapse:collapse;background:#fff;border:1px solid var(--line);border-radius:14px;overflow:hidden}}th,td{{padding:11px 13px;border-bottom:1px solid var(--line);text-align:left}}th{{background:#edf3ff;color:#27436e}}.status-planned{{color:var(--amber)}}.status-blocked{{color:var(--red)}}.status-pass{{color:var(--teal)}}.status-covered{{color:var(--teal)}}.status-gap{{color:var(--red)}}.status-ok{{color:var(--teal)}}.status-low{{color:var(--amber)}}.notice{{border-left:4px solid var(--amber);background:#fff8e8;padding:14px 16px;border-radius:8px}}@media(max-width:800px){{main{{padding:18px}}.kpis,.grid{{grid-template-columns:1fr}}}}
</style><main><header><div class="sub">{html.escape(project_id)} · Automotive Cybersecurity Test Framework · Design-Time Only</div><h1>网络安全测试框架</h1><div class="sub">源 Excel 与 SRS 仅作只读输入｜用例为需求→参考模式逻辑映射｜无实机验证｜不虚构 PASS/FAIL</div><div class="kpis"><div class="kpi"><strong>{framework['source_cases']['count']}</strong><small>源用例（手工确认，只读）</small></div><div class="kpi"><strong>{len(domains)}</strong><small>测试工作域</small></div><div class="kpi"><strong>{len(scenarios)}</strong><small>安全场景</small></div><div class="kpi"><strong>{scan['status']}</strong><small>敏感信息扫描</small></div></div></header><h2>输入与门禁</h2><div class="notice">{html.escape('；'.join(framework['readiness']['blockers']) or '输入齐备')}</div>{coverage_html}<h2>9 个测试工作域</h2><section class="grid">{domain_cards}</section><h2>派生用例（{len(cases['cases'])} 条，逻辑映射）</h2><section class="panel"><table><thead><tr><th>用例</th><th>场景</th><th>测试点</th><th>状态</th></tr></thead><tbody>{case_rows}</tbody></table></section><h2>交付边界</h2><p class="muted">本框架为设计期优化产物，不连接硬件执行。网络安全中的 LIN 只表示承载通道，不生成 LIN-* 帧/信号/调度用例；正式 REQ 编号与密钥/证书/镜像均以受控引用方式接入，缺失即 BLOCKED/低可测性提示。</p></main></html>'''


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--framework", required=True)
    parser.add_argument("--cases", required=True)
    parser.add_argument("--scan", required=True)
    parser.add_argument("--coverage", default=None)
    parser.add_argument("--source-map", default=None, help="参考工作簿选择性覆盖 JSON（source_case_scenarios.json）")
    parser.add_argument("--out", required=True)
    parser.add_argument("--project-config", default="", help="项目配置 JSON（可选）；决定报告抬头项目名")
    args = parser.parse_args()
    framework = json.loads(Path(args.framework).read_text(encoding="utf-8"))
    cases = json.loads(Path(args.cases).read_text(encoding="utf-8"))
    scan = json.loads(Path(args.scan).read_text(encoding="utf-8"))
    coverage = json.loads(Path(args.coverage).read_text(encoding="utf-8")) if args.coverage else None
    source_map = json.loads(Path(args.source_map).read_text(encoding="utf-8")) if args.source_map else None
    Path(args.out).write_text(build_report(framework, cases, scan, coverage, source_map,
                                           project_config=args.project_config or None), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
