# -*- coding: utf-8 -*-
"""参考工作簿网络安全用例的选择性覆盖分析（只读，不修改源文件）。

按“测试用例实际覆盖”而非理论场景目录来决定框架覆盖范围：解析工作簿
“网络安全”工作表每条用例的测试点/方法，归类到 CS 场景与工作域，输出
每场景覆盖计数与映射证据，供框架做选择性覆盖收敛。
"""
from __future__ import annotations

import argparse
import io
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Any, Iterable

_SKILLS_DIR = Path(__file__).resolve().parents[2]
if str(_SKILLS_DIR) not in sys.path:
    sys.path.insert(0, str(_SKILLS_DIR))

from project_config import project_identity  # noqa: E402

SHEET_NAME_HINT = "网络安全"

SCENARIO_KEYWORDS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("CS-01", ("认证", "seed", "0x27", "security access", "解锁", "authentication")),
    ("CS-02", ("错误", "失败", "锁定", "次数", "延迟", "false", "invalid key", "lock")),
    ("CS-03", ("重放", "replay", "跨会话")),
    ("CS-04", ("过期", "时效", "validity", "expire")),
    ("CS-05", ("证书", "certificate", "信任链", "chain")),
    ("CS-06", ("密钥", "key storage", "hsm", "aes", "cmac", "ctr", "rsa", "symmetric")),
    ("CS-07", ("可信根", "root of trust", "读写保护")),
    ("CS-08", ("启动链", "sbl", "pbl", "app 验签", "boot")),
    ("CS-09", ("篡改", "tamper", "拒绝启动")),
    ("CS-10", ("签名", "哈希", "镜像", "vbf", "swdl", "software download", "校验")),
    ("CS-11", ("防回滚", "旧版本", "rollback")),
    ("CS-12", ("版本计数器", "计数器边界", "version counter")),
    ("CS-13", ("jtag", "swd", "调试", "debug", "量产")),
    ("CS-14", ("非指定服务", "服务扫描", "未授权服务", "非法子功能")),
    ("CS-15", ("拒绝服务", "dos", "高频")),
    ("CS-16", ("模糊", "fuzz", "变异")),
    ("CS-17", ("密钥泄露", "泄露", "自检", "leak")),
    ("CS-18", ("日志", "审计", "事件证据", "供应链", "audit")),
)

DOMAIN_BY_SCENARIO = {
    "CS-01": "WD-02", "CS-02": "WD-02", "CS-03": "WD-07", "CS-04": "WD-07",
    "CS-05": "WD-03", "CS-06": "WD-03", "CS-07": "WD-03",
    "CS-08": "WD-04", "CS-09": "WD-04",
    "CS-10": "WD-05", "CS-11": "WD-05", "CS-12": "WD-05",
    "CS-13": "WD-06", "CS-14": "WD-02", "CS-15": "WD-08", "CS-16": "WD-08",
    "CS-17": "WD-09", "CS-18": "WD-09",
}


def _sheet_xml_and_strings(raw: bytes) -> tuple[str, list[str]]:
    z = zipfile.ZipFile(io.BytesIO(raw))
    wb = z.read("xl/workbook.xml").decode("utf-8", "ignore")
    rels = z.read("xl/_rels/workbook.xml.rels").decode("utf-8", "ignore")
    rid_to_target = dict(re.findall(r'<Relationship[^>]*Id="(rId\d+)"[^>]*Target="([^"]+)"', rels))
    target = None
    for m in re.finditer(r'<sheet[^>]*name="([^"]+)"[^>]*r:id="(rId\d+)"', wb):
        if SHEET_NAME_HINT in m.group(1):
            target = rid_to_target.get(m.group(2))
            break
    if not target:
        raise ValueError(f"未找到含 {SHEET_NAME_HINT} 的工作表")
    xml = z.read("xl/" + target).decode("utf-8", "ignore")
    strings = []
    if "xl/sharedStrings.xml" in z.namelist():
        ss = z.read("xl/sharedStrings.xml").decode("utf-8", "ignore")
        for s in re.findall(r"<si>(.*?)</si>", ss, re.S):
            strings.append("".join(re.findall(r"<t[^>]*>([^<]*)</t>", s)))
    return xml, strings


def _cell_attributes(tag: str) -> dict[str, str]:
    return dict(re.findall(r'([A-Za-z]+)="([^"]*)"', tag))


def _cell_value(cell: str, strings: list[str]) -> str:
    attrs = _cell_attributes(cell[: cell.find(">") + 1])
    value = ""
    vm = re.search(r"<v>([^<]*)</v>", cell)
    raw_v = vm.group(1) if vm else ""
    if attrs.get("t") == "s":
        try:
            idx = int(raw_v)
            value = strings[idx] if 0 <= idx < len(strings) else ""
        except ValueError:
            value = ""
    elif attrs.get("t") == "inlineStr":
        value = "".join(re.findall(r"<t[^>]*>([^<]*)</t>", cell))
    else:
        value = raw_v
    return value.strip()


def parse_rows(raw: bytes) -> list[dict[str, str]]:
    xml, strings = _sheet_xml_and_strings(raw)
    rows: list[dict[str, str]] = []
    for row in re.finditer(r"<row[^>]*r=\"(\d+)\"[^>]*>(.*?)</row>", xml, re.S):
        row_number = int(row.group(1))
        cells: dict[str, str] = {}
        for cell in re.finditer(r"<c\b[^>]*>.*?</c>", row.group(2), re.S):
            tag = cell.group(0)
            attrs = _cell_attributes(tag[: tag.find(">") + 1])
            ref = attrs.get("r", "")
            if not ref:
                continue
            value = _cell_value(tag, strings)
            if value:
                cells[ref] = value
        rows.append({"row": row_number, "cells": cells})
    return rows


def classify(text: str) -> tuple[list[str], list[str]]:
    low = (text or "").lower()
    scenarios, evidence = [], []
    for sid, kws in SCENARIO_KEYWORDS:
        hit = [k for k in kws if k.lower() in low]
        if hit:
            scenarios.append(sid)
            evidence.append(f"{sid}<={hit[0]}")
    return scenarios, evidence


def analyze(rows: Iterable[dict[str, Any]], source_workbook: str = "") -> dict[str, Any]:
    cases = []
    for row in rows:
        cells = row["cells"]
        text = " ".join(cells.values())
        case_id = next((v for k, v in cells.items() if k.startswith("D")), "") or next(iter(cells.values()), "")
        if not case_id:
            continue
        scenarios, evidence = classify(text)
        domain = DOMAIN_BY_SCENARIO.get(scenarios[0], "UNMAPPED") if scenarios else "UNMAPPED"
        cases.append({
            "row": row["row"],
            "case_id": case_id[:60],
            "scenario_ids": scenarios,
            "domain": domain,
            "evidence": evidence,
            "text_snapshot": text[:240],
        })
    scenario_totals = {sid: 0 for sid, _ in SCENARIO_KEYWORDS}
    domain_totals: dict[str, int] = {}
    for case in cases:
        for sid in case["scenario_ids"]:
            scenario_totals[sid] += 1
        domain_totals[case["domain"]] = domain_totals.get(case["domain"], 0) + 1
    return {
        "schema_version": "source-coverage/v0.1",
        "source_workbook": source_workbook,
        "sheet": "网络安全",
        "method_note": "只读解析；用例按文本关键词归类到 CS 场景并保留命中证据，归类不构成实测结论",
        "total_cases": len(cases),
        "unmapped_cases": [c["case_id"] for c in cases if not c["scenario_ids"]],
        "cases": cases,
        "scenario_totals": scenario_totals,
        "domain_totals": domain_totals,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="参考工作簿网络安全用例选择性覆盖分析（只读）")
    parser.add_argument("xlsx", nargs="?", default="-", help="xlsx 路径；- 表示从 stdin 读字节（DLP 环境）")
    parser.add_argument("--out", required=True)
    parser.add_argument("--rows", default="8:60", help="数据行范围（默认 8:60）")
    parser.add_argument("--source-workbook", default="",
                        help="源工作簿名称；留空时取项目配置 identity.source_workbook")
    parser.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    args = parser.parse_args()
    source_workbook = args.source_workbook or project_identity(args.project_config or None)["source_workbook"]
    raw = sys.stdin.buffer.read() if args.xlsx == "-" else Path(args.xlsx).read_bytes()
    rows = parse_rows(raw)
    lo, hi = (int(x) for x in args.rows.split(":"))
    selected = [r for r in rows if lo <= int(r["row"]) <= hi]
    result = analyze(selected, source_workbook=source_workbook)
    Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    covered = [k for k, v in result["scenario_totals"].items() if v]
    print(f"total={result['total_cases']} scenarios_covered={len(covered)} unmapped={len(result['unmapped_cases'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
