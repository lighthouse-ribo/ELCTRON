# -*- coding: utf-8 -*-
"""Build the framework bundle from the read-only source summary."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from coverage import analyze_coverage
from generate_security_cases import build_cases
from security_framework import build_framework
from security_scan import scan_path


def _load_requirements(path: str | None, ids: list[str]) -> list[dict]:
    if path:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        return list(raw.get("requirements") or raw or [])
    return [{"id": item, "title": item, "claim": "", "domain": "WD-08"} for item in ids]


def main() -> int:
    parser = argparse.ArgumentParser(description="构建汽车 ECU 网络安全框架")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--requirements", default=None, help="真实安全需求 JSON（含 requirements[]）")
    parser.add_argument("--requirement", action="append", default=[], help="仅给需求 ID 时的兜底锚点")
    parser.add_argument("--bus", default="LIN")
    parser.add_argument("--project-config", default="", help="项目配置 JSON（可选）")
    args = parser.parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    framework = build_framework(source_cases=50, project_config=args.project_config or None)
    reqs = _load_requirements(args.requirements, args.requirement)
    cases = build_cases(requirements=reqs, bus=args.bus)
    coverage = analyze_coverage(framework["catalog"], cases["cases"], cases["mapping"], reqs)
    for name, data in (("framework.json", framework), ("generated_security_cases.json", cases), ("coverage.json", coverage)):
        (out_dir / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    scan = scan_path(out_dir)
    (out_dir / "security_scan.json").write_text(json.dumps(scan, ensure_ascii=False, indent=2), encoding="utf-8")
    cov = coverage["summary"]
    print(f"framework={framework['readiness']['overall_status']} generation={cases['generation_status']} cases={len(cases['cases'])} "
          f"scenario_coverage={cov['scenario_covered']}/{cov['scenario_total']} scan={scan['status']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
