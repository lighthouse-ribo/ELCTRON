---
name: cybersecurity-test
version: "0.1.0"
agent_created: true
description: "This skill should be used when designing, generating, reviewing, or reporting automotive ECU cybersecurity tests from security requirements, TARA, the reference cybersecurity workbook, diagnostic/SWDL material, or controlled hardware evidence. It keeps cybersecurity separate from LIN network and ordinary UDS coverage."
---

# 汽车 ECU 网络安全测试技能

## 定位

将项目安全资料和参考 Excel 的写作模式转换为可追溯、可门禁、可执行的网络安全测试框架。仅把参考工作表作为**结构和覆盖输入**，不得直接照搬用例结论，不得把缺失证据写成 PASS/FAIL。

本技能独立于：

- `lin-network-test`：只负责 LIN 帧、信号、PID、校验和、调度与网络管理；
- `uds-diagnostic-test`：负责普通 UDS 服务与诊断执行；
- SWDL：负责刷写主流程，网络安全技能只验证签名、哈希、防回滚、密钥和授权安全属性。

当安全测试通过 LIN 承载时，LIN 只作为 `bus` 元数据，不能生成 `LIN-*` 用例。

## 固定框架

- 9 个工作域：资产/攻击面、安全访问、密钥证书/信任根、安全启动/运行时、安全刷写/更新、调试/制造状态、随机数/重放/时效性、鲁棒性/恢复、供应链/事件证据。
- 18 个场景：定义在 `data/cybersecurity_catalog.json`，详细说明见 `references/architecture.md`。
- 参考 Excel 摘要：`data/source_cases.json`，源工作簿只读，当前分析结果为 50 条网络安全用例；仅作为“写作模式/覆盖范围”参考，不照搬其用例内容。
- 需求清单模板：`data/security_requirements.example.json`，真实使用时替换为项目 SRS/TSR 中带编号的安全需求。

## 用例生成是“逻辑映射”，不是照搬

生成器 `scripts/generate_security_cases.py` 只把参考 Excel 当作“怎么写”的模式库（正向功能、错误推测/重放/过期、边界、扫描、模糊、恢复、证据），每条输出用例必须经过以下映射链：

```text
真实安全需求（id + 文本 + 域）
  → 需求文本命中参考模式关键词（base_pattern）
  → 派生用例（正例或变异用例，TG1_TC##_SC1）
  → derivation 记录：来源需求 + 域 + 场景锚点 + 参考模式 + 变异轴 + 推导理由
```

强制规则：

1. **没有真实需求锚点就不生成用例**：`requirements` 为空或全部无 ID 时返回 `BLOCKED` 与空用例列表，禁止产出“无源用例”。
2. 每条用例的 `requirement_ids` 与其 `derivation[0].source_requirement` 必须一致。
3. 参考 Excel 中的既有用例只用于归纳模式，不得作为输出用例的内容来源。
4. 完整追溯矩阵输出到 `mapping[]`：需求 ID → 域 → 场景 → 派生用例 ID 列表。

## 工作流程

1. **输入体检**：读取 `templates/security-input-manifest.example.json` 的角色状态；检查安全需求、TARA、授权、硬件、受控密钥引用、证书链和签名镜像。
2. **建立追溯**：把真实 `REQ/CS` ID 绑定到 `CS-*` 场景。没有真实需求 ID 时生成器返回 `BLOCKED`，不产出无锚点用例。
3. **生成用例**：调用 `generate_security_cases.py` 并传入真实需求清单；保留参考 Excel 的字段顺序：需求来源、用例 ID、优先级、自动化评估、测试点、测试方法、设计方法、环境、前提、步骤、预期、选择。
4. **逻辑映射与变异派生**：生成器按需求文本命中参考模式，从正向需求派生边界、错误推测、重放、过期、越界、篡改、扫描、模糊和恢复场景；每条用例在 `derivation` 记录来源需求、参考模式、变异轴与推导理由，不直接采用参考 Excel 的既有用例。
5. **状态门禁**：使用 `security_framework.py` 的 `gate_status`。设计完成但未执行为 `PLANNED`；缺钥/缺证书/缺镜像/缺硬件/缺授权为 `BLOCKED`；不适用才使用 `NA`；实测证据完整后才允许 `PASS/FAIL`。
6. **覆盖度与质量分析（设计期）**：执行 `scripts/coverage.py`，输出域/场景覆盖矩阵、未覆盖场景缺口、需求锚点可测性（章节标题级锚点标记低可测性）与优化提示，产物 `coverage.json` 进入报告。
7. **选择性覆盖收敛**：执行 `scripts/source_coverage.py`（只读解析参考工作簿“网络安全”工作表，用例归类到 CS 场景并保留命中证据），框架最终范围 = 工作簿实际覆盖 ∪ SWRS 锚定派生；目录其余场景不进入交付范围。
8. **敏感信息扫描**：执行 `security_scan.py`，扫描源码、脚本、日志、报告和压缩包；输出命中文件和模式，不输出秘密值。命中即 `BLOCKED`。
9. **报告和交付**：把框架 JSON、用例 JSON、覆盖 JSON、选择性覆盖 JSON、扫描 JSON 和 HTML 报告放入网络安全独立交付目录；需要交付时再按项目规范打包 ZIP。

## 设计期优化闭环（不依赖实机）

框架优化在纯设计期完成：需求锚点 → 逻辑映射派生 → 覆盖度/缺口分析 → 可测性检查 → 报告与交付。该闭环不需要连接硬件、不产生实测判定；只有"生成设计"与"状态管理"，没有 PASS/FAIL 实机统计。需要执行时另行接入硬件与授权门禁，本技能不把设计产物当作安全验证结论。

## 安全红线

- 不在 manifest、上下文、日志、HTML、JSON 或 ZIP 中写入真实密钥、私钥、Seed/Key、token 或证书私密内容。
- 不从二进制、DLL、CANoe/CAPL 或加密资料中破解、导出或猜测密钥。
- 不连接硬件执行未授权攻击、模糊测试、DoS、JTAG/SWD 或刷写篡改测试。
- 不将 `BLOCKED`、`PLANNED`、`NT`、`NA` 改写为 PASS/FAIL。
- 源 Excel 只读分析，禁止覆写用户源文件。

## 台架取证对账红线（v3.9 实测固化）

1. **新执行证据格式固定为 ASC 标准格式（python 转写）**：帧与硬件时间戳由驱动逐帧捕获；历史 ASC 或文本导出的 XCT 只能经只读导入复盘，不能反向生成本次执行证据或改判 PASS。
   ASC 仅作格式转写、校验和按 LIN 规范实算、ASC 头部含溯源注释；管线与坑清单见
   `uds-diagnostic-test/references/asc-evidence-pipeline.md`。
2. **篡改类探测的构造必须与判据语义一致**：改 IV/载荷后若重算 AUTH，报文自洽 → DUT 接受属
   **正确行为**，不得判安全缺陷；真篡改必须**保留原 AUTH** 只改被校验载荷。构造前先写明期望的失败层。
3. **NRC/响应判据不得硬编码单一值**：集合取自 SDDB（诊断数据库）Service 表记载；判据优先级
   **SDDB > xlsx 用例表 > 实现侧状态机文档 > ISO 14229/17987**；xlsx 语义差异显式登记进证据链字段。
4. **探针/冒烟/格式校验产物与测试证据隔离**：SMOKE/FORMAT_CHECK 的 result JSON 混进证据目录
   会污染 summary 重建与审计对账（实测发生过），必须放独立目录并在索引中声明非证据件。
5. **密钥材料全 0xFF 的语义需用户确认**（约定密钥 vs 占位符，实测有过 PASS 先例），
   确认结论写入证据链登记，不得自行判定。
6. **样件状态门禁**：密钥/会话/编程状态相关用例判读前先确认样件当前状态
   （如 D09B 状态位、开发密钥 vs 已编程公钥），状态不符标 BLOCKED 并写明缺的状态，不判 FAIL。

## 主要入口

```text
scripts/security_framework.py       状态、目录与门禁
scripts/generate_security_cases.py  需求→参考模式→派生用例生成（无锚点即 BLOCKED）
scripts/coverage.py                 覆盖度与可测性分析（域/场景矩阵、缺口、优化提示）
scripts/source_coverage.py          参考工作簿选择性覆盖分析（只读解析“网络安全”工作表 → CS 场景归类 + 证据）
scripts/security_scan.py            敏感信息扫描
scripts/build_report.py             独立 HTML 框架报告
scripts/test_framework.py           单元测试
references/architecture.md          9 域、18 场景、证据规范
data/source_cases.json              参考 Excel 只读摘要（写作模式来源）
data/security_requirements.example.json 真实安全需求清单模板
data/cybersecurity_catalog.json     场景目录
templates/security-input-manifest.example.json 输入契约
```

## 输出要求

每次输出必须区分：

1. 参考资料事实；
2. 生成设计；
3. 输入缺口与阻塞；
4. 已执行证据；
5. 尚未执行的计划。

不得把“生成了用例”描述为“安全性已验证”。
