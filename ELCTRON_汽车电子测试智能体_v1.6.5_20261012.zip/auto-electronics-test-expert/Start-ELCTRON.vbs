Option Explicit
Dim shell, fs, root, script, command
Set shell = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
root = fs.GetParentFolderName(WScript.ScriptFullName)
script = fs.BuildPath(root, "Start-AutoElectronicsAgent.ps1")
If Not fs.FileExists(script) Then
  MsgBox "ELCTRON startup script is missing: " & script, vbCritical, "ELCTRON"
  WScript.Quit 1
End If
shell.CurrentDirectory = root
command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & script & Chr(34)
shell.Run command, 0, False
