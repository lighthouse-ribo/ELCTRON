# baseline —— P0 基线冻结产物

本目录是「专家模块智能体化改造」P0 阶段的交付物。
**P0 只新增本目录，不改动任何现有脚本、技能、提示词或插件清单。**

改造工作区：`plugins/marketplaces/my-experts/plugins/auto-electronics-test-expert`
运行时 cache 快照：保持不动（即「保留的专家包」）

---

## 目录内容

| 文件 | 类型 | 说明 |
|---|---|---|
| `asset_inventory.csv` | 台账 | 226 个资产按 A–I 九层归类，含 CLI 入口、IO 契约线索、测试配对、硬件依赖、复核标记 |
| `cleanup_candidates.csv` | 审计 | 逐文件的「产物 / 模块」判定与建议动作，只列不删 |
| `baseline_manifest.json` | 指纹 | 逐文件 SHA-256 + 字节数 + 整体聚合哈希 + git 侧状态快照 |
| `hw_risk_register.md` | 风险 | 硬件依赖字段级清单（不含真实值）+ 8 条风险 + 迁移检查清单 |
| `out_of_scope.md` | 签核 | 8 项不做范围 + R1–R8 红线 + 六阶段门禁 + P0 特别约束 |
| `p0_report.md` | 报告 | P0 执行报告与出口条件判定 |
| `evidence/` | 证据 | 回归测试原始输出等 |
| `tools/scan_assets.py` | 工具 | 资产台账扫描器（只读） |
| `tools/plan_cleanup.py` | 工具 | 清理候选审计器（只读，不删） |
| `tools/snapshot_baseline.py` | 工具 | 基线指纹生成与漂移校验（只读） |

---

## 三个工具

三个都是**只读**工具：不删除、不修改任何被扫描文件。

```bash
PY="C:/Users/80026384/.workbuddy/binaries/python/envs/default/Scripts/python.exe"

# 1) 资产台账：扫 A–I 九层，产出 asset_inventory.csv
"$PY" baseline/tools/scan_assets.py

# 2) 清理审计：以仓库 .gitignore 为判据，产出 cleanup_candidates.csv（只列不删）
"$PY" baseline/tools/plan_cleanup.py

# 3) 基线指纹：生成 baseline_manifest.json
"$PY" baseline/tools/snapshot_baseline.py

# 4) 漂移校验：与既有清单比对，报告 added / removed / changed
"$PY" baseline/tools/snapshot_baseline.py --verify
```

---

## 判据说明

### 资产分层（A–I）

沿用改造方案定义的九层：A 入口与治理 / B 项目与参考 / C 解析与设计 / D 静态质量门 /
E 执行编排 / F 协议与硬件 / G SWDL 专项 / H 证据与报告 / I 测试与可移植。

分层规则集中在 `scan_assets.py` 的 `SCRIPT_LAYER` 与 `PATH_LAYER` 两张表，
调整归属只改规则表，不改扫描逻辑。

### 产物 vs 模块

**以仓库自带的 `.gitignore` 为权威判据**，而不是主观判断：

| 判定 | 含义 |
|---|---|
| `DELETE_SAFE` | 被 `.gitignore` 排除且可再生（如 `__pycache__`），删除无信息损失 |
| `REVIEW_PROJECT_SPECIFIC` | 已入库但含项目特定锚点、且未被本技能 SKILL.md 引用，与「技能必须通用」原则冲突 |
| `REVIEW_TASK_PRODUCT` | 任务执行产物（历史评审报告），已被 `.gitignore` 白名单放行 |
| `REVIEW_IGNORED` | 被 `.gitignore` 命中但未归入已知类别，需人工确认 |
| `SKIP_PROTECTED` | 受保护目录（`.workbuddy/`、`agents/`、`avatars/`、`.codebuddy-plugin/`），任何情况不动 |
| `KEEP_MODULE` | 专家模块本体 |

### 基线双重冻结

只靠 git commit 不够：工作区存在未提交改动（6 改 + 3 新增）。
因此基线同时冻结：

1. **git 侧**：commit `f9c6984` + tag `v1.6.4-baseline`
2. **文件侧**：`baseline_manifest.json` 的逐文件 SHA-256 与聚合哈希

回退时两者一起校验，才能覆盖未提交改动。

---

## 回退方法

```bash
# A. 只回退到基线 commit（会丢弃未提交改动，谨慎）
git -C "<包根目录>" checkout f9c6984 -- .

# B. 校验当前工作区是否偏离基线（推荐先跑这个）
"$PY" baseline/tools/snapshot_baseline.py --verify
#    输出 added / removed / changed 三类漂移；无漂移时退出码 0
```

删除基线 tag（如需）：`git -C "<包根目录>" tag -d v1.6.4-baseline`
