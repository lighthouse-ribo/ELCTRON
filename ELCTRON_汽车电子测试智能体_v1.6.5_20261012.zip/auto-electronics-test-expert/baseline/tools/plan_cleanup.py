#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P0 清理候选审计器（只读，绝不删除）。

用途：在删除任何东西之前，先把「执行任务生成的产物」与「专家本身的模块」分开，
产出一份可人工确认的清单。本脚本自身不执行删除。

判据（按优先级）：
  1. 仓库自带的 .gitignore 是「产物 vs 模块」边界的权威定义（git status --ignored）。
  2. 受保护目录（.workbuddy/）一律标记 SKIP，即使被 gitignore 命中也不动。
  3. 已入库（tracked）但内容含项目特定锚点的文件 → REVIEW_PROJECT_SPECIFIC，
     与「技能通用化、禁止项目特定数据入库」原则冲突，需人工判定。

输出：
  baseline/cleanup_candidates.csv
  控制台汇总 + 建议动作

用法:
  python plan_cleanup.py [--root <专家包根目录>]
"""
import argparse
import csv
import os
import re
import subprocess
import sys

PROTECTED = (".workbuddy/", ".codebuddy-plugin/", "agents/", "avatars/")
REGENERABLE = ("__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache")
REGENERABLE_EXT = (".pyc", ".pyo", ".pyd")
PROJECT_TOKEN_RX = re.compile(
    r"(bbs[_-]?v?\d{3}\b|v436\b|p519\b|volvo\b|REQ-89\d{3}|TG1_TC)", re.I)
PROJECT_SCOPED_DATA_RX = re.compile(r"^skills/[\w-]+/data/.+\.json$")


def git(root, *args):
    try:
        r = subprocess.run(["git", "-C", root, *args], capture_output=True,
                           text=True, encoding="utf-8", errors="replace")
        return r.stdout if r.returncode == 0 else ""
    except OSError:
        return ""


def classify(rel, is_ignored, is_tracked, root):
    p = rel.replace(os.sep, "/")
    base = os.path.basename(p)

    if p.startswith(PROTECTED):
        return ("SKIP_PROTECTED", "受保护目录/模块，不在清理范围")

    if any(seg in p for seg in REGENERABLE) or base.endswith(REGENERABLE_EXT):
        return ("DELETE_SAFE", "Python 缓存，运行期自动重建，删除无信息损失")

    if p.startswith("deliverables/"):
        return ("REVIEW_TASK_PRODUCT", "任务执行产物（历史评审报告），已入库白名单，建议归档而非删除")

    if PROJECT_SCOPED_DATA_RX.match(p):
        path = os.path.join(root, rel)
        try:
            text = open(path, encoding="utf-8", errors="replace").read(200_000)
        except OSError:
            text = ""
        if base.endswith(".example.json"):
            return ("KEEP_MODULE", "技能内置示例数据，通用，保留")
        # 被同一技能 SKILL.md 明确引用的内置数据 → 属于技能定义的一部分
        skill_dir = p.split("/data/")[0]
        spec = os.path.join(root, skill_dir, "SKILL.md")
        if os.path.isfile(spec):
            try:
                spec_text = open(spec, encoding="utf-8", errors="replace").read(300_000)
            except OSError:
                spec_text = ""
            if base in spec_text:
                return ("KEEP_MODULE", "被本技能 SKILL.md 明确引用，属技能定义的内置数据")
        if PROJECT_TOKEN_RX.search(text):
            hit = PROJECT_TOKEN_RX.search(text).group(0)
            return ("REVIEW_PROJECT_SPECIFIC",
                    f"未被 SKILL.md 引用且含项目特定锚点（命中 “{hit}”），建议移出通用包")
        return ("KEEP_MODULE", "技能内置参考数据，未见项目特定锚点")

    if is_ignored:
        return ("REVIEW_IGNORED", "被 .gitignore 命中但未归入已知类别，需人工确认")

    if is_tracked:
        return ("KEEP_MODULE", "已入库的专家模块资产")
    return ("KEEP_MODULE", "未入库的专家模块资产（新增/未提交）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    args = ap.parse_args()
    root = os.path.abspath(args.root or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    ignored = set()
    for line in git(root, "status", "--ignored", "--short").splitlines():
        if line.startswith("!!"):
            ignored.add(line[3:].strip().strip('"').replace("\\", "/"))

    tracked = set()
    for line in git(root, "ls-files").splitlines():
        if line.strip():
            tracked.add(line.strip().replace("\\", "/"))

    rows = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != ".git"]
        for fn in filenames:
            rel = os.path.relpath(os.path.join(dirpath, fn), root)
            p = rel.replace(os.sep, "/")
            size = os.path.getsize(os.path.join(root, rel))
            # 目录级 ignored（git 只报目录）也要能命中文件
            is_ign = p in ignored or any(p.startswith(d.rstrip("/") + "/") for d in ignored)
            is_trk = p in tracked
            action, reason = classify(p, is_ign, is_trk, root)
            rows.append(dict(action=action, rel_path=p, size_bytes=size,
                             git_tracked="yes" if is_trk else "no",
                             git_ignored="yes" if is_ign else "no", reason=reason))

    order = {"DELETE_SAFE": 0, "REVIEW_PROJECT_SPECIFIC": 1, "REVIEW_TASK_PRODUCT": 2,
             "REVIEW_IGNORED": 3, "SKIP_PROTECTED": 4, "KEEP_MODULE": 5}
    rows.sort(key=lambda r: (order.get(r["action"], 9), r["rel_path"]))

    out = os.path.join(root, "baseline", "cleanup_candidates.csv")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    from collections import defaultdict
    agg = defaultdict(lambda: [0, 0])
    for r in rows:
        agg[r["action"]][0] += 1
        agg[r["action"]][1] += r["size_bytes"]

    print(f"root : {root}")
    print(f"csv  : {out}\n")
    print(f"{'action':<26}{'files':>7}{'size':>12}")
    print("-" * 46)
    for a in sorted(agg, key=lambda x: order.get(x, 9)):
        c, s = agg[a]
        print(f"{a:<26}{c:>7}{s/1024:>10.1f} KB")

    for a in ("DELETE_SAFE", "REVIEW_PROJECT_SPECIFIC", "REVIEW_TASK_PRODUCT", "REVIEW_IGNORED"):
        items = [r for r in rows if r["action"] == a]
        if not items:
            continue
        print(f"\n-- {a} ({len(items)}) --")
        for r in items[:40]:
            print(f"  {r['size_bytes']:>9} B  {r['rel_path']}")
        if len(items) > 40:
            print(f"  ... 另有 {len(items)-40} 项，见 CSV")
    return 0


if __name__ == "__main__":
    sys.exit(main())
