#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P0/T0.2 基线指纹工具（只读）。

生成 baseline/baseline_manifest.json：
  - 逐文件 SHA-256 + 字节数（排除 .git / __pycache__ / baseline 自身）
  - git 侧快照：HEAD commit、分支/游离状态、已修改、未跟踪、被忽略
  - 汇总统计与整体聚合哈希（用于判断「基线是否被改动」）

另有 --verify 模式：用清单重新校验工作区，报告漂移文件。改造期间每次改动前后都可跑。

用法:
  python snapshot_baseline.py            # 生成基线指纹
  python snapshot_baseline.py --verify   # 与既有清单比对，输出漂移
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys

EXCLUDE_DIRS = {".git", "__pycache__", "baseline", ".pytest_cache"}
EXCLUDE_EXT = (".pyc", ".pyo")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(root, *args):
    try:
        r = subprocess.run(["git", "-C", root, *args], capture_output=True,
                           text=True, encoding="utf-8", errors="replace")
        return r.stdout.strip() if r.returncode == 0 else ""
    except OSError:
        return ""


def collect(root):
    files = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        for fn in filenames:
            if fn.endswith(EXCLUDE_EXT) or fn.startswith("~$"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, fn), root).replace(os.sep, "/")
            p = os.path.join(root, rel)
            files[rel] = {"sha256": sha256(p), "size": os.path.getsize(p)}
    return files


def aggregate(files):
    h = hashlib.sha256()
    for rel in sorted(files):
        h.update(rel.encode("utf-8"))
        h.update(files[rel]["sha256"].encode("ascii"))
    return h.hexdigest()


def status_sets(root):
    out = {"modified": [], "untracked": [], "ignored_dirs": []}
    for line in git(root, "status", "--short").splitlines():
        if not line.strip():
            continue
        code, _, path = line[:2], line[2], line[3:].strip().strip('"')
        path = path.replace("\\", "/")
        if code.strip() == "??":
            out["untracked"].append(path)
        elif code.strip():
            out["modified"].append(path)
    for line in git(root, "status", "--ignored", "--short").splitlines():
        if line.startswith("!!"):
            out["ignored_dirs"].append(line[3:].strip().replace("\\", "/"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    ap.add_argument("--verify", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.root or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    man_path = os.path.join(root, "baseline", "baseline_manifest.json")

    if args.verify:
        if not os.path.isfile(man_path):
            print("no baseline manifest; run without --verify first")
            return 2
        old = json.load(open(man_path, encoding="utf-8"))
        cur = collect(root)
        added = sorted(set(cur) - set(old["files"]))
        removed = sorted(set(old["files"]) - set(cur))
        changed = sorted(k for k in set(cur) & set(old["files"])
                         if cur[k]["sha256"] != old["files"][k]["sha256"])
        print(f"baseline_aggregate : {old['aggregate_sha256']}")
        print(f"current_aggregate  : {aggregate(cur)}")
        print(f"added={len(added)} removed={len(removed)} changed={len(changed)}")
        for tag, items in (("ADDED", added), ("REMOVED", removed), ("CHANGED", changed)):
            for p in items[:30]:
                print(f"  {tag:<8} {p}")
        return 0 if not (added or removed or changed) else 1

    files = collect(root)
    st = status_sets(root)
    git_dir = git(root, "rev-parse", "--git-dir")
    is_worktree = os.path.isfile(os.path.join(root, ".git")) if not git_dir else False
    manifest = {
        "generated_by": "baseline/tools/snapshot_baseline.py",
        "root": root.replace("\\", "/"),
        "file_count": len(files),
        "total_bytes": sum(v["size"] for v in files.values()),
        "aggregate_sha256": aggregate(files),
        "git": {
            "head_commit": git(root, "rev-parse", "HEAD"),
            "head_short": git(root, "rev-parse", "--short", "HEAD"),
            "branch": git(root, "rev-parse", "--abbrev-ref", "HEAD") or "(detached)",
            "branch_line": git(root, "status", "--short", "--branch").splitlines()[0] if git(root, "status", "--short", "--branch") else "",
            "is_linked_worktree": bool(is_worktree),
        },
        "worktree_state": st,
        "files": files,
    }
    os.makedirs(os.path.dirname(man_path), exist_ok=True)
    with open(man_path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)

    print(f"manifest : {man_path}")
    print(f"files    : {len(files)}  ({manifest['total_bytes']/1024/1024:.2f} MB)")
    print(f"aggregate: {manifest['aggregate_sha256']}")
    print(f"HEAD     : {manifest['git']['head_short']}  branch={manifest['git']['branch']}")
    print(f"modified={len(st['modified'])} untracked={len(st['untracked'])} ignored={len(st['ignored_dirs'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
