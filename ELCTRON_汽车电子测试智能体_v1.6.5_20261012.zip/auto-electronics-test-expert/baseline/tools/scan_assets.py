#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P0/T0.1 资产台账扫描器（只读，不删除任何文件）。

扫描 auto-electronics-test-expert 专家包，按 A–I 九层产出：
    baseline/asset_inventory.csv     全量资产台账
    baseline/asset_summary.md        分层/分类汇总

用法:
    python scan_assets.py [--root <专家包根目录>]

设计约定：
- 只读。本脚本永不删除或修改被扫描文件。
- 分层用「文件名规则 + 路径规则」两段式判定，规则集中在 SCRIPT_LAYER / PATH_LAYER，
  调整归属只改规则表，不改扫描逻辑。
- CLI 入口判定：源码含 `if __name__ == "__main__"`。
- io_contract / cli_usage 是从源码提取的「契约线索」，不是权威契约，需人工复核。
- hw_dependency 只登记依赖**类型关键词**；绝不落库真实路径、通道号、DLL 路径或密钥值。
"""
import argparse
import csv
import os
import re
import sys
from collections import Counter

SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", "baseline", ".venv"}
A = ("A", "入口与治理")
B = ("B", "项目与参考")
C = ("C", "解析与设计")
D = ("D", "静态质量门")
E = ("E", "执行编排")
F = ("F", "协议与硬件")
G = ("G", "SWDL 专项")
H = ("H", "证据与报告")
I = ("I", "测试与可移植")

# 1) 脚本按文件名归属（.py / .ps1 优先命中）
SCRIPT_LAYER = {}
for files, layer in [
    (["project_config.py", "reference_router.py"], B),
    (["uds_survey_parser.py", "ldf_parser.py", "dbc_parser.py", "sddb_extract.py",
      "uds_test_generator.py", "gen_case_scripts.py", "steps_generator.py",
      "cybersecurity_case_generator.py", "swdl_case_generator.py",
      "generate_reference_cases.py", "reference_case_adapter.py",
      "lin_case_matrix.py", "lin_case_model.py", "generate_lin_matrix_cli.py",
      "security_framework.py", "generate_security_cases.py"], C),
    (["script_review.py", "review_truth.py", "review_depth.py",
      "project_artifact_binding.py", "check_template_drift.py",
      "consistency_check.py", "uds_case_gate.py", "swdl_case_review.py",
      "coverage.py", "source_coverage.py", "security_scan.py"], D),
    (["uds_runner.py", "timing_case_runner.py", "flow_contract.py",
      "result_contract.py", "partition_model.py", "session_flow.py",
      "session_keepalive.py"], E),
    (["f1l1_uds.py", "lin_tp.py", "lin_pci.py", "tp_layout.py", "can_init.py",
      "link_check.py", "timing_trace.py", "win_timer.py", "xcdev_wrapper.py",
      "rsa_4096.py", "seedkey_gen2.py", "expectation_check.py", "nrc_guide.py"], F),
    (["swdl_flow.py", "swdl_architecture.py", "swdl_trace_import.py",
      "swdl_report_adapter.py"], G),
    (["asc_evidence.py", "trace_env_mixin.py", "report_to_html.py",
      "error_log.py", "parse_cache.py", "build_report.py", "build_framework.py"], H),
    (["run_tests.py", "testsupport.py", "setup_env.ps1"], I),
    # srs-doc-extract / srs-uds-testcase-designer（需求解析与用例设计主链）
    (["extract_srs_text.py", "srs_input_analyzer.py", "srs_focus_extractor.py",
      "build_testcase_template.py", "build_testcase_xlsx.py", "testcase_headers.py",
      "execution_profile.py", "project_context_builder.py", "project_fact_mapper.py",
      "project_parser_adapter.py", "portable_pack_reader.py", "steps_generator.py",
      "uds_full_matrix_generator.py", "uds_req_matrix_generator.py",
      "script_header_template.py"], C),
    (["case_lint.py", "test_case_lint.py", "input_pack_validator.py",
      "project_capability_gate.py", "req_coverage.py"], D),
]:
    for f in files:
        SCRIPT_LAYER[f] = layer

# 2) 路径规则，按顺序先命中先返回
PATH_LAYER = [
    (lambda p, b: p.startswith(".codebuddy-plugin/"), A),
    (lambda p, b: p.startswith("agents/"), A),
    (lambda p, b: p in ("README.md", "DESIGN.md"), A),
    (lambda p, b: p.startswith("references/REFERENCE_ROUTING.md"), A),
    (lambda p, b: p.startswith("references/reference-routing.json"), A),
    (lambda p, b: p.startswith("references/input-file-spec.md"), A),
    (lambda p, b: p.startswith("references/portable-input-contract.md"), A),
    (lambda p, b: b == "SKILL.md", A),
    (lambda p, b: b == "README.md" and p.startswith("skills/"), A),
    (lambda p, b: b == "requirements.txt", A),
    (lambda p, b: b == "uds_report_framework.html", H),      # 报告展示框架
    (lambda p, b: "/schemas/" in p or p.startswith("schemas/"), B),
    (lambda p, b: "/templates/" in p, B),                    # 契约与模板资产
    (lambda p, b: "/data/" in p, B),                         # 技能内置参考数据
    (lambda p, b: "/references/" in p, B),
    (lambda p, b: b == "project_config.example.json", B),
    (lambda p, b: b == "input_manifest.example.json", B),
    (lambda p, b: b.endswith(".json"), B),                   # 脚本内参考数据（如 req_map_v31.json）
    (lambda p, b: p.startswith("examples/"), I),
    (lambda p, b: p.startswith("references/"), B),
    (lambda p, b: p.startswith("avatars/"), A),
    (lambda p, b: p.startswith("deliverables/"), ("-", "任务产物")),
    (lambda p, b: p.startswith(".workbuddy/"), ("-", "受保护运行数据")),
    (lambda p, b: b in (".gitignore",), ("-", "仓库元数据")),
]

HW_PATTERNS = [
    ("VICKCAN/CDP", re.compile(r"(vickcan|cdp_|xcdev)", re.I)),
    ("F1L1/LIN 硬件", re.compile(r"(f1l1|lin_?tp|lin_?pci|\bnad\b)", re.I)),
    ("CAN/CANFD", re.compile(r"(python-can|import can\b|canfd|can_init)", re.I)),
    ("$27 安全访问", re.compile(r"(seed_?key|security_?access|\$27|0x27|rsa_?4096)", re.I)),
    ("SWDL 刷写", re.compile(r"(swdl|bootloader|0x34|0x36|0x37)", re.I)),
    ("设备路径/驱动", re.compile(r"(\.dll|driver_?adapter|device_?path|baudrate)", re.I)),
    ("密钥材料", re.compile(r"(sa_?key|aes|cmac|private_?key|api_?key)", re.I)),
]
MAIN_RX = re.compile(r'if\s+__name__\s*==\s*[\'"]__main__[\'"]')
OPT_RX = re.compile(r'["\'](--[a-zA-Z0-9][\w-]*)["\']')
OUT_RX = re.compile(r"\b([\w./\\-]+\.(?:json|jsonl|csv|asc|xlsx|html|md|txt|log))\b")

EXPECTED_ASSET_TYPES = {
    ".py": "script", ".md": "reference", ".json": "schema_or_meta",
    ".ps1": "setup_script", ".png": "asset", ".txt": "reference",
    ".csv": "reference", ".example": "reference",
}


def classify(rel):
    p = rel.replace(os.sep, "/")
    b = os.path.basename(p)
    if b in SCRIPT_LAYER and p.startswith("skills/"):
        return SCRIPT_LAYER[b]
    if b.startswith("test_") and p.startswith("skills/"):
        return I
    if b in ("testsupport.py",):
        return I
    for pred, layer in PATH_LAYER:
        if pred(p, b):
            return layer or ("-", "任务产物")
    return "", "未归类"


def asset_type(base):
    if base.startswith("test_"):
        return "test"
    if base == "testsupport.py":
        return "test_support"
    if base == "SKILL.md":
        return "skill_spec"
    if base == ".gitkeep":
        return "placeholder"
    if base in (".gitignore",):
        return "repo_meta"
    ext = os.path.splitext(base)[1].lower()
    return EXPECTED_ASSET_TYPES.get(ext, ext.lstrip(".") or "other")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    args = ap.parse_args()
    root = args.root or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    root = os.path.abspath(root)

    files, scripts = [], {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if fn.startswith("~$"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, fn), root)
            files.append(rel)
            if fn.endswith(".py"):
                scripts.setdefault(fn, rel.replace(os.sep, "/"))

    rows = []
    for rel in sorted(files):
        base = os.path.basename(rel)
        layer = classify(rel)
        code, name = layer if layer else ("", "未归类")
        atype = asset_type(base)
        path = os.path.join(root, rel)
        size = os.path.getsize(path)
        entry = cli = io_contract = hw = flag = ""

        if atype in ("script", "test", "test_support", "setup_script"):
            try:
                text = open(path, encoding="utf-8", errors="replace").read(400_000)
            except OSError:
                text = ""
            entry = "yes" if MAIN_RX.search(text) else "no"
            cli = " ".join(sorted(set(OPT_RX.findall(text)))[:14])
            io_contract = "|".join(sorted(set(OUT_RX.findall(text)))[:10])
            hw = "|".join(tag for tag, rx in HW_PATTERNS if rx.search(text))
            if atype == "script" and entry == "no":
                flag = "no_cli_entry"
            if code in ("E", "F", "G") and not hw:
                flag = (flag + ";hw_unresolved").lstrip(";")

        test_cov = ""
        if atype == "script":
            cand = "test_" + base
            stem = base[:-3]
            test_cov = "|".join(sorted(
                [v for k, v in scripts.items() if k == cand or (k.startswith("test_") and stem in k)])[:3])

        rows.append(dict(layer_code=code, layer_name=name, asset_type=atype,
                         rel_path=rel.replace(os.sep, "/"), size_bytes=size,
                         entry_point=entry, cli_usage=cli, io_contract=io_contract,
                         test_coverage=test_cov, hw_dependency=hw, review_flag=flag))

    cols = list(rows[0].keys())
    out_csv = os.path.join(root, "baseline", "asset_inventory.csv")
    os.makedirs(os.path.dirname(out_csv), exist_ok=True)
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)

    by_layer = Counter((r["layer_code"], r["layer_name"]) for r in rows)
    by_type = Counter(r["asset_type"] for r in rows)
    size_by_layer = Counter()
    for r in rows:
        size_by_layer[(r["layer_code"], r["layer_name"])] += r["size_bytes"]
    no_cli = [r for r in rows if "no_cli_entry" in r["review_flag"]]
    untested = [r for r in rows if r["asset_type"] == "script" and not r["test_coverage"]]
    hwcnt = sum(1 for r in rows if r["hw_dependency"])

    print(f"root      : {root}")
    print(f"total     : {len(rows)} files, {sum(r['size_bytes'] for r in rows)/1024/1024:.2f} MB")
    print(f"csv       : {out_csv}")
    print("\n-- by layer --")
    for (c, n), cnt in sorted(by_layer.items(), key=lambda x: str(x[0])):
        print(f"  [{c}] {n:<12} files={cnt:<4} size={size_by_layer[(c,n)]/1024:8.1f} KB")
    print("\n-- by type --")
    for t, cnt in by_type.most_common():
        print(f"  {t:<18} {cnt}")
    print(f"\nscripts without __main__ : {len(no_cli)}")
    print(f"scripts without test pair: {len(untested)}")
    print(f"files with hw dependency : {hwcnt}")
    if no_cli:
        print("\n-- no_cli_entry (top 20) --")
        for r in no_cli[:20]:
            print(f"  [{r['layer_code']}] {r['rel_path']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
