#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""DLP 落盘状态体检（可复用门禁）。

背景
----
本机受公司 DLP 透明加密（TsdEncrypt/TsdEncryptMF）保护。加密驱动**按访问进程**
决定返回明文还是密文：受信任程序（git、rg、IAR）看到明文视图，普通进程（Python、
多数编辑器、预览面板）看到 `%TSD-Header-###%` 密文。

实测规律（2026-09-15 普查 24581 个文本类文件）：

  * **git 写盘的文件是密文** —— `git worktree` / `git clone` / 快照备份产出的
    `.md` 等文本文件在磁盘上都是密文；
  * **安装机制写盘的文件是明文** —— 本专家包源仓库 286 个文件全为明文。

因此同一份内容可能「在 worktree 里打开是乱码、在包根里打开正常」。本脚本用于把
这个状态**变成可检查的事实**，而不是靠经验猜。

两类用法
--------
1. **门禁**（默认）：检查本包是否为 0 密文。改造工作区必须 0 密文，否则编排层
   读写会静默看到乱码。

       python baseline/tools/scan_dlp_state.py

   退出码 0 = 通过（0 密文）；1 = 发现密文；2 = 用法错误。

2. **普查 + 找可读副本**：把其它位置（worktree、备份）也算进来，并为其定位
   本包内的明文等价文件。

       python baseline/tools/scan_dlp_state.py --census "$USERPROFILE/.codex/worktrees"

输出中「可读副本」列的判据是：同一相对路径在本包存在，且该副本读到的头不是 `%TSD`。
"""
from __future__ import annotations

import argparse
import os
import sys
from collections import Counter, defaultdict

TEXT_EXT = {
    ".md", ".py", ".json", ".csv", ".html", ".htm", ".txt", ".yaml", ".yml",
    ".ts", ".js", ".ps1", ".sh", ".cfg", ".ini", ".toml", ".xml",
}
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".next",
             "dist", "build", ".mypy_cache", ".pytest_cache"}
MAGIC = b"%TSD"
PACKAGE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))


def is_ciphertext(path: str) -> bool | None:
    """True=密文，False=明文，None=读不了。"""
    try:
        with open(path, "rb") as fh:
            return fh.read(len(MAGIC)) == MAGIC
    except OSError:
        return None


def walk_text_files(root: str):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            if os.path.splitext(name)[1].lower() in TEXT_EXT:
                yield os.path.join(dirpath, name)


def find_twin(path: str, package_root: str, max_up: int = 6) -> str:
    """在包根内按「同相对路径」寻找明文等价文件。

    逐级上溯路径祖先，以每个祖先为基点计算相对路径再拼到包根下。这样无论普查根
    传的是仓库根还是它的任一上层目录（如 `.codex`、`.codex/worktrees/6345`），
    都能命中同一份文件。返回命中的相对路径；找不到返回空串。
    """
    cur = path
    for _ in range(max_up):
        parent = os.path.dirname(cur)
        if not parent or len(parent) <= 3 or parent == cur:
            break
        cur = parent
        rel = os.path.relpath(path, cur)
        if rel.startswith(".."):
            continue
        cand = os.path.join(package_root, rel)
        if os.path.exists(cand) and is_ciphertext(cand) is False:
            return rel
    return ""


def gate(package_root: str) -> int:
    """门禁：本包必须 0 密文。"""
    scanned = 0
    bad: list[str] = []
    unknown: list[str] = []
    for full in walk_text_files(package_root):
        scanned += 1
        state = is_ciphertext(full)
        if state is True:
            bad.append(os.path.relpath(full, package_root))
        elif state is None:
            unknown.append(os.path.relpath(full, package_root))

    print(f"包根: {package_root}")
    print(f"受检文本类文件: {scanned}")
    print(f"密文: {len(bad)}   读取失败: {len(unknown)}")

    if bad:
        print("\n[FAIL] 本包出现密文文件 —— 编排层读写会看到乱码：")
        for rel in bad[:40]:
            print(f"   * {rel}")
        if len(bad) > 40:
            print(f"   ... 另有 {len(bad) - 40} 个")
        print("\n处置：删除后用明文通道重建（Write 工具 / PowerShell "
              "[System.IO.File]::WriteAllText 配 UTF8Encoding($false)），"
              "不要用 git checkout 或 cp 复制。")
        return 1
    if unknown:
        print("\n[WARN] 以下文件读不到，请人工确认：")
        for rel in unknown[:20]:
            print(f"   * {rel}")
        return 1
    print("\n[PASS] 本包 0 密文，全部明文可读。")
    return 0


def census(extra_roots: list[str], package_root: str) -> int:
    """普查：统计密文分布，并为本包内的明文等价文件建立映射。"""
    roots = [package_root] + [r for r in extra_roots if os.path.isdir(r)]
    enc: dict[str, list[str]] = defaultdict(list)
    scanned: Counter = Counter()

    for root in roots:
        for full in walk_text_files(root):
            scanned[root] += 1
            if is_ciphertext(full) is True:
                enc[root].append(full)

    total_scan = sum(scanned.values())
    total_enc = sum(len(v) for v in enc.values())
    print(f"受检 {total_scan} 个，密文 {total_enc} 个")
    print()
    print(f"{'位置':<52}{'受检':>8}{'密文':>8}")
    print("-" * 70)
    for root in roots:
        print(f"{root[:50]:<52}{scanned[root]:>8}{len(enc[root]):>8}")

    print("\n按前两层目录聚合（仅列 >=5 个的）：")
    agg: Counter = Counter()
    for root, files in enc.items():
        for full in files:
            rel = os.path.relpath(full, root)
            parts = rel.split(os.sep)
            agg[os.sep.join(parts[:2]) if len(parts) > 1 else rel] += 1
    for bucket, n in agg.most_common():
        if n >= 5:
            print(f"   {bucket:<50}{n:>6}")

    print("\n密文文件 -> 本包内可读副本：")
    no_twin = 0
    for root, files in enc.items():
        if os.path.normcase(root) == os.path.normcase(package_root):
            continue
        for full in sorted(files):
            twin = find_twin(full, package_root)
            label = os.path.relpath(full, root)
            if twin:
                print(f"   [有明文本] {label}  ->  {twin}")
            else:
                no_twin += 1
                print(f"   [仅此一份] {label}")
    print(f"\n无本包明文等价: {no_twin} 个 —— 需读取时走受信任 rg 通道，"
          f"确需预览则在工作区生成临时明文副本，用完即删。")
    return 0


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--package-root", default=PACKAGE_ROOT,
                        help="本包根目录（默认自动推断）")
    parser.add_argument("--census", nargs="*", default=None, metavar="ROOT",
                        help="额外普查的根目录（可多个）；给出即切换到普查模式")
    parser.add_argument("--limit", type=int, default=0,
                        help="普查明细最多打印多少条（0=不限）")
    args = parser.parse_args(argv)

    if args.census is not None:
        return census(args.census, args.package_root)
    return gate(args.package_root)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
