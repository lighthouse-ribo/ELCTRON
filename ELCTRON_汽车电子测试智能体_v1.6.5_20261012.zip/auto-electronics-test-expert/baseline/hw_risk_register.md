# T0.3 硬件依赖与风险登记

基线：`auto-electronics-test-expert` @ `f9c6984`（工作区指纹 `4c32a475…`）
日期：2026-09-15
扫描范围：专家包源仓库全部 226 个文件（排除 `.git` / `__pycache__`）
**登记原则：只登记字段名、依赖类型与风险结论。本文件不记录任何真实设备路径、通道号、波特率、密钥或凭据值。**

---

## 1 硬件与运行时依赖面（字段级清单）

### 1.1 传输层契约字段（来自 `schemas/portable-contract-v0.1.json` 与 `examples/execution-profile.local.example.json`）

| 字段 | 含义 | 是否机器相关 | 处置 |
|---|---|---|---|
| `transport.adapter` | 驱动适配器名（示例：`xcdevlay`） | 否 | 可入库 |
| `transport.channel` | 通道标识（示例：`LIN1`） | **是** | 仅存 `config.local.json`，不入库 |
| `transport.library_path` | 驱动库完整路径 | **是** | 仅存 `config.local.json`，不入库 |
| `runtime.python` | 测试解释器路径 | **是** | 仅存本机配置 |
| `runtime.working_directory` | 工作目录 | **是** | 仅存本机配置 |
| `project_context.path` + `sha256` | 项目上下文路径与哈希 | 半 | 路径外置，哈希入库 |

### 1.2 环境变量依赖

| 变量 | 作用 | 现状 |
|---|---|---|
| `F1L1_DLL_PATH` | 显式指定 xcdevlay DLL 完整路径（**加载优先级第 1**） | 代码已支持覆盖 |
| `F1L1_XCWRAPPER_DIR` | 指定 wrapper 所在目录，缺省为 cwd / 脚本目录 | 代码已支持覆盖 |
| `UDS_PYTHON` | 测试/执行解释器（`run_tests.py` 解析顺序第 2） | 本机 `.uds_env` 已设置 |
| `UDS_SKILL_DIR` | 技能目录 | **本机已失效**，见 §3 风险 R-05 |
| `UDS_WORK` | 运行工作区 | 本机已设置 |

### 1.3 驱动与设备类型

| 依赖 | 类型 | 涉及脚本 | 通道独占要求 |
|---|---|---|---|
| CANviex F1L1（LIN） | `xcdevlay.dll` + ctypes 封装 | `xcdev_wrapper.py`、`f1l1_uds.py` | 必须关闭 VickCAN.exe / CANoe |
| Vector XL（CAN / CAN-FD） | `vxlapi64.dll`，需 64 位 Python | `can_init.py` | 需 Vector Driver Setup |
| VickCAN 上位机 | 仅作参考与人工操作，脚本不依赖其进程 | `references/VickCAN-help-重点.md` | 与 F1L1 互斥 |

### 1.4 密钥与凭据引用（**只登记引用形式，不登记值**）

| 项 | 形式 | 当前状态 |
|---|---|---|
| `$27` 安全访问 | `--sa-key-file <密钥文件路径>` | 占位全 0xFF 时应判 BLOCKED |
| 凭据引用 | `secure_key_references[].reference` = `credential://…` | 示例中 `available: false`、`material_in_context: false` |
| SWDL 密钥材料 | `swdl-input-manifest` 中 `role: security_key_material` | 示例中 `status: blocked`、`material_in_context: false` |

### 1.5 LIN 电气前置

- LIN 收发器供电由 `xLinOpt.outputV` 控制（DB9 pin4 = LIN-VBAT）。无外部 12 V 时必须开。
- 结构体对齐必须用 C 默认 8 字节（xNetpack 152 字节），禁止 `_pack_=1`。

---

## 2 已入库真实值扫描结果

| 检查项 | 结果 |
|---|---|
| 是否存在非 `example` 的本机配置文件（`*local*.json` / `execution-profile.json` / `project_config.json`） | **未发现**，包内只有 `*.example.json` |
| 生产代码中是否存在硬编码的 Windows 盘符路径 | **未发现**（仅示例文件与测试夹具中出现） |
| 是否存在明文密钥 / PEM 私钥 | **未发现**；`security_scan.py` 已内置私钥与 secret 检测规则 |
| 契约层是否禁止密钥字段 | **已禁止**：`execution_profile.py` 与 `test_portable_contract.py` 均有 `private_key / key_value / password / token` 等禁用字段清单 |
| `.gitignore` 是否已排除运行产物 | **已排除**：`live_runs/`、`out/`、`*_run_*/`、`case_scripts/`、`*.asc`、`*.blf`、`*.log`、`.workbuddy/`、`runtime-results/` |

**结论：包内没有泄漏真实设备配置或密钥，安全基线是干净的。**

---

## 3 风险登记

| ID | 风险 | 证据 | 影响 | 控制措施 | 归属任务 |
|---|---|---|---|---|---|
| R-01 | **DLL 绝对路径写死为默认值** | `xcdev_wrapper.py` 模块 docstring：加载优先级第 2 项为 `D:/VickCAN_x64_QT5_2.37++3/…/x64/xcdevlay.dll` | 换机后若未设 `F1L1_DLL_PATH` 会静默走错误路径，表现为"设备打不开"而非可读错误 | ① 改为「仅 `F1L1_DLL_PATH`，无默认值」；② 缺失时抛带修复指引的环境错误；③ 禁止把机器路径写进源码 | T6.1 / T6.2 |
| R-02 | 通道独占未强制 | 代码注释要求"执行前必须关闭 VickCAN.exe / CANoe"，但无进程锁 | 双任务并发打开同一通道 → 时序异常或打开失败，且证据不可信 | 本地执行器单实例锁 + 设备白名单 + 占用进程预检 | T3.1 / T3.2 |
| R-03 | 本机配置与发布包边界靠约定 | `examples/` 里同时存在 `*.example.json`，真实值需人工拷贝到本机 | 误把本机配置入库 → 泄漏设备信息且不可移植 | 契约强制 `config.local.json` 独立命名 + 打包前扫描 | T6.2 |
| R-04 | `$27` 占位密钥的判定依赖人工 | `gen_case_scripts.py --sa-key-file`，占位 0xFF 应判 BLOCKED | 占位密钥被当真实授权 → 生成不可执行脚本却标为可执行 | 执行前预校验密钥有效性，占位一律 BLOCKED | T3.6 |
| R-05 | `.uds_env` 存在失效条目 | `UDS_SKILL_DIR` 指向 `~/.workbuddy/skills/uds-diagnostic-test`，**该目录不存在** | 若某个脚本依赖它解析技能目录，会以"路径不存在"失败 | 基线阶段统一为「以包内相对路径解析」，`.uds_env` 只保留解释器与工作区 | T0.5 / T6.2 |
| R-06 | 存在未提交的工作区改动 | 6 个已修改文件 + 3 个新增脚本（含 `swdl_trace_import.py`） | 基线若按 commit 冻结会漏掉这些改动，后续 diff 失真 | 基线同时冻结 `baseline_manifest.json`（逐文件 SHA-256），不只依赖 commit | T0.2 |
| R-07 | 同一技能存在同名副本的另一处注册 | 用户级 `~/.workbuddy/skills/` 下**未**发现同名技能，但 `.uds_env` 曾指向该位置 | 技能解析可能命中陈旧副本 | 基线阶段确认解析来源唯一 | T0.5 |
| R-08 | 二进制专有 XCT 无解析能力 | 包内仅支持文本 XCT | 二进制 XCT 需人工转文本，否则证据链断裂 | 明确写为 BLOCKED，不伪装成已支持 | T4.5 |

---

## 4 迁移检查清单（换机器 / 换项目时必须逐项核对）

- [ ] `F1L1_DLL_PATH` 指向新机器上的 xcdevlay DLL（**不要改源码**）
- [ ] LIN 通道标识与 `transport.channel` 一致
- [ ] 测试解释器 `UDS_PYTHON` 指向已装齐 `requirements.txt` 的解释器
- [ ] 运行前确认 VickCAN.exe / CANoe 均未占用通道
- [ ] LIN 收发器供电策略（`outputV`）已按新台架确认
- [ ] SWDL 密钥材料以 `credential://` 引用提供，**不落盘、不入库、不进模型上下文**
- [ ] 打包前跑 `baseline/tools/plan_cleanup.py` 确认无本机配置混入
- [ ] 打包后跑 `baseline/tools/snapshot_baseline.py --verify` 确认指纹一致
