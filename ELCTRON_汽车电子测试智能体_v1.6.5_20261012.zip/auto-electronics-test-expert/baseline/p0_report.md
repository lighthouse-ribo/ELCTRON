# P0 基线冻结 · 执行报告

日期：2026-09-15
改造工作区：`plugins/marketplaces/my-experts/plugins/auto-electronics-test-expert`
基线 commit：`f9c6984` ｜ 基线 tag：`v1.6.4-baseline`
工作区指纹：`4c32a4757bcf0d8b198647c09282f54c653da34efb1bc09c4b9a48d1b89e06a9`
运行时 cache 快照：**未改动**（即保留的专家包）

---

## 1 P0 出口条件判定

| 出口条件 | 判定 | 证据 |
|---|---|---|
| 资产台账完整 | **通过** | `asset_inventory.csv`：226 个文件全部归档，未归类 0 项 |
| 全量回归通过 | **通过** | 49/49 PASS，退出码 0，耗时 5 分 29 秒（`evidence/regression_2026-09-15.txt`） |
| 可回退 | **通过** | tag `v1.6.4-baseline` → `f9c6984`；逐文件 SHA-256 指纹可校验 |
| 红线书面确认 | **待签核** | `out_of_scope.md` 已出具，8 项不做范围 + R1–R8 待签字 |
| 执行产物已清理 | **部分完成** | 45/60 个 `.pyc` 已删；剩余 15 个受单轮批量删除阈值阻断 |

**P0 结论：技术出口条件全部达成，仅剩「红线签核」与「15 个缓存文件」两项收尾。**

---

## 2 五项任务执行结果

| ID | 任务 | 结果 | 交付物 |
|---|---|---|---|
| T0.1 | 清点九层资产台账 | **完成** | `asset_inventory.csv`、`tools/scan_assets.py` |
| T0.2 | 冻结基线 + 全量回归 | **完成** | tag `v1.6.4-baseline`、`baseline_manifest.json`、`evidence/regression_2026-09-15.txt` |
| T0.3 | 硬件依赖与风险登记 | **完成** | `hw_risk_register.md`（8 条风险 + 迁移检查清单） |
| T0.4 | 确认 CodeBuddy SDK 环境 | **完成（含 1 项待办）** | 见 §5 |
| T0.5 | 不做范围与红线确认 | **出具完成，待签核** | `out_of_scope.md` |

---

## 3 T0.1 资产台账

226 个文件，2.99 MB。其中**专家模块 207 个文件（2.82 MB）**，非模块 19 个（任务产物 4 + 受保护运行数据 14 + 仓库元数据 1）。

| 层 | 文件数 | 体积 | 说明 |
|---|---|---|---|
| A 入口与治理 | 19 | 510.0 KB | agent 定义、参考路由、输入规范、技能 SKILL.md、头像 |
| B 项目与参考 | 51 | 485.2 KB | 三套 ISO 速查分支、契约 Schema、技能内置数据、模板 |
| C 解析与设计 | 30 | 805.1 KB | 调查表/LDF/DBC 解析器、用例与脚本生成器（最大层） |
| D 静态质量门 | 16 | 189.2 KB | case_lint、script_review、review_truth、能力/覆盖门禁 |
| E 执行编排 | 7 | 212.7 KB | uds_runner、timing_case_runner、契约与分区模型 |
| F 协议与硬件 | 13 | 108.8 KB | f1l1_uds、lin_tp、lin_pci、can_init、链路与时序 |
| G SWDL 专项 | 4 | 71.3 KB | swdl_flow、architecture、trace_import、report_adapter |
| H 证据与报告 | 8 | 157.2 KB | asc_evidence、trace_env_mixin、report_to_html |
| I 测试与可移植 | 59 | 346.7 KB | 49 个 test_*.py + 可移植项目包样例 |

结构指标：**79 个脚本、49 个测试、8 个技能、20 个契约/元数据、97 个脚本带 CLI 入口、41 个脚本有测试配对。**

### 关键判读

- **C 层最重（805 KB）**：`uds_test_generator.py`、`gen_case_scripts.py`、`script_header_template.py` 三个大件占大头。改造时它们是 LangGraph 计划节点的被调用工具，**不建议拆分**。
- **I 层文件数最多（59）**：49 个测试覆盖 4 个技能，是可回退性的真实保障。
- **未归类 0 项**：分层规则已收敛，可作为后续改造的稳定索引。

---

## 4 执行产物清理

判据：**以仓库自带 `.gitignore` 为权威定义**，不主观判断。

| 判定 | 文件数 | 体积 | 处置 |
|---|---|---|---|
| `DELETE_SAFE`（Python 缓存） | 60 | 1231.6 KB | **已删 45 个**；剩 15 个（332 KB）受单轮批量删除阈值阻断 |
| `REVIEW_PROJECT_SPECIFIC` | 2 | 46.3 KB | 保留（用户裁定） |
| `REVIEW_TASK_PRODUCT` | 4 | 84.0 KB | 保留（用户裁定） |
| `SKIP_PROTECTED` | 17 | 423.5 KB | 不动 |
| `KEEP_MODULE` | 207 | 2590.8 KB | 不动 |

**包体变化：5.0 MB → 4.1 MB。**

> 注：60 个 `.pyc` 中有一个 `f1l1_uds.cpython-312.pyc` 与 `f1l1_uds.cpython-313.pyc` 并存，说明该脚本曾被 Python 3.12 与 3.13 两个解释器分别执行过 —— 环境双轨的痕迹，已记入风险 R-05 相关观察。

### 未采纳的清理项（保留原因）

| 文件 | 保留理由 |
|---|---|
| `cybersecurity-test/data/security_requirements.bbs_v436.json` | 含 BBS V436 真实 SWRS REQ 锚点，删了不可恢复；建议后续**移到项目包**而非删除 |
| `cybersecurity-test/data/source_case_scenarios.json` | 参考工作簿解析产物；同上，建议移出通用包 |
| `deliverables/` 4 份 .md | 历史审计证据（冗余审计 / 误判 Fail 根因 / 专家包审查与实机复测 / 版本收敛验收） |

---

## 5 T0.4 CodeBuddy SDK 环境确认

| 项 | 状态 | 说明 |
|---|---|---|
| Node.js | **可用** | v22.22.2 |
| npm | **可用** | 10.9.7 |
| CodeBuddy CLI（`codebuddy`） | **未安装** | 不在 PATH。**P5 的 T5.1 需要先装**：`npm install -g @tencent-ai/codebuddy-code` |
| Chat Web 模板 | **可用** | `plugins/cache/cb_teams_marketplace/codebuddy-chat-web/1.0.0`，含 `copy-template.sh` 与完整 `templates/` |
| 测试解释器 | **可用** | `.uds_env` 的 `UDS_PYTHON` 指向已装齐依赖的解释器：`python-can 4.6.1`、`openpyxl 3.1.5`、`cryptography 49.0.0`、`cantools 42.0.3`、`fitz 1.28.0`、`pywin32` 全部 OK |
| `~/.uds_env` | **1 项失效** | `UDS_SKILL_DIR` 指向 `~/.workbuddy/skills/uds-diagnostic-test`，**该目录不存在**（`~/.workbuddy/skills/` 下无同名技能）。记入风险 R-05 |

**判定：Web 侧环境基本就绪，唯一缺口是 CodeBuddy CLI 未安装。该缺口不阻塞 P1–P4（纯 Python 治理层），只影响 P5 的模板初始化。**

---

## 6 关键发现（供 P1 起使用）

1. **DLL 绝对路径写死为默认值**（最高优先级）。`xcdev_wrapper.py` docstring 声明加载优先级第 2 项是一台开发机的绝对路径。换机后若未设 `F1L1_DLL_PATH`，会静默走错路径，表现为"设备打不开"而非可读错误。→ 必须在 T6.2 前改为「无默认值 + 缺失即抛可读错误」。
2. **安全基线干净**。包内没有真实本机配置、没有硬编码盘符路径（生产代码）、没有明文密钥；`security_scan.py` 已内置私钥与 secret 检测；契约层 `execution_profile.py` 与 `test_portable_contract.py` 都有禁用字段清单（`private_key / key_value / password / token`）。
3. **`.gitignore` 已定义产物边界**，可直接作为改造期「什么能提交」的机器判据。
4. **存在未提交的工作区改动**（6 改 + 3 新增，含 `swdl_trace_import.py`）。因此基线采用**双重冻结**：commit + 逐文件 SHA-256。只靠 commit 会漏掉这些改动。
5. **工作区指纹零漂移**：回归跑完后再校验，`added=0 removed=0 changed=0`，证明本轮未污染任何被扫描文件。

---

## 7 遗留项与下一步

| # | 遗留项 | 处置 |
|---|---|---|
| 1 | 15 个 `.pyc`（332 KB）未删 | 下一条消息继续（单轮批量删除阈值 50/轮，本轮已耗尽） |
| 2 | `out_of_scope.md` 待签核 | 需项目负责人、诊断测试、平台三方签字 |
| 3 | `codebuddy` CLI 未安装 | P5 前执行 `npm install -g @tencent-ai/codebuddy-code` |
| 4 | 2 个项目特定数据 json 仍在通用包内 | 建议在 P1 建项目包结构时移出，而非删除 |
| 5 | `.uds_env` 的 `UDS_SKILL_DIR` 失效 | 在 T6.2 统一为「以包内相对路径解析」 |

### 建议的 P1 入口

按 `out_of_scope.md` 补齐签核后，直接进 **T1.1 契约单一来源**（9 份 JSON Schema）。
本轮已产出可复用的两项前置能力：

- 用 `baseline/tools/scan_assets.py` 建立「哪些脚本是契约生产者/消费者」的索引；
- 用 `baseline/tools/snapshot_baseline.py --verify` 作为每次改造后的漂移门禁（0 漂移才算没破坏基线）。
