# DESIGN.md — 报告页设计世界（report_to_html.py）

> 本文件记录 `skills/uds-diagnostic-test/scripts/report_to_html.py` 生成的 UDS 测试报告页的持久设计决策。新页面/组件继承此世界；改设计先改这里。
>
> **修订记录（2026-08-19）：以用户指定的原始交付页为唯一视觉基准。** 页面框架、DOM 层级、CSS、响应式断点和交互顺序以 `skills/uds-diagnostic-test/templates/uds_report_framework.html` 为准；`report_to_html.py` 只替换数据，不另起页面骨架。测试结果、统计和证据使用执行结果数据。

## 场景与模式

- 使用者：整车诊断工程师，在台架/实验室环境读一份夜测报告；屏幕即仪表。
- 模式：**Operate + Read**（工程师浏览测试统计并定位用例证据）。
- 方向契约：**保留原始交付页的浅色工程面板、渐变蓝标识、彩色模块语义、卡片网格、版本时间轴和分块报告结构**。只更新数据，不擅自把页面改成另一套视觉系统。

## 色彩

| Token | 值 | 用途 |
|---|---|---|
| 页面底/卡片/线 | `#f3f5fa` / `#ffffff` / `#e2e7f0` | 原始框架的浅色工程面板 |
| 正文/次级/标注 | `#17203a` / `#45536e` / `#63728e` | 原始框架文字层级 |
| 蓝色模块 | `#2563eb` / `#60a5fa` | 版本时间轴、UDS 模块、主状态与品牌标识 |
| 青色/紫色/琥珀/玫红 | `#0f9f8f` / `#7c5cd6` / `#d97706` / `#be185d` | 覆盖率、时序、阻塞、网络安全等真实语义分区 |
| 语义状态（数据编码） | `#15803d` PASS / `#64748b` NA / `#b45309` BLOCKED / `#b91c1c` FAIL | 状态文字色均达 AA；仅用于结果状态与对应 KPI，不用于装饰 |

- 规则：保留原始框架已有的多色分区，不额外引入新的配色体系；颜色只表达模块和结果语义。

## 字体与数字

- 无衬线：`system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "PingFang SC", "Microsoft YaHei"` 栈（Read 面工作字体，不引第三方字体，单文件离线可用是硬约束）。
- 等宽（数据/报文/编号/筛选器）：`Cascadia Mono / JetBrains Mono / SF Mono / Consolas / Menlo` 栈。
- 数字一律 `font-variant-numeric: tabular-nums`；KPI 通过率保留一位小数（`data-dec` 控制计数动画精度）。

## 布局与结构

- 顶栏和 Hero：沿用原始 `.topbar`、`.hero`、`.meta-grid`、`.typebar`。
- **软件版本时间轴**：沿用原始 `.tnav`、`.ttrack`、`.tnode`、`.tcard`。时间轴只切换版本报告。
- **报告内模块导航**：沿用 `.report-head` 与 `.module-nav` 连续容器。UDS、网络安全及后续模块属于同一版本报告，未执行模块显示规划占位。
- 内容区：沿用原始 `.grid` 和 `.card` 分块；覆盖率 `.c-cov` 与时序 `.c-tm` 保持并排等高；阻塞 `.c-blk`、参数 `.c-par`、服务 `.c-svc` 和用例明细保持原顺序。
- 用例明细：沿用原始 `.toolbar`、`.fbtn`、`.search`、`.tbl-wrap`、`.vchip`，筛选按钮显示真实数量。

## 动效与浏览器面

- 沿用原始模板的轻量滚动、时间轴选中反馈、报告头闪烁和模块切换；不新增大面积动画。
- `prefers-reduced-motion: reduce` 时关闭平滑滚动和闪烁。
- 浏览器原生面沿用原模板：浅色滚动条、焦点描边、输入框聚焦样式。

## 打印

- `@media print`：沿用原模板打印规则，隐藏时间轴、回到顶部、筛选与搜索控件，取消表格滚动限制并恢复静态表头。

## 响应式

- 980px：Hero 元数据两列、KPI 三列、主内容单列、服务三列、参数单列；
- 560px：容器收窄、KPI 两列、服务两列、模块页签自适应。

## 数据惯例与判定口径

- 结果状态用 `vchip`：PASS / FAIL / NA / BLOCKED / SKIP，并保留 RETEST / DEVIATION 的独立筛选和颜色。
- 真实回包放入用例明细说明，服务分布按执行结果重新统计。
- 不编造：请求/响应全部来自执行结果；阻塞项标注“前置未满足”，不混判为 FAIL。

## 违禁（本世界）

- 不另起 v2 页面，不替换原始 `.wrap`、`.hero`、`.tnav`、`.report-block`、`.card` 结构。
- 不删除原始模块占位结构；未执行数据只显示规划/待录入，不伪装成结果。
- 不使用数据层之外的硬编码项目事实；版本、时间、链路和状态从输入数据注入。
- **改设计先改本文件，再改代码**；若代码与本文不一致，以代码实测为准并同步本文。

## 报告模板契约（固化到专家模块）

`report_to_html.py` 是所有离线 HTML 报告的唯一默认入口。`templates/uds_report_framework.html` 保存用户指定的原始交付页框架；后续测试只提供数据，不另起一套页面结构。

- **版本时间轴**：`versions[]` 的每个节点代表一次软件版本测试报告。节点可包含 `version`、`test_time`、`modules`、`summary`、`report_url`；时间轴只负责切换版本，不切换 UDS 或网络安全模块。
- **模块页签**：`modules[]` 属于当前软件版本的一份综合报告。每项包含 `id`、`label`、`status`、`count`，可选 `description` 或 `summary`。`status=planned`、`blocked`、`na` 只能显示规划或范围限制，不得伪装为实测结论。
- **默认模块**：未提供 `modules[]` 时自动生成 `UDS 诊断（executed）` 与 `网络安全（planned）` 两个模块；新增模块只需增加数据项，前端页签和占位面板自动生成。
- **数据状态**：`meta.notice` 用于说明本轮数据来源、复测范围和判定限制；缺省时使用不带项目事实的通用说明。链路状态使用 `meta.flag`，禁止在模板中写死某一总线、版本或执行结果。
- **视觉固定项**：原始页面的浅色工程面板、蓝/青/紫/琥珀/玫红语义色、覆盖率与时序同高双卡、绿色条纹与对应文字纵向排列、外框清晰的版本时间轴、模块页签与版本节点分工明确、可筛选用例明细、离线单文件可打开。
- **结果口径**：`PASS / FAIL / NA / BLOCKED / SKIP / RETEST / DEVIATION` 分开显示；`BLOCKED` 和 `SKIP` 不得被模板折算为 `FAIL`，协议通过率只使用可判定结果。

推荐附加数据最小结构：

```json
{
  "meta": {"version": "BBS_V436", "test_time": "2026-08-19", "notice": "..."},
  "versions": [{"version": "BBS_V436", "test_time": "2026-08-19", "modules": ["UDS 诊断", "网络安全"]}],
  "modules": [
    {"id": "uds", "label": "UDS 诊断", "status": "executed", "count": 70},
    {"id": "security", "label": "网络安全", "status": "planned", "count": 0, "description": "..."}
  ]
}
```
