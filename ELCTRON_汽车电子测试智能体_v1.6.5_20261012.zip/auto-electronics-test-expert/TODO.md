# 当前架构状态与续跑

2026-09-23 更新：生产执行器明确为 `runtime.orchestrator.graph.GraphRunner`；`langgraph_adapter.py` 是可选编译器，不是第二执行路径。`runtime_cli.py` 是唯一模型注入与状态推进边界，Web 只提交命令、读取事件/工件并提交审批，不能持有模型调用或写入运行状态。DeepSeek Worker 已接入原生 MCP 工具循环：模型请求 → runtime profile/MCP 双白名单执行 → 截断结果回传 → 受控草案；设计节点仍不能执行硬件。首个可运行切片为「真实 reference_router → 受控文件清单哈希挂载 → 确定性输入体检 → 模型+MCP 测试设计草案 → REVIEW_REQUIRED」。P6 记忆、失败样本、VICKCAN 均标记 dormant，等待不可伪造运行事件钩子后再接线，不计入交付完成度。

已关闭的架构歧义：`runtime/orchestrator/graph.py` 是五节点语义内核与唯一生产执行器；`langgraph_adapter.py` 仍为可选适配层。任何 Web 工作流记录只能是会话/展示投影，不能推进 `run_state.json`、生成审批令牌或调用模型。

已完成：新增 `runtime/orchestrator/production_nodes.py`（未接入真实能力时 fail-closed）与 `runtime/orchestrator/runtime_cli.py`（JSONL start/status/issue_approval/approve，唯一调用 GraphRunner）。Web `/api/workflows/*` 已代理该 CLI；审批由 runtime 签发并校验 `run_id + action + 有效期`，checkpoint 不落令牌元数据或凭据引用；`aetex-web/scripts/verify-p2.ts` 已覆盖启动、状态、审批、篡改拒绝及 Web 禁止直接写状态文件。

验证证据：`runtime.tests.test_graph` 34/34；`verify:p0`、`verify:p1`、`verify:p2` 全部 PASS；Node 类型检查（`tsconfig.node.json`）PASS；提交 `7eff4b2` / `d8fab61`，tag `v1.6.8-runtime-approval-guard`。

P3 真机前发布门槛已补齐：`runtime.executor.release_gate` 默认 fail-closed，覆盖设备白名单、租约冲突、崩溃恢复、ASC 首帧与落盘 SHA-256；`test_release_gate` 3/3 PASS。Web 全项目 TypeScript 历史错误已清零，`tsc -p tsconfig.json --noEmit` PASS；P0/P1/P2 均再次 PASS。

已知验证限制：真机硬件执行仍由 `production_nodes` fail-closed 阻断；发布门槛通过后，仍需完成真实资料路由和受控生产节点接线，才可进入人工审批后的只读真机 e2e。
